import type { GetAudioFromAPIOptions } from "../../types/audioDownloader";
import debug from "../../utils/debug";
import { GM_fetch } from "../../utils/gm";
import { getLastManifestUrl } from "../../utils/manifestSniffer";

const VK_PLAYER_SELECTOR = ".videoplayer_media, vk-video-player";

function makeSimpleFileId(size: number, chunkSize: number): string {
  return `vk_${size}_${chunkSize}_${Date.now()}`;
}

function isM3u8(url: string): boolean {
  return /\.m3u8(?:$|[?#])/i.test(url);
}

function isMpd(url: string): boolean {
  return /\.mpd(?:$|[?#])/i.test(url);
}

function resolveUrl(url: string, baseUrl: string): string {
  return new URL(url, baseUrl).toString();
}

function getVideoSrc(video: HTMLVideoElement): string {
  const sourceEl = video.querySelector("source");
  return String(
    video.currentSrc ||
      video.src ||
      sourceEl?.src ||
      sourceEl?.getAttribute("src") ||
      "",
  ).trim();
}

function isVisibleVideo(video: HTMLVideoElement): boolean {
  const rect = video.getBoundingClientRect();
  return rect.width > 64 && rect.height > 64;
}

function collectVideoCandidates(
  preferredVideo?: HTMLVideoElement | null,
): HTMLVideoElement[] {
  const seen = new Set<HTMLVideoElement>();
  const result: HTMLVideoElement[] = [];

  const push = (video: HTMLVideoElement | null | undefined) => {
    if (!(video instanceof HTMLVideoElement) || seen.has(video)) {
      return;
    }
    seen.add(video);
    result.push(video);
  };

  push(preferredVideo);

  for (const video of Array.from(document.querySelectorAll("video"))) {
    push(video);
  }

  return result;
}

function scoreVideoCandidate(
  video: HTMLVideoElement,
  preferredVideo?: HTMLVideoElement | null,
): number {
  let score = 0;
  const src = getVideoSrc(video);

  if (video === preferredVideo) score += 100;
  if (video.isConnected) score += 10;
  if (isVisibleVideo(video)) score += 25;
  if (video.closest(VK_PLAYER_SELECTOR)) score += 20;
  if (!video.paused) score += 8;
  if (video.readyState > 0) score += 8;
  if (src) score += 4;
  if (src && !src.startsWith("blob:")) score += 6;

  return score;
}

function normalizeCandidateUrl(url: string): string {
  try {
    return new URL(url, globalThis.location.href).toString();
  } catch {
    return String(url || "").trim();
  }
}

function scoreVkMediaUrl(url: string): number {
  const normalized = normalizeCandidateUrl(url);
  if (!normalized) {
    return Number.NEGATIVE_INFINITY;
  }

  const lower = normalized.toLowerCase();
  let score = 0;

  if (lower.startsWith("blob:")) score -= 100;
  if (/\.mp4(?:$|[?#])/i.test(normalized)) score += 50;
  if (/\.webm(?:$|[?#])/i.test(normalized)) score += 55;
  if (/\.m3u8(?:$|[?#])/i.test(normalized)) score += 45;
  if (/master\.m3u8/i.test(normalized)) score += 35;

  if (/\.mpd(?:$|[?#])/i.test(normalized)) score += 70;

  if (/manifest/i.test(normalized)) score += 15;
  if (/dashplaylist/i.test(normalized)) score += 15;
  if (/vkvd\d+\.okcdn\.ru|\.okcdn\.ru|vkvideo\.ru/i.test(normalized))
    score += 10;
  if (/\.okcdn\.ru/i.test(normalized)) {
    if (/[?&]ct=22(?:[&#]|$)/i.test(normalized)) score += 100;
    if (/[?&]ct=21(?:[&#]|$)/i.test(normalized)) score -= 50;
  }
  if (/[?&]bytes=\d+-\d+/i.test(normalized)) score -= 60;
  if (/[?&]subid=/i.test(lower)) score -= 80;
  if (/[?&]type=2(?:[&#]|$)/i.test(normalized)) score -= 80;

  return score;
}

function pickBestVkMediaUrl(
  candidates: Array<string | null | undefined>,
): string {
  let best = "";
  let bestScore = Number.NEGATIVE_INFINITY;

  for (const candidate of candidates) {
    const normalized = normalizeCandidateUrl(String(candidate || "").trim());
    const score = scoreVkMediaUrl(normalized);
    if (score > bestScore) {
      best = normalized;
      bestScore = score;
    }
  }

  return best;
}

function stripBytesParam(url: string): string {
  try {
    const u = new URL(url);
    u.searchParams.delete("bytes");
    return u.toString();
  } catch {
    return url;
  }
}

function getPerformanceMediaUrl(): string {
  try {
    const entries = performance.getEntriesByType("resource");
    const candidates = entries
      .map((entry) => {
        const raw = String(
          (entry as PerformanceResourceTiming)?.name || "",
        ).trim();
        return /[?&]bytes=\d+-\d+/i.test(raw) ? stripBytesParam(raw) : raw;
      })
      .filter((candidate) =>
        /vkvd\d+\.okcdn\.ru|\.okcdn\.ru|vkvideo\.ru/i.test(candidate),
      )
      .filter((candidate) =>
        /\.mp4(?:$|[?#])|\.webm(?:$|[?#])|\.m3u8(?:$|[?#])|\.mpd(?:$|[?#])|[?&]type=1(?:[&#]|$)/i.test(
          candidate,
        ),
      )
      .filter(Boolean);

    return pickBestVkMediaUrl(candidates);
  } catch {
    return "";
  }
}

async function fetchVkMedia(
  src: string,
  signal: AbortSignal,
): Promise<Response> {
  const isVkCdn =
    /(?:^|\.)okcdn\.ru/i.test(src) ||
    /vkvd\d+\.okcdn\.ru/i.test(src) ||
    /vkvideo\.ru/i.test(src);

  if (isVkCdn) {
    const gmRes = await GM_fetch(src, {
      signal,
      timeout: 0,
    });

    if (!gmRes.ok) {
      throw new Error(
        `[VOT] VK: failed to fetch media source via GM_fetch: ${gmRes.status}`,
      );
    }

    return gmRes;
  }

  try {
    const res = await fetch(src, {
      signal,
      credentials: "include",
    });

    if (res.ok) return res;
  } catch {
    // fallback below
  }

  const gmRes = await GM_fetch(src, {
    signal,
    timeout: 0,
  });

  if (!gmRes.ok) {
    throw new Error(`[VOT] VK: failed to fetch media source: ${gmRes.status}`);
  }

  return gmRes;
}

async function fetchText(src: string, signal: AbortSignal): Promise<string> {
  const res = await fetchVkMedia(src, signal);
  return await res.text();
}

async function fetchBytes(
  src: string,
  signal: AbortSignal,
): Promise<Uint8Array> {
  const res = await fetchVkMedia(src, signal);
  const buffer = await res.arrayBuffer();
  return new Uint8Array(buffer);
}

function parseM3u8Urls(text: string, baseUrl: string): string[] {
  return text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line && !line.startsWith("#"))
    .map((line) => resolveUrl(line, baseUrl));
}

async function resolveM3u8Segments(
  manifestUrl: string,
  signal: AbortSignal,
): Promise<string[]> {
  const manifestText = await fetchText(manifestUrl, signal);
  const urls = parseM3u8Urls(manifestText, manifestUrl);

  const nestedManifest = urls.find((url) => isM3u8(url));

  if (nestedManifest) {
    const nestedText = await fetchText(nestedManifest, signal);
    return parseM3u8Urls(nestedText, nestedManifest).filter(
      (url) => !isM3u8(url),
    );
  }

  return urls.filter((url) => !isM3u8(url));
}

async function resolveMpdAudioSegments(
  manifestUrl: string,
  signal: AbortSignal,
): Promise<string[]> {
  const manifestText = await fetchText(manifestUrl, signal);

  const xml = new DOMParser().parseFromString(manifestText, "application/xml");

  if (xml.querySelector("parsererror")) {
    throw new Error("[VOT] VK: failed to parse MPD");
  }

  const adaptationSets = Array.from(xml.querySelectorAll("AdaptationSet"));

  const audioSet = adaptationSets.find((set) => {
    const contentType = set.getAttribute("contentType") || "";
    const mimeType = set.getAttribute("mimeType") || "";

    return (
      contentType.toLowerCase() === "audio" ||
      mimeType.toLowerCase().startsWith("audio/")
    );
  });

  if (!audioSet) {
    throw new Error("[VOT] VK: MPD audio AdaptationSet not found");
  }

  const representations = Array.from(
    audioSet.querySelectorAll(":scope > Representation"),
  );

  if (!representations.length) {
    throw new Error("[VOT] VK: MPD audio Representation not found");
  }

  // Для распознавания речи нет смысла скачивать самый тяжёлый вариант.
  // Берём дорожку с минимальным bitrate.
  representations.sort((a, b) => {
    const left = Number(a.getAttribute("bandwidth") || Number.MAX_SAFE_INTEGER);
    const right = Number(
      b.getAttribute("bandwidth") || Number.MAX_SAFE_INTEGER,
    );

    return left - right;
  });

  const representation = representations[0];

  const segmentTemplate =
    representation.querySelector(":scope > SegmentTemplate") ||
    audioSet.querySelector(":scope > SegmentTemplate");

  if (!segmentTemplate) {
    throw new Error("[VOT] VK: MPD audio SegmentTemplate not found");
  }

  const initialization = segmentTemplate.getAttribute("initialization");
  const media = segmentTemplate.getAttribute("media");

  if (!initialization || !media) {
    throw new Error("[VOT] VK: invalid MPD audio SegmentTemplate");
  }

  let segmentNumber = Number(
    segmentTemplate.getAttribute("startNumber") || "1",
  );

  const result: string[] = [];

  const replaceTemplate = (template: string, number?: number): string => {
    let value = template;

    if (number !== undefined) {
      value = value.replace(/\$Number(?:%0\d+d)?\$/g, String(number));
    }

    const representationId = representation.getAttribute("id");

    if (representationId) {
      value = value.replace(/\$RepresentationID\$/g, representationId);
    }

    return resolveUrl(value, manifestUrl);
  };

  result.push(replaceTemplate(initialization));

  const timeline = segmentTemplate.querySelector("SegmentTimeline");

  if (!timeline) {
    throw new Error("[VOT] VK: MPD SegmentTimeline not found");
  }

  const segments = Array.from(timeline.querySelectorAll(":scope > S"));

  for (const segment of segments) {
    const repeat = Number(segment.getAttribute("r") || "0");

    // r=600 означает текущий сегмент + ещё 600 повторений.
    const count = repeat >= 0 ? repeat + 1 : 1;

    for (let i = 0; i < count; i++) {
      result.push(replaceTemplate(media, segmentNumber));
      segmentNumber++;
    }
  }

  return result;
}

export async function getAudioFromVkVideo({
  videoId,
  signal,
  preferredVideo,
}: GetAudioFromAPIOptions) {
  const videos = collectVideoCandidates(preferredVideo).sort(
    (left, right) =>
      scoreVideoCandidate(right, preferredVideo) -
      scoreVideoCandidate(left, preferredVideo),
  );
  const video = videos[0];

  if (!(video instanceof HTMLVideoElement)) {
    throw new Error("[VOT] VK: video element not found");
  }

  const sniffedManifestUrl = getLastManifestUrl();
  const performanceMediaUrl = getPerformanceMediaUrl();
  const selectedVideoSrc = getVideoSrc(video);
  const directVideoUrls = videos
    .map((candidate) => getVideoSrc(candidate))
    .filter((candidate) => candidate && !candidate.startsWith("blob:"));
  const src = pickBestVkMediaUrl([
    sniffedManifestUrl,
    performanceMediaUrl,
    ...directVideoUrls,
    selectedVideoSrc,
  ]);

  debug.log("[VOT] VK strategy videoId:", videoId);
  debug.log("[VOT] VK strategy manifest:", sniffedManifestUrl);
  debug.log("[VOT] VK strategy performance media:", performanceMediaUrl);
  debug.log("[VOT] VK strategy currentSrc:", video.currentSrc);
  debug.log("[VOT] VK strategy src:", video.src);
  debug.log("[VOT] VK strategy selected video src:", selectedVideoSrc);
  debug.log(
    "[VOT] VK strategy candidate videos:",
    videos.map((candidate) => ({
      src: getVideoSrc(candidate),
      visible: isVisibleVideo(candidate),
      paused: candidate.paused,
      readyState: candidate.readyState,
      score: scoreVideoCandidate(candidate, preferredVideo),
    })),
  );
  debug.log("[VOT] VK strategy selected src:", src);

  if (!src) {
    throw new Error("[VOT] VK: empty video src");
  }

  if (src.startsWith("blob:")) {
    throw new Error(
      "[VOT] VK: blob source detected; need direct mp4/webm/m3u8/mpd URL from player/network",
    );
  }

  const chunkSize = 256 * 1024;

  if (isMpd(src)) {
    const segmentUrls = await resolveMpdAudioSegments(src, signal);

    if (!segmentUrls.length) {
      throw new Error("[VOT] VK: empty MPD audio segment list");
    }

    debug.log("[VOT] VK strategy MPD audio segments:", segmentUrls.length);
    debug.log("[VOT] VK strategy MPD first segment:", segmentUrls[0]);
    debug.log(
      "[VOT] VK strategy MPD last segment:",
      segmentUrls[segmentUrls.length - 1],
    );

    // OK.ru DASH:
    // track.a.m4s + s1.a.m4s + s2.a.m4s + ...
    // Browser confirmed that concatenating these fragments produces
    // a playable audio/mp4 stream.
    const parts: Uint8Array[] = [];
    let totalLength = 0;

    for (let i = 0; i < segmentUrls.length; i++) {
      const segmentUrl = segmentUrls[i];
      const bytes = await fetchBytes(segmentUrl, signal);

      if (!bytes.byteLength) {
        throw new Error(
          `[VOT] VK: empty MPD audio segment ${i}/${segmentUrls.length}`,
        );
      }

      parts.push(bytes);
      totalLength += bytes.byteLength;

      debug.log(
        `[VOT] VK strategy MPD downloaded ${i + 1}/${segmentUrls.length}`,
      );
    }

    if (!totalLength) {
      throw new Error("[VOT] VK: empty combined MPD audio");
    }

    const combined = new Uint8Array(totalLength);

    let offset = 0;

    for (const part of parts) {
      combined.set(part, offset);
      offset += part.byteLength;
    }

    const fileId = `vk_dash_audio_${totalLength}_${Date.now()}`;

    debug.log("[VOT] VK strategy MPD combined bytes:", totalLength);
    debug.log("[VOT] VK strategy MPD combined fileId:", fileId);

    return {
      fileId,
      mediaPartsLength: 1,

      async *getMediaBuffers(): AsyncGenerator<Uint8Array> {
        yield combined;
      },
    };
  }

  if (isM3u8(src)) {
    const segmentUrls = await resolveM3u8Segments(src, signal);

    if (!segmentUrls.length) {
      throw new Error("[VOT] VK: empty m3u8 segment list");
    }

    const fileId = `vk_hls_${Date.now()}`;

    debug.log("[VOT] VK strategy m3u8 segments:", segmentUrls.length);

    return {
      fileId,
      mediaPartsLength: segmentUrls.length,
      async *getMediaBuffers(): AsyncGenerator<Uint8Array> {
        for (const segmentUrl of segmentUrls) {
          const bytes = await fetchBytes(segmentUrl, signal);

          if (!bytes.byteLength) {
            throw new Error("[VOT] VK: empty m3u8 segment");
          }

          yield bytes;
        }
      },
    };
  }

  const bytes = await fetchBytes(src, signal);

  if (!bytes.byteLength) {
    throw new Error("[VOT] VK: empty media bytes");
  }

  const mediaPartsLength = Math.max(1, Math.ceil(bytes.byteLength / chunkSize));
  const fileId = makeSimpleFileId(bytes.byteLength, chunkSize);

  debug.log("[VOT] VK strategy bytes:", bytes.byteLength);
  debug.log("[VOT] VK strategy mediaPartsLength:", mediaPartsLength);

  return {
    fileId,
    mediaPartsLength,
    async *getMediaBuffers(): AsyncGenerator<Uint8Array> {
      for (let start = 0; start < bytes.byteLength; start += chunkSize) {
        const end = Math.min(start + chunkSize, bytes.byteLength);
        yield bytes.subarray(start, end);
      }
    },
  };
}
