import { authCallbackOrigin, authCallbackPath } from "../config/config";
import { initAuth } from "../core/auth";
import { installGoogleDriveOverlayPatch } from "../core/google-drive-overlay";
import { installGoogleDriveTopFramePatch } from "../core/google-drive-top-frame";
import { installVkOverlayPatch } from "../core/vk-overlay";
import { installYandexDiskOverlayPatch } from "../core/yandex-disk-overlay";
import {
  ensureLocalizationProviderReady,
  localizationProvider,
} from "../localization/localizationProvider";
import debug from "../utils/debug";
import { isIframe } from "../utils/iframeConnector";
import { initIframeInteractor } from "./iframeInteractor";

type LogBootstrap = (
  message: string,
  details?: Record<string, unknown>,
) => void;

let runtimeActivated = false;
let runtimeActivationPromise: Promise<void> | null = null;
let iframeInteractorBound = false;

function isAuthPage(): boolean {
  return (
    globalThis.location.origin === authCallbackOrigin &&
    globalThis.location.pathname === authCallbackPath
  );
}

export async function ensureRuntimeActivated(
  reason: string,
  logBootstrap: LogBootstrap,
): Promise<void> {
  if (runtimeActivated) return;
  if (runtimeActivationPromise !== null) {
    await runtimeActivationPromise;
    return;
  }

  runtimeActivationPromise = (async () => {
    logBootstrap("Activating runtime", { reason });

    if (isAuthPage()) {
      await initAuth();
      runtimeActivated = true;
      return;
    }

    if (!isIframe()) {
      await ensureLocalizationProviderReady();
      await localizationProvider.update();
      debug.log(`Selected menu language: ${localizationProvider.lang}`);
    } else {
      debug.log("[VOT] iframe mode: skip localization init");
    }

    if (!iframeInteractorBound) {
      iframeInteractorBound = true;
      initIframeInteractor();
    }
    function isYandexDiskHost(): boolean {
      const host = globalThis.location.hostname.toLowerCase();
      return host === "disk.yandex.ru" || host === "disk.yandex.com";
    }
    function isGoogleDriveEmbedHost(): boolean {
      const host = globalThis.location.hostname.toLowerCase();
      return (
        host === "youtube.googleapis.com" &&
        globalThis.location.pathname.startsWith("/embed")
      );
    }
    function isGoogleDriveTopFrameHost(): boolean {
      const host = globalThis.location.hostname.toLowerCase();
      return (
        !isIframe() &&
        (host === "drive.google.com" || host === "docs.google.com")
      );
    }
    if (isYandexDiskHost()) {
      installYandexDiskOverlayPatch();
    }
    if (isGoogleDriveEmbedHost()) {
      installGoogleDriveOverlayPatch();
    }
    if (isGoogleDriveTopFrameHost()) {
      installGoogleDriveTopFramePatch();
    }
    installVkOverlayPatch();
    runtimeActivated = true;
  })();

  try {
    await runtimeActivationPromise;
  } finally {
    runtimeActivationPromise = null;
  }
}
