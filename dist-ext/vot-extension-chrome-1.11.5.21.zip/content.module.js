var Uc = Object.defineProperty;
var Hc = (n, t, e) => t in n ? Uc(n, t, { enumerable: !0, configurable: !0, writable: !0, value: e }) : n[t] = e;
var c = (n, t, e) => Hc(n, typeof t != "symbol" ? t + "" : t, e);
const Q = {
  host: "api.browser.yandex.ru",
  hostVOT: "vot.toil.cc/v1",
  hostWorker: "vot-worker.toil.cc",
  mediaProxy: "media-proxy.toil.cc",
  userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 YaBrowser/25.4.0.0 Safari/537.36",
  componentVersion: "25.6.0.2259",
  hmac: "bt8xH3VOlb4mqf0nqAibnDOoiPlXsisf",
  defaultDuration: 343,
  minChunkSize: 5295308,
  loggerLevel: 1,
  version: "2.4.12"
}, $c = {
  afr: "af",
  aka: "ak",
  alb: "sq",
  amh: "am",
  ara: "ar",
  arm: "hy",
  asm: "as",
  aym: "ay",
  aze: "az",
  baq: "eu",
  bel: "be",
  ben: "bn",
  bos: "bs",
  bul: "bg",
  bur: "my",
  cat: "ca",
  chi: "zh",
  cos: "co",
  cze: "cs",
  dan: "da",
  div: "dv",
  dut: "nl",
  eng: "en",
  epo: "eo",
  est: "et",
  ewe: "ee",
  fin: "fi",
  fre: "fr",
  fry: "fy",
  geo: "ka",
  ger: "de",
  gla: "gd",
  gle: "ga",
  glg: "gl",
  gre: "el",
  grn: "gn",
  guj: "gu",
  hat: "ht",
  hau: "ha",
  hin: "hi",
  hrv: "hr",
  hun: "hu",
  ibo: "ig",
  ice: "is",
  ind: "id",
  ita: "it",
  jav: "jv",
  jpn: "ja",
  kan: "kn",
  kaz: "kk",
  khm: "km",
  kin: "rw",
  kir: "ky",
  kor: "ko",
  kur: "ku",
  lao: "lo",
  lat: "la",
  lav: "lv",
  lin: "ln",
  lit: "lt",
  ltz: "lb",
  lug: "lg",
  mac: "mk",
  mal: "ml",
  mao: "mi",
  mar: "mr",
  may: "ms",
  mlg: "mg",
  mlt: "mt",
  mon: "mn",
  nep: "ne",
  nor: "no",
  nya: "ny",
  ori: "or",
  orm: "om",
  pan: "pa",
  per: "fa",
  pol: "pl",
  por: "pt",
  pus: "ps",
  que: "qu",
  rum: "ro",
  rus: "ru",
  san: "sa",
  sin: "si",
  slo: "sk",
  slv: "sl",
  smo: "sm",
  sna: "sn",
  snd: "sd",
  som: "so",
  sot: "st",
  spa: "es",
  srp: "sr",
  sun: "su",
  swa: "sw",
  swe: "sv",
  tam: "ta",
  tat: "tt",
  tel: "te",
  tgk: "tg",
  tha: "th",
  tir: "ti",
  tso: "ts",
  tuk: "tk",
  tur: "tr",
  uig: "ug",
  ukr: "uk",
  urd: "ur",
  uzb: "uz",
  vie: "vi",
  wel: "cy",
  xho: "xh",
  yid: "yi",
  yor: "yo",
  zul: "zu"
};
async function ja(n, t = {
  headers: {
    "User-Agent": Q.userAgent
  }
}) {
  const { timeout: e = 3e3, ...i } = t, s = new AbortController(), o = setTimeout(() => s.abort(), e), r = await fetch(n, {
    signal: s.signal,
    ...i
  });
  return clearTimeout(o), r;
}
function Wc() {
  return Math.floor(Date.now() / 1e3);
}
function tt(n) {
  return n.length === 3 ? $c[n] : n.toLowerCase().split(/[_;-]/)[0].trim();
}
function St(n, t = "mp4") {
  const e = `https://${Q.mediaProxy}/v1/proxy/video.${t}?format=base64&force=true`;
  return n instanceof URL ? `${e}&url=${btoa(n.href)}&origin=${n.origin}&referer=${n.origin}` : `${e}&url=${btoa(n)}`;
}
const zc = /(?:^|\.)vkvideo\.ru$|(?:^|\.)vk\.(?:com|ru)$/i, qc = /api\.vkvideo\.ru|\/al_video\.php(?:$|[?#])|\/method\/video\.|video_ext\.php|vkvideo\.ru/i, yo = /\.(vtt|srt|ass|json)(?:$|[?#])/i, Gc = 15e5, Kc = 64, ss = 600 * 1e3, Xn = /* @__PURE__ */ new Map(), vo = /* @__PURE__ */ Symbol("votSniffedSubtitleUrl");
let wo = !1;
function Yc(n) {
  return zc.test(n);
}
function Pi() {
  return Yc(String(globalThis.location.hostname || ""));
}
function Os(n) {
  try {
    return new URL(n, globalThis.location.href).href;
  } catch {
    return n;
  }
}
function Ds(n) {
  const t = n.split(/[?#]/u, 1)[0]?.toLowerCase() ?? "";
  return t.endsWith(".vtt") ? "vtt" : t.endsWith(".srt") ? "srt" : t.endsWith(".ass") ? "ass" : t.endsWith(".json") ? "json" : null;
}
function ke(n) {
  if (typeof n != "string")
    return;
  const t = n.trim();
  if (t)
    try {
      return tt(t);
    } catch {
      return t.toLowerCase().split(/[_;-]/u)[0]?.trim() || void 0;
    }
}
function _s(n) {
  try {
    const t = new URL(n, globalThis.location.href), e = t.searchParams.get("lang") || t.searchParams.get("language") || t.searchParams.get("locale") || t.searchParams.get("srclang");
    if (e)
      return ke(e);
    const i = decodeURIComponent(t.pathname), s = /(?:^|[._/-])([a-z]{2,3}(?:-[a-z]{2,4})?)(?=\.(?:vtt|srt|ass|json)\b)/i.exec(
      i
    ) || /(?:^|[._/-])([a-z]{2,3})(?:[._-]captions?)(?=\b)/i.exec(i);
    return ke(s?.[1]);
  } catch {
    return;
  }
}
function Xa(n, t) {
  const e = String(n || "").trim(), i = String(t || "").trim();
  if (!e || !i)
    return;
  const s = Number.parseInt(e, 10);
  if (!Number.isNaN(s))
    return `video-${Math.abs(s)}_${i}`;
}
function Rs(n) {
  try {
    const t = new URL(n, globalThis.location.href), e = /\/(video-?\d+_\d+)/i.exec(t.pathname) || /\/playlist\/[^/]+\/(video-?\d+_\d+)/i.exec(t.pathname);
    if (e?.[1])
      return e[1];
    const i = t.searchParams.get("z");
    if (i) {
      const r = /(video-?\d+_\d+)/i.exec(i);
      if (r?.[1])
        return r[1];
    }
    const s = t.searchParams.get("oid"), o = t.searchParams.get("id");
    if (s && o)
      return Xa(s, o);
  } catch {
    return;
  }
}
function jc(n) {
  return n !== null && typeof n == "object";
}
function Je(n, t) {
  for (const e of t) {
    const i = n[e];
    if (typeof i == "string" && i.trim())
      return i.trim();
  }
}
function So(n, t) {
  for (const e of t) {
    const i = n[e];
    if (typeof i == "number" && Number.isFinite(i))
      return String(i);
    if (typeof i == "string" && i.trim())
      return i.trim();
  }
}
function os(n) {
  if (typeof n == "boolean")
    return n;
  if (typeof n == "number")
    return n !== 0;
  if (typeof n == "string") {
    const t = n.trim().toLowerCase();
    if (t === "true" || t === "1") return !0;
    if (t === "false" || t === "0") return !1;
  }
}
function Xc(n) {
  const t = Je(n, [
    "videoId",
    "video_id",
    "video",
    "player_id"
  ]);
  if (t) {
    const s = /(video-?\d+_\d+)/i.exec(t);
    if (s?.[1])
      return s[1];
  }
  const e = So(n, [
    "owner_id",
    "ownerId",
    "oid",
    "video_oid"
  ]), i = So(n, ["id", "vid", "video_id", "videoId"]);
  if (e && i)
    return Xa(e, i);
}
function Jc(n) {
  return n === "subs" || n === "subtitles" || n === "captions" || n === "text_tracks" || n.includes("subtitle") || n.includes("caption");
}
function Zc(n, t) {
  const e = Je(n, [
    "url",
    "src",
    "file",
    "download_url",
    "downloadUrl",
    "webVttUrl",
    "webvtturl",
    "link"
  ]);
  if (!e)
    return null;
  const i = Os(e), s = Ds(i) ?? (t.collectionHint ? "vtt" : null);
  if (!s)
    return null;
  const o = ke(
    Je(n, [
      "lang",
      "language",
      "lang_code",
      "language_code",
      "locale",
      "locale_id",
      "srclang",
      "code",
      "subtitles_lang"
    ]) ?? t.languageHint ?? _s(i)
  );
  return o ? {
    source: "vk",
    format: s,
    language: o,
    url: i,
    translatedFromLanguage: ke(
      Je(n, [
        "translatedFromLanguage",
        "translated_from_language",
        "from_lang",
        "source_lang"
      ])
    ),
    isAutoGenerated: os(
      n.is_auto ?? n.isAutoGenerated ?? n.auto_generated ?? n.autogenerated
    )
  } : null;
}
function rs(n, t, e, i, s = 0) {
  if (s > 7 || n == null)
    return;
  if (Array.isArray(n)) {
    for (const u of n.slice(0, 400))
      rs(u, t, e, i, s + 1);
    return;
  }
  if (!jc(n) || i.has(n))
    return;
  i.add(n);
  const o = n, r = t.videoId ?? Xc(o), a = t.languageHint ?? ke(
    Je(o, [
      "subtitles_lang",
      "lang",
      "language",
      "locale",
      "locale_id"
    ])
  ), l = Zc(o, {
    ...t,
    languageHint: a
  });
  l && e.push({
    descriptor: l,
    seenAt: Date.now(),
    videoId: r
  });
  for (const [u, d] of Object.entries(o)) {
    if (d == null)
      continue;
    const h = {
      collectionHint: t.collectionHint || Jc(u.toLowerCase()),
      languageHint: a,
      videoId: r
    };
    rs(
      d,
      h,
      e,
      i,
      s + 1
    );
  }
}
function Qc(n) {
  return n.replace(/\\u0026/giu, "&").replace(/\\u002f/giu, "/").replace(/\\\//gu, "/");
}
function tu(n, t) {
  const e = [], i = /* @__PURE__ */ new Set(), s = Rs(t), o = Qc(n), r = (u, d, h) => {
    const f = ke(
      u ?? _s(String(d || ""))
    ), g = typeof d == "string" ? Os(d) : "", m = Ds(g) ?? "vtt";
    if (!f || !g)
      return;
    const v = `${s ?? ""}|${f}|${g}`;
    i.has(v) || (i.add(v), e.push({
      videoId: s,
      seenAt: Date.now(),
      descriptor: {
        source: "vk",
        format: m,
        language: f,
        url: g,
        isAutoGenerated: h
      }
    }));
  }, a = /["'](?:lang|language|locale|subtitles_lang)["']\s*:\s*["']([a-zA-Z_-]{2,12})["'][\s\S]{0,400}?["']url["']\s*:\s*["']([^"'\\]+(?:\\.[^"'\\]*)*)["'][\s\S]{0,120}?(?:["']is_auto["']\s*:\s*(true|false|0|1))?/g, l = /["']url["']\s*:\s*["']([^"'\\]+(?:\\.[^"'\\]*)*)["'][\s\S]{0,400}?["'](?:lang|language|locale|subtitles_lang)["']\s*:\s*["']([a-zA-Z_-]{2,12})["'][\s\S]{0,120}?(?:["']is_auto["']\s*:\s*(true|false|0|1))?/g;
  for (const u of o.matchAll(a))
    r(u[1], u[2], os(u[3]));
  for (const u of o.matchAll(l))
    r(u[2], u[1], os(u[3]));
  return e;
}
function Bs(n, t) {
  if (!t.length)
    return;
  const e = Date.now(), i = Xn.get(n) ?? [], s = /* @__PURE__ */ new Map();
  for (const r of i)
    e - r.seenAt > ss || s.set(
      [
        r.videoId ?? "",
        r.descriptor.language,
        r.descriptor.translatedFromLanguage ?? "",
        r.descriptor.url
      ].join("|"),
      r
    );
  for (const r of t)
    e - r.seenAt > ss || s.set(
      [
        r.videoId ?? "",
        r.descriptor.language,
        r.descriptor.translatedFromLanguage ?? "",
        r.descriptor.url
      ].join("|"),
      r
    );
  const o = Array.from(s.values()).sort((r, a) => a.seenAt - r.seenAt).slice(0, Kc);
  Xn.set(n, o);
}
function To(n) {
  const t = Os(n), e = Ds(t), i = _s(t);
  !e || !i || Bs("vk", [
    {
      videoId: Rs(t),
      seenAt: Date.now(),
      descriptor: {
        source: "vk",
        format: e,
        language: i,
        url: t
      }
    }
  ]);
}
function Ja(n) {
  return qc.test(n);
}
function Fs(n, t) {
  const e = [];
  rs(
    t,
    {
      collectionHint: !1,
      videoId: Rs(n)
    },
    e,
    /* @__PURE__ */ new WeakSet()
  ), Bs("vk", e);
}
function as(n, t) {
  if (!(!t || t.length > Gc)) {
    try {
      Fs(n, JSON.parse(t));
      return;
    } catch {
    }
    Bs("vk", tu(t, n));
  }
}
function eu(n, t) {
  const e = String(t.headers.get("content-type") || "").trim().toLowerCase();
  if (!(!Ja(n) && !(e.includes("json") && /vkvideo|vk\.com|okcdn\.ru/i.test(n)))) {
    if (e.includes("json")) {
      t.clone().json().then((i) => {
        Fs(n, i);
      }).catch(() => {
        t.clone().text().then((i) => {
          as(n, i);
        }).catch(() => {
        });
      });
      return;
    }
    t.clone().text().then((i) => {
      as(n, i);
    }).catch(() => {
    });
  }
}
function nu(n, t) {
  const e = Date.now(), i = (Xn.get(n) ?? []).filter(
    (r) => e - r.seenAt <= ss
  );
  Xn.set(n, i);
  const s = t ? i.filter((r) => !r.videoId || r.videoId === t) : i, o = /* @__PURE__ */ new Map();
  for (const r of s)
    o.set(
      [
        r.descriptor.language,
        r.descriptor.translatedFromLanguage ?? "",
        r.descriptor.url
      ].join("|"),
      r.descriptor
    );
  return Array.from(o.values());
}
function iu() {
  if (wo)
    return;
  wo = !0;
  const n = globalThis.fetch.bind(globalThis);
  globalThis.fetch = async (...i) => {
    const s = await n(...i);
    if (!Pi())
      return s;
    const o = i[0], r = typeof o == "string" ? o : o instanceof Request ? o.url : String(o ?? "");
    return yo.test(r) && To(r), eu(r, s), s;
  };
  const t = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(i, s, ...o) {
    const r = String(s);
    return this[vo] = r, Pi() && yo.test(r) && To(r), t.call(this, i, s, ...o);
  };
  const e = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function(...i) {
    return Pi() && this.addEventListener(
      "load",
      () => {
        const s = this[vo];
        if (!s)
          return;
        const o = String(
          this.getResponseHeader("content-type") || ""
        ).trim().toLowerCase();
        if (!Ja(s) && !(o.includes("json") && /vkvideo|vk\.com|okcdn\.ru/i.test(s)))
          return;
        if (this.responseType === "json" && this.response) {
          Fs(s, this.response);
          return;
        }
        if (this.responseType !== "" && this.responseType !== "text" && this.responseType !== "json")
          return;
        const r = typeof this.responseText == "string" ? this.responseText : "";
        as(s, r);
      },
      { once: !0 }
    ), e.apply(this, i);
  };
}
var we;
(function(n) {
  n[n.DEBUG = 0] = "DEBUG", n[n.INFO = 1] = "INFO", n[n.WARN = 2] = "WARN", n[n.ERROR = 3] = "ERROR", n[n.SILENCE = 4] = "SILENCE";
})(we || (we = {}));
const wt = class wt {
  static canLog(t) {
    return Q.loggerLevel <= t;
  }
  static log(...t) {
    wt.canLog(we.DEBUG) && console.log(wt.prefix, ...t);
  }
  static info(...t) {
    wt.canLog(we.INFO) && console.info(wt.prefix, ...t);
  }
  static warn(...t) {
    wt.canLog(we.WARN) && console.warn(wt.prefix, ...t);
  }
  static error(...t) {
    wt.canLog(we.ERROR) && console.error(wt.prefix, ...t);
  }
};
c(wt, "prefix", `[vot.js v${Q.version}]`);
let M = wt;
function su() {
  let n = 0, t = 0;
  for (let i = 0; i < 28; i += 7) {
    let s = this.buf[this.pos++];
    if (n |= (s & 127) << i, (s & 128) == 0)
      return this.assertBounds(), [n, t];
  }
  let e = this.buf[this.pos++];
  if (n |= (e & 15) << 28, t = (e & 112) >> 4, (e & 128) == 0)
    return this.assertBounds(), [n, t];
  for (let i = 3; i <= 31; i += 7) {
    let s = this.buf[this.pos++];
    if (t |= (s & 127) << i, (s & 128) == 0)
      return this.assertBounds(), [n, t];
  }
  throw new Error("invalid varint");
}
function Mi(n, t, e) {
  for (let o = 0; o < 28; o = o + 7) {
    const r = n >>> o, a = !(!(r >>> 7) && t == 0), l = (a ? r | 128 : r) & 255;
    if (e.push(l), !a)
      return;
  }
  const i = n >>> 28 & 15 | (t & 7) << 4, s = t >> 3 != 0;
  if (e.push((s ? i | 128 : i) & 255), !!s) {
    for (let o = 3; o < 31; o = o + 7) {
      const r = t >>> o, a = !!(r >>> 7), l = (a ? r | 128 : r) & 255;
      if (e.push(l), !a)
        return;
    }
    e.push(t >>> 31 & 1);
  }
}
const $n = 4294967296;
function ko(n) {
  const t = n[0] === "-";
  t && (n = n.slice(1));
  const e = 1e6;
  let i = 0, s = 0;
  function o(r, a) {
    const l = Number(n.slice(r, a));
    s *= e, i = i * e + l, i >= $n && (s = s + (i / $n | 0), i = i % $n);
  }
  return o(-24, -18), o(-18, -12), o(-12, -6), o(-6), t ? Qa(i, s) : Ns(i, s);
}
function ou(n, t) {
  let e = Ns(n, t);
  const i = e.hi & 2147483648;
  i && (e = Qa(e.lo, e.hi));
  const s = Za(e.lo, e.hi);
  return i ? "-" + s : s;
}
function Za(n, t) {
  if ({ lo: n, hi: t } = ru(n, t), t <= 2097151)
    return String($n * t + n);
  const e = n & 16777215, i = (n >>> 24 | t << 8) & 16777215, s = t >> 16 & 65535;
  let o = e + i * 6777216 + s * 6710656, r = i + s * 8147497, a = s * 2;
  const l = 1e7;
  return o >= l && (r += Math.floor(o / l), o %= l), r >= l && (a += Math.floor(r / l), r %= l), a.toString() + Lo(r) + Lo(o);
}
function ru(n, t) {
  return { lo: n >>> 0, hi: t >>> 0 };
}
function Ns(n, t) {
  return { lo: n | 0, hi: t | 0 };
}
function Qa(n, t) {
  return t = ~t, n ? n = ~n + 1 : t += 1, Ns(n, t);
}
const Lo = (n) => {
  const t = String(n);
  return "0000000".slice(t.length) + t;
};
function xo(n, t) {
  if (n >= 0) {
    for (; n > 127; )
      t.push(n & 127 | 128), n = n >>> 7;
    t.push(n);
  } else {
    for (let e = 0; e < 9; e++)
      t.push(n & 127 | 128), n = n >> 7;
    t.push(1);
  }
}
function au() {
  let n = this.buf[this.pos++], t = n & 127;
  if ((n & 128) == 0)
    return this.assertBounds(), t;
  if (n = this.buf[this.pos++], t |= (n & 127) << 7, (n & 128) == 0)
    return this.assertBounds(), t;
  if (n = this.buf[this.pos++], t |= (n & 127) << 14, (n & 128) == 0)
    return this.assertBounds(), t;
  if (n = this.buf[this.pos++], t |= (n & 127) << 21, (n & 128) == 0)
    return this.assertBounds(), t;
  n = this.buf[this.pos++], t |= (n & 15) << 28;
  for (let e = 5; (n & 128) !== 0 && e < 10; e++)
    n = this.buf[this.pos++];
  if ((n & 128) != 0)
    throw new Error("invalid varint");
  return this.assertBounds(), t >>> 0;
}
const xt = /* @__PURE__ */ lu();
function lu() {
  const n = new DataView(new ArrayBuffer(8));
  if (typeof BigInt == "function" && typeof n.getBigInt64 == "function" && typeof n.getBigUint64 == "function" && typeof n.setBigInt64 == "function" && typeof n.setBigUint64 == "function" && (!!globalThis.Deno || typeof process != "object" || typeof process.env != "object" || process.env.BUF_BIGINT_DISABLE !== "1")) {
    const e = BigInt("-9223372036854775808"), i = BigInt("9223372036854775807"), s = BigInt("0"), o = BigInt("18446744073709551615");
    return {
      zero: BigInt(0),
      supported: !0,
      parse(r) {
        const a = typeof r == "bigint" ? r : BigInt(r);
        if (a > i || a < e)
          throw new Error(`invalid int64: ${r}`);
        return a;
      },
      uParse(r) {
        const a = typeof r == "bigint" ? r : BigInt(r);
        if (a > o || a < s)
          throw new Error(`invalid uint64: ${r}`);
        return a;
      },
      enc(r) {
        return n.setBigInt64(0, this.parse(r), !0), {
          lo: n.getInt32(0, !0),
          hi: n.getInt32(4, !0)
        };
      },
      uEnc(r) {
        return n.setBigInt64(0, this.uParse(r), !0), {
          lo: n.getInt32(0, !0),
          hi: n.getInt32(4, !0)
        };
      },
      dec(r, a) {
        return n.setInt32(0, r, !0), n.setInt32(4, a, !0), n.getBigInt64(0, !0);
      },
      uDec(r, a) {
        return n.setInt32(0, r, !0), n.setInt32(4, a, !0), n.getBigUint64(0, !0);
      }
    };
  }
  return {
    zero: "0",
    supported: !1,
    parse(e) {
      return typeof e != "string" && (e = e.toString()), Ao(e), e;
    },
    uParse(e) {
      return typeof e != "string" && (e = e.toString()), Eo(e), e;
    },
    enc(e) {
      return typeof e != "string" && (e = e.toString()), Ao(e), ko(e);
    },
    uEnc(e) {
      return typeof e != "string" && (e = e.toString()), Eo(e), ko(e);
    },
    dec(e, i) {
      return ou(e, i);
    },
    uDec(e, i) {
      return Za(e, i);
    }
  };
}
function Ao(n) {
  if (!/^-?[0-9]+$/.test(n))
    throw new Error("invalid int64: " + n);
}
function Eo(n) {
  if (!/^[0-9]+$/.test(n))
    throw new Error("invalid uint64: " + n);
}
const Oi = /* @__PURE__ */ Symbol.for("@bufbuild/protobuf/text-encoding");
function tl() {
  if (globalThis[Oi] == null) {
    const n = new globalThis.TextEncoder(), t = new globalThis.TextDecoder();
    globalThis[Oi] = {
      encodeUtf8(e) {
        return n.encode(e);
      },
      decodeUtf8(e) {
        return t.decode(e);
      },
      checkUtf8(e) {
        try {
          return encodeURIComponent(e), !0;
        } catch {
          return !1;
        }
      }
    };
  }
  return globalThis[Oi];
}
var Bt;
(function(n) {
  n[n.Varint = 0] = "Varint", n[n.Bit64 = 1] = "Bit64", n[n.LengthDelimited = 2] = "LengthDelimited", n[n.StartGroup = 3] = "StartGroup", n[n.EndGroup = 4] = "EndGroup", n[n.Bit32 = 5] = "Bit32";
})(Bt || (Bt = {}));
const cu = 34028234663852886e22, uu = -34028234663852886e22, du = 4294967295, hu = 2147483647, fu = -2147483648;
class G {
  constructor(t = tl().encodeUtf8) {
    this.encodeUtf8 = t, this.stack = [], this.chunks = [], this.buf = [];
  }
  /**
   * Return all bytes written and reset this writer.
   */
  finish() {
    this.buf.length && (this.chunks.push(new Uint8Array(this.buf)), this.buf = []);
    let t = 0;
    for (let s = 0; s < this.chunks.length; s++)
      t += this.chunks[s].length;
    let e = new Uint8Array(t), i = 0;
    for (let s = 0; s < this.chunks.length; s++)
      e.set(this.chunks[s], i), i += this.chunks[s].length;
    return this.chunks = [], e;
  }
  /**
   * Start a new fork for length-delimited data like a message
   * or a packed repeated field.
   *
   * Must be joined later with `join()`.
   */
  fork() {
    return this.stack.push({ chunks: this.chunks, buf: this.buf }), this.chunks = [], this.buf = [], this;
  }
  /**
   * Join the last fork. Write its length and bytes, then
   * return to the previous state.
   */
  join() {
    let t = this.finish(), e = this.stack.pop();
    if (!e)
      throw new Error("invalid state, fork stack empty");
    return this.chunks = e.chunks, this.buf = e.buf, this.uint32(t.byteLength), this.raw(t);
  }
  /**
   * Writes a tag (field number and wire type).
   *
   * Equivalent to `uint32( (fieldNo << 3 | type) >>> 0 )`.
   *
   * Generated code should compute the tag ahead of time and call `uint32()`.
   */
  tag(t, e) {
    return this.uint32((t << 3 | e) >>> 0);
  }
  /**
   * Write a chunk of raw bytes.
   */
  raw(t) {
    return this.buf.length && (this.chunks.push(new Uint8Array(this.buf)), this.buf = []), this.chunks.push(t), this;
  }
  /**
   * Write a `uint32` value, an unsigned 32 bit varint.
   */
  uint32(t) {
    for (Vo(t); t > 127; )
      this.buf.push(t & 127 | 128), t = t >>> 7;
    return this.buf.push(t), this;
  }
  /**
   * Write a `int32` value, a signed 32 bit varint.
   */
  int32(t) {
    return Di(t), xo(t, this.buf), this;
  }
  /**
   * Write a `bool` value, a variant.
   */
  bool(t) {
    return this.buf.push(t ? 1 : 0), this;
  }
  /**
   * Write a `bytes` value, length-delimited arbitrary data.
   */
  bytes(t) {
    return this.uint32(t.byteLength), this.raw(t);
  }
  /**
   * Write a `string` value, length-delimited data converted to UTF-8 text.
   */
  string(t) {
    let e = this.encodeUtf8(t);
    return this.uint32(e.byteLength), this.raw(e);
  }
  /**
   * Write a `float` value, 32-bit floating point number.
   */
  float(t) {
    gu(t);
    let e = new Uint8Array(4);
    return new DataView(e.buffer).setFloat32(0, t, !0), this.raw(e);
  }
  /**
   * Write a `double` value, a 64-bit floating point number.
   */
  double(t) {
    let e = new Uint8Array(8);
    return new DataView(e.buffer).setFloat64(0, t, !0), this.raw(e);
  }
  /**
   * Write a `fixed32` value, an unsigned, fixed-length 32-bit integer.
   */
  fixed32(t) {
    Vo(t);
    let e = new Uint8Array(4);
    return new DataView(e.buffer).setUint32(0, t, !0), this.raw(e);
  }
  /**
   * Write a `sfixed32` value, a signed, fixed-length 32-bit integer.
   */
  sfixed32(t) {
    Di(t);
    let e = new Uint8Array(4);
    return new DataView(e.buffer).setInt32(0, t, !0), this.raw(e);
  }
  /**
   * Write a `sint32` value, a signed, zigzag-encoded 32-bit varint.
   */
  sint32(t) {
    return Di(t), t = (t << 1 ^ t >> 31) >>> 0, xo(t, this.buf), this;
  }
  /**
   * Write a `fixed64` value, a signed, fixed-length 64-bit integer.
   */
  sfixed64(t) {
    let e = new Uint8Array(8), i = new DataView(e.buffer), s = xt.enc(t);
    return i.setInt32(0, s.lo, !0), i.setInt32(4, s.hi, !0), this.raw(e);
  }
  /**
   * Write a `fixed64` value, an unsigned, fixed-length 64 bit integer.
   */
  fixed64(t) {
    let e = new Uint8Array(8), i = new DataView(e.buffer), s = xt.uEnc(t);
    return i.setInt32(0, s.lo, !0), i.setInt32(4, s.hi, !0), this.raw(e);
  }
  /**
   * Write a `int64` value, a signed 64-bit varint.
   */
  int64(t) {
    let e = xt.enc(t);
    return Mi(e.lo, e.hi, this.buf), this;
  }
  /**
   * Write a `sint64` value, a signed, zig-zag-encoded 64-bit varint.
   */
  sint64(t) {
    const e = xt.enc(t), i = e.hi >> 31, s = e.lo << 1 ^ i, o = (e.hi << 1 | e.lo >>> 31) ^ i;
    return Mi(s, o, this.buf), this;
  }
  /**
   * Write a `uint64` value, an unsigned 64-bit varint.
   */
  uint64(t) {
    const e = xt.uEnc(t);
    return Mi(e.lo, e.hi, this.buf), this;
  }
}
class R {
  constructor(t, e = tl().decodeUtf8) {
    this.decodeUtf8 = e, this.varint64 = su, this.uint32 = au, this.buf = t, this.len = t.length, this.pos = 0, this.view = new DataView(t.buffer, t.byteOffset, t.byteLength);
  }
  /**
   * Reads a tag - field number and wire type.
   */
  tag() {
    let t = this.uint32(), e = t >>> 3, i = t & 7;
    if (e <= 0 || i < 0 || i > 5)
      throw new Error("illegal tag: field no " + e + " wire type " + i);
    return [e, i];
  }
  /**
   * Skip one element and return the skipped data.
   *
   * When skipping StartGroup, provide the tags field number to check for
   * matching field number in the EndGroup tag.
   */
  skip(t, e) {
    let i = this.pos;
    switch (t) {
      case Bt.Varint:
        for (; this.buf[this.pos++] & 128; )
          ;
        break;
      // @ts-ignore TS7029: Fallthrough case in switch -- ignore instead of expect-error for compiler settings without noFallthroughCasesInSwitch: true
      case Bt.Bit64:
        this.pos += 4;
      case Bt.Bit32:
        this.pos += 4;
        break;
      case Bt.LengthDelimited:
        let s = this.uint32();
        this.pos += s;
        break;
      case Bt.StartGroup:
        for (; ; ) {
          const [o, r] = this.tag();
          if (r === Bt.EndGroup) {
            if (e !== void 0 && o !== e)
              throw new Error("invalid end group tag");
            break;
          }
          this.skip(r, o);
        }
        break;
      default:
        throw new Error("cant skip wire type " + t);
    }
    return this.assertBounds(), this.buf.subarray(i, this.pos);
  }
  /**
   * Throws error if position in byte array is out of range.
   */
  assertBounds() {
    if (this.pos > this.len)
      throw new RangeError("premature EOF");
  }
  /**
   * Read a `int32` field, a signed 32 bit varint.
   */
  int32() {
    return this.uint32() | 0;
  }
  /**
   * Read a `sint32` field, a signed, zigzag-encoded 32-bit varint.
   */
  sint32() {
    let t = this.uint32();
    return t >>> 1 ^ -(t & 1);
  }
  /**
   * Read a `int64` field, a signed 64-bit varint.
   */
  int64() {
    return xt.dec(...this.varint64());
  }
  /**
   * Read a `uint64` field, an unsigned 64-bit varint.
   */
  uint64() {
    return xt.uDec(...this.varint64());
  }
  /**
   * Read a `sint64` field, a signed, zig-zag-encoded 64-bit varint.
   */
  sint64() {
    let [t, e] = this.varint64(), i = -(t & 1);
    return t = (t >>> 1 | (e & 1) << 31) ^ i, e = e >>> 1 ^ i, xt.dec(t, e);
  }
  /**
   * Read a `bool` field, a variant.
   */
  bool() {
    let [t, e] = this.varint64();
    return t !== 0 || e !== 0;
  }
  /**
   * Read a `fixed32` field, an unsigned, fixed-length 32-bit integer.
   */
  fixed32() {
    return this.view.getUint32((this.pos += 4) - 4, !0);
  }
  /**
   * Read a `sfixed32` field, a signed, fixed-length 32-bit integer.
   */
  sfixed32() {
    return this.view.getInt32((this.pos += 4) - 4, !0);
  }
  /**
   * Read a `fixed64` field, an unsigned, fixed-length 64 bit integer.
   */
  fixed64() {
    return xt.uDec(this.sfixed32(), this.sfixed32());
  }
  /**
   * Read a `fixed64` field, a signed, fixed-length 64-bit integer.
   */
  sfixed64() {
    return xt.dec(this.sfixed32(), this.sfixed32());
  }
  /**
   * Read a `float` field, 32-bit floating point number.
   */
  float() {
    return this.view.getFloat32((this.pos += 4) - 4, !0);
  }
  /**
   * Read a `double` field, a 64-bit floating point number.
   */
  double() {
    return this.view.getFloat64((this.pos += 8) - 8, !0);
  }
  /**
   * Read a `bytes` field, length-delimited arbitrary data.
   */
  bytes() {
    let t = this.uint32(), e = this.pos;
    return this.pos += t, this.assertBounds(), this.buf.subarray(e, e + t);
  }
  /**
   * Read a `string` field, length-delimited data converted to UTF-8 text.
   */
  string() {
    return this.decodeUtf8(this.bytes());
  }
}
function Di(n) {
  if (typeof n == "string")
    n = Number(n);
  else if (typeof n != "number")
    throw new Error("invalid int32: " + typeof n);
  if (!Number.isInteger(n) || n > hu || n < fu)
    throw new Error("invalid int32: " + n);
}
function Vo(n) {
  if (typeof n == "string")
    n = Number(n);
  else if (typeof n != "number")
    throw new Error("invalid uint32: " + typeof n);
  if (!Number.isInteger(n) || n > du || n < 0)
    throw new Error("invalid uint32: " + n);
}
function gu(n) {
  if (typeof n == "string") {
    const t = n;
    if (n = Number(n), Number.isNaN(n) && t !== "NaN")
      throw new Error("invalid float32: " + t);
  } else if (typeof n != "number")
    throw new Error("invalid float32: " + typeof n);
  if (Number.isFinite(n) && (n > cu || n < uu))
    throw new Error("invalid float32: " + n);
}
var dt;
(function(n) {
  n[n.NO_CONNECTION = 0] = "NO_CONNECTION", n[n.TRANSLATING = 10] = "TRANSLATING", n[n.STREAMING = 20] = "STREAMING", n[n.UNRECOGNIZED = -1] = "UNRECOGNIZED";
})(dt || (dt = {}));
function mu(n) {
  switch (n) {
    case 0:
    case "NO_CONNECTION":
      return dt.NO_CONNECTION;
    case 10:
    case "TRANSLATING":
      return dt.TRANSLATING;
    case 20:
    case "STREAMING":
      return dt.STREAMING;
    default:
      return dt.UNRECOGNIZED;
  }
}
function pu(n) {
  switch (n) {
    case dt.NO_CONNECTION:
      return "NO_CONNECTION";
    case dt.TRANSLATING:
      return "TRANSLATING";
    case dt.STREAMING:
      return "STREAMING";
    case dt.UNRECOGNIZED:
    default:
      return "UNRECOGNIZED";
  }
}
function Co() {
  return { target: "", targetUrl: "" };
}
const fe = {
  encode(n, t = new G()) {
    return n.target !== "" && t.uint32(10).string(n.target), n.targetUrl !== "" && t.uint32(18).string(n.targetUrl), t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Co();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.target = e.string();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.targetUrl = e.string();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      target: E(n.target) ? globalThis.String(n.target) : "",
      targetUrl: E(n.targetUrl) ? globalThis.String(n.targetUrl) : ""
    };
  },
  toJSON(n) {
    const t = {};
    return n.target !== "" && (t.target = n.target), n.targetUrl !== "" && (t.targetUrl = n.targetUrl), t;
  },
  create(n) {
    return fe.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Co();
    return t.target = n.target ?? "", t.targetUrl = n.targetUrl ?? "", t;
  }
};
function Io() {
  return {
    url: "",
    deviceId: void 0,
    firstRequest: !1,
    duration: 0,
    unknown0: 0,
    language: "",
    forceSourceLang: !1,
    unknown1: 0,
    translationHelp: [],
    wasStream: !1,
    responseLanguage: "",
    unknown2: 0,
    unknown3: 0,
    bypassCache: !1,
    useLivelyVoice: !1,
    videoTitle: ""
  };
}
const el = {
  encode(n, t = new G()) {
    n.url !== "" && t.uint32(26).string(n.url), n.deviceId !== void 0 && t.uint32(34).string(n.deviceId), n.firstRequest !== !1 && t.uint32(40).bool(n.firstRequest), n.duration !== 0 && t.uint32(49).double(n.duration), n.unknown0 !== 0 && t.uint32(56).int32(n.unknown0), n.language !== "" && t.uint32(66).string(n.language), n.forceSourceLang !== !1 && t.uint32(72).bool(n.forceSourceLang), n.unknown1 !== 0 && t.uint32(80).int32(n.unknown1);
    for (const e of n.translationHelp)
      fe.encode(e, t.uint32(90).fork()).join();
    return n.wasStream !== !1 && t.uint32(104).bool(n.wasStream), n.responseLanguage !== "" && t.uint32(114).string(n.responseLanguage), n.unknown2 !== 0 && t.uint32(120).int32(n.unknown2), n.unknown3 !== 0 && t.uint32(128).int32(n.unknown3), n.bypassCache !== !1 && t.uint32(136).bool(n.bypassCache), n.useLivelyVoice !== !1 && t.uint32(144).bool(n.useLivelyVoice), n.videoTitle !== "" && t.uint32(154).string(n.videoTitle), t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Io();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 3: {
          if (o !== 26)
            break;
          s.url = e.string();
          continue;
        }
        case 4: {
          if (o !== 34)
            break;
          s.deviceId = e.string();
          continue;
        }
        case 5: {
          if (o !== 40)
            break;
          s.firstRequest = e.bool();
          continue;
        }
        case 6: {
          if (o !== 49)
            break;
          s.duration = e.double();
          continue;
        }
        case 7: {
          if (o !== 56)
            break;
          s.unknown0 = e.int32();
          continue;
        }
        case 8: {
          if (o !== 66)
            break;
          s.language = e.string();
          continue;
        }
        case 9: {
          if (o !== 72)
            break;
          s.forceSourceLang = e.bool();
          continue;
        }
        case 10: {
          if (o !== 80)
            break;
          s.unknown1 = e.int32();
          continue;
        }
        case 11: {
          if (o !== 90)
            break;
          s.translationHelp.push(fe.decode(e, e.uint32()));
          continue;
        }
        case 13: {
          if (o !== 104)
            break;
          s.wasStream = e.bool();
          continue;
        }
        case 14: {
          if (o !== 114)
            break;
          s.responseLanguage = e.string();
          continue;
        }
        case 15: {
          if (o !== 120)
            break;
          s.unknown2 = e.int32();
          continue;
        }
        case 16: {
          if (o !== 128)
            break;
          s.unknown3 = e.int32();
          continue;
        }
        case 17: {
          if (o !== 136)
            break;
          s.bypassCache = e.bool();
          continue;
        }
        case 18: {
          if (o !== 144)
            break;
          s.useLivelyVoice = e.bool();
          continue;
        }
        case 19: {
          if (o !== 154)
            break;
          s.videoTitle = e.string();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      url: E(n.url) ? globalThis.String(n.url) : "",
      deviceId: E(n.deviceId) ? globalThis.String(n.deviceId) : void 0,
      firstRequest: E(n.firstRequest) ? globalThis.Boolean(n.firstRequest) : !1,
      duration: E(n.duration) ? globalThis.Number(n.duration) : 0,
      unknown0: E(n.unknown0) ? globalThis.Number(n.unknown0) : 0,
      language: E(n.language) ? globalThis.String(n.language) : "",
      forceSourceLang: E(n.forceSourceLang) ? globalThis.Boolean(n.forceSourceLang) : !1,
      unknown1: E(n.unknown1) ? globalThis.Number(n.unknown1) : 0,
      translationHelp: globalThis.Array.isArray(n?.translationHelp) ? n.translationHelp.map((t) => fe.fromJSON(t)) : [],
      wasStream: E(n.wasStream) ? globalThis.Boolean(n.wasStream) : !1,
      responseLanguage: E(n.responseLanguage) ? globalThis.String(n.responseLanguage) : "",
      unknown2: E(n.unknown2) ? globalThis.Number(n.unknown2) : 0,
      unknown3: E(n.unknown3) ? globalThis.Number(n.unknown3) : 0,
      bypassCache: E(n.bypassCache) ? globalThis.Boolean(n.bypassCache) : !1,
      useLivelyVoice: E(n.useLivelyVoice) ? globalThis.Boolean(n.useLivelyVoice) : !1,
      videoTitle: E(n.videoTitle) ? globalThis.String(n.videoTitle) : ""
    };
  },
  toJSON(n) {
    const t = {};
    return n.url !== "" && (t.url = n.url), n.deviceId !== void 0 && (t.deviceId = n.deviceId), n.firstRequest !== !1 && (t.firstRequest = n.firstRequest), n.duration !== 0 && (t.duration = n.duration), n.unknown0 !== 0 && (t.unknown0 = Math.round(n.unknown0)), n.language !== "" && (t.language = n.language), n.forceSourceLang !== !1 && (t.forceSourceLang = n.forceSourceLang), n.unknown1 !== 0 && (t.unknown1 = Math.round(n.unknown1)), n.translationHelp?.length && (t.translationHelp = n.translationHelp.map((e) => fe.toJSON(e))), n.wasStream !== !1 && (t.wasStream = n.wasStream), n.responseLanguage !== "" && (t.responseLanguage = n.responseLanguage), n.unknown2 !== 0 && (t.unknown2 = Math.round(n.unknown2)), n.unknown3 !== 0 && (t.unknown3 = Math.round(n.unknown3)), n.bypassCache !== !1 && (t.bypassCache = n.bypassCache), n.useLivelyVoice !== !1 && (t.useLivelyVoice = n.useLivelyVoice), n.videoTitle !== "" && (t.videoTitle = n.videoTitle), t;
  },
  create(n) {
    return el.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Io();
    return t.url = n.url ?? "", t.deviceId = n.deviceId ?? void 0, t.firstRequest = n.firstRequest ?? !1, t.duration = n.duration ?? 0, t.unknown0 = n.unknown0 ?? 0, t.language = n.language ?? "", t.forceSourceLang = n.forceSourceLang ?? !1, t.unknown1 = n.unknown1 ?? 0, t.translationHelp = n.translationHelp?.map((e) => fe.fromPartial(e)) || [], t.wasStream = n.wasStream ?? !1, t.responseLanguage = n.responseLanguage ?? "", t.unknown2 = n.unknown2 ?? 0, t.unknown3 = n.unknown3 ?? 0, t.bypassCache = n.bypassCache ?? !1, t.useLivelyVoice = n.useLivelyVoice ?? !1, t.videoTitle = n.videoTitle ?? "", t;
  }
};
function Po() {
  return {
    url: void 0,
    duration: void 0,
    status: 0,
    remainingTime: void 0,
    unknown0: void 0,
    translationId: "",
    language: void 0,
    message: void 0,
    isLivelyVoice: !1,
    unknown2: void 0,
    shouldRetry: void 0,
    unknown3: void 0
  };
}
const nl = {
  encode(n, t = new G()) {
    return n.url !== void 0 && t.uint32(10).string(n.url), n.duration !== void 0 && t.uint32(17).double(n.duration), n.status !== 0 && t.uint32(32).int32(n.status), n.remainingTime !== void 0 && t.uint32(40).int32(n.remainingTime), n.unknown0 !== void 0 && t.uint32(48).int32(n.unknown0), n.translationId !== "" && t.uint32(58).string(n.translationId), n.language !== void 0 && t.uint32(66).string(n.language), n.message !== void 0 && t.uint32(74).string(n.message), n.isLivelyVoice !== !1 && t.uint32(80).bool(n.isLivelyVoice), n.unknown2 !== void 0 && t.uint32(88).int32(n.unknown2), n.shouldRetry !== void 0 && t.uint32(96).int32(n.shouldRetry), n.unknown3 !== void 0 && t.uint32(104).int32(n.unknown3), t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Po();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.url = e.string();
          continue;
        }
        case 2: {
          if (o !== 17)
            break;
          s.duration = e.double();
          continue;
        }
        case 4: {
          if (o !== 32)
            break;
          s.status = e.int32();
          continue;
        }
        case 5: {
          if (o !== 40)
            break;
          s.remainingTime = e.int32();
          continue;
        }
        case 6: {
          if (o !== 48)
            break;
          s.unknown0 = e.int32();
          continue;
        }
        case 7: {
          if (o !== 58)
            break;
          s.translationId = e.string();
          continue;
        }
        case 8: {
          if (o !== 66)
            break;
          s.language = e.string();
          continue;
        }
        case 9: {
          if (o !== 74)
            break;
          s.message = e.string();
          continue;
        }
        case 10: {
          if (o !== 80)
            break;
          s.isLivelyVoice = e.bool();
          continue;
        }
        case 11: {
          if (o !== 88)
            break;
          s.unknown2 = e.int32();
          continue;
        }
        case 12: {
          if (o !== 96)
            break;
          s.shouldRetry = e.int32();
          continue;
        }
        case 13: {
          if (o !== 104)
            break;
          s.unknown3 = e.int32();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      url: E(n.url) ? globalThis.String(n.url) : void 0,
      duration: E(n.duration) ? globalThis.Number(n.duration) : void 0,
      status: E(n.status) ? globalThis.Number(n.status) : 0,
      remainingTime: E(n.remainingTime) ? globalThis.Number(n.remainingTime) : void 0,
      unknown0: E(n.unknown0) ? globalThis.Number(n.unknown0) : void 0,
      translationId: E(n.translationId) ? globalThis.String(n.translationId) : "",
      language: E(n.language) ? globalThis.String(n.language) : void 0,
      message: E(n.message) ? globalThis.String(n.message) : void 0,
      isLivelyVoice: E(n.isLivelyVoice) ? globalThis.Boolean(n.isLivelyVoice) : !1,
      unknown2: E(n.unknown2) ? globalThis.Number(n.unknown2) : void 0,
      shouldRetry: E(n.shouldRetry) ? globalThis.Number(n.shouldRetry) : void 0,
      unknown3: E(n.unknown3) ? globalThis.Number(n.unknown3) : void 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.url !== void 0 && (t.url = n.url), n.duration !== void 0 && (t.duration = n.duration), n.status !== 0 && (t.status = Math.round(n.status)), n.remainingTime !== void 0 && (t.remainingTime = Math.round(n.remainingTime)), n.unknown0 !== void 0 && (t.unknown0 = Math.round(n.unknown0)), n.translationId !== "" && (t.translationId = n.translationId), n.language !== void 0 && (t.language = n.language), n.message !== void 0 && (t.message = n.message), n.isLivelyVoice !== !1 && (t.isLivelyVoice = n.isLivelyVoice), n.unknown2 !== void 0 && (t.unknown2 = Math.round(n.unknown2)), n.shouldRetry !== void 0 && (t.shouldRetry = Math.round(n.shouldRetry)), n.unknown3 !== void 0 && (t.unknown3 = Math.round(n.unknown3)), t;
  },
  create(n) {
    return nl.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Po();
    return t.url = n.url ?? void 0, t.duration = n.duration ?? void 0, t.status = n.status ?? 0, t.remainingTime = n.remainingTime ?? void 0, t.unknown0 = n.unknown0 ?? void 0, t.translationId = n.translationId ?? "", t.language = n.language ?? void 0, t.message = n.message ?? void 0, t.isLivelyVoice = n.isLivelyVoice ?? !1, t.unknown2 = n.unknown2 ?? void 0, t.shouldRetry = n.shouldRetry ?? void 0, t.unknown3 = n.unknown3 ?? void 0, t;
  }
};
function Mo() {
  return { status: 0, remainingTime: void 0, message: void 0, unknown0: void 0 };
}
const vt = {
  encode(n, t = new G()) {
    return n.status !== 0 && t.uint32(8).int32(n.status), n.remainingTime !== void 0 && t.uint32(16).int32(n.remainingTime), n.message !== void 0 && t.uint32(26).string(n.message), n.unknown0 !== void 0 && t.uint32(32).int32(n.unknown0), t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Mo();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 8)
            break;
          s.status = e.int32();
          continue;
        }
        case 2: {
          if (o !== 16)
            break;
          s.remainingTime = e.int32();
          continue;
        }
        case 3: {
          if (o !== 26)
            break;
          s.message = e.string();
          continue;
        }
        case 4: {
          if (o !== 32)
            break;
          s.unknown0 = e.int32();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      status: E(n.status) ? globalThis.Number(n.status) : 0,
      remainingTime: E(n.remainingTime) ? globalThis.Number(n.remainingTime) : void 0,
      message: E(n.message) ? globalThis.String(n.message) : void 0,
      unknown0: E(n.unknown0) ? globalThis.Number(n.unknown0) : void 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.status !== 0 && (t.status = Math.round(n.status)), n.remainingTime !== void 0 && (t.remainingTime = Math.round(n.remainingTime)), n.message !== void 0 && (t.message = n.message), n.unknown0 !== void 0 && (t.unknown0 = Math.round(n.unknown0)), t;
  },
  create(n) {
    return vt.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Mo();
    return t.status = n.status ?? 0, t.remainingTime = n.remainingTime ?? void 0, t.message = n.message ?? void 0, t.unknown0 = n.unknown0 ?? void 0, t;
  }
};
function Oo() {
  return { url: "", duration: 0, language: "", responseLanguage: "" };
}
const il = {
  encode(n, t = new G()) {
    return n.url !== "" && t.uint32(10).string(n.url), n.duration !== 0 && t.uint32(17).double(n.duration), n.language !== "" && t.uint32(26).string(n.language), n.responseLanguage !== "" && t.uint32(34).string(n.responseLanguage), t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Oo();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.url = e.string();
          continue;
        }
        case 2: {
          if (o !== 17)
            break;
          s.duration = e.double();
          continue;
        }
        case 3: {
          if (o !== 26)
            break;
          s.language = e.string();
          continue;
        }
        case 4: {
          if (o !== 34)
            break;
          s.responseLanguage = e.string();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      url: E(n.url) ? globalThis.String(n.url) : "",
      duration: E(n.duration) ? globalThis.Number(n.duration) : 0,
      language: E(n.language) ? globalThis.String(n.language) : "",
      responseLanguage: E(n.responseLanguage) ? globalThis.String(n.responseLanguage) : ""
    };
  },
  toJSON(n) {
    const t = {};
    return n.url !== "" && (t.url = n.url), n.duration !== 0 && (t.duration = n.duration), n.language !== "" && (t.language = n.language), n.responseLanguage !== "" && (t.responseLanguage = n.responseLanguage), t;
  },
  create(n) {
    return il.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Oo();
    return t.url = n.url ?? "", t.duration = n.duration ?? 0, t.language = n.language ?? "", t.responseLanguage = n.responseLanguage ?? "", t;
  }
};
function Do() {
  return { default: void 0, cloning: void 0 };
}
const sl = {
  encode(n, t = new G()) {
    return n.default !== void 0 && vt.encode(n.default, t.uint32(10).fork()).join(), n.cloning !== void 0 && vt.encode(n.cloning, t.uint32(18).fork()).join(), t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Do();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.default = vt.decode(e, e.uint32());
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.cloning = vt.decode(e, e.uint32());
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      default: E(n.default) ? vt.fromJSON(n.default) : void 0,
      cloning: E(n.cloning) ? vt.fromJSON(n.cloning) : void 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.default !== void 0 && (t.default = vt.toJSON(n.default)), n.cloning !== void 0 && (t.cloning = vt.toJSON(n.cloning)), t;
  },
  create(n) {
    return sl.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Do();
    return t.default = n.default !== void 0 && n.default !== null ? vt.fromPartial(n.default) : void 0, t.cloning = n.cloning !== void 0 && n.cloning !== null ? vt.fromPartial(n.cloning) : void 0, t;
  }
};
function _o() {
  return { audioFile: new Uint8Array(0), fileId: "" };
}
const ge = {
  encode(n, t = new G()) {
    return n.audioFile.length !== 0 && t.uint32(18).bytes(n.audioFile), n.fileId !== "" && t.uint32(10).string(n.fileId), t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = _o();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 2: {
          if (o !== 18)
            break;
          s.audioFile = e.bytes();
          continue;
        }
        case 1: {
          if (o !== 10)
            break;
          s.fileId = e.string();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      audioFile: E(n.audioFile) ? fl(n.audioFile) : new Uint8Array(0),
      fileId: E(n.fileId) ? globalThis.String(n.fileId) : ""
    };
  },
  toJSON(n) {
    const t = {};
    return n.audioFile.length !== 0 && (t.audioFile = gl(n.audioFile)), n.fileId !== "" && (t.fileId = n.fileId), t;
  },
  create(n) {
    return ge.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = _o();
    return t.audioFile = n.audioFile ?? new Uint8Array(0), t.fileId = n.fileId ?? "", t;
  }
};
function Ro() {
  return { audioFile: new Uint8Array(0), chunkId: 0 };
}
const me = {
  encode(n, t = new G()) {
    return n.audioFile.length !== 0 && t.uint32(18).bytes(n.audioFile), n.chunkId !== 0 && t.uint32(8).int32(n.chunkId), t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Ro();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 2: {
          if (o !== 18)
            break;
          s.audioFile = e.bytes();
          continue;
        }
        case 1: {
          if (o !== 8)
            break;
          s.chunkId = e.int32();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      audioFile: E(n.audioFile) ? fl(n.audioFile) : new Uint8Array(0),
      chunkId: E(n.chunkId) ? globalThis.Number(n.chunkId) : 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.audioFile.length !== 0 && (t.audioFile = gl(n.audioFile)), n.chunkId !== 0 && (t.chunkId = Math.round(n.chunkId)), t;
  },
  create(n) {
    return me.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Ro();
    return t.audioFile = n.audioFile ?? new Uint8Array(0), t.chunkId = n.chunkId ?? 0, t;
  }
};
function Bo() {
  return { audioBuffer: void 0, audioPartsLength: 0, fileId: "", version: 0 };
}
const pe = {
  encode(n, t = new G()) {
    return n.audioBuffer !== void 0 && me.encode(n.audioBuffer, t.uint32(10).fork()).join(), n.audioPartsLength !== 0 && t.uint32(16).int32(n.audioPartsLength), n.fileId !== "" && t.uint32(26).string(n.fileId), n.version !== 0 && t.uint32(32).int32(n.version), t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Bo();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.audioBuffer = me.decode(e, e.uint32());
          continue;
        }
        case 2: {
          if (o !== 16)
            break;
          s.audioPartsLength = e.int32();
          continue;
        }
        case 3: {
          if (o !== 26)
            break;
          s.fileId = e.string();
          continue;
        }
        case 4: {
          if (o !== 32)
            break;
          s.version = e.int32();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      audioBuffer: E(n.audioBuffer) ? me.fromJSON(n.audioBuffer) : void 0,
      audioPartsLength: E(n.audioPartsLength) ? globalThis.Number(n.audioPartsLength) : 0,
      fileId: E(n.fileId) ? globalThis.String(n.fileId) : "",
      version: E(n.version) ? globalThis.Number(n.version) : 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.audioBuffer !== void 0 && (t.audioBuffer = me.toJSON(n.audioBuffer)), n.audioPartsLength !== 0 && (t.audioPartsLength = Math.round(n.audioPartsLength)), n.fileId !== "" && (t.fileId = n.fileId), n.version !== 0 && (t.version = Math.round(n.version)), t;
  },
  create(n) {
    return pe.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Bo();
    return t.audioBuffer = n.audioBuffer !== void 0 && n.audioBuffer !== null ? me.fromPartial(n.audioBuffer) : void 0, t.audioPartsLength = n.audioPartsLength ?? 0, t.fileId = n.fileId ?? "", t.version = n.version ?? 0, t;
  }
};
function Fo() {
  return { translationId: "", url: "", partialAudioInfo: void 0, audioInfo: void 0 };
}
const ls = {
  encode(n, t = new G()) {
    return n.translationId !== "" && t.uint32(10).string(n.translationId), n.url !== "" && t.uint32(18).string(n.url), n.partialAudioInfo !== void 0 && pe.encode(n.partialAudioInfo, t.uint32(34).fork()).join(), n.audioInfo !== void 0 && ge.encode(n.audioInfo, t.uint32(50).fork()).join(), t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Fo();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.translationId = e.string();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.url = e.string();
          continue;
        }
        case 4: {
          if (o !== 34)
            break;
          s.partialAudioInfo = pe.decode(e, e.uint32());
          continue;
        }
        case 6: {
          if (o !== 50)
            break;
          s.audioInfo = ge.decode(e, e.uint32());
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      translationId: E(n.translationId) ? globalThis.String(n.translationId) : "",
      url: E(n.url) ? globalThis.String(n.url) : "",
      partialAudioInfo: E(n.partialAudioInfo) ? pe.fromJSON(n.partialAudioInfo) : void 0,
      audioInfo: E(n.audioInfo) ? ge.fromJSON(n.audioInfo) : void 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.translationId !== "" && (t.translationId = n.translationId), n.url !== "" && (t.url = n.url), n.partialAudioInfo !== void 0 && (t.partialAudioInfo = pe.toJSON(n.partialAudioInfo)), n.audioInfo !== void 0 && (t.audioInfo = ge.toJSON(n.audioInfo)), t;
  },
  create(n) {
    return ls.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Fo();
    return t.translationId = n.translationId ?? "", t.url = n.url ?? "", t.partialAudioInfo = n.partialAudioInfo !== void 0 && n.partialAudioInfo !== null ? pe.fromPartial(n.partialAudioInfo) : void 0, t.audioInfo = n.audioInfo !== void 0 && n.audioInfo !== null ? ge.fromPartial(n.audioInfo) : void 0, t;
  }
};
function No() {
  return { status: 0, remainingChunks: [] };
}
const ol = {
  encode(n, t = new G()) {
    n.status !== 0 && t.uint32(8).int32(n.status);
    for (const e of n.remainingChunks)
      t.uint32(18).string(e);
    return t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = No();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 8)
            break;
          s.status = e.int32();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.remainingChunks.push(e.string());
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      status: E(n.status) ? globalThis.Number(n.status) : 0,
      remainingChunks: globalThis.Array.isArray(n?.remainingChunks) ? n.remainingChunks.map((t) => globalThis.String(t)) : []
    };
  },
  toJSON(n) {
    const t = {};
    return n.status !== 0 && (t.status = Math.round(n.status)), n.remainingChunks?.length && (t.remainingChunks = n.remainingChunks), t;
  },
  create(n) {
    return ol.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = No();
    return t.status = n.status ?? 0, t.remainingChunks = n.remainingChunks?.map((e) => e) || [], t;
  }
};
function Uo() {
  return { language: "", url: "", unknown0: 0, translatedLanguage: "", translatedUrl: "", unknown1: 0, unknown2: 0 };
}
const be = {
  encode(n, t = new G()) {
    return n.language !== "" && t.uint32(10).string(n.language), n.url !== "" && t.uint32(18).string(n.url), n.unknown0 !== 0 && t.uint32(24).int32(n.unknown0), n.translatedLanguage !== "" && t.uint32(34).string(n.translatedLanguage), n.translatedUrl !== "" && t.uint32(42).string(n.translatedUrl), n.unknown1 !== 0 && t.uint32(48).int32(n.unknown1), n.unknown2 !== 0 && t.uint32(56).int32(n.unknown2), t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Uo();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.language = e.string();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.url = e.string();
          continue;
        }
        case 3: {
          if (o !== 24)
            break;
          s.unknown0 = e.int32();
          continue;
        }
        case 4: {
          if (o !== 34)
            break;
          s.translatedLanguage = e.string();
          continue;
        }
        case 5: {
          if (o !== 42)
            break;
          s.translatedUrl = e.string();
          continue;
        }
        case 6: {
          if (o !== 48)
            break;
          s.unknown1 = e.int32();
          continue;
        }
        case 7: {
          if (o !== 56)
            break;
          s.unknown2 = e.int32();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      language: E(n.language) ? globalThis.String(n.language) : "",
      url: E(n.url) ? globalThis.String(n.url) : "",
      unknown0: E(n.unknown0) ? globalThis.Number(n.unknown0) : 0,
      translatedLanguage: E(n.translatedLanguage) ? globalThis.String(n.translatedLanguage) : "",
      translatedUrl: E(n.translatedUrl) ? globalThis.String(n.translatedUrl) : "",
      unknown1: E(n.unknown1) ? globalThis.Number(n.unknown1) : 0,
      unknown2: E(n.unknown2) ? globalThis.Number(n.unknown2) : 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.language !== "" && (t.language = n.language), n.url !== "" && (t.url = n.url), n.unknown0 !== 0 && (t.unknown0 = Math.round(n.unknown0)), n.translatedLanguage !== "" && (t.translatedLanguage = n.translatedLanguage), n.translatedUrl !== "" && (t.translatedUrl = n.translatedUrl), n.unknown1 !== 0 && (t.unknown1 = Math.round(n.unknown1)), n.unknown2 !== 0 && (t.unknown2 = Math.round(n.unknown2)), t;
  },
  create(n) {
    return be.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Uo();
    return t.language = n.language ?? "", t.url = n.url ?? "", t.unknown0 = n.unknown0 ?? 0, t.translatedLanguage = n.translatedLanguage ?? "", t.translatedUrl = n.translatedUrl ?? "", t.unknown1 = n.unknown1 ?? 0, t.unknown2 = n.unknown2 ?? 0, t;
  }
};
function Ho() {
  return { url: "", language: "" };
}
const rl = {
  encode(n, t = new G()) {
    return n.url !== "" && t.uint32(10).string(n.url), n.language !== "" && t.uint32(18).string(n.language), t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Ho();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.url = e.string();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.language = e.string();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      url: E(n.url) ? globalThis.String(n.url) : "",
      language: E(n.language) ? globalThis.String(n.language) : ""
    };
  },
  toJSON(n) {
    const t = {};
    return n.url !== "" && (t.url = n.url), n.language !== "" && (t.language = n.language), t;
  },
  create(n) {
    return rl.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Ho();
    return t.url = n.url ?? "", t.language = n.language ?? "", t;
  }
};
function $o() {
  return { waiting: !1, subtitles: [] };
}
const al = {
  encode(n, t = new G()) {
    n.waiting !== !1 && t.uint32(8).bool(n.waiting);
    for (const e of n.subtitles)
      be.encode(e, t.uint32(18).fork()).join();
    return t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = $o();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 8)
            break;
          s.waiting = e.bool();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.subtitles.push(be.decode(e, e.uint32()));
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      waiting: E(n.waiting) ? globalThis.Boolean(n.waiting) : !1,
      subtitles: globalThis.Array.isArray(n?.subtitles) ? n.subtitles.map((t) => be.fromJSON(t)) : []
    };
  },
  toJSON(n) {
    const t = {};
    return n.waiting !== !1 && (t.waiting = n.waiting), n.subtitles?.length && (t.subtitles = n.subtitles.map((e) => be.toJSON(e))), t;
  },
  create(n) {
    return al.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = $o();
    return t.waiting = n.waiting ?? !1, t.subtitles = n.subtitles?.map((e) => be.fromPartial(e)) || [], t;
  }
};
function Wo() {
  return { url: "", timestamp: "" };
}
const ye = {
  encode(n, t = new G()) {
    return n.url !== "" && t.uint32(10).string(n.url), n.timestamp !== "" && t.uint32(18).string(n.timestamp), t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Wo();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.url = e.string();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.timestamp = e.string();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      url: E(n.url) ? globalThis.String(n.url) : "",
      timestamp: E(n.timestamp) ? globalThis.String(n.timestamp) : ""
    };
  },
  toJSON(n) {
    const t = {};
    return n.url !== "" && (t.url = n.url), n.timestamp !== "" && (t.timestamp = n.timestamp), t;
  },
  create(n) {
    return ye.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Wo();
    return t.url = n.url ?? "", t.timestamp = n.timestamp ?? "", t;
  }
};
function zo() {
  return { url: "", language: "", responseLanguage: "", unknown0: 0, unknown1: 0 };
}
const ll = {
  encode(n, t = new G()) {
    return n.url !== "" && t.uint32(10).string(n.url), n.language !== "" && t.uint32(18).string(n.language), n.responseLanguage !== "" && t.uint32(26).string(n.responseLanguage), n.unknown0 !== 0 && t.uint32(40).int32(n.unknown0), n.unknown1 !== 0 && t.uint32(48).int32(n.unknown1), t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = zo();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.url = e.string();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.language = e.string();
          continue;
        }
        case 3: {
          if (o !== 26)
            break;
          s.responseLanguage = e.string();
          continue;
        }
        case 5: {
          if (o !== 40)
            break;
          s.unknown0 = e.int32();
          continue;
        }
        case 6: {
          if (o !== 48)
            break;
          s.unknown1 = e.int32();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      url: E(n.url) ? globalThis.String(n.url) : "",
      language: E(n.language) ? globalThis.String(n.language) : "",
      responseLanguage: E(n.responseLanguage) ? globalThis.String(n.responseLanguage) : "",
      unknown0: E(n.unknown0) ? globalThis.Number(n.unknown0) : 0,
      unknown1: E(n.unknown1) ? globalThis.Number(n.unknown1) : 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.url !== "" && (t.url = n.url), n.language !== "" && (t.language = n.language), n.responseLanguage !== "" && (t.responseLanguage = n.responseLanguage), n.unknown0 !== 0 && (t.unknown0 = Math.round(n.unknown0)), n.unknown1 !== 0 && (t.unknown1 = Math.round(n.unknown1)), t;
  },
  create(n) {
    return ll.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = zo();
    return t.url = n.url ?? "", t.language = n.language ?? "", t.responseLanguage = n.responseLanguage ?? "", t.unknown0 = n.unknown0 ?? 0, t.unknown1 = n.unknown1 ?? 0, t;
  }
};
function qo() {
  return { interval: 0, translatedInfo: void 0, pingId: void 0 };
}
const cl = {
  encode(n, t = new G()) {
    return n.interval !== 0 && t.uint32(8).int32(n.interval), n.translatedInfo !== void 0 && ye.encode(n.translatedInfo, t.uint32(18).fork()).join(), n.pingId !== void 0 && t.uint32(24).int32(n.pingId), t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = qo();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 8)
            break;
          s.interval = e.int32();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.translatedInfo = ye.decode(e, e.uint32());
          continue;
        }
        case 3: {
          if (o !== 24)
            break;
          s.pingId = e.int32();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      interval: E(n.interval) ? mu(n.interval) : 0,
      translatedInfo: E(n.translatedInfo) ? ye.fromJSON(n.translatedInfo) : void 0,
      pingId: E(n.pingId) ? globalThis.Number(n.pingId) : void 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.interval !== 0 && (t.interval = pu(n.interval)), n.translatedInfo !== void 0 && (t.translatedInfo = ye.toJSON(n.translatedInfo)), n.pingId !== void 0 && (t.pingId = Math.round(n.pingId)), t;
  },
  create(n) {
    return cl.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = qo();
    return t.interval = n.interval ?? 0, t.translatedInfo = n.translatedInfo !== void 0 && n.translatedInfo !== null ? ye.fromPartial(n.translatedInfo) : void 0, t.pingId = n.pingId ?? void 0, t;
  }
};
function Go() {
  return { pingId: 0 };
}
const ul = {
  encode(n, t = new G()) {
    return n.pingId !== 0 && t.uint32(8).int32(n.pingId), t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Go();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 8)
            break;
          s.pingId = e.int32();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return { pingId: E(n.pingId) ? globalThis.Number(n.pingId) : 0 };
  },
  toJSON(n) {
    const t = {};
    return n.pingId !== 0 && (t.pingId = Math.round(n.pingId)), t;
  },
  create(n) {
    return ul.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Go();
    return t.pingId = n.pingId ?? 0, t;
  }
};
function Ko() {
  return { uuid: "", module: "" };
}
const dl = {
  encode(n, t = new G()) {
    return n.uuid !== "" && t.uint32(10).string(n.uuid), n.module !== "" && t.uint32(18).string(n.module), t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Ko();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.uuid = e.string();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.module = e.string();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      uuid: E(n.uuid) ? globalThis.String(n.uuid) : "",
      module: E(n.module) ? globalThis.String(n.module) : ""
    };
  },
  toJSON(n) {
    const t = {};
    return n.uuid !== "" && (t.uuid = n.uuid), n.module !== "" && (t.module = n.module), t;
  },
  create(n) {
    return dl.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Ko();
    return t.uuid = n.uuid ?? "", t.module = n.module ?? "", t;
  }
};
function Yo() {
  return { secretKey: "", expires: 0 };
}
const hl = {
  encode(n, t = new G()) {
    return n.secretKey !== "" && t.uint32(10).string(n.secretKey), n.expires !== 0 && t.uint32(16).int32(n.expires), t;
  },
  decode(n, t) {
    const e = n instanceof R ? n : new R(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Yo();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.secretKey = e.string();
          continue;
        }
        case 2: {
          if (o !== 16)
            break;
          s.expires = e.int32();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      secretKey: E(n.secretKey) ? globalThis.String(n.secretKey) : "",
      expires: E(n.expires) ? globalThis.Number(n.expires) : 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.secretKey !== "" && (t.secretKey = n.secretKey), n.expires !== 0 && (t.expires = Math.round(n.expires)), t;
  },
  create(n) {
    return hl.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Yo();
    return t.secretKey = n.secretKey ?? "", t.expires = n.expires ?? 0, t;
  }
};
function fl(n) {
  if (globalThis.Buffer)
    return Uint8Array.from(globalThis.Buffer.from(n, "base64"));
  {
    const t = globalThis.atob(n), e = new Uint8Array(t.length);
    for (let i = 0; i < t.length; ++i)
      e[i] = t.charCodeAt(i);
    return e;
  }
}
function gl(n) {
  if (globalThis.Buffer)
    return globalThis.Buffer.from(n).toString("base64");
  {
    const t = [];
    return n.forEach((e) => {
      t.push(globalThis.String.fromCharCode(e));
    }), globalThis.btoa(t.join(""));
  }
}
function E(n) {
  return n != null;
}
const { componentVersion: cs } = Q;
async function bu() {
  return typeof window < "u" && window.crypto ? window.crypto : await import("./__vite-browser-external-DYxpcVy9.js");
}
const Us = new TextEncoder();
async function ml(n, t, e) {
  const i = await bu(), s = await i.subtle.importKey("raw", Us.encode(t), { name: "HMAC", hash: { name: n } }, !1, ["sign", "verify"]);
  return await i.subtle.sign("HMAC", s, e);
}
async function us(n) {
  const t = await ml("SHA-256", Q.hmac, n);
  return new Uint8Array(t).reduce((e, i) => e + i.toString(16).padStart(2, "0"), "");
}
async function ce(n, t, e, i) {
  const { secretKey: s, uuid: o } = t, r = `${o}:${i}:${cs}`, a = Us.encode(r), l = await us(a);
  if (n === "Ya-Summary")
    return {
      [`X-${n}-Sk`]: s,
      [`X-${n}-Token`]: `${l}:${r}`
    };
  const u = await us(e);
  return {
    [`${n}-Signature`]: u,
    [`Sec-${n}-Sk`]: s,
    [`Sec-${n}-Token`]: `${l}:${r}`
  };
}
function yu() {
  const n = "0123456789ABCDEF";
  let t = "";
  for (let e = 0; e < 32; e++) {
    const i = Math.floor(Math.random() * 16);
    t += n[i];
  }
  return t;
}
async function vu(n, t) {
  try {
    const e = Us.encode(t), i = await ml("SHA-1", n, e);
    return btoa(String.fromCharCode(...new Uint8Array(i)));
  } catch (e) {
    return M.error(e), !1;
  }
}
const pl = {
  "sec-ch-ua": `"Chromium";v="134", "YaBrowser";v="${cs.slice(0, 5)}", "Not?A_Brand";v="24", "Yowser";v="2.5"`,
  "sec-ch-ua-full-version-list": `"Chromium";v="134.0.6998.543", "YaBrowser";v="${cs}", "Not?A_Brand";v="24.0.0.0", "Yowser";v="2.5"`,
  "Sec-Fetch-Mode": "no-cors"
};
class st {
  static encodeTranslationRequest(t, e, i, s, o, { forceSourceLang: r = !1, wasStream: a = !1, videoTitle: l = "", bypassCache: u = !1, useLivelyVoice: d = !1, firstRequest: h = !0 } = {}) {
    return el.encode({
      url: t,
      firstRequest: h,
      duration: e,
      unknown0: 1,
      language: i,
      forceSourceLang: r,
      unknown1: 0,
      translationHelp: o ?? [],
      responseLanguage: s,
      wasStream: a,
      unknown2: 1,
      unknown3: 2,
      bypassCache: u,
      useLivelyVoice: d,
      videoTitle: l
    }).finish();
  }
  static decodeTranslationResponse(t) {
    return nl.decode(new Uint8Array(t));
  }
  static encodeTranslationCacheRequest(t, e, i, s) {
    return il.encode({
      url: t,
      duration: e,
      language: i,
      responseLanguage: s
    }).finish();
  }
  static decodeTranslationCacheResponse(t) {
    return sl.decode(new Uint8Array(t));
  }
  static isPartialAudioBuffer(t) {
    return "chunkId" in t;
  }
  static encodeTranslationAudioRequest(t, e, i, s) {
    return s && st.isPartialAudioBuffer(i) ? ls.encode({
      url: t,
      translationId: e,
      partialAudioInfo: {
        ...s,
        audioBuffer: i
      }
    }).finish() : ls.encode({
      url: t,
      translationId: e,
      audioInfo: i
    }).finish();
  }
  static decodeTranslationAudioResponse(t) {
    return ol.decode(new Uint8Array(t));
  }
  static encodeSubtitlesRequest(t, e) {
    return rl.encode({
      url: t,
      language: e
    }).finish();
  }
  static decodeSubtitlesResponse(t) {
    return al.decode(new Uint8Array(t));
  }
  static encodeStreamPingRequest(t) {
    return ul.encode({
      pingId: t
    }).finish();
  }
  static encodeStreamRequest(t, e, i) {
    return ll.encode({
      url: t,
      language: e,
      responseLanguage: i,
      unknown0: 1,
      unknown1: 0
    }).finish();
  }
  static decodeStreamResponse(t) {
    return cl.decode(new Uint8Array(t));
  }
}
class jo {
  static encodeSessionRequest(t, e) {
    return dl.encode({
      uuid: t,
      module: e
    }).finish();
  }
  static decodeSessionResponse(t) {
    return hl.decode(new Uint8Array(t));
  }
}
var rt;
(function(n) {
  n[n.FAILED = 0] = "FAILED", n[n.FINISHED = 1] = "FINISHED", n[n.WAITING = 2] = "WAITING", n[n.LONG_WAITING = 3] = "LONG_WAITING", n[n.PART_CONTENT = 5] = "PART_CONTENT", n[n.AUDIO_REQUESTED = 6] = "AUDIO_REQUESTED", n[n.SESSION_REQUIRED = 7] = "SESSION_REQUIRED";
})(rt || (rt = {}));
var on;
(function(n) {
  n.WEB_API_VIDEO_SRC_FROM_IFRAME = "web_api_video_src_from_iframe", n.WEB_API_VIDEO_SRC = "web_api_video_src", n.WEB_API_GET_ALL_GENERATING_URLS_DATA_FROM_IFRAME = "web_api_get_all_generating_urls_data_from_iframe", n.WEB_API_GET_ALL_GENERATING_URLS_DATA_FROM_IFRAME_TMP_EXP = "web_api_get_all_generating_urls_data_from_iframe_tmp_exp", n.WEB_API_REPLACED_FETCH_INSIDE_IFRAME = "web_api_replaced_fetch_inside_iframe", n.ANDROID_API = "android_api", n.WEB_API_SLOW = "web_api_slow", n.WEB_API_STEAL_SIG_AND_N = "web_api_steal_sig_and_n", n.WEB_API_COMBINED = "web_api_get_all_generating_urls_data_from_iframe,web_api_steal_sig_and_n";
})(on || (on = {}));
var y;
(function(n) {
  n.custom = "custom", n.directlink = "custom", n.youtube = "youtube", n.piped = "piped", n.invidious = "invidious", n.vk = "vk", n.nine_gag = "nine_gag", n.gag = "nine_gag", n.twitch = "twitch", n.proxitok = "proxitok", n.tiktok = "tiktok", n.vimeo = "vimeo", n.xvideos = "xvideos", n.pornhub = "pornhub", n.twitter = "twitter", n.x = "twitter", n.rumble = "rumble", n.facebook = "facebook", n.rutube = "rutube", n.coub = "coub", n.bilibili = "bilibili", n.mail_ru = "mailru", n.mailru = "mailru", n.bitchute = "bitchute", n.eporner = "eporner", n.peertube = "peertube", n.dailymotion = "dailymotion", n.trovo = "trovo", n.yandexdisk = "yandexdisk", n.ok_ru = "okru", n.okru = "okru", n.googledrive = "googledrive", n.bannedvideo = "bannedvideo", n.weverse = "weverse", n.newgrounds = "newgrounds", n.egghead = "egghead", n.youku = "youku", n.archive = "archive", n.kodik = "kodik", n.patreon = "patreon", n.reddit = "reddit", n.kick = "kick", n.apple_developer = "apple_developer", n.appledeveloper = "apple_developer", n.poketube = "poketube", n.epicgames = "epicgames", n.odysee = "odysee", n.coursehunterLike = "coursehunterLike", n.sap = "sap", n.watchpornto = "watchpornto", n.linkedin = "linkedin", n.ricktube = "ricktube", n.incestflix = "incestflix", n.porntn = "porntn", n.dzen = "dzen", n.cloudflarestream = "cloudflarestream", n.loom = "loom", n.rtnews = "rtnews", n.bitview = "bitview", n.thisvid = "thisvid", n.ign = "ign", n.bunkr = "bunkr", n.imdb = "imdb", n.telegram = "telegram";
})(y || (y = {}));
function Xo(n, t, e) {
  return n === y.patreon ? {
    service: "mux",
    videoId: new URL(e).pathname.slice(1)
  } : {
    service: n,
    videoId: t
  };
}
class J extends Error {
  constructor(e, i = void 0) {
    super(e);
    c(this, "data");
    this.data = i, this.name = "VOTJSError", this.message = e;
  }
}
class wu {
  constructor({ host: t = Q.host, fetchFn: e = ja, fetchOpts: i = {}, headers: s = {} } = {}) {
    c(this, "host");
    c(this, "schema");
    c(this, "fetch");
    c(this, "fetchOpts");
    c(this, "sessions", {});
    c(this, "userAgent", Q.userAgent);
    c(this, "headers", {
      "User-Agent": this.userAgent,
      Accept: "application/x-protobuf",
      "Accept-Language": "en",
      "Content-Type": "application/x-protobuf",
      Pragma: "no-cache",
      "Cache-Control": "no-cache"
    });
    c(this, "hostSchemaRe", /(http(s)?):\/\//);
    const o = this.hostSchemaRe.exec(t)?.[1];
    this.host = o ? t.replace(`${o}://`, "") : t, this.schema = o ?? "https", this.fetch = e, this.fetchOpts = i, this.headers = { ...this.headers, ...s };
  }
  async request(t, e, i = {}, s = "POST") {
    const o = this.getOpts(new Blob([e]), i, s);
    try {
      const r = await this.fetch(`${this.schema}://${this.host}${t}`, o), a = await r.arrayBuffer();
      return {
        success: r.status === 200,
        data: a
      };
    } catch (r) {
      return {
        success: !1,
        data: r?.message
      };
    }
  }
  async requestJSON(t, e = null, i = {}, s = "POST") {
    const o = this.getOpts(e, {
      "Content-Type": "application/json",
      ...i
    }, s);
    try {
      const r = await this.fetch(`${this.schema}://${this.host}${t}`, o), a = await r.json();
      return {
        success: r.status === 200,
        data: a
      };
    } catch (r) {
      return {
        success: !1,
        data: r?.message
      };
    }
  }
  getOpts(t, e = {}, i = "POST") {
    return {
      method: i,
      headers: {
        ...this.headers,
        ...e
      },
      body: t,
      ...this.fetchOpts
    };
  }
  async getSession(t) {
    const e = Wc(), i = this.sessions[t];
    if (i && i.timestamp + i.expires > e)
      return i;
    const { secretKey: s, expires: o, uuid: r } = await this.createSession(t);
    return this.sessions[t] = {
      secretKey: s,
      expires: o,
      timestamp: e,
      uuid: r
    }, this.sessions[t];
  }
  async createSession(t) {
    const e = yu(), i = jo.encodeSessionRequest(e, t), s = await this.request("/session/create", i, {
      "Vtrans-Signature": await us(i)
    });
    if (!s.success)
      throw new J("Failed to request create session", s);
    return {
      ...jo.decodeSessionResponse(s.data),
      uuid: e
    };
  }
}
let bl = class extends wu {
  constructor({ host: e, hostVOT: i = Q.hostVOT, fetchFn: s, fetchOpts: o, requestLang: r = "en", responseLang: a = "ru", apiToken: l, headers: u } = {}) {
    super({
      host: e,
      fetchFn: s,
      fetchOpts: o,
      headers: u
    });
    c(this, "hostVOT");
    c(this, "schemaVOT");
    c(this, "apiToken");
    c(this, "requestLang");
    c(this, "responseLang");
    c(this, "paths", {
      videoTranslation: "/video-translation/translate",
      videoTranslationFailAudio: "/video-translation/fail-audio-js",
      videoTranslationAudio: "/video-translation/audio",
      videoTranslationCache: "/video-translation/cache",
      videoSubtitles: "/video-subtitles/get-subtitles",
      streamPing: "/stream-translation/ping-stream",
      streamTranslation: "/stream-translation/translate-stream"
    });
    c(this, "headersVOT", {
      "User-Agent": `vot.js/${Q.version}`,
      "Content-Type": "application/json",
      Pragma: "no-cache",
      "Cache-Control": "no-cache"
    });
    const d = this.hostSchemaRe.exec(i)?.[1];
    this.hostVOT = d ? i.replace(`${d}://`, "") : i, this.schemaVOT = d ?? "https", this.requestLang = r, this.responseLang = a, this.apiToken = l;
  }
  isCustomLink(e) {
    return !!(/\.(m3u8|m4(a|v)|mpd)/.exec(e) ?? /^https:\/\/cdn\.qstv\.on\.epicgames\.com/.exec(e));
  }
  get apiTokenHeader() {
    return this.apiToken ? {
      Authorization: `OAuth ${this.apiToken}`
    } : {};
  }
  async requestVOT(e, i, s = {}) {
    const o = this.getOpts(JSON.stringify(i), {
      ...this.headersVOT,
      ...s
    });
    try {
      const r = await this.fetch(`${this.schemaVOT}://${this.hostVOT}${e}`, o), a = await r.json();
      return {
        success: r.status === 200,
        data: a
      };
    } catch (r) {
      return {
        success: !1,
        data: r?.message
      };
    }
  }
  async translateVideoYAImpl({ videoData: e, requestLang: i = this.requestLang, responseLang: s = this.responseLang, translationHelp: o = null, headers: r = {}, extraOpts: a = {}, shouldSendFailedAudio: l = !0 }) {
    const { url: u, duration: d = Q.defaultDuration } = e, h = await this.getSession("video-translation"), f = st.encodeTranslationRequest(u, d, i, s, o, a), g = this.paths.videoTranslation, m = await ce("Vtrans", h, f, g), v = a.useLivelyVoice ? this.apiTokenHeader : {}, T = await this.request(g, f, {
      ...m,
      ...v,
      ...r
    });
    if (!T.success)
      throw new J("Failed to request video translation", T);
    const S = st.decodeTranslationResponse(T.data);
    M.log("translateVideo", S);
    const { status: w, translationId: x } = S;
    switch (w) {
      case rt.FAILED:
        throw new J("Yandex couldn't translate video", S);
      case rt.FINISHED:
      case rt.PART_CONTENT:
        if (!S.url)
          throw new J("Audio link wasn't received from Yandex response", S);
        return {
          translationId: x,
          translated: !0,
          url: S.url,
          status: w,
          remainingTime: S.remainingTime ?? -1
        };
      case rt.WAITING:
      case rt.LONG_WAITING:
        return {
          translationId: x,
          translated: !1,
          status: w,
          remainingTime: S.remainingTime
        };
      case rt.AUDIO_REQUESTED:
        return u.startsWith("https://youtu.be/") && l ? (await this.requestVtransFailAudio(u), await this.requestVtransAudio(u, S.translationId, {
          audioFile: new Uint8Array(),
          fileId: on.WEB_API_GET_ALL_GENERATING_URLS_DATA_FROM_IFRAME
        }), await this.translateVideoYAImpl({
          videoData: e,
          requestLang: i,
          responseLang: s,
          translationHelp: o,
          headers: r,
          shouldSendFailedAudio: !1
        })) : {
          translationId: x,
          translated: !1,
          status: w,
          remainingTime: S.remainingTime ?? -1
        };
      case rt.SESSION_REQUIRED:
        throw new J("Yandex auth required to translate video. See docs for more info", S);
      default:
        throw M.error("Unknown response", S), new J("Unknown response from Yandex", S);
    }
  }
  async translateVideoVOTImpl({ url: e, videoId: i, service: s, requestLang: o = this.requestLang, responseLang: r = this.responseLang, headers: a = {}, provider: l = "yandex" }) {
    const u = Xo(s, i, e), d = await this.requestVOT(this.paths.videoTranslation, {
      provider: l,
      service: u.service,
      video_id: u.videoId,
      from_lang: o,
      to_lang: r,
      raw_video: e
    }, {
      ...a
    });
    if (!d.success)
      throw new J("Failed to request video translation", d);
    const h = d.data;
    switch (h.status) {
      case "failed":
        throw new J("Yandex couldn't translate video", h);
      case "success":
        if (!h.translated_url)
          throw new J("Audio link wasn't received from VOT response", h);
        return {
          translationId: String(h.id),
          translated: !0,
          url: h.translated_url,
          status: 1,
          remainingTime: -1
        };
      case "waiting":
        return {
          translationId: "",
          translated: !1,
          remainingTime: h.remaining_time,
          status: 2,
          message: h.message
        };
    }
  }
  async requestVtransFailAudio(e) {
    const i = await this.requestJSON(this.paths.videoTranslationFailAudio, JSON.stringify({
      video_url: e
    }), void 0, "PUT");
    if (!i.data || typeof i.data == "string" || i.data.status !== 1)
      throw new J("Failed to request to fake video translation fail audio js", i);
    return i;
  }
  async requestVtransAudio(e, i, s, o, r = {}) {
    const a = await this.getSession("video-translation"), l = st.isPartialAudioBuffer(s) ? st.encodeTranslationAudioRequest(e, i, s, o) : st.encodeTranslationAudioRequest(e, i, s, void 0), u = this.paths.videoTranslationAudio, d = await ce("Vtrans", a, l, u), h = await this.request(u, l, {
      ...d,
      ...r
    }, "PUT");
    if (!h.success)
      throw new J("Failed to request video translation audio", h);
    return st.decodeTranslationAudioResponse(h.data);
  }
  async translateVideoCache({ videoData: e, requestLang: i = this.requestLang, responseLang: s = this.responseLang, headers: o = {} }) {
    const { url: r, duration: a = Q.defaultDuration } = e, l = await this.getSession("video-translation"), u = st.encodeTranslationCacheRequest(r, a, i, s), d = this.paths.videoTranslationCache, h = await ce("Vtrans", l, u, d), f = await this.request(d, u, {
      ...h,
      ...o
    }, "POST");
    if (!f.success)
      throw new J("Failed to request video translation cache", f);
    return st.decodeTranslationCacheResponse(f.data);
  }
  async translateVideo({ videoData: e, requestLang: i = this.requestLang, responseLang: s = this.responseLang, translationHelp: o = null, headers: r = {}, extraOpts: a = {}, shouldSendFailedAudio: l = !0 }) {
    const { url: u, videoId: d, host: h } = e;
    return this.isCustomLink(u) ? await this.translateVideoVOTImpl({
      url: u,
      videoId: d,
      service: h,
      requestLang: i,
      responseLang: s,
      headers: r,
      provider: a.useLivelyVoice ? "yandex_lively" : "yandex"
    }) : await this.translateVideoYAImpl({
      videoData: e,
      requestLang: i,
      responseLang: s,
      translationHelp: o,
      headers: r,
      extraOpts: a,
      shouldSendFailedAudio: l
    });
  }
  async getSubtitlesYAImpl({ videoData: e, requestLang: i = this.requestLang, headers: s = {} }) {
    const { url: o } = e, r = await this.getSession("video-translation"), a = st.encodeSubtitlesRequest(o, i), l = this.paths.videoSubtitles, u = await ce("Vsubs", r, a, l), d = await this.request(l, a, {
      ...u,
      ...s
    });
    if (!d.success)
      throw new J("Failed to request video subtitles", d);
    const h = st.decodeSubtitlesResponse(d.data), f = h.subtitles.map((g) => {
      const { language: m, url: v, translatedLanguage: T, translatedUrl: S } = g;
      return {
        language: m,
        url: v,
        translatedLanguage: T,
        translatedUrl: S
      };
    });
    return {
      waiting: h.waiting,
      subtitles: f
    };
  }
  async getSubtitlesVOTImpl({ url: e, videoId: i, service: s, headers: o = {} }) {
    const r = Xo(s, i, e), a = await this.requestVOT(this.paths.videoSubtitles, {
      provider: "yandex",
      service: r.service,
      video_id: r.videoId
    }, o);
    if (!a.success)
      throw new J("Failed to request video subtitles", a);
    const l = a.data;
    return {
      waiting: !1,
      subtitles: l.reduce((d, h) => {
        if (!h.lang_from)
          return d;
        const f = l.find((g) => g.lang === h.lang_from);
        return f && d.push({
          language: f.lang,
          url: f.subtitle_url,
          translatedLanguage: h.lang,
          translatedUrl: h.subtitle_url
        }), d;
      }, [])
    };
  }
  async getSubtitles({ videoData: e, requestLang: i = this.requestLang, headers: s = {} }) {
    const { url: o, videoId: r, host: a } = e;
    return this.isCustomLink(o) ? await this.getSubtitlesVOTImpl({
      url: o,
      videoId: r,
      service: a,
      headers: s
    }) : await this.getSubtitlesYAImpl({
      videoData: e,
      requestLang: i,
      headers: s
    });
  }
  async pingStream({ pingId: e, headers: i = {} }) {
    const s = await this.getSession("video-translation"), o = st.encodeStreamPingRequest(e), r = this.paths.streamPing, a = await ce("Vtrans", s, o, r), l = await this.request(r, o, {
      ...a,
      ...i
    });
    if (!l.success)
      throw new J("Failed to request stream ping", l);
    return !0;
  }
  async translateStream({ videoData: e, requestLang: i = this.requestLang, responseLang: s = this.responseLang, headers: o = {} }) {
    const { url: r } = e;
    if (this.isCustomLink(r))
      throw new J("Unsupported video URL for getting stream translation");
    const a = await this.getSession("video-translation"), l = st.encodeStreamRequest(r, i, s), u = this.paths.streamTranslation, d = await ce("Vtrans", a, l, u), h = await this.request(u, l, {
      ...d,
      ...o
    });
    if (!h.success)
      throw new J("Failed to request stream translation", h);
    const f = st.decodeStreamResponse(h.data), g = f.interval;
    switch (g) {
      case dt.NO_CONNECTION:
      case dt.TRANSLATING:
        return {
          translated: !1,
          interval: g,
          message: g === dt.NO_CONNECTION ? "streamNoConnectionToServer" : "translationTakeFewMinutes"
        };
      case dt.STREAMING:
        return {
          translated: !0,
          interval: g,
          pingId: f.pingId,
          result: f.translatedInfo
        };
      default:
        throw M.error("Unknown response", f), new J("Unknown response from Yandex", f);
    }
  }
}, Su = class extends bl {
  constructor(t = {}) {
    t.host = t.host ?? Q.hostWorker, super(t);
  }
  async request(t, e, i = {}, s = "POST") {
    const o = this.getOpts(JSON.stringify({
      headers: {
        ...this.headers,
        ...i
      },
      body: Array.from(e)
    }), {
      "Content-Type": "application/json"
    }, s);
    try {
      const r = await this.fetch(`${this.schema}://${this.host}${t}`, o), a = await r.arrayBuffer();
      return {
        success: r.status === 200,
        data: a
      };
    } catch (r) {
      return {
        success: !1,
        data: r?.message
      };
    }
  }
  async requestJSON(t, e = null, i = {}, s = "POST") {
    const o = this.getOpts(JSON.stringify({
      headers: {
        ...this.headers,
        "Content-Type": "application/json",
        Accept: "application/json",
        ...i
      },
      body: e
    }), {
      Accept: "application/json",
      "Content-Type": "application/json"
    }, s);
    try {
      const r = await this.fetch(`${this.schema}://${this.host}${t}`, o), a = await r.json();
      return {
        success: r.status === 200,
        data: a
      };
    } catch (r) {
      return {
        success: !1,
        data: r?.message
      };
    }
  }
};
class Tu extends bl {
  constructor(t) {
    super(t), this.headers = {
      ...pl,
      ...this.headers
    };
  }
}
class ku extends Su {
  constructor(t) {
    super(t), this.headers = {
      ...pl,
      ...this.headers
    };
  }
}
class Jn extends Error {
  constructor(t) {
    super(t), this.name = "VideoDataError", this.message = t;
  }
}
const Lu = /(file:\/\/(\/)?|(http(s)?:\/\/)(127\.0\.0\.1|localhost|192\.168\.(\d){1,3}\.(\d){1,3}))/, xu = [
  "yewtu.be",
  "yt.artemislena.eu",
  "invidious.flokinet.to",
  "iv.melmac.space",
  "inv.nadeko.net",
  "inv.tux.pizza",
  "invidious.private.coffee",
  "yt.drgnz.club",
  "vid.puffyan.us",
  "invidious.dhusch.de"
], Au = [
  "piped.video",
  "piped.tokhmi.xyz",
  "piped.moomoo.me",
  "piped.syncpundit.io",
  "piped.mha.fi",
  "watch.whatever.social",
  "piped.garudalinux.org",
  "efy.piped.pages.dev",
  "watch.leptons.xyz",
  "piped.lunar.icu",
  "yt.dc09.ru",
  "piped.mint.lgbt",
  "il.ax",
  "piped.privacy.com.de",
  "piped.esmailelbob.xyz",
  "piped.projectsegfau.lt",
  "piped.in.projectsegfau.lt",
  "piped.us.projectsegfau.lt",
  "piped.privacydev.net",
  "piped.palveluntarjoaja.eu",
  "piped.smnz.de",
  "piped.adminforge.de",
  "piped.qdi.fi",
  "piped.hostux.net",
  "piped.chauvet.pro",
  "piped.jotoma.de",
  "piped.pfcd.me",
  "piped.frontendfriendly.xyz"
], Eu = [
  "proxitok.pabloferreiro.es",
  "proxitok.pussthecat.org",
  "tok.habedieeh.re",
  "proxitok.esmailelbob.xyz",
  "proxitok.privacydev.net",
  "tok.artemislena.eu",
  "tok.adminforge.de",
  "tt.vern.cc",
  "cringe.whatever.social",
  "proxitok.lunar.icu",
  "proxitok.privacy.com.de"
], Vu = [
  "peertube.1312.media",
  "tube.shanti.cafe",
  "bee-tube.fr",
  "video.sadmin.io",
  "dalek.zone",
  "review.peertube.biz",
  "peervideo.club",
  "tube.la-dina.net",
  "peertube.tmp.rcp.tf",
  "peertube.su",
  "video.blender.org",
  "videos.viorsan.com",
  "tube-sciences-technologies.apps.education.fr",
  "tube-numerique-educatif.apps.education.fr",
  "tube-arts-lettres-sciences-humaines.apps.education.fr",
  "beetoons.tv",
  "comics.peertube.biz",
  "makertube.net"
], Cu = [
  "poketube.fun",
  "pt.sudovanilla.org",
  "poke.ggtyler.dev",
  "poke.uk2.littlekai.co.uk",
  "poke.blahai.gay"
], Iu = ["ricktube.ru"], Pu = ["coursehunter.net", "coursetrain.net"];
var K;
(function(n) {
  n.udemy = "udemy", n.coursera = "coursera", n.douyin = "douyin", n.artstation = "artstation", n.kickstarter = "kickstarter", n.oraclelearn = "oraclelearn", n.deeplearningai = "deeplearningai", n.netacad = "netacad";
})(K || (K = {}));
({
  ...y,
  ...K
});
const Mu = [
  {
    additionalData: "mobile",
    host: y.youtube,
    url: "https://youtu.be/",
    match: /^m.youtube.com$/,
    selector: ".player-container",
    needExtraData: !0
  },
  {
    host: y.youtube,
    url: "https://youtu.be/",
    match: /^(www.)?youtube(-nocookie|kids)?.com$/,
    selector: ".html5-video-container:not(#inline-player *)",
    needExtraData: !0
  },
  {
    host: y.invidious,
    url: "https://youtu.be/",
    match: xu,
    selector: "#player",
    needBypassCSP: !0
  },
  {
    host: y.piped,
    url: "https://youtu.be/",
    match: Au,
    selector: ".shaka-video-container",
    needBypassCSP: !0
  },
  {
    host: y.poketube,
    url: "https://youtu.be/",
    match: Cu,
    selector: ".video-player-container"
  },
  {
    host: y.ricktube,
    url: "https://youtu.be/",
    match: Iu,
    selector: "#oframeplayer > pjsdiv:has(video)"
  },
  {
    additionalData: "mobile",
    host: y.vk,
    url: "https://vk.com/video?z=",
    match: [/^m.vk.(com|ru)$/, /^m.vkvideo.ru$/],
    selector: "vk-video-player",
    shadowRoot: !0,
    needExtraData: !0
  },
  {
    additionalData: "clips",
    host: y.vk,
    url: "https://vk.com/video?z=",
    match: /^(www.|m.)?vk.(com|ru)$/,
    selector: 'div[data-testid="clipcontainer-video"]',
    needExtraData: !0
  },
  {
    host: y.vk,
    url: "https://vk.com/video?z=",
    match: [/^(www.|m.)?vk.(com|ru)$/, /^(www.|m.)?vkvideo.ru$/],
    selector: ".videoplayer_media",
    needExtraData: !0
  },
  {
    host: y.nine_gag,
    url: "https://9gag.com/gag/",
    match: /^9gag.com$/,
    selector: ".video-post",
    needExtraData: !0
  },
  {
    host: y.twitch,
    url: "https://twitch.tv/",
    match: [
      /^m.twitch.tv$/,
      /^(www.)?twitch.tv$/,
      /^clips.twitch.tv$/,
      /^player.twitch.tv$/
    ],
    needExtraData: !0,
    selector: ".video-ref, main > div > section > div > div > div"
  },
  {
    host: y.proxitok,
    url: "https://www.tiktok.com/",
    match: Eu,
    selector: ".column.has-text-centered"
  },
  {
    host: y.tiktok,
    url: "https://www.tiktok.com/",
    match: /^(www.)?tiktok.com$/,
    selector: null
  },
  {
    host: K.douyin,
    url: "https://www.douyin.com/",
    match: /^(www.)?douyin.com/,
    selector: ".xg-video-container",
    needExtraData: !0,
    needBypassCSP: !0
  },
  {
    host: y.vimeo,
    url: "https://vimeo.com/",
    match: /^vimeo.com$/,
    needExtraData: !0,
    selector: ".player"
  },
  {
    host: y.vimeo,
    url: "https://player.vimeo.com/",
    match: /^player.vimeo.com$/,
    additionalData: "embed",
    needExtraData: !0,
    needBypassCSP: !0,
    selector: ".player"
  },
  {
    host: y.xvideos,
    url: "https://www.xvideos.com/",
    match: [
      /^(www.)?xvideos(-ar)?.com$/,
      /^(www.)?xvideos(\d\d\d).com$/,
      /^(www.)?xv-ru.com$/
    ],
    selector: "#hlsplayer",
    needBypassCSP: !0
  },
  {
    host: y.pornhub,
    url: "https://rt.pornhub.com/view_video.php?viewkey=",
    match: /^[a-z]+.pornhub.(com|org)$/,
    selector: ".mainPlayerDiv > .video-element-wrapper-js > div",
    eventSelector: ".mgp_eventCatcher"
  },
  {
    additionalData: "embed",
    host: y.pornhub,
    url: "https://rt.pornhub.com/view_video.php?viewkey=",
    match: (n) => /^[a-z]+.pornhub.(com|org)$/.exec(n.host) && n.pathname.startsWith("/embed/"),
    selector: "#player"
  },
  {
    host: y.twitter,
    url: "https://twitter.com/i/status/",
    match: /^(twitter|x).com$/,
    selector: 'div[data-testid="videoComponent"] > div:nth-child(1) > div',
    eventSelector: 'div[data-testid="videoPlayer"]',
    needBypassCSP: !0
  },
  {
    host: y.rumble,
    url: "https://rumble.com/",
    match: /^rumble.com$/,
    selector: "#videoPlayer > .videoPlayer-Rumble-cls > div"
  },
  {
    host: y.facebook,
    url: "https://facebook.com/",
    match: (n) => n.host.includes("facebook.com") && n.pathname.includes("/videos/"),
    selector: 'div[role="main"] div[data-pagelet$="video" i]',
    needBypassCSP: !0
  },
  {
    additionalData: "reels",
    host: y.facebook,
    url: "https://facebook.com/",
    match: (n) => n.host.includes("facebook.com") && n.pathname.includes("/reel/"),
    selector: 'div[role="main"]',
    needBypassCSP: !0
  },
  {
    host: y.rutube,
    url: "https://rutube.ru/video/",
    match: /^rutube.ru$/,
    selector: ".video-player > div > div > div:nth-child(2)"
  },
  {
    additionalData: "embed",
    host: y.rutube,
    url: "https://rutube.ru/video/",
    match: /^rutube.ru$/,
    selector: "#app > div > div"
  },
  {
    host: y.bilibili,
    url: "https://www.bilibili.com/",
    match: /^(www|m|player).bilibili.com$/,
    selector: ".bpx-player-video-wrap"
  },
  {
    additionalData: "old",
    host: y.bilibili,
    url: "https://www.bilibili.com/",
    match: /^(www|m).bilibili.com$/,
    selector: null
  },
  {
    host: y.mailru,
    url: "https://my.mail.ru/",
    match: /^my.mail.ru$/,
    selector: "#b-video-wrapper"
  },
  {
    host: y.bitchute,
    url: "https://www.bitchute.com/video/",
    match: /^(www.)?bitchute.com$/,
    selector: ".video-js"
  },
  {
    host: y.eporner,
    url: "https://www.eporner.com/",
    match: /^(www.)?eporner.com$/,
    selector: ".vjs-v7"
  },
  {
    host: y.peertube,
    url: "stub",
    match: Vu,
    selector: ".vjs-v7"
  },
  {
    host: y.dailymotion,
    url: "https://dai.ly/",
    match: /^geo([\d]+)?.dailymotion.com$/,
    selector: ".player"
  },
  {
    host: y.trovo,
    url: "https://trovo.live/s/",
    match: /^trovo.live$/,
    selector: ".player-video"
  },
  {
    host: y.yandexdisk,
    url: "https://yadi.sk/",
    match: /^disk.yandex.(ru|kz|com(\.(am|ge|tr))?|by|az|co\.il|ee|lt|lv|md|net|tj|tm|uz)$/,
    selector: ".video-player__player > div:nth-child(1)",
    eventSelector: ".video-player__player",
    needBypassCSP: !0,
    needExtraData: !0
  },
  {
    host: y.okru,
    url: "https://ok.ru/video/",
    match: /^ok.ru$/,
    selector: "vk-video-player",
    shadowRoot: !0
  },
  {
    host: y.googledrive,
    url: "https://drive.google.com/file/d/",
    match: /^youtube.googleapis.com$/,
    selector: ".html5-video-container"
  },
  {
    host: y.bannedvideo,
    url: "https://madmaxworld.tv/watch?id=",
    match: /^(www.)?banned.video|madmaxworld.tv$/,
    selector: ".vjs-v7",
    needExtraData: !0
  },
  {
    host: y.weverse,
    url: "https://weverse.io/",
    match: /^weverse.io$/,
    selector: ".webplayer-internal-source-wrapper",
    needExtraData: !0
  },
  {
    host: y.newgrounds,
    url: "https://www.newgrounds.com/",
    match: /^(www.)?newgrounds.com$/,
    selector: ".ng-video-player"
  },
  {
    host: y.egghead,
    url: "https://egghead.io/",
    match: /^egghead.io$/,
    selector: ".cueplayer-react-video-holder"
  },
  {
    host: y.youku,
    url: "https://v.youku.com/",
    match: /^v.youku.com$/,
    selector: "#ykPlayer"
  },
  {
    host: y.archive,
    url: "https://archive.org/details/",
    match: /^archive.org$/,
    selector: ".jw-media"
  },
  {
    host: y.kodik,
    url: "stub",
    match: /^kodik.(info|biz|cc)$/,
    selector: ".fp-player",
    needExtraData: !0
  },
  {
    host: y.patreon,
    url: "stub",
    match: /^(www.)?patreon.com$/,
    selector: 'div[data-tag="post-card"] div[elevation="subtle"] > div > div > div > div',
    needExtraData: !0
  },
  {
    additionalData: "old",
    host: y.reddit,
    url: "stub",
    match: /^old.reddit.com$/,
    selector: ".reddit-video-player-root",
    needExtraData: !0,
    needBypassCSP: !0
  },
  {
    host: y.reddit,
    url: "stub",
    match: /^(www.|new.)?reddit.com$/,
    selector: "div[slot=post-media-container]",
    shadowRoot: !0,
    needExtraData: !0,
    needBypassCSP: !0
  },
  {
    host: y.kick,
    url: "https://kick.com/",
    match: /^kick.com$/,
    selector: "#injected-embedded-channel-player-video > div",
    needExtraData: !0
  },
  {
    host: y.appledeveloper,
    url: "https://developer.apple.com/",
    match: /^developer.apple.com$/,
    selector: ".developer-video-player",
    needExtraData: !0,
    needBypassCSP: !0
  },
  {
    host: y.epicgames,
    url: "https://dev.epicgames.com/community/learning/",
    match: /^dev.epicgames.com$/,
    selector: ".vjs-v7",
    needExtraData: !0
  },
  {
    host: y.odysee,
    url: "stub",
    match: /^odysee.com$/,
    selector: ".vjs-v7",
    needExtraData: !0
  },
  {
    host: y.coursehunterLike,
    url: "stub",
    match: Pu,
    selector: "#oframeplayer > pjsdiv:has(video)",
    needExtraData: !0
  },
  {
    host: y.sap,
    url: "https://learning.sap.com/courses/",
    match: /^learning.sap.com$/,
    selector: ".playkit-container",
    eventSelector: ".playkit-player",
    needExtraData: !0,
    needBypassCSP: !0
  },
  {
    host: K.udemy,
    url: "https://www.udemy.com/",
    match: /udemy.com$/,
    selector: 'div[data-purpose="curriculum-item-viewer-content"] > section > div > div > div > div:nth-of-type(2)',
    needExtraData: !0
  },
  {
    host: K.coursera,
    url: "https://www.coursera.org/",
    match: /coursera.org$/,
    selector: ".vjs-v8",
    needExtraData: !0
  },
  {
    host: y.watchpornto,
    url: "https://watchporn.to/",
    match: /^watchporn.to$/,
    selector: ".fp-player"
  },
  {
    host: y.linkedin,
    url: "https://www.linkedin.com/learning/",
    match: /^(www.)?linkedin.com$/,
    selector: ".vjs-v7",
    needExtraData: !0,
    needBypassCSP: !0
  },
  {
    host: y.incestflix,
    url: "https://www.incestflix.net/watch/",
    match: /^(www.)?incestflix.(net|to|com)$/,
    selector: "#incflix-stream",
    needExtraData: !0
  },
  {
    host: y.porntn,
    url: "https://porntn.com/videos/",
    match: /^porntn.com$/,
    selector: ".fp-player",
    needExtraData: !0
  },
  {
    host: y.dzen,
    url: "https://dzen.ru/video/watch/",
    match: /^dzen.ru$/,
    selector: ".zen-ui-video-video-player"
  },
  {
    host: y.cloudflarestream,
    url: "stub",
    match: /^(watch|embed|iframe|customer-[^.]+).cloudflarestream.com$/,
    selector: null
  },
  {
    host: y.loom,
    url: "https://www.loom.com/share/",
    match: /^(www.)?loom.com$/,
    selector: ".VideoLayersContainer",
    needExtraData: !0,
    needBypassCSP: !0
  },
  {
    host: K.artstation,
    url: "https://www.artstation.com/learning/",
    match: /^(www.)?artstation.com$/,
    selector: ".vjs-v7",
    needExtraData: !0
  },
  {
    host: y.rtnews,
    url: "https://www.rt.com/",
    match: /^(www.)?rt.com$/,
    selector: ".jw-media",
    needExtraData: !0
  },
  {
    host: y.bitview,
    url: "https://www.bitview.net/watch?v=",
    match: /^(www.)?bitview.net$/,
    selector: ".vlScreen",
    needExtraData: !0
  },
  {
    host: K.kickstarter,
    url: "https://www.kickstarter.com/",
    match: /^(www.)?kickstarter.com/,
    selector: ".ksr-video-player",
    needExtraData: !0
  },
  {
    host: y.thisvid,
    url: "https://thisvid.com/",
    match: /^(www.)?thisvid.com$/,
    selector: ".fp-player"
  },
  {
    additionalData: "regional",
    host: y.ign,
    url: "https://de.ign.com/",
    match: /^(\w{2}.)?ign.com$/,
    needExtraData: !0,
    selector: ".video-container"
  },
  {
    host: y.ign,
    url: "https://www.ign.com/",
    match: /^(www.)?ign.com$/,
    selector: ".player",
    needExtraData: !0
  },
  {
    host: y.bunkr,
    url: "https://bunkr.site/",
    match: /^bunkr\.(site|black|cat|media|red|site|ws|org|s[kiu]|c[ir]|fi|p[hks]|ru|la|is|to|a[cx])$/,
    needExtraData: !0,
    selector: ".plyr__video-wrapper"
  },
  {
    host: y.imdb,
    url: "https://www.imdb.com/video/",
    match: /^(www\.)?imdb\.com$/,
    selector: ".jw-media"
  },
  {
    host: y.telegram,
    url: "https://t.me/",
    match: (n) => /^web\.telegram\.org$/.test(n.hostname) && n.pathname.startsWith("/k"),
    selector: ".ckin__player"
  },
  {
    host: K.oraclelearn,
    url: "https://mylearn.oracle.com/ou/course/",
    match: /^mylearn\.oracle\.com/,
    selector: ".vjs-v7",
    needExtraData: !0,
    needBypassCSP: !0
  },
  {
    host: K.deeplearningai,
    url: "https://learn.deeplearning.ai/courses/",
    match: /^learn(-dev|-staging)?\.deeplearning\.ai/,
    selector: ".lesson-video-player",
    needExtraData: !0
  },
  {
    host: K.netacad,
    url: "https://www.netacad.com/",
    match: /^(www\.)?netacad\.com/,
    selector: ".vjs-v8",
    needExtraData: !0
  },
  {
    host: y.custom,
    url: "stub",
    match: (n) => /([^.]+)\.(mp4|webm)/.test(n.pathname),
    rawResult: !0
  }
];
class F extends Error {
  constructor(t) {
    super(t), this.name = "VideoHelper", this.message = t;
  }
}
class P {
  constructor({ fetchFn: t = ja, extraInfo: e = !0, referer: i = document.referrer ?? `${window.location.origin}/`, origin: s = window.location.origin, service: o, video: r, language: a = "en" } = {}) {
    c(this, "API_ORIGIN", window.location.origin);
    c(this, "fetch");
    c(this, "extraInfo");
    c(this, "referer");
    c(this, "origin");
    c(this, "service");
    c(this, "video");
    c(this, "language");
    this.fetch = t, this.extraInfo = e, this.referer = i, this.origin = /^(http(s)?):\/\//.test(String(s)) ? s : window.location.origin, this.service = o, this.video = r, this.language = a;
  }
  async getVideoData(t) {
  }
  async getVideoId(t) {
  }
  returnBaseData(t) {
    if (this.service)
      return {
        url: this.service.url + t,
        videoId: t,
        host: this.service.host,
        duration: void 0
      };
  }
}
class Ou extends P {
  constructor() {
    super(...arguments);
    c(this, "API_ORIGIN", "https://developer.apple.com");
  }
  async getVideoData(e) {
    try {
      const i = document.querySelector("meta[property='og:video']")?.content;
      if (!i)
        throw new F("Failed to find content url");
      return {
        url: i
      };
    } catch (i) {
      M.error(`Failed to get apple developer video data by video ID: ${e}`, i.message);
      return;
    }
  }
  async getVideoId(e) {
    return /videos\/play\/([^/]+)\/([\d]+)/.exec(e.pathname)?.[0];
  }
}
class Du extends P {
  async getVideoId(t) {
    return /(details|embed)\/([^/]+)/.exec(t.pathname)?.[2];
  }
}
class _u extends P {
  constructor() {
    super(...arguments);
    c(this, "API_ORIGIN", "https://www.artstation.com/api/v2/learning");
  }
  getCSRFToken() {
    return document.querySelector('meta[name="public-csrf-token"]')?.content;
  }
  async getCourseInfo(e) {
    try {
      return await (await this.fetch(`${this.API_ORIGIN}/courses/${e}/autoplay.json`, {
        method: "POST",
        headers: {
          "PUBLIC-CSRF-TOKEN": this.getCSRFToken()
        }
      })).json();
    } catch (i) {
      return M.error(`Failed to get artstation course info by courseId: ${e}.`, i.message), !1;
    }
  }
  async getVideoUrl(e) {
    try {
      return (await (await this.fetch(`${this.API_ORIGIN}/quicksilver/video_url.json?chapter_id=${e}`)).json()).url.replace("qsep://", "https://");
    } catch (i) {
      return M.error(`Failed to get artstation video url by chapterId: ${e}.`, i.message), !1;
    }
  }
  async getVideoData(e) {
    const [, i, , , s] = e.split("/"), o = await this.getCourseInfo(i);
    if (!o)
      return;
    const r = o.chapters.find((f) => f.hash_id === s);
    if (!r)
      return;
    const a = await this.getVideoUrl(r.id);
    if (!a)
      return;
    const { title: l, duration: u, subtitles: d } = r, h = d.filter((f) => f.format === "vtt").map((f) => ({
      language: tt(f.locale),
      source: "artstation",
      format: "vtt",
      url: f.file_url
    }));
    return {
      url: a,
      title: l,
      duration: u,
      subtitles: h
    };
  }
  async getVideoId(e) {
    return /courses\/(\w{3,5})\/([^/]+)\/chapters\/(\w{3,5})/.exec(e.pathname)?.[0];
  }
}
class Ru extends P {
  constructor() {
    super(...arguments);
    c(this, "API_ORIGIN", "https://api.banned.video");
  }
  async getVideoInfo(e) {
    try {
      return await (await this.fetch(`${this.API_ORIGIN}/graphql`, {
        method: "POST",
        body: JSON.stringify({
          operationName: "GetVideo",
          query: `query GetVideo($id: String!) {
            getVideo(id: $id) {
              title
              description: summary
              duration: videoDuration
              videoUrl: directUrl
              isStream: live
            }
          }`,
          variables: {
            id: e
          }
        }),
        headers: {
          "User-Agent": "bannedVideoFrontEnd",
          "apollographql-client-name": "banned-web",
          "apollographql-client-version": "1.3",
          "content-type": "application/json"
        }
      })).json();
    } catch (i) {
      return console.error(`Failed to get bannedvideo video info by videoId: ${e}.`, i.message), !1;
    }
  }
  async getVideoData(e) {
    const i = await this.getVideoInfo(e);
    if (!i)
      return;
    const { videoUrl: s, duration: o, isStream: r, description: a, title: l } = i.data.getVideo;
    return {
      url: s,
      duration: o,
      isStream: r,
      title: l,
      description: a
    };
  }
  async getVideoId(e) {
    return e.searchParams.get("id") ?? void 0;
  }
}
class Bu extends P {
  async getVideoId(t) {
    const e = /bangumi\/play\/([^/]+)/.exec(t.pathname)?.[0];
    if (e)
      return e;
    const i = t.searchParams.get("bvid");
    if (i)
      return `video/${i}`;
    let s = /video\/([^/]+)/.exec(t.pathname)?.[0];
    return s && t.searchParams.get("p") !== null && (s += `/?p=${t.searchParams.get("p")}`), s;
  }
}
class Fu extends P {
  async getVideoId(t) {
    return /(video|embed)\/([^/]+)/.exec(t.pathname)?.[2];
  }
}
class Nu extends P {
  async getVideoData(t) {
    try {
      const e = document.querySelector(".vlScreen > video")?.src;
      if (!e)
        throw new F("Failed to find video URL");
      return {
        url: e
      };
    } catch (e) {
      M.error(`Failed to get Bitview data by videoId: ${t}`, e.message);
      return;
    }
  }
  async getVideoId(t) {
    return t.searchParams.get("v");
  }
}
class Uu extends P {
  async getVideoData(t) {
    const e = document.querySelector('#player > source[type="video/mp4"]')?.src;
    if (e)
      return {
        url: e
      };
  }
  async getVideoId(t) {
    return /\/f\/([^/]+)/.exec(t.pathname)?.[1];
  }
}
class Hu extends P {
  async getVideoId(t) {
    return t.pathname + t.search;
  }
}
class $u extends P {
  constructor() {
    super(...arguments);
    c(this, "API_ORIGIN", this.origin ?? "https://coursehunter.net");
  }
  async getCourseId() {
    const e = window.course_id;
    return e !== void 0 ? String(e) : document.querySelector('input[name="course_id"]')?.value;
  }
  async getLessonsData(e) {
    const i = window.lessons;
    if (i?.length)
      return i;
    try {
      return await (await this.fetch(`${this.API_ORIGIN}/api/v1/course/${e}/lessons`)).json();
    } catch (s) {
      M.error(`Failed to get CoursehunterLike lessons data by courseId: ${e}, because ${s.message}`);
      return;
    }
  }
  getLessondId(e) {
    let i = e.split("?lesson=")?.[1];
    return i || (i = document.querySelector(".lessons-item_active")?.dataset?.index, i) ? +i : 1;
  }
  async getVideoData(e) {
    const i = await this.getCourseId();
    if (!i)
      return;
    const s = await this.getLessonsData(i);
    if (!s)
      return;
    const o = this.getLessondId(e), r = s?.[o - 1], { file: a, duration: l, title: u } = r;
    if (a)
      return {
        url: St(a),
        duration: l,
        title: u
      };
  }
  async getVideoId(e) {
    const i = /course\/([^/]+)/.exec(e.pathname)?.[0];
    return i ? i + e.search : void 0;
  }
}
class oe extends P {
  constructor() {
    super(...arguments);
    c(this, "SUBTITLE_SOURCE", "videojs");
    c(this, "SUBTITLE_FORMAT", "vtt");
  }
  static getPlayer() {
    return document.querySelector(".video-js")?.player;
  }
  getVideoDataByPlayer(e) {
    try {
      const i = oe.getPlayer();
      if (!i)
        throw new Error(`Video player doesn't have player option, videoId ${e}`);
      const s = i.duration(), o = Array.isArray(i.currentSources) ? i.currentSources : i.getCache()?.sources, { tracks_: r } = i.textTracks(), a = o.find((u) => u.type === "video/mp4" || u.type === "video/webm");
      if (!a)
        throw new Error(`Failed to find video url for videoID ${e}`);
      const l = r.filter((u) => u.src && u.kind !== "metadata").map((u) => ({
        language: tt(u.language),
        source: this.SUBTITLE_SOURCE,
        format: this.SUBTITLE_FORMAT,
        url: u.src
      }));
      return {
        url: a.src,
        duration: s,
        subtitles: l
      };
    } catch (i) {
      M.error("Failed to get videojs video data", i.message);
      return;
    }
  }
}
const Pt = [
  "auto",
  "ru",
  "en",
  "zh",
  "ko",
  "lt",
  "lv",
  "ar",
  "fr",
  "it",
  "es",
  "de",
  "ja"
], mi = ["ru", "en", "kk"];
class Hs extends oe {
  constructor() {
    super(...arguments);
    c(this, "API_ORIGIN", "https://www.coursera.org/api");
    c(this, "SUBTITLE_SOURCE", "coursera");
  }
  async getCourseData(e) {
    try {
      return (await (await this.fetch(`${this.API_ORIGIN}/onDemandCourses.v1/${e}`)).json())?.elements?.[0];
    } catch (i) {
      M.error(`Failed to get course data by courseId: ${e}`, i.message);
      return;
    }
  }
  static getPlayer() {
    return oe.getPlayer();
  }
  async getVideoData(e) {
    const i = this.getVideoDataByPlayer(e);
    if (!i)
      return;
    const { options_: s } = Hs.getPlayer() ?? {};
    !i.subtitles?.length && s && (i.subtitles = s.tracks.map((g) => ({
      url: g.src,
      language: tt(g.srclang),
      source: this.SUBTITLE_SOURCE,
      format: this.SUBTITLE_FORMAT
    })));
    const o = s?.courseId;
    if (!o)
      return i;
    let r = "en";
    const a = await this.getCourseData(o);
    if (a) {
      const { primaryLanguageCodes: [g] } = a;
      r = g ? tt(g) : "en";
    }
    Pt.includes(r) || (r = "en");
    const u = (i.subtitles.find((g) => g.language === r) ?? i.subtitles?.[0])?.url;
    u || M.warn("Failed to find any subtitle file");
    const { url: d, duration: h } = i, f = u ? [
      {
        target: "subtitles_file_url",
        targetUrl: u
      },
      {
        target: "video_file_url",
        targetUrl: d
      }
    ] : null;
    return {
      ...u ? {
        url: this.service?.url + e,
        translationHelp: f
      } : {
        url: d,
        translationHelp: f
      },
      detectedLanguage: r,
      duration: h
    };
  }
  async getVideoId(e) {
    return (/learn\/([^/]+)\/lecture\/([^/]+)/.exec(e.pathname) ?? /lecture\/([^/]+)\/([^/]+)/.exec(e.pathname))?.[0];
  }
}
class Wu extends P {
  async getVideoId(t) {
    const i = Array.from(document.querySelectorAll("*")).filter((s) => s.innerHTML.trim().includes(".m3u8"))?.[1]?.lastChild?.src;
    return i ? /\/video\/(\w+)\.m3u8/.exec(i)?.[1] : void 0;
  }
}
class zu extends P {
  async getVideoData(t) {
    if (!this.video)
      return;
    const e = this.video.querySelector('source[type="application/x-mpegurl"]')?.src;
    if (e)
      return {
        url: e
      };
  }
  async getVideoId(t) {
    return /courses\/(([^/]+)\/lesson\/([^/]+)\/([^/]+))/.exec(t.pathname)?.[1];
  }
}
class Zn extends P {
  static getPlayer() {
    if (!(typeof player > "u"))
      return player;
  }
  async getVideoData(t) {
    const e = Zn.getPlayer();
    if (!e)
      return;
    const { config: { url: i, duration: s, lang: o, isLive: r } } = e;
    if (!i)
      return;
    const a = i.find((l) => l.src.includes("www.douyin.com/aweme/v1/play/"));
    if (a)
      return {
        url: St(a.src),
        duration: s,
        isStream: r,
        ...Pt.includes(o) ? { detectedLanguage: o } : {}
      };
  }
  async getVideoId(t) {
    const e = /video\/([\d]+)/.exec(t.pathname)?.[0];
    return e || Zn.getPlayer()?.config.vid;
  }
}
class qu extends P {
  async getVideoId(t) {
    return /video\/watch\/([^/]+)/.exec(t.pathname)?.[1];
  }
}
class Gu extends P {
  async getVideoId(t) {
    return t.pathname.slice(1);
  }
}
class Ku extends P {
  constructor() {
    super(...arguments);
    c(this, "API_ORIGIN", "https://dev.epicgames.com/community/api/learning");
  }
  async getPostInfo(e) {
    try {
      return await (await this.fetch(`${this.API_ORIGIN}/post.json?hash_id=${e}`)).json();
    } catch (i) {
      return M.error(`Failed to get epicgames post info by videoId: ${e}.`, i.message), !1;
    }
  }
  getVideoBlock() {
    const e = /videoUrl\s?=\s"([^"]+)"?/, i = Array.from(document.body.querySelectorAll("script")).find((a) => e.exec(a.innerHTML));
    if (!i)
      return;
    const s = i.innerHTML.trim(), o = e.exec(s)?.[1]?.replace("qsep://", "https://");
    if (!o)
      return;
    let r = /sources\s?=\s(\[([^\]]+)\])?/.exec(s)?.[1];
    if (!r)
      return {
        playlistUrl: o,
        subtitles: []
      };
    try {
      r = (r.replace(/src:(\s)+?(videoUrl)/g, 'src:"removed"').substring(0, r.lastIndexOf("},")) + "]").split(`
`).map((u) => u.replace(/([^\s]+):\s?(?!.*\1)/, '"$1":')).join(`
`);
      const l = JSON.parse(r).filter((u) => u.type === "captions");
      return {
        playlistUrl: o,
        subtitles: l
      };
    } catch {
      return {
        playlistUrl: o,
        subtitles: []
      };
    }
  }
  async getVideoData(e) {
    const i = e.split(":")?.[1], s = await this.getPostInfo(i);
    if (!s)
      return;
    const o = this.getVideoBlock();
    if (!o)
      return;
    const { playlistUrl: r, subtitles: a } = o, { title: l, description: u } = s, d = a.map((h) => ({
      language: tt(h.srclang),
      source: "epicgames",
      format: "vtt",
      url: h.src
    }));
    return {
      url: r,
      title: l,
      description: u,
      subtitles: d
    };
  }
  async getVideoId(e) {
    return new Promise((i) => {
      const s = "https://dev.epicgames.com", o = btoa(window.location.href);
      window.addEventListener("message", (r) => {
        if (r.origin !== s || !(typeof r.data == "string" && r.data.startsWith("getVideoId:")))
          return;
        const a = r.data.replace("getVideoId:", "");
        return i(a);
      }), window.top.postMessage(`getVideoId:${o}`, s);
    });
  }
}
class Yu extends P {
  async getVideoId(t) {
    return /video-([^/]+)\/([^/]+)/.exec(t.pathname)?.[0];
  }
}
class ju extends P {
  async getVideoId(t) {
    return t.pathname.slice(1);
  }
}
class Xu extends P {
  getPlayerData() {
    return document.querySelector("#movie_player")?.getVideoData?.call() ?? void 0;
  }
  async getVideoId(t) {
    return this.getPlayerData()?.video_id;
  }
}
class Ju extends P {
  getVideoDataBySource(t) {
    const e = document.querySelector('.icms.video > source[type="video/mp4"][data-quality="360"]')?.src;
    return e ? {
      url: St(e)
    } : this.returnBaseData(t);
  }
  getVideoDataByNext(t) {
    try {
      const e = document.getElementById("__NEXT_DATA__")?.textContent;
      if (!e)
        throw new Jn("Not found __NEXT_DATA__ content");
      const i = JSON.parse(e), { props: { pageProps: { page: { description: s, title: o, video: { videoMetadata: { duration: r }, assets: a } } } } } = i, l = a.find((u) => u.height === 360 && u.url.includes(".mp4"))?.url;
      if (!l)
        throw new Jn("Not found video URL in assets");
      return {
        url: St(l),
        duration: r,
        title: o,
        description: s
      };
    } catch (e) {
      return M.warn(`Failed to get ign video data by video ID: ${t}, because ${e.message}. Using clear link instead...`), this.returnBaseData(t);
    }
  }
  async getVideoData(t) {
    return document.getElementById("__NEXT_DATA__") ? this.getVideoDataByNext(t) : this.getVideoDataBySource(t);
  }
  async getVideoId(t) {
    return /([^/]+)\/([\d]+)\/video\/([^/]+)/.exec(t.pathname)?.[0] ?? /\/videos\/([^/]+)/.exec(t.pathname)?.[0];
  }
}
class Zu extends P {
  async getVideoId(t) {
    return /video\/([^/]+)/.exec(t.pathname)?.[1];
  }
}
class Qu extends P {
  async getVideoData(t) {
    try {
      const e = document.querySelector("#incflix-stream source:first-of-type");
      if (!e)
        throw new F("Failed to find source element");
      const i = e.getAttribute("src");
      if (!i)
        throw new F("Failed to find source link");
      const s = new URL(i.startsWith("//") ? `https:${i}` : i);
      return s.searchParams.append("media-proxy", "video.mp4"), {
        url: St(s)
      };
    } catch (e) {
      M.error(`Failed to get Incestflix data by videoId: ${t}`, e.message);
      return;
    }
  }
  async getVideoId(t) {
    return /\/watch\/([^/]+)/.exec(t.pathname)?.[1];
  }
}
class td extends P {
  constructor() {
    super(...arguments);
    c(this, "API_ORIGIN", "https://kick.com/api");
  }
  async getClipInfo(e) {
    try {
      const s = await (await this.fetch(`${this.API_ORIGIN}/v2/clips/${e}`)).json(), { clip_url: o, duration: r, title: a } = s.clip;
      return {
        url: o,
        duration: r,
        title: a
      };
    } catch (i) {
      M.error(`Failed to get kick clip info by clipId: ${e}.`, i.message);
      return;
    }
  }
  async getVideoInfo(e) {
    try {
      const s = await (await this.fetch(`${this.API_ORIGIN}/v1/video/${e}`)).json(), { source: o, livestream: r } = s, { session_title: a, duration: l } = r;
      return {
        url: o,
        duration: Math.round(l / 1e3),
        title: a
      };
    } catch (i) {
      M.error(`Failed to get kick video info by videoId: ${e}.`, i.message);
      return;
    }
  }
  async getVideoData(e) {
    return e.startsWith("videos") ? await this.getVideoInfo(e.replace("videos/", "")) : await this.getClipInfo(e.replace("clips/", ""));
  }
  async getVideoId(e) {
    return /([^/]+)\/((videos|clips)\/([^/]+))/.exec(e.pathname)?.[2];
  }
}
class ed extends P {
  async getVideoData(t) {
    try {
      const e = document.querySelector(".ksr-video-player > video"), i = e?.querySelector("source[type^='video/mp4']")?.src;
      if (!i)
        throw new F("Failed to find video URL");
      const s = e?.querySelectorAll("track") ?? [];
      return {
        url: i,
        subtitles: Array.from(s).reduce((o, r) => {
          const a = r.getAttribute("srclang"), l = r.getAttribute("src");
          return !a || !l || o.push({
            language: tt(a),
            url: l,
            format: "vtt",
            source: "kickstarter"
          }), o;
        }, [])
      };
    } catch (e) {
      M.error(`Failed to get Kickstarter data by videoId: ${t}`, e.message);
      return;
    }
  }
  async getVideoId(t) {
    return t.pathname.slice(1);
  }
}
class nd extends P {
  constructor() {
    super(...arguments);
    c(this, "API_ORIGIN", window.location.origin);
  }
  getSecureData(e) {
    try {
      const [i, s, o] = e.split("/").filter((m) => m), r = Array.from(document.getElementsByTagName("script")), a = r.filter((m) => m.innerHTML.includes(`videoId = "${s}"`) || m.innerHTML.includes(`serialId = Number(${s})`));
      if (!a.length)
        throw new F("Failed to find secure script");
      const l = /'{[^']+}'/.exec(a[0].textContent.trim())?.[0];
      if (!l)
        throw new F("Secure json wasn't found in secure script");
      const u = JSON.parse(l.replaceAll("'", ""));
      if (i !== "serial")
        return {
          videoType: i,
          videoId: s,
          hash: o,
          ...u
        };
      const d = r.find((m) => m.innerHTML.includes("var videoInfo = {}"))?.textContent?.trim();
      if (!d)
        throw new F("Failed to find videoInfo content");
      const h = /videoInfo\.type\s+?=\s+?'([^']+)'/.exec(d)?.[1], f = /videoInfo\.id\s+?=\s+?'([^']+)'/.exec(d)?.[1], g = /videoInfo\.hash\s+?=\s+?'([^']+)'/.exec(d)?.[1];
      if (!h || !f || !g)
        throw new F("Failed to parse videoInfo content");
      return {
        videoType: h,
        videoId: f,
        hash: g,
        ...u
      };
    } catch (i) {
      return M.error(`Failed to get kodik secure data by videoPath: ${e}.`, i.message), !1;
    }
  }
  async getFtor(e) {
    const { videoType: i, videoId: s, hash: o, d: r, d_sign: a, pd: l, pd_sign: u, ref: d, ref_sign: h } = e;
    try {
      return await (await this.fetch(this.API_ORIGIN + "/ftor", {
        method: "POST",
        headers: {
          "User-Agent": Q.userAgent,
          Origin: this.API_ORIGIN,
          Referer: `${this.API_ORIGIN}/${i}/${s}/${o}/360p`
        },
        body: new URLSearchParams({
          d: r,
          d_sign: a,
          pd: l,
          pd_sign: u,
          ref: decodeURIComponent(d),
          ref_sign: h,
          bad_user: "false",
          cdn_is_working: "true",
          info: "{}",
          type: i,
          hash: o,
          id: s
        })
      })).json();
    } catch (f) {
      return M.error(`Failed to get kodik video data (type: ${i}, id: ${s}, hash: ${o})`, f.message), !1;
    }
  }
  decryptUrl(e) {
    return "https:" + atob(e.replace(/[a-zA-Z]/g, function(s) {
      const o = s.charCodeAt(0) + 18, r = s <= "Z" ? 90 : 122;
      return String.fromCharCode(r >= o ? o : o - 26);
    }));
  }
  async getVideoData(e) {
    const i = this.getSecureData(e);
    if (!i)
      return;
    const s = await this.getFtor(i);
    if (!s)
      return;
    const r = Object.entries(s.links[s.default.toString()]).find(([, a]) => a.type === "application/x-mpegURL")?.[1];
    if (r)
      return {
        url: r.src.startsWith("//") ? `https:${r.src}` : this.decryptUrl(r.src)
      };
  }
  async getVideoId(e) {
    return /\/(uv|video|seria|episode|season|serial)\/([^/]+)\/([^/]+)\/([\d]+)p/.exec(e.pathname)?.[0];
  }
}
class id extends oe {
  constructor() {
    super(...arguments);
    c(this, "SUBTITLE_SOURCE", "linkedin");
  }
  async getVideoData(e) {
    const i = this.getVideoDataByPlayer(e);
    if (!i)
      return;
    const { url: s, duration: o, subtitles: r } = i;
    return {
      url: St(new URL(s)),
      duration: o,
      subtitles: r
    };
  }
  async getVideoId(e) {
    return /\/learning\/(([^/]+)\/([^/]+))/.exec(e.pathname)?.[1];
  }
}
var Jo;
(function(n) {
  n.Channel = "Channel", n.Video = "Video";
})(Jo || (Jo = {}));
class sd extends P {
  getClientVersion() {
    if (!(typeof SENTRY_RELEASE > "u"))
      return SENTRY_RELEASE.id;
  }
  async getVideoData(t) {
    try {
      const e = this.getClientVersion();
      if (!e)
        throw new F("Failed to get client version");
      const i = await this.fetch("https://www.loom.com/graphql", {
        headers: {
          "User-Agent": Q.userAgent,
          "content-type": "application/json",
          "x-loom-request-source": `loom_web_${e}`,
          "apollographql-client-name": "web",
          "apollographql-client-version": e,
          "Alt-Used": "www.loom.com"
        },
        body: `{"operationName":"FetchCaptions","variables":{"videoId":"${t}"},"query":"query FetchCaptions($videoId: ID!, $password: String) {\\n  fetchVideoTranscript(videoId: $videoId, password: $password) {\\n    ... on VideoTranscriptDetails {\\n      id\\n      captions_source_url\\n      language\\n      __typename\\n    }\\n    ... on GenericError {\\n      message\\n      __typename\\n    }\\n    __typename\\n  }\\n}"}`,
        method: "POST"
      });
      if (i.status !== 200)
        throw new F("Failed to get data from graphql");
      const o = (await i.json()).data.fetchVideoTranscript;
      if (o.__typename === "GenericError")
        throw new F(o.message);
      return {
        url: this.service.url + t,
        subtitles: [
          {
            format: "vtt",
            language: tt(o.language),
            source: "loom",
            url: o.captions_source_url
          }
        ]
      };
    } catch (e) {
      return M.error(`Failed to get Loom video data, because: ${e.message}`), this.returnBaseData(t);
    }
  }
  async getVideoId(t) {
    return /(embed|share)\/([^/]+)?/.exec(t.pathname)?.[2];
  }
}
class od extends P {
  constructor() {
    super(...arguments);
    c(this, "API_ORIGIN", "https://my.mail.ru");
  }
  async getVideoMeta(e) {
    try {
      return await (await this.fetch(`${this.API_ORIGIN}/+/video/meta/${e}?xemail=&ajax_call=1&func_name=&mna=&mnb=&ext=1&_=${(/* @__PURE__ */ new Date()).getTime()}`)).json();
    } catch (i) {
      M.error("Failed to get mail.ru video data", i.message);
      return;
    }
  }
  async getVideoId(e) {
    const i = e.pathname;
    if (/\/(v|mail|bk|inbox)\//.exec(i))
      return i.slice(1);
    const s = /video\/embed\/([^/]+)/.exec(i)?.[1];
    if (!s)
      return;
    const o = await this.getVideoMeta(s);
    if (o)
      return o.meta.url.replace("//my.mail.ru/", "");
  }
}
class rd extends oe {
  constructor() {
    super(...arguments);
    c(this, "SUBTITLE_SOURCE", "netacad");
  }
  async getVideoData(e) {
    const i = this.getVideoDataByPlayer(e);
    if (!i)
      return;
    const { url: s, duration: o, subtitles: r } = i;
    return {
      url: St(new URL(s)),
      duration: o,
      subtitles: r
    };
  }
  async getVideoId(e) {
    return e.pathname + e.search;
  }
}
class ad extends P {
  async getVideoId(t) {
    return /([^/]+)\/(view)\/([^/]+)/.exec(t.pathname)?.[0];
  }
}
class ld extends P {
  async getVideoData(t) {
    const e = this.returnBaseData(t);
    if (!e)
      return e;
    try {
      if (!this.video)
        throw new Error("Video element not found");
      const i = this.video.querySelector('source[type^="video/mp4"], source[type^="video/webm"]')?.src;
      if (!i || !/^https?:\/\//.test(i))
        throw new Error("Video source not found");
      return {
        ...e,
        translationHelp: [
          {
            target: "video_file_url",
            targetUrl: i
          }
        ]
      };
    } catch {
      return e;
    }
  }
  async getVideoId(t) {
    return /gag\/([^/]+)/.exec(t.pathname)?.[1];
  }
}
class cd extends P {
  constructor() {
    super(...arguments);
    c(this, "API_ORIGIN", "https://odysee.com");
  }
  async getVideoData(e) {
    try {
      const s = await (await this.fetch(`${this.API_ORIGIN}/${e}`)).text(), o = /"contentUrl":(\s)?"([^"]+)"/.exec(s)?.[2];
      if (!o)
        throw new F("Odysee url doesn't parsed");
      return { url: o };
    } catch (i) {
      M.error(`Failed to get odysee video data by video ID: ${e}`, i.message);
      return;
    }
  }
  async getVideoId(e) {
    return e.pathname.slice(1);
  }
}
class ud extends P {
  async getVideoId(t) {
    return /\/video\/(\d+)/.exec(t.pathname)?.[1];
  }
}
class dd extends oe {
  constructor() {
    super(...arguments);
    c(this, "SUBTITLE_SOURCE", "oraclelearn");
  }
  async getVideoData(e) {
    const i = this.getVideoDataByPlayer(e);
    if (!i)
      return;
    const { url: s, duration: o, subtitles: r } = i, a = this.returnBaseData(e), l = St(new URL(s));
    return a ? {
      url: a.url,
      duration: o,
      subtitles: r,
      translationHelp: [
        {
          target: "video_file_url",
          targetUrl: l
        }
      ]
    } : {
      url: l,
      duration: o,
      subtitles: r
    };
  }
  async getVideoId(e) {
    return /\/ou\/course\/(([^/]+)\/(\d+)\/(\d+))/.exec(e.pathname)?.[1];
  }
}
class hd extends P {
  constructor() {
    super(...arguments);
    c(this, "API_ORIGIN", "https://www.patreon.com/api");
  }
  async getPosts(e) {
    try {
      return await (await this.fetch(`${this.API_ORIGIN}/posts/${e}?json-api-use-default-includes=false`)).json();
    } catch (i) {
      return M.error(`Failed to get patreon posts by postId: ${e}.`, i.message), !1;
    }
  }
  async getVideoData(e) {
    const i = await this.getPosts(e);
    if (!i)
      return;
    const s = i.data.attributes.post_file.url;
    if (s)
      return {
        url: s
      };
  }
  async getVideoId(e) {
    const i = /posts\/([^/]+)/.exec(e.pathname)?.[1];
    if (i)
      return i.replace(/[^\d.]/g, "");
  }
}
class fd extends P {
  async getVideoId(t) {
    return /\/w\/([^/]+)/.exec(t.pathname)?.[0];
  }
}
class gd extends P {
  async getVideoId(t) {
    return t.searchParams.get("viewkey") ?? /embed\/([^/]+)/.exec(t.pathname)?.[1];
  }
}
class md extends P {
  async getVideoData(t) {
    try {
      if (typeof flashvars > "u")
        return;
      const { rnd: e, video_url: i, video_title: s } = flashvars;
      if (!i || !e)
        throw new F("Failed to find video source or rnd");
      const o = new URL(i);
      o.searchParams.append("rnd", e), M.log("PornTN get_file link", o.href);
      const r = await this.fetch(o.href, { method: "head" }), a = new URL(r.url);
      return M.log("PornTN cdn link", a.href), {
        url: St(a),
        title: s
      };
    } catch (e) {
      M.error(`Failed to get PornTN data by videoId: ${t}`, e.message);
      return;
    }
  }
  async getVideoId(t) {
    return /\/videos\/(([^/]+)\/([^/]+))/.exec(t.pathname)?.[1];
  }
}
class pd extends P {
  constructor() {
    super(...arguments);
    c(this, "API_ORIGIN", "https://www.reddit.com");
  }
  async getContentUrl(e) {
    return this.service?.additionalData !== "old" ? document.querySelector("shreddit-player-2")?.src : document.querySelector("[data-hls-url]")?.dataset.hlsUrl?.replaceAll("&amp;", "&");
  }
  async getVideoData(e) {
    try {
      const i = await this.getContentUrl(e);
      if (!i)
        throw new F("Failed to find content url");
      return {
        url: decodeURIComponent(i)
      };
    } catch (i) {
      M.error(`Failed to get reddit video data by video ID: ${e}`, i.message);
      return;
    }
  }
  async getVideoId(e) {
    return /\/r\/(([^/]+)\/([^/]+)\/([^/]+)\/([^/]+))/.exec(e.pathname)?.[1];
  }
}
class bd extends P {
  async getVideoData(t) {
    const e = document.querySelector(".jw-video, .media__video_noscript");
    if (!e)
      return;
    let i = e.getAttribute("src");
    if (i)
      return i.endsWith(".MP4") && (i = St(i)), {
        videoId: t,
        url: i
      };
  }
  async getVideoId(t) {
    return t.pathname.slice(1);
  }
}
class yd extends P {
  async getVideoId(t) {
    return t.pathname.slice(1);
  }
}
class vd extends P {
  async getVideoId(t) {
    return /(?:video|embed)\/([^/]+)/.exec(t.pathname)?.[1];
  }
}
class wd extends P {
  constructor() {
    super(...arguments);
    c(this, "API_ORIGIN", "https://learning.sap.com/");
  }
  async requestKaltura(e, i, s) {
    const o = "html5:v3.17.22", r = "3.3.0";
    try {
      return await (await this.fetch(`https://${e}/api_v3/service/multirequest`, {
        method: "POST",
        body: JSON.stringify({
          1: {
            service: "session",
            action: "startWidgetSession",
            widgetId: `_${i}`
          },
          2: {
            service: "baseEntry",
            action: "list",
            ks: "{1:result:ks}",
            filter: { redirectFromEntryId: s },
            responseProfile: {
              type: 1,
              fields: "id,referenceId,name,description,dataUrl,duration,flavorParamsIds,type,dvrStatus,externalSourceType,createdAt,updatedAt,endDate,plays,views,downloadUrl,creatorId"
            }
          },
          3: {
            service: "baseEntry",
            action: "getPlaybackContext",
            entryId: "{2:result:objects:0:id}",
            ks: "{1:result:ks}",
            contextDataParams: {
              objectType: "KalturaContextDataParams",
              flavorTags: "all"
            }
          },
          apiVersion: r,
          format: 1,
          ks: "",
          clientTag: o,
          partnerId: i
        }),
        headers: {
          "Content-Type": "application/json"
        }
      })).json();
    } catch (a) {
      M.error("Failed to request kaltura data", a.message);
      return;
    }
  }
  async getKalturaData(e) {
    try {
      const i = document.querySelector('script[data-nscript="beforeInteractive"]');
      if (!i)
        throw new F("Failed to find script element");
      const s = /https:\/\/([^"]+)\/p\/([^"]+)\/embedPlaykitJs\/uiconf_id\/([^"]+)/.exec(i?.src);
      if (!s)
        throw new F(`Failed to get sap data for videoId: ${e}`);
      const [, o, r] = s;
      let a = document.querySelector("#shadow")?.firstChild?.getAttribute("id");
      if (!a) {
        const l = document.querySelector("#__NEXT_DATA__");
        if (!l)
          throw new F("Failed to find next data element");
        a = /"sourceId":\s?"([^"]+)"/.exec(l.innerText)?.[1];
      }
      if (!o || Number.isNaN(+r) || !a)
        throw new F(`One of the necessary parameters for getting a link to a sap video in wasn't found for ${e}. Params: kalturaDomain = ${o}, partnerId = ${r}, entryId = ${a}`);
      return await this.requestKaltura(o, r, a);
    } catch (i) {
      M.error("Failed to get kaltura data", i.message);
      return;
    }
  }
  async getVideoData(e) {
    const i = await this.getKalturaData(e);
    if (!i)
      return;
    const [, s, o] = i, { duration: r } = s.objects[0], a = o.sources.find((u) => u.format === "url" && u.protocols === "http,https" && u.url.includes(".mp4"))?.url;
    if (!a)
      return;
    const l = o.playbackCaptions.map((u) => ({
      language: tt(u.languageCode),
      source: "sap",
      format: "vtt",
      url: u.webVttUrl,
      isAutoGenerated: u.label.includes("auto-generated")
    }));
    return {
      url: a,
      subtitles: l,
      duration: r
    };
  }
  async getVideoId(e) {
    return /((courses|learning-journeys)\/([^/]+)(\/[^/]+)?)/.exec(e.pathname)?.[1];
  }
}
class $s extends P {
  static getMediaViewer() {
    if (!(typeof appMediaViewer > "u"))
      return appMediaViewer;
  }
  async getVideoId(t) {
    const e = $s.getMediaViewer();
    if (!e || e.live)
      return;
    const i = e.target.message;
    if (i.peer_id._ !== "peerChannel")
      return;
    const s = i.media;
    if (s._ !== "messageMediaDocument" || s.document.type !== "video")
      return;
    const o = i.mid & 4294967295;
    return `${await e.managers.appPeersManager.getPeerUsername(i.peerId)}/${o}`;
  }
}
class Sd extends P {
  async getVideoId(t) {
    return /(videos|embed)\/[^/]+/.exec(t.pathname)?.[0];
  }
}
class Zo extends P {
  async getVideoId(t) {
    return /([^/]+)\/video\/([^/]+)/.exec(t.pathname)?.[0];
  }
}
class Td extends P {
  async getVideoId(t) {
    const e = t.searchParams.get("vid"), i = /([^/]+)\/([\d]+)/.exec(t.pathname)?.[0];
    if (!(!e || !i))
      return `${i}?vid=${e}`;
  }
}
class kd extends P {
  constructor() {
    super(...arguments);
    c(this, "API_ORIGIN", "https://clips.twitch.tv");
  }
  async getClipLink(e, i) {
    const s = document.querySelector("script[type='application/ld+json']"), o = e.slice(1);
    if (s) {
      const d = JSON.parse(s.innerText)["@graph"].find((f) => f["@type"] === "VideoObject")?.creator.url;
      if (!d)
        throw new F("Failed to find channel link");
      return `${d.replace("https://www.twitch.tv/", "")}/clip/${o}`;
    }
    const r = o === "embed", a = document.querySelector(r ? ".tw-link[data-test-selector='stream-info-card-component__stream-avatar-link']" : ".clips-player a:not([class])");
    return a ? `${a.href.replace("https://www.twitch.tv/", "")}/clip/${r ? i : o}` : void 0;
  }
  async getVideoData(e) {
    const i = document.querySelector('[data-a-target="stream-title"], [data-test-selector="stream-info-card-component__subtitle"]')?.innerText, s = !!document.querySelector('[data-a-target="animated-channel-viewers-count"], .channel-status-info--live, .top-bar--pointer-enabled .tw-channel-status-text-indicator');
    return {
      url: this.service.url + e,
      isStream: s,
      title: i
    };
  }
  async getVideoId(e) {
    const i = e.pathname;
    if (/^m\.twitch\.tv$/.test(i))
      return /videos\/([^/]+)/.exec(e.href)?.[0] ?? i.slice(1);
    if (/^player\.twitch\.tv$/.test(e.hostname))
      return `videos/${e.searchParams.get("video")}`;
    const s = /([^/]+)\/(?:clip)\/([^/]+)/.exec(i);
    if (s)
      return s[0];
    if (/^clips\.twitch\.tv$/.test(e.hostname))
      return await this.getClipLink(i, e.searchParams.get("clip"));
    const r = /(?:videos)\/([^/]+)/.exec(i);
    if (r)
      return r[0];
    const a = document.querySelector(".home-offline-hero .tw-link");
    if (a?.href) {
      const l = new URL(a.href);
      return /(?:videos)\/([^/]+)/.exec(l.pathname)?.[0];
    }
    return document.querySelector(".persistent-player") ? i : void 0;
  }
}
class Ld extends P {
  async getVideoId(t) {
    const e = /status\/([^/]+)/.exec(t.pathname)?.[1];
    if (e)
      return e;
    const s = this.video?.closest('[data-testid="tweet"]')?.querySelector('a[role="link"][aria-label]')?.href;
    return s ? /status\/([^/]+)/.exec(s)?.[1] : void 0;
  }
}
class xd extends P {
  constructor() {
    super(...arguments);
    c(this, "API_ORIGIN", "https://www.udemy.com/api-2.0");
  }
  getModuleData() {
    const i = document.querySelector(".ud-app-loader[data-module-id='course-taking']")?.dataset?.moduleArgs;
    if (i)
      return JSON.parse(i);
  }
  getLectureId() {
    return /learn\/lecture\/([^/]+)/.exec(window.location.pathname)?.[1];
  }
  isErrorData(e) {
    return Object.hasOwn(e, "error");
  }
  async getLectureData(e, i) {
    try {
      const o = await (await this.fetch(`${this.API_ORIGIN}/users/me/subscribed-courses/${e}/lectures/${i}/?` + new URLSearchParams({
        "fields[lecture]": "title,description,asset",
        "fields[asset]": "length,media_sources,captions"
      }).toString())).json();
      if (this.isErrorData(o))
        throw new F(o.detail ?? "unknown error");
      return o;
    } catch (s) {
      M.error(`Failed to get lecture data by courseId: ${e} and lectureId: ${i}`, s.message);
      return;
    }
  }
  async getCourseLang(e) {
    try {
      const s = await (await this.fetch(`${this.API_ORIGIN}/users/me/subscribed-courses/${e}?` + new URLSearchParams({
        "fields[course]": "locale"
      }).toString())).json();
      if (this.isErrorData(s))
        throw new F(s.detail ?? "unknown error");
      return s;
    } catch (i) {
      M.error(`Failed to get course lang by courseId: ${e}`, i.message);
      return;
    }
  }
  findVideoUrl(e) {
    return e?.find((i) => i.type === "video/mp4")?.src;
  }
  findSubtitleUrl(e, i) {
    return (e?.find((o) => tt(o.locale_id) === i) ?? e?.find((o) => tt(o.locale_id) === "en") ?? e?.[0])?.url;
  }
  async getVideoData(e) {
    const i = this.getModuleData();
    if (!i)
      return;
    const { courseId: s } = i, o = this.getLectureId();
    if (M.log(`[Udemy] courseId: ${s}, lectureId: ${o}`), !o)
      return;
    const r = await this.getLectureData(s, o);
    if (!r)
      return;
    const { title: a, description: l, asset: u } = r, { length: d, media_sources: h, captions: f } = u, g = this.findVideoUrl(h);
    if (!g) {
      M.log("Failed to find .mp4 video file in media_sources", h);
      return;
    }
    let m = "en";
    const v = await this.getCourseLang(s);
    if (v) {
      const { locale: { locale: S } } = v;
      m = S ? tt(S) : m;
    }
    Pt.includes(m) || (m = "en");
    const T = this.findSubtitleUrl(f, m);
    return T || M.log("Failed to find subtitle file in captions", f), {
      ...T ? {
        url: this.service?.url + e,
        translationHelp: [
          {
            target: "subtitles_file_url",
            targetUrl: T
          },
          {
            target: "video_file_url",
            targetUrl: g
          }
        ],
        detectedLanguage: m
      } : {
        url: g,
        translationHelp: null
      },
      duration: d,
      title: a,
      description: l
    };
  }
  async getVideoId(e) {
    return e.pathname.slice(1);
  }
}
class Ad extends P {
  constructor() {
    super(...arguments);
    c(this, "API_KEY", "");
    c(this, "DEFAULT_SITE_ORIGIN", "https://vimeo.com");
    c(this, "SITE_ORIGIN", this.service?.url?.slice(0, -1) ?? this.DEFAULT_SITE_ORIGIN);
  }
  isErrorData(e) {
    return Object.hasOwn(e, "error");
  }
  isPrivatePlayer() {
    return this.referer && !this.referer.includes("vimeo.com") && this.origin.endsWith("player.vimeo.com");
  }
  async getViewerData() {
    try {
      const i = await (await this.fetch("https://vimeo.com/_next/viewer")).json(), { apiUrl: s, jwt: o } = i;
      return this.API_ORIGIN = `https://${s}`, this.API_KEY = `jwt ${o}`, i;
    } catch (e) {
      return M.error("Failed to get default viewer data.", e.message), !1;
    }
  }
  async getVideoInfo(e) {
    try {
      const i = new URLSearchParams({
        fields: "name,link,description,duration"
      }).toString(), o = await (await this.fetch(`${this.API_ORIGIN}/videos/${e}?${i}`, {
        headers: {
          Authorization: this.API_KEY
        }
      })).json();
      if (this.isErrorData(o))
        throw new Error(o.developer_message ?? o.error);
      return o;
    } catch (i) {
      return M.error(`Failed to get video info by video ID: ${e}`, i.message), !1;
    }
  }
  async getPrivateVideoSource(e) {
    try {
      const { default_cdn: i, cdns: s } = e.dash, o = s[i].url, r = await this.fetch(o);
      if (r.status !== 200)
        throw new F(await r.text());
      const a = await r.json(), l = new URL(a.base_url, o), u = a.audio.find((m) => m.mime_type === "audio/mp4" && m.format === "dash");
      if (!u)
        throw new F("Failed to find video data");
      const d = u.segments?.[0]?.url;
      if (!d)
        throw new F("Failed to find first segment url");
      const [h, f] = d.split("?", 2), g = new URLSearchParams(f);
      return g.delete("range"), new URL(`${u.base_url}${h}?${g.toString()}`, l).href;
    } catch (i) {
      return M.error("Failed to get private video source", i.message), !1;
    }
  }
  async getPrivateVideoInfo(e) {
    try {
      if (typeof playerConfig > "u")
        return;
      const i = await this.getPrivateVideoSource(playerConfig.request.files);
      if (!i)
        throw new F("Failed to get private video source");
      const { video: { title: s, duration: o }, request: { text_tracks: r } } = playerConfig;
      return {
        url: `${this.SITE_ORIGIN}/${e}`,
        video_url: i,
        title: s,
        duration: o,
        subs: r
      };
    } catch (i) {
      return M.error(`Failed to get private video info by video ID: ${e}`, i.message), !1;
    }
  }
  async getSubsInfo(e) {
    try {
      const i = new URLSearchParams({
        per_page: "100",
        fields: "language,type,link"
      }).toString(), o = await (await this.fetch(`${this.API_ORIGIN}/videos/${e}/texttracks?${i}`, {
        headers: {
          Authorization: this.API_KEY
        }
      })).json();
      if (this.isErrorData(o))
        throw new Error(o.developer_message ?? o.error);
      return o.data;
    } catch (i) {
      return M.error(`Failed to get subtitles info by video ID: ${e}`, i.message), [];
    }
  }
  async getVideoData(e) {
    if (this.isPrivatePlayer()) {
      const f = await this.getPrivateVideoInfo(e);
      if (!f)
        return;
      const { url: g, subs: m, video_url: v, title: T, duration: S } = f, w = m.map((I) => ({
        language: tt(I.lang),
        source: "vimeo",
        format: "vtt",
        url: this.SITE_ORIGIN + I.url,
        isAutoGenerated: I.lang.includes("autogenerated")
      })), x = w.length ? [
        { target: "video_file_url", targetUrl: v },
        { target: "subtitles_file_url", targetUrl: w[0].url }
      ] : null;
      return {
        ...x ? {
          url: g,
          translationHelp: x
        } : {
          url: v
        },
        subtitles: w,
        title: T,
        duration: S
      };
    }
    if (!this.extraInfo)
      return this.returnBaseData(e);
    if (e.includes("/") && (e = e.replace("/", ":")), !await this.getViewerData())
      return this.returnBaseData(e);
    const o = await this.getVideoInfo(e);
    if (!o)
      return this.returnBaseData(e);
    const a = (await this.getSubsInfo(e)).map((f) => ({
      language: tt(f.language),
      source: "vimeo",
      format: "vtt",
      url: f.link,
      isAutoGenerated: f.language.includes("autogen")
    })), { link: l, duration: u, name: d, description: h } = o;
    return {
      url: l,
      title: d,
      description: h,
      subtitles: a,
      duration: u
    };
  }
  async getVideoId(e) {
    const i = /video\/[^/]+$/.exec(e.pathname)?.[0];
    if (this.isPrivatePlayer())
      return i;
    if (i) {
      const o = e.searchParams.get("h"), r = i.replace("video/", "");
      return o ? `${r}/${o}` : r;
    }
    const s = /channels\/[^/]+\/([^/]+)/.exec(e.pathname)?.[1] ?? /groups\/[^/]+\/videos\/([^/]+)/.exec(e.pathname)?.[1] ?? /(showcase|album)\/[^/]+\/video\/([^/]+)/.exec(e.pathname)?.[2];
    return s || /([^/]+\/)?[^/]+$/.exec(e.pathname)?.[0];
  }
}
const Ed = (n) => new Promise((t) => setTimeout(t, n));
class Ws extends P {
  static getPlayer() {
    if (!(typeof Videoview > "u"))
      return Videoview?.getPlayerObject?.call(void 0);
  }
  async getVideoData(t) {
    const e = await this.waitForPlayerWithSubs();
    if (!e)
      return this.returnBaseData(t);
    try {
      const { description: i, duration: s, md_title: o } = e.vars, a = new DOMParser().parseFromString(i, "text/html"), l = Array.from(a.body.childNodes).filter((d) => d.nodeName !== "BR").map((d) => d.textContent).join(`
`);
      let u;
      return Object.hasOwn(e.vars, "subs") && (u = e.vars.subs.map((d) => ({
        language: tt(d.lang),
        source: "vk",
        format: "vtt",
        url: d.url,
        isAutoGenerated: !!d.is_auto
      }))), {
        url: this.service.url + t,
        title: o,
        description: l,
        duration: s,
        subtitles: u
      };
    } catch (i) {
      return M.error(`Failed to get VK video data, because: ${i.message}`), this.returnBaseData(t);
    }
  }
  async waitForPlayerWithSubs(t = 3e3) {
    const e = Date.now();
    let i;
    for (; Date.now() - e < t; ) {
      const s = Ws.getPlayer();
      i = s;
      const o = s?.vars?.subs;
      if (Array.isArray(o) && o.length > 0)
        return s;
      await Ed(200);
    }
    return i;
  }
  async getVideoId(t) {
    const e = /^\/(video|clip)-?\d{8,9}_\d{9}$/.exec(t.pathname);
    if (e)
      return e[0].slice(1);
    const i = /\/playlist\/[^/]+\/(video-?\d{8,9}_\d{9})/.exec(t.pathname);
    if (i)
      return i[1];
    const s = t.searchParams.get("z");
    if (s)
      return s.split("/")[0];
    const o = t.searchParams.get("oid"), r = t.searchParams.get("id");
    if (o && r)
      return `video-${Math.abs(parseInt(o))}_${r}`;
  }
}
class Vd extends P {
  async getVideoId(t) {
    return /(video|embed)\/(\d+)(\/[^/]+\/)?/.exec(t.pathname)?.[0];
  }
}
class Cd extends P {
  constructor() {
    super(...arguments);
    c(this, "API_ORIGIN", "https://global.apis.naver.com/weverse/wevweb");
    c(this, "API_APP_ID", "be4d79eb8fc7bd008ee82c8ec4ff6fd4");
    c(this, "API_HMAC_KEY", "1b9cb6378d959b45714bec49971ade22e6e24e42");
    c(this, "HEADERS", {
      Accept: "application/json, text/plain, */*",
      Origin: "https://weverse.io",
      Referer: "https://weverse.io/"
    });
  }
  getURLData() {
    return {
      appId: this.API_APP_ID,
      language: "en",
      os: "WEB",
      platform: "WEB",
      wpf: "pc"
    };
  }
  async createHash(e) {
    const i = Date.now(), s = e.substring(0, Math.min(255, e.length)) + i, o = await vu(this.API_HMAC_KEY, s);
    if (!o)
      throw new F("Failed to get weverse HMAC signature");
    return {
      wmsgpad: i.toString(),
      wmd: o
    };
  }
  async getHashURLParams(e) {
    const i = await this.createHash(e);
    return new URLSearchParams(i).toString();
  }
  async getPostPreview(e) {
    const i = `/post/v1.0/post-${e}/preview?` + new URLSearchParams({
      fieldSet: "postForPreview",
      ...this.getURLData()
    }).toString();
    try {
      const s = await this.getHashURLParams(i);
      return await (await this.fetch(this.API_ORIGIN + i + "&" + s, {
        headers: this.HEADERS
      })).json();
    } catch (s) {
      return M.error(`Failed to get weverse post preview by postId: ${e}`, s.message), !1;
    }
  }
  async getVideoInKey(e) {
    const i = `/video/v1.1/vod/${e}/inKey?` + new URLSearchParams({
      gcc: "RU",
      ...this.getURLData()
    }).toString();
    try {
      const s = await this.getHashURLParams(i);
      return await (await this.fetch(this.API_ORIGIN + i + "&" + s, {
        method: "POST",
        headers: this.HEADERS
      })).json();
    } catch (s) {
      return M.error(`Failed to get weverse InKey by videoId: ${e}`, s.message), !1;
    }
  }
  async getVideoInfo(e, i, s) {
    const o = Date.now();
    try {
      const r = new URLSearchParams({
        key: i,
        sid: s,
        nonce: o.toString(),
        devt: "html5_pc",
        prv: "N",
        aup: "N",
        stpb: "N",
        cpl: "en",
        env: "prod",
        lc: "en",
        adi: JSON.stringify([
          {
            adSystem: null
          }
        ]),
        adu: "/"
      }).toString();
      return await (await this.fetch(`https://global.apis.naver.com/rmcnmv/rmcnmv/vod/play/v2.0/${e}?` + r, {
        headers: this.HEADERS
      })).json();
    } catch (r) {
      return M.error(`Failed to get weverse video info (infraVideoId: ${e}, inkey: ${i}, serviceId: ${s}`, r.message), !1;
    }
  }
  extractVideoInfo(e) {
    return e.find((i) => i.useP2P === !1 && i.source.includes(".mp4"));
  }
  async getVideoData(e) {
    const i = await this.getPostPreview(e);
    if (!i)
      return;
    const { videoId: s, serviceId: o, infraVideoId: r } = i.extension.video;
    if (!(s && o && r))
      return;
    const a = await this.getVideoInKey(s);
    if (!a)
      return;
    const l = await this.getVideoInfo(r, a.inKey, o);
    if (!l)
      return;
    const u = this.extractVideoInfo(l.videos.list);
    if (u)
      return {
        url: u.source,
        duration: u.duration
      };
  }
  async getVideoId(e) {
    return /([^/]+)\/(live|media)\/([^/]+)/.exec(e.pathname)?.[3];
  }
}
class Id extends P {
  async getVideoId(t) {
    return /[^/]+\/[^/]+$/.exec(t.pathname)?.[0];
  }
}
class Pd extends P {
  constructor() {
    super(...arguments);
    c(this, "API_ORIGIN", window.location.origin);
    c(this, "CLIENT_PREFIX", "/client/disk");
    c(this, "INLINE_PREFIX", "/i/");
    c(this, "DISK_PREFIX", "/d/");
  }
  isErrorData(e) {
    return Object.hasOwn(e, "error");
  }
  async getClientVideoData(e) {
    const s = new URL(window.location.href).searchParams.get("idDialog");
    if (!s)
      return;
    const o = document.querySelector("#preloaded-data");
    if (o)
      try {
        const r = JSON.parse(o.innerText), { idClient: a, sk: l } = r.config, d = await (await this.fetch(this.API_ORIGIN + "/models-v2?m=mpfs/info", {
          method: "POST",
          body: JSON.stringify({
            apiMethod: "mpfs/info",
            connection_id: a,
            requestParams: {
              path: s
            },
            sk: l
          }),
          headers: {
            "Content-Type": "application/json"
          }
        })).json();
        if (this.isErrorData(d))
          throw new F(d.error?.message ?? d.error?.code);
        if (d?.type !== "file")
          throw new F("Failed to get resource info");
        const { meta: { short_url: h, video_info: f }, name: g } = d;
        if (!f)
          throw new F("There's no video open right now");
        if (!h)
          throw new F("Access to the video is limited");
        const m = this.clearTitle(g), v = Math.round(f.duration / 1e3);
        return {
          url: h,
          title: m,
          duration: v
        };
      } catch (r) {
        M.error(`Failed to get yandex disk video data by video ID: ${e}, because ${r.message}`);
        return;
      }
  }
  clearTitle(e) {
    return e.replace(/(\.[^.]+)$/, "");
  }
  getBodyHash(e, i) {
    const s = JSON.stringify({
      hash: e,
      sk: i
    });
    return encodeURIComponent(s);
  }
  async fetchList(e, i) {
    const s = this.getBodyHash(e, i), r = await (await this.fetch(this.API_ORIGIN + "/public/api/fetch-list", {
      method: "POST",
      body: s
    })).json();
    if (Object.hasOwn(r, "error"))
      throw new F("Failed to fetch folder list");
    return r.resources;
  }
  async getDownloadUrl(e, i) {
    const s = this.getBodyHash(e, i), r = await (await this.fetch(this.API_ORIGIN + "/public/api/download-url", {
      method: "POST",
      body: s
    })).json();
    if (r.error)
      throw new F("Failed to get download url");
    return r.data.url;
  }
  async getDiskVideoData(e) {
    try {
      const i = document.getElementById("store-prefetch");
      if (!i)
        throw new F("Failed to get prefetch data");
      const s = e.split("/").slice(3);
      if (!s.length)
        throw new F("Failed to find video file path");
      const o = JSON.parse(i.innerText), { resources: r, rootResourceId: a, environment: { sk: l } } = o, u = r[a], d = s.length - 1, h = s.filter((A, $) => $ !== d).join("/");
      let f = Object.values(r);
      h.includes("/") && (f = await this.fetchList(`${u.hash}:/${h}`, l));
      const g = f.find((A) => A.name === s[d]);
      if (!g)
        throw new F("Failed to find resource");
      if (g && g.type === "dir")
        throw new F("Path is dir, but expected file");
      const { meta: { short_url: m, mediatype: v, videoDuration: T }, path: S, name: w } = g;
      if (v !== "video")
        throw new F("Resource isn't a video");
      const x = this.clearTitle(w), I = Math.round(T / 1e3);
      if (m)
        return {
          url: m,
          duration: I,
          title: x
        };
      const k = await this.getDownloadUrl(S, l);
      return {
        url: St(new URL(k)),
        duration: I,
        title: x
      };
    } catch (i) {
      M.error(`Failed to get yandex disk video data by disk video ID: ${e}`, i.message);
      return;
    }
  }
  async getVideoData(e) {
    return e.startsWith(this.INLINE_PREFIX) || /^\/d\/([^/]+)$/.exec(e) ? {
      url: this.service.url + e.slice(1)
    } : (e = decodeURIComponent(e), e.startsWith(this.CLIENT_PREFIX) ? await this.getClientVideoData(e) : await this.getDiskVideoData(e));
  }
  async getVideoId(e) {
    if (e.pathname.startsWith(this.CLIENT_PREFIX))
      return e.pathname + e.search;
    const i = /\/i\/([^/]+)/.exec(e.pathname)?.[0];
    return i || (/\/d\/([^/]+)/.exec(e.pathname) ? e.pathname : void 0);
  }
}
class Md extends P {
  async getVideoId(t) {
    return /v_show\/id_[\w=]+/.exec(t.pathname)?.[0];
  }
}
class N extends P {
  static isMobile() {
    return /^m\.youtube\.com$/.test(window.location.hostname);
  }
  static getPlayer() {
    return window.location.pathname.startsWith("/shorts/") && !N.isMobile() ? document.querySelector("#shorts-player") : document.querySelector("#movie_player");
  }
  static getPlayerResponse() {
    return N.getPlayer()?.getPlayerResponse?.call(void 0);
  }
  static getPlayerData() {
    return N.getPlayer()?.getVideoData?.call(void 0);
  }
  static getVolume() {
    const t = N.getPlayer();
    return t?.getVolume ? t.getVolume() / 100 : 1;
  }
  static setVolume(t) {
    const e = N.getPlayer();
    return e?.setVolume ? (e.setVolume(Math.round(t * 100)), !0) : !1;
  }
  static isMuted() {
    const t = N.getPlayer();
    return t?.isMuted ? t.isMuted() : !1;
  }
  static videoSeek(t, e) {
    M.log("videoSeek", e);
    const s = (N.getPlayer()?.getProgressState()?.seekableEnd ?? t.currentTime) - e;
    t.currentTime = s;
  }
  static getPoToken() {
    const t = N.getPlayer();
    if (!t)
      return;
    const e = t.getAudioTrack?.call(void 0);
    if (!e?.captionTracks?.length)
      return;
    const i = e.captionTracks.find((s) => s.url.includes("&pot="));
    if (i)
      return /&pot=([^&]+)/.exec(i.url)?.[1];
  }
  static getGlobalConfig() {
    return typeof yt < "u" ? yt?.config_ : typeof ytcfg < "u" ? ytcfg?.data_ : void 0;
  }
  static getDeviceParams() {
    const t = N.getGlobalConfig();
    if (!t)
      return "c=WEB";
    const e = t.INNERTUBE_CONTEXT?.client, i = new URLSearchParams(t.DEVICE);
    return i.delete("ceng"), i.delete("cengver"), i.set("c", e?.clientName ?? t.INNERTUBE_CLIENT_NAME), i.set("cver", e?.clientVersion ?? t.INNERTUBE_CLIENT_VERSION), i.set("cplayer", "UNIPLAYER"), i.toString();
  }
  static getSubtitles(t) {
    const i = N.getPlayerResponse()?.captions?.playerCaptionsTracklistRenderer;
    if (!i)
      return [];
    const s = i.captionTracks ?? [], r = (i.translationLanguages ?? []).find((d) => d.languageCode === t), l = s.find((d) => d?.kind === "asr")?.languageCode ?? "en", u = s.reduce((d, h) => {
      if (!("languageCode" in h))
        return d;
      const f = h.languageCode ? tt(h.languageCode) : void 0, g = h.baseUrl;
      if (!f || !g)
        return d;
      const m = `${g.startsWith("http") ? g : `${window.location.origin}/${g}`}&fmt=json3`;
      return d.push({
        source: "youtube",
        format: "json",
        language: f,
        isAutoGenerated: h?.kind === "asr",
        url: m
      }), r && h.isTranslatable && h.languageCode === l && t !== f && d.push({
        source: "youtube",
        format: "json",
        language: t,
        isAutoGenerated: h?.kind === "asr",
        translatedFromLanguage: f,
        url: `${m}&tlang=${t}`
      }), d;
    }, []);
    return M.log("youtube subtitles:", u), u;
  }
  static getLanguage() {
    if (!N.isMobile()) {
      const s = N.getPlayer()?.getAudioTrack?.call(void 0)?.getLanguageInfo();
      if (s && s.id !== "und")
        return tt(s.id.split(".")[0]);
    }
    const e = N.getPlayerResponse()?.captions?.playerCaptionsTracklistRenderer.captionTracks.find((i) => i.kind === "asr" && i.languageCode);
    return e ? tt(e.languageCode) : void 0;
  }
  async getVideoData(t) {
    const { title: e } = N.getPlayerData() ?? {}, { shortDescription: i, isLive: s, title: o } = N.getPlayerResponse()?.videoDetails ?? {}, r = N.getSubtitles(this.language);
    let a = N.getLanguage();
    a && !Pt.includes(a) && (a = void 0);
    const l = N.getPlayer()?.getDuration?.call(void 0) ?? void 0;
    return {
      url: this.service.url + t,
      isStream: s,
      title: o,
      localizedTitle: e,
      detectedLanguage: a,
      description: i,
      subtitles: r,
      duration: l
    };
  }
  async getVideoId(t) {
    if (t.hostname === "youtu.be" && (t.search = `?v=${t.pathname.replace("/", "")}`, t.pathname = "/watch"), t.searchParams.has("enablejsapi")) {
      const e = N.getPlayer()?.getVideoUrl();
      t = e ? new URL(e) : t;
    }
    return /(?:watch|embed|shorts|live)\/([^/]+)/.exec(t.pathname)?.[1] ?? t.searchParams.get("v");
  }
}
const yl = {
  [y.mailru]: od,
  [y.weverse]: Cd,
  [y.kodik]: nd,
  [y.patreon]: hd,
  [y.reddit]: pd,
  [y.bannedvideo]: Ru,
  [y.kick]: td,
  [y.appledeveloper]: Ou,
  [y.epicgames]: Ku,
  [y.odysee]: cd,
  [y.coursehunterLike]: $u,
  [y.twitch]: kd,
  [y.sap]: wd,
  [y.linkedin]: id,
  [y.vimeo]: Ad,
  [y.yandexdisk]: Pd,
  [y.vk]: Ws,
  [y.trovo]: Td,
  [y.incestflix]: Qu,
  [y.porntn]: md,
  [y.googledrive]: Xu,
  [y.bilibili]: Bu,
  [y.xvideos]: Id,
  [y.watchpornto]: Vd,
  [y.archive]: Du,
  [y.dailymotion]: Wu,
  [y.youku]: Md,
  [y.egghead]: Gu,
  [y.newgrounds]: ad,
  [y.okru]: ud,
  [y.peertube]: fd,
  [y.eporner]: Yu,
  [y.bitchute]: Fu,
  [y.rutube]: vd,
  [y.facebook]: ju,
  [y.rumble]: yd,
  [y.twitter]: Ld,
  [y.pornhub]: gd,
  [y.tiktok]: Zo,
  [y.proxitok]: Zo,
  [y.nine_gag]: ld,
  [y.youtube]: N,
  [y.ricktube]: N,
  [y.invidious]: N,
  [y.poketube]: N,
  [y.piped]: N,
  [y.dzen]: qu,
  [y.cloudflarestream]: Hu,
  [y.loom]: sd,
  [y.rtnews]: bd,
  [y.bitview]: Nu,
  [y.thisvid]: Sd,
  [y.ign]: Ju,
  [y.bunkr]: Uu,
  [y.imdb]: Zu,
  [y.telegram]: $s,
  [K.udemy]: xd,
  [K.coursera]: Hs,
  [K.douyin]: Zn,
  [K.artstation]: _u,
  [K.kickstarter]: ed,
  [K.oraclelearn]: dd,
  [K.deeplearningai]: zu,
  [K.netacad]: rd
};
class vl {
  constructor(t = {}) {
    c(this, "helpersData");
    this.helpersData = t;
  }
  getHelper(t) {
    return new yl[t](this.helpersData);
  }
}
function Od() {
  if (Lu.exec(window.location.href))
    return [];
  const n = window.location.hostname, t = new URL(window.location.href), e = (i) => i instanceof RegExp ? i.test(n) : typeof i == "string" ? n.includes(i) : typeof i == "function" ? i(t) : !1;
  return Mu.filter((i) => (Array.isArray(i.match) ? i.match.some(e) : e(i.match)) && i.host && i.url);
}
async function wl(n, t = {}) {
  const e = new URL(window.location.href), i = n.host;
  return Object.keys(yl).includes(i) ? await new vl(t).getHelper(i).getVideoId(e) : i === y.custom ? e.href : void 0;
}
async function Dd(n, t = {}) {
  const e = await wl(n, t);
  if (!e)
    throw new Jn(`Entered unsupported link: "${n.host}"`);
  const i = window.location.origin;
  if ([
    y.peertube,
    y.coursehunterLike,
    y.cloudflarestream
  ].includes(n.host) && (n.url = i), n.rawResult)
    return {
      url: e,
      videoId: e,
      host: n.host,
      duration: void 0
    };
  if (!n.needExtraData)
    return {
      url: n.url + e,
      videoId: e,
      host: n.host,
      duration: void 0
    };
  const o = await new vl({
    ...t,
    service: n,
    origin: i
  }).getHelper(n.host).getVideoData(e);
  if (!o)
    throw new Jn(`Failed to get video raw url for ${n.host}`);
  return {
    ...o,
    videoId: e,
    host: n.host
  };
}
const Ze = {
  version: "1.0.6",
  debug: !1,
  fetchFn: fetch.bind(window)
}, et = {
  log: (...n) => {
    if (Ze.debug)
      return console.log(`%c✦ chaimu.js v${Ze.version} ✦`, "background: #000; color: #fff; padding: 0 8px", ...n);
  }
}, Qo = [
  "playing",
  "ratechange",
  "play",
  "waiting",
  "pause",
  "seeked"
];
function zs() {
  const n = window.AudioContext || window.webkitAudioContext;
  return n ? new n() : void 0;
}
class qs {
  constructor(t, e) {
    c(this, "chaimu");
    c(this, "fetch");
    c(this, "_src");
    c(this, "fetchOpts");
    c(this, "handleVideoEvent", (t) => (et.log(`handle video ${t.type}`), this.lipSync(t.type), this));
    this.chaimu = t, this._src = e, this.fetch = this.chaimu.fetchFn, this.fetchOpts = this.chaimu.fetchOpts;
  }
  async init() {
    return this;
  }
  async clear() {
    return this;
  }
  lipSync(t = !1) {
    return this;
  }
  removeVideoEvents() {
    for (const t of Qo)
      this.chaimu.video?.removeEventListener(t, this.handleVideoEvent);
    return this;
  }
  addVideoEvents() {
    for (const t of Qo)
      this.chaimu.video?.addEventListener(t, this.handleVideoEvent);
    return this;
  }
  async play() {
    return this;
  }
  async pause() {
    return this;
  }
  get name() {
    return this.constructor.name;
  }
  set src(t) {
    this._src = t;
  }
  get src() {
    return this._src;
  }
  get currentSrc() {
    return this._src;
  }
  set volume(t) {
  }
  get volume() {
    return 0;
  }
  get playbackRate() {
    return 0;
  }
  set playbackRate(t) {
  }
  get currentTime() {
    return 0;
  }
}
c(qs, "name", "BasePlayer");
class Sl extends qs {
  constructor(e, i) {
    super(e, i);
    c(this, "audio");
    c(this, "gainNode");
    c(this, "audioSource");
    c(this, "audioErrorHandle", (e) => {
      console.error("[AudioPlayer]", e);
    });
    this.updateAudio();
  }
  initAudioBooster() {
    return this.chaimu.audioContext ? (this.disconnectAudioNodes(), this.gainNode = this.chaimu.audioContext.createGain(), this.gainNode.connect(this.chaimu.audioContext.destination), this.audioSource = this.chaimu.audioContext.createMediaElementSource(this.audio), this.audioSource.connect(this.gainNode), this) : this;
  }
  disconnectAudioNodes() {
    this.audioSource && (this.audioSource.disconnect(), this.audioSource = void 0), this.gainNode && (this.gainNode.disconnect(), this.gainNode = void 0);
  }
  updateAudio() {
    return this.audio = new Audio(this.src), this.audio.crossOrigin = "anonymous", this;
  }
  async init() {
    return this.updateAudio(), this.initAudioBooster(), this;
  }
  lipSync(e = !1) {
    if (et.log("[AudioPlayer] lipsync video", this.chaimu.video), !this.chaimu.video)
      return this;
    if (this.audio.currentTime = this.chaimu.video.currentTime, this.audio.playbackRate = this.chaimu.video.playbackRate, !e)
      return et.log("[AudioPlayer] lipsync mode isn't set"), this;
    switch (et.log(`[AudioPlayer] lipsync mode is ${e}`), e) {
      case "play":
      case "playing":
      case "seeked":
        return this.chaimu.video.paused || this.syncPlay(), this;
      case "pause":
      case "waiting":
        return this.pause(), this;
      default:
        return this;
    }
  }
  async clear() {
    return this.audio.pause(), this.audio.src = "", this.audio.removeAttribute("src"), this.disconnectAudioNodes(), this;
  }
  syncPlay() {
    return et.log("[AudioPlayer] sync play called"), this.audio && this.audio.play().catch(this.audioErrorHandle), this;
  }
  async play() {
    return et.log("[AudioPlayer] play called"), this.audio && await this.audio.play().catch(this.audioErrorHandle), this;
  }
  async pause() {
    return et.log("[AudioPlayer] pause called"), this.audio && this.audio.pause(), this;
  }
  set src(e) {
    if (this._src = e, !e) {
      this.clear();
      return;
    }
    this.audio.src = e;
  }
  get src() {
    return this._src;
  }
  get currentSrc() {
    return this.audio.currentSrc;
  }
  set volume(e) {
    if (this.gainNode) {
      this.gainNode.gain.value = e;
      return;
    }
    this.audio.volume = e;
  }
  get volume() {
    return this.gainNode ? this.gainNode.gain.value : this.audio.volume;
  }
  get playbackRate() {
    return this.audio.playbackRate;
  }
  set playbackRate(e) {
    this.audio.playbackRate = e;
  }
  get currentTime() {
    return this.audio.currentTime;
  }
}
c(Sl, "name", "AudioPlayer");
class Tl extends qs {
  constructor() {
    super(...arguments);
    c(this, "audioBuffer");
    c(this, "audioElement");
    c(this, "mediaElementSource");
    c(this, "gainNode");
    c(this, "blobUrl");
    c(this, "isClearing", !1);
    c(this, "isInitializing", !1);
    c(this, "clearingPromise");
  }
  async fetchAudio() {
    if (!this._src)
      throw new Error("No audio source provided");
    if (!this.chaimu.audioContext)
      throw new Error("No audio context available");
    et.log(`[ChaimuPlayer] Fetching audio from ${this._src}...`);
    let e;
    try {
      const i = await this.fetch(this._src, this.fetchOpts);
      et.log("[ChaimuPlayer] Decoding fetched audio...");
      const s = await i.arrayBuffer(), o = new Blob([s]);
      e = URL.createObjectURL(o), this.audioBuffer = await this.chaimu.audioContext.decodeAudioData(s), this.blobUrl && URL.revokeObjectURL(this.blobUrl), this.blobUrl = e, e = void 0;
    } catch (i) {
      throw e && URL.revokeObjectURL(e), new Error(`Failed to fetch audio file, because ${i.message}`);
    }
    return this;
  }
  initAudioBooster() {
    return this.chaimu.audioContext ? (this.disconnectAudioNodes(), this.gainNode = this.chaimu.audioContext.createGain(), this) : this;
  }
  disconnectAudioNodes() {
    this.mediaElementSource && (this.mediaElementSource.disconnect(), this.mediaElementSource = void 0), this.gainNode && (this.gainNode.disconnect(), this.gainNode = void 0);
  }
  async init() {
    if (this.isInitializing)
      throw new Error("Initialization already in progress");
    this.isInitializing = !0;
    try {
      return await this.fetchAudio(), this.initAudioBooster(), this.createAudioElement(), this;
    } finally {
      this.isInitializing = !1;
    }
  }
  createAudioElement() {
    if (!this.chaimu.audioContext)
      throw new Error("No audio context available");
    if (!this.blobUrl)
      throw new Error("No blob URL available.");
    const e = new Audio(this.blobUrl);
    e.crossOrigin = "anonymous", "preservesPitch" in e && (e.preservesPitch = !0, "mozPreservesPitch" in e && (e.mozPreservesPitch = !0), "webkitPreservesPitch" in e && (e.webkitPreservesPitch = !0)), this.audioElement = e, this.mediaElementSource = this.chaimu.audioContext.createMediaElementSource(e), this.mediaElementSource.connect(this.gainNode), this.gainNode.connect(this.chaimu.audioContext.destination);
  }
  lipSync(e = !1) {
    if (et.log("[ChaimuPlayer] lipsync video", this.chaimu.video, this), !this.chaimu.video)
      return this;
    if (!e)
      return et.log("[ChaimuPlayer] lipsync mode isn't set"), this;
    switch (et.log(`[ChaimuPlayer] lipsync mode is ${e}`), e) {
      case "play":
      case "playing":
      case "ratechange":
      case "seeked":
        return this.chaimu.video.paused || this.start(), this;
      case "pause":
      case "waiting":
        return this.pause(), this;
      default:
        return this;
    }
  }
  async reopenCtx() {
    if (!this.chaimu.audioContext)
      throw new Error("No audio context available");
    try {
      this.chaimu.audioContext.state !== "closed" && await this.chaimu.audioContext.close();
    } catch (e) {
      et.log("[ChaimuPlayer] Failed to close audio context:", e);
    }
    return this.chaimu.audioContext = zs(), this;
  }
  async clear() {
    if (this.isClearing && this.clearingPromise)
      return this.clearingPromise;
    if (!this.chaimu.audioContext)
      throw new Error("No audio context available");
    return et.log("clear audio context"), this.isClearing = !0, this.clearingPromise = (async () => {
      try {
        await this.pause(), this.audioElement && (this.audioElement.pause(), this.audioElement = void 0), this.blobUrl && (URL.revokeObjectURL(this.blobUrl), this.blobUrl = void 0), this.disconnectAudioNodes();
        const e = this.gainNode ? this.gainNode.gain.value : 1;
        return await this.reopenCtx(), this.chaimu.audioContext && (this.initAudioBooster(), this.volume = e), this;
      } finally {
        this.isClearing = !1, this.clearingPromise = void 0;
      }
    })(), this.clearingPromise;
  }
  async start() {
    if (!this.chaimu.audioContext)
      throw new Error("No audio context available");
    if (!this.audioElement)
      throw new Error("Audio element is missing");
    return this.isClearing && this.clearingPromise && (et.log("The other cleaner is still running, waiting..."), await this.clearingPromise), et.log("starting audio via HTMLAudioElement"), await this.play(), this.chaimu.video && (this.audioElement.currentTime = this.chaimu.video.currentTime, this.audioElement.playbackRate = this.chaimu.video.playbackRate), this.audioElement.play().catch((e) => et.log("[ChaimuPlayer] Play audioElement failed:", e)), this;
  }
  async pause() {
    if (!this.chaimu.audioContext)
      throw new Error("No audio context available");
    return this.audioElement && this.audioElement.pause(), this.chaimu.audioContext.state === "running" && await this.chaimu.audioContext.suspend(), this;
  }
  async play() {
    if (!this.chaimu.audioContext)
      throw new Error("No audio context available");
    return await this.chaimu.audioContext.resume(), this;
  }
  set src(e) {
    this._src = e;
  }
  get src() {
    return this._src;
  }
  get currentSrc() {
    return this._src;
  }
  set volume(e) {
    this.gainNode && (this.gainNode.gain.value = e);
  }
  get volume() {
    return this.gainNode ? this.gainNode.gain.value : 0;
  }
  set playbackRate(e) {
    this.audioElement && (this.audioElement.playbackRate = e);
  }
  get playbackRate() {
    return this.audioElement ? this.audioElement.playbackRate : this.chaimu.video?.playbackRate ?? 1;
  }
  get currentTime() {
    return this.chaimu.video?.currentTime ?? 0;
  }
}
c(Tl, "name", "ChaimuPlayer");
const _d = "__VOT_MAIN_BOOT_STATE__";
function Rd(n) {
  return n === "idle" || n === "booting" || n === "booted" || n === "failed";
}
function Bd(n) {
  return !n || typeof n != "object" ? !1 : Rd(n.status);
}
function Fd(n = _d) {
  const t = globalThis, e = t[n];
  if (Bd(e))
    return e;
  const i = {
    status: "idle",
    promise: null,
    error: null
  };
  return t[n] = i, i;
}
function Nd(n) {
  return n instanceof HTMLVideoElement ? n : null;
}
function tr(n, t) {
  for (const e of t)
    try {
      const i = Nd(n.querySelector(e));
      if (i)
        return i;
    } catch {
    }
  return null;
}
function er(n, t) {
  if (typeof n.querySelector != "function")
    return !1;
  try {
    return !!n.querySelector(t);
  } catch {
    return !1;
  }
}
function nr(n, t) {
  if (n.nodeType !== Node.ELEMENT_NODE && n.nodeType !== Node.DOCUMENT_FRAGMENT_NODE && n.nodeType !== Node.DOCUMENT_NODE)
    return !1;
  const e = n;
  for (const i of t) {
    if (n instanceof Element)
      try {
        if (n.matches(i))
          return !0;
      } catch {
      }
    if (er(e, i) || n instanceof Element && n.shadowRoot && er(n.shadowRoot, i))
      return !0;
  }
  return !1;
}
function Ud(n) {
  let t = !0, e = null, i = null, s = null, o = null;
  const r = n.selectors?.filter((S) => String(S || "").trim()) ?? [], a = r.length > 0 ? r : ["video"], l = n.strategy ?? "mutation", u = Math.max(25, Math.trunc(n.pollIntervalMs ?? 75)), d = Math.max(250, Math.trunc(n.pollTimeoutMs ?? 4e3)), h = Date.now() + d, f = () => {
    t && (t = !1, i?.disconnect(), i = null, e = null, o !== null && (clearTimeout(o), o = null), s && (document.removeEventListener("readystatechange", s), s = null));
  }, g = (S, w) => {
    t && (f(), n.onVideoDetected(S, w));
  }, m = () => {
    const S = tr(document, a);
    return S ? (g("probe-existing-video", S), !0) : nr(document, a) ? (g("probe-existing-video"), !0) : !1;
  }, v = () => {
    t && (m() || Date.now() >= h || (o = globalThis.setTimeout(v, u)));
  }, T = () => {
    if (!t || i)
      return;
    i = new MutationObserver((w) => {
      for (const x of w)
        if (x.type === "childList")
          for (const I of x.addedNodes) {
            if (I instanceof HTMLVideoElement) {
              g("probe-video-added", I);
              return;
            }
            if (I instanceof Document || I instanceof DocumentFragment || I instanceof Element) {
              const k = tr(I, a);
              if (k) {
                g("probe-video-added", k);
                return;
              }
            }
            if (nr(I, a)) {
              g("probe-video-added");
              return;
            }
          }
    });
    const S = document.documentElement;
    if (!S) {
      s = () => {
        if (!t || e)
          return;
        const w = document.documentElement;
        if (w) {
          if (document.removeEventListener("readystatechange", s), s = null, e = w, l === "mutation") {
            i?.observe(w, { childList: !0, subtree: !0 }), m();
            return;
          }
          v();
        }
      }, document.addEventListener("readystatechange", s);
      return;
    }
    if (e = S, l === "mutation") {
      i.observe(S, { childList: !0, subtree: !0 });
      return;
    }
    v();
  };
  return m() || T(), f;
}
function Hd() {
  let n = null, t = null;
  const e = 3e3, i = () => {
    t !== null && (window.clearTimeout(t), t = null);
  }, s = () => {
    const a = document.querySelector(".vot-segmented-button");
    a && (a.hidden = !1, a.removeAttribute("hidden"), a.style.opacity = "1", a.classList.remove("vot-segmented-button--hidden"), i(), t = window.setTimeout(() => {
      const l = document.querySelector(".vot-segmented-button");
      l && (l.style.opacity = "0", l.classList.add("vot-segmented-button--hidden"));
    }, e));
  }, o = () => {
    const a = document.querySelector("video");
    if (!a) return;
    const l = a.closest('[class*="player"], [class*="video"], main, article') || a.parentElement || a;
    if (!l || l === n) return;
    n = l;
    const u = () => s();
    l.addEventListener("mouseenter", u, { passive: !0 }), l.addEventListener("mousemove", u, { passive: !0 }), l.addEventListener("pointerenter", u, { passive: !0 }), l.addEventListener("pointermove", u, { passive: !0 }), s();
  };
  o(), new MutationObserver(() => {
    o();
  }).observe(document.documentElement, {
    childList: !0,
    subtree: !0
  });
}
function $d() {
  return /(?:^|\.)vkvideo\.ru$|(?:^|\.)vk\.(?:com|ru)$/i.test(
    String(globalThis.location?.hostname || "")
  );
}
let ir = !1;
function kl() {
  const n = [document], t = /* @__PURE__ */ new Set([document]), e = [document];
  for (; e.length > 0; ) {
    const i = e.shift();
    if (!i)
      continue;
    const s = i instanceof Document || i instanceof ShadowRoot ? i.querySelectorAll("*") : [];
    for (const o of s) {
      const r = o.shadowRoot;
      !r || t.has(r) || (t.add(r), n.push(r), e.push(r));
    }
  }
  return n;
}
function _i(n) {
  const t = [], e = /* @__PURE__ */ new Set();
  for (const i of kl())
    for (const s of Array.from(i.querySelectorAll(n)))
      e.has(s) || (e.add(s), t.push(s));
  return t;
}
function sr() {
  const n = _i(
    "vot-block.vot-segmented-button, .vot-segmented-button"
  );
  for (const s of n)
    s.hidden = !1, s.removeAttribute("hidden"), s.removeAttribute("inert"), s.classList.remove("vot-segmented-button--hidden"), s.style.setProperty("display", "flex", "important"), s.style.setProperty("opacity", "1", "important"), s.style.setProperty("pointer-events", "auto", "important"), s.style.setProperty("z-index", "2147483647", "important"), s.style.setProperty("visibility", "visible", "important");
  const t = _i(
    ".vot-subtitles-widget, .vot-subtitles-layer"
  );
  for (const s of t)
    s.hidden = !1, s.removeAttribute("hidden"), s.style.setProperty("display", "block", "important"), s.style.setProperty("opacity", "1", "important"), s.style.setProperty("pointer-events", "none", "important"), s.style.setProperty("z-index", "2147483647", "important"), s.style.setProperty("visibility", "visible", "important");
  const e = _i("video"), i = {
    buttons: n.length,
    subtitlesWidgets: t.length,
    videos: e.length,
    visibleVideos: e.filter((s) => {
      const o = s.getBoundingClientRect();
      return o.width > 64 && o.height > 64;
    }).length,
    href: globalThis.location.href
  };
  return globalThis.__VOT_VK_PROBE__ = i, n.length + t.length;
}
function or() {
  for (const n of kl()) {
    const t = n instanceof Document ? n.head || n.documentElement : n instanceof ShadowRoot ? n : null;
    if (!t)
      continue;
    const e = n instanceof Document || n instanceof ShadowRoot ? n : null;
    if (e && !e.querySelector("#vot-vk-overlay-fix-style"))
      try {
        const i = document.createElement("style");
        i.id = "vot-vk-overlay-fix-style", i.textContent = `
        .vot-segmented-button {
          display: flex !important;
          opacity: 1 !important;
          pointer-events: auto !important;
          z-index: 2147483647 !important;
          visibility: visible !important;
        }

        .vot-segmented-button.vot-segmented-button--hidden {
          opacity: 1 !important;
          pointer-events: auto !important;
        }

        .vot-subtitles-layer,
        .vot-subtitles-widget {
          display: block !important;
          opacity: 1 !important;
          z-index: 2147483647 !important;
          visibility: visible !important;
        }
      `, t.appendChild(i);
      } catch {
      }
  }
}
function Wd() {
  if ($d() && (or(), !ir)) {
    ir = !0;
    try {
      const n = (r) => {
        console.log(
          r,
          globalThis.__VOT_VK_PROBE__
        );
      };
      let t = "";
      const e = sr();
      console.log(
        e > 0 ? "[VOT][VK probe] overlay nodes detected" : "[VOT][VK probe] no VOT overlay nodes yet",
        globalThis.__VOT_VK_PROBE__
      );
      const i = () => {
        or();
        const r = sr(), a = globalThis.__VOT_VK_PROBE__, l = JSON.stringify(a);
        r > 0 && l !== t && (t = l, n("[VOT][VK probe] standard overlay refresh"));
      };
      let s = 0;
      const o = globalThis.setInterval(() => {
        s += 1, i(), s >= 160 && globalThis.clearInterval(o);
      }, 500);
      document.addEventListener(
        "visibilitychange",
        () => {
          document.hidden || i();
        },
        { passive: !0 }
      );
    } catch (n) {
      console.warn("[VOT][VK probe] failed", n);
    }
  }
}
const zd = "api.browser.yandex.ru", qd = "media-proxy.toil.cc/v1/proxy/m3u8", rn = "vot-worker.kload.workers.dev", Gd = "https://vot.toil.cc/v1", Kd = "https://translate-backend.transly.workers.dev/v2", Yd = "https://rust-server-531j.onrender.com/detect", Ll = "b4dd2893e5ec40bf835cc0615b2992e3", yn = "https://oauth.yandex.ru", Gs = "/verification_code", xl = `${yn}${Gs}`, rr = "https://avatars.mds.yandex.net/get-yapic", Al = "Acobat12/voice-over-translation-direct", ar = `https://raw.githubusercontent.com/${Al}`, jd = `https://github.com/${Al}`, pi = 15, El = 900, Xd = 5, bi = "yandexbrowser", Ks = "yandexbrowser", Vl = ["UA", "LV", "LT"], Ys = 1e3, an = "2025-05-09", Jd = [
  "autoTranslate",
  "autoSubtitles",
  "dontTranslateLanguages",
  "enabledDontTranslateLanguages",
  "enabledAutoVolume",
  "enabledSmartDucking",
  "autoVolume",
  "buttonPos",
  "showVideoSlider",
  "syncVolume",
  "downloadWithName",
  "sendNotifyOnComplete",
  "subtitlesMaxLength",
  "subtitlesSmartLayout",
  "highlightWords",
  "subtitlesFontSize",
  "subtitlesFontFamily",
  "subtitlesOpacity",
  "subtitlesDownloadFormat",
  "responseLanguage",
  "defaultVolume",
  "onlyBypassMediaCSP",
  "newAudioPlayer",
  "showPiPButton",
  "translateAPIErrors",
  "translationService",
  "detectService",
  "translationHotkey",
  "subtitlesHotkey",
  "m3u8ProxyHost",
  "proxyWorkerHost",
  "translateProxyEnabled",
  "translateProxyEnabledDefault",
  "audioBooster",
  "useLivelyVoice",
  "autoHideButtonDelay",
  "useAudioDownload",
  "compatVersion",
  "localePhrases",
  "localeLang",
  "localeHash",
  "localeVersion",
  "localeUpdatedAt",
  "localeLangOverride",
  "account"
], js = () => {
}, Zd = js, Qd = js, th = js, V = { log: Zd, warn: Qd, error: th };
function eh() {
  return navigator.language?.substring(0, 2).toLowerCase() || "en";
}
const nh = /* @__PURE__ */ new Set([
  "uk",
  "be",
  "bg",
  "mk",
  "sr",
  "bs",
  "hr",
  "sl",
  "pl",
  "sk",
  "cs"
]);
function ih(n) {
  return mi.includes(n) ? n : nh.has(n) ? "ru" : "en";
}
const Xs = eh(), Wn = ih(Xs), lr = 3e4, sh = /[\\/:*?"'<>|]+/g, oh = /^https?:\/\//i, rh = /-{2,}/g, ah = /^[.\s-]+|[.\s-]+$/g;
function cr() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
function lh(n) {
  let t = "";
  for (let e = 0; e < n.length; e++) {
    const i = n.codePointAt(e) ?? 0;
    i >= 32 && i !== 127 && (t += n[e]);
  }
  return t;
}
function ch(n) {
  const t = /* @__PURE__ */ new WeakSet();
  return JSON.stringify(n, (e, i) => {
    if (i && typeof i == "object") {
      if (t.has(i))
        return "[Circular]";
      if (t.add(i), Array.isArray(i))
        return i;
      const s = {}, o = Object.keys(i).sort(
        (r, a) => r.localeCompare(a)
      );
      for (const r of o)
        s[r] = i[r];
      return s;
    }
    return i;
  });
}
function ds(n) {
  let t = 2166136261, e = 0;
  for (; e < n.length; ) {
    const i = n.codePointAt(e) ?? 0;
    t ^= i, t = Math.imul(t, 16777619), e += i > 65535 ? 2 : 1;
  }
  return (t >>> 0).toString(36);
}
const Cl = () => !!document.pictureInPictureEnabled;
async function uh(n, t) {
  try {
    const e = await n.createWritable();
    return await e.write(t), await e.close(), !0;
  } catch {
    return !1;
  }
}
async function dh(n, t) {
  const e = typeof navigator > "u" ? void 0 : navigator;
  if (!e?.share || typeof File > "u")
    return "unsupported";
  let i;
  try {
    i = new File([n], t, {
      type: n.type || "application/octet-stream"
    });
  } catch {
    return "unsupported";
  }
  if (typeof e.canShare == "function" && !e.canShare({ files: [i] }))
    return "unsupported";
  try {
    return await e.share({ files: [i], title: t }), "shared";
  } catch (s) {
    return s instanceof DOMException && s.name === "AbortError" ? "shared" : "error";
  }
}
function hh(n, t) {
  const e = URL.createObjectURL(n), i = document.createElement("a");
  i.href = e, i.download = t, i.rel = "noopener noreferrer", i.target = "_blank", i.style.position = "fixed", i.style.left = "-9999px", i.style.top = "0", (document.body ?? document.documentElement).append(i);
  try {
    return i.click(), !0;
  } catch {
    return !1;
  } finally {
    i.remove(), fh(e);
  }
}
async function Il(n, t, e = {}) {
  return e.fileHandle && await uh(e.fileHandle, n) || e.preferShare && await dh(n, t) === "shared" ? !0 : hh(n, t);
}
function fh(n, t = lr) {
  const e = Number.isFinite(t) && t >= 0 ? t : lr;
  globalThis.setTimeout(() => URL.revokeObjectURL(n), e);
}
function ur(n) {
  const t = n.trim();
  return t && lh(t).replace(oh, "").replaceAll(sh, "-").replaceAll(rh, "-").replaceAll(ah, "") || cr();
}
const dr = () => Math.floor(Date.now() / 1e3), gh = (n) => n ? Object.fromEntries(new Headers(n).entries()) : {};
function W(n, t = 0, e = 100) {
  const i = Math.min(t, e), s = Math.max(t, e);
  return Math.min(Math.max(n, i), s);
}
function Pl(n) {
  const t = {}, e = Object.entries(n);
  for (; e.length; ) {
    const i = e.pop();
    if (!i) continue;
    const [s, o] = i;
    if (o === void 0) continue;
    if (!(o !== null && typeof o == "object" && !Array.isArray(o))) {
      t[s] = o;
      continue;
    }
    for (const [a, l] of Object.entries(o))
      e.push([`${s}.${a}`, l]);
  }
  return t;
}
const Ml = 7200 * 1e3, hr = "x-vot-cache-created-at", Fe = "x-vot-cache-key", mh = "vot-http-cache-v1", ph = 500, bh = "VOTSession", Ri = {
  translation: "translationExpiresAt",
  subtitles: "subtitlesExpiresAt"
};
function yh() {
  return Math.floor(Date.now() / 1e3);
}
function vh(n) {
  if (!n || typeof n != "object")
    return !1;
  const t = n;
  return typeof t.expires == "number" && Number.isFinite(t.expires) && typeof t.timestamp == "number" && Number.isFinite(t.timestamp) && typeof t.uuid == "string" && t.uuid.length > 0 && typeof t.secretKey == "string" && t.secretKey.length > 0;
}
function wh(n) {
  if (!n || typeof n != "object")
    return {};
  const t = yh(), e = Object.entries(n).flatMap(
    ([i, s]) => vh(s) ? s.timestamp + s.expires <= t ? [] : [[i, s]] : []
  );
  return Object.fromEntries(e);
}
function Sh(n) {
  if (!n || typeof n != "object")
    return !1;
  const t = n;
  return typeof t.expiresAt == "number" && Number.isFinite(t.expiresAt) && typeof t.secretKey == "string" && t.secretKey.length > 0 && typeof t.uuid == "string" && t.uuid.length > 0;
}
class Th {
  constructor(t = C) {
    this.storage = t;
  }
  getStorageKey(t) {
    return bh;
  }
  async restore(t, e = {}) {
    const i = this.getStorageKey(t), s = await this.storage.getRaw(i);
    if (!Sh(s))
      return e;
    const o = Date.now();
    if (s.expiresAt <= o)
      return await this.storage.deleteRaw(i), e;
    const r = Math.max(
      1,
      Math.ceil((s.expiresAt - o) / 1e3)
    );
    return {
      ...e,
      "video-translation": {
        secretKey: s.secretKey,
        uuid: s.uuid,
        expires: r,
        timestamp: Math.floor(o / 1e3)
      }
    };
  }
  async persist(t, e) {
    const i = this.getStorageKey(t), s = wh(e)["video-translation"];
    if (!s) {
      await this.storage.deleteRaw(i);
      return;
    }
    await this.storage.setRaw(i, {
      secretKey: s.secretKey,
      uuid: s.uuid,
      expiresAt: (s.timestamp + s.expires) * 1e3
    });
  }
}
class kh {
  constructor() {
    c(this, "cache", /* @__PURE__ */ new Map());
  }
  /**
   * Clears all cached entries.
   *
   * Used when runtime settings change (e.g. proxy mode/host), because cached
   * translation URLs and especially previous failures can become stale.
   */
  clear() {
    this.cache.clear();
  }
  getTranslation(t) {
    return this.getValue(t, "translation");
  }
  setTranslation(t, e) {
    this.setValue(t, "translation", e);
  }
  getSubtitles(t) {
    return this.getValue(t, "subtitles");
  }
  setSubtitles(t, e) {
    this.setValue(t, "subtitles", e);
  }
  deleteSubtitles(t) {
    this.deleteValue(t, "subtitles");
  }
  getValue(t, e) {
    const i = Date.now(), s = this.cache.get(t);
    if (!s) return;
    const o = Ri[e], r = s[o];
    if (r !== void 0 && r <= i) {
      s[e] = void 0, s[o] = void 0, this.evictIfEmpty(t, s);
      return;
    }
    return s[e];
  }
  setValue(t, e, i) {
    const s = Date.now(), o = this.getOrCreateEntry(t), r = s + Ml, a = Ri[e];
    o[e] = i, o[a] = r;
  }
  deleteValue(t, e) {
    const i = this.cache.get(t);
    if (!i) return;
    const s = Ri[e];
    i[e] = void 0, i[s] = void 0, this.evictIfEmpty(t, i);
  }
  evictIfEmpty(t, e) {
    e.translation === void 0 && e.subtitles === void 0 && this.cache.delete(t);
  }
  getOrCreateEntry(t) {
    const e = this.cache.get(t);
    if (e) return e;
    const i = {};
    return this.cache.set(t, i), i;
  }
}
class Lh {
  constructor() {
    c(this, "memoryCache", /* @__PURE__ */ new Map());
    c(this, "inFlightRequests", /* @__PURE__ */ new Map());
  }
  async execute(t, e, i) {
    if (!e || e.ttlMs <= 0)
      return i();
    const s = e.key ?? this.buildDefaultCacheKey(t);
    if (!s)
      return i();
    const o = this.normalizeMethod(t.method), r = e.ttlMs, a = e.cacheName || mh, l = e.useMemory !== !1, u = e.useCacheApi !== !1 && o === "GET" && this.supportsCacheApi(), d = u ? ds(s) : "", h = e.dedupe !== !1, f = e.allowStaleOnError !== !1, g = Date.now();
    let m;
    if (l) {
      const w = this.readMemoryCache(s, g);
      if (w.fresh)
        return w.fresh;
      m = w.stale ?? m;
    }
    if (u) {
      const w = await this.readCacheApi(
        a,
        t.url,
        d,
        r,
        g,
        f
      );
      if (w.fresh)
        return l && this.writeMemoryCache(
          s,
          w.fresh.clone(),
          w.expiresAt ?? g + r
        ), w.fresh;
      m = m ?? w.stale;
    }
    const v = async () => {
      const w = await i();
      if (!w.ok)
        return w;
      const x = Date.now(), I = this.computeExpiresAt(x, r);
      if (l && this.writeMemoryCache(s, w.clone(), I), u) {
        const k = this.toStorableResponse(w.clone(), x);
        await this.writeCacheApi(a, t.url, d, k);
      }
      return w;
    };
    if (!h)
      try {
        return await v();
      } catch (w) {
        if (f && m)
          return m;
        throw w;
      }
    const T = this.inFlightRequests.get(s);
    if (T !== void 0)
      return (await T).clone();
    const S = (async () => {
      try {
        return await v();
      } catch (w) {
        if (f && m)
          return m.clone();
        throw w;
      }
    })();
    this.inFlightRequests.set(s, S);
    try {
      return (await S).clone();
    } finally {
      this.inFlightRequests.delete(s);
    }
  }
  computeExpiresAt(t, e) {
    if (!Number.isFinite(e) || e <= 0)
      return t;
    const i = Number.MAX_SAFE_INTEGER - t;
    return e >= i ? Number.MAX_SAFE_INTEGER : t + e;
  }
  normalizeMethod(t) {
    return (t || "GET").toUpperCase();
  }
  resolveBodyKey(t) {
    if (t == null) return "";
    if (typeof t == "string") return t;
    if (t instanceof URLSearchParams) return t.toString();
  }
  buildDefaultCacheKey(t) {
    const e = this.normalizeMethod(t.method);
    if (e === "GET" || e === "HEAD")
      return `${e}:${t.url}`;
    const i = this.resolveBodyKey(t.body);
    if (i !== void 0)
      return `${e}:${t.url}#${ds(i)}`;
  }
  supportsCacheApi() {
    return typeof caches < "u" && typeof caches.open == "function";
  }
  readCreatedAtMs(t) {
    const e = t.headers.get(hr);
    if (!e) return null;
    const i = Number(e);
    return Number.isFinite(i) ? i : null;
  }
  ensureVaryByCacheKey(t) {
    const e = t.get("vary");
    if (!e) {
      t.set("vary", Fe);
      return;
    }
    const i = new Set(
      e.split(",").map((s) => s.trim().toLowerCase())
    );
    !i.has("*") && !i.has(Fe) && t.set("vary", `${e}, ${Fe}`);
  }
  toStorableResponse(t, e) {
    const i = new Headers(t.headers);
    return i.set(hr, String(e)), this.ensureVaryByCacheKey(i), new Response(t.body, {
      status: t.status,
      statusText: t.statusText,
      headers: i
    });
  }
  readMemoryCache(t, e) {
    const i = this.memoryCache.get(t);
    return i ? i.expiresAt > e ? (this.touchMemoryCache(t, i), {
      fresh: i.response.clone(),
      expiresAt: i.expiresAt
    }) : (this.memoryCache.delete(t), {
      stale: i.response.clone(),
      expiresAt: i.expiresAt
    }) : {};
  }
  touchMemoryCache(t, e) {
    this.memoryCache.delete(t), this.memoryCache.set(t, e);
  }
  trimMemoryCache() {
    for (; this.memoryCache.size > ph; ) {
      const t = this.memoryCache.keys().next().value;
      if (typeof t != "string") break;
      this.memoryCache.delete(t);
    }
  }
  writeMemoryCache(t, e, i) {
    this.memoryCache.has(t) && this.memoryCache.delete(t), this.memoryCache.set(t, {
      response: e,
      expiresAt: i
    }), this.trimMemoryCache();
  }
  async readCacheApi(t, e, i, s, o, r) {
    try {
      const a = new Request(e, {
        method: "GET",
        headers: {
          [Fe]: i
        }
      }), l = await caches.open(t), u = await l.match(a);
      if (!u) return {};
      const d = this.readCreatedAtMs(u);
      if (d === null)
        return await l.delete(a), {};
      const h = this.computeExpiresAt(d, s);
      if (h > o)
        return {
          fresh: u.clone(),
          expiresAt: h
        };
      if (!r)
        return await l.delete(a), {};
      const f = u.clone();
      return await l.delete(a), {
        stale: f,
        expiresAt: h
      };
    } catch {
      return {};
    }
  }
  async writeCacheApi(t, e, i, s) {
    try {
      const o = new Request(e, {
        method: "GET",
        headers: {
          [Fe]: i
        }
      });
      await (await caches.open(t)).put(o, s);
    } catch {
    }
  }
}
const xh = new Lh();
async function Ah(n, t, e) {
  return xh.execute(n, t, e);
}
function Eh(n) {
  const t = /* @__PURE__ */ new WeakSet();
  try {
    return JSON.stringify(n, (i, s) => typeof s != "object" || s === null ? s : t.has(s) ? "[Circular]" : (t.add(s), s)) ?? null;
  } catch {
    return null;
  }
}
function Ol(n, t = "Unknown error") {
  if (n instanceof Error)
    return n.message || t;
  if (typeof n == "string")
    return n || t;
  if (n == null)
    return t;
  if (typeof n == "object") {
    const e = n;
    if (typeof e?.data?.message == "string" && e.data.message)
      return e.data.message;
    if (typeof e?.error?.message == "string" && e.error.message)
      return e.error.message;
    if (typeof e?.message == "string" && e.message)
      return e.message;
    const i = Eh(n);
    if (i && i !== "{}")
      return i;
    const s = n.constructor?.name;
    return s ? `[${s}]` : t;
  }
  return typeof n == "number" || typeof n == "boolean" || typeof n == "bigint" ? `${n}` : typeof n == "symbol" ? n.description ? `Symbol(${n.description})` : "Symbol" : typeof n == "function" ? n.name ? `[Function ${n.name}]` : "[Function]" : t;
}
function yi(n) {
  return Ol(n, "");
}
function ln(n) {
  const t = n;
  return typeof DOMException < "u" && t instanceof DOMException && t.name === "AbortError" || t instanceof Error && t.name === "AbortError" || t?.message === "AbortError";
}
function re(n = "Aborted") {
  try {
    return new DOMException(n, "AbortError");
  } catch {
    const t = new Error(n);
    return t.name = "AbortError", t;
  }
}
const hs = new AbortController().signal;
function Bi(n) {
  const t = n.throwIfAborted;
  if (typeof t == "function")
    try {
      t.call(n);
      return;
    } catch (e) {
      throw n.aborted || ln(e) ? re() : e instanceof Error ? e : new Error(String(e));
    }
  if (n.aborted)
    throw re();
}
function Vh(n, t) {
  if (!(Number.isFinite(n) && n > 0))
    return {
      signal: t ?? hs,
      cleanup: () => {
      }
    };
  const i = new AbortController();
  let s;
  const o = () => {
    s !== void 0 && (clearTimeout(s), s = void 0), i.abort(t?.reason);
  };
  return t && (t.addEventListener("abort", o, { once: !0 }), t.aborted && o()), i.signal.aborted || (s = setTimeout(() => {
    i.abort(re("Timeout")), s = void 0;
  }, n)), {
    signal: i.signal,
    cleanup: () => {
      s !== void 0 && (clearTimeout(s), s = void 0), t?.removeEventListener("abort", o);
    }
  };
}
const fr = "api.browser.yandex.ru", gr = "googlevideo.com", mr = "toil.cc", pr = "workers.dev", br = "onrender.com", yr = "cloudflare-dns.com", Ch = /^([\w-]+):\s*(.+)$/, Ih = /^[a-zA-Z][a-zA-Z\d+.-]*:/;
typeof GM_info > "u" || GM_info?.scriptHandler;
const Dl = (
  // The extension build provides a full GM_xmlhttpRequest implementation, so
  // we should not fall into the "proxy-only" compatibility mode.
  !1
), Ne = typeof GM < "u", cn = typeof GM_xmlhttpRequest < "u";
function Ph(n) {
  const t = n.trim();
  try {
    return new URL(t).hostname.toLowerCase();
  } catch {
    if (!Ih.test(t))
      try {
        return new URL(`https://${t}`).hostname.toLowerCase();
      } catch {
      }
    return;
  }
}
function Mh(n) {
  if (n != null)
    return typeof n == "string" ? n : n instanceof URLSearchParams ? n.toString() : (n instanceof FormData || n instanceof Blob || n instanceof ArrayBuffer, n);
}
function ue(n, t) {
  return n === t || n.endsWith(`.${t}`);
}
function Oh(n, t, e = !1) {
  if (e)
    return !0;
  if (!n) {
    const i = t.toLowerCase();
    return i.includes(fr) || i.includes(gr) || i.includes(mr) || i.includes(pr) || i.includes(br) || i.includes(yr);
  }
  return ue(n, fr) || ue(n, gr) || ue(n, mr) || ue(n, pr) || ue(n, br) || ue(n, yr);
}
function Dh(n) {
  return typeof n == "string" ? n : n instanceof URL ? n.href : n.url;
}
function _h(n, t) {
  return t ? t.toUpperCase() : n instanceof Request ? (n.method || "GET").toUpperCase() : "GET";
}
function Rh(n) {
  return typeof n != "string" || n.length === 0 ? {} : n.split(/\r?\n/).reduce((t, e) => {
    const i = Ch.exec(e);
    if (!i)
      return t;
    const [, s, o] = i;
    return t[s] = o, t;
  }, {});
}
function Bh(n) {
  const t = n;
  return typeof t?.error == "string" ? t.error : typeof t?.statusText == "string" ? t.statusText : yi(n) || "Unknown error";
}
async function vr(n, t, e) {
  const i = gh(e.headers);
  return await new Promise((s, o) => {
    const r = typeof GM_xmlhttpRequest > "u" ? globalThis.GM_xmlhttpRequest : GM_xmlhttpRequest;
    if (typeof r != "function") {
      o(new TypeError("GM_xmlhttpRequest is not available"));
      return;
    }
    let a = !1, l;
    const u = () => {
      l && e.signal?.removeEventListener("abort", l);
    }, d = (f) => {
      a || (a = !0, u(), o(f));
    }, h = r({
      method: e.method || "GET",
      url: n,
      responseType: "blob",
      data: Mh(e.body),
      timeout: t,
      headers: i,
      onload: (f) => {
        if (a) return;
        a = !0, u();
        const g = Rh(f.responseHeaders), m = new Response(f.response, {
          status: f.status,
          statusText: typeof f.statusText == "string" ? f.statusText : "",
          headers: g
        });
        Object.defineProperty(m, "url", {
          value: f.finalUrl ?? n
        }), s(m);
      },
      ontimeout: () => d(new Error("Timeout")),
      onerror: (f) => d(new Error(Bh(f))),
      onabort: () => d(re())
    });
    if (l = () => {
      try {
        h?.abort?.();
      } catch {
      }
      d(re());
    }, e.signal && (e.signal.addEventListener("abort", l, { once: !0 }), e.signal.aborted)) {
      l();
      return;
    }
  });
}
async function nt(n, t = {}) {
  const {
    timeout: e = 15e3,
    forceGmXhr: i = !1,
    responseCache: s,
    ...o
  } = t, r = Dh(n), a = Ph(r), l = _h(n, o.method), u = async () => {
    if (Oh(a, r, i))
      return await vr(r, e, o);
    const { signal: d, cleanup: h } = Vh(
      e,
      o.signal
    );
    try {
      return await fetch(n, {
        ...o,
        signal: d
      });
    } catch (f) {
      if (d.aborted || ln(f))
        throw f;
      return V.log(
        "GM_fetch preventing CORS by GM_xmlhttpRequest",
        yi(f) || "Unknown error"
      ), await vr(r, e, o);
    } finally {
      h();
    }
  };
  return s ? await Ah(
    {
      url: r,
      method: l,
      body: o.body
    },
    s,
    u
  ) : await u();
}
const Fh = {
  numToBool: [
    ["autoTranslate"],
    ["dontTranslateYourLang", "enabledDontTranslateLanguages"],
    ["autoSetVolumeYandexStyle", "enabledAutoVolume"],
    ["showVideoSlider"],
    ["syncVolume"],
    ["downloadWithName"],
    ["sendNotifyOnComplete"],
    ["highlightWords"],
    ["onlyBypassMediaCSP"],
    ["newAudioPlayer"],
    ["showPiPButton"],
    ["translateAPIErrors"],
    ["audioBooster"],
    ["useNewModel", "useLivelyVoice"]
  ],
  number: [["autoVolume"]],
  array: [["dontTranslateLanguage", "dontTranslateLanguages"]],
  string: [
    ["hotkeyButton", "translationHotkey"],
    ["locale-lang-override", "localeLangOverride"],
    ["locale-lang", "localeLang"]
  ]
}, _l = Object.entries(Fh).flatMap(
  ([n, t]) => t.map(([e, i]) => ({
    category: n,
    oldKey: e,
    newKey: i ?? e,
    shouldDeleteOldKey: !!i
  }))
), Nh = new Map(
  _l.map((n) => [n.oldKey, n])
), Uh = Array.from(
  new Set(_l.map((n) => n.oldKey))
);
function Hh(n) {
  const t = {};
  for (const e of n)
    t[e] = void 0;
  return t;
}
function $h(n, t) {
  switch (n) {
    case "numToBool":
    case "number":
      return typeof t == "number";
    case "array":
      return Array.isArray(t);
    case "string":
      return typeof t == "string" || t === null;
    default:
      return !1;
  }
}
function Wh(n, t) {
  switch (n) {
    case "string":
    case "array":
    case "number":
      return t;
    default:
      return !!t;
  }
}
function zh(n, t) {
  let e = Wh(n.category, t);
  return n.oldKey === "autoVolume" && typeof t == "number" && t < 1 && (e = Math.round(t * 100)), e;
}
function qh(n, t) {
  return Array.isArray(n) && Array.isArray(t) ? n.length === t.length && n.every((e, i) => Object.is(e, t[i])) : Object.is(n, t);
}
async function Gh(n) {
  if (n.compatVersion === an)
    return n;
  const t = /* @__PURE__ */ new Set([
    ...Object.keys(n),
    ...Uh
  ]), e = await C.getValues(Hh(t)), i = { ...n }, s = [], o = [];
  for (const [r, a] of Object.entries(e)) {
    if (a === void 0)
      continue;
    const l = Nh.get(r);
    if (!l || !$h(l.category, a))
      continue;
    const u = zh(l, a);
    i[l.newKey] = u;
    const d = e[l.newKey];
    (l.shouldDeleteOldKey || !qh(d, u)) && s.push(C.set(l.newKey, u)), l.shouldDeleteOldKey && o.push(C.delete(l.oldKey));
  }
  return await Promise.all([...s, ...o]), {
    ...i,
    compatVersion: an
  };
}
class wr {
  constructor() {
    c(this, "support", null);
  }
  resolveSupport() {
    if (this.support)
      return this.support;
    const t = {
      legacyGet: typeof GM_getValue == "function",
      legacySet: typeof GM_setValue == "function",
      legacyDelete: typeof GM_deleteValue == "function",
      legacyList: typeof GM_listValues == "function",
      promiseGet: Ne && typeof GM?.getValue == "function",
      promiseGetValues: Ne && typeof GM?.getValues == "function",
      promiseSet: Ne && typeof GM?.setValue == "function",
      promiseDelete: Ne && typeof GM?.deleteValue == "function",
      promiseList: Ne && typeof GM?.listValues == "function"
    };
    return this.support = t, V.log(
      `[VOT Storage] GM Promises: ${t.promiseGet} | GM legacy: ${t.legacyGet}`
    ), t;
  }
  /**
   * Check if storage type is LocalStorage
   */
  get isSupportOnlyLS() {
    const t = this.resolveSupport();
    return !t.legacyGet && !t.legacySet && !t.legacyDelete && !t.legacyList && !t.promiseGet && !t.promiseGetValues && !t.promiseSet && !t.promiseDelete && !t.promiseList;
  }
  syncGetByName(t, e, i) {
    if (i.legacyGet)
      return GM_getValue(t, e);
    const s = globalThis.localStorage.getItem(t);
    if (s === null)
      return e;
    try {
      return JSON.parse(s);
    } catch {
      return e;
    }
  }
  async getRaw(t, e) {
    const i = this.resolveSupport();
    return i.promiseGet && GM.getValue ? await GM.getValue(t, e) : this.syncGetByName(t, e, i);
  }
  async get(t, e) {
    return this.getRaw(t, e);
  }
  async getValues(t) {
    const e = this.resolveSupport();
    if (e.promiseGetValues && GM.getValues)
      return await GM.getValues(t);
    const i = Object.entries(t);
    if (e.promiseGet && GM.getValue) {
      const s = await Promise.all(
        i.map(async ([o, r]) => {
          const a = await GM.getValue(o, r);
          return [o, a];
        })
      );
      return Object.fromEntries(s);
    }
    return Object.fromEntries(
      i.map(([s, o]) => [
        s,
        this.syncGetByName(s, o, e)
      ])
    );
  }
  syncSetByName(t, e, i) {
    return i.legacySet ? GM_setValue(t, e) : globalThis.localStorage.setItem(t, JSON.stringify(e));
  }
  async setRaw(t, e) {
    const i = this.resolveSupport();
    return i.promiseSet && GM.setValue ? await GM.setValue(t, e) : this.syncSetByName(t, e, i);
  }
  async set(t, e) {
    return this.setRaw(t, e);
  }
  syncDeleteByName(t, e) {
    return e.legacyDelete ? GM_deleteValue(t) : globalThis.localStorage.removeItem(t);
  }
  async deleteRaw(t) {
    const e = this.resolveSupport();
    return e.promiseDelete && GM.deleteValue ? await GM.deleteValue(t) : this.syncDeleteByName(t, e);
  }
  async delete(t) {
    return this.deleteRaw(t);
  }
  syncList(t) {
    return t.legacyList ? GM_listValues() : Jd;
  }
  async list() {
    const t = this.resolveSupport();
    return t.promiseList && GM.listValues ? await GM.listValues() : this.syncList(t);
  }
}
const Sr = "__VOT_STORAGE_SINGLETON__", C = (() => {
  const n = globalThis, t = n[Sr];
  if (t instanceof wr)
    return t;
  const e = new wr();
  return n[Sr] = e, e;
})();
function Kh() {
  const n = globalThis._userData;
  if (!n || typeof n != "object") return null;
  const t = n;
  return typeof t.avatar_id != "string" || typeof t.username != "string" || !t.avatar_id || !t.username ? null : {
    avatar_id: t.avatar_id,
    username: t.username
  };
}
function Yh(n) {
  let t = "";
  for (const e of n) t += String.fromCharCode(e);
  return btoa(t).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
async function jh(n) {
  const t = new TextEncoder().encode(n), e = await crypto.subtle.digest("SHA-256", t);
  return Yh(new Uint8Array(e));
}
function Tr(n = 64) {
  const t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~", e = new Uint8Array(n);
  crypto.getRandomValues(e);
  let i = "";
  for (let s = 0; s < n; s += 1)
    i += t[e[s] % t.length];
  return i;
}
async function Xh() {
  const n = Tr(32), t = Tr(64), e = await jh(t);
  return sessionStorage.setItem("vot-yandex-oauth-state", n), sessionStorage.setItem("vot-yandex-oauth-code-verifier", t), `https://oauth.yandex.ru/authorize?${new URLSearchParams({
    response_type: "code",
    client_id: Ll,
    redirect_uri: xl,
    state: n,
    code_challenge: e,
    code_challenge_method: "S256"
  }).toString()}`;
}
function Jh(n, t) {
  return new Promise((e, i) => {
    GM_xmlhttpRequest({
      method: "POST",
      url: n,
      headers: {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
      },
      data: t,
      onload: (s) => {
        e({
          status: s.status,
          responseText: s.responseText || ""
        });
      },
      onerror: (s) => {
        console.error("[VOT] GM OAuth request failed:", s), i(new Error("[VOT] GM OAuth request network error"));
      },
      ontimeout: () => {
        i(new Error("[VOT] GM OAuth request timeout"));
      }
    });
  });
}
async function Zh(n) {
  const t = sessionStorage.getItem("vot-yandex-oauth-code-verifier");
  if (!t)
    throw new Error("[VOT] Missing PKCE code_verifier in opener");
  const e = new URLSearchParams({
    grant_type: "authorization_code",
    code: n,
    client_id: Ll,
    code_verifier: t,
    redirect_uri: xl
  }).toString(), i = await Jh("https://oauth.yandex.ru/token", e), s = i.responseText || "";
  let o = {};
  try {
    o = s ? JSON.parse(s) : {};
  } catch {
    o = {};
  }
  if (i.status < 200 || i.status >= 300 || o?.error) {
    const r = o?.error ?? `http_${i.status}`, a = o?.error_description ? ` (${o.error_description})` : "";
    throw new Error(
      `[VOT] Failed to exchange verification code: ${r}${a}. Response: ${s}`
    );
  }
  if (!o?.access_token)
    throw new Error(
      `[VOT] access_token was not returned by Yandex. Response: ${s}`
    );
  if (typeof o.expires_in != "number")
    throw new Error(
      `[VOT] expires_in was not returned or invalid. Response: ${s}`
    );
  return {
    access_token: o.access_token,
    expires_in: o.expires_in,
    refresh_token: o.refresh_token
  };
}
async function Qh(n) {
  await C.set("account", {
    token: n.access_token,
    expires: Date.now() + n.expires_in * 1e3,
    username: void 0,
    avatarId: void 0
  }), sessionStorage.removeItem("vot-yandex-oauth-state"), sessionStorage.removeItem("vot-yandex-oauth-code-verifier");
}
async function Fi(n) {
  globalThis.opener && !globalThis.opener.closed && globalThis.opener.postMessage(n, "*");
}
async function tf() {
  const n = new URLSearchParams(globalThis.location.search), t = n.get("code"), e = n.get("state") ?? void 0, i = n.get("error"), s = n.get("error_description") ?? void 0;
  if (i) {
    await Fi({
      source: "vot-auth",
      type: "error",
      error: i,
      error_description: s,
      state: e
    }), globalThis.close();
    return;
  }
  if (!t) {
    await Fi({
      source: "vot-auth",
      type: "error",
      error: "missing_code",
      state: e
    }), globalThis.close();
    return;
  }
  await Fi({
    source: "vot-auth",
    type: "code",
    code: t,
    state: e
  }), globalThis.close();
}
async function ef() {
  const n = Kh();
  if (!n)
    throw new Error("[VOT] Invalid user data");
  const t = await C.get("account");
  if (!t)
    throw new Error("[VOT] No account data found");
  await C.set("account", {
    ...t,
    username: n.username,
    avatarId: n.avatar_id
  });
}
async function nf() {
  if (globalThis.location.origin === yn && globalThis.location.pathname === Gs)
    return tf();
  if (globalThis.location.pathname === "/my/profile")
    return ef();
}
const sf = "recommended", of = "Translate video", rf = "Turn off", af = "Translation settings", lf = "Subtitles settings", cf = "Smart subtitle layout", uf = "Reset settings", df = "The video is being translated", hf = "Video language", ff = "Translation language", gf = "The translation will take", mf = "The translation will take more than an hour", pf = "The translation will take about a minute", bf = "The translation will take a few minutes", yf = "The translation will take approximately {0} minutes", vf = "The translation will take approximately {0} minutes", wf = "Failed to request video translation", Sf = "Audio link not received", Tf = "Failed to download audio", kf = "The audio format is not supported", Lf = "Translate on open", xf = "Subtitles on open", Af = "Don't translate from my language", Ef = "Video volume:", Vf = "Translation volume:", Cf = "Reduce video volume to", If = "Video volume slider", Pf = "Link translation and video volume", Mf = "You have disabled the translation of the video in your language", Of = "Video is too long", Df = "No video ID found", _f = "Subtitles", Rf = "Disabled", Bf = "Subtitles max length", Ff = "Highlight words", Nf = "translated from", Uf = "autogenerated", Hf = "VOT Settings", $f = "Menu language", Wf = "Authors", zf = "Version", qf = "Loader", Gf = "Browser", Kf = "Show PiP button", Yf = { auto: "Auto", af: "Afrikaans", ak: "Akan", sq: "Albanian", am: "Amharic", ar: "Arabic", hy: "Armenian", as: "Assamese", ay: "Aymara", az: "Azerbaijani", bn: "Bangla", eu: "Basque", be: "Belarusian", bho: "Bhojpuri", bs: "Bosnian", bg: "Bulgarian", my: "Burmese", ca: "Catalan", ceb: "Cebuano", zh: "Chinese", "zh-Hans": "Chinese (Simplified)", "zh-Hant": "Chinese (Traditional)", co: "Corsican", hr: "Croatian", cs: "Czech", da: "Danish", dv: "Divehi", nl: "Dutch", en: "English", eo: "Esperanto", et: "Estonian", ee: "Ewe", fil: "Filipino", fi: "Finnish", fr: "French", gl: "Galician", lg: "Ganda", ka: "Georgian", de: "German", el: "Greek", gn: "Guarani", gu: "Gujarati", ht: "Haitian Creole", ha: "Hausa", haw: "Hawaiian", iw: "Hebrew", hi: "Hindi", hmn: "Hmong", hu: "Hungarian", is: "Icelandic", ig: "Igbo", id: "Indonesian", ga: "Irish", it: "Italian", ja: "Japanese", jv: "Javanese", kn: "Kannada", kk: "Kazakh", km: "Khmer", rw: "Kinyarwanda", ko: "Korean", kri: "Krio", ku: "Kurdish", ky: "Kyrgyz", lo: "Lao", la: "Latin", lv: "Latvian", ln: "Lingala", lt: "Lithuanian", lb: "Luxembourgish", mk: "Macedonian", mg: "Malagasy", ms: "Malay", ml: "Malayalam", mt: "Maltese", mi: "Māori", mr: "Marathi", mn: "Mongolian", ne: "Nepali", nso: "Northern Sotho", no: "Norwegian", ny: "Nyanja", or: "Odia", om: "Oromo", ps: "Pashto", fa: "Persian", pl: "Polish", pt: "Portuguese", pa: "Punjabi", qu: "Quechua", ro: "Romanian", ru: "Russian", sm: "Samoan", sa: "Sanskrit", gd: "Scottish Gaelic", sr: "Serbian", sn: "Shona", sd: "Sindhi", si: "Sinhala", sk: "Slovak", sl: "Slovenian", so: "Somali", st: "Southern Sotho", es: "Spanish", su: "Sundanese", sw: "Swahili", sv: "Swedish", tg: "Tajik", ta: "Tamil", tt: "Tatar", te: "Telugu", th: "Thai", ti: "Tigrinya", ts: "Tsonga", tr: "Turkish", tk: "Turkmen", uk: "Ukrainian", ur: "Urdu", ug: "Uyghur", uz: "Uzbek", vi: "Vietnamese", cy: "Welsh", fy: "Western Frisian", xh: "Xhosa", yi: "Yiddish", yo: "Yoruba", zu: "Zulu" }, jf = "There is no connection to the server", Xf = "Search...", Jf = "Translate errors from the API", Zf = "Language detection service", Qf = "Enter the proxy worker address", tg = "Enter the address of the m3u8 proxy worker", eg = "Proxy Settings", ng = "The translation will take approximately {0} minutes", ig = "Extended translation volume increase", sg = "Subtitles design", og = "Subtitle font", rg = "Font size of subtitles", ag = "Transparency of the subtitle background", lg = "The format for downloading subtitles", cg = "Download files with the video name", ug = "Update localization files", dg = "Locale hash", hg = "Updated at", fg = "To enable this, you must have a Web Audio API", gg = "Media CSP is enabled on this site", mg = "Use it only for bypassing Media CSP", pg = "Use the new audio player", bg = "Use an experimental variation of Yandex voices for some videos", yg = "The translation is slightly delayed", vg = "The translation on the {0} has been completed!", wg = "Send a notification that the video has been translated", Sg = "Report a bug", Tg = "Disabled", kg = "Enabled", Lg = "Proxy everything", xg = "Proxying mode", Ag = "Translated by {0}", Eg = "Translate stream isn't available", Vg = "Text translation service", Cg = "Doesn't affect the translation of text in voice over", Ig = "Don't translate from selected languages", Pg = "Display the video volume slider", Mg = "Hotkeys settings", Og = "None", Dg = "Use lively voices. Speakers sound like native Russians.", _g = "Misc settings", Rg = { yandexbrowser: "Yandex Browser", msedge: "Microsoft Edge", "rust-server": "Rust Server" }, Bg = "About extension", Fg = "Appearance", Ng = "Button position in the player", Ug = { left: "Left", right: "Right", top: "Top", default: "Default" }, Hg = "secs", $g = "Delay before hiding the translate button", Wg = "not found", zg = "The button position only changes in players larger than 600 pixels.", qg = "Completely disabling proxying in your country may break the extension", Gg = "Press the key combination...", Kg = "Use audio download", Yg = "Disabling audio downloads may affect the functionality of the extension", jg = "You need to log in to use this feature", Xg = "My account", Jg = "Login", Zg = "Logout", Qg = "Refresh", tm = "Enter the Yandex OAuth Token", em = "You can manually set the account token in this field. Please note that we don't check its validity before sending a translate request", nm = "Login via token", im = "Adaptive volume", sm = {
  recommended: sf,
  translateVideo: of,
  disableTranslate: rf,
  translationSettings: af,
  subtitlesSettings: lf,
  subtitlesSmartLayout: cf,
  resetSettings: uf,
  videoBeingTranslated: df,
  videoLanguage: hf,
  translationLanguage: ff,
  translationTake: gf,
  translationTakeMoreThanHour: mf,
  translationTakeAboutMinute: pf,
  translationTakeFewMinutes: bf,
  translationTakeApproximatelyMinutes: yf,
  translationTakeApproximatelyMinute: vf,
  requestTranslationFailed: wf,
  audioNotReceived: Sf,
  VOTFailedDownloadAudio: Tf,
  audioFormatNotSupported: kf,
  VOTAutoTranslate: Lf,
  VOTAutoSubtitles: xf,
  VOTDontTranslateYourLang: Af,
  VOTVolume: Ef,
  VOTVolumeTranslation: Vf,
  VOTAutoSetVolume: Cf,
  VOTShowVideoSlider: If,
  VOTSyncVolume: Pf,
  VOTDisableFromYourLang: Mf,
  VOTVideoIsTooLong: Of,
  VOTNoVideoIDFound: Df,
  VOTSubtitles: _f,
  VOTSubtitlesDisabled: Rf,
  VOTSubtitlesMaxLength: Bf,
  VOTHighlightWords: Ff,
  VOTTranslatedFrom: Nf,
  VOTAutogenerated: Uf,
  VOTSettings: Hf,
  VOTMenuLanguage: $f,
  VOTAuthors: Wf,
  VOTVersion: zf,
  VOTLoader: qf,
  VOTBrowser: Gf,
  VOTShowPiPButton: Kf,
  langs: Yf,
  streamNoConnectionToServer: jf,
  searchField: Xf,
  VOTTranslateAPIErrors: Jf,
  VOTDetectService: Zf,
  VOTProxyWorkerHost: Qf,
  VOTM3u8ProxyHost: tg,
  proxySettings: eg,
  translationTakeApproximatelyMinute2: ng,
  VOTAudioBooster: ig,
  VOTSubtitlesDesign: sg,
  VOTSubtitlesFont: og,
  VOTSubtitlesFontSize: rg,
  VOTSubtitlesOpacity: ag,
  VOTSubtitlesDownloadFormat: lg,
  VOTDownloadWithName: cg,
  VOTUpdateLocaleFiles: ug,
  VOTLocaleHash: dg,
  VOTUpdatedAt: hg,
  VOTNeedWebAudioAPI: fg,
  VOTMediaCSPEnabledOnSite: gg,
  VOTOnlyBypassMediaCSP: mg,
  VOTNewAudioPlayer: pg,
  VOTUseNewModel: bg,
  TranslationDelayed: yg,
  VOTTranslationCompletedNotify: vg,
  VOTSendNotifyOnComplete: wg,
  VOTBugReport: Sg,
  VOTTranslateProxyDisabled: Tg,
  VOTTranslateProxyEnabled: kg,
  VOTTranslateProxyEverything: Lg,
  VOTTranslateProxyStatus: xg,
  VOTTranslatedBy: Ag,
  VOTStreamNotAvailable: Eg,
  VOTTranslationTextService: Vg,
  VOTNotAffectToVoice: Cg,
  DontTranslateSelectedLanguages: Ig,
  showVideoVolumeSlider: Pg,
  hotkeysSettings: Mg,
  None: Og,
  VOTUseLivelyVoice: Dg,
  miscSettings: _g,
  services: Rg,
  aboutExtension: Bg,
  appearance: Fg,
  buttonPosition: Ng,
  position: Ug,
  secs: Hg,
  autoHideButtonDelay: $g,
  notFound: Wg,
  minButtonPositionContainer: zg,
  VOTTranslateProxyStatusDefault: qg,
  PressTheKeyCombination: Gg,
  VOTUseAudioDownload: Kg,
  VOTUseAudioDownloadWarning: Yg,
  VOTAccountRequired: jg,
  VOTMyAccount: Xg,
  VOTLogin: Jg,
  VOTLogout: Zg,
  VOTRefresh: Qg,
  VOTYandexToken: tm,
  VOTYandexTokenInfo: em,
  VOTLoginViaToken: nm,
  smartDucking: im
};
var Ni = ["auto", "en", "ru", "af", "am", "ar", "az", "bg", "bn", "bs", "ca", "cs", "cy", "da", "de", "el", "es", "et", "eu", "fa", "fi", "fr", "gl", "hi", "hr", "hu", "hy", "id", "it", "ja", "jv", "kk", "km", "kn", "ko", "lo", "mk", "ml", "mn", "ms", "mt", "my", "ne", "nl", "pa", "pl", "pt", "ro", "si", "sk", "sl", "sq", "sr", "su", "sv", "sw", "tr", "uk", "ur", "uz", "vi", "zh", "zu"];
const om = [
  "localePhrases",
  "localeLang",
  "localeHash",
  "localeVersion",
  "localeUpdatedAt",
  "localeLangOverride"
], rm = Pl(sm), kr = "master", am = (() => {
  const n = typeof Ni < "u" && Array.isArray(Ni) ? Ni : ["en"];
  return n.includes("auto") ? n : ["auto", ...n];
})();
function lm(n, t) {
  return n || t || "unknown";
}
function cm() {
  const n = "1.11.5.21", t = typeof GM_info < "u" ? String(GM_info?.script?.version || "") : "";
  return lm(n, t);
}
class um {
  constructor() {
    /**
     * Language used before page was reloaded
     */
    c(this, "lang");
    /**
     * Locale phrases with current language
     */
    c(this, "locale");
    c(this, "defaultLocale", rm);
    c(this, "localesUrl", `${ar}/${kr}/src/localization/locales`);
    c(this, "hashesUrl", `${ar}/${kr}/src/localization/hashes.json`);
    c(this, "warnedMissingKeys", /* @__PURE__ */ new Set());
    c(this, "_langOverride", "auto");
    this.lang = this.getLang(), this.locale = {};
  }
  async init() {
    const [t, e] = await Promise.all([
      C.get("localeLangOverride", "auto"),
      C.get("localePhrases", "")
    ]);
    return this._langOverride = t, this.lang = this.getLang(), this.setLocaleFromJsonString(e), this;
  }
  get langOverride() {
    return this._langOverride;
  }
  getLang() {
    return this.langOverride !== "auto" ? this.langOverride : Xs;
  }
  getAvailableLangs() {
    return [...am];
  }
  async reset() {
    return await Promise.all(om.map((t) => C.delete(t))), this;
  }
  buildUrl(t, e = "", i = !1) {
    const s = i ? `?timestamp=${dr()}` : "";
    return `${t}${e}${s}`;
  }
  async changeLang(t) {
    return this.langOverride === t ? !1 : (await C.set("localeLangOverride", t), this._langOverride = t, this.lang = this.getLang(), await this.update(!0), !0);
  }
  async checkUpdates(t = !1) {
    try {
      const e = await nt(this.buildUrl(this.hashesUrl, "", t), {
        forceGmXhr: !0
      });
      if (!e.ok) throw e.status;
      const i = await e.json();
      if (!i || typeof i != "object")
        throw new Error("Invalid locale hashes payload");
      const s = i[this.lang];
      return typeof s != "string" || !s || await C.get("localeHash", "") === s ? !1 : s;
    } catch (e) {
      return console.error(
        "[VOT] [localizationProvider] Failed to get locales hash:",
        e
      ), null;
    }
  }
  async update(t = !1) {
    const e = cm(), i = await C.get(
      "localeVersion",
      ""
    );
    if (!t && i === e)
      return this;
    const s = await this.checkUpdates(t);
    if (s === null)
      return this;
    if (!s)
      return this;
    const o = dr();
    try {
      const r = await nt(
        this.buildUrl(this.localesUrl, `/${this.lang}.json`, t),
        { forceGmXhr: !0 }
      );
      if (!r.ok) throw r.status;
      const a = await r.text();
      this.setLocaleFromJsonString(a), await Promise.all([
        C.set("localePhrases", a),
        C.set("localeHash", s),
        C.set("localeLang", this.lang),
        C.set("localeVersion", e),
        C.set("localeUpdatedAt", o)
      ]);
    } catch (r) {
      console.error("[VOT] [localizationProvider] Failed to get locale:", r), this.setLocaleFromJsonString(await C.get("localePhrases", ""));
    }
    return this;
  }
  setLocaleFromJsonString(t) {
    const e = t.trim();
    if (!e)
      return this.locale = {}, this.warnedMissingKeys.clear(), this;
    try {
      const i = JSON.parse(e);
      if (!i || typeof i != "object" || Array.isArray(i))
        throw new Error("Locale payload should be a JSON object");
      this.locale = Pl(i);
    } catch (i) {
      console.error("[VOT] [localizationProvider]", i), this.locale = {};
    }
    return this.warnedMissingKeys.clear(), this;
  }
  getFromLocale(t, e, i = "locale") {
    return t[e] ?? this.warnMissingKey(t, e, i);
  }
  warnMissingKey(t, e, i) {
    const s = `${i}:${e}`;
    this.warnedMissingKeys.has(s) || (this.warnedMissingKeys.add(s), console.warn(
      "[VOT] [localizationProvider] locale",
      t,
      "doesn't contain key",
      e
    ));
  }
  getDefault(t) {
    return this.getFromLocale(this.defaultLocale, t, "default") ?? t;
  }
  get(t) {
    return this.getFromLocale(this.locale, t) ?? this.getDefault(t);
  }
  getLangLabel(t) {
    const e = `langs.${t}`;
    if (e in this.defaultLocale) {
      const i = this.get(e);
      if (i)
        return i;
    }
    return t.toUpperCase();
  }
}
const p = new um();
let Lr = null;
function dm() {
  return Lr ?? (Lr = p.init()), Lr;
}
const Qn = () => globalThis.self !== globalThis.top;
function hm() {
  const t = Object.entries({
    "https://dev.epicgames.com": {
      targetOrigin: "https://dev.epicgames.com",
      dataFilter: (e) => typeof e == "string" && e.startsWith("getVideoId:"),
      extractVideoId: (e) => e.pathname.split("/").at(-2) ?? null,
      responseFormatter: (e, i) => `${typeof i == "string" ? i : ""}:${e}`
    },
    "https://www.dailymotion.com": {
      targetOrigin: "https://geo.dailymotion.com",
      dataFilter: (e) => typeof e == "string" && e.startsWith("getVideoId:"),
      extractVideoId: (e) => /(?:^|\/)video\/([^/]+)/.exec(e.pathname)?.[1],
      responseFormatter: (e) => `getVideoId:${e}`
    }
  }).find(
    ([e]) => globalThis.location.origin === e
  )?.[1];
  t && globalThis.addEventListener("message", (e) => {
    try {
      if (e.origin !== t.targetOrigin || !t.dataFilter(e.data)) return;
      const i = t.extractVideoId(
        new URL(globalThis.location.href)
      );
      if (!i) return;
      const s = t.responseFormatter(i, e.data);
      e.source && "postMessage" in e.source && e.source.postMessage(
        s,
        t.targetOrigin
      );
    } catch (i) {
      console.error("Iframe communication error:", i);
    }
  });
}
let Ui = !1, Ue = null, xr = !1;
function fm() {
  return globalThis.location.origin === yn && globalThis.location.pathname === Gs;
}
async function Ar(n, t) {
  if (!Ui) {
    if (Ue !== null) {
      await Ue;
      return;
    }
    Ue = (async () => {
      if (t("Activating runtime", { reason: n }), fm()) {
        await nf(), Ui = !0;
        return;
      }
      Qn() || (await dm(), await p.update(), V.log(`Selected menu language: ${p.lang}`)), xr || (xr = !0, hm());
      function e() {
        const i = globalThis.location.hostname.toLowerCase();
        return i === "disk.yandex.ru" || i === "disk.yandex.com";
      }
      e() && Hd(), Wd(), Ui = !0;
    })();
    try {
      await Ue;
    } finally {
      Ue = null;
    }
  }
}
const Er = /* @__PURE__ */ new WeakSet(), Vr = /* @__PURE__ */ new WeakMap();
function Cr() {
  return /(?:^|\.)vkvideo\.ru$|(?:^|\.)vk\.(?:com|ru)$/i.test(
    String(globalThis.location.hostname || "")
  );
}
function fs(n) {
  if (!n.isConnected)
    return !1;
  const t = n.getBoundingClientRect();
  if (t.width < 64 || t.height < 64)
    return !1;
  const e = globalThis.getComputedStyle(n);
  return !(e.display === "none" || e.visibility === "hidden" || Number(e.opacity || "1") === 0);
}
function Ir(n) {
  const t = n.getBoundingClientRect();
  return Math.max(0, t.width) * Math.max(0, t.height);
}
function Pr(n) {
  if (n.currentSrc || n.src || n.srcObject)
    return !0;
  const t = n.querySelector("source");
  return !!(t?.getAttribute("src") || t?.src);
}
function gm(n) {
  const t = Array.from(n.querySelectorAll("track")).map((i, s) => {
    const o = String(i.src || i.getAttribute("src") || "").trim();
    if (!o)
      return null;
    let r = o;
    try {
      r = new URL(o, document.baseURI).href;
    } catch {
    }
    return {
      index: s,
      kind: String(i.kind || i.getAttribute("kind") || "").trim(),
      srclang: String(
        i.srclang || i.track?.language || i.getAttribute("srclang") || ""
      ).trim(),
      label: String(i.label || i.getAttribute("label") || "").trim(),
      url: r
    };
  }).filter((i) => !!i), e = t.map(
    (i) => [i.index, i.kind, i.srclang, i.label, i.url].join("|")
  ).join("||");
  if (Vr.get(n) !== e) {
    if (Vr.set(n, e), globalThis.__VOT_DETECTED_NATIVE_SUBTITLE_TRACKS__ = t, !t.length) {
      console.log("[VOT][subtitles][native] no <track> subtitle URLs detected for video");
      return;
    }
    console.log(
      `[VOT][subtitles][native] detected ${t.length} <track> subtitle URL(s). Inspect window.__VOT_DETECTED_NATIVE_SUBTITLE_TRACKS__.`
    ), console.table(t);
  }
}
function mm(n, t) {
  if (!n.isConnected)
    return !0;
  const e = Ir(n), i = Ir(t), s = fs(n), o = fs(t), r = Pr(n), a = Pr(t);
  return !!(!s && o || !r && a || i > e * 1.1);
}
function pm(n) {
  const {
    videoObserver: t,
    videosWrappers: e,
    ensureRuntimeActivated: i,
    getServicesCached: s,
    findContainer: o,
    createVideoHandler: r
  } = n;
  if (Er.has(t)) return;
  Er.add(t);
  const a = /* @__PURE__ */ new WeakSet(), l = /* @__PURE__ */ new WeakMap(), u = /* @__PURE__ */ new WeakMap(), d = /* @__PURE__ */ new WeakMap();
  let h = !1;
  const f = (k) => {
    const A = u.get(k);
    return A && l.get(A) === k && l.delete(A), u.delete(k), A ?? void 0;
  }, g = (k) => {
    k && d.delete(k);
  }, m = async (k, A) => {
    const $ = e.get(k);
    if ($)
      try {
        await $.release();
      } catch (H) {
        console.error(`[VOT] Failed to release videoHandler (${A})`, H);
      } finally {
        e.delete(k);
      }
  }, v = (k) => {
    for (const A of s()) {
      const $ = o(A, k);
      if ($)
        return { site: A, container: $ };
    }
    return null;
  }, T = (k) => {
    const A = String(k.host);
    return A === "peertube" || A === "directlink" ? { ...k, url: globalThis.location.origin } : k;
  }, S = (k) => k.host === "youtube" && !k.additionalData, w = (k) => {
    h || !S(k) || (h = !0, console.log(
      "[VOT][observer] disabling video discovery after first successful YouTube attach",
      {
        host: globalThis.location.hostname,
        path: globalThis.location.pathname
      }
    ), t.disable());
  }, x = async (k) => {
    if (!k)
      return;
    const A = d.get(k);
    A && (d.delete(k), !(!A.isConnected || e.has(A) || a.has(A)) && await I(A));
  }, I = async (k) => {
    if (!(e.has(k) || a.has(k))) {
      a.add(k);
      try {
        try {
          await i("video-detected");
        } catch (q) {
          console.error("[VOT] Failed to activate runtime", q);
          return;
        }
        gm(k);
        const A = v(k);
        if (!A) {
          if (Cr()) {
            const q = k.getBoundingClientRect();
            console.warn("[VOT][VK probe] video detected but no site/container match", {
              src: k.currentSrc || k.src || "",
              w: q.width,
              h: q.height,
              path: globalThis.location.pathname
            });
          }
          return;
        }
        const { site: $, container: H } = A;
        if (Cr()) {
          const q = k.getBoundingClientRect();
          console.log("[VOT][VK probe] matched video", {
            site: $.host,
            selector: $.selector,
            container: H?.tagName,
            classes: H?.className,
            w: q.width,
            h: q.height,
            src: k.currentSrc || k.src || ""
          });
        }
        if (($.host === "googledrive" || globalThis.location.hostname === "youtube.googleapis.com") && !fs(k))
          return;
        const _ = l.get(H);
        if (_ && _ !== k)
          if (_.isConnected)
            if (mm(_, k))
              await m(_, "smaller duplicate"), f(_);
            else {
              d.set(H, k);
              return;
            }
          else
            await m(_, "stale container"), f(_);
        const z = r(
          k,
          H,
          T($)
        );
        e.set(k, z), u.set(k, H), l.set(H, k), z.onPrimaryAttachReady = () => {
          e.get(k) === z && w($);
        };
        try {
          if (await z.init(), e.get(k) !== z)
            return;
          try {
            await z.setCanPlay(), e.get(k) === z && w($);
          } catch (q) {
            console.error("[VOT] Failed to get video data", q);
          }
        } catch (q) {
          if (e.get(k) === z) {
            await m(k, "init failed");
            const Y = f(k);
            g(Y), await x(Y);
          }
          console.error("[VOT] Failed to initialize videoHandler", q);
        }
      } finally {
        a.delete(k);
      }
    }
  };
  t.onVideoAdded.addListener(I), t.onVideoRemoved.addListener(async (k) => {
    const A = f(k);
    await m(k, "video removed"), a.delete(k), A && d.get(A) === k && g(A), await x(A);
  });
}
function Mr(n, t) {
  const e = String(n || "").trim();
  if (!e)
    return null;
  try {
    return new URL(e, t).toString();
  } catch {
    return e;
  }
}
function Js(n = globalThis.location.href) {
  try {
    const t = new URL(n, globalThis.location.href);
    if (!/\/player\.html$/i.test(t.pathname))
      return null;
    const e = Mr(t.searchParams.get("src"), t.toString()), i = Mr(
      t.searchParams.get("list"),
      t.toString()
    );
    return !e && !i ? null : {
      kind: "playlist-player",
      playerUrl: t.toString(),
      sourceUrl: e,
      playlistUrl: i,
      hasTranslationReadyCallback: !!i
    };
  } catch {
    return null;
  }
}
function bm(n) {
  return !!Js(n.toString());
}
const ym = [
  ".player",
  ".video-player",
  ".video_player",
  ".video-container",
  ".video-wrapper",
  ".player-container",
  ".player-wrapper",
  ".plyr",
  ".jwplayer",
  ".shaka-video-container",
  ".dplayer",
  ".artplayer",
  ".vjs-player",
  ".video-js",
  "[data-player]",
  "[data-player-container]",
  "[data-video-player]",
  "[data-testid*='player']",
  "[class*='player']",
  "[class*='Player']",
  "[class*='video-player']",
  "[class*='VideoPlayer']",
  "[class*='video-container']",
  "[id*='player']",
  "video-player",
  "video"
], lt = ym.join(", "), Or = ".videoplayer_media, vk-video-player", vm = 'div[data-testid="clipcontainer-video"], [data-testid="clipcontainer-video"]', wm = [
  {
    host: y.vk,
    url: "https://vk.com/video?z=",
    additionalData: "mobile",
    match: [/^m\.vk\.(com|ru)$/i, /^m\.vkvideo\.ru$/i],
    selector: Or,
    shadowRoot: !0,
    needExtraData: !0
  },
  {
    host: y.vk,
    url: "https://vk.com/video?z=",
    additionalData: "clips",
    match: /^(www\.|m\.)?vk\.(com|ru)$/i,
    selector: vm,
    needExtraData: !0
  },
  {
    host: y.vk,
    url: "https://vk.com/video?z=",
    match: [/^(www\.|m\.)?vk\.(com|ru)$/i, /^(.*\.)?vkvideo\.ru$/i],
    selector: Or,
    needExtraData: !0
  },
  {
    host: y.custom,
    url: "stub",
    match: (n) => bm(n),
    selector: lt,
    eventSelector: lt,
    rawResult: !0
  },
  {
    host: y.custom,
    url: "stub",
    match: /(^|\.)kodikplayer\.com$/i,
    selector: lt
  },
  {
    host: y.custom,
    url: "stub",
    match: /(^|\.)player\.cdnvideohub\.com$/i,
    selector: lt,
    rawResult: !0
  },
  {
    host: y.custom,
    url: "stub",
    match: /(^|\.)cdnvideohub\.com$/i,
    selector: lt,
    rawResult: !0
  },
  {
    host: y.custom,
    url: "stub",
    match: /(^|\.)okcdn\.ru$/i,
    selector: lt,
    rawResult: !0
  },
  {
    host: y.custom,
    url: "stub",
    match: /(^|\.)dailymotion\.com$/i,
    selector: lt,
    eventSelector: lt,
    rawResult: !0
  },
  {
    host: y.custom,
    url: "stub",
    match: /(^|\.)geo\.dailymotion\.com$/i,
    selector: lt,
    eventSelector: lt,
    rawResult: !0
  }
], Sm = /* @__PURE__ */ new Set(["youtube"]), Tm = /* @__PURE__ */ new Set(["youtube"]), km = /* @__PURE__ */ new Set(["youtube"]), Lm = /* @__PURE__ */ new Set([
  "vk",
  "googledrive",
  "yandexdisk"
]), xm = [
  /(?:^|\.)vkvideo\.ru$/i,
  /(?:^|\.)vk\.(?:com|ru)$/i,
  /^youtube\.googleapis\.com$/i,
  /^disk\.yandex\./i
], Am = /* @__PURE__ */ new Set([
  "vk",
  "googledrive",
  "yandexdisk"
]), Em = [
  /(?:^|\.)vkvideo\.ru$/i,
  /(?:^|\.)vk\.(?:com|ru)$/i,
  /^youtube\.googleapis\.com$/i,
  /^disk\.yandex\./i
];
function Vm(n) {
  const t = /* @__PURE__ */ new Set();
  for (const e of n) {
    if (e.shadowRoot !== !0)
      continue;
    const i = typeof e.selector == "string" ? e.selector.trim() : "";
    i && t.add(i);
  }
  return Array.from(t);
}
function Cm(n, t) {
  return new Set(t.map((i) => String(i.host || "").trim())).has("youtube") || /(?:^|\.)youtube(?:-nocookie|kids)?\.com$/i.test(n) ? ["video.html5-main-video, .html5-video-container video, .player-container video, video"] : ["video"];
}
function Im(n) {
  const t = String(n.hostname || "").trim().toLowerCase(), e = n.services, s = !e.some(
    (f) => Sm.has(String(f.host || "").trim())
  ), o = e.some(
    (f) => Tm.has(String(f.host || "").trim())
  ) ? "poll" : "mutation", r = e.some(
    (f) => km.has(String(f.host || "").trim())
  ), a = Cm(t, e), l = !e.some(
    (f) => Lm.has(String(f.host || "").trim())
  ) && !xm.some((f) => f.test(t)), u = s ? Vm(e) : [], d = u.length > 0, h = e.some(
    (f) => Am.has(String(f.host || "").trim())
  ) || Em.some(
    (f) => f.test(t)
  );
  return {
    preferProbeBootstrap: l,
    startDomObservationOnEnable: s,
    probeStrategy: o,
    probeSelectors: a,
    probePollIntervalMs: o === "poll" ? 120 : 0,
    probePollTimeoutMs: o === "poll" ? 4e3 : 0,
    stopAfterFirstVideoDetected: r,
    keepWatchingAfterVideoDetected: h,
    observeShadowRoots: d,
    shadowHostSelectors: u
  };
}
function Pm(n) {
  return n.isIframe ? n.origin === "null" : !1;
}
function Mm(n) {
  return Pm(n) ? "skip" : !n.isIframe && n.origin === n.authOrigin ? "auth-eager" : "lazy";
}
class Om {
  constructor({
    url: t,
    video: e,
    debug: i = !1,
    fetchFn: s = Ze.fetchFn,
    fetchOpts: o = {},
    preferAudio: r = !1
  }) {
    c(this, "_debug", !1);
    c(this, "audioContext");
    c(this, "player");
    c(this, "video");
    c(this, "fetchFn");
    c(this, "fetchOpts");
    this._debug = Ze.debug = i, this.fetchFn = s, this.fetchOpts = o, this.audioContext = r ? void 0 : zs(), this.player = r ? new Sl(this, t) : new Tl(this, t), this.video = e;
  }
  async init() {
    await this.player.init(), this.video && !this.video.paused && this.player.lipSync("play"), this.player.addVideoEvents();
  }
  set debug(t) {
    this._debug = Ze.debug = t;
  }
  get debug() {
    return this._debug;
  }
}
function Rl(n) {
  return n ? typeof ShadowRoot < "u" && n instanceof ShadowRoot ? n.host : n.parentNode ?? null : null;
}
function un(n, t) {
  let e = t;
  for (; e; ) {
    if (e === n) return !0;
    e = Rl(e);
  }
  return !1;
}
function Dm(n) {
  return n === document.body || n === document.documentElement;
}
function Zs(n, t, e = {}) {
  const { allowDocumentViewport: i = !1 } = e;
  if (!(n instanceof HTMLElement) || Dm(n) && !i)
    return null;
  for (const s of t)
    if (s && (un(n, s) || un(s, n)))
      return n;
  return null;
}
function _m(n, t) {
  if (!n || !t) return null;
  const e = n instanceof Document ? null : n, i = (s) => {
    if (!s) return null;
    if (s instanceof Document) {
      if (e) {
        const a = s.querySelectorAll(t);
        for (const l of a)
          if (un(l, e))
            return l;
        return null;
      }
      return s.querySelector(t);
    }
    const o = s.closest(t);
    if (o) return o;
    const r = s.getRootNode();
    if (r instanceof ShadowRoot)
      return i(r.host);
    if (r instanceof Document)
      return i(r);
    if (r !== s) {
      const a = Rl(r);
      if (a && a !== s && a instanceof Element)
        return i(a);
    }
    return null;
  };
  return i(n);
}
function Rm(n, t) {
  if (n !== t)
    return n;
  let e = t.parentElement;
  for (; e; ) {
    if (e !== document.body && e !== document.documentElement)
      return e;
    e = e.parentElement;
  }
  return n;
}
function ti(n, t) {
  if (!t)
    return null;
  const e = _m(n, t);
  return e instanceof HTMLElement && e.isConnected && un(e, n) ? Rm(e, n) : null;
}
function Bm(n, t) {
  return n instanceof HTMLVideoElement || t.host === "youtube" && t.additionalData !== "mobile" ? n.parentElement ?? n : n;
}
function Fm(n) {
  const t = Bm(n.container, n.site), e = n.fullscreenRoot ?? t, i = n.site.host === "googledrive" ? n.fullscreenRoot ?? document.body : e;
  return {
    base: t,
    root: e,
    portalContainer: t,
    subtitlesMountContainer: i
  };
}
function jt(n, t) {
  return n === "custom" || t === "custom";
}
function Nm(n) {
  return jt(n.siteHost, n.videoHost) || n.isStream || !n.hasAudioContext || !n.newAudioPlayer ? !0 : n.onlyBypassMediaCSP ? !n.needBypassCSP : !1;
}
function gs() {
  const n = globalThis.location.hostname.toLowerCase();
  return n === "drive.google.com" || n === "youtube.googleapis.com";
}
class U {
  constructor() {
    c(this, "listeners", /* @__PURE__ */ new Set());
  }
  get size() {
    return this.listeners.size;
  }
  addListener(t) {
    return this.listeners.add(t), this;
  }
  removeListener(t) {
    return this.listeners.delete(t), this;
  }
  dispatch(...t) {
    for (const e of this.listeners)
      try {
        e(...t);
      } catch (i) {
        console.error("[VOT]", i);
      }
  }
  async dispatchAsync(...t) {
    const e = [];
    for (const s of this.listeners)
      try {
        const o = s(...t);
        o && typeof o.then == "function" && e.push(Promise.resolve(o));
      } catch (o) {
        console.error("[VOT]", o);
      }
    if (!e.length)
      return;
    const i = await Promise.allSettled(e);
    for (const s of i)
      s.status === "rejected" && console.error("[VOT]", s.reason);
  }
  clear() {
    this.listeners.clear();
  }
}
function Dr(n, t, e, i) {
  return JSON.stringify({
    downloadType: n,
    itag: t,
    minChunkSize: i,
    fileSize: e
  });
}
function Qs(n) {
  return n?.toLowerCase() ?? "";
}
function Bl(n) {
  const t = Qs(n);
  return t.includes("audio/") && !t.includes("video/");
}
function Um(n) {
  const t = Qs(n);
  return t.includes("audio/mp4") && t.includes("mp4a.");
}
function _r(n) {
  const t = Qs(n);
  return t.includes("audio/webm") && t.includes("opus");
}
function Hm(n) {
  if (!n)
    return "mp4a.40.2";
  const t = /codecs="([^"]+)"/i.exec(n);
  if (!t?.[1])
    return "mp4a.40.2";
  const e = t[1].split(",").map((i) => i.trim());
  return e.find((i) => i.toLowerCase().startsWith("mp4a.")) ?? e[0] ?? "mp4a.40.2";
}
function $m(n, t) {
  let e = null, i = t === "max" ? -1 / 0 : 1 / 0;
  for (const s of n) {
    const o = s.bitrate ?? 0;
    (t === "max" && o > i || t === "min" && o < i) && (e = s, i = o);
  }
  return e;
}
function Wm(n, t) {
  const e = n.filter(
    (o) => Bl(o.mimeType)
  );
  if (!e.length)
    throw new Error("No adaptive audio formats were found in player response");
  const i = t === "bestefficiency" ? "min" : "max", s = t === "bestefficiency" ? [
    e.filter(
      (o) => _r(o.mimeType)
    ),
    e
  ] : [
    e.filter(
      (o) => Um(o.mimeType)
    ),
    e.filter(
      (o) => _r(o.mimeType)
    ),
    e
  ];
  for (const o of s) {
    if (!o.length)
      continue;
    const r = $m(o, i);
    if (r)
      return r;
  }
  throw new Error("No adaptive audio formats were found in player response");
}
class Fl extends Error {
  constructor(e = 403) {
    super(`Failed to load watch page: ${e}`);
    c(this, "status");
    this.name = "YtWatchContextForbiddenError", this.status = e;
  }
}
const He = /^[a-zA-Z0-9_-]{11}$/, Le = "https://www.youtube.com", zm = "19.44.38", qm = "1.60.19", Gm = "19.45.4", Rr = [
  "ANDROID_VR",
  "ANDROID",
  "IOS",
  "WEB",
  "MWEB"
], In = {
  accept: "*/*",
  origin: Le,
  referer: `${Le}/`
}, Br = 256 * 1024;
function Pn(n) {
  return n ? { signal: n } : {};
}
function Km(n, t, e) {
  switch (n) {
    case "ANDROID":
    case "YTMUSIC_ANDROID":
    case "YTSTUDIO_ANDROID":
      return {
        clientName: "ANDROID",
        clientVersion: zm,
        hl: "en",
        gl: "US",
        androidSdkVersion: 34,
        osName: "Android",
        osVersion: "14",
        platform: "MOBILE"
      };
    case "ANDROID_VR":
      return {
        clientName: "ANDROID_VR",
        clientVersion: qm,
        hl: "en",
        gl: "US",
        androidSdkVersion: 31,
        osName: "Android",
        osVersion: "12",
        platform: "MOBILE"
      };
    case "IOS":
      return {
        clientName: "IOS",
        clientVersion: Gm,
        hl: "en",
        gl: "US",
        platform: "MOBILE",
        osName: "iPhone",
        osVersion: "18.0.0.22A3354",
        deviceMake: "Apple",
        deviceModel: "iPhone16,2"
      };
    case "MWEB":
      return {
        clientName: "MWEB",
        clientVersion: t.clientVersion,
        hl: "en",
        gl: "US",
        originalUrl: `${Le}/watch?v=${e}`
      };
    default:
      return {
        clientName: "WEB",
        clientVersion: t.clientVersion,
        hl: "en",
        gl: "US",
        utcOffsetMinutes: 0,
        originalUrl: `${Le}/watch?v=${e}`
      };
  }
}
function Ym(n) {
  const t = n.trim();
  if (He.test(t))
    return t;
  let e;
  try {
    e = new URL(t);
  } catch {
    throw new Error(`Cannot extract YouTube video id from: ${n}`);
  }
  const i = e.hostname.toLowerCase();
  if (i === "youtu.be" || i.endsWith(".youtu.be")) {
    const l = e.pathname.split("/").find(Boolean);
    if (l && He.test(l))
      return l;
  }
  const s = e.searchParams.get("v");
  if (s && He.test(s))
    return s;
  const o = e.pathname.split("/").filter(Boolean), r = o.indexOf("shorts");
  if (r !== -1) {
    const l = o[r + 1];
    if (l && He.test(l))
      return l;
  }
  const a = o.indexOf("embed");
  if (a !== -1) {
    const l = o[a + 1];
    if (l && He.test(l))
      return l;
  }
  throw new Error(`Cannot extract YouTube video id from: ${n}`);
}
function jm(n) {
  return n.replaceAll("\\u0026", "&").replaceAll("\\/", "/");
}
function Xm(n) {
  const t = n.videoId ?? n.videoUrl;
  if (!t)
    throw new Error("Either videoId or videoUrl is required");
  return Ym(t);
}
function Mn(n, t) {
  for (const e of t) {
    const i = e.exec(n)?.[1];
    if (i)
      return i;
  }
}
async function Jm(n) {
  return new Uint8Array(await n.arrayBuffer());
}
function Zm(n = 16) {
  const t = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_";
  let e = "";
  if (typeof crypto < "u" && typeof crypto.getRandomValues == "function") {
    const i = new Uint8Array(n);
    crypto.getRandomValues(i);
    for (const s of i)
      e += t[s % t.length] ?? "a";
    return e;
  }
  for (let i = 0; i < n; i++)
    e += t[Math.floor(Math.random() * t.length)] ?? "a";
  return e;
}
function zn(n) {
  if (!n)
    return null;
  const t = Number.parseInt(n, 10);
  return !Number.isFinite(t) || t <= 0 ? null : t;
}
function Qm(n) {
  if (!n)
    return null;
  const t = /\/(\d+)\s*$/i.exec(n);
  return zn(t?.[1]);
}
function tp(n) {
  if (!n)
    return null;
  const t = /^bytes\s+(\d+)-(\d+)\/(?:\d+|\*)$/i.exec(
    n.trim()
  );
  if (!t)
    return null;
  const e = Number.parseInt(t[1] ?? "", 10), i = Number.parseInt(t[2] ?? "", 10);
  return !Number.isFinite(e) || !Number.isFinite(i) || e < 0 || i < e ? null : { start: e, end: i };
}
function ep(n, t) {
  return t - n + 1;
}
function np(n, t, e, i) {
  const s = ep(e, i);
  if (s <= 0 || t.byteLength <= 0 || t.byteLength > s)
    return !1;
  const o = tp(
    n.headers.get("content-range")
  );
  return o ? o.start === e && o.end === e + t.byteLength - 1 : n.status === 206 ? t.byteLength === s : n.status === 200 ? e === 0 && t.byteLength === s : !1;
}
function ip(n, t) {
  const e = n.headers.get("content-range") ?? "none", i = n.headers.get("content-length") ?? "none";
  return `status=${n.status}; bytes=${t.byteLength}; content-range=${e}; content-length=${i}`;
}
function sp(n) {
  const t = n?.toLowerCase() ?? "";
  return t.includes("audio/webm") ? "audio/webm" : t.includes("audio/mp4") ? "audio/mp4" : "audio/aac";
}
function op(n) {
  const t = n ? [n, ...Rr] : [...Rr], e = /* @__PURE__ */ new Set();
  return t.filter((i) => e.has(i) ? !1 : (e.add(i), !0));
}
let rp = class {
  constructor(t = {}) {
    c(this, "fetchFn");
    this.fetchFn = t.fetchImplementation ?? fetch;
  }
  async fetchRangeChunk(t, e, i, s) {
    const o = `bytes=${e}-${i}`, r = await this.fetchFn(t, {
      headers: {
        ...In,
        range: o
      },
      ...Pn(s)
    });
    if (!r.ok)
      throw new Error(`Failed to download stream chunk: ${r.status}`);
    const a = await Jm(r);
    if (!np(r, a, e, i))
      throw new Error(
        `Received unexpected stream chunk payload: ${ip(r, a)}`
      );
    return a;
  }
  async downloadStreamByRanges(t, e, i) {
    const s = await this.resolveStreamContentLength(
      t,
      e,
      i,
      !0
    ), o = new Uint8Array(s);
    let r = 0;
    for (let a = 0; a < s; a += Br) {
      const l = Math.min(s - 1, a + Br - 1), u = await this.fetchRangeChunk(t, a, l, i);
      if (r + u.byteLength > o.byteLength)
        throw new Error(
          "Downloaded stream chunk exceeds probed stream content length"
        );
      o.set(u, r), r += u.byteLength;
    }
    return r === o.byteLength ? o : o.slice(0, r);
  }
  async downloadAudioToChunkStream(t, e) {
    if (e.chunkSize <= 0)
      throw new RangeError("Audio downloader. ytAudio. chunkSize must be > 0");
    return this.withResolvedPlayableAudioFormat(
      t,
      t.videoQuality ?? "best",
      "Chunk mode requires an adaptive audio stream format",
      "Unable to resolve streamable format for chunk mode",
      async ({ resolved: i, signal: s }) => {
        const o = await this.resolveStreamContentLength(
          i.streamUrl,
          i.chosenFormat.contentLength,
          s,
          !0
        ), r = Math.max(
          1,
          Math.ceil(o / e.chunkSize)
        );
        return {
          videoId: i.videoId,
          fileSize: o,
          itag: i.chosenFormat.itag ?? 0,
          mediaPartsLength: r,
          getMediaBuffers: async function* () {
            for (let a = 0; a < r; a++) {
              const l = a * e.chunkSize, u = Math.min(o - 1, l + e.chunkSize - 1);
              yield await this.fetchRangeChunk(
                i.streamUrl,
                l,
                u,
                s
              );
            }
          }.bind(this)
        };
      }
    );
  }
  async downloadAudioToUint8Array(t) {
    const e = [];
    let i = 0;
    const s = await this.extractAndWriteAudio(t, {
      async write(a) {
        e.push(a), i += a.byteLength;
      }
    }), o = new Uint8Array(i);
    let r = 0;
    for (const a of e)
      o.set(a, r), r += a.byteLength;
    return {
      ...s,
      bytes: o
    };
  }
  async extractAndWriteAudio(t, e) {
    return this.withResolvedPlayableAudioFormat(
      t,
      t.videoQuality ?? "bestefficiency",
      "Selected stream is not audio-only",
      "Unable to download playable stream format",
      async ({ resolved: i, signal: s }) => {
        const o = await this.downloadStreamByRanges(
          i.streamUrl,
          i.chosenFormat.contentLength,
          s
        ), r = this.getExtractionHints(i.chosenFormat);
        return await e.write(o), {
          videoId: i.videoId,
          bytesWritten: o.byteLength,
          mimeType: sp(i.chosenFormat.mimeType),
          codec: r.codec,
          sampleRate: r.sampleRate,
          channels: r.channels
        };
      }
    );
  }
  async withResolvedPlayableAudioFormat(t, e, i, s, o) {
    const r = Xm(t), { signal: a } = t, l = await this.fetchWatchContext(r, a), u = op(t.client), d = [];
    for (const h of u)
      try {
        const f = await this.resolvePlayableFormatForClient({
          videoId: r,
          watchContext: l,
          client: h,
          quality: e,
          signal: a
        });
        if (!Bl(f.chosenFormat.mimeType))
          throw new Error(i);
        return await o({ resolved: f, signal: a });
      } catch (f) {
        const g = f instanceof Error ? f.message : String(f);
        d.push(`${h}: ${g}`);
      }
    throw new Error(`${s}. Attempts: ${d.join(" | ")}`);
  }
  async resolvePlayableFormatForClient({
    videoId: t,
    watchContext: e,
    client: i,
    quality: s,
    signal: o
  }) {
    const l = ((await this.fetchPlayerResponse(
      t,
      e,
      i,
      o
    )).streamingData?.adaptiveFormats ?? []).filter(
      (h) => !!h.url
    );
    if (!l.length)
      throw new Error(
        "Player response did not contain direct adaptive audio stream URLs"
      );
    const u = Wm(
      l,
      s
    ), d = this.resolveFormatUrl(
      u,
      e.clientVersion
    );
    return {
      videoId: t,
      chosenFormat: u,
      streamUrl: d
    };
  }
  async resolveStreamContentLength(t, e, i, s = !1) {
    const o = zn(e);
    if (o !== null && !s)
      return o;
    let r;
    try {
      r = await this.fetchFn(t, {
        headers: {
          ...In,
          range: "bytes=0-0"
        },
        ...Pn(i)
      });
    } catch (d) {
      if (o !== null)
        return o;
      const h = d instanceof Error ? d.message : String(d);
      throw new Error(`Failed to probe stream content length: ${h}`);
    }
    if (!r.ok) {
      if (o !== null)
        return o;
      throw new Error(
        `Failed to probe stream content length: ${r.status}`
      );
    }
    const a = Qm(
      r.headers.get("content-range")
    ), l = zn(
      r.headers.get("x-goog-stored-content-length")
    ), u = zn(
      r.headers.get("content-length")
    );
    if (typeof r.body?.cancel == "function")
      try {
        await r.body.cancel();
      } catch {
      }
    return a ?? l ?? o ?? u ?? (() => {
      throw new Error("Failed to resolve stream content length");
    })();
  }
  getExtractionHints(t) {
    const e = Hm(t.mimeType), i = Number.parseInt(t.audioSampleRate ?? "", 10);
    return {
      codec: e,
      sampleRate: Number.isFinite(i) && i > 0 ? i : 44100,
      channels: t.audioChannels && t.audioChannels > 0 ? t.audioChannels : 2
    };
  }
  resolveFormatUrl(t, e) {
    if (!t.url)
      throw new Error("Selected format does not contain a direct stream URL");
    const i = new URL(t.url);
    return i.searchParams.get("c") === "WEB" && i.searchParams.set("cver", e), i.searchParams.set("cpn", Zm()), i.toString();
  }
  async fetchWatchContext(t, e) {
    const i = `${Le}/watch?v=${encodeURIComponent(t)}&hl=en`, s = await this.fetchFn(i, {
      headers: In,
      ...Pn(e)
    });
    if (!s.ok)
      throw s.status === 403 ? new Fl(s.status) : new Error(`Failed to load watch page: ${s.status}`);
    const o = await s.text(), r = Mn(o, [
      /"INNERTUBE_API_KEY":"([^"]+)"/,
      /["']INNERTUBE_API_KEY["']\s*:\s*"([^"]+)"/
    ]), a = Mn(o, [
      /"INNERTUBE_CLIENT_VERSION":"([^"]+)"/,
      /["']INNERTUBE_CLIENT_VERSION["']\s*:\s*"([^"]+)"/
    ]), l = Mn(o, [/"STS":(\d+)/, /["']STS["']\s*:\s*(\d+)/]), u = Mn(o, [
      /"VISITOR_DATA":"([^"]+)"/,
      /"visitorData":"([^"]+)"/,
      /["'](?:VISITOR_DATA|visitorData)["']\s*:\s*"([^"]+)"/
    ]);
    if (!r || !a)
      throw new Error(
        "Failed to extract required player context from watch page"
      );
    const d = l ? Number.parseInt(l, 10) : void 0, h = {
      apiKey: r,
      clientVersion: a
    };
    return typeof d == "number" && Number.isFinite(d) && (h.signatureTimestamp = d), u && (h.visitorData = jm(u)), h;
  }
  async fetchPlayerResponse(t, e, i, s) {
    const o = Km(
      i,
      e,
      t
    );
    e.visitorData && (o.visitorData = e.visitorData);
    const r = {
      context: {
        client: o
      },
      videoId: t,
      contentCheckOk: !0,
      racyCheckOk: !0
    };
    e.signatureTimestamp && (r.playbackContext = {
      contentPlaybackContext: {
        signatureTimestamp: e.signatureTimestamp
      }
    });
    const a = `${Le}/youtubei/v1/player?key=${encodeURIComponent(e.apiKey)}`, l = await this.fetchFn(a, {
      method: "POST",
      headers: {
        ...In,
        "content-type": "application/json",
        ...e.visitorData ? { "x-goog-visitor-id": e.visitorData } : {}
      },
      body: JSON.stringify(r),
      ...Pn(s)
    });
    if (!l.ok)
      throw new Error(
        `Player API request failed with status ${l.status}`
      );
    const u = await l.json(), d = !!u.streamingData?.formats?.length, h = !!u.streamingData?.adaptiveFormats?.length;
    if (!d && !h)
      throw new Error("Player response did not contain streaming formats");
    return u;
  }
};
const Fr = "bestefficiency", ap = 3e4;
function lp(n) {
  if (n <= 0)
    throw new RangeError("Audio downloader. ytAudio. chunkSize must be > 0");
}
function cp({
  signal: n,
  timeoutMs: t
}) {
  return async (e, i = {}) => await nt(e, {
    ...i,
    signal: i.signal ?? n,
    forceGmXhr: !0,
    timeout: t
  });
}
function up(n) {
  return n instanceof Fl ? !0 : n instanceof Error && /failed to load watch page:\s*403/i.test(n.message);
}
async function dp({ videoId: n, signal: t }, e = {}) {
  const i = e.chunkSize ?? Q.minChunkSize;
  lp(i);
  const s = cp({
    signal: t,
    timeoutMs: e.fetchTimeoutMs ?? ap
  }), o = e.createDownloader?.(s) ?? new rp({ fetchImplementation: s });
  try {
    const d = await o.downloadAudioToChunkStream(
      {
        videoId: n,
        videoQuality: Fr,
        signal: t
      },
      { chunkSize: i }
    );
    return {
      fileId: Dr(
        on.WEB_API_STEAL_SIG_AND_N,
        d.itag,
        String(d.fileSize),
        i
      ),
      mediaPartsLength: d.mediaPartsLength,
      getMediaBuffers: d.getMediaBuffers
    };
  } catch (d) {
    if (up(d))
      throw d;
    console.warn(
      "[VOT] ytAudio streaming mode failed, falling back to buffered mode",
      d
    );
  }
  const a = (await o.downloadAudioToUint8Array({
    videoId: n,
    videoQuality: Fr,
    signal: t
  })).bytes;
  if (!a || a.byteLength === 0)
    throw new Error("Audio downloader. ytAudio. Empty audio");
  const l = Math.max(1, Math.ceil(a.byteLength / i));
  return {
    fileId: Dr(
      on.WEB_API_STEAL_SIG_AND_N,
      0,
      String(a.byteLength),
      i
    ),
    mediaPartsLength: l,
    async *getMediaBuffers() {
      for (let d = 0; d < a.byteLength; d += i) {
        const h = Math.min(d + i, a.byteLength);
        yield a.subarray(d, h);
      }
    }
  };
}
function hp(n, t) {
  return `yadisk_${n}_${t}_${Date.now()}`;
}
async function fp({
  videoId: n,
  signal: t
}) {
  const e = document.querySelector("video");
  if (!(e instanceof HTMLVideoElement))
    throw new Error("[VOT] Yandex Disk: video element not found");
  const i = e.currentSrc || e.src;
  if (!i)
    throw new Error("[VOT] Yandex Disk: empty video src");
  const s = await fetch(i, { signal: t });
  if (!s.ok)
    throw new Error(
      `[VOT] Yandex Disk: failed to fetch media source: ${s.status}`
    );
  V.log("[VOT] Yandex Disk strategy currentSrc:", e.currentSrc), V.log("[VOT] Yandex Disk strategy src:", e.src);
  const o = await s.arrayBuffer(), r = new Uint8Array(o);
  if (!r.byteLength)
    throw new Error("[VOT] Yandex Disk: empty audio/video bytes");
  const a = 256 * 1024, l = Math.max(1, Math.ceil(r.byteLength / a)), u = hp(r.byteLength, a);
  return V.log("[VOT] Yandex Disk strategy bytes:", r.byteLength), {
    fileId: u,
    mediaPartsLength: l,
    async *getMediaBuffers() {
      for (let d = 0; d < r.byteLength; d += a) {
        const h = Math.min(d + a, r.byteLength);
        yield r.subarray(d, h);
      }
    }
  };
}
function Nr(n, t) {
  return `local_${n}_${t}_${Date.now()}`;
}
async function gp(n, t) {
  if (!n)
    throw new Error("[VOT] Local file: empty media src");
  if (n.startsWith("blob:")) {
    const i = await fetch(n, { signal: t });
    if (!i.ok)
      throw new Error(
        `[VOT] Local file: failed to fetch blob media: ${i.status}`
      );
    return i;
  }
  try {
    const i = await fetch(n, { signal: t });
    if (i.ok)
      return i;
  } catch {
  }
  const e = await nt(n, { signal: t, timeout: 0 });
  if (!e.ok)
    throw new Error(
      `[VOT] Local file: failed to fetch media source: ${e.status}`
    );
  return e;
}
function mp(n) {
  const t = n.headers.get("content-length") || n.headers.get("Content-Length");
  if (!t) return null;
  const e = Number.parseInt(t, 10);
  return Number.isFinite(e) && e > 0 ? e : null;
}
async function pp({
  signal: n
}) {
  const t = document.querySelector("video");
  if (!(t instanceof HTMLVideoElement))
    throw new Error("[VOT] Local file: video element not found");
  const e = t.querySelector("source"), i = t.currentSrc || t.src || e?.src || e?.getAttribute("src") || "";
  if (!i)
    throw new Error("[VOT] Local file: empty video src");
  const s = await gp(i, n), o = 256 * 1024, r = mp(s);
  if (s.body && r) {
    const h = Math.max(
      1,
      Math.ceil(r / o)
    );
    return {
      fileId: Nr(r, o),
      mediaPartsLength: h,
      async *getMediaBuffers() {
        const g = s.body.getReader();
        let m = new Uint8Array(0);
        try {
          for (; ; ) {
            const { done: v, value: T } = await g.read();
            if (v) break;
            if (!T || !T.byteLength) continue;
            let S;
            m.byteLength === 0 ? S = T : (S = new Uint8Array(m.byteLength + T.byteLength), S.set(m, 0), S.set(T, m.byteLength));
            let w = 0;
            for (; S.byteLength - w >= o; )
              yield S.subarray(w, w + o), w += o;
            m = w < S.byteLength ? S.slice(w) : new Uint8Array(0);
          }
          m.byteLength && (yield m);
        } finally {
          g.releaseLock();
        }
      }
    };
  }
  const a = await s.arrayBuffer(), l = new Uint8Array(a);
  if (!l.byteLength)
    throw new Error("[VOT] Local file: empty media bytes");
  const u = Math.max(1, Math.ceil(l.byteLength / o));
  return {
    fileId: Nr(l.byteLength, o),
    mediaPartsLength: u,
    async *getMediaBuffers() {
      for (let h = 0; h < l.byteLength; h += o) {
        const f = Math.min(h + o, l.byteLength);
        yield l.subarray(h, f);
      }
    }
  };
}
const bp = [
  /\.m3u8(?:$|[?#])/i,
  /\.mpd(?:$|[?#])/i,
  /master\.m3u8/i,
  /manifest/i,
  /dashplaylist/i,
  /\.mp4(?:$|[?#])/i
];
function yp(n) {
  return bp.some((t) => t.test(n));
}
let Kt = null, Ur = !1;
function vp(n) {
  try {
    return new URL(n, globalThis.location.href).href;
  } catch {
    return n;
  }
}
function wp(n) {
  const t = n.toLowerCase();
  return t.includes("okcdn.ru/?") || /[?&]bytes=\d+-\d+/i.test(t) || /[?&]type=\d+/i.test(t);
}
function Hr(n) {
  const t = vp(n);
  if (wp(t) || !yp(t))
    return;
  if (console.log("[VOT][manifestSniffer] candidate", t), !Kt) {
    Kt = { url: t, seenAt: Date.now() }, console.log("[VOT][manifestSniffer] selected", Kt.url);
    return;
  }
  const e = $r(Kt.url);
  $r(t) >= e && (Kt = { url: t, seenAt: Date.now() }, console.log("[VOT][manifestSniffer] selected", Kt.url));
}
function $r(n) {
  let t = 0;
  return /\.mp4(?:$|[?#])/i.test(n) && (t += 5), /\.m3u8(?:$|[?#])/i.test(n) && (t += 4), /master\.m3u8/i.test(n) && (t += 3), /\.mpd(?:$|[?#])/i.test(n) && (t += 2), /manifest/i.test(n) && (t += 1), /dashplaylist/i.test(n) && (t += 1), /vkvd\d+\.okcdn\.ru|\.okcdn\.ru|vkvideo\.ru/i.test(n) && (t += 2), t;
}
function Nl() {
  return Kt?.url ?? "";
}
function Ul() {
  if (Ur)
    return;
  Ur = !0;
  const n = globalThis.fetch.bind(globalThis);
  globalThis.fetch = async (...e) => {
    const i = e[0], s = typeof i == "string" ? i : i instanceof Request ? i.url : String(i ?? "");
    return Hr(s), n(...e);
  };
  const t = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(e, i, ...s) {
    return Hr(String(i)), t.call(this, e, i, ...s);
  };
}
function Sp(n, t) {
  return `vk_${n}_${t}_${Date.now()}`;
}
function qn(n) {
  return /\.m3u8(?:$|[?#])/i.test(n);
}
function Tp(n, t) {
  return new URL(n, t).toString();
}
async function Hl(n, t) {
  try {
    const i = await fetch(n, {
      signal: t,
      credentials: "include"
    });
    if (i.ok) return i;
  } catch {
  }
  const e = await nt(n, {
    signal: t,
    timeout: 0
  });
  if (!e.ok)
    throw new Error(`[VOT] VK: failed to fetch media source: ${e.status}`);
  return e;
}
async function Wr(n, t) {
  return await (await Hl(n, t)).text();
}
async function zr(n, t) {
  const i = await (await Hl(n, t)).arrayBuffer();
  return new Uint8Array(i);
}
function qr(n, t) {
  return n.split(/\r?\n/).map((e) => e.trim()).filter((e) => e && !e.startsWith("#")).map((e) => Tp(e, t));
}
async function kp(n, t) {
  const e = await Wr(n, t), i = qr(e, n), s = i.find((o) => qn(o));
  if (s) {
    const o = await Wr(s, t);
    return qr(o, s).filter(
      (r) => !qn(r)
    );
  }
  return i.filter((o) => !qn(o));
}
async function Lp({
  videoId: n,
  signal: t
}) {
  const e = document.querySelector("video");
  if (!(e instanceof HTMLVideoElement))
    throw new Error("[VOT] VK: video element not found");
  const i = e.querySelector("source"), o = Nl() || e.currentSrc || e.src || i?.src || i?.getAttribute("src") || "";
  if (V.log("[VOT] VK strategy currentSrc:", e.currentSrc), V.log("[VOT] VK strategy src:", e.src), !o)
    throw new Error("[VOT] VK: empty video src");
  if (o.startsWith("blob:"))
    throw new Error(
      "[VOT] VK: blob source detected; need direct mp4/m3u8 URL from VK player/network"
    );
  const r = 256 * 1024;
  if (qn(o)) {
    const d = await kp(o, t);
    if (!d.length)
      throw new Error("[VOT] VK: empty m3u8 segment list");
    const h = `vk_hls_${Date.now()}`;
    return V.log("[VOT] VK strategy m3u8 segments:", d.length), {
      fileId: h,
      mediaPartsLength: d.length,
      async *getMediaBuffers() {
        for (const f of d) {
          const g = await zr(f, t);
          if (!g.byteLength)
            throw new Error("[VOT] VK: empty m3u8 segment");
          yield g;
        }
      }
    };
  }
  const a = await zr(o, t);
  if (!a.byteLength)
    throw new Error("[VOT] VK: empty media bytes");
  const l = Math.max(1, Math.ceil(a.byteLength / r)), u = Sp(a.byteLength, r);
  return V.log("[VOT] VK strategy bytes:", a.byteLength), {
    fileId: u,
    mediaPartsLength: l,
    async *getMediaBuffers() {
      for (let d = 0; d < a.byteLength; d += r) {
        const h = Math.min(d + r, a.byteLength);
        yield a.subarray(d, h);
      }
    }
  };
}
const Qe = "ytAudio", ms = "vkAudio", xp = {
  [Qe]: dp,
  [ms]: Lp,
  yandexDisk: fp,
  localFile: pp
};
function Ap(n) {
  if (!Number.isInteger(n) || n < 1)
    throw new Error("Audio downloader. Invalid media parts length");
}
function Gr(n) {
  if (!n || n.byteLength === 0)
    throw new Error("Audio downloader. Empty audio");
  return n;
}
async function Ep({
  audioDownloader: n,
  translationId: t,
  videoId: e,
  signal: i
}) {
  const s = await xp[n.strategy]({
    videoId: e,
    signal: i
  });
  if (!s)
    throw new Error("Audio downloader. Can not get audio data");
  V.log("Audio downloader. Url found", {
    audioDownloadType: n.strategy
  });
  const { getMediaBuffers: o, mediaPartsLength: r, fileId: a } = s;
  if (Ap(r), r < 2) {
    const u = o(), { value: d } = await u.next(), h = Gr(d);
    await n.onDownloadedAudio.dispatchAsync(t, {
      videoId: e,
      fileId: a,
      audioData: h
    });
    return;
  }
  let l = 0;
  for await (const u of o()) {
    const d = Gr(u);
    await n.onDownloadedPartialAudio.dispatchAsync(
      t,
      {
        videoId: e,
        fileId: a,
        audioData: d,
        version: 1,
        index: l,
        amount: r
      }
    ), l++;
  }
  if (l !== r)
    throw new Error(
      `Audio downloader. Expected ${r} chunks, got ${l}`
    );
}
class Vp {
  constructor(t = Qe) {
    c(this, "onDownloadedAudio", new U());
    c(this, "onDownloadedPartialAudio", new U());
    c(this, "onDownloadAudioError", new U());
    c(this, "strategy");
    this.strategy = t;
  }
  async runAudioDownload(t, e, i) {
    try {
      await Ep({
        audioDownloader: this,
        translationId: e,
        videoId: t,
        signal: i
      }), V.log("Audio downloader. Audio download finished", {
        videoId: t
      });
    } catch (s) {
      V.error("Audio downloader. Failed to download audio", {
        videoId: t,
        error: s instanceof Error ? s.message : String(s)
      }), this.onDownloadAudioError.dispatch(t);
    }
  }
  addEventListener(t, e) {
    switch (t) {
      case "downloadedAudio":
        this.onDownloadedAudio.addListener(e);
        break;
      case "downloadedPartialAudio":
        this.onDownloadedPartialAudio.addListener(e);
        break;
      case "downloadAudioError":
        this.onDownloadAudioError.addListener(e);
        break;
    }
    return this;
  }
  removeEventListener(t, e) {
    switch (t) {
      case "downloadedAudio":
        this.onDownloadedAudio.removeListener(e);
        break;
      case "downloadedPartialAudio":
        this.onDownloadedPartialAudio.removeListener(e);
        break;
      case "downloadAudioError":
        this.onDownloadAudioError.removeListener(e);
        break;
    }
    return this;
  }
}
const Cp = 0.66;
function Kr(n, t) {
  let e = Math.floor(n / 60);
  if (Math.floor(n % 60) / 60 >= Cp && (e += 1), e >= 60)
    return t("translationTakeMoreThanHour");
  if (e <= 1)
    return t("translationTakeAboutMinute");
  const o = String(e);
  return e !== 11 && e % 10 === 1 ? t("translationTakeApproximatelyMinute2").replace(
    "{0}",
    o
  ) : ![12, 13, 14].includes(e) && [2, 3, 4].includes(e % 10) ? t("translationTakeApproximatelyMinute").replace(
    "{0}",
    o
  ) : t("translationTakeApproximatelyMinutes").replace(
    "{0}",
    o
  );
}
class ft extends Error {
  constructor(e) {
    super(p.getDefault(e));
    c(this, "name", "VOTLocalizedError");
    /** Original (non-localized) message key. */
    c(this, "unlocalizedMessage");
    /** Resolved localized message. */
    c(this, "localizedMessage");
    this.unlocalizedMessage = e, this.localizedMessage = p.get(e);
  }
}
function to(n) {
  return n ?? null;
}
async function Ip(n, t) {
  const e = await n.translateVideoImpl(
    t.videoData,
    t.requestLang,
    t.responseLang,
    to(t.translationHelp),
    !t.useAudioDownload,
    t.signal
  );
  return e?.url ? {
    url: e.url,
    usedLivelyVoice: !!e.usedLivelyVoice
  } : null;
}
function Pp(n) {
  return {
    videoId: n.videoId,
    from: n.requestLang,
    to: n.responseLang,
    url: n.downloadTranslationUrl ?? n.fallbackUrl,
    useLivelyVoice: n.usedLivelyVoice
  };
}
async function $l(n) {
  return n.isActionStale(n.actionContext) || (await n.updateTranslation(n.url, n.actionContext), n.isActionStale(n.actionContext)) ? !1 : (n.scheduleTranslationRefresh(), !0);
}
async function Mp(n) {
  const t = await Ip(n.requester, {
    videoData: n.request.videoData,
    requestLang: n.request.requestLang,
    responseLang: n.request.responseLang,
    translationHelp: n.request.translationHelp,
    useAudioDownload: n.request.useAudioDownload,
    signal: n.request.signal
  });
  return !t || !await $l({
    url: t.url,
    actionContext: n.actionContext,
    isActionStale: n.isActionStale,
    updateTranslation: n.updateTranslation,
    scheduleTranslationRefresh: n.scheduleTranslationRefresh
  }) || n.isActionStale(n.actionContext) ? null : t;
}
function Op(n) {
  n.setTranslation(
    n.cacheKey,
    Pp({
      videoId: n.videoId,
      requestLang: n.requestLang,
      responseLang: n.responseLang,
      fallbackUrl: n.fallbackUrl,
      downloadTranslationUrl: n.downloadTranslationUrl,
      usedLivelyVoice: n.usedLivelyVoice
    })
  );
}
function ps(n) {
  return n.aborted || !n.translateApiErrorsEnabled || !n.hadAsyncWait ? n.hadAsyncWait : (n.notify({
    videoId: n.videoId,
    message: n.error
  }), !1);
}
function Wl(n) {
  if (!n || typeof n != "object")
    return null;
  const t = n, e = t.data && typeof t.data == "object" ? t.data : void 0;
  return {
    name: t.name,
    message: t.message,
    data: e
  };
}
function Yr(n) {
  const e = Wl(n)?.data?.message;
  return typeof e == "string" && e.length > 0 ? e : void 0;
}
function jr(n, t) {
  const e = Wl(n);
  if (!e || e.name !== "VOTJSError")
    return n;
  const i = typeof e.message == "string" ? e.message : "", s = typeof e.data?.message == "string" ? e.data.message : "";
  return console.log("[VOT][mapVotClientErrorForUi]", {
    siteHost: t,
    originalMessage: i,
    serverMessage: s,
    rawError: n
  }), i === "Audio link wasn't received" || i === "Audio link wasn't received from VOT response" ? new ft("audioNotReceived") : t === "yandexdisk" ? s ? new Error(s) : n : i === "Failed to request video translation" ? new ft("requestTranslationFailed") : i === "Yandex couldn't translate video" ? new ft("requestTranslationFailed") : n;
}
class Dp {
  constructor(t) {
    c(this, "videoHandler");
    c(this, "audioDownloader");
    c(this, "downloading");
    c(this, "downloadWaiters", /* @__PURE__ */ new Set());
    c(this, "requestedFailAudio", /* @__PURE__ */ new Set());
    c(this, "activeTranslationUrl");
    c(this, "activeYandexDiskResolvedVideoData");
    c(this, "onDownloadedAudio", async (t, e) => {
      if (!this.downloading)
        return;
      const { videoId: i, fileId: s, audioData: o } = e, r = this.getCanonicalUrl(i);
      try {
        console.log("[VOT] Uploading full audio", {
          translationId: t,
          videoId: i,
          fileId: s,
          size: o.byteLength,
          videoUrl: r
        }), await this.videoHandler.votClient.requestVtransAudio(
          r,
          t,
          {
            audioFile: o,
            fileId: s
          }
        );
      } catch {
        this.finishDownloadFailure(
          new Error("Audio downloader failed while uploading full audio")
        );
        return;
      }
      this.finishDownloadSuccess();
    });
    c(this, "onDownloadedPartialAudio", async (t, e) => {
      if (!this.downloading)
        return;
      const { audioData: i, fileId: s, videoId: o, amount: r, version: a, index: l } = e, u = this.getCanonicalUrl(o);
      try {
        console.log("[VOT] Uploading audio chunk", {
          translationId: t,
          videoId: o,
          fileId: s,
          index: l,
          amount: r,
          size: i.byteLength,
          videoUrl: u
        }), await this.videoHandler.votClient.requestVtransAudio(
          u,
          t,
          {
            audioFile: i,
            chunkId: l
          },
          {
            audioPartsLength: r,
            fileId: s,
            version: a
          }
        );
      } catch {
        this.finishDownloadFailure(
          new Error("Audio downloader failed while uploading chunk")
        );
        return;
      }
      l === r - 1 && this.finishDownloadSuccess();
    });
    c(this, "onDownloadAudioError", async (t) => {
      if (!this.downloading)
        return;
      const e = this.getCanonicalUrl(t), i = this.videoHandler.site.host === "youtube" && !!this.videoHandler.data?.useAudioDownload;
      if (console.log("[VOT] downloadAudioError host:", this.videoHandler.site.host), console.log("[VOT] downloadAudioError strategy:", this.audioDownloader.strategy), !i) {
        this.finishDownloadFailure(
          new ft("VOTFailedDownloadAudio")
        );
        return;
      }
      try {
        this.requestedFailAudio.has(e) ? V.log("fail-audio-js request already sent for this video") : (V.log("Sending fail-audio-js request"), await this.videoHandler.votClient.requestVtransFailAudio(e), this.requestedFailAudio.add(e)), this.finishDownloadSuccess();
      } catch {
        this.finishDownloadFailure(
          new ft("VOTFailedDownloadAudio")
        );
      }
    });
    this.videoHandler = t;
    const e = this.videoHandler.site.host === "vk" ? ms : this.videoHandler.site.host === "youtube" ? Qe : this.videoHandler.site.host === "yandexdisk" ? "yandexDisk" : this.videoHandler.site.host === "custom" ? "localFile" : Qe;
    this.audioDownloader = new Vp(e), this.downloading = !1, this.audioDownloader.addEventListener("downloadedAudio", this.onDownloadedAudio).addEventListener("downloadedPartialAudio", this.onDownloadedPartialAudio).addEventListener("downloadAudioError", this.onDownloadAudioError);
  }
  normalizeUrlForRequest(t) {
    try {
      return new URL(t, globalThis.location.href).toString();
    } catch {
      return String(t || "");
    }
  }
  normalizeOdyseeDirectUrl(t) {
    try {
      if (!t)
        return t;
      const e = t.match(
        /^https:\/\/player\.odycdn\.com\/api\/v3\/streams\/free\/[^/]+\/([a-f0-9]+)\/([^/?#]+\.mp4)(?:[?#].*)?$/i
      );
      if (e) {
        const i = e[1], s = e[2];
        return `https://player.odycdn.com/v6/streams/${i}/${s}`;
      }
    } catch {
    }
    return t;
  }
  getCurrentMediaRequestUrl(t) {
    return this.normalizeUrlForRequest(
      String(
        t?.url || this.videoHandler.video?.currentSrc || this.videoHandler.video?.src || globalThis.location.href
      )
    );
  }
  isHlsManifestUrl(t) {
    return /\.m3u8(?:[?#]|$)/i.test(String(t || ""));
  }
  isDirectMediaUrlCandidate(t) {
    if (!t || this.isHlsManifestUrl(t))
      return !1;
    try {
      return this.videoHandler.votClient.isDirectMediaUrl(t);
    } catch {
      return !1;
    }
  }
  isCrossOriginMediaUrl(t) {
    try {
      return new URL(t, globalThis.location.href).hostname !== globalThis.location.hostname;
    } catch {
      return !1;
    }
  }
  shouldUseLocalFileWorkflow(t) {
    if (!t)
      return !1;
    const e = this.getCurrentMediaRequestUrl(t);
    return this.isDirectMediaUrlCandidate(e) ? this.videoHandler.site.host === "custom" || t.host === "custom" ? !0 : this.isCrossOriginMediaUrl(e) : !1;
  }
  buildLocalFileWorkflowVideoData(t) {
    let e = this.getCurrentMediaRequestUrl(t);
    (this.videoHandler.site.host === "odysee" || t.host === "odysee") && (e = this.normalizeUrlForRequest(this.normalizeOdyseeDirectUrl(e)));
    const i = typeof t.videoId == "string" && t.videoId.trim().length > 0 ? t.videoId : e;
    return {
      ...t,
      host: "custom",
      url: e,
      videoId: i
    };
  }
  updateAudioDownloaderStrategy(t) {
    const e = t ? this.getCurrentMediaRequestUrl(t) : "", o = (this.videoHandler.site.host === "custom" || t?.host === "custom") && !this.isHlsManifestUrl(e) && this.isDirectMediaUrlCandidate(e) || this.shouldUseLocalFileWorkflow(t) ? "localFile" : this.videoHandler.site.host === "vk" ? ms : this.videoHandler.site.host === "yandexdisk" ? "yandexDisk" : Qe;
    this.audioDownloader.strategy !== o && (this.audioDownloader.strategy = o, console.log("[VOT][audio] switched downloader strategy", {
      siteHost: this.videoHandler.site.host,
      videoHost: t?.host,
      strategy: o,
      url: t?.url
    }));
  }
  isDirectResolvedUploadVideoData(t) {
    if (!t)
      return !1;
    const e = String(t.url || "");
    if (!e.length || this.isYandexDiskDownloadUrl(e))
      return !1;
    if (t.host === "yandexdisk")
      return !0;
    if (t.host === "custom")
      try {
        return this.videoHandler.votClient.isDirectMediaUrl(e);
      } catch {
        return !1;
      }
    return !1;
  }
  parseYandexDiskUrl(t) {
    const e = String(t || globalThis.location.href || "");
    try {
      const i = new URL(e, globalThis.location.href), s = i.pathname || "/", o = s.match(/^\/i\/([^/]+)$/i);
      if (o)
        return {
          mode: "file",
          origin: i.origin,
          pathname: s,
          fileId: o[1]
        };
      const r = s.match(/^\/d\/([^/]+)\/?$/i);
      if (r)
        return {
          mode: "folderRoot",
          origin: i.origin,
          pathname: s,
          folderId: r[1]
        };
      const a = s.match(/^\/d\/([^/]+)\/.+$/i);
      return a ? {
        mode: "folderFile",
        origin: i.origin,
        pathname: s,
        folderId: a[1]
      } : {
        mode: "unknown",
        origin: i.origin,
        pathname: s
      };
    } catch {
      return {
        mode: "unknown",
        origin: globalThis.location.origin,
        pathname: e.split("?")[0].split("#")[0]
      };
    }
  }
  normalizeYandexDiskPublicUrl(t) {
    const e = this.parseYandexDiskUrl(t);
    return e.mode === "file" && e.fileId ? `${e.origin}/i/${e.fileId}` : e.mode === "folderRoot" || e.mode === "folderFile" ? `${e.origin}${e.pathname}` : String(t || globalThis.location.href || "").split("?")[0].split("#")[0];
  }
  makeStableShortHash(t) {
    let e = 2166136261;
    for (let i = 0; i < t.length; i += 1)
      e ^= t.charCodeAt(i), e = Math.imul(e, 16777619);
    return (e >>> 0).toString(36);
  }
  extractYandexDiskPublicId(t) {
    try {
      const e = new URL(t, globalThis.location.href), i = e.pathname.match(/^\/i\/([^/]+)$/i);
      if (i)
        return i[1];
      const s = e.pathname.match(/^\/d\/([^/]+)(\/.*)?$/i);
      if (s) {
        const o = s[2] || "";
        return !o || o === "/" ? s[1] : `ydisk-${s[1]}-${this.makeStableShortHash(e.pathname)}`;
      }
      return `yandexdisk-${this.makeStableShortHash(e.pathname)}`;
    } catch {
      return `yandexdisk-${this.makeStableShortHash(String(t || "yandexdisk-public"))}`;
    }
  }
  extractYandexDiskPublicTarget(t) {
    try {
      const i = new URL(t, globalThis.location.href).pathname || "/", s = "https://disk.yandex.com", o = i.match(/^\/i\/([^/?#]+)$/i);
      if (o)
        return {
          url: `${s}/i/${o[1]}`,
          videoId: `/i/${o[1]}`
        };
      const r = i.match(/^\/d\/([^/?#]+)\/?$/i);
      return r ? {
        url: `${s}/d/${r[1]}`,
        videoId: `/d/${r[1]}`
      } : null;
    } catch {
      return null;
    }
  }
  extractYandexDiskPublicTargetFromMedia() {
    const t = (o) => this.extractYandexDiskPublicTarget(String(o || "")), e = String(globalThis.location.href || ""), i = this.parseYandexDiskUrl(e);
    if (i.mode === "file" && i.fileId)
      return {
        url: `${i.origin}/i/${i.fileId}`,
        videoId: i.fileId
      };
    const s = Array.from(document.querySelectorAll("video"));
    for (const o of s) {
      const r = o, a = [
        r.currentSrc || "",
        r.src || "",
        r.getAttribute("src") || ""
      ];
      for (const u of a) {
        const d = t(u);
        if (d)
          return d;
      }
      const l = Array.from(o.querySelectorAll("source"));
      for (const u of l) {
        const d = t(u.getAttribute("src") || "");
        if (d)
          return d;
      }
    }
    return null;
  }
  isYandexDiskFolderRootTarget(t, e) {
    if (!e.folderId)
      return !1;
    const i = `${e.origin}/d/${e.folderId}`;
    return t.videoId === e.folderId || t.url === i;
  }
  async gmGetJson(t) {
    return new Promise((e, i) => {
      GM_xmlhttpRequest({
        method: "GET",
        url: t,
        headers: {
          Accept: "application/json"
        },
        onload: (s) => {
          try {
            console.log("[VOT][yandexdisk] GM response", {
              url: t,
              status: s.status,
              responseText: String(s.responseText || "").slice(0, 1e3)
            }), e(JSON.parse(s.responseText || "null"));
          } catch (o) {
            i(o);
          }
        },
        onerror: (s) => i(s),
        ontimeout: () => i(new Error("Yandex Disk public API timeout"))
      });
    });
  }
  getYandexDiskServiceVideoId(t, e) {
    try {
      const s = new URL(t, globalThis.location.href).pathname || "";
      if (/^\/i\/[^/]+$/i.test(s) || /^\/d\/.+$/i.test(s))
        return s;
    } catch {
    }
    return e || String(t || "");
  }
  extractBridgeDirectMediaTarget() {
    try {
      const t = globalThis.__VOT_DIRECT_SOURCES__ || JSON.parse(document?.documentElement?.dataset?.votDirectSources || "null");
      if (!t || typeof t != "object")
        return null;
      const e = t, i = [
        e.hlsUrl,
        e.dashUrl,
        e.mpegLowUrl,
        e.url
      ].filter((s) => !!s);
      for (const s of i) {
        const o = this.normalizeUrlForRequest(s);
        if (o)
          try {
            if (this.videoHandler.votClient.isDirectMediaUrl(o))
              return {
                url: o,
                videoId: String(e.unitedVideoId || o),
                host: "custom",
                title: e.title || ""
              };
          } catch {
          }
      }
    } catch {
    }
    return null;
  }
  extractDirectMediaTargetFromVideo() {
    const t = document.querySelector("video");
    if (!(t instanceof HTMLVideoElement))
      return null;
    const e = [
      t.currentSrc || "",
      t.src || "",
      t.getAttribute("src") || ""
    ];
    for (const i of e) {
      const s = this.normalizeUrlForRequest(i);
      if (s)
        try {
          if (this.videoHandler.votClient.isDirectMediaUrl(s))
            return {
              url: s,
              videoId: s,
              host: "custom"
            };
        } catch {
        }
    }
    return null;
  }
  extractOdyseeMetaMediaTarget() {
    try {
      if (!/odysee\.com$/i.test(location.hostname))
        return null;
      const t = Array.from(
        document.querySelectorAll('script[type="application/ld+json"]')
      );
      for (const e of t) {
        const i = e.textContent || "";
        if (!i.includes('"contentUrl"'))
          continue;
        const s = JSON.parse(i), o = s?.contentUrl;
        if (typeof o == "string" && o) {
          const r = this.normalizeUrlForRequest(o);
          return {
            url: r,
            videoId: r,
            host: "custom",
            title: s?.name || document.title || ""
          };
        }
      }
    } catch {
    }
    return null;
  }
  async resolveYandexDiskFolderFileTargetViaApi(t) {
    if (t.mode !== "folderFile" || !t.folderId)
      return null;
    const e = t.pathname.replace(/^\/d\/[^/]+/, "") || "/";
    let i = e;
    try {
      i = decodeURIComponent(e);
    } catch {
      i = e;
    }
    const s = `${t.origin}/d/${t.folderId}`, o = new URL("https://cloud-api.yandex.com/v1/disk/public/resources");
    o.searchParams.set("public_key", s), o.searchParams.set("path", i);
    try {
      const r = await this.gmGetJson(o.toString());
      if (console.log("[VOT][yandexdisk] public API payload", {
        relativePathRaw: e,
        relativePath: i,
        publicKey: s,
        type: r?.type,
        path: r?.path,
        name: r?.name,
        public_url: r?.public_url,
        short_url: r?.short_url,
        file: r?.file
      }), !r || typeof r != "object")
        return null;
      if ("error" in r && r.error)
        return console.log("[VOT][yandexdisk] public API returned error", {
          error: r.error,
          message: r.message,
          description: r.description
        }), null;
      const a = [r.public_url, r.short_url].filter(
        (l) => typeof l == "string" && l.length > 0
      );
      for (const l of a) {
        const u = this.extractYandexDiskPublicTarget(l);
        if (!u)
          continue;
        if (this.isYandexDiskFolderRootTarget(u, t)) {
          console.log("[VOT][yandexdisk] skip folder-root target from API", {
            target: u,
            relativePath: i
          });
          continue;
        }
        const d = this.getYandexDiskServiceVideoId(
          u.url,
          t.pathname
        );
        return console.log("[VOT][yandexdisk] public target from API", {
          target: u,
          candidate: l,
          relativePath: i,
          serviceVideoId: d
        }), {
          url: u.url,
          videoId: d
        };
      }
      if (r.type === "file" && typeof r.file == "string" && r.file) {
        const l = this.normalizeUrlForRequest(r.file);
        return console.log("[VOT][yandexdisk] use direct file url from API", {
          directUrl: l,
          relativePath: i
        }), {
          url: l,
          videoId: l,
          host: "custom"
        };
      }
      if (r.type === "file")
        return console.log(
          "[VOT][yandexdisk] API did not return usable public target, continue fallback chain",
          {
            public_url: r.public_url,
            short_url: r.short_url,
            file: r.file,
            relativePath: i
          }
        ), null;
    } catch (r) {
      console.log("[VOT][yandexdisk] failed to resolve public target via API", {
        relativePathRaw: e,
        relativePath: i,
        publicKey: s,
        error: r
      });
    }
    return null;
  }
  isResolvedYandexDiskVideoData(t) {
    if (t.host !== "yandexdisk")
      return !1;
    const e = String(t.url || "");
    if (!e || this.isYandexDiskDownloadUrl(e))
      return !1;
    const i = this.parseYandexDiskUrl(e);
    return i.mode === "file" || i.mode === "folderRoot" || i.mode === "folderFile";
  }
  isYandexDiskDownloadUrl(t) {
    try {
      return new URL(t, globalThis.location.href).hostname === "downloader.disk.yandex.ru";
    } catch {
      return !1;
    }
  }
  isYandexDiskStreamUrl(t) {
    return /^https:\/\/streaming\.disk\.yandex\.net\/.+\.m3u8(?:[?#].*)?$/i.test(
      String(t || "")
    );
  }
  extractYandexDiskStreamTargetFromPlayerState() {
    const t = (o) => {
      if (typeof o != "string")
        return null;
      const r = this.normalizeUrlForRequest(o);
      return this.isYandexDiskStreamUrl(r) ? r : null;
    }, e = /* @__PURE__ */ new WeakSet(), i = (o, r) => {
      if (r < 0)
        return null;
      const a = t(o);
      if (a)
        return a;
      if (!o || typeof o != "object")
        return null;
      const l = o;
      if (e.has(l))
        return null;
      e.add(l);
      const u = [
        "streamUrl",
        "url",
        "stream",
        "streams",
        "source",
        "sources",
        "controller",
        "state",
        "playerState",
        "playerApiState",
        "internalInitialConfig",
        "config",
        "store",
        "redux"
      ];
      for (const h of u) {
        if (!(h in l))
          continue;
        const f = i(l[h], r - 1);
        if (f)
          return f;
      }
      const d = Array.isArray(l) ? l : Object.keys(l).slice(0, 50).map((h) => l[h]);
      for (const h of d) {
        const f = i(h, r - 1);
        if (f)
          return f;
      }
      return null;
    }, s = globalThis;
    for (const o of Object.keys(s)) {
      if (!/player|state|store|redux|disk|video|ya|vh/i.test(o))
        continue;
      const r = i(s[o], 6);
      if (r)
        return console.log("[VOT][yandexdisk] use stream url from deep player state", {
          key: o,
          url: r
        }), {
          url: r,
          videoId: r,
          host: "yandexdisk"
        };
    }
    return null;
  }
  extractYandexDiskStreamTargetFromPerformance() {
    try {
      const t = performance.getEntriesByType("resource");
      console.log("[VOT][yandexdisk] inspect performance resources", {
        count: t.length
      });
      for (let e = t.length - 1; e >= 0; e -= 1) {
        const i = t[e], s = String(i?.name || ""), o = this.normalizeUrlForRequest(s);
        if (this.isYandexDiskStreamUrl(o))
          return console.log("[VOT][yandexdisk] use stream url from performance", {
            url: o
          }), {
            url: o,
            videoId: o,
            host: "yandexdisk"
          };
      }
    } catch (t) {
      console.log("[VOT][yandexdisk] failed to inspect performance resources", {
        error: t
      });
    }
    return null;
  }
  async buildYandexDiskVideoData(t) {
    const e = this.extractBridgeDirectMediaTarget();
    if (e)
      return {
        ...t,
        ...e,
        host: "custom"
      };
    const i = this.extractOdyseeMetaMediaTarget();
    if (i)
      return {
        ...t,
        ...i,
        host: "custom"
      };
    const s = this.getYandexDiskSourceUrl(t), o = this.parseYandexDiskUrl(s);
    if (console.log("[VOT][yandexdisk] build source", {
      pageUrl: globalThis.location.href,
      videoDataUrl: t.url,
      sourceUrl: s,
      parsedMode: o.mode,
      videoId: t.videoId
    }), o.mode === "file" && o.fileId) {
      const u = `${o.origin}/i/${o.fileId}`;
      return {
        ...t,
        url: u,
        videoId: this.getYandexDiskServiceVideoId(u, o.pathname),
        host: "yandexdisk"
      };
    }
    if (o.mode === "folderFile") {
      const u = await this.resolveYandexDiskFolderFileTargetViaApi(o);
      if (u) {
        const f = this.normalizeUrlForRequest(u.url), g = u.host === "custom" ? f : this.getYandexDiskServiceVideoId(f, o.pathname);
        return console.log("[VOT][yandexdisk] resolved folder file target", {
          sourceUrl: s,
          resolvedUrl: f,
          videoId: g,
          host: u.host ?? "yandexdisk"
        }), {
          ...t,
          url: f,
          videoId: g,
          host: u.host ?? "yandexdisk"
        };
      }
      const d = this.extractYandexDiskStreamTargetFromPlayerState();
      if (d)
        return {
          ...t,
          url: d.url,
          videoId: d.videoId,
          host: "yandexdisk"
        };
      const h = this.extractYandexDiskStreamTargetFromPerformance();
      if (h)
        return {
          ...t,
          url: h.url,
          videoId: h.videoId,
          host: "yandexdisk"
        };
    }
    const r = this.extractYandexDiskPublicTarget(s);
    if (r)
      return {
        ...t,
        url: r.url,
        videoId: this.getYandexDiskServiceVideoId(r.url, o.pathname),
        host: "yandexdisk"
      };
    const a = this.extractYandexDiskPublicTargetFromMedia();
    if (a)
      return {
        ...t,
        url: a.url,
        videoId: this.getYandexDiskServiceVideoId(a.url, o.pathname),
        host: "yandexdisk"
      };
    const l = this.extractDirectMediaTargetFromVideo();
    if (l)
      return {
        ...t,
        url: l.url,
        videoId: l.videoId,
        host: "custom"
      };
    throw new Error("Failed to build Yandex Disk translation target");
  }
  finishDownloadSuccess() {
    this.downloading = !1, this.resolveDownloadWaiters();
  }
  finishDownloadFailure(t) {
    this.downloading = !1, this.rejectDownloadWaiters(t);
  }
  getCanonicalUrl(t) {
    return this.shouldUseLocalFileWorkflow(this.videoHandler.videoData) ? this.activeTranslationUrl || this.getCurrentMediaRequestUrl(this.videoHandler.videoData) : this.videoHandler.site.host === "youtube" ? `https://youtu.be/${t}` : this.videoHandler.site.host === "yandexdisk" ? this.activeTranslationUrl || this.normalizeYandexDiskPublicUrl(
      this.videoHandler.videoData?.url || globalThis.location.href
    ) : this.videoHandler.site.host === "custom" ? this.activeTranslationUrl || this.normalizeUrlForRequest(
      String(this.videoHandler.videoData?.url || globalThis.location.href)
    ) : this.videoHandler.videoData?.url || globalThis.location.href;
  }
  isLivelyVoiceUnavailableError(t) {
    const e = yi(t);
    return !!e && e.toLowerCase().includes("обычная озвучка");
  }
  scheduleRetry(t, e, i) {
    return new Promise((s, o) => {
      let r = null;
      const a = () => {
        r !== null && clearTimeout(r), i.removeEventListener("abort", l);
      }, l = () => {
        a(), o(re());
      };
      if (i.addEventListener("abort", l, { once: !0 }), i.aborted) {
        l();
        return;
      }
      r = setTimeout(async () => {
        if (i.aborted) {
          l();
          return;
        }
        a();
        try {
          const u = await t();
          s(u);
        } catch (u) {
          o(u);
        }
      }, e), r !== null && (this.videoHandler.autoRetry = r);
    });
  }
  async translateVideoYDImpl(t, e, i, s = null, o = hs, r = !1) {
    let a;
    this.updateAudioDownloaderStrategy(t);
    const l = this.getCurrentMediaRequestUrl(t);
    if (!this.isHlsManifestUrl(l) && (this.videoHandler.site.host === "custom" || t.host === "custom" || this.shouldUseLocalFileWorkflow(t)))
      a = this.buildLocalFileWorkflowVideoData(t);
    else {
      const d = this.activeYandexDiskResolvedVideoData && this.isDirectResolvedUploadVideoData(
        this.activeYandexDiskResolvedVideoData
      ) ? this.activeYandexDiskResolvedVideoData : void 0, h = this.isDirectResolvedUploadVideoData(t) ? t : void 0, f = d || h || await this.buildYandexDiskVideoData(t);
      a = {
        ...f,
        url: this.normalizeUrlForRequest(String(f.url || ""))
      };
    }
    if (a.host === "odysee" && typeof a.url == "string") {
      const d = this.normalizeOdyseeDirectUrl(a.url);
      a = d !== a.url ? {
        ...a,
        url: d,
        host: "custom"
      } : {
        ...a,
        url: this.normalizeUrlForRequest(a.url)
      };
    }
    a && typeof a.url == "string" && a.url && !/\/frame\/?$/i.test(a.url) && !/blob:/i.test(a.url) && (this.activeYandexDiskResolvedVideoData = a), this.activeTranslationUrl = a.url, console.log("[VOT][upload] translateVideoYDImpl input", {
      host: a.host,
      url: a.url,
      videoId: a.videoId
    });
    try {
      Bi(o);
      const d = !r && this.videoHandler.isLivelyVoiceAllowed(e, i) && !!this.videoHandler.data?.useLivelyVoice, h = await this.videoHandler.votClient.translateVideo({
        videoData: a,
        requestLang: e,
        responseLang: i,
        translationHelp: s,
        extraOpts: {
          useLivelyVoice: d,
          videoTitle: this.videoHandler.videoData?.title
        },
        shouldSendFailedAudio: !0
      });
      if (!h)
        throw new Error("Failed to get translation response");
      if (console.log("[VOT][upload] translate response", {
        translated: h.translated,
        status: h.status,
        remainingTime: h.remainingTime,
        message: h.message
      }), h.translated && (h.status === rt.FINISHED || h.status === rt.PART_CONTENT) && typeof h.url == "string" && h.url.length > 0)
        return { ...h, usedLivelyVoice: d };
      const f = h.message ?? p.get("translationTakeFewMinutes");
      if (await this.videoHandler.updateTranslationErrorMsg(
        h.remainingTime > 0 ? Kr(
          h.remainingTime,
          (g) => p.get(g)
        ) : f,
        o
      ), h.status === rt.AUDIO_REQUESTED && this.videoHandler.canUploadAudioForCurrentSite())
        return this.videoHandler.hadAsyncWait = !0, this.downloading = !0, await this.audioDownloader.runAudioDownload(
          a.videoId,
          h.translationId,
          o
        ), await this.waitForAudioDownloadCompletion(o, 12e4), await this.translateVideoYDImpl(
          a,
          e,
          i,
          s,
          o,
          r || !d
        );
      if (h.status === rt.WAITING || h.status === rt.LONG_WAITING) {
        this.videoHandler.hadAsyncWait = !0;
        const g = a.host === "custom" ? 15e3 : 5e3;
        return this.scheduleRetry(
          () => this.translateVideoYDImpl(
            a,
            e,
            i,
            s,
            o,
            r || !d
          ),
          g,
          o
        );
      }
      throw new Error(
        typeof h.message == "string" && h.message ? h.message : "Yandex couldn't translate video"
      );
    } catch (d) {
      if (ln(d))
        return null;
      const h = jr(d, this.videoHandler.site.host);
      return await this.videoHandler.updateTranslationErrorMsg(
        Yr(h) ?? h,
        o
      ), this.videoHandler.hadAsyncWait = ps({
        aborted: !!this.videoHandler.actionsAbortController?.signal?.aborted,
        translateApiErrorsEnabled: !!this.videoHandler.data?.translateAPIErrors,
        hadAsyncWait: this.videoHandler.hadAsyncWait,
        videoId: a.videoId,
        error: d,
        notify: (f) => this.videoHandler.notifier.translationFailed(f)
      }), console.error("[VOT][upload]", d), null;
    }
  }
  async translateVideoImpl(t, e, i, s = null, o = !1, r = hs, a = !1) {
    clearTimeout(this.videoHandler.autoRetry), this.finishDownloadSuccess();
    const l = this.videoHandler.getRequestLangForTranslation(
      e,
      i
    );
    let u = a;
    const d = this.shouldUseLocalFileWorkflow(t);
    if (this.updateAudioDownloaderStrategy(t), this.videoHandler.site.host === "yandexdisk" || this.videoHandler.site.host === "custom" || t.host === "custom" || d)
      return await this.translateVideoYDImpl(
        t,
        l,
        i,
        s,
        r
      );
    let h = t;
    if (this.videoHandler.site.host === "odysee" && typeof t.url == "string") {
      const f = this.normalizeUrlForRequest(t.url), g = this.normalizeOdyseeDirectUrl(f);
      h = g !== f ? {
        ...t,
        url: g,
        host: "custom"
      } : {
        ...t,
        url: f
      };
    }
    this.activeTranslationUrl = this.videoHandler.site.host === "odysee" ? h.url : this.getCanonicalUrl(t.videoId);
    try {
      Bi(r);
      const f = this.videoHandler.isLivelyVoiceAllowed(
        l,
        i
      );
      let g = !u && f && !!this.videoHandler.data?.useLivelyVoice, m;
      for (let T = 0; T < 2; T++) {
        try {
          m = await this.videoHandler.votClient.translateVideo({
            videoData: h,
            requestLang: l,
            responseLang: i,
            translationHelp: s,
            extraOpts: {
              useLivelyVoice: g,
              videoTitle: this.videoHandler.videoData?.title
            },
            shouldSendFailedAudio: o
          }), console.log("[VOT][translate] translate response", {
            translated: m.translated,
            status: m.status,
            remainingTime: m.remainingTime,
            message: m.message,
            requestHost: h.host,
            requestUrl: h.url
          });
        } catch (S) {
          if (g && this.isLivelyVoiceUnavailableError(S)) {
            V.log(
              "[translateVideoImpl] Lively voices are unavailable. Falling back to standard translation.",
              S
            ), u = !0, g = !1;
            continue;
          }
          throw S;
        }
        if (g && this.isLivelyVoiceUnavailableError(m)) {
          V.log(
            "[translateVideoImpl] Server responded that lively voices are unavailable. Falling back to standard translation.",
            m
          ), u = !0, g = !1, m = void 0;
          continue;
        }
        break;
      }
      if (!m)
        throw new Error("Failed to get translation response");
      if (V.log("Translate video result", m), console.log("[VOT] host:", this.videoHandler.site.host), console.log("[VOT] status:", m.status), console.log("[VOT] translated:", m.translated), console.log("[VOT] remainingTime:", m.remainingTime), console.log("[VOT] translationId:", m.translationId), console.log(
        "[VOT] canUploadAudio:",
        this.videoHandler.canUploadAudioForCurrentSite()
      ), console.log("[VOT] downloader strategy:", this.audioDownloader.strategy), this.videoHandler.site.host === "vk" && this.videoHandler.canUploadAudioForCurrentSite() && m.translationId && t.videoId && (V.log("[VOT][VK subtitles] force audio upload", {
        videoId: t.videoId,
        translationId: m.translationId,
        strategy: this.audioDownloader.strategy
      }), this.downloading = !0, this.audioDownloader.runAudioDownload(
        t.videoId,
        String(m.translationId),
        r
      ), await this.waitForAudioDownloadCompletion(r, 12e4)), Bi(r), m.translated && m.remainingTime < 1)
        return V.log("Video translation finished with this data: ", m), { ...m, usedLivelyVoice: g };
      const v = m.message ?? p.get("translationTakeFewMinutes");
      if (await this.videoHandler.updateTranslationErrorMsg(
        m.remainingTime > 0 ? Kr(
          m.remainingTime,
          (T) => p.get(T)
        ) : v,
        r
      ), m.status === rt.AUDIO_REQUESTED && this.videoHandler.canUploadAudioForCurrentSite())
        return this.videoHandler.hadAsyncWait = !0, V.log("Start audio download"), this.downloading = !0, await this.audioDownloader.runAudioDownload(
          t.videoId,
          m.translationId,
          r
        ), V.log("waiting downloading finish"), await this.waitForAudioDownloadCompletion(
          r,
          this.audioDownloader.strategy === "yandexDisk" ? 12e4 : 15e3
        ), await this.translateVideoImpl(
          t,
          e,
          i,
          s,
          !0,
          r,
          u
        );
    } catch (f) {
      if (ln(f))
        return null;
      const g = jr(f, this.videoHandler.site.host);
      return await this.videoHandler.updateTranslationErrorMsg(
        Yr(g) ?? g,
        r
      ), this.videoHandler.hadAsyncWait = ps({
        aborted: !!this.videoHandler.actionsAbortController?.signal?.aborted,
        translateApiErrorsEnabled: !!this.videoHandler.data?.translateAPIErrors,
        hadAsyncWait: this.videoHandler.hadAsyncWait,
        videoId: t.videoId,
        error: f,
        notify: (m) => this.videoHandler.notifier.translationFailed(m)
      }), console.error("[VOT]", f), null;
    }
    return this.videoHandler.hadAsyncWait = !0, this.scheduleRetry(
      () => this.translateVideoImpl(
        t,
        e,
        i,
        s,
        o,
        r,
        u
      ),
      2e4,
      r
    );
  }
  getYandexDiskSourceUrl(t) {
    const e = String(t.url || "");
    if (e && (this.isYandexDiskStreamUrl(e) || !this.isYandexDiskDownloadUrl(e) && this.parseYandexDiskUrl(e).mode !== "unknown"))
      return e;
    const i = String(globalThis.location.href || "");
    return this.parseYandexDiskUrl(i).mode !== "unknown" ? i : e || i;
  }
  waitForAudioDownloadCompletion(t, e) {
    return this.downloading ? new Promise((i, s) => {
      let o;
      const r = () => {
        l(), s(re());
      }, a = setTimeout(() => {
        l(), s(new Error("Audio download wait timeout"));
      }, e), l = () => {
        clearTimeout(a), t.removeEventListener("abort", r), this.downloadWaiters.delete(o);
      };
      o = {
        resolve: () => {
          l(), i();
        },
        reject: (u) => {
          l(), s(u);
        }
      }, this.downloadWaiters.add(o), t.addEventListener("abort", r, { once: !0 }), t.aborted && r();
    }) : Promise.resolve();
  }
  resolveDownloadWaiters() {
    this.forEachDownloadWaiter((t) => t.resolve());
  }
  rejectDownloadWaiters(t) {
    this.forEachDownloadWaiter((e) => e.reject(t));
  }
  forEachDownloadWaiter(t) {
    if (!this.downloadWaiters.size)
      return;
    const e = Array.from(this.downloadWaiters);
    this.downloadWaiters.clear();
    for (const i of e)
      t(i);
  }
}
class _p {
  constructor(t) {
    c(this, "state", { status: "idle" });
    c(this, "deps");
    this.deps = t;
  }
  get currentState() {
    return this.state;
  }
  setState(t) {
    this.state = t;
  }
  reset() {
    this.setState({ status: "idle" });
  }
  async runAutoTranslationIfEligible() {
    if (this.state.status === "idle" && this.deps.isFirstPlay() && this.deps.isAutoTranslateEnabled() && this.deps.getVideoId()) {
      if (this.deps.isMobileYouTubeMuted?.()) {
        this.setState({ status: "deferred", reason: "muted" }), this.deps.setMuteWatcher?.(() => {
          this.setState({ status: "idle" }), this.runAutoTranslationIfEligible();
        });
        return;
      }
      this.setState({ status: "pending", reason: "auto" });
      try {
        await this.deps.scheduleAutoTranslate(), this.deps.setFirstPlay(!1), this.reset();
      } catch (t) {
        throw this.setState({ status: "error", message: t }), t;
      }
    }
  }
}
function Rp(n, t = {}) {
  const { requireVideoData: e = !1, clearVideoData: i = !1 } = t;
  e && !n.videoData || (i && (n.videoData = void 0), n.stopTranslation(), n.resetSubtitlesWidget());
}
function Gn(n, t = {}) {
  const { hideMenu: e = !1 } = t;
  n?.votButton?.container && (n.votButton.container.hidden = !0), e && n?.votMenu && (n.votMenu.hidden = !0);
}
function zl(n, t, e = {}) {
  const { requireVideoData: i, clearVideoData: s, hideMenu: o } = e;
  Rp(n, {
    requireVideoData: i,
    clearVideoData: s
  }), Gn(t, { hideMenu: o });
}
function Bp() {
  return /(?:^|\.)vkvideo\.ru$|(?:^|\.)vk\.(?:com|ru)$/i.test(
    String(globalThis.location.hostname || "")
  );
}
class Fp {
  constructor(t) {
    c(this, "host");
    c(this, "lifecycleGeneration", 0);
    c(this, "lastSetCanPlaySourceKey", "");
    c(this, "activeSetCanPlaySourceKey", "");
    c(this, "setCanPlayRequested", !1);
    c(this, "setCanPlayLoopPromise");
    c(this, "deferredAutoStartupTimer");
    this.host = t;
  }
  isStale(t) {
    return t !== this.lifecycleGeneration;
  }
  resetActions(t) {
    if (typeof this.host.resetActionsAbortController == "function") {
      this.host.resetActionsAbortController(t);
      return;
    }
    this.host.actionsAbortController?.abort(t);
  }
  invalidateActiveSession(t) {
    this.clearDeferredAutoStartup(), this.lifecycleGeneration !== 0 && (this.lifecycleGeneration += 1, this.resetActions(`[VideoLifecycle] ${t}`), V.log(
      `[VideoLifecycle] cancelled active session (active: ${this.lifecycleGeneration})`,
      { reason: t }
    ));
  }
  startSession(t) {
    this.lifecycleGeneration += 1;
    const e = this.lifecycleGeneration;
    return this.resetActions(`[VideoLifecycle][session:${e}] ${t}`), e;
  }
  shouldAbortHandleSrcChanged(t, e) {
    return this.isStale(t) ? (V.log(
      `[VideoLifecycle][session:${t}] handleSrcChanged aborted at ${e} (active: ${this.lifecycleGeneration})`
    ), !0) : !1;
  }
  showOverlayButton(t) {
    t.votButton.container.hidden = !1, t.votButton.opacity = 1, this.host.queueOverlayAutoHide?.();
  }
  hasResolvableMediaSource() {
    const { video: t } = this.host;
    if (t.currentSrc || t.src || t.srcObject)
      return !0;
    const e = t.querySelector("source");
    return !!(e?.getAttribute("src") || e?.src);
  }
  teardown() {
    this.clearDeferredAutoStartup(), this.setCanPlayRequested = !1, this.invalidateActiveSession("teardown");
  }
  clearDeferredAutoStartup() {
    this.deferredAutoStartupTimer !== void 0 && (clearTimeout(this.deferredAutoStartupTimer), this.deferredAutoStartupTimer = void 0);
  }
  shouldDeferAutoStartup() {
    return this.host.site.host === "youtube" && !this.host.site.additionalData;
  }
  hasAutoStartupWork() {
    return !!(this.host.data.autoTranslate || this.host.data.autoSubtitles);
  }
  async runAutoStartupSequence(t, e) {
    if (e === "immediate") {
      const i = this.runAutoSubtitlesIfEnabled(t);
      if (await this.host.translationOrchestrator.runAutoTranslationIfEligible(), this.isStale(t))
        return;
      await i, this.isStale(t);
      return;
    }
    await this.host.translationOrchestrator.runAutoTranslationIfEligible(), !this.isStale(t) && (await this.runAutoSubtitlesIfEnabled(t), this.isStale(t));
  }
  scheduleDeferredAutoStartup(t, e) {
    this.hasAutoStartupWork() && (this.clearDeferredAutoStartup(), this.deferredAutoStartupTimer = globalThis.setTimeout(() => {
      this.deferredAutoStartupTimer = void 0, !this.isStale(t) && this.getCurrentSourceKey() === e && this.runAutoStartupSequence(t, "deferred").catch((i) => {
      });
    }, 800));
  }
  getCurrentSourceKey() {
    const t = this.host.video.srcObject ? "1" : "0";
    if (this.host.site.host === "youtube") {
      const i = globalThis.location.pathname;
      return `${`${globalThis.location.origin}${i}${globalThis.location.search}`}||${t}`;
    }
    const e = this.host.video.currentSrc || this.host.video.src || "";
    return `${globalThis.location.href}||${e}||${t}`;
  }
  resolveContainer() {
    const { site: t, video: e, container: i } = this.host;
    if (!t.selector)
      return e.parentElement ?? i;
    const s = ti(e, t.selector);
    return s || (i.isConnected && un(i, e) ? i : e.parentElement ?? i);
  }
  async setCanPlay() {
    if (this.setCanPlayRequested = !0, this.setCanPlayLoopPromise !== void 0) {
      const e = this.getCurrentSourceKey();
      return this.activeSetCanPlaySourceKey && e !== this.activeSetCanPlaySourceKey && this.invalidateActiveSession(
        "setCanPlay source changed while previous trigger is running"
      ), await this.setCanPlayLoopPromise;
    }
    const t = (async () => {
      for (; this.setCanPlayRequested; )
        this.setCanPlayRequested = !1, await this.runSetCanPlayOnce();
    })();
    this.setCanPlayLoopPromise = t;
    try {
      await t;
    } finally {
      this.setCanPlayLoopPromise === t && (this.setCanPlayLoopPromise = void 0);
    }
  }
  async runSetCanPlayOnce() {
    const t = this.getCurrentSourceKey();
    if (this.host.videoData?.videoId && t === this.lastSetCanPlaySourceKey) {
      if (this.shouldDeferAutoStartup())
        return;
      await this.runAutoSubtitlesIfEnabled(this.lifecycleGeneration);
      return;
    }
    let e;
    try {
      e = await this.host.getVideoData();
    } catch {
      this.host.videoData = void 0, this.hasResolvableMediaSource() ? this.showOverlayButton(this.host.uiManager.votOverlayView) : Gn(this.host.uiManager.votOverlayView, {
        hideMenu: !0
      });
      return;
    }
    if (this.getCurrentSourceKey() !== t)
      return;
    this.host.videoData = e, Bp() && console.log("[VOT][VK probe] videoData", {
      videoId: e?.videoId,
      host: e?.host,
      url: e?.url,
      duration: e?.duration,
      subtitles: Array.isArray(e?.subtitles) ? e.subtitles.length : null
    }), this.activeSetCanPlaySourceKey = t;
    const i = this.startSession(`setCanPlay (source: ${t})`);
    try {
      if (await this.handleSrcChanged(i, t), this.isStale(i)) {
        V.log(
          `[VideoLifecycle][session:${i}] setCanPlay aborted after src change (active: ${this.lifecycleGeneration})`
        );
        return;
      }
      if (this.shouldDeferAutoStartup()) {
        this.scheduleDeferredAutoStartup(i, t), V.log(
          `[VideoLifecycle][session:${i}] deferred auto startup scheduled`,
          { sourceKey: t }
        );
        return;
      }
      await this.runAutoStartupSequence(i, "immediate"), V.log(`[VideoLifecycle][session:${i}] setCanPlay finished`);
    } finally {
      this.activeSetCanPlaySourceKey === t && (this.activeSetCanPlaySourceKey = "");
    }
  }
  async runAutoSubtitlesIfEnabled(t) {
    if (!(!this.host.data.autoSubtitles || !this.host.videoData?.videoId))
      try {
        await this.host.enableSubtitlesForCurrentLangPair();
      } catch {
      }
  }
  async handleSrcChanged(t, e) {
    const i = typeof t == "number" ? t : this.startSession("manual handleSrcChanged"), s = typeof e == "string" && e.length > 0 ? e : this.getCurrentSourceKey();
    if (this.shouldAbortHandleSrcChanged(i, "before start"))
      return;
    this.host.translationOrchestrator.reset(), this.host.firstPlay = !0;
    const o = this.host.uiManager.votOverlayView;
    zl(this.host, o, { requireVideoData: !0 }), !this.host.video.src && !this.host.video.currentSrc && !this.host.video.srcObject && Gn(o, { hideMenu: !0 });
    const a = this.resolveContainer();
    if (a !== this.host.container && (this.host.container = a), this.shouldAbortHandleSrcChanged(i, "before getVideoData") || (this.showOverlayButton(o), this.shouldAbortHandleSrcChanged(i, "after getVideoData")))
      return;
    if (!this.host.videoData?.videoId) {
      this.hasResolvableMediaSource() ? this.showOverlayButton(o) : Gn(o, { hideMenu: !0 });
      return;
    }
    const l = this.host.getSubtitlesCacheKey(
      this.host.videoData.videoId,
      this.host.videoData.detectedLanguage,
      this.host.videoData.responseLanguage
    ), u = this.host.cacheManager.getSubtitles(l);
    this.host.subtitles = u ?? [], this.host.subtitlesCacheKey = u !== void 0 ? l : null, await this.host.updateSubtitlesLangSelect(), !this.shouldAbortHandleSrcChanged(i, "after subtitles update") && (this.host.translateToLang = this.host.data.responseLanguage ?? "ru", this.host.setSelectMenuValues(
      this.host.videoData.detectedLanguage,
      this.host.videoData.responseLanguage
    ), this.showOverlayButton(o), this.lastSetCanPlaySourceKey = s, this.host.onPrimaryAttachReady?.());
  }
}
const Np = 450, Up = new RegExp(
  [
    // URLs.
    String.raw`(?:https?:\/\/|www\.)\S+`,
    String.raw`#[^\s#]+`,
    String.raw`auto-generated\s+by\s+youtube`,
    String.raw`provided\s+to\s+youtube\s+by`,
    String.raw`released\s+on`,
    String.raw`\bpaypal\b`,
    String.raw`\b0x[a-f0-9]{40}\b`,
    // Bitcoin legacy Base58 (mainnet P2PKH/P2SH).
    String.raw`\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b`,
    // Bitcoin Bech32 / Bech32m.
    String.raw`\b(?:bc1|tb1|bcrt1)[ac-hj-np-z02-9]{11,71}\b`,
    // TON raw format.
    String.raw`\b(?:-1|0):[a-f0-9]{64}\b`
  ].join("|"),
  "giu"
), Hp = /[\p{N}\p{P}\p{S}]+/gu, $p = /\s+/g, Wp = /\p{L}/u;
function zp(n, t) {
  return n.length <= t ? n : n.slice(0, t).trimEnd();
}
function qp(n, t) {
  const e = `${n ?? ""} ${t ?? ""}`.trim();
  if (!e) return "";
  const i = e.normalize("NFKC").replace(Up, " ").replace(Hp, " ").replace($p, " ").trim();
  return Wp.test(i) ? zp(i, Np) : "";
}
const ql = 5e3, Gl = Number.MAX_SAFE_INTEGER;
let On = null, Xr = 0, Dn = null, Jr = 0;
async function Gp() {
  const n = Date.now();
  if (On && n - Xr < ql)
    return On;
  const t = await C.get(
    "translationService",
    bi
  );
  return On = String(t), Xr = n, On;
}
async function Kp() {
  const n = Date.now();
  if (Dn && n - Jr < ql)
    return Dn;
  const t = await C.get("detectService", Ks);
  return Dn = String(t), Jr = n, Dn;
}
const Kl = ["yandexbrowser", "msedge"], bs = new class {
  isFOSWLYError(n) {
    return Object.hasOwn(n, "error");
  }
  async request(n, t = {}) {
    try {
      const i = await (await nt(`${Kd}${n}`, {
        ...t,
        timeout: 3e3,
        forceGmXhr: !0,
        responseCache: {
          ttlMs: Gl,
          cacheName: "vot-foswly-api-v1",
          allowStaleOnError: !0
        }
      })).json();
      if (this.isFOSWLYError(i))
        throw new Error(i.error);
      return i;
    } catch (e) {
      console.error(
        `[VOT] Failed to get data from FOSWLY Translate API, because ${e instanceof Error ? e.message : String(e)}`
      );
      return;
    }
  }
  async translateMultiple(n, t, e) {
    const i = await this.request(
      "/translate",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          text: n,
          lang: t,
          service: e
        })
      }
    );
    return i ? i.translations : n;
  }
  async translate(n, t, e) {
    const i = await this.request(
      `/translate?${new URLSearchParams({
        text: n,
        lang: t,
        service: e
      })}`
    );
    return i ? i.translations[0] : n;
  }
  async detect(n, t) {
    const e = await this.request(
      `/detect?${new URLSearchParams({
        text: n,
        service: t
      })}`
    );
    return e ? e.lang : "en";
  }
}(), Yp = {
  async detect(n) {
    try {
      return await (await nt(Yd, {
        method: "POST",
        body: n,
        timeout: 3e3,
        forceGmXhr: !0,
        responseCache: {
          ttlMs: Gl,
          cacheName: "vot-rust-detect-v1",
          allowStaleOnError: !0
        }
      })).text();
    } catch (t) {
      return console.error(
        `[VOT] Error getting lang from text, because ${t.message}`
      ), "en";
    }
  }
};
async function ys(n, t = "", e = "ru") {
  if (t && e && t === e)
    return n;
  const i = await Gp();
  switch (i) {
    case "yandexbrowser":
    case "msedge": {
      const s = t && e ? `${t}-${e}` : e;
      return Array.isArray(n) ? await bs.translateMultiple(n, s, i) : await bs.translate(n, s, i);
    }
    default:
      return n;
  }
}
async function jp(n) {
  const t = await Kp();
  switch (t) {
    case "yandexbrowser":
    case "msedge":
      return await bs.detect(n, t);
    case "rust-server":
      return await Yp.detect(n);
    default:
      return "en";
  }
}
const Xp = [...Kl, "rust-server"], Jp = 0, Zp = 100, ei = 0.01, Zr = 1e-6;
function xe(n, t, e) {
  return !Number.isFinite(n) || e < t ? t : Math.max(t, Math.min(e, n));
}
function vs(n, t, e) {
  return Math.trunc(xe(n, t, e));
}
function At(n, t = Jp, e = Zp) {
  return Number.isFinite(n) ? vs(Math.round(n), t, e) : t;
}
function Yl(n) {
  const t = xe(n, 0, 1);
  return At(t * 100);
}
function Qp(n) {
  return At(n) / 100;
}
function tb(n, t, e) {
  if (!Number.isFinite(n) || !Number.isFinite(t) || t <= 0) return n;
  const i = 1 / t, s = n * i;
  switch (e) {
    case "down":
      return Math.floor(s + Zr) / i;
    case "up":
      return Math.ceil(s - Zr) / i;
    default:
      return Math.round(s) / i;
  }
}
function ne(n, t = "nearest", e = ei) {
  const i = xe(n, 0, 1), s = tb(i, e, t);
  return xe(s, 0, 1);
}
function eb(n, t, e, i = ei) {
  const s = xe(t, 0, 1), o = xe(e, 0, 1);
  if (o < s) {
    const r = ne(n, "down", i);
    return Math.max(o, r);
  }
  if (o > s) {
    const r = ne(n, "up", i);
    return Math.min(o, r);
  }
  return ne(n, "nearest", i);
}
const jl = /* @__PURE__ */ new Set(["youtube", "googledrive"]), nb = jl, ib = /* @__PURE__ */ new Set(["rutube", "ok"]), sb = /* @__PURE__ */ new Set([
  "youtube",
  "invidious",
  "piped"
]);
function _n(n) {
  return jl.has(n);
}
function Xl(n) {
  return nb.has(n);
}
function ob(n) {
  return ib.has(n);
}
function Jl(n) {
  return Xl(n.host) && n.additionalData !== "mobile";
}
function rb(n) {
  return sb.has(n);
}
function ab() {
  const n = Array.from(
    document.querySelectorAll('script[type="application/ld+json"]')
  );
  for (const t of n) {
    const e = t.textContent?.trim();
    if (e)
      try {
        const i = JSON.parse(e), s = Array.isArray(i) ? i : [i];
        for (const o of s)
          if (!(!o || typeof o != "object") && o["@type"] === "VideoObject")
            return {
              contentUrl: typeof o.contentUrl == "string" ? o.contentUrl : void 0,
              embedUrl: typeof o.embedUrl == "string" ? o.embedUrl : void 0,
              pageUrl: typeof o.url == "string" ? o.url : void 0,
              title: typeof o.name == "string" ? o.name : void 0
            };
      } catch {
      }
  }
  return null;
}
function de(n, t) {
  const e = String(n || "").trim();
  if (!e)
    return t;
  try {
    const i = new URL(e, globalThis.location.href);
    return i.hash = "", i.toString();
  } catch {
    return e;
  }
}
function Hi(n) {
  const t = n.filter(Boolean).map((s) => String(s).trim()).filter(Boolean), e = (s) => {
    const o = s.toLowerCase();
    return o.includes("thumbnails.") || o.includes("/speech/") || o.endsWith(".jpg") || o.endsWith(".jpeg") || o.endsWith(".png") || o.endsWith(".webp") || o.includes("okcdn.ru/?") || /[?&]bytes=\d+-\d+/i.test(o) || /[?&]type=\d+/i.test(o);
  }, i = t.filter((s) => !e(s));
  return i.find((s) => /\.m3u8([?#]|$)/i.test(s)) || i.find((s) => /\.mpd([?#]|$)/i.test(s)) || i.find((s) => /\.mp4([?#]|$)/i.test(s)) || i.find((s) => /\/streams\//i.test(s)) || null;
}
function lb(n) {
  const t = [
    String(n?.hlsUrl || "").trim(),
    String(n?.dashUrl || "").trim(),
    String(n?.mpegLowUrl || "").trim(),
    String(n?.url || "").trim()
  ].filter(Boolean);
  return t.find((e) => /\.m3u8([?#]|$)/i.test(e)) || t.find((e) => /\.mpd([?#]|$)/i.test(e)) || t.find((e) => /\.mp4([?#]|$)/i.test(e)) || t[0] || "";
}
function $e(n) {
  const t = String(n || "").toLowerCase();
  return !t || t.startsWith("blob:") || t.includes("thumbnails.") || t.includes("/speech/") || t.endsWith(".jpg") || t.endsWith(".jpeg") || t.endsWith(".png") || t.endsWith(".webp") || t.includes("okcdn.ru/?") || /[?&]bytes=\d+-\d+/i.test(t) || /[?&]type=\d+/i.test(t);
}
async function cb(n, t) {
  const e = Js(t);
  if (e) {
    const o = performance.getEntriesByType("resource").map((d) => typeof d.name == "string" ? d.name : "").filter(Boolean), r = Hi(o), a = document.querySelector("video"), l = String(a?.currentSrc || a?.src || "").trim(), u = ($e(e.sourceUrl || "") ? "" : String(e.sourceUrl)) || ($e(l) ? "" : l) || e.playerUrl;
    return console.log("[VOT][custom][tunnel] resolved tunnel player source", {
      playerUrl: e.playerUrl,
      sourceUrl: e.sourceUrl,
      playlistUrl: e.playlistUrl,
      currentSrc: l,
      resourceUrl: r,
      resolvedUrl: u
    }), {
      url: u,
      videoId: de(
        u || e.sourceUrl || t,
        e.sourceUrl || u || t
      ),
      title: document.title
    };
  }
  let i = globalThis.__VOT_DIRECT_SOURCES__;
  if (!i)
    try {
      const s = document.documentElement.dataset.votDirectSources;
      s && (i = JSON.parse(s));
    } catch {
    }
  if (i && typeof i == "object") {
    const s = lb(i), o = String(i.unitedVideoId || t).trim();
    if (s && !$e(s))
      return console.log("[VOT][custom][direct-sources] resolved direct source", {
        bestDirect: s,
        unitedVideoId: o
      }), {
        url: s,
        videoId: de(o || s, s || t),
        title: String(i.title || document.title || "")
      };
  }
  if (/^odysee\.com$/i.test(n)) {
    const s = ab();
    if (s?.contentUrl && /^https?:\/\//i.test(s.contentUrl))
      return console.log("[VOT][custom][odysee] resolved contentUrl", s.contentUrl), {
        url: s.contentUrl,
        videoId: t,
        title: s.title || document.title
      };
    const r = performance.getEntriesByType("resource").map((f) => typeof f.name == "string" ? f.name : "").filter(Boolean), a = (f) => {
      const g = f.toLowerCase();
      return g.includes(".jpg") || g.includes(".jpeg") || g.includes(".png") || g.includes(".webp") || g.includes("/speech/") || g.includes("thumbnails.odycdn.com");
    }, l = (f) => r.find((g) => !a(g) && f(g)) || null, u = l((f) => f.toLowerCase().includes(".m3u8")) || l((f) => f.toLowerCase().includes(".mpd")) || l((f) => f.toLowerCase().includes(".mp4")) || l((f) => f.toLowerCase().includes("/streams/"));
    if (u)
      return console.log("[VOT][custom][odysee] resolved media url", u), {
        url: u,
        videoId: t,
        title: s?.title || document.title
      };
    const d = document.querySelector("video"), h = String(d?.currentSrc || d?.src || "");
    return h && !h.startsWith("blob:") && !a(h) ? (console.log("[VOT][custom][odysee] resolved direct src", h), {
      url: h,
      videoId: t,
      title: s?.title || document.title
    }) : s?.embedUrl ? (console.log("[VOT][custom][odysee] fallback embedUrl", s.embedUrl), {
      url: s.embedUrl,
      videoId: t,
      title: s.title || document.title
    }) : (console.log("[VOT][custom][odysee] fallback page url", t), {
      url: t,
      videoId: t,
      title: s?.title || document.title
    });
  }
  if (/^player\.cdnvideohub\.com$/i.test(n) || /(^|\.)okcdn\.ru$/i.test(n)) {
    const s = String(document.referrer || "").trim(), o = document.querySelector("video"), r = String(o?.currentSrc || o?.src || "").trim();
    if (!$e(r))
      return console.log("[VOT][custom][cdnvideohub] using direct src", r), {
        url: r,
        videoId: de(r, s || t),
        title: document.title
      };
    const l = performance.getEntriesByType("resource").map((d) => typeof d.name == "string" ? d.name : "").filter(Boolean), u = Hi(l);
    return u ? (console.log("[VOT][custom][cdnvideohub] using performance resource", u), {
      url: u,
      videoId: de(u, s || t),
      title: document.title
    }) : /^https?:\/\/([^/]+\.)?kodikplayer\.com\//i.test(s) ? (console.log("[VOT][custom][cdnvideohub] using kodik referrer", s), {
      url: s,
      videoId: s,
      title: document.title
    }) : s ? (console.log("[VOT][custom][cdnvideohub] fallback referrer", s), {
      url: s,
      videoId: s,
      title: document.title
    }) : (console.log("[VOT][custom][cdnvideohub] fallback page url", t), {
      url: t,
      videoId: t,
      title: document.title
    });
  }
  {
    const o = performance.getEntriesByType("resource").map((u) => typeof u.name == "string" ? u.name : "").filter(Boolean), r = Hi(o);
    if (r)
      return console.log("[VOT][custom][generic] resolved media url", r), {
        url: r,
        videoId: de(r, t),
        title: document.title
      };
    const a = document.querySelector("video"), l = String(a?.currentSrc || a?.src || "");
    if (!$e(l))
      return console.log("[VOT][custom][generic] resolved direct src", l), {
        url: l,
        videoId: de(l, t),
        title: document.title
      };
  }
  return null;
}
const ub = {
  rutube: "ru",
  "ok.ru": "ru",
  mail_ru: "ru",
  weverse: "ko",
  niconico: "ja",
  youku: "zh",
  bilibili: "zh",
  weibo: "zh",
  zdf: "de"
}, Qr = ".ytp-volume-panel [aria-valuenow]", db = 35, hb = 500, fb = new Set(
  Pt
), ve = /* @__PURE__ */ new Map();
function $i(n) {
  if (typeof n == "string")
    try {
      const t = new URL(n, globalThis.location.href);
      return decodeURIComponent(t.pathname.split("/").pop() || "").replace(/\.[^.]+$/u, "").trim() || void 0;
    } catch {
      return;
    }
}
function ta() {
  const n = Array.from(
    document.querySelectorAll('[data-is-tooltip-wrapper="true"] > span')
  ).map((o) => o.textContent?.trim() ?? "").find((o) => /\.(mp4|mkv|mov|webm|avi|m4v)$/i.test(o)) || "", t = document.querySelector('meta[property="og:title"], meta[name="title"]')?.getAttribute("content")?.trim() || "", e = document.querySelector('h1, [role="heading"], div[role="heading"], [data-tooltip]')?.textContent?.trim() || "", i = String(document.title || "").trim(), s = n || t || e || i;
  if (s)
    return s.replace(/\s*-\s*Google Drive\s*$/i, "").replace(/\s*-\s*Google Диск\s*$/i, "").trim();
}
function We(n) {
  if (typeof n != "string") return !0;
  const t = n.trim();
  return t ? /^youtube$/i.test(t) || /^google drive$/i.test(t) || /^google диск$/i.test(t) || /^[A-Za-z0-9_-]{20,}$/.test(t) : !0;
}
function Yt(n) {
  return typeof n != "string" ? void 0 : n.replace(/\s*-\s*Google Drive\s*$/i, "").replace(/\s*-\s*Google Диск\s*$/i, "").trim() || void 0;
}
async function gb(n) {
  try {
    const t = await C.get(`googledrive:title:${n}`);
    return Yt(t);
  } catch {
    return;
  }
}
function mb(n) {
  const t = n.split(/[?#]/u, 1)[0]?.toLowerCase() ?? "";
  return t.endsWith(".srt") ? "srt" : t.endsWith(".json") ? "json" : "vtt";
}
function pb(n) {
  return n === "custom" ? String(globalThis.location.hostname || "native").trim() || "native" : n || String(globalThis.location.hostname || "native").trim();
}
function ea(n, t) {
  const e = [], i = Array.from(n.querySelectorAll("track"));
  for (const s of i) {
    const o = String(s.kind || s.getAttribute("kind") || "").trim().toLowerCase();
    if (o === "metadata")
      continue;
    const r = String(
      s.srclang || s.track?.language || s.getAttribute("srclang") || ""
    ).trim().toLowerCase(), a = String(s.src || s.getAttribute("src") || "").trim();
    if (!r || !a)
      continue;
    let l = a;
    try {
      l = new URL(a, document.baseURI).href;
    } catch {
    }
    e.push({
      language: r,
      url: l,
      format: mb(l),
      source: t,
      isAutoGenerated: o === "captions"
    });
  }
  return e;
}
function Wi(n, t) {
  const e = [], i = /* @__PURE__ */ new Set(), s = (o) => {
    if (Array.isArray(o))
      for (const r of o) {
        if (!r || typeof r != "object")
          continue;
        const a = r;
        if (typeof a.language != "string" || typeof a.url != "string" || typeof a.source != "string" || typeof a.format != "string")
          continue;
        const l = [
          a.source,
          a.language,
          a.translatedFromLanguage ?? "",
          a.url
        ].join("|");
        i.has(l) || (i.add(l), e.push({
          language: a.language,
          url: a.url,
          source: a.source,
          format: a.format,
          translatedFromLanguage: typeof a.translatedFromLanguage == "string" ? a.translatedFromLanguage : void 0,
          isAutoGenerated: typeof a.isAutoGenerated == "boolean" ? a.isAutoGenerated : void 0
        }));
      }
  };
  return s(n), s(t), e;
}
function Kn(n) {
  if (typeof n != "string") return !0;
  const t = n.trim().toLowerCase();
  return t ? t === "undefined" || t === "null" || t.startsWith("blob:") || t.includes("/frame/") || /\/s\d+\/v[\d.]+\/frame\/?$/i.test(t) || t.includes("okcdn.ru/?") || /[?&]bytes=\d+-\d+/i.test(t) || /[?&]type=\d+/i.test(t) : !0;
}
function zi(n, t) {
  if (typeof n != "string")
    return !1;
  const e = n.trim();
  if (!e)
    return !1;
  if (e === t)
    return !0;
  try {
    const i = new URL(e, globalThis.location.href), s = new URL(t, globalThis.location.href);
    if (i.hash = "", s.hash = "", i.toString() === s.toString())
      return !0;
    if (i.origin !== s.origin || i.pathname !== s.pathname)
      return !1;
    const o = (r) => Array.from(r.searchParams.entries()).sort(([a, l], [u, d]) => a === u ? l.localeCompare(d) : a.localeCompare(u)).map(([a, l]) => `${a}=${l}`).join("&");
    return o(i) === o(s);
  } catch {
    return !1;
  }
}
function ws(n) {
  if (typeof n != "string") return !0;
  const t = n.trim().toLowerCase();
  return t ? t.startsWith("blob:") || t.startsWith("data:") || t.includes("/frame/") || /\/s\d+\/v[\d.]+\/frame\/?$/i.test(t) || t.includes("okcdn.ru/?") || /[?&]bytes=\d+-\d+/i.test(t) || /[?&]type=\d+/i.test(t) : !0;
}
function bb(...n) {
  for (const t of n) {
    if (typeof t != "string")
      continue;
    const e = t.trim();
    if (!(!e || ws(e)))
      return e;
  }
  return "";
}
function yb(n, t, e) {
  return !e || ws(e.url) ? !1 : ws(n) || Kn(t) || /^https?:\/\//i.test(e.url) && !/^https?:\/\//i.test(String(n || "").trim());
}
function he(n) {
  const t = ve.get(n);
  if (t)
    return t;
  const e = {};
  for (ve.set(n, e); ve.size > hb; ) {
    const i = ve.keys().next().value;
    if (typeof i != "string")
      break;
    ve.delete(i);
  }
  return e;
}
function te(n) {
  if (typeof n != "string") return;
  const t = n.toLowerCase().split(/[-_]/)[0];
  return fb.has(t) ? t : void 0;
}
function ie(n) {
  return !!(n && n !== "auto");
}
function vb(n, t) {
  return qp(typeof n == "string" ? n : "", typeof t == "string" ? t : void 0);
}
function wb(n) {
  const t = ub[n];
  if (t)
    return t;
  if (n === "vk") {
    const e = document.getElementsByTagName("track")?.[0]?.srclang;
    return te(e);
  }
}
function Sb(n) {
  if (!Array.isArray(n) || n.length === 0)
    return;
  const t = (e) => {
    for (const i of n) {
      if (!i || typeof i != "object")
        continue;
      const s = i;
      if (s.source !== "youtube" || typeof s.translatedFromLanguage == "string" || e && s.isAutoGenerated === !0)
        continue;
      const o = te(s.language);
      if (ie(o))
        return o;
    }
  };
  return t(!0) ?? t(!1);
}
async function na(n) {
  if (n.isStream)
    return { detectedLanguage: "auto" };
  if (n.userOverrideLanguage)
    return { detectedLanguage: n.userOverrideLanguage };
  const t = wb(n.host);
  if (ie(t))
    return {
      detectedLanguage: t,
      cacheLanguage: t
    };
  const e = te(
    n.possibleLanguage
  );
  if (ie(e))
    return {
      detectedLanguage: e,
      cacheLanguage: e
    };
  const i = n.host === "youtube" ? Sb(n.subtitles) : void 0;
  if (ie(i))
    return {
      detectedLanguage: i,
      cacheLanguage: i
    };
  if (n.cachedDetectedLanguage)
    return { detectedLanguage: n.cachedDetectedLanguage };
  if (!n.allowTextLanguageDetection)
    return { detectedLanguage: "auto" };
  const s = vb(n.title, n.description);
  if (!s || s.length < db)
    return { detectedLanguage: "auto" };
  const o = await n.detectLanguage(s);
  return o ? {
    detectedLanguage: o,
    cacheLanguage: o
  } : { detectedLanguage: "auto" };
}
function ia(n) {
  const t = document.querySelector(n), e = t?.getAttribute("aria-valuenow"), i = t?.getAttribute("aria-valuemax"), s = e == null ? Number.NaN : Number.parseFloat(e), o = i == null ? Number.NaN : Number.parseFloat(i);
  return Number.isFinite(s) ? Number.isFinite(o) && o > 0 ? At(s / o * 100) : At(s) : null;
}
class Tb {
  constructor(t) {
    c(this, "videoHandler");
    this.videoHandler = t;
  }
  setDetectedLanguageCache(t, e) {
    he(t).detectedLanguage = e;
  }
  rememberUserLanguageSelection(t, e) {
    const i = te(e);
    if (!ie(i)) {
      const o = ve.get(t);
      o && delete o.userLanguageOverride;
      return;
    }
    const s = he(t);
    s.userLanguageOverride = i, s.detectedLanguage = i;
  }
  rememberDetectedLanguage(t, e) {
    const i = te(e);
    ie(i) && (this.setDetectedLanguageCache(t, i), this.videoHandler.videoData?.videoId === t && (this.videoHandler.videoData.detectedLanguage = i));
  }
  async detectLanguageSingleFlight(t, e) {
    const i = he(t), s = i.detectInFlight;
    if (s !== void 0)
      return s;
    const o = (async () => {
      const r = te(await jp(e));
      return ie(r) ? r : void 0;
    })();
    i.detectInFlight = o;
    try {
      return await o;
    } finally {
      i.detectInFlight === o && delete i.detectInFlight;
    }
  }
  async ensureDetectedLanguageForTranslation(t) {
    if (!t?.videoId || t.detectedLanguage !== "auto")
      return;
    const e = he(t.videoId), { detectedLanguage: i, cacheLanguage: s } = await na({
      isStream: t.isStream,
      host: this.videoHandler.site.host,
      possibleLanguage: t.detectedLanguage,
      subtitles: t.subtitles,
      userOverrideLanguage: e.userLanguageOverride,
      cachedDetectedLanguage: e.detectedLanguage,
      title: t.title,
      description: t.description,
      allowTextLanguageDetection: !0,
      detectLanguage: async (o) => await this.detectLanguageSingleFlight(t.videoId, o)
    });
    s && this.setDetectedLanguageCache(t.videoId, s), i !== "auto" && (t.detectedLanguage = i, this.videoHandler.translateFromLang === "auto" && (this.videoHandler.translateFromLang = i));
  }
  async getVideoData() {
    const t = String(globalThis.location.href || "").trim(), e = String(globalThis.location.hostname || "").trim(), i = Nl(), s = String(
      this.videoHandler.video.currentSrc || this.videoHandler.video.src || ""
    ).trim(), o = ea(
      this.videoHandler.video,
      pb(this.videoHandler.site.host)
    );
    let r, a;
    try {
      a = await Dd(this.videoHandler.site, {
        fetchFn: nt,
        video: this.videoHandler.video,
        language: p.lang
      });
    } catch (_) {
      r = _, console.warn(
        "[VOT][fallback:getVideoData] site getVideoData() failed, using DOM fallback",
        {
          siteHost: this.videoHandler.site.host,
          hostname: e,
          error: _
        }
      ), a = {
        duration: this.videoHandler.video?.duration || Q.defaultDuration,
        url: "",
        videoId: "",
        host: this.videoHandler.site.host,
        title: document.title,
        translationHelp: null,
        localizedTitle: document.title,
        description: void 0,
        detectedLanguage: "auto",
        subtitles: o,
        isStream: !1
      };
    }
    let {
      duration: l,
      url: u,
      videoId: d,
      host: h,
      title: f,
      translationHelp: g = null,
      localizedTitle: m,
      description: v,
      detectedLanguage: T,
      subtitles: S,
      isStream: w = !1
    } = a;
    S = Wi(S, o), this.videoHandler.site.host === "vk" && (S = Wi(
      S,
      nu("vk", d)
    ));
    const x = await cb(e, t);
    if (this.videoHandler.site.host === "custom" || !!r || yb(u, d, x)) {
      const _ = bb(
        x?.url,
        i,
        s,
        u,
        t
      );
      if (_ && (u = _), Kn(d) || zi(d, t)) {
        const q = !Kn(_) && !zi(_, t) ? _ : "", Y = !Kn(x?.videoId) && !zi(String(x?.videoId || ""), t) ? String(x?.videoId).trim() : "";
        d = q || Y || t;
      }
      h = "custom";
      const z = x?.title || $i(u) || (typeof document.title == "string" ? document.title.trim() : void 0);
      z && (f = z, m || (m = z)), console.log("[VOT][fallback:getVideoData] using DOM/media fallback", {
        siteHost: this.videoHandler.site.host,
        sniffedManifestUrl: i,
        mediaUrl: s,
        pageUrl: t,
        resolvedFallback: x,
        finalUrl: u,
        finalVideoId: d,
        finalHost: h
      });
    }
    if (this.videoHandler.site.host === "googledrive") {
      S = Wi(
        S,
        ea(this.videoHandler.video, "googledrive")
      );
      const _ = Yt(ta()), z = await gb(d), q = Yt(f), Y = Yt(m), Mt = We(q) ? We(z) ? We(_) ? We(Y) ? void 0 : Y : _ : z : q;
      Mt && (f = Mt, We(m) && (m = Mt));
    }
    const k = he(d), { detectedLanguage: A, cacheLanguage: $ } = await na({
      isStream: w,
      host: this.videoHandler.site.host,
      possibleLanguage: T,
      subtitles: S,
      userOverrideLanguage: k.userLanguageOverride,
      cachedDetectedLanguage: k.detectedLanguage,
      title: f,
      description: v,
      allowTextLanguageDetection: !1,
      detectLanguage: async (_) => await this.detectLanguageSingleFlight(d, _)
    });
    if ($ && this.setDetectedLanguageCache(d, $), h === "custom") {
      const _ = $i(u) || (typeof document.title == "string" ? document.title.trim() : void 0);
      _ && (f = _, m || (m = _));
    }
    const H = {
      translationHelp: g,
      isStream: w,
      duration: l || this.videoHandler.video?.duration || Q.defaultDuration,
      videoId: d,
      url: u,
      host: h,
      detectedLanguage: A,
      responseLanguage: this.videoHandler.translateToLang,
      subtitles: S,
      title: f,
      localizedTitle: m,
      description: v,
      downloadTitle: this.videoHandler.site.host === "googledrive" ? Yt(f) ?? Yt(m) ?? Yt(ta()) ?? d : h === "custom" ? $i(u) ?? f ?? m ?? d : m ?? f ?? d
    };
    return k.lastLoggedDetectedLanguage !== A && (console.log("[VOT] Detected language:", A), k.lastLoggedDetectedLanguage = A), Array.isArray(H.subtitles) && H.subtitles.length > 0 && (console.log(
      `[VOT][subtitles] video data contains ${H.subtitles.length} subtitle track(s).`
    ), console.table(
      H.subtitles.map((_, z) => ({
        index: z,
        language: _.language,
        translatedFromLanguage: _.translatedFromLanguage ?? "",
        source: _.source,
        isAutoGenerated: !!_.isAutoGenerated,
        url: _.url
      }))
    )), H;
  }
  async videoValidator() {
    const t = this.videoHandler.videoData, e = this.videoHandler.data;
    if (!t || !e)
      throw new ft("VOTNoVideoIDFound");
    if (V.log("VideoValidator videoData: ", this.videoHandler.videoData), this.videoHandler.data.enabledDontTranslateLanguages && this.videoHandler.data.dontTranslateLanguages?.includes(
      this.videoHandler.videoData.detectedLanguage
    ))
      throw new ft("VOTDisableFromYourLang");
    if (this.videoHandler.videoData.isStream)
      throw new ft("VOTStreamNotAvailable");
    if (this.videoHandler.videoData.duration > 14400)
      throw new ft("VOTVideoIsTooLong");
    return !0;
  }
  /**
   * Gets current video volume (0.0 - 1.0)
   */
  getVideoVolume() {
    const t = this.videoHandler.video;
    if (t) {
      if (_n(this.videoHandler.site.host)) {
        const e = ia(Qr);
        if (e != null)
          return Qp(e);
        const i = N.getVolume();
        if (typeof i == "number" && Number.isFinite(i))
          return ne(i);
      }
      return ne(t.volume);
    }
  }
  /**
   * Sets the video volume
   */
  setVideoVolume(t) {
    const e = ne(t);
    if (!_n(this.videoHandler.site.host))
      return this.videoHandler.video.volume = e, this;
    try {
      const i = N.setVolume(e);
      if (typeof i == "boolean" && i || typeof i == "number" && Number.isFinite(i)) return this;
    } catch {
    }
    return this.videoHandler.video.volume = e, this;
  }
  /**
   * Checks if the video is muted
   */
  isMuted() {
    return _n(this.videoHandler.site.host) ? N.isMuted() : this.videoHandler.video?.muted;
  }
  /**
   * Syncs the video volume slider with the actual video volume.
   */
  syncVideoVolumeSlider() {
    const t = this.videoHandler.uiManager.votOverlayView;
    if (!t?.isInitialized()) return this;
    const e = _n(this.videoHandler.site.host) ? ia(Qr) : null, i = this.isMuted() ? 0 : e ?? Yl(this.getVideoVolume() ?? 0);
    return t.videoVolumeSlider.value = i, this.videoHandler.onVideoVolumeSliderSynced?.(i), this;
  }
  setSelectMenuValues(t, e) {
    const i = this.videoHandler.videoData;
    if (!i)
      return this;
    const s = te(t) ?? "auto", o = `${s}->${e}`, r = he(i.videoId);
    r.lastLoggedLangPair !== o && (console.log(`[VOT] Set translation from ${s} to ${e}`), r.lastLoggedLangPair = o), i.detectedLanguage = s, i.responseLanguage = e, this.videoHandler.translateFromLang = s, this.videoHandler.translateToLang = e;
    const a = this.videoHandler.uiManager.votOverlayView;
    return a?.isInitialized() ? (a.languagePairSelect.fromSelect.selectTitle = p.getLangLabel(s), a.languagePairSelect.toSelect.selectTitle = p.getLangLabel(e), a.languagePairSelect.fromSelect.setSelectedValue(s), a.languagePairSelect.toSelect.setSelectedValue(e), this) : this;
  }
}
const tn = globalThis, sa = (n) => n, ni = tn.trustedTypes, oa = ni ? ni.createPolicy("lit-html", { createHTML: (n) => n }) : void 0, Zl = "$lit$", Nt = `lit$${Math.random().toFixed(9).slice(2)}$`, Ql = "?" + Nt, kb = `<${Ql}>`, ae = document, dn = () => ae.createComment(""), hn = (n) => n === null || typeof n != "object" && typeof n != "function", eo = Array.isArray, Lb = (n) => eo(n) || typeof n?.[Symbol.iterator] == "function", qi = `[ 	
\f\r]`, ze = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, ra = /-->/g, aa = />/g, Gt = RegExp(`>|${qi}(?:([^\\s"'>=/]+)(${qi}*=${qi}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), la = /'/g, ca = /"/g, tc = /^(?:script|style|textarea|title)$/i, ec = (n) => (t, ...e) => ({ _$litType$: n, strings: t, values: e }), je = ec(1), gt = ec(2), fn = /* @__PURE__ */ Symbol.for("lit-noChange"), Z = /* @__PURE__ */ Symbol.for("lit-nothing"), ua = /* @__PURE__ */ new WeakMap(), ee = ae.createTreeWalker(ae, 129);
function nc(n, t) {
  if (!eo(n) || !n.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return oa !== void 0 ? oa.createHTML(t) : t;
}
const xb = (n, t) => {
  const e = n.length - 1, i = [];
  let s, o = t === 2 ? "<svg>" : t === 3 ? "<math>" : "", r = ze;
  for (let a = 0; a < e; a++) {
    const l = n[a];
    let u, d, h = -1, f = 0;
    for (; f < l.length && (r.lastIndex = f, d = r.exec(l), d !== null); ) f = r.lastIndex, r === ze ? d[1] === "!--" ? r = ra : d[1] !== void 0 ? r = aa : d[2] !== void 0 ? (tc.test(d[2]) && (s = RegExp("</" + d[2], "g")), r = Gt) : d[3] !== void 0 && (r = Gt) : r === Gt ? d[0] === ">" ? (r = s ?? ze, h = -1) : d[1] === void 0 ? h = -2 : (h = r.lastIndex - d[2].length, u = d[1], r = d[3] === void 0 ? Gt : d[3] === '"' ? ca : la) : r === ca || r === la ? r = Gt : r === ra || r === aa ? r = ze : (r = Gt, s = void 0);
    const g = r === Gt && n[a + 1].startsWith("/>") ? " " : "";
    o += r === ze ? l + kb : h >= 0 ? (i.push(u), l.slice(0, h) + Zl + l.slice(h) + Nt + g) : l + Nt + (h === -2 ? a : g);
  }
  return [nc(n, o + (n[e] || "<?>") + (t === 2 ? "</svg>" : t === 3 ? "</math>" : "")), i];
};
class gn {
  constructor({ strings: t, _$litType$: e }, i) {
    let s;
    this.parts = [];
    let o = 0, r = 0;
    const a = t.length - 1, l = this.parts, [u, d] = xb(t, e);
    if (this.el = gn.createElement(u, i), ee.currentNode = this.el.content, e === 2 || e === 3) {
      const h = this.el.content.firstChild;
      h.replaceWith(...h.childNodes);
    }
    for (; (s = ee.nextNode()) !== null && l.length < a; ) {
      if (s.nodeType === 1) {
        if (s.hasAttributes()) for (const h of s.getAttributeNames()) if (h.endsWith(Zl)) {
          const f = d[r++], g = s.getAttribute(h).split(Nt), m = /([.?@])?(.*)/.exec(f);
          l.push({ type: 1, index: o, name: m[2], strings: g, ctor: m[1] === "." ? Eb : m[1] === "?" ? Vb : m[1] === "@" ? Cb : vi }), s.removeAttribute(h);
        } else h.startsWith(Nt) && (l.push({ type: 6, index: o }), s.removeAttribute(h));
        if (tc.test(s.tagName)) {
          const h = s.textContent.split(Nt), f = h.length - 1;
          if (f > 0) {
            s.textContent = ni ? ni.emptyScript : "";
            for (let g = 0; g < f; g++) s.append(h[g], dn()), ee.nextNode(), l.push({ type: 2, index: ++o });
            s.append(h[f], dn());
          }
        }
      } else if (s.nodeType === 8) if (s.data === Ql) l.push({ type: 2, index: o });
      else {
        let h = -1;
        for (; (h = s.data.indexOf(Nt, h + 1)) !== -1; ) l.push({ type: 7, index: o }), h += Nt.length - 1;
      }
      o++;
    }
  }
  static createElement(t, e) {
    const i = ae.createElement("template");
    return i.innerHTML = t, i;
  }
}
function Ae(n, t, e = n, i) {
  if (t === fn) return t;
  let s = i !== void 0 ? e._$Co?.[i] : e._$Cl;
  const o = hn(t) ? void 0 : t._$litDirective$;
  return s?.constructor !== o && (s?._$AO?.(!1), o === void 0 ? s = void 0 : (s = new o(n), s._$AT(n, e, i)), i !== void 0 ? (e._$Co ?? (e._$Co = []))[i] = s : e._$Cl = s), s !== void 0 && (t = Ae(n, s._$AS(n, t.values), s, i)), t;
}
class Ab {
  constructor(t, e) {
    this._$AV = [], this._$AN = void 0, this._$AD = t, this._$AM = e;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t) {
    const { el: { content: e }, parts: i } = this._$AD, s = (t?.creationScope ?? ae).importNode(e, !0);
    ee.currentNode = s;
    let o = ee.nextNode(), r = 0, a = 0, l = i[0];
    for (; l !== void 0; ) {
      if (r === l.index) {
        let u;
        l.type === 2 ? u = new vn(o, o.nextSibling, this, t) : l.type === 1 ? u = new l.ctor(o, l.name, l.strings, this, t) : l.type === 6 && (u = new Ib(o, this, t)), this._$AV.push(u), l = i[++a];
      }
      r !== l?.index && (o = ee.nextNode(), r++);
    }
    return ee.currentNode = ae, s;
  }
  p(t) {
    let e = 0;
    for (const i of this._$AV) i !== void 0 && (i.strings !== void 0 ? (i._$AI(t, i, e), e += i.strings.length - 2) : i._$AI(t[e])), e++;
  }
}
class vn {
  get _$AU() {
    return this._$AM?._$AU ?? this._$Cv;
  }
  constructor(t, e, i, s) {
    this.type = 2, this._$AH = Z, this._$AN = void 0, this._$AA = t, this._$AB = e, this._$AM = i, this.options = s, this._$Cv = s?.isConnected ?? !0;
  }
  get parentNode() {
    let t = this._$AA.parentNode;
    const e = this._$AM;
    return e !== void 0 && t?.nodeType === 11 && (t = e.parentNode), t;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t, e = this) {
    t = Ae(this, t, e), hn(t) ? t === Z || t == null || t === "" ? (this._$AH !== Z && this._$AR(), this._$AH = Z) : t !== this._$AH && t !== fn && this._(t) : t._$litType$ !== void 0 ? this.$(t) : t.nodeType !== void 0 ? this.T(t) : Lb(t) ? this.k(t) : this._(t);
  }
  O(t) {
    return this._$AA.parentNode.insertBefore(t, this._$AB);
  }
  T(t) {
    this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
  }
  _(t) {
    this._$AH !== Z && hn(this._$AH) ? this._$AA.nextSibling.data = t : this.T(ae.createTextNode(t)), this._$AH = t;
  }
  $(t) {
    const { values: e, _$litType$: i } = t, s = typeof i == "number" ? this._$AC(t) : (i.el === void 0 && (i.el = gn.createElement(nc(i.h, i.h[0]), this.options)), i);
    if (this._$AH?._$AD === s) this._$AH.p(e);
    else {
      const o = new Ab(s, this), r = o.u(this.options);
      o.p(e), this.T(r), this._$AH = o;
    }
  }
  _$AC(t) {
    let e = ua.get(t.strings);
    return e === void 0 && ua.set(t.strings, e = new gn(t)), e;
  }
  k(t) {
    eo(this._$AH) || (this._$AH = [], this._$AR());
    const e = this._$AH;
    let i, s = 0;
    for (const o of t) s === e.length ? e.push(i = new vn(this.O(dn()), this.O(dn()), this, this.options)) : i = e[s], i._$AI(o), s++;
    s < e.length && (this._$AR(i && i._$AB.nextSibling, s), e.length = s);
  }
  _$AR(t = this._$AA.nextSibling, e) {
    for (this._$AP?.(!1, !0, e); t !== this._$AB; ) {
      const i = sa(t).nextSibling;
      sa(t).remove(), t = i;
    }
  }
  setConnected(t) {
    this._$AM === void 0 && (this._$Cv = t, this._$AP?.(t));
  }
}
class vi {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(t, e, i, s, o) {
    this.type = 1, this._$AH = Z, this._$AN = void 0, this.element = t, this.name = e, this._$AM = s, this.options = o, i.length > 2 || i[0] !== "" || i[1] !== "" ? (this._$AH = Array(i.length - 1).fill(new String()), this.strings = i) : this._$AH = Z;
  }
  _$AI(t, e = this, i, s) {
    const o = this.strings;
    let r = !1;
    if (o === void 0) t = Ae(this, t, e, 0), r = !hn(t) || t !== this._$AH && t !== fn, r && (this._$AH = t);
    else {
      const a = t;
      let l, u;
      for (t = o[0], l = 0; l < o.length - 1; l++) u = Ae(this, a[i + l], e, l), u === fn && (u = this._$AH[l]), r || (r = !hn(u) || u !== this._$AH[l]), u === Z ? t = Z : t !== Z && (t += (u ?? "") + o[l + 1]), this._$AH[l] = u;
    }
    r && !s && this.j(t);
  }
  j(t) {
    t === Z ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
  }
}
class Eb extends vi {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t) {
    this.element[this.name] = t === Z ? void 0 : t;
  }
}
class Vb extends vi {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t) {
    this.element.toggleAttribute(this.name, !!t && t !== Z);
  }
}
class Cb extends vi {
  constructor(t, e, i, s, o) {
    super(t, e, i, s, o), this.type = 5;
  }
  _$AI(t, e = this) {
    if ((t = Ae(this, t, e, 0) ?? Z) === fn) return;
    const i = this._$AH, s = t === Z && i !== Z || t.capture !== i.capture || t.once !== i.once || t.passive !== i.passive, o = t !== Z && (i === Z || s);
    s && this.element.removeEventListener(this.name, this, i), o && this.element.addEventListener(this.name, this, t), this._$AH = t;
  }
  handleEvent(t) {
    typeof this._$AH == "function" ? this._$AH.call(this.options?.host ?? this.element, t) : this._$AH.handleEvent(t);
  }
}
class Ib {
  constructor(t, e, i) {
    this.element = t, this.type = 6, this._$AN = void 0, this._$AM = e, this.options = i;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t) {
    Ae(this, t);
  }
}
const Pb = tn.litHtmlPolyfillSupport;
Pb?.(gn, vn), (tn.litHtmlVersions ?? (tn.litHtmlVersions = [])).push("3.3.2");
const ht = (n, t, e) => {
  const i = t;
  let s = i._$litPart$;
  return s === void 0 && (i._$litPart$ = s = new vn(t.insertBefore(dn(), null), null, void 0, {})), s._$AI(n), s;
};
function Mb() {
  if (globalThis.__votKeyboardNavInitialized) return;
  globalThis.__votKeyboardNavInitialized = !0;
  const n = document.documentElement, t = "vot-keyboard-nav", e = () => n.classList.add(t), i = () => n.classList.remove(t);
  globalThis.addEventListener(
    "keydown",
    (s) => {
      s.key === "Tab" && e();
    },
    !0
  );
  for (const s of ["pointerdown", "mousedown", "touchstart"])
    globalThis.addEventListener(s, i, {
      capture: !0,
      passive: !0
    });
}
Mb();
const L = {
  /**
   * Makes a non-native element behave like a button (keyboard + ARIA).
   *
   * We use custom tags (`vot-block`) for isolation, so we must re-add
   * basic semantics for accessibility.
   */
  makeButtonLike(n, { ariaLabel: t } = {}) {
    n.setAttribute("role", "button"), n.hasAttribute("tabindex") || (n.tabIndex = 0);
    const e = n.tabIndex, i = () => {
      n.getAttribute("disabled") === "true" ? (n.setAttribute("aria-disabled", "true"), n.tabIndex = -1) : (n.removeAttribute("aria-disabled"), n.tabIndex = e);
    };
    return i(), new MutationObserver(() => i()).observe(n, {
      attributes: !0,
      attributeFilter: ["disabled"]
    }), t && n.setAttribute("aria-label", t), n.addEventListener("keydown", (s) => {
      n.getAttribute("disabled") === "true" || n.getAttribute("aria-disabled") === "true" || (s.key === "Enter" || s.key === " ") && (s.preventDefault(), n.click());
    }), n;
  },
  /**
   * Auxiliary method for creating HTML elements
   */
  createEl(n, t = [], e = null) {
    const i = document.createElement(n);
    return t.length && i.classList.add(...t), e !== null && i.append(e), i;
  },
  /**
   * Create header element
   */
  createHeader(n, t = 4) {
    return L.createEl(
      "vot-block",
      ["vot-header", `vot-header-level-${t}`],
      n
    );
  },
  /**
   * Create information element
   */
  createInformation(n, t) {
    const e = L.createEl("vot-block", ["vot-info"]), i = L.createEl("vot-block");
    ht(n, i);
    const s = L.createEl("vot-block");
    return ht(t, s), e.append(i, s), { container: e, header: i, value: s };
  },
  /**
   * Create button
   */
  createButton(n) {
    const t = L.createEl("vot-block", ["vot-button"], n);
    return L.makeButtonLike(t);
  },
  /**
   * Create text button
   */
  createTextButton(n) {
    const t = L.createEl("vot-block", ["vot-text-button"], n);
    return L.makeButtonLike(t);
  },
  /**
   * Create outlined button
   */
  createOutlinedButton(n) {
    const t = L.createEl("vot-block", ["vot-outlined-button"], n);
    return L.makeButtonLike(t);
  },
  /**
   * Create icon button
   */
  createIconButton(n, t = {}) {
    const e = L.createEl("vot-block", ["vot-icon-button"]);
    return ht(n, e), L.makeButtonLike(e, t);
  },
  createInlineLoader() {
    return L.createEl("vot-block", ["vot-inline-loader"]);
  },
  createPortal(n = !1) {
    return L.createEl("vot-block", [`vot-portal${n ? "-local" : ""}`]);
  },
  createSubtitleInfo(n, t, e) {
    const i = L.createEl("vot-block", ["vot-subtitles-info"]);
    i.id = "vot-subtitles-info";
    const s = L.createEl(
      "vot-block",
      ["vot-subtitles-info-service"],
      p.get("VOTTranslatedBy").replace("{0}", e)
    ), o = L.createEl(
      "vot-block",
      ["vot-subtitles-info-header"],
      n
    ), r = L.createEl(
      "vot-block",
      ["vot-subtitles-info-context"],
      t
    );
    return i.append(s, o, r), {
      container: i,
      translatedWith: s,
      header: o,
      context: r
    };
  }
}, Ob = ["left", "top", "right", "bottom"], Db = ["hover", "click"], Zt = class Zt {
  constructor({
    target: t,
    anchor: e = void 0,
    content: i = "",
    position: s = "top",
    trigger: o = "hover",
    offset: r = 4,
    maxWidth: a = void 0,
    hidden: l = !1,
    autoLayout: u = !0,
    backgroundColor: d = void 0,
    borderRadius: h = void 0,
    bordered: f = !0,
    parentElement: g = document.body,
    layoutRoot: m = document.documentElement
  }) {
    /** Whether tooltip element is currently mounted. */
    c(this, "showed", !1);
    c(this, "target");
    c(this, "anchor");
    c(this, "content");
    c(this, "position");
    c(this, "preferredPosition");
    c(this, "trigger");
    c(this, "parentElement");
    c(this, "layoutRoot");
    c(this, "offsetX");
    c(this, "offsetY");
    c(this, "_hidden");
    c(this, "autoLayout");
    c(this, "pageWidth");
    c(this, "pageHeight");
    c(this, "globalOffsetX");
    c(this, "globalOffsetY");
    c(this, "maxWidth");
    c(this, "backgroundColor");
    c(this, "borderRadius");
    c(this, "_bordered");
    c(this, "container");
    c(this, "onResizeObserver");
    c(this, "intersectionObserver");
    c(this, "scrollListening", !1);
    c(this, "positionRafId", null);
    c(this, "destroyFallbackTimerId");
    // Accessibility: link trigger -> tooltip via aria-describedby.
    c(this, "tooltipId", typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `vot-tooltip-${Math.random().toString(36).slice(2)}`);
    c(this, "prevAriaDescribedBy", null);
    c(this, "onResize", () => {
      this.schedulePositionUpdate();
    });
    c(this, "onClick", () => {
      this.showed ? this.destroy() : this.create();
    });
    c(this, "onTargetKeyDown", (t) => {
      t.key !== "Escape" || !this.showed || this.destroy();
    });
    c(this, "onScroll", () => {
      this.schedulePositionUpdate();
    });
    c(this, "onHoverPointerDown", (t) => {
      t.pointerType !== "mouse" && this.create();
    });
    c(this, "onHoverPointerUp", (t) => {
      t.pointerType !== "mouse" && this.destroy();
    });
    c(this, "onMouseEnter", () => {
      this.create();
    });
    c(this, "onMouseLeave", (t) => {
      this.isInTooltipContext(t.relatedTarget) || this.destroy();
    });
    c(this, "onTooltipMouseLeave", (t) => {
      this.isInTooltipContext(t.relatedTarget) || this.destroy();
    });
    c(this, "onIntersect", ([t]) => {
      if (!t.isIntersecting)
        return this.destroy(!0);
    });
    if (!(t instanceof HTMLElement))
      throw new TypeError("target must be a valid HTMLElement");
    this.target = t, this.anchor = e instanceof HTMLElement ? e : t, this.content = i, typeof r == "number" ? this.offsetY = this.offsetX = r : (this.offsetX = r.x, this.offsetY = r.y), this._hidden = l, this.autoLayout = u, this.trigger = Zt.validateTrigger(o) ? o : "hover", this.position = Zt.validatePos(s) ? s : "top", this.preferredPosition = this.position, this.parentElement = g, this.layoutRoot = m, this.borderRadius = h, this._bordered = f, this.maxWidth = a, this.backgroundColor = d, this.updatePageSize(), this.init();
  }
  static validatePos(t) {
    return Ob.includes(t);
  }
  static validateTrigger(t) {
    return Db.includes(t);
  }
  setPosition(t) {
    return this.preferredPosition = Zt.validatePos(t) ? t : "top", this.position = this.preferredPosition, this.schedulePositionUpdate(), this;
  }
  setContent(t) {
    return this.content = t, this.container ? (this.container.replaceChildren(), typeof t == "string" ? this.container.textContent = t : this.container.append(t), this.schedulePositionUpdate(), this) : this;
  }
  /**
   * Update tooltip mount dependencies.
   * If the tooltip is currently rendered, it will be moved to the new parent.
   */
  updateMount({
    parentElement: t,
    layoutRoot: e
  }) {
    return t && this.parentElement !== t && (this.parentElement = t, this.container?.isConnected && t.appendChild(this.container)), e && this.layoutRoot !== e && (this.layoutRoot = e), this.schedulePositionUpdate(), this;
  }
  isInTooltipContext(t) {
    return t instanceof Node ? this.target.contains(t) || this.container?.contains(t) : !1;
  }
  updatePageSize() {
    if (this.layoutRoot === document.documentElement)
      this.globalOffsetX = 0, this.globalOffsetY = 0;
    else {
      const { left: t, top: e } = this.layoutRoot.getBoundingClientRect();
      this.globalOffsetX = t, this.globalOffsetY = e;
    }
    return this.pageWidth = this.layoutRoot.clientWidth || document.documentElement.clientWidth, this.pageHeight = this.layoutRoot.clientHeight || document.documentElement.clientHeight, this;
  }
  init() {
    return this.onResizeObserver = new ResizeObserver(this.onResize), this.intersectionObserver = new IntersectionObserver(this.onIntersect), this.target.addEventListener("keydown", this.onTargetKeyDown), this.trigger === "click" ? (this.target.addEventListener("pointerdown", this.onClick), this) : (this.target.addEventListener("mouseenter", this.onMouseEnter), this.target.addEventListener("mouseleave", this.onMouseLeave), this.target.addEventListener("focusin", this.onMouseEnter), this.target.addEventListener("focusout", this.onMouseLeave), this.target.addEventListener("pointerdown", this.onHoverPointerDown), this.target.addEventListener("pointerup", this.onHoverPointerUp), this);
  }
  release() {
    return this.destroy(!0), this.detachScrollListener(), this.target.removeEventListener("keydown", this.onTargetKeyDown), this.trigger === "click" ? (this.target.removeEventListener("pointerdown", this.onClick), this) : (this.target.removeEventListener("mouseenter", this.onMouseEnter), this.target.removeEventListener("mouseleave", this.onMouseLeave), this.target.removeEventListener("focusin", this.onMouseEnter), this.target.removeEventListener("focusout", this.onMouseLeave), this.target.removeEventListener("pointerdown", this.onHoverPointerDown), this.target.removeEventListener("pointerup", this.onHoverPointerUp), this);
  }
  schedulePositionUpdate() {
    this.container && this.positionRafId === null && (this.positionRafId = requestAnimationFrame(() => {
      this.positionRafId = null, this.updatePageSize(), this.updatePos();
    }));
  }
  cancelPositionUpdate() {
    this.positionRafId !== null && (cancelAnimationFrame(this.positionRafId), this.positionRafId = null);
  }
  clearDestroyFallbackTimer() {
    this.destroyFallbackTimerId !== void 0 && (globalThis.clearTimeout(this.destroyFallbackTimerId), this.destroyFallbackTimerId = void 0);
  }
  create() {
    return this.destroy(!0), this.showed = !0, this.container = L.createEl("vot-block", ["vot-tooltip"], this.content), this.bordered && this.container.classList.add("vot-tooltip-bordered"), this.container.setAttribute("role", "tooltip"), this.container.id = this.tooltipId, this.container.dataset.trigger = this.trigger, this.container.dataset.position = this.position, this.parentElement.appendChild(this.container), this.schedulePositionUpdate(), this.backgroundColor !== void 0 && (this.container.style.backgroundColor = this.backgroundColor), this.borderRadius !== void 0 && (this.container.style.borderRadius = `${this.borderRadius}px`), this.hidden ? this.container.hidden = !0 : this.syncAriaDescribedBy(!0), this.container.style.opacity = "1", this.trigger === "hover" && this.container.addEventListener("mouseleave", this.onTooltipMouseLeave), this.attachScrollListener(), this.onResizeObserver?.observe(this.layoutRoot), this.anchor !== this.layoutRoot && this.onResizeObserver?.observe(this.anchor), this.intersectionObserver?.observe(this.target), this;
  }
  updatePos() {
    if (!this.container)
      return this;
    const { top: t, left: e } = this.calcPos(this.autoLayout, this.preferredPosition), i = Math.max(0, this.pageWidth - this.offsetX * 2), s = W(this.maxWidth ?? i, 0, i);
    return this.container.style.transform = `translate(${e}px, ${t}px)`, this.container.dataset.position = this.position, this.container.style.maxWidth = `${s}px`, this;
  }
  calcPos(t = !0, e = this.preferredPosition) {
    if (!this.container)
      return { top: 0, left: 0 };
    const {
      left: i,
      right: s,
      top: o,
      bottom: r,
      width: a,
      height: l
    } = this.anchor.getBoundingClientRect(), { width: u, height: d } = this.container.getBoundingClientRect(), h = W(u, 0, this.pageWidth), f = W(d, 0, this.pageHeight), g = i - this.globalOffsetX, m = s - this.globalOffsetX, v = o - this.globalOffsetY, T = r - this.globalOffsetY;
    let S = e;
    if (t)
      switch (e) {
        case "top": {
          W(v - f - this.offsetY, 0, this.pageHeight) + this.offsetY < f && (S = "bottom");
          break;
        }
        case "right": {
          W(m + this.offsetX, 0, this.pageWidth - h) + h > this.pageWidth - this.offsetX && (S = "left");
          break;
        }
        case "bottom": {
          W(
            T + this.offsetY,
            0,
            this.pageHeight - f
          ) + f > this.pageHeight - this.offsetY && (S = "top");
          break;
        }
        case "left": {
          Math.max(0, g - h - this.offsetX) + h > g - this.offsetX && (S = "right");
          break;
        }
      }
    let w;
    switch (S) {
      case "top":
        w = {
          top: W(v - f - this.offsetY, 0, this.pageHeight),
          left: W(
            g - h / 2 + a / 2,
            this.offsetX,
            this.pageWidth - h - this.offsetX
          )
        };
        break;
      case "right":
        w = {
          top: W(
            v + (l - f) / 2,
            this.offsetY,
            this.pageHeight - f - this.offsetY
          ),
          left: W(m + this.offsetX, 0, this.pageWidth - h)
        };
        break;
      case "bottom":
        w = {
          top: W(T + this.offsetY, 0, this.pageHeight - f),
          left: W(
            g - h / 2 + a / 2,
            this.offsetX,
            this.pageWidth - h - this.offsetX
          )
        };
        break;
      case "left":
        w = {
          top: W(
            v + (l - f) / 2,
            this.offsetY,
            this.pageHeight - f - this.offsetY
          ),
          left: Math.max(0, g - h - this.offsetX)
        };
        break;
      default:
        w = { top: 0, left: 0 };
    }
    return this.position = S, {
      top: w.top + this.globalOffsetY,
      left: w.left + this.globalOffsetX
    };
  }
  destroy(t = !1) {
    if (!this.container)
      return this;
    const e = this.container;
    if (this.cancelPositionUpdate(), this.clearDestroyFallbackTimer(), this.showed = !1, this.syncAriaDescribedBy(!1), this.onResizeObserver?.disconnect(), this.intersectionObserver?.disconnect(), this.detachScrollListener(), t)
      return e.remove(), this.container = void 0, this;
    e.removeEventListener("mouseleave", this.onTooltipMouseLeave), e.style.pointerEvents = "none", e.style.opacity = "0";
    const i = () => {
      this.clearDestroyFallbackTimer(), e?.remove(), this.container === e && (this.container = void 0);
    };
    return e.addEventListener("transitionend", i, {
      once: !0
    }), e.addEventListener("transitioncancel", i, {
      once: !0
    }), this.destroyFallbackTimerId = globalThis.setTimeout(
      i,
      Zt.DESTROY_FALLBACK_MS
    ), this;
  }
  syncAriaDescribedBy(t) {
    const e = this.target.getAttribute("aria-describedby");
    if (this.prevAriaDescribedBy ?? (this.prevAriaDescribedBy = e), !t) {
      this.prevAriaDescribedBy === null ? this.target.removeAttribute("aria-describedby") : this.target.setAttribute("aria-describedby", this.prevAriaDescribedBy), this.prevAriaDescribedBy = null;
      return;
    }
    const i = new Set((e ?? "").split(/\s+/).filter(Boolean));
    i.add(this.tooltipId), this.target.setAttribute("aria-describedby", Array.from(i).join(" "));
  }
  set bordered(t) {
    this._bordered = t, this.container?.classList.toggle("vot-tooltip-bordered", t);
  }
  get bordered() {
    return this._bordered;
  }
  set hidden(t) {
    this._hidden = t, this.container && (this.container.hidden = t), this.showed && this.syncAriaDescribedBy(!t);
  }
  get hidden() {
    return this._hidden;
  }
  attachScrollListener() {
    this.scrollListening || (this.scrollListening = !0, document.addEventListener("scroll", this.onScroll, {
      passive: !0,
      capture: !0
    }));
  }
  detachScrollListener() {
    this.scrollListening && (this.scrollListening = !1, document.removeEventListener("scroll", this.onScroll, {
      capture: !0
    }));
  }
};
c(Zt, "DESTROY_FALLBACK_MS", 700);
let ct = Zt;
const _b = ["srt", "vtt", "ass", "json"], ic = [
  "default-sans",
  "arial",
  "helvetica",
  "roboto",
  "verdana",
  "open-sans",
  "poppins",
  "lato",
  "montserrat",
  "barlow"
], da = {
  "default-sans": '"Roboto", "Segoe UI", system-ui, sans-serif',
  arial: 'Arial, "Helvetica Neue", Helvetica, sans-serif',
  helvetica: '"Helvetica Neue", Helvetica, Arial, sans-serif',
  roboto: '"Roboto", "Segoe UI", system-ui, sans-serif',
  verdana: "Verdana, Geneva, sans-serif",
  "open-sans": '"Open Sans", "Segoe UI", system-ui, sans-serif',
  poppins: '"Poppins", "Segoe UI", system-ui, sans-serif',
  lato: '"Lato", "Segoe UI", system-ui, sans-serif',
  montserrat: '"Montserrat", "Segoe UI", system-ui, sans-serif',
  barlow: '"Barlow", "Segoe UI", system-ui, sans-serif'
};
function ii(n) {
  return ic.includes(n);
}
const Ss = "google:", Rb = "https://fonts.googleapis.com/css2", Bb = "https://fonts.google.com/metadata/fonts", Fb = {
  roboto: "Roboto",
  "open-sans": "Open Sans",
  poppins: "Poppins",
  lato: "Lato",
  montserrat: "Montserrat",
  barlow: "Barlow"
}, Gi = /* @__PURE__ */ new Set(), Ki = /* @__PURE__ */ new Map();
let qe = null;
function Nb(n) {
  return `${Ss}${n}`;
}
function Ee(n) {
  if (n.startsWith(Ss)) {
    const t = n.slice(Ss.length).trim();
    return t.length > 0 ? t : null;
  }
  return Fb[n] ?? null;
}
function ha(n) {
  if (ii(n))
    return da[n];
  const t = Ee(n);
  return t ? `"${t}", "Segoe UI", system-ui, sans-serif` : da["default-sans"];
}
function Ub(n) {
  const t = Ee(n);
  if (!t)
    return null;
  const e = t.trim().replaceAll(/\s+/g, "+");
  return `${Rb}?family=${e}&display=swap`;
}
function Hb(n, t) {
  const e = `vot-google-font-${n}`;
  if (document.getElementById(e))
    return;
  const i = globalThis.GM_addStyle, s = typeof i == "function" ? i(t) : document.createElement("style");
  s instanceof HTMLElement && (s.id = e, s.textContent || (s.textContent = t), s.parentElement || (document.head || document.documentElement).appendChild(s));
}
async function $b(n, t = {}) {
  if (Gi.has(n))
    return;
  const e = Ki.get(n);
  if (e !== void 0) {
    await e;
    return;
  }
  const i = Ub(n);
  if (!i) {
    Gi.add(n);
    return;
  }
  const s = Ee(n), o = (async () => {
    try {
      const r = await nt(i, {
        timeout: 1e4,
        forceGmXhr: t.forceGmXhr ?? !0,
        headers: {
          Accept: "text/css,*/*;q=0.1"
        }
      });
      if (!r.ok)
        throw new Error(
          `Google Fonts CSS request failed with ${r.status}`
        );
      const a = await r.text();
      if (!a.trim())
        throw new Error("Google Fonts CSS response is empty");
      Hb(n, a), Gi.add(n), document.fonts && s && await document.fonts.load(`500 20px "${s}"`), t.onLoaded?.();
    } catch {
    } finally {
      Ki.delete(n);
    }
  })();
  Ki.set(n, o), await o;
}
async function Wb() {
  return qe !== null ? await qe : (qe = (async () => {
    const n = await nt(Bb, {
      timeout: 15e3,
      forceGmXhr: cn
    });
    if (!n.ok)
      throw new Error(
        `Google Fonts metadata request failed with ${n.status}`
      );
    const e = (await n.text()).replace(/^\)\]\}'\n?/, ""), s = JSON.parse(e).familyMetadataList?.map((o) => o.family?.trim() ?? "").filter((o) => o.length > 0);
    return Array.from(new Set(s)).sort(
      (o, r) => o.localeCompare(r)
    );
  })().catch((n) => (qe = null, [])), await qe);
}
class zb {
  constructor({ video: t, container: e }) {
    c(this, "video");
    c(this, "container");
    c(this, "fullscreenLayer", null);
    this.video = t, this.container = e;
  }
  updateContainer(t) {
    this.container = t;
  }
  getWidgetParentElement() {
    return this.shouldUseFullscreenViewportLayer() ? this.ensureFullscreenLayer() : this.container;
  }
  getLayoutRootElement() {
    return this.fullscreenLayer?.isConnected ? this.fullscreenLayer : this.container;
  }
  syncWidgetContainer(t) {
    const e = this.getWidgetParentElement();
    e === this.container && getComputedStyle(this.container).position === "static" && (this.container.style.position = "relative"), t && t.parentElement !== e && e.appendChild(t), e === this.container && this.fullscreenLayer?.parentElement && (this.fullscreenLayer.remove(), this.fullscreenLayer = null);
  }
  release() {
    this.fullscreenLayer && (this.fullscreenLayer.remove(), this.fullscreenLayer = null);
  }
  getActiveFullscreenElement() {
    const t = document, e = t.fullscreenElement ?? t.webkitFullscreenElement;
    return Zs(
      e,
      [this.container, this.video],
      {
        allowDocumentViewport: !0
      }
    );
  }
  isCurrentVideoInFullscreenSession() {
    const t = this.getActiveFullscreenElement();
    return t ? t === this.container || t.contains(this.container) || this.container.contains(t) ? !0 : !!(this.video && (t === this.video || t.contains(this.video) || this.video.contains(t))) : !1;
  }
  shouldUseFullscreenViewportLayer() {
    return this.isCurrentVideoInFullscreenSession();
  }
  ensureFullscreenLayer() {
    if (!this.fullscreenLayer) {
      const i = document.createElement("vot-block");
      i.classList.add("vot-subtitles-layer"), Object.assign(i.style, {
        position: "absolute",
        inset: "0",
        zIndex: "2147483647",
        pointerEvents: "none"
      }), this.fullscreenLayer = i;
    }
    const t = this.getActiveFullscreenElement(), e = t instanceof HTMLElement ? t : this.container;
    return getComputedStyle(e).position === "static" && (e.style.position = "relative"), this.fullscreenLayer.parentElement !== e && e.appendChild(this.fullscreenLayer), this.fullscreenLayer;
  }
}
function qb(n, t) {
  return n >= t.startMs && n < t.startMs + t.durationMs;
}
function Gb(n, t) {
  let e = 0, i = t.length - 1;
  for (; e <= i; ) {
    const s = e + i >> 1, o = t[s];
    if (n < o.startMs)
      i = s - 1;
    else if (n >= o.startMs + o.durationMs)
      e = s + 1;
    else
      return s;
  }
  return -1;
}
function Ft(n, t, e) {
  return Math.max(t, Math.min(n, e));
}
function Kb(n, t, e, i, s) {
  const o = e - n, r = i - t;
  return o * o + r * r >= s * s;
}
function fa({
  anchorX: n,
  anchorY: t,
  elementWidth: e,
  elementHeight: i,
  boxWidth: s,
  boxHeight: o,
  bottomInset: r
}) {
  let a = n, l = t;
  const u = Math.max(0, o - r), d = i || 0;
  if (e) {
    let h = a - e / 2;
    const f = s - e;
    f >= 0 ? h = Ft(h, 0, f) : h = f / 2, a = h + e / 2;
  }
  return l = Ft(l, d, u), { anchorX: a, anchorY: l };
}
function ga({
  current: n,
  candidates: t,
  thresholdPx: e
}) {
  let i = n, s = Number.POSITIVE_INFINITY;
  for (const o of t) {
    const r = Math.abs(o - n);
    r < s && (s = r, i = o);
  }
  return !Number.isFinite(s) || s > e ? { snapped: !1, value: n } : { snapped: !0, value: i };
}
const ma = (n, t) => !!n?.italic == !!t?.italic && !!n?.bold == !!t?.bold && !!n?.underline == !!t?.underline;
function Yb(n, t, e) {
  const i = [];
  let s = "", o;
  for (let r = 0; r <= t; ) {
    const a = n[r], l = a?.text ?? "";
    if (!l) {
      r += 1;
      continue;
    }
    if (l === `
`) {
      s && (i.push({
        kind: "text",
        text: s,
        style: o
      }), s = "", o = void 0), i.push({ kind: "break" }), r += 1;
      continue;
    }
    if (a.isWordLike) {
      let h = s + l;
      const f = s ? o : a.style;
      s = "", o = void 0;
      let g = r, v = !!e?.has(r) ? r : null;
      for (; v === null && g + 1 <= t; ) {
        const T = n[g + 1];
        if (!T || T.isWordLike || T.text === `
` || !ma(T.style, f))
          break;
        if (h += T.text, g += 1, e?.has(g)) {
          v = g;
          break;
        }
      }
      if (v !== null) {
        for (i.push(
          {
            kind: "word",
            text: h,
            style: f
          },
          { kind: "break" }
        ), r = v + 1; r <= t && !n[r]?.isWordLike && !n[r]?.text.trim(); )
          r += 1;
        continue;
      }
      i.push({
        kind: "word",
        text: h,
        style: f
      }), r = g + 1;
      continue;
    }
    const u = !!e?.has(r);
    if (!(l.trim().length === 0)) {
      u ? (i.push(
        {
          kind: "text",
          text: s + l,
          style: s ? o : a.style
        },
        { kind: "break" }
      ), s = "", o = void 0) : (s && !ma(o, a.style) && (i.push({
        kind: "text",
        text: s,
        style: o
      }), s = ""), s += l, o = a.style), r += 1;
      continue;
    }
    s && (i.push({
      kind: "text",
      text: s,
      style: o
    }), s = "", o = void 0), u ? i.push(
      {
        kind: "text",
        text: l,
        style: a.style
      },
      { kind: "break" }
    ) : i.push({
      kind: "text",
      text: l,
      style: a.style
    }), r += 1;
  }
  return s && i.push({
    kind: "text",
    text: s,
    style: o
  }), i;
}
const jb = 0.55;
function Xb(n, t, e) {
  return Number.isNaN(n) ? t : Math.min(e, Math.max(t, n));
}
function Jb(n) {
  return n < 1 ? 28 : n < 1.4 ? 32 : 42;
}
function Zb(n, t) {
  const e = Math.max(1, n.w), i = Math.max(1, n.h), s = e / i;
  let o = Jb(s);
  if (t) {
    const { fontSizePx: a, maxWidthPx: l } = t;
    if (Number.isFinite(a) && Number.isFinite(l) && a > 0 && l > 0) {
      const u = a * jb;
      u > 0 && (o = l / u);
    }
  }
  return { maxLength: Xb(Math.round(o * 2), 50, 180) };
}
const pa = (n) => !!(n?.isWordLike && n.text?.trim()), le = (n, t, e) => Math.min(e, Math.max(t, n)), sc = (n, t, e) => e < t ? 0 : n[e + 1] - n[t], Qb = /[.!?\u2026]+(?:["'`)\]}\u00BB\u201D\u2019]+)?$/u;
function ty(n) {
  const t = [];
  let e = "";
  for (let i = 0; i < n.length; i += 1) {
    const s = n[i];
    if (!pa(s)) continue;
    let o = s.text, r = i, a = s.text.length, l = i + 1, u = !1, d = !1;
    for (; l < n.length; ) {
      const f = n[l];
      if (!f) {
        l += 1;
        continue;
      }
      if (pa(f)) break;
      if (f.text === `
`) {
        r = l;
        break;
      }
      const g = f.text ?? "";
      if (o += g, !g.trim()) {
        u && (d = !0), l += 1;
        continue;
      }
      d || (r = l, u = !0, a = o.length), l += 1;
    }
    const h = o.slice(a);
    t.push({
      tokenIndex: i,
      breakAfterTokenIndex: r,
      textToNextWord: o,
      trailingGapAfterBreakText: h
    }), e && (e += ""), e += `${o}${h}${r}`;
  }
  return {
    slices: t,
    key: e
  };
}
function ey(n, t) {
  const e = n.length, i = new Array(e), s = new Array(e), o = new Array(e), r = new Array(e), a = new Array(e + 1), l = new Array(e + 1);
  a[0] = 0, l[0] = 0;
  for (let u = 0; u < e; u += 1) {
    const d = n[u].textToNextWord, h = n[u].trailingGapAfterBreakText, f = t(d), g = d.length, m = h.length, v = m ? t(h) : 0;
    i[u] = f, s[u] = g, o[u] = v, r[u] = m, a[u + 1] = a[u] + f, l[u + 1] = l[u] + g;
  }
  return {
    widths: i,
    chars: s,
    trailingGapWidths: o,
    trailingGapChars: r,
    prefixWidths: a,
    prefixChars: l
  };
}
const no = (n, t, e) => sc(n.prefixWidths, t, e) - (n.trailingGapWidths[e] ?? 0);
function ny(n, t, e) {
  if (e < t || !n.widths.length) return 0;
  const i = le(t, 0, n.widths.length - 1), s = le(e, 0, n.widths.length - 1);
  return s < i ? 0 : no(n, i, s);
}
const iy = (n, t, e) => sc(n.prefixChars, t, e) - (n.trailingGapChars[e] ?? 0);
function oc(n, t, e, i) {
  if (e < t) return !0;
  if (i <= 0) return !1;
  if (!n.widths.length) return !0;
  const s = le(t, 0, n.widths.length - 1), o = le(e, 0, n.widths.length - 1);
  if (o < s) return !0;
  const r = n.prefixWidths, a = n.trailingGapWidths, l = r[s], u = r[o + 1], d = a[o] ?? 0;
  if (u - l - d <= i)
    return !0;
  for (let h = s; h < o; h += 1) {
    const f = r[h + 1], g = f - l - (a[h] ?? 0), m = u - f - d;
    if (g <= i && m <= i)
      return !0;
  }
  return !1;
}
const sy = (n, t, e, i, s, o) => {
  const r = (n + t) / 2, a = e - n, l = e - t, u = a * a + l * l, d = n - r, h = t - r, f = d * d + h * h, m = o >= 4 && (i <= 1 || s <= 1) ? 1e9 : 0, T = o >= 6 && (i <= 2 || s <= 2) ? 2e7 : 0;
  let S = u + f + m + T;
  return n > t && (S += (n - t) / Math.max(1, e) * 0.15), S;
};
function rc(n, t, e, i) {
  if (i <= 0 || !n.widths.length) return null;
  const s = le(t, 0, n.widths.length - 1), o = le(e, 0, n.widths.length - 1);
  if (o <= s) return null;
  const r = n.prefixWidths, a = n.trailingGapWidths, l = r[s], u = r[o + 1], d = a[o] ?? 0;
  let h = null, f = Number.POSITIVE_INFINITY;
  const g = o - s + 1;
  for (let m = s; m < o; m += 1) {
    const v = r[m + 1], T = v - l - (a[m] ?? 0), S = u - v - d;
    if (T > i || S > i) continue;
    const w = m - s + 1, x = o - m, I = sy(
      T,
      S,
      i,
      w,
      x,
      g
    );
    I < f && (f = I, h = m);
  }
  return h;
}
function ac(n, t) {
  const e = n.widths.length;
  if (e <= 1 || t <= 0) return [];
  if (no(n, 0, e - 1) <= t)
    return [];
  const i = rc(n, 0, e - 1, t);
  return i === null ? [] : [i];
}
function oy(n, t) {
  const e = n.widths.length;
  if (e <= 0 || t <= 0) return null;
  let i = 0, s = e - 1, o = null;
  for (; i <= s; ) {
    const r = i + s >> 1;
    oc(n, 0, r, t) ? (o = r, i = r + 1) : s = r - 1;
  }
  return o;
}
function ry(n, t) {
  if (t <= 0)
    return {
      breakAfterWordIndices: [],
      truncateAfterWordIndex: null
    };
  const e = n.widths.length;
  if (e <= 1)
    return {
      breakAfterWordIndices: [],
      truncateAfterWordIndex: null
    };
  if (no(n, 0, e - 1) <= t)
    return {
      breakAfterWordIndices: [],
      truncateAfterWordIndex: null
    };
  const s = ac(n, t);
  if (s.length)
    return {
      breakAfterWordIndices: s,
      truncateAfterWordIndex: null
    };
  const r = oy(n, t) ?? 0;
  if (r >= e - 1)
    return {
      breakAfterWordIndices: [],
      truncateAfterWordIndex: null
    };
  const a = rc(
    n,
    0,
    r,
    t
  );
  return {
    breakAfterWordIndices: a === null ? [] : [a],
    truncateAfterWordIndex: r
  };
}
const io = (n) => n.endWord - n.startWord + 1, ay = (n, t) => {
  const e = [];
  let i = 0;
  for (; i < n; ) {
    let s = i;
    for (; s + 1 < n && t(i, s + 1); )
      s += 1;
    e.push({ startWord: i, endWord: s }), i = s + 1;
  }
  return e;
}, ly = (n, t, e) => {
  if (t <= 0) return !1;
  const i = n[t], s = n[t - 1];
  if (!i || !s || io(s) < 3) return !1;
  const o = s.endWord, r = {
    startWord: s.startWord,
    endWord: o - 1
  }, a = {
    startWord: o,
    endWord: i.endWord
  };
  return !e(r.startWord, r.endWord) || !e(a.startWord, a.endWord) ? !1 : (s.endWord = r.endWord, i.startWord = a.startWord, !0);
}, cy = (n, t, e) => {
  if (t >= n.length - 1) return !1;
  const i = n[t], s = n[t + 1];
  if (!i || !s || io(s) < 3) return !1;
  const o = s.startWord, r = {
    startWord: i.startWord,
    endWord: o
  }, a = {
    startWord: o + 1,
    endWord: s.endWord
  };
  return !e(r.startWord, r.endWord) || !e(a.startWord, a.endWord) ? !1 : (i.endWord = r.endWord, s.startWord = a.startWord, !0);
}, uy = (n, t) => {
  for (let e = n.length - 1; e >= 0; e -= 1)
    io(n[e]) === 1 && (ly(n, e, t) || cy(n, e, t));
}, dy = (n, t, e) => {
  const i = t[e];
  if (!i) return "";
  let s = "";
  for (let o = i.tokenIndex; o <= i.breakAfterTokenIndex; o += 1)
    s += n[o]?.text ?? "";
  return s.trimEnd();
}, hy = (n, t, e, i) => {
  for (let s = 0; s < n.length - 1; s += 1) {
    const o = n[s], r = n[s + 1];
    if (!o || !r) continue;
    let a = -1;
    const l = Math.max(o.startWord, o.endWord - 2);
    for (let m = o.endWord - 1; m >= l; m -= 1)
      if (Qb.test(dy(t, e, m))) {
        a = m;
        break;
      }
    if (a < o.startWord) continue;
    const u = o.startWord, d = a;
    if (d - u + 1 < 3) continue;
    const f = a + 1, g = r.endWord;
    !i(u, d) || !i(f, g) || (o.endWord = d, r.startWord = f);
  }
}, fy = (n, t, e) => {
  const i = t[e];
  if (!i) return 0;
  const s = e > 0 ? t[e - 1]?.breakAfterTokenIndex ?? i.tokenIndex - 1 : -1;
  let o = le(
    s + 1,
    0,
    i.tokenIndex
  );
  for (; o < i.tokenIndex && !n[o]?.text.trim(); )
    o += 1;
  return o;
}, gy = (n, t, e) => {
  const i = [];
  for (const s of n) {
    const o = t[s.startWord], r = t[s.endWord];
    if (!o || !r) continue;
    const a = fy(e, t, s.startWord), l = r.breakAfterTokenIndex + 1, u = e[o.tokenIndex]?.startMs ?? e[a]?.startMs ?? 0, d = e[r.tokenIndex]?.startMs ?? u, h = e[r.tokenIndex]?.durationMs ?? 0, f = t[s.endWord + 1], m = (f ? e[f.tokenIndex]?.startMs : void 0) ?? d + h;
    i.push({
      startToken: a,
      endToken: l,
      startMs: u,
      endMs: m
    });
  }
  return i;
};
function my(n, t, e, i, s) {
  const o = t.length;
  if (o === 0) return [];
  const r = Number.isFinite(s) && s > 0 ? s : null, a = (u, d) => d < u || r !== null && iy(e, u, d) > r ? !1 : oc(e, u, d, i), l = ay(o, a);
  return uy(l, a), hy(l, n, t, a), gy(l, t, n);
}
const py = 8, by = 0.97, yy = 24;
function ba(n) {
  if (!Number.isFinite(n) || n <= 0) return 0;
  const t = n - py, e = n * by, i = Math.min(t, e);
  return Math.max(yy, i);
}
class vy {
  constructor(t, e, i, s = void 0) {
    c(this, "video");
    c(this, "container");
    c(this, "fullscreenLayerController");
    c(this, "tooltipLayoutRoot");
    c(this, "subtitlesContainer", null);
    c(this, "subtitlesBlock", null);
    c(this, "renderedTokenEls", []);
    c(this, "passedFlagsBuffer", []);
    c(this, "subtitles", null);
    c(this, "subtitleLang");
    c(this, "lastRenderKey", null);
    c(this, "lastActiveLineIndex", null);
    c(this, "highlightWords", !1);
    c(this, "fontSize", 20);
    c(this, "fontSizeOverridden", !1);
    c(this, "fontFamily", "default-sans");
    c(this, "manualMaxLength", 300);
    c(this, "smartLayoutEnabled", !0);
    c(this, "smartFontSizePx", 0);
    c(this, "smartMaxWidthPx", 0);
    c(this, "smartMaxLength", 0);
    c(this, "smartAnchorWidthPx", 0);
    c(this, "smartAnchorHeightPx", 0);
    c(this, "lastSmartLayoutKey", null);
    c(this, "lastSmartLayoutCheckTs", 0);
    c(this, "opacity", "0.2");
    c(this, "maxLength", 300);
    c(this, "repositionPending", !1);
    c(this, "positionRefreshPending", !1);
    c(this, "updatePending", !1);
    c(this, "lastUpdateRequestTs", 0);
    c(this, "updateMinIntervalMs", 100);
    c(this, "updateMinIntervalHighlightMs", 33);
    c(this, "useVideoFrameCallbacks");
    c(this, "videoFrameRequestId", null);
    c(this, "dragDocListenersAttached", !1);
    c(this, "lastPositionRefreshTs", 0);
    c(this, "positionRefreshIntervalMs", 250);
    c(this, "subtitleMaxWidthPx", 0);
    c(this, "breakAfterTokenIndices", []);
    c(this, "breakAfterTokenIndexSet", null);
    c(this, "smartTruncateAfterTokenIndex", null);
    c(this, "wrapPending", !1);
    c(this, "lastWrapKey", null);
    c(this, "lastWrapTokens", null);
    c(this, "measureCanvas", null);
    c(this, "measureCtx", null);
    c(this, "tokenProcessingMemo", null);
    c(this, "tokenPrecomputeMemo", null);
    c(this, "lineMeasureMemo", null);
    c(this, "lastSegmentIndex", 0);
    c(this, "lastAppliedLeftPct", null);
    c(this, "lastAppliedTopPct", null);
    c(this, "position", {
      left: 50,
      top: 100
    });
    c(this, "positionPreset", "bottom-center");
    c(this, "dragging", {
      pointerId: null,
      candidate: !1,
      active: !1,
      moved: !1,
      startClientX: 0,
      startClientY: 0,
      offset: {
        x: 0,
        y: 0
      }
    });
    c(this, "dragStartThresholdPx", 4);
    c(this, "snapThresholdPx", 18);
    c(this, "suppressTokenClicksUntil", 0);
    c(this, "abortController", new AbortController());
    c(this, "resizeObserver");
    c(this, "tokenTooltip");
    c(this, "tooltipTranslationRequestId", 0);
    c(this, "intervalIdleChecker");
    c(this, "checkerUnsubscribe", null);
    c(this, "edgePunctuationTrimRe", /(?:^[\p{P}\p{S}]+|[\p{P}\p{S}]+$)/gu);
    c(this, "strTokens", "");
    c(this, "strTranslatedTokens", "");
    c(this, "passedStateKey", null);
    c(this, "passedThresholds", []);
    c(this, "bottomInsetCachedPx", 0);
    // layout px
    c(this, "safeAreaBottomInsetCachedPx", 0);
    c(this, "containerPaddingBottomCachedPx", 0);
    c(this, "insetCacheReady", !1);
    c(this, "bottomInsetByMode", {
      normal: {
        ratio: 0.1,
        minPx: 56,
        maxPx: 220,
        gapPx: 10
      },
      fullscreen: {
        ratio: 0.07,
        minPx: 44,
        maxPx: 140,
        gapPx: 9
      }
    });
    c(this, "safeAreaProbeEl", null);
    c(this, "guidesLayer", null);
    c(this, "verticalGuide", null);
    c(this, "horizontalGuide", null);
    c(this, "onPointerDownBound");
    c(this, "onPointerUpBound");
    c(this, "onPointerMoveBound");
    c(this, "onTimeUpdateBound");
    c(this, "onPlaybackStateChangeBound");
    c(this, "onVisualViewportChangeBound");
    c(this, "onVideoFrame", (t, e) => {
      if (this.videoFrameRequestId = null, this.abortController.signal.aborted) return;
      const i = this.video;
      !i || i.paused || i.ended || this.subtitles && (this.requestUpdate(t), this.startVideoFrameLoop());
    });
    c(this, "onClick", async (t) => {
      if (performance.now() < this.suppressTokenClicksUntil) {
        t.preventDefault(), t.stopPropagation();
        return;
      }
      const e = this.resolveTokenSpanFromClick(t);
      if (!e) return;
      if (this.tokenTooltip?.target === e && this.tokenTooltip?.container) {
        this.tokenTooltip.showed ? e.classList.add("selected") : e.classList.remove("selected");
        return;
      }
      this.releaseTooltip();
      const i = this.tooltipTranslationRequestId, s = this.normalizeTokenTextForTranslation(
        e.textContent ?? ""
      );
      if (!s) return;
      const o = await C.get(
        "translationService",
        bi
      );
      if (i !== this.tooltipTranslationRequestId) return;
      e.classList.add("selected");
      const r = L.createSubtitleInfo(
        s,
        this.strTranslatedTokens || this.strTokens,
        o
      ), a = Math.max(
        this.subtitleMaxWidthPx,
        this.subtitlesContainer?.offsetWidth ?? 0,
        this.subtitlesBlock?.offsetWidth ?? 0,
        Math.min(globalThis.innerWidth * 0.6, 320)
      ), l = new ct({
        target: e,
        anchor: this.subtitlesBlock ?? e,
        layoutRoot: this.tooltipLayoutRoot,
        content: r.container,
        parentElement: this.getTokenTooltipParentElement(),
        offset: { x: 4, y: 12 },
        maxWidth: a,
        borderRadius: 12,
        bordered: !1,
        position: "top",
        trigger: "click"
      });
      this.tokenTooltip = l, l.onClick();
      const u = this.strTokens, d = await this.translateStrTokens(s);
      i === this.tooltipTranslationRequestId && (u !== this.strTokens || this.tokenTooltip !== l || l.target !== e || !l.showed || (r.header.textContent = d[1], r.context.textContent = d[0], l.setContent(r.container)));
    });
    this.video = t, this.container = e, this.fullscreenLayerController = new zb({
      video: t,
      container: e
    }), this.intervalIdleChecker = i, this.tooltipLayoutRoot = s, this.useVideoFrameCallbacks = !!this.video && typeof this.video.requestVideoFrameCallback == "function", this.onPointerDownBound = (o) => this.onPointerDown(o), this.onPointerUpBound = (o) => this.onPointerUp(o), this.onPointerMoveBound = (o) => this.onPointerMove(o), this.onTimeUpdateBound = () => this.requestUpdate(), this.onPlaybackStateChangeBound = () => this.handlePlaybackStateChange(), this.onVisualViewportChangeBound = () => this.scheduleReposition(), this.checkerUnsubscribe = this.intervalIdleChecker.subscribe(() => {
      this.onCheckerTick();
    }), this.bindEvents();
  }
  normalizeTokenTextForTranslation(t) {
    return t.trim().replace(this.edgePunctuationTrimRe, "");
  }
  updateMount({
    container: t,
    tooltipLayoutRoot: e
  }) {
    const i = this.container !== t, s = this.tooltipLayoutRoot !== e;
    this.container = t, this.fullscreenLayerController.updateContainer(t), this.tooltipLayoutRoot = e, this.syncWidgetMount(), (i || s) && this.tokenTooltip?.updateMount({
      parentElement: this.getTokenTooltipParentElement(),
      layoutRoot: this.tooltipLayoutRoot ?? document.documentElement
    }), this.subtitles && (this.insetCacheReady = !1, this.lastAppliedLeftPct = null, this.lastAppliedTopPct = null, this.updateContainerRect(), this.requestUpdate());
  }
  resetTranslationContext(t = !1) {
    this.strTranslatedTokens = "", t && this.releaseTooltip();
  }
  resetSegmentationMemo() {
    this.tokenProcessingMemo = null, this.tokenPrecomputeMemo = null, this.lineMeasureMemo = null, this.lastSegmentIndex = 0;
  }
  resetWrapMemo() {
    this.setBreakAfterTokenIndices([]), this.smartTruncateAfterTokenIndex = null, this.lastWrapKey = null;
  }
  resetRenderMemo() {
    this.lastRenderKey = null;
  }
  computeAnchorBoxLayout(t) {
    const e = {
      left: 0,
      top: 0,
      w: t.w,
      h: t.h
    }, i = this.video;
    if (!i) return e;
    const s = i.getBoundingClientRect();
    if (!(s.width > 0 && s.height > 0)) return e;
    const o = t.rect;
    if (!(s.right > o.left && s.left < o.right && s.bottom > o.top && s.top < o.bottom)) return e;
    const a = s.width / t.scaleX, l = s.height / t.scaleY;
    if (!(a > 0 && l > 0)) return e;
    const u = (s.left - o.left) / t.scaleX, d = (s.top - o.top) / t.scaleY, h = t.w - a, f = t.h - l, g = h >= 0 ? Ft(u, 0, h) : (t.w - a) / 2, m = f >= 0 ? Ft(d, 0, f) : (t.h - l) / 2;
    return { left: g, top: m, w: a, h: l };
  }
  readSmartCssMetrics() {
    const t = this.subtitlesBlock;
    if (!t) return null;
    const e = getComputedStyle(t), i = Number.parseFloat(e.fontSize), s = Number.parseFloat(e.maxWidth);
    if (!Number.isFinite(i) || !Number.isFinite(s) || i <= 0 || s <= 0)
      return null;
    this.subtitleMaxWidthPx = s;
    const o = Number.parseFloat(e.paddingLeft) || 0, r = Number.parseFloat(e.paddingRight) || 0, a = Math.max(0, s - o - r);
    return a <= 0 ? null : { fontSizePx: i, maxWidthPx: a };
  }
  ensureSmartLayout(t) {
    if (!this.smartLayoutEnabled)
      return this.maxLength = this.manualMaxLength, null;
    const e = this.readSmartCssMetrics(), i = e?.fontSizePx ?? this.smartFontSizePx, s = e?.maxWidthPx ?? this.smartMaxWidthPx, o = Zb(t, e), r = `${Math.round(i)}|${Math.round(
      s
    )}|${o.maxLength}`, a = Math.abs(i - this.smartFontSizePx) > 0.5, l = Math.abs(s - this.smartMaxWidthPx) > 0.5, u = o.maxLength !== this.smartMaxLength;
    return r !== this.lastSmartLayoutKey && (this.lastSmartLayoutKey = r, this.smartFontSizePx = i, this.smartMaxWidthPx = s, this.smartMaxLength = o.maxLength), u && (this.maxLength = o.maxLength, this.resetRenderMemo(), this.resetSegmentationMemo()), (a || l) && this.lastWrapTokens && (this.lastWrapKey = null, this.scheduleWrapRecompute(), this.resetSegmentationMemo()), o;
  }
  scheduleReposition() {
    this.abortController.signal.aborted || this.subtitles && (this.repositionPending = !0, this.intervalIdleChecker.markActivity("subtitles-reposition"), this.intervalIdleChecker.requestImmediateTick());
  }
  setSubtitlesContainerVar(t, e) {
    const i = this.subtitlesContainer;
    if (i) {
      if (e === null) {
        i.style.removeProperty(t);
        return;
      }
      i.style.setProperty(t, e);
    }
  }
  applyOpacityStyle() {
    this.setSubtitlesContainerVar("--vot-subtitles-opacity", this.opacity);
  }
  applyManualFontSizeStyle() {
    if (!this.smartLayoutEnabled && this.fontSizeOverridden) {
      this.setSubtitlesContainerVar(
        "--vot-subtitles-font-size",
        `${this.fontSize}px`
      );
      return;
    }
    this.setSubtitlesContainerVar("--vot-subtitles-font-size", null);
  }
  applyFontFamilyStyle() {
    const t = this.fontFamily;
    this.setSubtitlesContainerVar(
      "--vot-subtitles-font-family-custom",
      ha(t)
    ), $b(t, {
      forceGmXhr: !0,
      onLoaded: () => {
        this.fontFamily === t && (this.lastWrapKey = null, this.resetSegmentationMemo(), this.scheduleWrapRecompute(), this.scheduleReposition());
      }
    });
  }
  syncVisualStyleVars() {
    this.applyOpacityStyle(), this.applyManualFontSizeStyle(), this.applyFontFamilyStyle();
  }
  ensureGuidesLayer() {
    if (this.guidesLayer)
      return this.guidesLayer;
    const t = document.createElement("vot-block");
    t.classList.add("vot-subtitles-guides");
    const e = document.createElement("vot-block");
    e.classList.add(
      "vot-subtitles-guide",
      "vot-subtitles-guide--vertical"
    );
    const i = document.createElement("vot-block");
    return i.classList.add(
      "vot-subtitles-guide",
      "vot-subtitles-guide--horizontal"
    ), t.append(e, i), this.guidesLayer = t, this.verticalGuide = e, this.horizontalGuide = i, this.hideSnapGuides(), t;
  }
  hideSnapGuides() {
    this.verticalGuide?.removeAttribute("data-visible"), this.horizontalGuide?.removeAttribute("data-visible");
  }
  updateSnapGuides(t, e) {
    const { showVerticalCenter: i = !1, showHorizontalCenter: s = !1 } = e;
    this.ensureGuidesLayer().isConnected || this.syncGuideLayerMount(), this.verticalGuide && (this.verticalGuide.style.left = `${t.left + t.w / 2}px`, this.verticalGuide.style.top = `${t.top}px`, this.verticalGuide.style.height = `${t.h}px`, i ? this.verticalGuide.dataset.visible = "true" : delete this.verticalGuide.dataset.visible), this.horizontalGuide && (this.horizontalGuide.style.left = `${t.left}px`, this.horizontalGuide.style.top = `${t.top + t.h / 2}px`, this.horizontalGuide.style.width = `${t.w}px`, s ? this.horizontalGuide.dataset.visible = "true" : delete this.horizontalGuide.dataset.visible);
  }
  syncGuideLayerMount() {
    const t = this.fullscreenLayerController.getWidgetParentElement(), e = this.ensureGuidesLayer();
    e.parentElement !== t && t.appendChild(e);
  }
  syncWidgetMount() {
    this.fullscreenLayerController.syncWidgetContainer(this.subtitlesContainer), this.syncGuideLayerMount();
  }
  getTokenTooltipParentElement() {
    const t = this.fullscreenLayerController.getWidgetParentElement();
    return t === this.container ? document.documentElement : t;
  }
  createSubtitlesContainer() {
    if (this.subtitlesContainer)
      return this.subtitlesContainer;
    const t = document.createElement("vot-block");
    return t.classList.add("vot-subtitles-widget"), this.subtitlesContainer = t, this.syncWidgetMount(), t.addEventListener("pointerdown", this.onPointerDownBound, {
      signal: this.abortController.signal,
      passive: !0
    }), this.syncVisualStyleVars(), this.insetCacheReady = !1, this.updateContainerRect(), t;
  }
  bindEvents() {
    const { signal: t } = this.abortController, e = { signal: t };
    this.video?.addEventListener("play", this.onPlaybackStateChangeBound, e), this.video?.addEventListener(
      "pause",
      this.onPlaybackStateChangeBound,
      e
    ), this.video?.addEventListener(
      "seeking",
      this.onPlaybackStateChangeBound,
      e
    ), this.video?.addEventListener(
      "seeked",
      this.onPlaybackStateChangeBound,
      e
    ), this.video?.addEventListener(
      "ended",
      this.onPlaybackStateChangeBound,
      e
    ), this.resizeObserver = new ResizeObserver(() => this.onResize()), this.resizeObserver.observe(this.container), this.video && this.resizeObserver.observe(this.video), globalThis.visualViewport?.addEventListener(
      "resize",
      this.onVisualViewportChangeBound,
      e
    ), globalThis.visualViewport?.addEventListener(
      "scroll",
      this.onVisualViewportChangeBound,
      e
    );
  }
  getUpdateMinIntervalMs() {
    return this.highlightWords ? this.updateMinIntervalHighlightMs : this.updateMinIntervalMs;
  }
  requestUpdate(t = performance.now()) {
    if (this.abortController.signal.aborted || !this.subtitles) return;
    const e = this.getUpdateMinIntervalMs();
    t - this.lastUpdateRequestTs < e || (this.lastUpdateRequestTs = t, this.updatePending = !0, this.intervalIdleChecker.requestImmediateTick());
  }
  handlePlaybackStateChange() {
    if (!this.subtitles) {
      this.stopVideoFrameLoop();
      return;
    }
    this.scheduleReposition(), this.requestUpdate(), this.syncVideoFrameLoop();
  }
  syncVideoFrameLoop() {
    if (!this.useVideoFrameCallbacks) return;
    const t = this.video;
    if (t) {
      if (!this.subtitles || t.paused || t.ended) {
        this.stopVideoFrameLoop();
        return;
      }
      this.startVideoFrameLoop();
    }
  }
  startVideoFrameLoop() {
    if (!this.useVideoFrameCallbacks) return;
    const t = this.video;
    t && this.videoFrameRequestId === null && (this.videoFrameRequestId = t.requestVideoFrameCallback(
      this.onVideoFrame
    ));
  }
  stopVideoFrameLoop() {
    if (!this.useVideoFrameCallbacks) return;
    const t = this.video;
    if (t && this.videoFrameRequestId !== null) {
      try {
        t.cancelVideoFrameCallback(this.videoFrameRequestId);
      } catch {
      }
      this.videoFrameRequestId = null;
    }
  }
  onCheckerTick() {
    this.abortController.signal.aborted || (this.repositionPending && (this.repositionPending = !1, this.updateContainerRect(), this.updatePending = !0), this.wrapPending && (this.wrapPending = !1, this.recomputeWrapNow()), this.positionRefreshPending && (this.positionRefreshPending = !1, this.applySubtitlePosition()), this.updatePending && (this.updatePending = !1, this.update()));
  }
  attachDragDocumentListeners() {
    this.dragDocListenersAttached || (this.dragDocListenersAttached = !0, document.addEventListener("pointermove", this.onPointerMoveBound, {
      passive: !1
    }), document.addEventListener("pointerup", this.onPointerUpBound), document.addEventListener("pointercancel", this.onPointerUpBound));
  }
  detachDragDocumentListeners() {
    this.dragDocListenersAttached && (this.dragDocListenersAttached = !1, document.removeEventListener("pointermove", this.onPointerMoveBound), document.removeEventListener("pointerup", this.onPointerUpBound), document.removeEventListener("pointercancel", this.onPointerUpBound));
  }
  onResize() {
    this.syncWidgetMount(), this.scheduleReposition();
  }
  updateContainerRect() {
    const t = this.getLayoutSize();
    if (!t.w || !t.h) return;
    const e = this.computeAnchorBoxLayout(t);
    !e.w || !e.h || (this.refreshBottomInsetNow(t, e), this.applySubtitlePositionWithLayout(t, e));
  }
  getLayoutSize() {
    const t = this.fullscreenLayerController.getLayoutRootElement(), e = t.getBoundingClientRect(), i = t.clientWidth || e.width, s = t.clientHeight || e.height, o = e.width && i ? e.width / i : 1, r = e.height && s ? e.height / s : 1;
    return { w: i, h: s, rect: e, scaleX: o, scaleY: r };
  }
  ensureSafeAreaProbe() {
    if (this.safeAreaProbeEl) return;
    const t = document.createElement("div");
    t.style.position = "fixed", t.style.left = "0", t.style.right = "0", t.style.bottom = "0", t.style.height = "env(safe-area-inset-bottom, 0px)", t.style.pointerEvents = "none", t.style.opacity = "0", t.style.zIndex = "-1", document.documentElement.appendChild(t), this.safeAreaProbeEl = t;
  }
  getSafeAreaBottomInsetPx() {
    return this.ensureSafeAreaProbe(), this.safeAreaProbeEl && this.safeAreaProbeEl.offsetHeight || 0;
  }
  refreshInsetCache() {
    const t = this.fullscreenLayerController.getLayoutRootElement();
    this.safeAreaBottomInsetCachedPx = this.getSafeAreaBottomInsetPx(), this.containerPaddingBottomCachedPx = Number.parseFloat(getComputedStyle(t).paddingBottom || "0") || 0, this.insetCacheReady = !0;
  }
  isMobileViewport() {
    return typeof globalThis.matchMedia != "function" ? !1 : globalThis.matchMedia("(max-width: 900px) and (pointer: coarse)").matches;
  }
  getBottomInsetPreset() {
    const t = document, e = t.fullscreenElement ?? t.webkitFullscreenElement;
    if (!(e instanceof Element))
      return this.bottomInsetByMode.normal;
    const { container: i, video: s } = this;
    return e === i || e.contains(i) || i.contains(e) ? this.bottomInsetByMode.fullscreen : s && (e === s || e.contains(s) || s.contains(e)) ? this.bottomInsetByMode.fullscreen : this.bottomInsetByMode.normal;
  }
  computeReservedBottomInsetPx(t, e = this.getBottomInsetPreset()) {
    const i = t * e.ratio;
    return Ft(i, e.minPx, e.maxPx);
  }
  refreshBottomInsetNow(t, e) {
    this.refreshInsetCache();
    const i = e?.h ?? this.computeAnchorBoxLayout(t ?? this.getLayoutSize()).h;
    if (!i) {
      this.bottomInsetCachedPx = 0;
      return;
    }
    const s = this.getBottomInsetPreset();
    this.bottomInsetCachedPx = this.computeReservedBottomInsetPx(
      i,
      s
    );
  }
  getBottomInsetPx(t, e) {
    this.insetCacheReady || this.refreshInsetCache();
    const i = this.getBottomInsetPreset(), s = this.safeAreaBottomInsetCachedPx, o = this.containerPaddingBottomCachedPx;
    if (this.isMobileViewport())
      return Math.max(o, s);
    const r = e?.h ?? this.computeAnchorBoxLayout(t ?? this.getLayoutSize()).h, a = r ? this.computeReservedBottomInsetPx(r, i) : i.minPx, l = Math.max(this.bottomInsetCachedPx, a);
    return Math.max(o, s, l) + i.gapPx;
  }
  onPointerDown(t) {
    const e = this.subtitlesContainer;
    if (!e) return;
    const i = t.target;
    if (!(i instanceof Node) || !e.contains(i) || !t.isPrimary || t.pointerType === "mouse" && t.button !== 0) return;
    const s = this.getLayoutSize(), { rect: o, w: r, h: a, scaleX: l, scaleY: u } = s;
    if (!r || !a) return;
    const d = this.computeAnchorBoxLayout(s);
    if (!d.w || !d.h) return;
    this.lastPositionRefreshTs = performance.now();
    const h = e.getBoundingClientRect(), f = (t.clientX - o.left) / l - d.left, g = (t.clientY - o.top) / u - d.top, m = (h.left - o.left + h.width / 2) / l - d.left, v = (h.top - o.top + h.height) / u - d.top;
    this.dragging.pointerId = t.pointerId, this.dragging.candidate = !0, this.dragging.active = !1, this.dragging.moved = !1, this.dragging.startClientX = t.clientX, this.dragging.startClientY = t.clientY, this.dragging.offset.x = m - f, this.dragging.offset.y = v - g, this.hideSnapGuides(), this.attachDragDocumentListeners();
    const T = this.subtitlesBlock ?? (i instanceof Element ? i : null);
    try {
      T?.setPointerCapture(t.pointerId);
    } catch {
    }
  }
  onPointerUp(t) {
    this.dragging.pointerId !== null && t.pointerId === this.dragging.pointerId && (this.dragging.moved && (this.suppressTokenClicksUntil = performance.now() + 450), this.dragging.pointerId = null, this.dragging.candidate = !1, this.dragging.active = !1, this.dragging.moved = !1, this.hideSnapGuides(), this.detachDragDocumentListeners());
  }
  onPointerMove(t) {
    if (!this.dragging.candidate || this.dragging.pointerId === null || t.pointerId !== this.dragging.pointerId) return;
    if (this.dragging.active)
      this.dragging.moved = !0;
    else {
      if (!Kb(
        this.dragging.startClientX,
        this.dragging.startClientY,
        t.clientX,
        t.clientY,
        this.dragStartThresholdPx
      ))
        return;
      this.dragging.active = !0, this.dragging.moved = !0, this.suppressTokenClicksUntil = performance.now() + 450, this.releaseTooltip();
    }
    t.preventDefault(), t.stopPropagation();
    const e = this.getLayoutSize(), { rect: i, w: s, h: o, scaleX: r, scaleY: a } = e;
    if (!s || !o) return;
    const l = this.computeAnchorBoxLayout(e);
    if (!l.w || !l.h) return;
    const u = (t.clientX - i.left) / r - l.left, d = (t.clientY - i.top) / a - l.top;
    let h = u + this.dragging.offset.x, f = d + this.dragging.offset.y;
    const g = this.subtitlesContainer?.offsetWidth ?? 0, m = this.subtitlesContainer?.offsetHeight ?? 0, v = this.getBottomInsetPx(e, l), T = ga({
      current: h,
      candidates: [l.w / 2],
      thresholdPx: this.snapThresholdPx
    });
    T.snapped && (h = T.value);
    const S = l.h / 2 + m / 2, w = ga({
      current: f,
      candidates: [S],
      thresholdPx: this.snapThresholdPx
    });
    w.snapped && (f = w.value), { anchorX: h, anchorY: f } = fa({
      anchorX: h,
      anchorY: f,
      elementWidth: g,
      elementHeight: m,
      boxWidth: l.w,
      boxHeight: l.h,
      bottomInset: v
    }), this.positionPreset = "custom", this.position.left = h / l.w * 100, this.position.top = f / l.h * 100, this.updateSnapGuides(l, {
      showVerticalCenter: T.snapped,
      showHorizontalCenter: w.snapped
    }), this.applySubtitlePositionWithLayout(e, l);
  }
  applySubtitlePosition() {
    if (!this.subtitlesContainer) return;
    const e = this.getLayoutSize();
    if (!e.w || !e.h) return;
    const i = this.computeAnchorBoxLayout(e);
    !i.w || !i.h || this.applySubtitlePositionWithLayout(e, i);
  }
  applySubtitlePositionWithLayout(t, e) {
    const i = this.subtitlesContainer;
    if (!i) return;
    const s = Math.min(t.scaleX || 1, t.scaleY || 1), o = s > 0 && s < 0.999 ? Math.min(1 / s, 3) : 1;
    Math.abs(o - 1) < 1e-3 ? i.style.removeProperty(
      "--vot-subtitles-scale-compensation"
    ) : i.style.setProperty(
      "--vot-subtitles-scale-compensation",
      o.toFixed(3)
    );
    const r = Math.max(1, Math.round(e.w)), a = Math.max(1, Math.round(e.h));
    (r !== this.smartAnchorWidthPx || a !== this.smartAnchorHeightPx) && (this.smartAnchorWidthPx = r, this.smartAnchorHeightPx = a, i.style.setProperty(
      "--vot-subtitles-anchor-width",
      `${r}px`
    ), i.style.setProperty(
      "--vot-subtitles-anchor-height",
      `${a}px`
    ), this.lastWrapTokens && (this.lastWrapKey = null, this.resetSegmentationMemo(), this.scheduleWrapRecompute())), this.smartLayoutEnabled && this.ensureSmartLayout(e);
    const u = i.offsetWidth, d = i.offsetHeight, h = this.getBottomInsetPx(t, e);
    let f = this.position.left / 100 * e.w, g = this.position.top / 100 * e.h;
    if (this.positionPreset !== "custom") {
      const A = this.resolvePresetAnchorPosition({
        preset: this.positionPreset,
        anchorBox: e,
        elementWidth: u,
        elementHeight: d,
        bottomInset: h
      });
      f = A.anchorX, g = A.anchorY, e.w > 0 && (this.position.left = f / e.w * 100), e.h > 0 && (this.position.top = g / e.h * 100);
    }
    let m = f - u / 2, v = g - d;
    const T = e.w - u, S = e.h - h - d;
    T >= 0 ? m = Ft(m, 0, T) : m = T / 2, S >= 0 ? v = Ft(v, 0, S) : v = 0, f = m + u / 2, g = v + d;
    const w = e.left + f, x = e.top + g, I = w / t.w * 100, k = x / t.h * 100;
    (this.lastAppliedLeftPct === null || Math.abs(I - this.lastAppliedLeftPct) >= 0.01) && (i.style.left = `${I}%`, this.lastAppliedLeftPct = I), (this.lastAppliedTopPct === null || Math.abs(k - this.lastAppliedTopPct) >= 0.01) && (i.style.top = `${k}%`, this.lastAppliedTopPct = k), this.tokenTooltip?.updatePos();
  }
  resolvePresetAnchorPosition({
    preset: t,
    anchorBox: e,
    elementWidth: i,
    elementHeight: s,
    bottomInset: o
  }) {
    let r = e.w / 2, a = e.h - o;
    switch (t) {
      case "top-center":
        a = s;
        break;
      case "center":
        a = e.h / 2 + s / 2;
        break;
      case "bottom-left":
        r = i / 2;
        break;
      case "bottom-right":
        r = e.w - i / 2;
        break;
    }
    return fa({
      anchorX: r,
      anchorY: a,
      elementWidth: i,
      elementHeight: s,
      boxWidth: e.w,
      boxHeight: e.h,
      bottomInset: o
    });
  }
  applyPositionAfterContentRender() {
    const t = this.getLayoutSize();
    if (t.w && t.h) {
      const e = this.computeAnchorBoxLayout(t);
      if (e.w && e.h) {
        this.refreshBottomInsetNow(t, e), this.applySubtitlePositionWithLayout(t, e);
        return;
      }
      this.refreshBottomInsetNow(t), this.applySubtitlePosition();
      return;
    }
    this.refreshBottomInsetNow(), this.applySubtitlePosition();
  }
  trimEdgeWhitespaceTokens(t) {
    if (!t.length) return t;
    let e = 0, i = t.length;
    for (; e < i && !t[e]?.text.trim(); ) e += 1;
    for (; i > e && !t[i - 1]?.text.trim(); ) i -= 1;
    return e === 0 && i === t.length ? t : e >= i ? [] : t.slice(e, i);
  }
  selectTokensByMaxLength(t, e) {
    if (!t.length) return t;
    let i = 0, s = 0, o = !1, r = 0, a = t.length, l = !1, u = !1;
    const d = (h, f) => {
      if (f <= h || (l || (r = h, a = f, l = !0), u)) return;
      const g = t[h], m = t[f - 1];
      if (!g || !m) return;
      const T = (f < t.length ? t[f]?.startMs : void 0) ?? m.startMs + (m.durationMs ?? 0);
      g.startMs <= e && e < T && (r = h, a = f, u = !0);
    };
    for (const [h, f] of t.entries()) {
      const g = s + f.text.length;
      if (g > this.maxLength && h > i) {
        o = !0, d(i, h), i = h, s = f.text.length;
        continue;
      }
      s = g;
    }
    return o ? (d(i, t.length), this.trimEdgeWhitespaceTokens(t.slice(r, a))) : this.trimEdgeWhitespaceTokens(t);
  }
  buildTokenPrecomputeInput(t) {
    const e = this.tokenPrecomputeMemo;
    if (e?.tokens === t)
      return e.value;
    const { slices: i, key: s } = ty(t), r = {
      words: i.map((a) => ({
        tokenIndex: a.tokenIndex,
        breakAfterTokenIndex: a.breakAfterTokenIndex
      })),
      wordSlices: i,
      normalizedWordsKey: s
    };
    return this.tokenPrecomputeMemo = {
      tokens: t,
      value: r
    }, r;
  }
  getTokenLayoutInputs(t) {
    const e = this.subtitlesBlock;
    if (e) {
      const u = getComputedStyle(e), d = `${u.fontStyle} ${u.fontVariant} ${u.fontWeight} ${u.fontSize} ${u.fontFamily}`;
      t.font = d;
      const h = Number.parseFloat(u.maxWidth), f = Number.parseFloat(u.paddingLeft) || 0, g = Number.parseFloat(u.paddingRight) || 0, m = Number.isFinite(h) ? h : this.subtitleMaxWidthPx || globalThis.innerWidth * 0.8;
      return Number.isFinite(m) && m > 0 && (this.subtitleMaxWidthPx = m), {
        fontKey: d,
        maxWidthPx: Math.max(0, m - f - g)
      };
    }
    const i = Number.parseFloat(getComputedStyle(document.documentElement).fontSize) || 16, r = Math.min(
      i * 52,
      this.subtitleMaxWidthPx || globalThis.innerWidth * 0.8
    ), a = this.fontSizeOverridden ? this.fontSize : Math.min(24, Math.max(14, globalThis.innerWidth * 0.016)), l = `normal normal 500 ${a}px ${ha(this.fontFamily)}`;
    return t.font = l, {
      fontKey: l,
      maxWidthPx: Math.max(0, r - a)
    };
  }
  getActiveLineKey(t) {
    return this.lastActiveLineIndex !== null ? `${this.lastActiveLineIndex}` : `${t[0]?.startMs ?? 0}:${t[0]?.durationMs ?? 0}:${t.length}`;
  }
  getLineMeasureMemo(t, e) {
    const { words: i, wordSlices: s, normalizedWordsKey: o } = this.buildTokenPrecomputeInput(t);
    if (!i.length) return null;
    const r = this.getMeasureContext();
    if (!r) return null;
    const { fontKey: a, maxWidthPx: l } = this.getTokenLayoutInputs(r);
    if (!Number.isFinite(l) || l < 24)
      return null;
    const u = `${e}|${a}|${Math.round(
      l
    )}|${o}`;
    if (this.lineMeasureMemo?.key === u)
      return this.lineMeasureMemo;
    const d = ey(
      s,
      (f) => r.measureText(f).width
    ), h = {
      key: u,
      words: i,
      metrics: d,
      maxWidthPx: l
    };
    return this.lineMeasureMemo = h, h;
  }
  buildTokenProcessingMemo(t, e) {
    const i = this.getLineMeasureMemo(t, e);
    if (!i) return null;
    const s = `${i.key}|${this.maxLength}`;
    if (this.tokenProcessingMemo?.key === s)
      return this.tokenProcessingMemo;
    const o = ba(i.maxWidthPx), r = my(
      t,
      i.words,
      i.metrics,
      o,
      this.maxLength
    ), a = {
      key: s,
      segmentRanges: r
    };
    return this.tokenProcessingMemo = a, this.lastSegmentIndex = 0, a;
  }
  selectSegmentIndexFromRanges(t, e) {
    if (!t.length) return -1;
    let i = this.lastSegmentIndex;
    for (i >= t.length && (i = 0); i < t.length - 1 && e >= t[i].endMs; )
      i += 1;
    for (; i > 0 && e < t[i].startMs; )
      i -= 1;
    if (!(e >= t[i].startMs && e < t[i].endMs)) {
      const s = t.findIndex(
        (o) => e >= o.startMs && e < o.endMs
      );
      s >= 0 ? i = s : i = e < t[0].startMs ? 0 : t.length - 1;
    }
    return this.lastSegmentIndex = i, i;
  }
  processTokens(t, e) {
    if (!t.length) return t;
    const i = this.getActiveLineKey(t), s = this.buildTokenProcessingMemo(t, i);
    if (!s)
      return this.selectTokensByMaxLength(t, e);
    const { segmentRanges: o } = s;
    if (!o.length)
      return this.trimEdgeWhitespaceTokens(t);
    const r = this.selectSegmentIndexFromRanges(o, e);
    if (r < 0)
      return this.trimEdgeWhitespaceTokens(t);
    const a = o[r];
    return this.trimEdgeWhitespaceTokens(
      t.slice(a.startToken, a.endToken)
    );
  }
  async translateStrTokens(t) {
    const e = this.subtitleLang ?? "", i = p.lang;
    if (this.strTranslatedTokens) {
      const l = await ys(t, e, i);
      return [
        this.strTranslatedTokens,
        typeof l == "string" ? l : ""
      ];
    }
    const s = await ys(
      [this.strTokens, t],
      e,
      i
    ), o = Array.isArray(s) ? s : [s, s], r = typeof o[0] == "string" ? o[0] : "", a = typeof o[1] == "string" ? o[1] : "";
    return this.strTranslatedTokens = r, [r, a];
  }
  isTokenSpanElement(t) {
    return t instanceof HTMLSpanElement && t.dataset.votToken === "1";
  }
  findTokenSpanInPath(t, e) {
    for (const i of t)
      if (this.isTokenSpanElement(i) && e.contains(i))
        return i;
    return null;
  }
  findTokenSpanByPoint(t, e, i) {
    const s = document.elementFromPoint(t, e);
    if (this.isTokenSpanElement(s) && i.contains(s))
      return s;
    if (!(s instanceof Element)) return null;
    const o = s.closest('span[data-vot-token="1"]');
    return o instanceof HTMLSpanElement && i.contains(o) ? o : null;
  }
  resolveTokenSpanFromClick(t) {
    const e = this.subtitlesBlock ?? this.subtitlesContainer;
    if (!e) return null;
    if (this.isTokenSpanElement(t.target) && e.contains(t.target))
      return t.target;
    const i = typeof t.composedPath == "function" ? t.composedPath() : [], s = this.findTokenSpanInPath(i, e);
    if (s)
      return s;
    const o = t.clientX, r = t.clientY;
    return Number.isFinite(o) && Number.isFinite(r) ? this.findTokenSpanByPoint(o, r, e) : null;
  }
  releaseTooltip() {
    return this.tooltipTranslationRequestId += 1, this.tokenTooltip?.target && this.tokenTooltip.target.classList.remove("selected"), this.tokenTooltip?.release(), this.tokenTooltip = void 0, this;
  }
  clearPendingSchedulerState() {
    this.repositionPending = !1, this.updatePending = !1, this.wrapPending = !1, this.positionRefreshPending = !1;
  }
  clearRenderedContent({
    releaseTooltip: t = !1
  } = {}) {
    t && this.releaseTooltip(), this.resetRenderMemo(), this.lastActiveLineIndex = null, this.strTokens = "", this.resetTranslationContext(), this.subtitlesBlock = null, this.renderedTokenEls = [], this.resetWrapMemo(), this.lastWrapTokens = null, this.subtitleMaxWidthPx = 0, this.smartAnchorWidthPx = 0, this.smartAnchorHeightPx = 0, this.smartFontSizePx = 0, this.smartMaxWidthPx = 0, this.lastAppliedLeftPct = null, this.lastAppliedTopPct = null, this.passedStateKey = null, this.passedThresholds.length = 0, this.insetCacheReady = !1, this.hideSnapGuides(), this.resetSegmentationMemo(), this.clearPendingSchedulerState(), this.subtitlesContainer && ht(null, this.subtitlesContainer);
  }
  buildPassedState(t, e, i) {
    if (this.passedStateKey !== i) {
      this.passedStateKey = i, this.passedThresholds.length = 0;
      for (const r of t) {
        if (!r.isWordLike) continue;
        const a = r.startMs + r.durationMs / 2, l = Math.max(r.startMs - 100, a - 275);
        this.passedThresholds.push(Math.min(a, l));
      }
    }
    const s = this.passedFlagsBuffer, o = this.passedThresholds;
    for (let r = 0; r < o.length; r += 1)
      s[r] = e > o[r];
    return s.length = o.length, s;
  }
  renderTokens(t) {
    const e = this.breakAfterTokenIndexSet, i = [], s = Yb(t, t.length - 1, e);
    for (const o of s) {
      if (o.kind === "word") {
        i.push(
          je`<span
            data-vot-token="1"
            data-vot-style-italic=${o.style?.italic ? "1" : "0"}
            data-vot-style-bold=${o.style?.bold ? "1" : "0"}
            data-vot-style-underline=${o.style?.underline ? "1" : "0"}
            >${o.text}</span
          >`
        );
        continue;
      }
      if (o.kind === "break") {
        i.push(je`<br class="vot-subtitles-br" />`);
        continue;
      }
      if (o.style) {
        i.push(
          je`<span
            data-vot-style-italic=${o.style.italic ? "1" : "0"}
            data-vot-style-bold=${o.style.bold ? "1" : "0"}
            data-vot-style-underline=${o.style.underline ? "1" : "0"}
            >${o.text}</span
          >`
        );
        continue;
      }
      i.push(o.text);
    }
    return i;
  }
  updatePassedClasses(t) {
    const e = this.renderedTokenEls, i = Math.min(e.length, t.length);
    for (let s = 0; s < i; s += 1)
      e[s].classList.toggle("passed", t[s]);
    for (let s = i; s < e.length; s += 1)
      e[s].classList.remove("passed");
  }
  clearPassedClasses() {
    for (const t of this.renderedTokenEls)
      t.classList.remove("passed");
  }
  setBreakAfterTokenIndices(t) {
    this.breakAfterTokenIndices = t, this.breakAfterTokenIndexSet = t.length ? new Set(t) : null;
  }
  scheduleWrapRecompute(t = null) {
    t && (this.lastWrapTokens = t);
    const e = !this.wrapPending;
    this.wrapPending = !0, e && this.intervalIdleChecker.requestImmediateTick();
  }
  maybeRefreshPosition(t = !1) {
    if (this.abortController.signal.aborted || !this.subtitlesContainer) return;
    const e = performance.now();
    !t && e - this.lastPositionRefreshTs < this.positionRefreshIntervalMs || (this.lastPositionRefreshTs = e, this.positionRefreshPending = !0, this.intervalIdleChecker.requestImmediateTick());
  }
  getMeasureContext(t) {
    return this.measureCanvas || (this.measureCanvas = document.createElement("canvas"), this.measureCanvas.width = 1, this.measureCanvas.height = 1), this.measureCtx || (this.measureCtx = this.measureCanvas.getContext("2d", { alpha: !1 }) ?? this.measureCanvas.getContext("2d")), this.measureCtx ? (typeof t == "string" && t && (this.measureCtx.font = t), this.measureCtx) : null;
  }
  arraysEqual(t, e) {
    if (t === e) return !0;
    if (t.length !== e.length) return !1;
    for (let i = 0; i < t.length; i += 1)
      if (t[i] !== e[i]) return !1;
    return !0;
  }
  recomputeWrapNow() {
    const t = this.lastWrapTokens, e = this.subtitlesBlock;
    if (!t || !e) return;
    const i = this.getLineMeasureMemo(
      t,
      this.getActiveLineKey(t)
    );
    if (!i || i.maxWidthPx < 50) return;
    const { words: s, metrics: o, maxWidthPx: r } = i, a = ba(r);
    if (s.length <= 1) {
      (this.breakAfterTokenIndices.length || this.smartTruncateAfterTokenIndex !== null) && (this.resetWrapMemo(), this.resetRenderMemo(), this.update());
      return;
    }
    const l = i.key;
    if (l === this.lastWrapKey) return;
    this.lastWrapKey = l;
    let u = [], d = null;
    if (!(ny(o, 0, s.length - 1) <= a)) {
      const m = ac(
        o,
        a
      );
      if (m.length)
        u = m.map(
          (v) => s[v].breakAfterTokenIndex
        );
      else if (this.smartLayoutEnabled) {
        const v = ry(o, a);
        u = v.breakAfterWordIndices.map(
          (T) => s[T].breakAfterTokenIndex
        ), v.truncateAfterWordIndex !== null && (d = s[v.truncateAfterWordIndex]?.breakAfterTokenIndex ?? null);
      }
    }
    const f = !this.arraysEqual(
      u,
      this.breakAfterTokenIndices
    ), g = d !== this.smartTruncateAfterTokenIndex;
    (f || g) && (this.setBreakAfterTokenIndices(u), this.smartTruncateAfterTokenIndex = d, this.resetRenderMemo(), this.update());
  }
  setContent(t, e = void 0) {
    if (this.releaseTooltip(), this.subtitleLang = e, !t || !this.video) {
      this.clearRenderedContent(), this.subtitles = null, this.clearPendingSchedulerState(), this.video?.removeEventListener("timeupdate", this.onTimeUpdateBound), this.stopVideoFrameLoop(), this.detachDragDocumentListeners();
      return;
    }
    this.createSubtitlesContainer(), this.subtitles = t, this.lastActiveLineIndex = null, this.useVideoFrameCallbacks || this.video.addEventListener("timeupdate", this.onTimeUpdateBound, {
      signal: this.abortController.signal
    }), this.syncVideoFrameLoop(), this.updateContainerRect(), this.update(), this.intervalIdleChecker.requestImmediateTick();
  }
  setMaxLength(t) {
    typeof t == "number" && t > 0 && (this.manualMaxLength = t, this.smartLayoutEnabled || (this.maxLength = t, this.resetSegmentationMemo(), this.update(), this.scheduleReposition()));
  }
  setHighlightWords(t) {
    const e = this.highlightWords;
    this.highlightWords = !!t, e && !this.highlightWords && this.clearPassedClasses(), this.update();
  }
  setSmartLayout(t) {
    const e = t !== !1;
    e !== this.smartLayoutEnabled && (this.smartLayoutEnabled = e, this.subtitlesContainer?.style.removeProperty("--vot-subtitles-max-width"), this.lastSmartLayoutKey = null, this.resetWrapMemo(), this.resetRenderMemo(), this.resetSegmentationMemo(), this.smartLayoutEnabled || (this.maxLength = this.manualMaxLength), this.applyManualFontSizeStyle(), this.update(), this.scheduleWrapRecompute(), this.scheduleReposition());
  }
  setFontSize(t) {
    this.fontSize = t, this.fontSizeOverridden = !0, this.smartLayoutEnabled || (this.applyManualFontSizeStyle(), this.lastWrapKey = null, this.resetSegmentationMemo(), this.scheduleWrapRecompute(), this.scheduleReposition());
  }
  setFontFamily(t) {
    this.fontFamily = t, this.applyFontFamilyStyle(), this.lastWrapKey = null, this.resetSegmentationMemo(), this.scheduleWrapRecompute(), this.scheduleReposition();
  }
  setOpacity(t) {
    const e = Number(t), i = Number.isFinite(e) ? Ft(e, 0, 100) : 0;
    this.opacity = ((100 - i) / 100).toFixed(2), this.applyOpacityStyle();
  }
  stringifyTokens(t) {
    let e = "";
    for (const i of t)
      e += i.text;
    return e;
  }
  update() {
    if (!this.video || !this.subtitles) return;
    const t = this.video.currentTime * 1e3, e = this.subtitles.subtitles;
    let i, s = -1;
    const o = this.lastActiveLineIndex;
    if (typeof o == "number" && o >= 0 && o < e.length) {
      const T = e[o];
      qb(t, T) && (i = T, s = o);
    }
    if (!i) {
      const T = Gb(t, e);
      T !== -1 && (i = e[T], s = T);
    }
    if (!i) {
      this.lastActiveLineIndex = null, this.subtitlesBlock || this.lastRenderKey !== null || this.strTokens ? this.clearRenderedContent({ releaseTooltip: !0 }) : this.releaseTooltip();
      return;
    }
    if (this.lastActiveLineIndex = s, this.smartLayoutEnabled) {
      const T = performance.now();
      if (this.lastSmartLayoutKey === null || T - this.lastSmartLayoutCheckTs > 500) {
        this.lastSmartLayoutCheckTs = T;
        const S = this.getLayoutSize();
        if (S.w && S.h) {
          const w = this.computeAnchorBoxLayout(S);
          w.w && w.h && this.ensureSmartLayout(w);
        }
      }
    } else
      this.maxLength = this.manualMaxLength;
    const r = this.processTokens(i.tokens, t);
    this.lastWrapTokens = r;
    const a = this.smartLayoutEnabled && typeof this.smartTruncateAfterTokenIndex == "number" && this.smartTruncateAfterTokenIndex >= 0 && this.smartTruncateAfterTokenIndex < r.length - 1, l = this.stringifyTokens(r), u = l !== this.strTokens;
    u && (this.releaseTooltip(), this.strTokens = l, this.resetTranslationContext(), this.resetWrapMemo());
    const d = `${s}:${l}`, h = this.highlightWords ? this.buildPassedState(r, t, d) : null, f = `${this.breakAfterTokenIndices.join(",")}|${this.smartTruncateAfterTokenIndex ?? ""}`, g = `${s}:${l}:${f}`;
    if (g === this.lastRenderKey) {
      this.highlightWords && !u && h && this.updatePassedClasses(h), this.maybeRefreshPosition();
      return;
    }
    this.lastRenderKey = g, this.subtitlesContainer = this.subtitlesContainer ?? this.createSubtitlesContainer(), ht(
      je`<vot-block
        class="${a ? "vot-subtitles vot-subtitles--clamped" : "vot-subtitles"}"
        @click=${this.onClick}
      >
        ${this.renderTokens(r)}
      </vot-block>`,
      this.subtitlesContainer
    );
    const v = this.subtitlesContainer.firstElementChild;
    this.subtitlesBlock = v instanceof HTMLElement && v.classList.contains("vot-subtitles") ? v : null, this.renderedTokenEls = this.subtitlesBlock ? Array.from(
      this.subtitlesBlock.querySelectorAll(
        'span[data-vot-token="1"]'
      )
    ) : [], this.highlightWords && h && this.updatePassedClasses(h), u ? (this.applyPositionAfterContentRender(), this.scheduleWrapRecompute(r), this.scheduleReposition()) : this.maybeRefreshPosition();
  }
  release() {
    this.detachDragDocumentListeners(), this.stopVideoFrameLoop(), this.abortController.abort(), this.resizeObserver?.disconnect(), this.clearPendingSchedulerState(), this.checkerUnsubscribe?.(), this.checkerUnsubscribe = null, this.releaseTooltip(), this.subtitlesContainer && (this.subtitlesContainer.remove(), this.subtitlesContainer = null), this.fullscreenLayerController.release(), this.safeAreaProbeEl && (this.safeAreaProbeEl.remove(), this.safeAreaProbeEl = null), this.guidesLayer && (this.guidesLayer.remove(), this.guidesLayer = null, this.verticalGuide = null, this.horizontalGuide = null), this.measureCtx = null, this.measureCanvas = null, this.lastAppliedLeftPct = null, this.lastAppliedTopPct = null, this.passedStateKey = null, this.passedThresholds.length = 0, this.insetCacheReady = !1;
  }
}
const wy = /^<\s*(\/?)\s*([a-z0-9]+)(?:[.\s][^>]*)?>/iu, Sy = /^\{([^}]*)\}/u, Ty = /^(\s*)>>\s*/u, ky = (n) => {
  const t = {};
  return n.italic && (t.italic = !0), n.bold && (t.bold = !0), n.underline && (t.underline = !0), Object.keys(t).length > 0 ? t : void 0;
}, Ly = (n, t) => !!n?.italic == !!t?.italic && !!n?.bold == !!t?.bold && !!n?.underline == !!t?.underline, Ge = (n, t, e) => {
  if (!t) return;
  const i = ky(e), s = n.at(-1);
  if (s && Ly(s.style, i)) {
    s.text += t;
    return;
  }
  n.push({
    text: t,
    style: i
  });
}, xy = (n, t) => {
  const e = /^\\([ibu])([01])$/u.exec(n.trim());
  if (!e) return;
  const i = e[2] === "1";
  if (e[1] === "i") {
    t.italic = i;
    return;
  }
  if (e[1] === "b") {
    t.bold = i;
    return;
  }
  e[1] === "u" && (t.underline = i);
}, Ay = (n) => {
  for (const t of n) {
    if (!t.text) continue;
    const e = t.text.replace(Ty, "$1");
    if (t.text = e, e.length > 0)
      break;
  }
  for (; n[0]?.text === ""; )
    n.shift();
}, wn = (n) => {
  const t = [], e = {
    italic: !1,
    bold: !1,
    underline: !1
  };
  let i = 0;
  for (; i < n.length; ) {
    const f = n.slice(i);
    if (f.startsWith("\\N") || f.startsWith("\\n")) {
      Ge(t, `
`, e), i += 2;
      continue;
    }
    if (f.startsWith("\\h")) {
      Ge(t, " ", e), i += 2;
      continue;
    }
    if (f[0] === `
`) {
      Ge(t, `
`, e), i += 1;
      continue;
    }
    const g = Sy.exec(f);
    if (g) {
      const v = g[1].match(/\\[ibu][01]/gu) ?? [];
      for (const T of v)
        xy(T, e);
      i += g[0].length;
      continue;
    }
    const m = wy.exec(f);
    if (m) {
      const v = m[1] === "/", T = m[2].toLowerCase();
      T === "br" ? Ge(t, `
`, e) : T === "i" ? e.italic = !v : T === "b" ? e.bold = !v : T === "u" && (e.underline = !v), i += m[0].length;
      continue;
    }
    Ge(t, f[0], e), i += 1;
  }
  Ay(t);
  const s = [];
  let o = "";
  for (const f of t) {
    if (!f.text) continue;
    const g = o.length;
    o += f.text;
    const m = o.length;
    s.push({
      start: g,
      end: m,
      style: f.style
    });
  }
  const r = o.replaceAll(" ", " "), a = /^\s*/u.exec(r)?.[0].length ?? 0, l = /\s*$/u.exec(r)?.[0].length ?? 0, u = Math.max(
    a,
    r.length - l
  ), d = r.slice(a, u), h = s.map((f) => ({
    start: Math.max(0, f.start - a),
    end: Math.max(0, f.end - a),
    style: f.style
  })).filter((f) => f.end > f.start && f.start < d.length).map((f) => ({
    ...f,
    end: Math.min(f.end, d.length)
  }));
  return {
    text: d,
    styledSpans: h
  };
}, ya = (n, t, e) => !n?.length || e <= t ? void 0 : n.find(
  (s) => t < s.end && e > s.start && s.style
)?.style, Ey = "\uFEFF", Vy = /\{[^}]*\}/gu, Rn = /^\s*(?<start>\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})\s*-->\s*(?<end>\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})\s*$/u, Yi = /^(?<start>(?:\d{2}:)?\d{2}:\d{2}\.\d{3})\s+-->\s+(?<end>(?:\d{2}:)?\d{2}:\d{2}\.\d{3})(?<settings>(?:[ \t]+.+)?)$/u, so = (n) => n.replace(Ey, "").replaceAll(/\r\n?/gu, `
`), Cy = (n) => n.length >= 3 ? n.slice(0, 3) : n.padEnd(3, "0"), si = (n, t) => {
  const e = n.trim().split(":");
  if (e.length < 2 || e.length > 3)
    return null;
  const i = e.length === 2 ? ["00", ...e] : e, [s, o, r] = i, [a, l = "0"] = r.split(/[.,]/u);
  if (!/^\d+$/u.test(s) || !/^\d{2}$/u.test(o) || !/^\d{2}$/u.test(a) || !/^\d+$/u.test(l))
    return null;
  const u = Number(s), d = Number(o), h = Number(a), f = Number(
    Cy(l).slice(0, t)
  );
  return !Number.isFinite(u) || !Number.isFinite(d) || !Number.isFinite(h) || d > 59 || h > 59 ? null : ((u * 60 + d) * 60 + h) * 1e3 + f;
}, oi = (n, {
  delimiter: t,
  allowOptionalHours: e,
  fractionDigits: i
}) => {
  const s = Math.max(0, Math.round(n)), o = Math.floor(s / 36e5), r = Math.floor(s % 36e5 / 6e4), a = Math.floor(s % 6e4 / 1e3), u = (s % 1e3).toString().padStart(3, "0").slice(0, i);
  return `${e && o === 0 ? "" : `${o.toString().padStart(2, "0")}:`}${r.toString().padStart(2, "0")}:${a.toString().padStart(2, "0")}${t}${u}`;
}, va = (n) => {
  const t = Math.max(0, Math.round(n)), e = Math.floor(t / 36e5), i = Math.floor(t % 36e5 / 6e4), s = Math.floor(t % 6e4 / 1e3), o = Math.floor(t % 1e3 / 10);
  return `${e}:${i.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}.${o.toString().padStart(2, "0")}`;
}, wa = (n) => {
  const t = /^(?<hours>\d+):(?<minutes>\d{2}):(?<seconds>\d{2})\.(?<centiseconds>\d{2})$/u.exec(
    n.trim()
  );
  if (!t?.groups) return null;
  const e = Number(t.groups.hours), i = Number(t.groups.minutes), s = Number(t.groups.seconds), o = Number(t.groups.centiseconds);
  return i > 59 || s > 59 || !Number.isFinite(e) || !Number.isFinite(o) ? null : ((e * 60 + i) * 60 + s) * 1e3 + o * 10;
}, Ve = (n) => wn(n).text, wi = (n) => n.sort((t, e) => {
  const i = t.line.startMs - e.line.startMs;
  if (i !== 0) return i;
  const s = t.line.startMs + Math.max(0, t.line.durationMs) - (e.line.startMs + Math.max(0, e.line.durationMs));
  return s !== 0 ? s : t.index - e.index;
}).map(({ line: t }) => t), Iy = (n) => {
  let t = 0, e = n.length;
  for (; t < e && n[t] === ""; )
    t += 1;
  for (; e > t && n[e - 1] === ""; )
    e -= 1;
  return n.slice(t, e);
}, Py = (n) => {
  const t = n.trim();
  if (!t) return;
  const e = {};
  for (const i of t.split(/\s+/u)) {
    const s = i.indexOf(":");
    s <= 0 || (e[i.slice(0, s)] = i.slice(s + 1));
  }
  return {
    raw: t,
    values: e
  };
}, My = (n) => {
  const e = (/^\s*<v(?:\.[^ >]+)?(?:\s+([^>]*?))?>/iu.exec(n) ?? /^\s*<v\s+([^>]*?)>/iu.exec(n))?.[1]?.trim();
  return e || void 0;
}, Oy = (n) => Ve(n), Dy = (n) => Ve(n), _y = (n) => Ve(n), Ry = (n) => {
  const e = so(n).split(`
`), i = [], s = (a) => {
    const l = e[a]?.trim() ?? "", u = e[a + 1]?.trim() ?? "";
    return Rn.test(l) || /^\d+$/u.test(l) && Rn.test(u);
  };
  let o = 0, r = 0;
  for (; o < e.length; ) {
    for (; o < e.length && e[o].trim() === ""; )
      o += 1;
    if (o >= e.length) break;
    let a = o;
    /^\d+$/u.test(e[o].trim()) && Rn.test(e[o + 1]?.trim() ?? "") && (a = o + 1);
    const l = Rn.exec(
      e[a]?.trim() ?? ""
    );
    if (!l?.groups) {
      o += 1;
      continue;
    }
    const u = si(l.groups.start, 3), d = si(l.groups.end, 3);
    if (u == null || d == null || d < u) {
      o = a + 1;
      continue;
    }
    o = a + 1;
    const h = [];
    for (; o < e.length; ) {
      if (e[o].trim() === "") {
        const m = o + 1;
        if (s(m))
          break;
        o += 1;
        continue;
      }
      if (h.length > 0 && s(o))
        break;
      h.push(e[o]), o += 1;
    }
    const f = Iy(h).join(`
`), g = wn(f);
    i.push({
      index: r,
      line: {
        text: Oy(f),
        startMs: u,
        durationMs: Math.max(0, d - u),
        speakerId: "0",
        tokens: [],
        metadata: {
          rawText: f,
          styledSpans: g.styledSpans
        }
      }
    }), r += 1;
  }
  return {
    format: "srt",
    subtitles: wi(i)
  };
}, lc = (n, t, e) => n.format === e ? t.metadata?.rawText ?? t.text : e === "ass" ? t.text.replaceAll(`
`, "\\N") : t.text, By = (n) => n.subtitles.map((t, e) => {
  const i = lc(n, t, "srt"), s = t.startMs + Math.max(0, t.durationMs);
  return [
    String(e + 1),
    `${oi(t.startMs, {
      delimiter: ",",
      allowOptionalHours: !1,
      fractionDigits: 3
    })} --> ${oi(s, {
      delimiter: ",",
      allowOptionalHours: !1,
      fractionDigits: 3
    })}`,
    i
  ].join(`
`);
}).join(`

`), Fy = (n, t, e) => {
  n.push({
    cueIndex: t,
    lines: e
  });
}, Ny = (n) => {
  const e = so(n).split(`
`), i = e[0] ?? "";
  if (!i.startsWith("WEBVTT"))
    return {
      format: "vtt",
      subtitles: [],
      metadata: {
        vtt: {
          headerText: "",
          blocks: []
        }
      }
    };
  const s = {
    headerText: i.slice(6).trim(),
    blocks: []
  }, o = [];
  let r = 1;
  for (; r < e.length; ) {
    for (; r < e.length && e[r].trim() === ""; )
      r += 1;
    if (r >= e.length) break;
    if (e[r].startsWith("NOTE") || e[r] === "STYLE" || e[r] === "REGION") {
      const v = [];
      for (; r < e.length && e[r].trim() !== ""; )
        v.push(e[r]), r += 1;
      Fy(s.blocks, o.length, v);
      continue;
    }
    let a;
    !Yi.test(e[r] ?? "") && Yi.test(e[r + 1] ?? "") && (a = e[r], r += 1);
    const l = Yi.exec(e[r] ?? "");
    if (!l?.groups) {
      r += 1;
      continue;
    }
    const u = si(l.groups.start, 3), d = si(l.groups.end, 3);
    if (u == null || d == null || d < u) {
      r += 1;
      continue;
    }
    r += 1;
    const h = [];
    for (; r < e.length && e[r].trim() !== ""; )
      h.push(e[r]), r += 1;
    const f = h.join(`
`), g = wn(f), m = My(f);
    o.push({
      index: o.length,
      line: {
        text: Dy(f),
        startMs: u,
        durationMs: Math.max(0, d - u),
        speakerId: m ?? "0",
        tokens: [],
        metadata: {
          rawText: f,
          styledSpans: g.styledSpans,
          vtt: {
            cueId: a,
            settings: Py(l.groups.settings ?? ""),
            voice: m,
            rawPayload: h
          }
        }
      }
    });
  }
  return {
    format: "vtt",
    subtitles: wi(o),
    metadata: {
      vtt: s
    }
  };
}, Uy = (n) => {
  const t = n.startMs + Math.max(0, n.durationMs), e = n.metadata?.vtt?.settings?.raw;
  return `${oi(n.startMs, {
    delimiter: ".",
    allowOptionalHours: !0,
    fractionDigits: 3
  })} --> ${oi(t, {
    delimiter: ".",
    allowOptionalHours: !0,
    fractionDigits: 3
  })}${e ? ` ${e}` : ""}`;
}, Hy = (n) => {
  const t = n.metadata?.vtt, e = [
    `WEBVTT${t?.headerText ? ` ${t.headerText}` : ""}`
  ], i = /* @__PURE__ */ new Map();
  for (const o of t?.blocks ?? []) {
    const r = i.get(o.cueIndex) ?? [];
    r.push(o.lines), i.set(o.cueIndex, r);
  }
  const s = (o) => {
    for (const r of i.get(o) ?? [])
      e.push(r.join(`
`));
  };
  return s(0), n.subtitles.forEach((o, r) => {
    const a = o.metadata?.vtt?.cueId, l = [
      ...a ? [a] : [],
      Uy(o),
      (n.format === "vtt" ? o.metadata?.vtt?.rawPayload : o.text.split(`
`))?.join(`
`) ?? o.text
    ];
    e.push(l.join(`
`)), s(r + 1);
  }), e.filter(Boolean).join(`

`);
}, $y = (n, t) => {
  if (t <= 1)
    return [n];
  const e = [];
  let i = 0;
  for (let s = 0; s < t - 1; s += 1) {
    const o = n.indexOf(",", i);
    if (o < 0) {
      e.push(n.slice(i).trim()), i = n.length;
      break;
    }
    e.push(n.slice(i, o).trim()), i = o + 1;
  }
  return e.push(n.slice(i).trim()), e;
}, Wy = () => ({
  scriptInfoLines: [],
  styleFormat: "",
  styleLines: [],
  eventFormat: "",
  preEventLines: [],
  commentLines: []
}), zy = (n = "Exported subtitles") => ({
  scriptInfoLines: [
    `Title: ${n}`,
    "ScriptType: v4.00+",
    "WrapStyle: 0",
    "ScaledBorderAndShadow: yes"
  ],
  styleFormat: "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
  styleLines: [
    "Style: Default,Arial,42,&H00FFFFFF,&H000000FF,&H00000000,&H64000000,0,0,0,0,100,100,0,0,1,2,0,2,20,20,20,1"
  ],
  eventFormat: "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
  preEventLines: [],
  commentLines: []
}), qy = (n) => {
  const e = so(n).split(`
`), i = Wy(), s = [];
  let o = "", r = [];
  return e.forEach((a, l) => {
    const u = a.trim();
    if (!u) return;
    const d = /^\[(.+)\]$/u.exec(u);
    if (d) {
      o = d[1];
      return;
    }
    if (o === "Script Info") {
      i.scriptInfoLines.push(a);
      return;
    }
    if (o === "V4+ Styles" || o === "V4 Styles") {
      if (a.startsWith("Format:")) {
        i.styleFormat = a;
        return;
      }
      if (a.startsWith("Style:")) {
        i.styleLines.push(a);
        return;
      }
      i.preEventLines.push(a);
      return;
    }
    if (o === "Events") {
      if (a.startsWith("Format:")) {
        i.eventFormat = a, r = a.slice(7).split(",").map((k) => k.trim());
        return;
      }
      if (!a.includes(":")) {
        i.preEventLines.push(a);
        return;
      }
      const h = a.indexOf(":"), f = a.slice(0, h).trim(), g = a.slice(h + 1).trim();
      !r.length && i.eventFormat && (r = i.eventFormat.slice(7).split(",").map((k) => k.trim()));
      const m = $y(g, r.length), v = Object.fromEntries(
        r.map((k, A) => [
          k,
          m[A] ?? ""
        ])
      );
      if (f === "Comment") {
        i.commentLines.push(a);
        return;
      }
      if (f !== "Dialogue") {
        i.preEventLines.push(a);
        return;
      }
      const T = wa(v.Start ?? ""), S = wa(v.End ?? "");
      if (T == null || S == null || S < T)
        return;
      const w = v.Text ?? "", x = wn(w), I = {
        kind: "dialogue",
        layer: v.Layer ?? "0",
        style: v.Style ?? "Default",
        name: v.Name ?? "",
        marginL: v.MarginL ?? "0",
        marginR: v.MarginR ?? "0",
        marginV: v.MarginV ?? "0",
        effect: v.Effect ?? "",
        rawText: w,
        overrideTags: w.match(Vy) ?? []
      };
      s.push({
        index: l,
        line: {
          text: _y(w),
          startMs: T,
          durationMs: Math.max(0, S - T),
          speakerId: I.name || "0",
          tokens: [],
          metadata: {
            rawText: w,
            styledSpans: x.styledSpans,
            ass: I
          }
        }
      });
    }
  }), {
    format: "ass",
    subtitles: wi(s),
    metadata: {
      ass: i
    }
  };
}, Gy = (n) => {
  const t = n.metadata?.ass, e = n.startMs + Math.max(0, n.durationMs), i = t?.rawText ?? n.metadata?.rawText ?? n.text.replaceAll(`
`, "\\N");
  return [
    t?.kind === "comment" ? "Comment" : "Dialogue",
    ": ",
    [
      t?.layer ?? "0",
      va(n.startMs),
      va(e),
      t?.style ?? "Default",
      t?.name ?? "",
      t?.marginL ?? "0",
      t?.marginR ?? "0",
      t?.marginV ?? "0",
      t?.effect ?? "",
      i
    ].join(",")
  ].join("");
}, Ky = (n, t) => {
  if (!t)
    return n;
  const e = `Title: ${t}`, i = [...n.scriptInfoLines], s = i.findIndex(
    (o) => o.startsWith("Title:")
  );
  return s >= 0 ? i[s] === "Title: Exported subtitles" && (i[s] = e) : i.unshift(e), {
    ...n,
    scriptInfoLines: i
  };
}, Yy = (n, t) => {
  const e = n.metadata?.ass, i = e && e.scriptInfoLines.length > 0 && e.styleFormat && e.styleLines.length > 0 && e.eventFormat ? e : zy(t?.assTitle), s = Ky(i, t?.assTitle);
  return [
    "[Script Info]",
    ...s.scriptInfoLines,
    "",
    "[V4+ Styles]",
    s.styleFormat,
    ...s.styleLines,
    ...s.preEventLines,
    "",
    "[Events]",
    s.eventFormat,
    ...s.commentLines,
    ...n.subtitles.map(
      (r) => Gy({
        ...r,
        metadata: n.format === "ass" ? r.metadata : {
          ...r.metadata,
          rawText: lc(n, r, "ass")
        }
      })
    )
  ].join(`
`).trim();
}, jy = (n, t) => t === "srt" ? Ry(n) : t === "vtt" ? Ny(n) : qy(n), Sa = (n) => ({
  ...n,
  subtitles: wi(
    n.subtitles.map((t, e) => ({
      index: e,
      line: t
    }))
  )
}), Xy = (n) => {
  const t = n.subtitles.map((e) => ({
    text: e.text,
    startMs: e.startMs,
    durationMs: e.durationMs,
    speakerId: e.speakerId,
    tokens: e.tokens.map((i) => ({
      text: i.text,
      startMs: i.startMs,
      durationMs: i.durationMs
    }))
  }));
  return {
    containsTokens: t.some((e) => e.tokens.length > 0),
    subtitles: t
  };
}, Jy = (n, t, e) => t === "json" ? Xy(n) : t === "srt" ? By(n) : t === "vtt" ? Hy(n) : Yy(n, e);
function Zy(n) {
  return new Uint8Array([
    n >>> 24 & 255,
    n >>> 16 & 255,
    n >>> 8 & 255,
    n & 255
  ]);
}
function Qy(n) {
  return new Uint8Array([
    n >>> 21 & 127,
    n >>> 14 & 127,
    n >>> 7 & 127,
    n & 127
  ]);
}
function tv(n, t) {
  const e = new TextEncoder().encode(t), i = new Uint8Array(e.length + 1);
  i[0] = 3, i.set(e, 1);
  const s = new Uint8Array(10 + i.length);
  s.set([84, 73, 84, 50], 0), s.set(Zy(i.length), 4), s.set(i, 10);
  const o = new Uint8Array(10);
  o.set([73, 68, 51, 3, 0, 0], 0), o.set(Qy(s.length), 6);
  const r = new Uint8Array(n), a = new Uint8Array(o.length + s.length + r.length);
  return a.set(o, 0), a.set(s, o.length), a.set(r, o.length + s.length), new Blob([a], { type: "audio/mpeg" });
}
async function ev(n, t) {
  const e = Number(n.headers.get("Content-Length") ?? 0);
  if (!n.body) return n.arrayBuffer();
  const i = n.body.getReader();
  let s = 0, o = e > 0 ? new Uint8Array(e) : null;
  const r = [];
  for (; ; ) {
    const { done: u, value: d } = await i.read();
    if (u) break;
    if (!(!d || d.byteLength === 0)) {
      if (o) {
        const h = s + d.byteLength;
        if (h > o.length) {
          const f = new Uint8Array(Math.max(h, o.length * 2));
          f.set(o.subarray(0, s)), o = f;
        }
        o.set(d, s), s = h;
      } else
        r.push(d), s += d.byteLength;
      e > 0 && t(W(Math.round(s / e * 100)));
    }
  }
  if (o)
    return o.buffer.slice(0, s);
  const a = new Uint8Array(s);
  let l = 0;
  for (const u of r)
    a.set(u, l), l += u.byteLength;
  return a.buffer;
}
async function nv(n, t, e = () => {
}, i = {}) {
  const s = await iv(n, t, e);
  return await Il(s, `${t}.mp3`, i);
}
async function iv(n, t, e = () => {
}) {
  const i = await ev(n, e);
  return e(100), tv(i, t);
}
function cc(n, t) {
  return n.root === t.root && n.portalContainer === t.portalContainer && n.subtitlesMountContainer === t.subtitlesMountContainer && n.tooltipLayoutRoot === t.tooltipLayoutRoot;
}
function sv(n, t, e) {
  return cc(n, t) ? n : (e(t), t);
}
function ov(n, t) {
  return n.root !== t.root || n.tooltipLayoutRoot !== t.tooltipLayoutRoot;
}
const rv = gt`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <path
    id="vot-translate-icon"
    fill-rule="evenodd"
    d="M15.778 18.95L14.903 21.375C14.8364 21.5583 14.7197 21.7083 14.553 21.825C14.3864 21.9417 14.203 22 14.003 22C13.6697 22 13.3989 21.8625 13.1905 21.5875C12.9822 21.3125 12.9447 21.0083 13.078 20.675L16.878 10.625C16.9614 10.4417 17.0864 10.2917 17.253 10.175C17.4197 10.0583 17.603 10 17.803 10H18.553C18.753 10 18.9364 10.0583 19.103 10.175C19.2697 10.2917 19.3947 10.4417 19.478 10.625L23.278 20.7C23.4114 21.0167 23.378 21.3125 23.178 21.5875C22.978 21.8625 22.7114 22 22.378 22C22.1614 22 21.9739 21.9375 21.8155 21.8125C21.6572 21.6875 21.5364 21.525 21.453 21.325L20.628 18.95H15.778ZM19.978 17.2H16.378L18.228 12.25L19.978 17.2Z"
  ></path>
  <path
    d="M9 14L4.7 18.3C4.51667 18.4833 4.28333 18.575 4 18.575C3.71667 18.575 3.48333 18.4833 3.3 18.3C3.11667 18.1167 3.025 17.8833 3.025 17.6C3.025 17.3167 3.11667 17.0833 3.3 16.9L7.65 12.55C7.01667 11.85 6.4625 11.125 5.9875 10.375C5.5125 9.625 5.1 8.83333 4.75 8H6.85C7.15 8.6 7.47083 9.14167 7.8125 9.625C8.15417 10.1083 8.56667 10.6167 9.05 11.15C9.78333 10.35 10.3917 9.52917 10.875 8.6875C11.3583 7.84583 11.7667 6.95 12.1 6H2C1.71667 6 1.47917 5.90417 1.2875 5.7125C1.09583 5.52083 1 5.28333 1 5C1 4.71667 1.09583 4.47917 1.2875 4.2875C1.47917 4.09583 1.71667 4 2 4H8V3C8 2.71667 8.09583 2.47917 8.2875 2.2875C8.47917 2.09583 8.71667 2 9 2C9.28333 2 9.52083 2.09583 9.7125 2.2875C9.90417 2.47917 10 2.71667 10 3V4H16C16.2833 4 16.5208 4.09583 16.7125 4.2875C16.9042 4.47917 17 4.71667 17 5C17 5.28333 16.9042 5.52083 16.7125 5.7125C16.5208 5.90417 16.2833 6 16 6H14.1C13.75 7.18333 13.275 8.33333 12.675 9.45C12.075 10.5667 11.3333 11.6167 10.45 12.6L12.85 15.05L12.1 17.1L9 14Z"
  ></path>
  <path
    id="vot-loading-icon"
    style="display:none"
    d="M19.8081 16.3697L18.5842 15.6633V13.0832C18.5842 12.9285 18.5228 12.7801 18.4134 12.6707C18.304 12.5613 18.1556 12.4998 18.0009 12.4998C17.8462 12.4998 17.6978 12.5613 17.5884 12.6707C17.479 12.7801 17.4176 12.9285 17.4176 13.0832V15.9998C17.4176 16.1022 17.4445 16.2028 17.4957 16.2915C17.5469 16.3802 17.6205 16.4538 17.7092 16.505L19.2247 17.38C19.2911 17.4189 19.3645 17.4443 19.4407 17.4547C19.5169 17.4652 19.5945 17.4604 19.6688 17.4407C19.7432 17.4211 19.813 17.3869 19.8741 17.3402C19.9352 17.2934 19.9864 17.2351 20.0249 17.1684C20.0634 17.1018 20.0883 17.0282 20.0982 16.952C20.1081 16.8757 20.1028 16.7982 20.0827 16.7239C20.0625 16.6497 20.0279 16.5802 19.9808 16.5194C19.9336 16.4586 19.8749 16.4077 19.8081 16.3697ZM18.0015 10C16.8478 10 15.6603 10.359 14.7011 11C13.7418 11.641 12.9415 12.4341 12.5 13.5C12.0585 14.5659 11.8852 16.0369 12.1103 17.1684C12.3353 18.3 12.8736 19.4942 13.6894 20.31C14.5053 21.1258 15.8684 21.7749 17 22C18.1316 22.2251 19.4341 21.9415 20.5 21.5C21.5659 21.0585 22.359 20.2573 23 19.298C23.641 18.3387 24.0015 17.1537 24.0015 16C23.9998 14.4534 23.5951 13.0936 22.5015 12C21.4079 10.9064 19.5481 10.0017 18.0015 10ZM18.0009 20.6665C17.0779 20.6665 16.1757 20.3928 15.4082 19.88C14.6408 19.3672 14.0427 18.6384 13.6894 17.7857C13.3362 16.933 13.2438 15.9947 13.4239 15.0894C13.604 14.1842 14.0484 13.3527 14.7011 12.7C15.3537 12.0474 16.1852 11.6029 17.0905 11.4228C17.9957 11.2428 18.934 11.3352 19.7867 11.6884C20.6395 12.0416 21.3683 12.6397 21.8811 13.4072C22.3939 14.1746 22.6676 15.0769 22.6676 15.9998C22.666 17.237 22.1738 18.4231 21.299 19.298C20.4242 20.1728 19.2381 20.665 18.0009 20.6665Z"
  ></path>
</svg>`, av = gt`<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24">
  <path
    d="M120-520q-17 0-28.5-11.5T80-560q0-17 11.5-28.5T120-600h104L80-743q-12-12-12-28.5T80-800q12-12 28.5-12t28.5 12l143 144v-104q0-17 11.5-28.5T320-800q17 0 28.5 11.5T360-760v200q0 17-11.5 28.5T320-520H120Zm40 360q-33 0-56.5-23.5T80-240v-160q0-17 11.5-28.5T120-440q17 0 28.5 11.5T160-400v160h280q17 0 28.5 11.5T480-200q0 17-11.5 28.5T440-160H160Zm680-280q-17 0-28.5-11.5T800-480v-240H480q-17 0-28.5-11.5T440-760q0-17 11.5-28.5T480-800h320q33 0 56.5 23.5T880-720v240q0 17-11.5 28.5T840-440ZM600-160q-17 0-28.5-11.5T560-200v-120q0-17 11.5-28.5T600-360h240q17 0 28.5 11.5T880-320v120q0 17-11.5 28.5T840-160H600Z"
  />
</svg>`, lv = gt`<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24">
  <path
    d="M480-160q-33 0-56.5-23.5T400-240q0-33 23.5-56.5T480-320q33 0 56.5 23.5T560-240q0 33-23.5 56.5T480-160Zm0-240q-33 0-56.5-23.5T400-480q0-33 23.5-56.5T480-560q33 0 56.5 23.5T560-480q0 33-23.5 56.5T480-400Zm0-240q-33 0-56.5-23.5T400-720q0-33 23.5-56.5T480-800q33 0 56.5 23.5T560-720q0 33-23.5 56.5T480-640Z"
  />
</svg>`, cv = gt`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="100%" viewBox="0 0 24 24" class="vot-loader" id="vot-loader-download">
  <path class="vot-loader-main" d="M12 15.575C11.8667 15.575 11.7417 15.5542 11.625 15.5125C11.5083 15.4708 11.4 15.4 11.3 15.3L7.7 11.7C7.5 11.5 7.40417 11.2667 7.4125 11C7.42083 10.7333 7.51667 10.5 7.7 10.3C7.9 10.1 8.1375 9.99583 8.4125 9.9875C8.6875 9.97917 8.925 10.075 9.125 10.275L11 12.15V5C11 4.71667 11.0958 4.47917 11.2875 4.2875C11.4792 4.09583 11.7167 4 12 4C12.2833 4 12.5208 4.09583 12.7125 4.2875C12.9042 4.47917 13 4.71667 13 5V12.15L14.875 10.275C15.075 10.075 15.3125 9.97917 15.5875 9.9875C15.8625 9.99583 16.1 10.1 16.3 10.3C16.4833 10.5 16.5792 10.7333 16.5875 11C16.5958 11.2667 16.5 11.5 16.3 11.7L12.7 15.3C12.6 15.4 12.4917 15.4708 12.375 15.5125C12.2583 15.5542 12.1333 15.575 12 15.575ZM6 20C5.45 20 4.97917 19.8042 4.5875 19.4125C4.19583 19.0208 4 18.55 4 18V16C4 15.7167 4.09583 15.4792 4.2875 15.2875C4.47917 15.0958 4.71667 15 5 15C5.28333 15 5.52083 15.0958 5.7125 15.2875C5.90417 15.4792 6 15.7167 6 16V18H18V16C18 15.7167 18.0958 15.4792 18.2875 15.2875C18.4792 15.0958 18.7167 15 19 15C19.2833 15 19.5208 15.0958 19.7125 15.2875C19.9042 15.4792 20 15.7167 20 16V18C20 18.55 19.8042 19.0208 19.4125 19.4125C19.0208 19.8042 18.55 20 18 20H6Z"/>
  <circle class="vot-loader-progress" cx="12" cy="12" r="9"></circle>
</svg>`, uv = gt`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="100%" viewBox="0 0 24 24">
  <path d="M4 20q-.825 0-1.413-.588T2 18V6q0-.825.588-1.413T4 4h16q.825 0 1.413.588T22 6v12q0 .825-.588 1.413T20 20H4Zm2-4h8v-2H6v2Zm10 0h2v-2h-2v2ZM6 12h2v-2H6v2Zm4 0h8v-2h-8v2Z"/>
</svg>`, dv = gt`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="100%" viewBox="0 -960 960 960">
  <path d="M555-80H405q-15 0-26-10t-13-25l-12-93q-13-5-24.5-12T307-235l-87 36q-14 5-28 1t-22-17L96-344q-8-13-5-28t15-24l75-57q-1-7-1-13.5v-27q0-6.5 1-13.5l-75-57q-12-9-15-24t5-28l74-129q7-14 21.5-17.5T220-761l87 36q11-8 23-15t24-12l12-93q2-15 13-25t26-10h150q15 0 26 10t13 25l12 93q13 5 24.5 12t22.5 15l87-36q14-5 28-1t22 17l74 129q8 13 5 28t-15 24l-75 57q1 7 1 13.5v27q0 6.5-2 13.5l75 57q12 9 15 24t-5 28l-74 128q-8 13-22.5 17.5T738-199l-85-36q-11 8-23 15t-24 12l-12 93q-2 15-13 25t-26 10Zm-73-260q58 0 99-41t41-99q0-58-41-99t-99-41q-59 0-99.5 41T342-480q0 58 40.5 99t99.5 41Zm0-80q-25 0-42.5-17.5T422-480q0-25 17.5-42.5T482-540q25 0 42.5 17.5T542-480q0 25-17.5 42.5T482-420Zm-2-60Zm-40 320h79l14-106q31-8 57.5-23.5T639-327l99 41 39-68-86-65q5-14 7-29.5t2-31.5q0-16-2-31.5t-7-29.5l86-65-39-68-99 42q-22-23-48.5-38.5T533-694l-13-106h-79l-14 106q-31 8-57.5 23.5T321-633l-99-41-39 68 86 64q-5 15-7 30t-2 32q0 16 2 31t7 30l-86 65 39 68 99-42q22 23 48.5 38.5T427-266l13 106Z"/>
</svg>`, uc = gt`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" >
  <path
    d="M12 14.975q-.2 0-.375-.062T11.3 14.7l-4.6-4.6q-.275-.275-.275-.7t.275-.7q.275-.275.7-.275t.7.275l3.9 3.9l3.9-3.9q.275-.275.7-.275t.7.275q.275.275.275.7t-.275.7l-4.6 4.6q-.15.15-.325.213t-.375.062Z"
  />
</svg>`, hv = gt`<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24">
  <path
    d="M647-440H200q-17 0-28.5-11.5T160-480q0-17 11.5-28.5T200-520h447L451-716q-12-12-11.5-28t12.5-28q12-11 28-11.5t28 11.5l264 264q6 6 8.5 13t2.5 15q0 8-2.5 15t-8.5 13L508-188q-11 11-27.5 11T452-188q-12-12-12-28.5t12-28.5l195-195Z"
  />
</svg>`, fv = gt`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="100%" viewBox="0 -960 960 960">
  <path d="M480-424 284-228q-11 11-28 11t-28-11q-11-11-11-28t11-28l196-196-196-196q-11-11-11-28t11-28q11-11 28-11t28 11l196 196 196-196q11-11 28-11t28 11q11 11 11 28t-11 28L536-480l196 196q11 11 11 28t-11 28q-11 11-28 11t-28-11L480-424Z"/>
</svg>`, Ta = gt`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <g fill="none">
    <path d="m12.593 23.258l-.011.002l-.071.035l-.02.004l-.014-.004l-.071-.035q-.016-.005-.024.005l-.004.01l-.017.428l.005.02l.01.013l.104.074l.015.004l.012-.004l.104-.074l.012-.016l.004-.017l-.017-.427q-.004-.016-.017-.018m.265-.113l-.013.002l-.185.093l-.01.01l-.003.011l.018.43l.005.012l.008.007l.201.093q.019.005.029-.008l.004-.014l-.034-.614q-.005-.018-.02-.022m-.715.002a.02.02 0 0 0-.027.006l-.006.014l-.034.614q.001.018.017.024l.015-.002l.201-.093l.01-.008l.004-.011l.017-.43l-.003-.012l-.01-.01z"/><path fill="currentColor" d="M12 2c5.523 0 10 4.477 10 10s-4.477 10-10 10S2 17.523 2 12S6.477 2 12 2m0 2a8 8 0 1 0 0 16a8 8 0 0 0 0-16m0 11a1 1 0 1 1 0 2a1 1 0 0 1 0-2m0-9a1 1 0 0 1 1 1v6a1 1 0 1 1-2 0V7a1 1 0 0 1 1-1"/>
  </g>
</svg>`, ka = gt`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <g fill="none">
    <path d="m12.593 23.258l-.011.002l-.071.035l-.02.004l-.014-.004l-.071-.035q-.016-.005-.024.005l-.004.01l-.017.428l.005.02l.01.013l.104.074l.015.004l.012-.004l.104-.074l.012-.016l.004-.017l-.017-.427q-.004-.016-.017-.018m.265-.113l-.013.002l-.185.093l-.01.01l-.003.011l.018.43l.005.012l.008.007l.201.093q.019.005.029-.008l.004-.014l-.034-.614q-.005-.018-.02-.022m-.715.002a.02.02 0 0 0-.027.006l-.006.014l-.034.614q.001.018.017.024l.015-.002l.201-.093l.01-.008l.004-.011l.017-.43l-.003-.012l-.01-.01z"/><path fill="currentColor" d="M12 2c5.523 0 10 4.477 10 10s-4.477 10-10 10S2 17.523 2 12S6.477 2 12 2m0 2a8 8 0 1 0 0 16a8 8 0 0 0 0-16m0 12a1 1 0 1 1 0 2a1 1 0 0 1 0-2m0-9.5a3.625 3.625 0 0 1 1.348 6.99a.8.8 0 0 0-.305.201c-.044.05-.051.114-.05.18L13 14a1 1 0 0 1-1.993.117L11 14v-.25c0-1.153.93-1.845 1.604-2.116a1.626 1.626 0 1 0-2.229-1.509a1 1 0 1 1-2 0A3.625 3.625 0 0 1 12 6.5"/>
  </g>
</svg>`, gv = gt`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <g fill="none">
    <path d="m12.594 23.258l-.012.002l-.071.035l-.02.004l-.014-.004l-.071-.036q-.016-.004-.024.006l-.004.01l-.017.428l.005.02l.01.013l.104.074l.015.004l.012-.004l.104-.074l.012-.016l.004-.017l-.017-.427q-.004-.016-.016-.018m.264-.113l-.014.002l-.184.093l-.01.01l-.003.011l.018.43l.005.012l.008.008l.201.092q.019.005.029-.008l.004-.014l-.034-.614q-.005-.019-.02-.022m-.715.002a.02.02 0 0 0-.027.006l-.006.014l-.034.614q.001.018.017.024l.015-.002l.201-.093l.01-.008l.003-.011l.018-.43l-.003-.012l-.01-.01z"/>
    <path fill="currentColor" d="M20 9a1 1 0 0 1 1 1v1a8 8 0 0 1-8 8H9.414l.793.793a1 1 0 0 1-1.414 1.414l-2.496-2.496a1 1 0 0 1-.287-.567L6 17.991a1 1 0 0 1 .237-.638l.056-.06l2.5-2.5a1 1 0 0 1 1.414 1.414L9.414 17H13a6 6 0 0 0 6-6v-1a1 1 0 0 1 1-1m-4.793-6.207l2.5 2.5a1 1 0 0 1 0 1.414l-2.5 2.5a1 1 0 1 1-1.414-1.414L14.586 7H11a6 6 0 0 0-6 6v1a1 1 0 1 1-2 0v-1a8 8 0 0 1 8-8h3.586l-.793-.793a1 1 0 0 1 1.414-1.414"/>
  </g>
</svg>`, mv = gt`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <path fill="currentColor" d="M7 15q1.25 0 2.125-.875T10 12t-.875-2.125T7 9t-2.125.875T4 12t.875 2.125T7 15m0 3q-2.5 0-4.25-1.75T1 12t1.75-4.25T7 6q2.025 0 3.538 1.15T12.65 10h8.375L23 11.975l-3.5 4L17 14l-2 2l-2-2h-.35q-.625 1.8-2.175 2.9T7 18"/>
  </svg>`;
function Ht(n, t, e) {
  n[t].addListener(e);
}
function $t(n, t, e) {
  n[t].removeListener(e);
}
function mt(n, t) {
  n.hidden = t;
}
function pt(n) {
  return n.hidden;
}
class pv {
  constructor() {
    c(this, "button");
    c(this, "loaderMain");
    c(this, "loaderCircle");
    c(this, "onClick", new U());
    c(this, "events", {
      click: this.onClick
    });
    c(this, "_progress", 0);
    const t = this.createElements();
    this.button = t.button, this.loaderMain = t.loaderMain, this.loaderCircle = t.loaderCircle, this.progress = 0;
  }
  createElements() {
    const t = L.createIconButton(cv, {
      ariaLabel: "Download translation"
    }), e = t.querySelector(".vot-loader-main");
    if (!e)
      throw new Error("[VOT] DownloadButton loader main element not found");
    const i = t.querySelector(
      ".vot-loader-progress"
    );
    if (!i)
      throw new Error("[VOT] DownloadButton loader circle element not found");
    return t.addEventListener("click", () => {
      this.onClick.dispatch();
    }), { button: t, loaderMain: e, loaderCircle: i };
  }
  addEventListener(t, e) {
    return Ht(this.events, "click", e), this;
  }
  removeEventListener(t, e) {
    return $t(this.events, "click", e), this;
  }
  get progress() {
    return this._progress;
  }
  set progress(t) {
    const e = bv(t);
    this._progress = e;
    const i = this.getCircleCircumference();
    this.loaderCircle.style.strokeDasharray = `${i}`;
    const s = i * (1 - e / 100);
    this.loaderCircle.style.strokeDashoffset = `${s}`, this.loaderMain.style.opacity = e === 0 ? "1" : "0", this.loaderCircle.style.opacity = e === 0 ? "0" : "1";
  }
  getCircleCircumference() {
    const t = this.loaderCircle.r?.baseVal?.value ?? 0;
    return 2 * Math.PI * t;
  }
  set hidden(t) {
    mt(this.button, t);
  }
  get hidden() {
    return pt(this.button);
  }
}
function bv(n) {
  if (!Number.isFinite(n)) return 0;
  const t = n < 1 ? n * 100 : n;
  return Math.max(0, Math.min(100, Math.round(t)));
}
class It {
  constructor({ labelText: t, icon: e }) {
    c(this, "container");
    c(this, "icon");
    c(this, "text");
    c(this, "_labelText");
    c(this, "_icon");
    this._labelText = t, this._icon = e;
    const i = this.createElements();
    this.container = i.container, this.icon = i.icon, this.text = i.text;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-label"]), e = L.createEl("span", ["vot-label-text"]);
    e.textContent = this._labelText;
    const i = L.createEl("span", ["vot-label-icon"]);
    return this._icon ? ht(this._icon, i) : i.hidden = !0, t.append(e, i), {
      container: t,
      icon: i,
      text: e
    };
  }
  set hidden(t) {
    mt(this.container, t);
  }
  get hidden() {
    return pt(this.container);
  }
}
class Ts {
  constructor({ titleHtml: t, isTemp: e = !1 }) {
    c(this, "container");
    c(this, "backdrop");
    c(this, "box");
    c(this, "contentWrapper");
    c(this, "headerContainer");
    c(this, "titleContainer");
    c(this, "title");
    c(this, "closeButton");
    c(this, "bodyContainer");
    c(this, "footerContainer");
    c(this, "onClose", new U());
    c(this, "events", {
      close: this.onClose
    });
    // Focus management for accessibility.
    c(this, "previouslyFocused", null);
    c(this, "keydownListener");
    // Adaptive vertical alignment for long content.
    c(this, "adaptiveAlignObserver");
    c(this, "adaptiveAlignRaf", null);
    c(this, "handleViewportChange", () => {
      this.scheduleAdaptiveVerticalAlign();
    });
    c(this, "titleId", typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `vot-dialog-title-${Math.random().toString(36).slice(2)}`);
    c(this, "_titleHtml");
    c(this, "_isTemp");
    this._titleHtml = t, this._isTemp = e;
    const i = this.createElements();
    this.container = i.container, this.backdrop = i.backdrop, this.box = i.box, this.contentWrapper = i.contentWrapper, this.headerContainer = i.headerContainer, this.titleContainer = i.titleContainer, this.title = i.title, this.closeButton = i.closeButton, this.bodyContainer = i.bodyContainer, this.footerContainer = i.footerContainer;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-dialog-container"]);
    this._isTemp && t.classList.add("vot-dialog-temp"), t.hidden = !this._isTemp, t.setAttribute("aria-hidden", t.hidden ? "true" : "false"), t.toggleAttribute("inert", t.hidden);
    const e = L.createEl("vot-block", ["vot-dialog-backdrop"]), i = L.createEl("vot-block", ["vot-dialog"]);
    i.dataset.verticalAlign = "center", i.setAttribute("role", "dialog"), i.setAttribute("aria-modal", "true"), i.tabIndex = -1;
    const s = L.createEl("vot-block", [
      "vot-dialog-content-wrapper"
    ]), o = L.createEl("vot-block", [
      "vot-dialog-header-container"
    ]), r = L.createEl("vot-block", [
      "vot-dialog-title-container"
    ]), a = L.createEl("vot-block", ["vot-dialog-title"]);
    a.id = this.titleId, a.append(this._titleHtml), r.appendChild(a), i.setAttribute("aria-labelledby", this.titleId);
    const l = L.createIconButton(fv, {
      ariaLabel: "Close"
    });
    l.classList.add("vot-dialog-close-button"), e.addEventListener("click", () => {
      this.close();
    }), l.addEventListener("click", () => {
      this.close();
    }), o.append(r, l);
    const u = L.createEl("vot-block", [
      "vot-dialog-body-container"
    ]), d = L.createEl("vot-block", [
      "vot-dialog-footer-container"
    ]);
    return s.append(o, u, d), i.appendChild(s), t.append(e, i), i.addEventListener("click", (h) => {
      h.stopPropagation();
    }), {
      container: t,
      backdrop: e,
      box: i,
      contentWrapper: s,
      headerContainer: o,
      titleContainer: r,
      title: a,
      closeButton: l,
      bodyContainer: u,
      footerContainer: d
    };
  }
  addEventListener(t, e) {
    return Ht(this.events, "close", e), this;
  }
  removeEventListener(t, e) {
    return $t(this.events, "close", e), this;
  }
  open() {
    return this.previouslyFocused ?? (this.previouslyFocused = document.activeElement), this.hidden = !1, this.attachKeydownTrap(), this.attachAdaptiveVerticalAlign(), queueMicrotask(() => this.focusFirst()), this;
  }
  remove() {
    return this.detachAdaptiveVerticalAlign(), this.detachKeydownTrap(), this.container.remove(), this.restoreFocus(), this.onClose.dispatch(), this;
  }
  close() {
    return this._isTemp ? this.remove() : (this.detachAdaptiveVerticalAlign(), this.detachKeydownTrap(), this.hidden = !0, this.restoreFocus(), this.onClose.dispatch(), this);
  }
  attachAdaptiveVerticalAlign() {
    if (this.adaptiveAlignObserver) {
      this.scheduleAdaptiveVerticalAlign();
      return;
    }
    typeof ResizeObserver < "u" && (this.adaptiveAlignObserver = new ResizeObserver(() => {
      this.scheduleAdaptiveVerticalAlign();
    }), this.adaptiveAlignObserver.observe(this.contentWrapper)), globalThis.addEventListener("resize", this.handleViewportChange, {
      passive: !0
    }), globalThis.visualViewport && (globalThis.visualViewport.addEventListener(
      "resize",
      this.handleViewportChange,
      { passive: !0 }
    ), globalThis.visualViewport.addEventListener(
      "scroll",
      this.handleViewportChange,
      { passive: !0 }
    )), this.scheduleAdaptiveVerticalAlign();
  }
  detachAdaptiveVerticalAlign() {
    this.adaptiveAlignObserver && (this.adaptiveAlignObserver.disconnect(), this.adaptiveAlignObserver = void 0), globalThis.removeEventListener("resize", this.handleViewportChange), globalThis.visualViewport?.removeEventListener(
      "resize",
      this.handleViewportChange
    ), globalThis.visualViewport?.removeEventListener(
      "scroll",
      this.handleViewportChange
    ), this.adaptiveAlignRaf !== null && (cancelAnimationFrame(this.adaptiveAlignRaf), this.adaptiveAlignRaf = null);
  }
  scheduleAdaptiveVerticalAlign() {
    this.adaptiveAlignRaf !== null && cancelAnimationFrame(this.adaptiveAlignRaf), this.adaptiveAlignRaf = requestAnimationFrame(() => {
      this.adaptiveAlignRaf = null, this.updateAdaptiveVerticalAlign();
    });
  }
  updateAdaptiveVerticalAlign() {
    const t = globalThis.visualViewport?.height ?? globalThis.innerHeight;
    if (!t || t <= 0)
      return;
    const e = 16, i = Math.max(160, Math.round(t * 0.75)), s = Math.max(160, Math.round(t - e * 2)), o = this.contentWrapper.scrollHeight, r = this.box.dataset.verticalAlign === "top", a = i - 8, l = Math.round(t * 0.6);
    (r ? o > l : o >= a) ? (this.box.dataset.verticalAlign = "top", this.box.style.setProperty("--vot-dialog-max-height", `${s}px`)) : (this.box.dataset.verticalAlign = "center", this.box.style.setProperty("--vot-dialog-max-height", `${i}px`));
  }
  restoreFocus() {
    const t = this.previouslyFocused;
    this.previouslyFocused = null, t && t instanceof HTMLElement && document.contains(t) && t.focus();
  }
  getFocusableElements() {
    const t = [
      "button:not([disabled])",
      "[href]",
      "input:not([disabled])",
      "select:not([disabled])",
      "textarea:not([disabled])",
      "[tabindex]:not([tabindex='-1'])",
      "[role='button']:not([aria-disabled='true'])"
    ];
    return Array.from(
      this.container.querySelectorAll(t.join(","))
    ).filter((e) => !e.hidden && e.getClientRects().length > 0);
  }
  focusFirst() {
    (this.getFocusableElements()[0] ?? this.closeButton ?? this.box).focus?.();
  }
  attachKeydownTrap() {
    this.keydownListener || (this.keydownListener = (t) => {
      if (t.key === "Escape") {
        t.preventDefault(), this.close();
        return;
      }
      if (t.key !== "Tab")
        return;
      const e = this.getFocusableElements();
      if (!e.length) {
        t.preventDefault(), this.box.focus();
        return;
      }
      const i = e[0], s = e.at(-1) ?? i, o = document.activeElement;
      t.shiftKey ? (o === i || o === this.box) && (t.preventDefault(), s.focus()) : o === s && (t.preventDefault(), i.focus());
    }, this.container.addEventListener("keydown", this.keydownListener));
  }
  detachKeydownTrap() {
    this.keydownListener && (this.container.removeEventListener("keydown", this.keydownListener), this.keydownListener = void 0);
  }
  set hidden(t) {
    mt(this.container, t), this.container.setAttribute("aria-hidden", t ? "true" : "false"), this.container.toggleAttribute("inert", t);
  }
  get hidden() {
    return pt(this.container);
  }
  get isDialogOpen() {
    return !this.container.hidden;
  }
}
class ks {
  constructor({
    labelHtml: t = "",
    placeholder: e = "",
    value: i = "",
    multiline: s = !1
  }) {
    c(this, "container");
    c(this, "input");
    c(this, "label");
    c(this, "onInput", new U());
    c(this, "onChange", new U());
    c(this, "events", {
      input: this.onInput,
      change: this.onChange
    });
    c(this, "_labelHtml");
    c(this, "_multiline");
    c(this, "_placeholder");
    c(this, "_value");
    this._labelHtml = t, this._multiline = s, this._placeholder = e, this._value = i;
    const o = this.createElements();
    this.container = o.container, this.input = o.input, this.label = o.label;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-textfield"]), e = document.createElement(
      this._multiline ? "textarea" : "input"
    );
    this._labelHtml || e.classList.add("vot-show-placeholer", "vot-show-placeholder"), e.placeholder = this._placeholder, e.value = this._value;
    const i = L.createEl("span");
    return i.append(this._labelHtml), t.append(e, i), e.addEventListener("input", () => {
      this._value = this.input.value, this.onInput.dispatch(this._value);
    }), e.addEventListener("change", () => {
      this._value = this.input.value, this.onChange.dispatch(this._value);
    }), {
      container: t,
      label: i,
      input: e
    };
  }
  addEventListener(t, e) {
    return Ht(this.events, t, e), this;
  }
  removeEventListener(t, e) {
    return $t(this.events, t, e), this;
  }
  get value() {
    return this._value;
  }
  /**
   * If you set a different new value, it will trigger the change event
   */
  set value(t) {
    this._value !== t && (this.input.value = this._value = t, this.onChange.dispatch(this._value));
  }
  get placeholder() {
    return this._placeholder;
  }
  set placeholder(t) {
    this.input.placeholder = this._placeholder = t;
  }
  get disabled() {
    return this.input.disabled;
  }
  set disabled(t) {
    this.input.disabled = t;
  }
  set hidden(t) {
    mt(this.container, t);
  }
  get hidden() {
    return pt(this.container);
  }
}
class ot {
  constructor({
    selectTitle: t,
    dialogTitle: e,
    items: i,
    searchItemsProvider: s,
    labelElement: o,
    dialogParent: r = document.documentElement,
    multiSelect: a
  }) {
    c(this, "container");
    c(this, "outer");
    c(this, "arrowIcon");
    c(this, "title");
    c(this, "dialogParent");
    c(this, "labelElement");
    c(this, "_selectTitle");
    c(this, "_dialogTitle");
    c(this, "multiSelect");
    c(this, "baseItems");
    c(this, "_items");
    c(this, "searchItemsProvider");
    c(this, "isLoading", !1);
    c(this, "isDialogOpen", !1);
    c(this, "searchRequestId", 0);
    c(this, "onSelectItem", new U());
    c(this, "onBeforeOpen", new U());
    c(this, "events", {
      selectItem: this.onSelectItem,
      beforeOpen: this.onBeforeOpen
    });
    c(this, "contentList");
    c(this, "contentItemSearchDatasetKey", "votSearchLabel");
    c(this, "contentItemIndexDatasetKey", "votIndex");
    c(this, "selectedItems", []);
    c(this, "selectedValues");
    c(this, "multiSelectItemHandle", (t) => {
      const e = t.value;
      this.selectedValues.has(e) && this.selectedValues.size > 1 ? this.selectedValues.delete(e) : this.selectedValues.add(e), this.syncItemsSelectionState(), this.syncItemsSelectionState(this.baseItems), this.updateSelectedState(), this.onSelectItem.dispatch(Array.from(this.selectedValues));
    });
    c(this, "singleSelectItemHandle", (t) => {
      const e = t.value;
      this.selectedValues = /* @__PURE__ */ new Set([e]), this.syncItemsSelectionState(), this.syncItemsSelectionState(this.baseItems), this.updateSelectedState(), this.onSelectItem.dispatch(e);
    });
    c(this, "onContentItemClick", (t) => {
      if (!(t.target instanceof HTMLElement))
        return;
      const e = t.target.closest(
        ".vot-select-content-item"
      );
      if (!e || e.inert || !this.contentList?.contains(e))
        return;
      const i = e.dataset[this.contentItemIndexDatasetKey];
      if (!i)
        return;
      const s = this._items[Number(i)];
      if (s) {
        if (this.multiSelect) {
          this.multiSelectItemHandle(s);
          return;
        }
        this.singleSelectItemHandle(s);
      }
    });
    this._selectTitle = t, this._dialogTitle = e, this.baseItems = this.cloneItems(i), this._items = this.cloneItems(i), this.searchItemsProvider = s, this.multiSelect = a ?? !1, this.labelElement = o, this.dialogParent = r, this.selectedValues = this.calcSelectedValues();
    const l = this.createElements();
    this.container = l.container, this.outer = l.outer, this.arrowIcon = l.arrowIcon, this.title = l.title;
  }
  cloneItems(t) {
    return t.map((e) => ({ ...e }));
  }
  static genLanguageItems(t, e) {
    return t.map((i) => {
      const s = `langs.${i}`, o = p.get(s);
      return {
        label: o === s ? i.toUpperCase() : o,
        value: i,
        selected: e === i
      };
    });
  }
  syncItemsSelectionState(t = this._items) {
    for (const e of t)
      e.selected = this.selectedValues.has(e.value);
  }
  restoreBaseItems() {
    this._items = this.cloneItems(this.baseItems), this.syncItemsSelectionState(), this.updateSelectedState();
  }
  createDialogContentList() {
    const t = L.createEl("vot-block", ["vot-select-content-list"]);
    for (const [e, i] of this._items.entries()) {
      const s = L.createEl("vot-block", ["vot-select-content-item"]);
      s.textContent = i.label, s.dataset.votSelected = i.selected === !0 ? "true" : "false", s.dataset.votValue = i.value, s.dataset[this.contentItemSearchDatasetKey] = i.label.toLowerCase(), s.dataset[this.contentItemIndexDatasetKey] = String(e), i.disabled && (s.inert = !0), t.appendChild(s);
    }
    return t.addEventListener("click", this.onContentItemClick), this.selectedItems = Array.from(t.children), t;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-select"]);
    this.labelElement ? (t.classList.add("vot-select--labeled"), t.append(this.labelElement)) : t.classList.add("vot-select--control-only");
    const e = L.createEl("vot-block", ["vot-select-outer"]);
    L.makeButtonLike(e), e.setAttribute("aria-haspopup", "dialog"), e.setAttribute("aria-expanded", "false");
    const i = L.createEl("vot-block", ["vot-select-title"]);
    i.textContent = this.visibleText;
    const s = L.createEl("vot-block", ["vot-select-arrow-icon"]);
    return ht(uc, s), e.append(i, s), e.addEventListener("click", () => {
      if (!this.disabled && !(this.isLoading || this.isDialogOpen))
        try {
          this.isLoading = !0;
          const o = new Ts({
            titleHtml: this._dialogTitle,
            isTemp: !0
          });
          this.onBeforeOpen.dispatch(o), this.dialogParent.appendChild(o.container), this.isDialogOpen = !0, e.setAttribute("aria-expanded", "true");
          const r = new ks({
            labelHtml: p.get("searchField")
          });
          r.addEventListener("input", async (a) => {
            const l = ++this.searchRequestId;
            if (this.searchItemsProvider) {
              const d = await this.searchItemsProvider(a);
              if (l !== this.searchRequestId)
                return;
              this.updateItems(d, { persist: !1 });
            }
            const u = a.toLowerCase();
            for (const d of this.selectedItems) {
              const h = d.dataset[this.contentItemSearchDatasetKey] ?? "";
              d.hidden = !h.includes(u);
            }
          }), this.contentList = this.createDialogContentList(), o.bodyContainer.append(
            r.container,
            this.contentList
          ), o.addEventListener("close", () => {
            this.isDialogOpen = !1, this.restoreBaseItems(), this.selectedItems = [], this.contentList = void 0, e.setAttribute("aria-expanded", "false");
          }), o.open();
        } finally {
          this.isLoading = !1;
        }
    }), t.appendChild(e), {
      container: t,
      outer: e,
      arrowIcon: s,
      title: i
    };
  }
  calcSelectedValues() {
    return new Set(
      this._items.filter((t) => t.selected).map((t) => t.value)
    );
  }
  addEventListener(t, e) {
    return Ht(this.events, t, e), this;
  }
  removeEventListener(t, e) {
    return $t(this.events, t, e), this;
  }
  updateTitle() {
    return this.title.textContent = this.visibleText, this;
  }
  updateSelectedState() {
    if (this.selectedItems.length > 0)
      for (const t of this.selectedItems) {
        const e = t.dataset.votValue;
        e !== void 0 && (t.dataset.votSelected = this.selectedValues.has(e).toString());
      }
    return this.updateTitle(), this;
  }
  setSelectedValue(t) {
    const e = Array.isArray(t) ? t : [t];
    let i;
    return this.multiSelect ? i = e : i = e.length > 0 ? [e[0]] : [], this.selectedValues = new Set(i), this.syncItemsSelectionState(), this.syncItemsSelectionState(this.baseItems), this.updateSelectedState(), this;
  }
  /**
   * @warning Use chaining with this method or reassign to variable to get the updated type of instance
   */
  updateItems(t, e = {}) {
    const { persist: i = !0 } = e, s = this.cloneItems(t);
    i && (this.baseItems = this.cloneItems(s)), this._items = s, this.selectedValues = this.calcSelectedValues(), this.updateSelectedState();
    const o = this.contentList?.parentElement;
    if (!this.contentList || !o)
      return this;
    const r = this.contentList;
    return this.contentList = this.createDialogContentList(), o.replaceChild(this.contentList, r), this;
  }
  get visibleText() {
    return this.multiSelect ? this._items.filter((t) => this.selectedValues.has(t.value)).map((t) => t.label).join(", ") || this._selectTitle : this._items.find((t) => t.selected)?.label ?? this._selectTitle;
  }
  set selectTitle(t) {
    this._selectTitle = t, this.updateTitle();
  }
  set hidden(t) {
    mt(this.container, t);
  }
  get hidden() {
    return pt(this.container);
  }
  get disabled() {
    return this.outer.getAttribute("disabled") === "true" || this.outer.getAttribute("aria-disabled") === "true";
  }
  set disabled(t) {
    if (t) {
      this.outer.setAttribute("disabled", "true");
      return;
    }
    this.outer.removeAttribute("disabled");
  }
}
class yv {
  constructor({
    from: {
      selectTitle: t = p.get("videoLanguage"),
      dialogTitle: e = p.get("videoLanguage"),
      items: i
    },
    to: {
      selectTitle: s = p.get(
        "translationLanguage"
      ),
      dialogTitle: o = p.get(
        "translationLanguage"
      ),
      items: r
    },
    dialogParent: a = document.documentElement
  }) {
    c(this, "container");
    c(this, "fromSelect");
    c(this, "directionIcon");
    c(this, "toSelect");
    c(this, "dialogParent");
    // from select opts
    c(this, "_fromSelectTitle");
    c(this, "_fromDialogTitle");
    c(this, "_fromItems");
    // to select opts
    c(this, "_toSelectTitle");
    c(this, "_toDialogTitle");
    c(this, "_toItems");
    this._fromSelectTitle = t, this._fromDialogTitle = e, this._fromItems = i, this._toSelectTitle = s, this._toDialogTitle = o, this._toItems = r, this.dialogParent = a;
    const l = this.createElements();
    this.container = l.container, this.fromSelect = l.fromSelect, this.directionIcon = l.directionIcon, this.toSelect = l.toSelect;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-lang-select"]), e = new ot({
      selectTitle: this._fromSelectTitle,
      dialogTitle: this._fromDialogTitle,
      items: this._fromItems,
      dialogParent: this.dialogParent
    }), i = L.createEl("vot-block", ["vot-lang-select-icon"]);
    ht(hv, i);
    const s = new ot({
      selectTitle: this._toSelectTitle,
      dialogTitle: this._toDialogTitle,
      items: this._toItems,
      dialogParent: this.dialogParent
    });
    return t.append(e.container, i, s.container), {
      container: t,
      fromSelect: e,
      directionIcon: i,
      toSelect: s
    };
  }
  setSelectedValues(t, e) {
    return this.fromSelect.setSelectedValue(t), this.toSelect.setSelectedValue(e), this;
  }
  updateItems(t, e) {
    return this._fromItems = t, this._toItems = e, this.fromSelect = this.fromSelect.updateItems(t), this.toSelect = this.toSelect.updateItems(e), this;
  }
}
class Xt {
  constructor({
    labelHtml: t,
    value: e = 50,
    min: i = 0,
    max: s = 100,
    step: o = 1
  }) {
    c(this, "container");
    c(this, "input");
    c(this, "label");
    c(this, "onInput", new U());
    c(this, "_labelHtml");
    c(this, "_value");
    c(this, "_min");
    c(this, "_max");
    c(this, "_step");
    this._labelHtml = t, this._value = e, this._min = i, this._max = s, this._step = o;
    const r = this.createElements();
    this.container = r.container, this.input = r.input, this.label = r.label, this.update();
  }
  updateProgress() {
    const t = this._max - this._min, e = t <= 0 ? 0 : (this._value - this._min) / t, i = Math.max(0, Math.min(1, e));
    return this.container.style.setProperty("--vot-progress", i.toString()), this;
  }
  update() {
    return this._value = this.input.valueAsNumber, this._min = +this.input.min, this._max = +this.input.max, this.updateProgress(), this;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-slider"]), e = document.createElement("input");
    e.type = "range", e.min = this._min.toString(), e.max = this._max.toString(), e.step = this._step.toString(), e.value = this._value.toString();
    const i = L.createEl("span");
    return ht(this._labelHtml, i), t.append(e, i), e.addEventListener("input", () => {
      this.update(), this.onInput.dispatch(this._value, !1);
    }), {
      container: t,
      label: i,
      input: e
    };
  }
  addEventListener(t, e) {
    return this.onInput.addListener(e), this;
  }
  removeEventListener(t, e) {
    return this.onInput.removeListener(e), this;
  }
  get value() {
    return this._value;
  }
  /**
   * If you set a different new value, it will trigger the input event
   */
  set value(t) {
    this._value = ji(t, this._min, this._max), this.input.value = this._value.toString(), this.updateProgress(), this.onInput.dispatch(this._value, !0);
  }
  get min() {
    return this._min;
  }
  set min(t) {
    this._min = t, this.input.min = this._min.toString(), this._value = ji(this._value, this._min, this._max), this.input.value = this._value.toString(), this.updateProgress();
  }
  get max() {
    return this._max;
  }
  set max(t) {
    this._max = t, this.input.max = this._max.toString(), this._value = ji(this._value, this._min, this._max), this.input.value = this._value.toString(), this.updateProgress();
  }
  get step() {
    return this._step;
  }
  set step(t) {
    this._step = t, this.input.step = this._step.toString();
  }
  get disabled() {
    return this.input.disabled;
  }
  set disabled(t) {
    this.input.disabled = t;
  }
  set hidden(t) {
    mt(this.container, t);
  }
  get hidden() {
    return pt(this.container);
  }
}
function ji(n, t, e) {
  return !Number.isFinite(n) || e < t ? t : Math.max(t, Math.min(e, n));
}
class Jt {
  constructor({
    labelText: t,
    labelEOL: e = "",
    value: i = 50,
    symbol: s = "%"
  }) {
    c(this, "container");
    c(this, "strong");
    c(this, "text");
    c(this, "_labelText");
    c(this, "_labelEOL");
    c(this, "_value");
    c(this, "_symbol");
    this._labelText = t, this._labelEOL = e, this._value = i, this._symbol = s;
    const o = this.createElements();
    this.container = o.container, this.strong = o.strong, this.text = o.text;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-slider-label"]), e = L.createEl("span", ["vot-slider-label-text"]);
    e.textContent = this.labelText;
    const i = L.createEl("span", ["vot-slider-label-value"]);
    return i.textContent = this.valueText, t.append(e, i), {
      container: t,
      strong: i,
      text: e
    };
  }
  get labelText() {
    return `${this._labelText}${this._labelEOL}`;
  }
  get valueText() {
    return `${this._value}${this._symbol}`;
  }
  get value() {
    return this._value;
  }
  set value(t) {
    this._value = t, this.strong.textContent = this.valueText;
  }
  set hidden(t) {
    mt(this.container, t);
  }
  get hidden() {
    return pt(this.container);
  }
}
class Xi {
  constructor({
    position: t = "default",
    direction: e = "default",
    status: i = "none",
    labelHtml: s = ""
  }) {
    c(this, "container");
    c(this, "translateButton");
    c(this, "separator");
    c(this, "pipButton");
    c(this, "separator2");
    c(this, "menuButton");
    c(this, "label");
    // Opacity is driven by a CSS class so host pages cannot break visibility by
    // writing inline `style="opacity:0; pointer-events:none"`.
    c(this, "_opacity", 1);
    c(this, "_position");
    c(this, "_direction");
    c(this, "_status");
    /** Text shown next to the translate icon (plain text, not HTML). */
    c(this, "_labelText");
    this._position = t, this._direction = e, this._status = i, this._labelText = s;
    const o = this.createElements();
    this.container = o.container, this.translateButton = o.translateButton, this.separator = o.separator, this.pipButton = o.pipButton, this.separator2 = o.separator2, this.menuButton = o.menuButton, this.label = o.label;
  }
  static calcPosition(t, e) {
    return e ? t <= 44 ? "left" : t >= 66 ? "right" : "default" : "default";
  }
  static calcDirection(t) {
    return ["default", "top"].includes(t) ? "row" : "column";
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-segmented-button"]);
    t.dataset.position = this._position, t.dataset.direction = this._direction, t.dataset.status = this._status;
    const e = L.createEl("vot-block", [
      "vot-segment",
      "vot-translate-button"
    ]);
    e.setAttribute("role", "button"), e.tabIndex = 0, e.setAttribute("aria-label", this._labelText || "Translate"), ht(rv, e);
    const i = L.createEl("span", ["vot-segment-label"]);
    i.textContent = this._labelText, e.appendChild(i);
    const s = L.createEl("vot-block", ["vot-separator"]), o = L.createEl("vot-block", ["vot-segment-only-icon"]);
    o.setAttribute("role", "button"), o.tabIndex = 0, o.setAttribute("aria-label", "Picture in picture"), ht(av, o);
    const r = L.createEl("vot-block", ["vot-separator"]), a = L.createEl("vot-block", ["vot-segment-only-icon"]);
    return a.setAttribute("role", "button"), a.tabIndex = 0, a.setAttribute("aria-label", "Menu"), a.setAttribute("aria-haspopup", "dialog"), a.setAttribute("aria-expanded", "false"), ht(lv, a), t.append(
      e,
      s,
      o,
      r,
      a
    ), {
      container: t,
      translateButton: e,
      separator: s,
      pipButton: o,
      separator2: r,
      menuButton: a,
      label: i
    };
  }
  showPiPButton(t) {
    return this.separator2.hidden = this.pipButton.hidden = !t, this;
  }
  setText(t) {
    return this._labelText = t, this.label.textContent = t, this.translateButton.setAttribute("aria-label", t || "Translate"), this;
  }
  remove() {
    return this.container.remove(), this;
  }
  get tooltipPos() {
    switch (this.position) {
      case "left":
        return "right";
      case "right":
        return "left";
      default:
        return "bottom";
    }
  }
  set status(t) {
    this._status = this.container.dataset.status = t;
  }
  get status() {
    return this._status;
  }
  set loading(t) {
    this.container.dataset.loading = t.toString();
  }
  get loading() {
    return this.container.dataset.loading === "true";
  }
  set hidden(t) {
    mt(this.container, t);
  }
  get hidden() {
    return pt(this.container);
  }
  get position() {
    return this._position;
  }
  set position(t) {
    this._position = this.container.dataset.position = t;
  }
  get direction() {
    return this._direction;
  }
  set direction(t) {
    this._direction = this.container.dataset.direction = t;
  }
  set opacity(t) {
    const e = Number.isFinite(t) ? t : 1;
    this._opacity = e;
    const i = e <= 0.01;
    this.container.classList.toggle("vot-segmented-button--hidden", i);
  }
  get opacity() {
    return this._opacity;
  }
}
class vv {
  constructor({ position: t = "default", titleHtml: e = "" }) {
    c(this, "container");
    c(this, "contentWrapper");
    c(this, "headerContainer");
    c(this, "bodyContainer");
    c(this, "footerContainer");
    c(this, "titleContainer");
    c(this, "title");
    c(this, "_position");
    c(this, "_titleHtml");
    // A11y: stable ids for aria-controls / aria-labelledby.
    c(this, "menuId", typeof crypto < "u" && "randomUUID" in crypto ? `vot-menu-${crypto.randomUUID()}` : `vot-menu-${Math.random().toString(36).slice(2)}`);
    c(this, "titleId", typeof crypto < "u" && "randomUUID" in crypto ? `vot-menu-title-${crypto.randomUUID()}` : `vot-menu-title-${Math.random().toString(36).slice(2)}`);
    this._position = t, this._titleHtml = e;
    const i = this.createElements();
    this.container = i.container, this.contentWrapper = i.contentWrapper, this.headerContainer = i.headerContainer, this.bodyContainer = i.bodyContainer, this.footerContainer = i.footerContainer, this.titleContainer = i.titleContainer, this.title = i.title;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-menu"]);
    t.hidden = !0, t.id = this.menuId, t.dataset.position = this._position, t.setAttribute("role", "dialog"), t.setAttribute("aria-modal", "false"), t.setAttribute("aria-hidden", "true"), t.toggleAttribute("inert", !0);
    const e = L.createEl("vot-block", [
      "vot-menu-content-wrapper"
    ]);
    t.appendChild(e);
    const i = L.createEl("vot-block", [
      "vot-menu-header-container"
    ]), s = L.createEl("vot-block", [
      "vot-menu-title-container"
    ]);
    i.appendChild(s);
    const o = L.createEl("vot-block", ["vot-menu-title"]);
    o.id = this.titleId, o.append(this._titleHtml), s.appendChild(o), t.setAttribute("aria-labelledby", this.titleId);
    const r = L.createEl("vot-block", ["vot-menu-body-container"]), a = L.createEl("vot-block", [
      "vot-menu-footer-container"
    ]);
    return e.append(i, r, a), {
      container: t,
      contentWrapper: e,
      headerContainer: i,
      bodyContainer: r,
      footerContainer: a,
      titleContainer: s,
      title: o
    };
  }
  setText(t) {
    return this._titleHtml = this.title.textContent = t, this;
  }
  remove() {
    return this.container.remove(), this;
  }
  set hidden(t) {
    mt(this.container, t), this.container.setAttribute("aria-hidden", t ? "true" : "false"), this.container.toggleAttribute("inert", t);
  }
  get hidden() {
    return pt(this.container);
  }
  get position() {
    return this._position;
  }
  set position(t) {
    this._position = this.container.dataset.position = t;
  }
}
const Te = class Te {
  constructor({
    mount: t,
    globalPortal: e,
    data: i = {},
    videoHandler: s,
    intervalIdleChecker: o
  }) {
    c(this, "mount");
    c(this, "globalPortal");
    c(this, "abortController", null);
    c(this, "defaultVolumePersistTimer");
    c(this, "defaultVolumePersistDelayMs", 250);
    c(this, "dragging", !1);
    c(this, "dragCandidate", !1);
    c(this, "dragDirty", !1);
    c(this, "dragStartX", 0);
    c(this, "dragStartY", 0);
    c(this, "currentClientX", 0);
    c(this, "dragThresholdPx", 6);
    c(this, "containerRect", null);
    c(this, "dragIsBigContainer", null);
    c(this, "checkerUnsubscribe", null);
    c(this, "initialized", !1);
    c(this, "data");
    c(this, "videoHandler");
    c(this, "intervalIdleChecker");
    c(this, "events", {
      "click:settings": new U(),
      "click:pip": new U(),
      "click:downloadTranslation": new U(),
      "click:downloadSubtitles": new U(),
      "click:translate": new U(),
      "input:videoVolume": new U(),
      "input:translationVolume": new U(),
      "select:fromLanguage": new U(),
      "select:toLanguage": new U(),
      "select:subtitles": new U()
    });
    // button
    c(this, "votButton");
    c(this, "votButtonTooltip");
    // menu
    c(this, "votMenu");
    c(this, "downloadTranslationButton");
    c(this, "downloadSubtitlesButton");
    c(this, "openSettingsButton");
    c(this, "languagePairSelect");
    c(this, "subtitlesSelectLabel");
    c(this, "subtitlesSelect");
    c(this, "videoVolumeSliderLabel");
    c(this, "videoVolumeSlider");
    c(this, "translationVolumeSliderLabel");
    c(this, "translationVolumeSlider");
    c(this, "onDragStart", (t) => {
      !t.isPrimary || t.button !== 0 || t.pointerType !== "touch" && (t.preventDefault(), this.startDragSession(t.clientX, t.clientY, "overlay-pointer-down"), document.addEventListener("pointermove", this.onGlobalPointerMove, {
        passive: !0
      }), document.addEventListener("pointerup", this.onDragEnd), document.addEventListener("pointercancel", this.onDragEnd));
    });
    // Touch fallback for browsers/environments that don't deliver Pointer Events
    // reliably on mobile. We only use the first active touch.
    c(this, "onTouchDragStart", (t) => {
      if (!t.touches || t.touches.length === 0) return;
      const e = t.touches[0];
      this.startDragSession(e.clientX, e.clientY, "overlay-touch-start"), document.addEventListener("touchmove", this.onGlobalTouchMove, {
        passive: !1
      }), document.addEventListener("touchend", this.onDragEnd), document.addEventListener("touchcancel", this.onDragEnd);
    });
    c(this, "onGlobalTouchMove", (t) => {
      if (!t.touches || t.touches.length === 0) return;
      const e = t.touches[0];
      this.updateDragFromMove(e.clientX, e.clientY, "overlay-touch-move"), this.dragging && t.preventDefault();
    });
    c(this, "onGlobalPointerMove", (t) => {
      this.updateDragFromMove(
        t.clientX,
        t.clientY,
        "overlay-pointer-move"
      );
    });
    c(this, "applyDragFromState", () => {
      if (!this.dragging || !this.dragDirty || !this.containerRect) return;
      const t = this.containerRect.width;
      if (!(t > 0 && Number.isFinite(t)))
        return;
      this.dragDirty = !1;
      const e = this.currentClientX - this.containerRect.left, s = Math.max(0, Math.min(e, t)) / t * 100;
      this.moveButton(s);
    });
    c(this, "onCheckerTick", () => {
      this.applyDragFromState();
    });
    c(this, "onDragEnd", () => {
      document.removeEventListener("pointermove", this.onGlobalPointerMove), document.removeEventListener("pointerup", this.onDragEnd), document.removeEventListener("pointercancel", this.onDragEnd), document.removeEventListener("touchmove", this.onGlobalTouchMove), document.removeEventListener("touchend", this.onDragEnd), document.removeEventListener("touchcancel", this.onDragEnd), this.applyDragFromState();
      const t = this.dragIsBigContainer ?? this.isBigContainer;
      this.dragging && t && this.data.buttonPos && C.set("buttonPos", this.data.buttonPos), this.dragging = !1, this.dragCandidate = !1, this.dragDirty = !1, this.containerRect = null, this.dragIsBigContainer = null;
    });
    this.mount = t, this.globalPortal = e, this.data = i, this.videoHandler = s, this.intervalIdleChecker = o;
  }
  get root() {
    return this.mount.root;
  }
  get portalContainer() {
    return this.mount.portalContainer;
  }
  get tooltipLayoutRoot() {
    return this.mount.tooltipLayoutRoot;
  }
  /**
   * Update mount points (root/tooltipLayoutRoot) when the player container changes.
   * Moves already-mounted UI nodes and rebinds root-bound listeners (dragging).
   */
  updateMount(t) {
    const e = this.mount.root, i = t.root, s = this.mount.tooltipLayoutRoot, o = t.tooltipLayoutRoot;
    return this.mount = t, this.isInitialized() ? (e !== i && (this.votButton && i.appendChild(this.votButton.container), this.votMenu && i.appendChild(this.votMenu.container)), this.votButtonTooltip && ov(
      {
        root: e,
        portalContainer: this.mount.portalContainer,
        subtitlesMountContainer: this.mount.subtitlesMountContainer,
        tooltipLayoutRoot: s
      },
      t
    ) && this.votButtonTooltip.updateMount({
      layoutRoot: o ?? document.documentElement
    }), this) : this;
  }
  isInitialized() {
    return this.initialized;
  }
  calcButtonLayout(t) {
    return this.isBigContainer && wv(t) ? {
      direction: "column",
      position: t
    } : {
      direction: "row",
      position: "default"
    };
  }
  addEventListener(t, e) {
    return this.events[t].addListener(e), this;
  }
  removeEventListener(t, e) {
    return this.events[t].removeListener(e), this;
  }
  scheduleDefaultVolumePersist() {
    this.defaultVolumePersistTimer !== void 0 && globalThis.clearTimeout(this.defaultVolumePersistTimer), this.defaultVolumePersistTimer = globalThis.setTimeout(() => {
      this.defaultVolumePersistTimer = void 0, this.flushDefaultVolumePersist();
    }, this.defaultVolumePersistDelayMs);
  }
  flushDefaultVolumePersist() {
    this.defaultVolumePersistTimer !== void 0 && (globalThis.clearTimeout(this.defaultVolumePersistTimer), this.defaultVolumePersistTimer = void 0), typeof this.data.defaultVolume == "number" && C.set("defaultVolume", this.data.defaultVolume);
  }
  initUI(t = "default") {
    if (this.isInitialized())
      throw new Error("[VOT] OverlayView is already initialized");
    this.initialized = !0;
    const { position: e, direction: i } = this.calcButtonLayout(t);
    this.votButton = new Xi({
      position: e,
      direction: i,
      status: "none",
      labelHtml: p.get("translateVideo")
    }), this.votButton.opacity = 0, this.pipButtonVisible || this.votButton.showPiPButton(!1), this.root.appendChild(this.votButton.container), this.votButtonTooltip = new ct({
      target: this.votButton.translateButton,
      content: p.get("translateVideo"),
      position: this.votButton.tooltipPos,
      // Keep side-tooltip direction stable for the moved button (left/right)
      // so status/error text does not mirror to the opposite side.
      autoLayout: !1,
      hidden: i === "row",
      bordered: !1,
      parentElement: this.globalPortal,
      layoutRoot: this.tooltipLayoutRoot
    }), this.votMenu = new vv({
      titleHtml: p.get("VOTSettings"),
      position: e
    }), this.root.appendChild(this.votMenu.container), this.votButton.menuButton.setAttribute(
      "aria-controls",
      this.votMenu.container.id
    ), this.downloadTranslationButton = new pv(), this.downloadTranslationButton.hidden = !0, this.downloadSubtitlesButton = L.createIconButton(uv, {
      ariaLabel: "Download subtitles"
    }), this.downloadSubtitlesButton.hidden = !0, this.openSettingsButton = L.createIconButton(dv, {
      ariaLabel: p.get("VOTSettings")
    }), this.votMenu.headerContainer.append(
      this.downloadTranslationButton.button,
      this.downloadSubtitlesButton,
      this.openSettingsButton
    );
    const s = this.videoHandler?.videoData?.detectedLanguage ?? "en", o = this.data.responseLanguage ?? "ru";
    this.languagePairSelect = new yv({
      from: {
        // `detectedLanguage` is dynamic and may include codes that aren't in
        // the compile-time Phrase union.
        selectTitle: p.get(
          `langs.${s}`
        ),
        items: ot.genLanguageItems(Pt, s)
      },
      to: {
        selectTitle: p.get(
          `langs.${o}`
        ),
        items: ot.genLanguageItems(mi, o)
      },
      dialogParent: this.globalPortal
    }), this.subtitlesSelectLabel = new It({
      labelText: p.get("VOTSubtitles")
    }), this.subtitlesSelect = new ot({
      selectTitle: p.get("VOTSubtitlesDisabled"),
      dialogTitle: p.get("VOTSubtitles"),
      labelElement: this.subtitlesSelectLabel.container,
      dialogParent: this.globalPortal,
      items: [
        {
          label: p.get("VOTSubtitlesDisabled"),
          value: "disabled",
          selected: !0
        }
      ]
    });
    const r = this.videoHandler ? this.videoHandler.getVideoVolume() * 100 : 100;
    this.videoVolumeSliderLabel = new Jt({
      labelText: p.get("VOTVolume"),
      value: r
    }), this.videoVolumeSlider = new Xt({
      labelHtml: this.videoVolumeSliderLabel.container,
      value: r
    }), this.videoVolumeSlider.hidden = !this.data.showVideoSlider || this.votButton.status !== "success";
    const a = this.data.defaultVolume ?? 100;
    return this.translationVolumeSliderLabel = new Jt({
      labelText: p.get("VOTVolumeTranslation"),
      value: a
    }), this.translationVolumeSlider = new Xt({
      labelHtml: this.translationVolumeSliderLabel.container,
      value: a,
      max: this.data.audioBooster ? El : 100
    }), this.translationVolumeSlider.hidden = this.votButton.status !== "success", this.votMenu.bodyContainer.append(
      this.languagePairSelect.container,
      this.subtitlesSelect.container,
      this.videoVolumeSlider.container,
      this.translationVolumeSlider.container
    ), this;
  }
  initUIEvents() {
    if (!this.isInitialized())
      throw new Error("[VOT] OverlayView isn't initialized");
    this.abortController = new AbortController();
    const t = this.abortController.signal;
    this.checkerUnsubscribe?.(), this.checkerUnsubscribe = this.intervalIdleChecker.subscribe(() => {
      this.onCheckerTick();
    }), this.votButton.container.addEventListener(
      "click",
      (l) => {
        l.preventDefault(), l.stopPropagation(), l.stopImmediatePropagation();
      },
      { signal: t }
    );
    const e = (l) => (u) => {
      (u.key === "Enter" || u.key === " ") && (u.preventDefault(), l());
    }, i = (l) => l.isPrimary && l.button === 0, s = (l, { returnFocusToToggle: u = !1 } = {}) => {
      this.isInitialized() && (this.votMenu.hidden = !l, this.votButton.menuButton.setAttribute("aria-expanded", l.toString()), this.votButtonTooltip && (this.votButtonTooltip.hidden = l || this.votButton.direction === "row"), l ? queueMicrotask(() => this.openSettingsButton?.focus?.()) : u ? queueMicrotask(() => this.votButton.menuButton.focus?.()) : this.votButton.menuButton.blur());
    }, o = () => s(this.votMenu.hidden), r = (l = !1) => s(!1, { returnFocusToToggle: l });
    this.votButton.translateButton.addEventListener(
      "pointerdown",
      (l) => {
        i(l) && (r(), this.events["click:translate"].dispatch());
      },
      { signal: t }
    ), this.votButton.translateButton.addEventListener(
      "keydown",
      e(() => {
        r(), this.events["click:translate"].dispatch();
      }),
      { signal: t }
    ), this.votButton.pipButton.addEventListener(
      "pointerdown",
      (l) => {
        i(l) && (r(), this.events["click:pip"].dispatch());
      },
      { signal: t }
    ), this.votButton.pipButton.addEventListener(
      "keydown",
      e(() => {
        r(), this.events["click:pip"].dispatch();
      }),
      { signal: t }
    ), this.votButton.menuButton.addEventListener(
      "pointerdown",
      (l) => {
        i(l) && (l.preventDefault(), o());
      },
      { signal: t }
    ), this.votButton.menuButton.addEventListener(
      "keydown",
      e(o),
      { signal: t }
    );
    const a = "none";
    this.votButton.container.style.touchAction = a, this.votButton.translateButton.style.touchAction = a, this.votButton.pipButton.style.touchAction = a, this.votButton.menuButton.style.touchAction = a, this.votButton.container.addEventListener("pointerdown", this.onDragStart, {
      signal: t
    }), this.votButton.container.addEventListener(
      "touchstart",
      this.onTouchDragStart,
      { signal: t, passive: !1 }
    ), this.votMenu.container.addEventListener(
      "click",
      (l) => {
        l.preventDefault(), l.stopPropagation(), l.stopImmediatePropagation();
      },
      { signal: t }
    );
    for (const l of ["pointerdown", "mousedown"])
      this.votMenu.container.addEventListener(
        l,
        (u) => {
          u.stopImmediatePropagation();
        },
        { signal: t }
      );
    return document.addEventListener(
      "pointerdown",
      (l) => {
        if (this.votMenu.hidden) return;
        const u = l.target, d = typeof l.composedPath == "function" ? l.composedPath() : [], h = u && this.votMenu.container.contains(u) || d.includes(this.votMenu.container), f = u && this.votButton.menuButton.contains(u) || d.includes(this.votButton.menuButton), g = u && this.votButton.container.contains(u) || d.includes(this.votButton.container), m = u instanceof HTMLElement && !!u.closest(".vot-dialog-container");
        h || f || g || m || r(!1);
      },
      { signal: t, capture: !0, passive: !0 }
    ), this.votMenu.container.addEventListener(
      "keydown",
      (l) => {
        if (l.key !== "Escape") return;
        const u = document.documentElement.classList.contains("vot-keyboard-nav");
        l.preventDefault(), l.stopPropagation(), r(u), this.votButton.container.matches(":hover") || this.votMenu.container.matches(":hover") || this.videoHandler?.overlayVisibility?.queueAutoHide?.();
      },
      { signal: t }
    ), this.downloadTranslationButton.addEventListener("click", () => {
      this.events["click:downloadTranslation"].dispatch();
    }), this.downloadSubtitlesButton.addEventListener(
      "click",
      () => {
        this.events["click:downloadSubtitles"].dispatch();
      },
      { signal: t }
    ), this.openSettingsButton.addEventListener(
      "click",
      () => {
        r(), this.events["click:settings"].dispatch();
      },
      { signal: t }
    ), this.languagePairSelect.fromSelect.addEventListener(
      "selectItem",
      (l) => {
        this.videoHandler?.videoData && (this.videoHandler.videoData.detectedLanguage = l, this.videoHandler.videoManager.rememberUserLanguageSelection(
          this.videoHandler.videoData.videoId,
          l
        )), this.events["select:fromLanguage"].dispatch(l);
      }
    ), this.languagePairSelect.toSelect.addEventListener(
      "selectItem",
      async (l) => {
        this.videoHandler?.videoData && (this.videoHandler.translateToLang = this.videoHandler.videoData.responseLanguage = l);
        const u = this.data.responseLanguage;
        u !== l && (this.data.responseLanguage = l, await C.set("responseLanguage", this.data.responseLanguage)), this.data.enabledDontTranslateLanguages && Array.isArray(this.data.dontTranslateLanguages) && this.data.dontTranslateLanguages.length === 1 && u !== l && typeof u == "string" && this.data.dontTranslateLanguages[0] === u && (this.data.dontTranslateLanguages = [l], await C.set(
          "dontTranslateLanguages",
          this.data.dontTranslateLanguages
        )), this.events["select:toLanguage"].dispatch(l);
      }
    ), this.subtitlesSelect.addEventListener("beforeOpen", async (l) => {
      if (!this.videoHandler?.videoData)
        return;
      const u = this.videoHandler.getSubtitlesCacheKey(
        this.videoHandler.videoData.videoId,
        this.videoHandler.videoData.detectedLanguage,
        this.videoHandler.videoData.responseLanguage
      );
      if (this.videoHandler.subtitlesCacheKey === u)
        return;
      if (this.videoHandler.cacheManager.getSubtitles(u) !== void 0) {
        await this.videoHandler.ensureSubtitlesForCurrentLangPair();
        return;
      }
      const d = this.votButton?.loading ?? !1;
      this.votButton && (this.votButton.loading = !0);
      const h = L.createInlineLoader();
      h.style.margin = "0 auto", l.footerContainer.appendChild(h);
      try {
        await this.videoHandler.ensureSubtitlesForCurrentLangPair();
      } finally {
        h.remove(), this.votButton && (this.votButton.loading = d);
      }
    }), this.subtitlesSelect.addEventListener("selectItem", (l) => {
      this.events["select:subtitles"].dispatch(l);
    }), this.videoVolumeSlider.addEventListener("input", (l, u) => {
      this.videoVolumeSliderLabel && (this.videoVolumeSliderLabel.value = l), !u && this.events["input:videoVolume"].dispatch(l);
    }), this.translationVolumeSlider.addEventListener(
      "input",
      (l, u) => {
        this.translationVolumeSliderLabel && (this.translationVolumeSliderLabel.value = l), this.data.defaultVolume !== l && (this.data.defaultVolume = l, this.scheduleDefaultVolumePersist()), !u && this.events["input:translationVolume"].dispatch(l);
      }
    ), this;
  }
  updateButtonLayout(t, e) {
    return this.isInitialized() ? (this.votMenu.position = t, this.votButton.position = t, this.votButton.direction = e, this.votButtonTooltip.hidden = e === "row", this.votButtonTooltip.setPosition(this.votButton.tooltipPos), this) : this;
  }
  moveButton(t) {
    if (!this.isInitialized())
      return this;
    const e = this.dragIsBigContainer ?? this.isBigContainer, i = Xi.calcPosition(t, e);
    if (i === this.votButton.position)
      return this;
    const s = Xi.calcDirection(i);
    return this.data.buttonPos = i, this.updateButtonLayout(i, s), this;
  }
  startDragSession(t, e, i) {
    this.dragCandidate = !0, this.dragging = !1, this.dragStartX = t, this.dragStartY = e, this.currentClientX = t, this.containerRect = this.root.getBoundingClientRect(), this.dragIsBigContainer = this.isBigContainer, this.dragDirty = !1, this.intervalIdleChecker.markActivity(i), this.intervalIdleChecker.requestImmediateTick();
  }
  queueDragTick(t) {
    this.dragDirty || (this.dragDirty = !0, this.intervalIdleChecker.markActivity(t), this.intervalIdleChecker.requestImmediateTick());
  }
  updateDragFromMove(t, e, i) {
    if (this.currentClientX = t, !!this.dragCandidate) {
      if (!this.dragging) {
        const s = Math.abs(this.currentClientX - this.dragStartX), o = Math.abs(e - this.dragStartY);
        s + o >= this.dragThresholdPx && (this.dragging = !0);
      }
      this.dragging && this.queueDragTick(i);
    }
  }
  updateButtonOpacity(t) {
    return !this.isInitialized() || !this.votMenu.hidden ? this : (Math.abs(this.votButton.opacity - t) > 0.01 && (this.votButton.opacity = t), this);
  }
  doReleaseUI() {
    this.votButton?.remove(), this.votMenu?.remove(), this.votButtonTooltip?.release();
  }
  doReleaseUIEvents() {
    this.abortController?.abort(), this.abortController = null, this.checkerUnsubscribe?.(), this.checkerUnsubscribe = null, this.onDragEnd(), this.flushDefaultVolumePersist();
    for (const t of Object.values(this.events))
      t.clear();
  }
  release() {
    return this.isInitialized() ? (this.doReleaseUIEvents(), this.doReleaseUI(), this.initialized = !1, this) : this;
  }
  get isBigContainer() {
    const t = this.videoHandler?.video?.getBoundingClientRect?.().width;
    if (typeof t == "number" && Number.isFinite(t))
      return t > Te.BIG_CONTAINER_WIDTH_PX;
    const e = this.videoHandler?.container?.getBoundingClientRect?.().width;
    return typeof e == "number" && Number.isFinite(e) ? e > Te.BIG_CONTAINER_WIDTH_PX : this.root.clientWidth > Te.BIG_CONTAINER_WIDTH_PX;
  }
  get pipButtonVisible() {
    return Cl() && !!this.data.showPiPButton;
  }
};
c(Te, "BIG_CONTAINER_WIDTH_PX", 550);
let Ls = Te;
function wv(n) {
  return n === "left" || n === "right";
}
const Sv = ["default", "top", "left", "right"], Tv = {
  AmazonBot: "amazonbot",
  "Amazon Silk": "amazon_silk",
  "Android Browser": "android",
  BaiduSpider: "baiduspider",
  Bada: "bada",
  BingCrawler: "bingcrawler",
  Brave: "brave",
  BlackBerry: "blackberry",
  "ChatGPT-User": "chatgpt_user",
  Chrome: "chrome",
  ClaudeBot: "claudebot",
  Chromium: "chromium",
  Diffbot: "diffbot",
  DuckDuckBot: "duckduckbot",
  DuckDuckGo: "duckduckgo",
  Electron: "electron",
  Epiphany: "epiphany",
  FacebookExternalHit: "facebookexternalhit",
  Firefox: "firefox",
  Focus: "focus",
  Generic: "generic",
  "Google Search": "google_search",
  Googlebot: "googlebot",
  GPTBot: "gptbot",
  "Internet Explorer": "ie",
  InternetArchiveCrawler: "internetarchivecrawler",
  "K-Meleon": "k_meleon",
  LibreWolf: "librewolf",
  Linespider: "linespider",
  Maxthon: "maxthon",
  "Meta-ExternalAds": "meta_externalads",
  "Meta-ExternalAgent": "meta_externalagent",
  "Meta-ExternalFetcher": "meta_externalfetcher",
  "Meta-WebIndexer": "meta_webindexer",
  "Microsoft Edge": "edge",
  "MZ Browser": "mz",
  "NAVER Whale Browser": "naver",
  "OAI-SearchBot": "oai_searchbot",
  Omgilibot: "omgilibot",
  Opera: "opera",
  "Opera Coast": "opera_coast",
  "Pale Moon": "pale_moon",
  PerplexityBot: "perplexitybot",
  "Perplexity-User": "perplexity_user",
  PhantomJS: "phantomjs",
  PingdomBot: "pingdombot",
  Puffin: "puffin",
  QQ: "qq",
  QQLite: "qqlite",
  QupZilla: "qupzilla",
  Roku: "roku",
  Safari: "safari",
  Sailfish: "sailfish",
  "Samsung Internet for Android": "samsung_internet",
  SlackBot: "slackbot",
  SeaMonkey: "seamonkey",
  Sleipnir: "sleipnir",
  "Sogou Browser": "sogou",
  Swing: "swing",
  Tizen: "tizen",
  "UC Browser": "uc",
  Vivaldi: "vivaldi",
  "WebOS Browser": "webos",
  WeChat: "wechat",
  YahooSlurp: "yahooslurp",
  "Yandex Browser": "yandex",
  YandexBot: "yandexbot",
  YouBot: "youbot"
}, dc = {
  amazonbot: "AmazonBot",
  amazon_silk: "Amazon Silk",
  android: "Android Browser",
  baiduspider: "BaiduSpider",
  bada: "Bada",
  bingcrawler: "BingCrawler",
  blackberry: "BlackBerry",
  brave: "Brave",
  chatgpt_user: "ChatGPT-User",
  chrome: "Chrome",
  claudebot: "ClaudeBot",
  chromium: "Chromium",
  diffbot: "Diffbot",
  duckduckbot: "DuckDuckBot",
  duckduckgo: "DuckDuckGo",
  edge: "Microsoft Edge",
  electron: "Electron",
  epiphany: "Epiphany",
  facebookexternalhit: "FacebookExternalHit",
  firefox: "Firefox",
  focus: "Focus",
  generic: "Generic",
  google_search: "Google Search",
  googlebot: "Googlebot",
  gptbot: "GPTBot",
  ie: "Internet Explorer",
  internetarchivecrawler: "InternetArchiveCrawler",
  k_meleon: "K-Meleon",
  librewolf: "LibreWolf",
  linespider: "Linespider",
  maxthon: "Maxthon",
  meta_externalads: "Meta-ExternalAds",
  meta_externalagent: "Meta-ExternalAgent",
  meta_externalfetcher: "Meta-ExternalFetcher",
  meta_webindexer: "Meta-WebIndexer",
  mz: "MZ Browser",
  naver: "NAVER Whale Browser",
  oai_searchbot: "OAI-SearchBot",
  omgilibot: "Omgilibot",
  opera: "Opera",
  opera_coast: "Opera Coast",
  pale_moon: "Pale Moon",
  perplexitybot: "PerplexityBot",
  perplexity_user: "Perplexity-User",
  phantomjs: "PhantomJS",
  pingdombot: "PingdomBot",
  puffin: "Puffin",
  qq: "QQ Browser",
  qqlite: "QQ Browser Lite",
  qupzilla: "QupZilla",
  roku: "Roku",
  safari: "Safari",
  sailfish: "Sailfish",
  samsung_internet: "Samsung Internet for Android",
  seamonkey: "SeaMonkey",
  slackbot: "SlackBot",
  sleipnir: "Sleipnir",
  sogou: "Sogou Browser",
  swing: "Swing",
  tizen: "Tizen",
  uc: "UC Browser",
  vivaldi: "Vivaldi",
  webos: "WebOS Browser",
  wechat: "WeChat",
  yahooslurp: "YahooSlurp",
  yandex: "Yandex Browser",
  yandexbot: "YandexBot",
  youbot: "YouBot"
}, O = {
  bot: "bot",
  desktop: "desktop",
  mobile: "mobile",
  tablet: "tablet",
  tv: "tv"
}, it = {
  Android: "Android",
  Bada: "Bada",
  BlackBerry: "BlackBerry",
  ChromeOS: "Chrome OS",
  HarmonyOS: "HarmonyOS",
  iOS: "iOS",
  Linux: "Linux",
  MacOS: "macOS",
  PlayStation4: "PlayStation 4",
  Roku: "Roku",
  Tizen: "Tizen",
  WebOS: "WebOS",
  Windows: "Windows",
  WindowsPhone: "Windows Phone"
}, Rt = {
  Blink: "Blink",
  EdgeHTML: "EdgeHTML",
  Gecko: "Gecko",
  Presto: "Presto",
  Trident: "Trident",
  WebKit: "WebKit"
};
class b {
  /**
   * Get first matched item for a string
   * @param {RegExp} regexp
   * @param {String} ua
   * @return {Array|{index: number, input: string}|*|boolean|string}
   */
  static getFirstMatch(t, e) {
    const i = e.match(t);
    return i && i.length > 0 && i[1] || "";
  }
  /**
   * Get second matched item for a string
   * @param regexp
   * @param {String} ua
   * @return {Array|{index: number, input: string}|*|boolean|string}
   */
  static getSecondMatch(t, e) {
    const i = e.match(t);
    return i && i.length > 1 && i[2] || "";
  }
  /**
   * Match a regexp and return a constant or undefined
   * @param {RegExp} regexp
   * @param {String} ua
   * @param {*} _const Any const that will be returned if regexp matches the string
   * @return {*}
   */
  static matchAndReturnConst(t, e, i) {
    if (t.test(e))
      return i;
  }
  static getWindowsVersionName(t) {
    switch (t) {
      case "NT":
        return "NT";
      case "XP":
        return "XP";
      case "NT 5.0":
        return "2000";
      case "NT 5.1":
        return "XP";
      case "NT 5.2":
        return "2003";
      case "NT 6.0":
        return "Vista";
      case "NT 6.1":
        return "7";
      case "NT 6.2":
        return "8";
      case "NT 6.3":
        return "8.1";
      case "NT 10.0":
        return "10";
      default:
        return;
    }
  }
  /**
   * Get macOS version name
   *    10.5 - Leopard
   *    10.6 - Snow Leopard
   *    10.7 - Lion
   *    10.8 - Mountain Lion
   *    10.9 - Mavericks
   *    10.10 - Yosemite
   *    10.11 - El Capitan
   *    10.12 - Sierra
   *    10.13 - High Sierra
   *    10.14 - Mojave
   *    10.15 - Catalina
   *    11 - Big Sur
   *    12 - Monterey
   *    13 - Ventura
   *    14 - Sonoma
   *    15 - Sequoia
   *
   * @example
   *   getMacOSVersionName("10.14") // 'Mojave'
   *
   * @param  {string} version
   * @return {string} versionName
   */
  static getMacOSVersionName(t) {
    const e = t.split(".").splice(0, 2).map((o) => parseInt(o, 10) || 0);
    e.push(0);
    const i = e[0], s = e[1];
    if (i === 10)
      switch (s) {
        case 5:
          return "Leopard";
        case 6:
          return "Snow Leopard";
        case 7:
          return "Lion";
        case 8:
          return "Mountain Lion";
        case 9:
          return "Mavericks";
        case 10:
          return "Yosemite";
        case 11:
          return "El Capitan";
        case 12:
          return "Sierra";
        case 13:
          return "High Sierra";
        case 14:
          return "Mojave";
        case 15:
          return "Catalina";
        default:
          return;
      }
    switch (i) {
      case 11:
        return "Big Sur";
      case 12:
        return "Monterey";
      case 13:
        return "Ventura";
      case 14:
        return "Sonoma";
      case 15:
        return "Sequoia";
      default:
        return;
    }
  }
  /**
   * Get Android version name
   *    1.5 - Cupcake
   *    1.6 - Donut
   *    2.0 - Eclair
   *    2.1 - Eclair
   *    2.2 - Froyo
   *    2.x - Gingerbread
   *    3.x - Honeycomb
   *    4.0 - Ice Cream Sandwich
   *    4.1 - Jelly Bean
   *    4.4 - KitKat
   *    5.x - Lollipop
   *    6.x - Marshmallow
   *    7.x - Nougat
   *    8.x - Oreo
   *    9.x - Pie
   *
   * @example
   *   getAndroidVersionName("7.0") // 'Nougat'
   *
   * @param  {string} version
   * @return {string} versionName
   */
  static getAndroidVersionName(t) {
    const e = t.split(".").splice(0, 2).map((i) => parseInt(i, 10) || 0);
    if (e.push(0), !(e[0] === 1 && e[1] < 5)) {
      if (e[0] === 1 && e[1] < 6) return "Cupcake";
      if (e[0] === 1 && e[1] >= 6) return "Donut";
      if (e[0] === 2 && e[1] < 2) return "Eclair";
      if (e[0] === 2 && e[1] === 2) return "Froyo";
      if (e[0] === 2 && e[1] > 2) return "Gingerbread";
      if (e[0] === 3) return "Honeycomb";
      if (e[0] === 4 && e[1] < 1) return "Ice Cream Sandwich";
      if (e[0] === 4 && e[1] < 4) return "Jelly Bean";
      if (e[0] === 4 && e[1] >= 4) return "KitKat";
      if (e[0] === 5) return "Lollipop";
      if (e[0] === 6) return "Marshmallow";
      if (e[0] === 7) return "Nougat";
      if (e[0] === 8) return "Oreo";
      if (e[0] === 9) return "Pie";
    }
  }
  /**
   * Get version precisions count
   *
   * @example
   *   getVersionPrecision("1.10.3") // 3
   *
   * @param  {string} version
   * @return {number}
   */
  static getVersionPrecision(t) {
    return t.split(".").length;
  }
  /**
   * Calculate browser version weight
   *
   * @example
   *   compareVersions('1.10.2.1',  '1.8.2.1.90')    // 1
   *   compareVersions('1.010.2.1', '1.09.2.1.90');  // 1
   *   compareVersions('1.10.2.1',  '1.10.2.1');     // 0
   *   compareVersions('1.10.2.1',  '1.0800.2');     // -1
   *   compareVersions('1.10.2.1',  '1.10',  true);  // 0
   *
   * @param {String} versionA versions versions to compare
   * @param {String} versionB versions versions to compare
   * @param {boolean} [isLoose] enable loose comparison
   * @return {Number} comparison result: -1 when versionA is lower,
   * 1 when versionA is bigger, 0 when both equal
   */
  /* eslint consistent-return: 1 */
  static compareVersions(t, e, i = !1) {
    const s = b.getVersionPrecision(t), o = b.getVersionPrecision(e);
    let r = Math.max(s, o), a = 0;
    const l = b.map([t, e], (u) => {
      const d = r - b.getVersionPrecision(u), h = u + new Array(d + 1).join(".0");
      return b.map(h.split("."), (f) => new Array(20 - f.length).join("0") + f).reverse();
    });
    for (i && (a = r - Math.min(s, o)), r -= 1; r >= a; ) {
      if (l[0][r] > l[1][r])
        return 1;
      if (l[0][r] === l[1][r]) {
        if (r === a)
          return 0;
        r -= 1;
      } else if (l[0][r] < l[1][r])
        return -1;
    }
  }
  /**
   * Array::map polyfill
   *
   * @param  {Array} arr
   * @param  {Function} iterator
   * @return {Array}
   */
  static map(t, e) {
    const i = [];
    let s;
    if (Array.prototype.map)
      return Array.prototype.map.call(t, e);
    for (s = 0; s < t.length; s += 1)
      i.push(e(t[s]));
    return i;
  }
  /**
   * Array::find polyfill
   *
   * @param  {Array} arr
   * @param  {Function} predicate
   * @return {Array}
   */
  static find(t, e) {
    let i, s;
    if (Array.prototype.find)
      return Array.prototype.find.call(t, e);
    for (i = 0, s = t.length; i < s; i += 1) {
      const o = t[i];
      if (e(o, i))
        return o;
    }
  }
  /**
   * Object::assign polyfill
   *
   * @param  {Object} obj
   * @param  {Object} ...objs
   * @return {Object}
   */
  static assign(t, ...e) {
    const i = t;
    let s, o;
    if (Object.assign)
      return Object.assign(t, ...e);
    for (s = 0, o = e.length; s < o; s += 1) {
      const r = e[s];
      typeof r == "object" && r !== null && Object.keys(r).forEach((l) => {
        i[l] = r[l];
      });
    }
    return t;
  }
  /**
   * Get short version/alias for a browser name
   *
   * @example
   *   getBrowserAlias('Microsoft Edge') // edge
   *
   * @param  {string} browserName
   * @return {string}
   */
  static getBrowserAlias(t) {
    return Tv[t];
  }
  /**
   * Get browser name for a short version/alias
   *
   * @example
   *   getBrowserTypeByAlias('edge') // Microsoft Edge
   *
   * @param  {string} browserAlias
   * @return {string}
   */
  static getBrowserTypeByAlias(t) {
    return dc[t] || "";
  }
}
const D = /version\/(\d+(\.?_?\d+)+)/i, kv = [
  /* GPTBot */
  {
    test: [/gptbot/i],
    describe(n) {
      const t = {
        name: "GPTBot"
      }, e = b.getFirstMatch(/gptbot\/(\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* ChatGPT-User */
  {
    test: [/chatgpt-user/i],
    describe(n) {
      const t = {
        name: "ChatGPT-User"
      }, e = b.getFirstMatch(/chatgpt-user\/(\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* OAI-SearchBot */
  {
    test: [/oai-searchbot/i],
    describe(n) {
      const t = {
        name: "OAI-SearchBot"
      }, e = b.getFirstMatch(/oai-searchbot\/(\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* ClaudeBot */
  {
    test: [/claudebot/i, /claude-web/i, /claude-user/i, /claude-searchbot/i],
    describe(n) {
      const t = {
        name: "ClaudeBot"
      }, e = b.getFirstMatch(/(?:claudebot|claude-web|claude-user|claude-searchbot)\/(\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* Omgilibot */
  {
    test: [/omgilibot/i, /webzio-extended/i],
    describe(n) {
      const t = {
        name: "Omgilibot"
      }, e = b.getFirstMatch(/(?:omgilibot|webzio-extended)\/(\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* Diffbot */
  {
    test: [/diffbot/i],
    describe(n) {
      const t = {
        name: "Diffbot"
      }, e = b.getFirstMatch(/diffbot\/(\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* PerplexityBot */
  {
    test: [/perplexitybot/i],
    describe(n) {
      const t = {
        name: "PerplexityBot"
      }, e = b.getFirstMatch(/perplexitybot\/(\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* Perplexity-User */
  {
    test: [/perplexity-user/i],
    describe(n) {
      const t = {
        name: "Perplexity-User"
      }, e = b.getFirstMatch(/perplexity-user\/(\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* YouBot */
  {
    test: [/youbot/i],
    describe(n) {
      const t = {
        name: "YouBot"
      }, e = b.getFirstMatch(/youbot\/(\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* Meta-WebIndexer */
  {
    test: [/meta-webindexer/i],
    describe(n) {
      const t = {
        name: "Meta-WebIndexer"
      }, e = b.getFirstMatch(/meta-webindexer\/(\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* Meta-ExternalAds */
  {
    test: [/meta-externalads/i],
    describe(n) {
      const t = {
        name: "Meta-ExternalAds"
      }, e = b.getFirstMatch(/meta-externalads\/(\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* Meta-ExternalAgent */
  {
    test: [/meta-externalagent/i],
    describe(n) {
      const t = {
        name: "Meta-ExternalAgent"
      }, e = b.getFirstMatch(/meta-externalagent\/(\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* Meta-ExternalFetcher */
  {
    test: [/meta-externalfetcher/i],
    describe(n) {
      const t = {
        name: "Meta-ExternalFetcher"
      }, e = b.getFirstMatch(/meta-externalfetcher\/(\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* Googlebot */
  {
    test: [/googlebot/i],
    describe(n) {
      const t = {
        name: "Googlebot"
      }, e = b.getFirstMatch(/googlebot\/(\d+(\.\d+))/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* Linespider */
  {
    test: [/linespider/i],
    describe(n) {
      const t = {
        name: "Linespider"
      }, e = b.getFirstMatch(/(?:linespider)(?:-[-\w]+)?[\s/](\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* AmazonBot */
  {
    test: [/amazonbot/i],
    describe(n) {
      const t = {
        name: "AmazonBot"
      }, e = b.getFirstMatch(/amazonbot\/(\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* BingCrawler */
  {
    test: [/bingbot/i],
    describe(n) {
      const t = {
        name: "BingCrawler"
      }, e = b.getFirstMatch(/bingbot\/(\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* BaiduSpider */
  {
    test: [/baiduspider/i],
    describe(n) {
      const t = {
        name: "BaiduSpider"
      }, e = b.getFirstMatch(/baiduspider\/(\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* DuckDuckBot */
  {
    test: [/duckduckbot/i],
    describe(n) {
      const t = {
        name: "DuckDuckBot"
      }, e = b.getFirstMatch(/duckduckbot\/(\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* InternetArchiveCrawler */
  {
    test: [/ia_archiver/i],
    describe(n) {
      const t = {
        name: "InternetArchiveCrawler"
      }, e = b.getFirstMatch(/ia_archiver\/(\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* FacebookExternalHit */
  {
    test: [/facebookexternalhit/i, /facebookcatalog/i],
    describe() {
      return {
        name: "FacebookExternalHit"
      };
    }
  },
  /* SlackBot */
  {
    test: [/slackbot/i, /slack-imgProxy/i],
    describe(n) {
      const t = {
        name: "SlackBot"
      }, e = b.getFirstMatch(/(?:slackbot|slack-imgproxy)(?:-[-\w]+)?[\s/](\d+(\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* YahooSlurp */
  {
    test: [/yahoo!?[\s/]*slurp/i],
    describe() {
      return {
        name: "YahooSlurp"
      };
    }
  },
  /* YandexBot */
  {
    test: [/yandexbot/i, /yandexmobilebot/i],
    describe() {
      return {
        name: "YandexBot"
      };
    }
  },
  /* PingdomBot */
  {
    test: [/pingdom/i],
    describe() {
      return {
        name: "PingdomBot"
      };
    }
  },
  /* Opera < 13.0 */
  {
    test: [/opera/i],
    describe(n) {
      const t = {
        name: "Opera"
      }, e = b.getFirstMatch(D, n) || b.getFirstMatch(/(?:opera)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  /* Opera > 13.0 */
  {
    test: [/opr\/|opios/i],
    describe(n) {
      const t = {
        name: "Opera"
      }, e = b.getFirstMatch(/(?:opr|opios)[\s/](\S+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/SamsungBrowser/i],
    describe(n) {
      const t = {
        name: "Samsung Internet for Android"
      }, e = b.getFirstMatch(D, n) || b.getFirstMatch(/(?:SamsungBrowser)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/Whale/i],
    describe(n) {
      const t = {
        name: "NAVER Whale Browser"
      }, e = b.getFirstMatch(D, n) || b.getFirstMatch(/(?:whale)[\s/](\d+(?:\.\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/PaleMoon/i],
    describe(n) {
      const t = {
        name: "Pale Moon"
      }, e = b.getFirstMatch(D, n) || b.getFirstMatch(/(?:PaleMoon)[\s/](\d+(?:\.\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/MZBrowser/i],
    describe(n) {
      const t = {
        name: "MZ Browser"
      }, e = b.getFirstMatch(/(?:MZBrowser)[\s/](\d+(?:\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/focus/i],
    describe(n) {
      const t = {
        name: "Focus"
      }, e = b.getFirstMatch(/(?:focus)[\s/](\d+(?:\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/swing/i],
    describe(n) {
      const t = {
        name: "Swing"
      }, e = b.getFirstMatch(/(?:swing)[\s/](\d+(?:\.\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/coast/i],
    describe(n) {
      const t = {
        name: "Opera Coast"
      }, e = b.getFirstMatch(D, n) || b.getFirstMatch(/(?:coast)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/opt\/\d+(?:.?_?\d+)+/i],
    describe(n) {
      const t = {
        name: "Opera Touch"
      }, e = b.getFirstMatch(/(?:opt)[\s/](\d+(\.?_?\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/yabrowser/i],
    describe(n) {
      const t = {
        name: "Yandex Browser"
      }, e = b.getFirstMatch(/(?:yabrowser)[\s/](\d+(\.?_?\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/ucbrowser/i],
    describe(n) {
      const t = {
        name: "UC Browser"
      }, e = b.getFirstMatch(D, n) || b.getFirstMatch(/(?:ucbrowser)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/Maxthon|mxios/i],
    describe(n) {
      const t = {
        name: "Maxthon"
      }, e = b.getFirstMatch(D, n) || b.getFirstMatch(/(?:Maxthon|mxios)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/epiphany/i],
    describe(n) {
      const t = {
        name: "Epiphany"
      }, e = b.getFirstMatch(D, n) || b.getFirstMatch(/(?:epiphany)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/puffin/i],
    describe(n) {
      const t = {
        name: "Puffin"
      }, e = b.getFirstMatch(D, n) || b.getFirstMatch(/(?:puffin)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/sleipnir/i],
    describe(n) {
      const t = {
        name: "Sleipnir"
      }, e = b.getFirstMatch(D, n) || b.getFirstMatch(/(?:sleipnir)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/k-meleon/i],
    describe(n) {
      const t = {
        name: "K-Meleon"
      }, e = b.getFirstMatch(D, n) || b.getFirstMatch(/(?:k-meleon)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/micromessenger/i],
    describe(n) {
      const t = {
        name: "WeChat"
      }, e = b.getFirstMatch(/(?:micromessenger)[\s/](\d+(\.?_?\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/qqbrowser/i],
    describe(n) {
      const t = {
        name: /qqbrowserlite/i.test(n) ? "QQ Browser Lite" : "QQ Browser"
      }, e = b.getFirstMatch(/(?:qqbrowserlite|qqbrowser)[/](\d+(\.?_?\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/msie|trident/i],
    describe(n) {
      const t = {
        name: "Internet Explorer"
      }, e = b.getFirstMatch(/(?:msie |rv:)(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/\sedg\//i],
    describe(n) {
      const t = {
        name: "Microsoft Edge"
      }, e = b.getFirstMatch(/\sedg\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/edg([ea]|ios)/i],
    describe(n) {
      const t = {
        name: "Microsoft Edge"
      }, e = b.getSecondMatch(/edg([ea]|ios)\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/vivaldi/i],
    describe(n) {
      const t = {
        name: "Vivaldi"
      }, e = b.getFirstMatch(/vivaldi\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/seamonkey/i],
    describe(n) {
      const t = {
        name: "SeaMonkey"
      }, e = b.getFirstMatch(/seamonkey\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/sailfish/i],
    describe(n) {
      const t = {
        name: "Sailfish"
      }, e = b.getFirstMatch(/sailfish\s?browser\/(\d+(\.\d+)?)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/silk/i],
    describe(n) {
      const t = {
        name: "Amazon Silk"
      }, e = b.getFirstMatch(/silk\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/phantom/i],
    describe(n) {
      const t = {
        name: "PhantomJS"
      }, e = b.getFirstMatch(/phantomjs\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/slimerjs/i],
    describe(n) {
      const t = {
        name: "SlimerJS"
      }, e = b.getFirstMatch(/slimerjs\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/blackberry|\bbb\d+/i, /rim\stablet/i],
    describe(n) {
      const t = {
        name: "BlackBerry"
      }, e = b.getFirstMatch(D, n) || b.getFirstMatch(/blackberry[\d]+\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/(web|hpw)[o0]s/i],
    describe(n) {
      const t = {
        name: "WebOS Browser"
      }, e = b.getFirstMatch(D, n) || b.getFirstMatch(/w(?:eb)?[o0]sbrowser\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/bada/i],
    describe(n) {
      const t = {
        name: "Bada"
      }, e = b.getFirstMatch(/dolfin\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/tizen/i],
    describe(n) {
      const t = {
        name: "Tizen"
      }, e = b.getFirstMatch(/(?:tizen\s?)?browser\/(\d+(\.?_?\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/qupzilla/i],
    describe(n) {
      const t = {
        name: "QupZilla"
      }, e = b.getFirstMatch(/(?:qupzilla)[\s/](\d+(\.?_?\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/librewolf/i],
    describe(n) {
      const t = {
        name: "LibreWolf"
      }, e = b.getFirstMatch(/(?:librewolf)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/firefox|iceweasel|fxios/i],
    describe(n) {
      const t = {
        name: "Firefox"
      }, e = b.getFirstMatch(/(?:firefox|iceweasel|fxios)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/electron/i],
    describe(n) {
      const t = {
        name: "Electron"
      }, e = b.getFirstMatch(/(?:electron)\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/sogoumobilebrowser/i, /metasr/i, /se 2\.[x]/i],
    describe(n) {
      const t = {
        name: "Sogou Browser"
      }, e = b.getFirstMatch(/(?:sogoumobilebrowser)[\s/](\d+(\.?_?\d+)+)/i, n), i = b.getFirstMatch(/(?:chrome|crios|crmo)\/(\d+(\.?_?\d+)+)/i, n), s = b.getFirstMatch(/se ([\d.]+)x/i, n), o = e || i || s;
      return o && (t.version = o), t;
    }
  },
  {
    test: [/MiuiBrowser/i],
    describe(n) {
      const t = {
        name: "Miui"
      }, e = b.getFirstMatch(/(?:MiuiBrowser)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  /* DuckDuckGo Browser */
  {
    test(n) {
      return n.hasBrand("DuckDuckGo") ? !0 : n.test(/\sDdg\/[\d.]+$/i);
    },
    describe(n, t) {
      const e = {
        name: "DuckDuckGo"
      };
      if (t) {
        const s = t.getBrandVersion("DuckDuckGo");
        if (s)
          return e.version = s, e;
      }
      const i = b.getFirstMatch(/\sDdg\/([\d.]+)$/i, n);
      return i && (e.version = i), e;
    }
  },
  /* Brave Browser */
  {
    test(n) {
      return n.hasBrand("Brave");
    },
    describe(n, t) {
      const e = {
        name: "Brave"
      };
      if (t) {
        const i = t.getBrandVersion("Brave");
        if (i)
          return e.version = i, e;
      }
      return e;
    }
  },
  {
    test: [/chromium/i],
    describe(n) {
      const t = {
        name: "Chromium"
      }, e = b.getFirstMatch(/(?:chromium)[\s/](\d+(\.?_?\d+)+)/i, n) || b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/chrome|crios|crmo/i],
    describe(n) {
      const t = {
        name: "Chrome"
      }, e = b.getFirstMatch(/(?:chrome|crios|crmo)\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/GSA/i],
    describe(n) {
      const t = {
        name: "Google Search"
      }, e = b.getFirstMatch(/(?:GSA)\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  /* Android Browser */
  {
    test(n) {
      const t = !n.test(/like android/i), e = n.test(/android/i);
      return t && e;
    },
    describe(n) {
      const t = {
        name: "Android Browser"
      }, e = b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* PlayStation 4 */
  {
    test: [/playstation 4/i],
    describe(n) {
      const t = {
        name: "PlayStation 4"
      }, e = b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* Safari */
  {
    test: [/safari|applewebkit/i],
    describe(n) {
      const t = {
        name: "Safari"
      }, e = b.getFirstMatch(D, n);
      return e && (t.version = e), t;
    }
  },
  /* Something else */
  {
    test: [/.*/i],
    describe(n) {
      const t = /^(.*)\/(.*) /, e = /^(.*)\/(.*)[ \t]\((.*)/, s = n.search("\\(") !== -1 ? e : t;
      return {
        name: b.getFirstMatch(s, n),
        version: b.getSecondMatch(s, n)
      };
    }
  }
], Lv = [
  /* Roku */
  {
    test: [/Roku\/DVP/],
    describe(n) {
      const t = b.getFirstMatch(/Roku\/DVP-(\d+\.\d+)/i, n);
      return {
        name: it.Roku,
        version: t
      };
    }
  },
  /* Windows Phone */
  {
    test: [/windows phone/i],
    describe(n) {
      const t = b.getFirstMatch(/windows phone (?:os)?\s?(\d+(\.\d+)*)/i, n);
      return {
        name: it.WindowsPhone,
        version: t
      };
    }
  },
  /* Windows */
  {
    test: [/windows /i],
    describe(n) {
      const t = b.getFirstMatch(/Windows ((NT|XP)( \d\d?.\d)?)/i, n), e = b.getWindowsVersionName(t);
      return {
        name: it.Windows,
        version: t,
        versionName: e
      };
    }
  },
  /* Firefox on iPad */
  {
    test: [/Macintosh(.*?) FxiOS(.*?)\//],
    describe(n) {
      const t = {
        name: it.iOS
      }, e = b.getSecondMatch(/(Version\/)(\d[\d.]+)/, n);
      return e && (t.version = e), t;
    }
  },
  /* macOS */
  {
    test: [/macintosh/i],
    describe(n) {
      const t = b.getFirstMatch(/mac os x (\d+(\.?_?\d+)+)/i, n).replace(/[_\s]/g, "."), e = b.getMacOSVersionName(t), i = {
        name: it.MacOS,
        version: t
      };
      return e && (i.versionName = e), i;
    }
  },
  /* iOS */
  {
    test: [/(ipod|iphone|ipad)/i],
    describe(n) {
      const t = b.getFirstMatch(/os (\d+([_\s]\d+)*) like mac os x/i, n).replace(/[_\s]/g, ".");
      return {
        name: it.iOS,
        version: t
      };
    }
  },
  /* HarmonyOS */
  {
    test: [/OpenHarmony/i],
    describe(n) {
      const t = b.getFirstMatch(/OpenHarmony\s+(\d+(\.\d+)*)/i, n);
      return {
        name: it.HarmonyOS,
        version: t
      };
    }
  },
  /* Android */
  {
    test(n) {
      const t = !n.test(/like android/i), e = n.test(/android/i);
      return t && e;
    },
    describe(n) {
      const t = b.getFirstMatch(/android[\s/-](\d+(\.\d+)*)/i, n), e = b.getAndroidVersionName(t), i = {
        name: it.Android,
        version: t
      };
      return e && (i.versionName = e), i;
    }
  },
  /* WebOS */
  {
    test: [/(web|hpw)[o0]s/i],
    describe(n) {
      const t = b.getFirstMatch(/(?:web|hpw)[o0]s\/(\d+(\.\d+)*)/i, n), e = {
        name: it.WebOS
      };
      return t && t.length && (e.version = t), e;
    }
  },
  /* BlackBerry */
  {
    test: [/blackberry|\bbb\d+/i, /rim\stablet/i],
    describe(n) {
      const t = b.getFirstMatch(/rim\stablet\sos\s(\d+(\.\d+)*)/i, n) || b.getFirstMatch(/blackberry\d+\/(\d+([_\s]\d+)*)/i, n) || b.getFirstMatch(/\bbb(\d+)/i, n);
      return {
        name: it.BlackBerry,
        version: t
      };
    }
  },
  /* Bada */
  {
    test: [/bada/i],
    describe(n) {
      const t = b.getFirstMatch(/bada\/(\d+(\.\d+)*)/i, n);
      return {
        name: it.Bada,
        version: t
      };
    }
  },
  /* Tizen */
  {
    test: [/tizen/i],
    describe(n) {
      const t = b.getFirstMatch(/tizen[/\s](\d+(\.\d+)*)/i, n);
      return {
        name: it.Tizen,
        version: t
      };
    }
  },
  /* Linux */
  {
    test: [/linux/i],
    describe() {
      return {
        name: it.Linux
      };
    }
  },
  /* Chrome OS */
  {
    test: [/CrOS/],
    describe() {
      return {
        name: it.ChromeOS
      };
    }
  },
  /* Playstation 4 */
  {
    test: [/PlayStation 4/],
    describe(n) {
      const t = b.getFirstMatch(/PlayStation 4[/\s](\d+(\.\d+)*)/i, n);
      return {
        name: it.PlayStation4,
        version: t
      };
    }
  }
], xv = [
  /* Googlebot */
  {
    test: [/googlebot/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Google"
      };
    }
  },
  /* LineSpider */
  {
    test: [/linespider/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Line"
      };
    }
  },
  /* AmazonBot */
  {
    test: [/amazonbot/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Amazon"
      };
    }
  },
  /* GPTBot */
  {
    test: [/gptbot/i],
    describe() {
      return {
        type: O.bot,
        vendor: "OpenAI"
      };
    }
  },
  /* ChatGPT-User */
  {
    test: [/chatgpt-user/i],
    describe() {
      return {
        type: O.bot,
        vendor: "OpenAI"
      };
    }
  },
  /* OAI-SearchBot */
  {
    test: [/oai-searchbot/i],
    describe() {
      return {
        type: O.bot,
        vendor: "OpenAI"
      };
    }
  },
  /* Baidu */
  {
    test: [/baiduspider/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Baidu"
      };
    }
  },
  /* Bingbot */
  {
    test: [/bingbot/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Bing"
      };
    }
  },
  /* DuckDuckBot */
  {
    test: [/duckduckbot/i],
    describe() {
      return {
        type: O.bot,
        vendor: "DuckDuckGo"
      };
    }
  },
  /* ClaudeBot */
  {
    test: [/claudebot/i, /claude-web/i, /claude-user/i, /claude-searchbot/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Anthropic"
      };
    }
  },
  /* Omgilibot */
  {
    test: [/omgilibot/i, /webzio-extended/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Webz.io"
      };
    }
  },
  /* Diffbot */
  {
    test: [/diffbot/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Diffbot"
      };
    }
  },
  /* PerplexityBot */
  {
    test: [/perplexitybot/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Perplexity AI"
      };
    }
  },
  /* Perplexity-User */
  {
    test: [/perplexity-user/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Perplexity AI"
      };
    }
  },
  /* YouBot */
  {
    test: [/youbot/i],
    describe() {
      return {
        type: O.bot,
        vendor: "You.com"
      };
    }
  },
  /* Internet Archive Crawler */
  {
    test: [/ia_archiver/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Internet Archive"
      };
    }
  },
  /* Meta-WebIndexer */
  {
    test: [/meta-webindexer/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Meta"
      };
    }
  },
  /* Meta-ExternalAds */
  {
    test: [/meta-externalads/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Meta"
      };
    }
  },
  /* Meta-ExternalAgent */
  {
    test: [/meta-externalagent/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Meta"
      };
    }
  },
  /* Meta-ExternalFetcher */
  {
    test: [/meta-externalfetcher/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Meta"
      };
    }
  },
  /* Meta Web Crawler */
  {
    test: [/facebookexternalhit/i, /facebookcatalog/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Meta"
      };
    }
  },
  /* SlackBot */
  {
    test: [/slackbot/i, /slack-imgProxy/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Slack"
      };
    }
  },
  /* Yahoo! Slurp */
  {
    test: [/yahoo/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Yahoo"
      };
    }
  },
  /* Yandex */
  {
    test: [/yandexbot/i, /yandexmobilebot/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Yandex"
      };
    }
  },
  /* Pingdom */
  {
    test: [/pingdom/i],
    describe() {
      return {
        type: O.bot,
        vendor: "Pingdom"
      };
    }
  },
  /* Huawei */
  {
    test: [/huawei/i],
    describe(n) {
      const t = b.getFirstMatch(/(can-l01)/i, n) && "Nova", e = {
        type: O.mobile,
        vendor: "Huawei"
      };
      return t && (e.model = t), e;
    }
  },
  /* Nexus Tablet */
  {
    test: [/nexus\s*(?:7|8|9|10).*/i],
    describe() {
      return {
        type: O.tablet,
        vendor: "Nexus"
      };
    }
  },
  /* iPad */
  {
    test: [/ipad/i],
    describe() {
      return {
        type: O.tablet,
        vendor: "Apple",
        model: "iPad"
      };
    }
  },
  /* Firefox on iPad */
  {
    test: [/Macintosh(.*?) FxiOS(.*?)\//],
    describe() {
      return {
        type: O.tablet,
        vendor: "Apple",
        model: "iPad"
      };
    }
  },
  /* Amazon Kindle Fire */
  {
    test: [/kftt build/i],
    describe() {
      return {
        type: O.tablet,
        vendor: "Amazon",
        model: "Kindle Fire HD 7"
      };
    }
  },
  /* Another Amazon Tablet with Silk */
  {
    test: [/silk/i],
    describe() {
      return {
        type: O.tablet,
        vendor: "Amazon"
      };
    }
  },
  /* Tablet */
  {
    test: [/tablet(?! pc)/i],
    describe() {
      return {
        type: O.tablet
      };
    }
  },
  /* iPod/iPhone */
  {
    test(n) {
      const t = n.test(/ipod|iphone/i), e = n.test(/like (ipod|iphone)/i);
      return t && !e;
    },
    describe(n) {
      const t = b.getFirstMatch(/(ipod|iphone)/i, n);
      return {
        type: O.mobile,
        vendor: "Apple",
        model: t
      };
    }
  },
  /* Nexus Mobile */
  {
    test: [/nexus\s*[0-6].*/i, /galaxy nexus/i],
    describe() {
      return {
        type: O.mobile,
        vendor: "Nexus"
      };
    }
  },
  /* Nokia */
  {
    test: [/Nokia/i],
    describe(n) {
      const t = b.getFirstMatch(/Nokia\s+([0-9]+(\.[0-9]+)?)/i, n), e = {
        type: O.mobile,
        vendor: "Nokia"
      };
      return t && (e.model = t), e;
    }
  },
  /* Mobile */
  {
    test: [/[^-]mobi/i],
    describe() {
      return {
        type: O.mobile
      };
    }
  },
  /* BlackBerry */
  {
    test(n) {
      return n.getBrowserName(!0) === "blackberry";
    },
    describe() {
      return {
        type: O.mobile,
        vendor: "BlackBerry"
      };
    }
  },
  /* Bada */
  {
    test(n) {
      return n.getBrowserName(!0) === "bada";
    },
    describe() {
      return {
        type: O.mobile
      };
    }
  },
  /* Windows Phone */
  {
    test(n) {
      return n.getBrowserName() === "windows phone";
    },
    describe() {
      return {
        type: O.mobile,
        vendor: "Microsoft"
      };
    }
  },
  /* Android Tablet */
  {
    test(n) {
      const t = Number(String(n.getOSVersion()).split(".")[0]);
      return n.getOSName(!0) === "android" && t >= 3;
    },
    describe() {
      return {
        type: O.tablet
      };
    }
  },
  /* Android Mobile */
  {
    test(n) {
      return n.getOSName(!0) === "android";
    },
    describe() {
      return {
        type: O.mobile
      };
    }
  },
  /* Smart TV */
  {
    test: [/smart-?tv|smarttv/i],
    describe() {
      return {
        type: O.tv
      };
    }
  },
  /* NetCast (LG Smart TV) */
  {
    test: [/netcast/i],
    describe() {
      return {
        type: O.tv
      };
    }
  },
  /* desktop */
  {
    test(n) {
      return n.getOSName(!0) === "macos";
    },
    describe() {
      return {
        type: O.desktop,
        vendor: "Apple"
      };
    }
  },
  /* Windows */
  {
    test(n) {
      return n.getOSName(!0) === "windows";
    },
    describe() {
      return {
        type: O.desktop
      };
    }
  },
  /* Linux */
  {
    test(n) {
      return n.getOSName(!0) === "linux";
    },
    describe() {
      return {
        type: O.desktop
      };
    }
  },
  /* PlayStation 4 */
  {
    test(n) {
      return n.getOSName(!0) === "playstation 4";
    },
    describe() {
      return {
        type: O.tv
      };
    }
  },
  /* Roku */
  {
    test(n) {
      return n.getOSName(!0) === "roku";
    },
    describe() {
      return {
        type: O.tv
      };
    }
  }
], Av = [
  /* EdgeHTML */
  {
    test(n) {
      return n.getBrowserName(!0) === "microsoft edge";
    },
    describe(n) {
      if (/\sedg\//i.test(n))
        return {
          name: Rt.Blink
        };
      const e = b.getFirstMatch(/edge\/(\d+(\.?_?\d+)+)/i, n);
      return {
        name: Rt.EdgeHTML,
        version: e
      };
    }
  },
  /* Trident */
  {
    test: [/trident/i],
    describe(n) {
      const t = {
        name: Rt.Trident
      }, e = b.getFirstMatch(/trident\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  /* Presto */
  {
    test(n) {
      return n.test(/presto/i);
    },
    describe(n) {
      const t = {
        name: Rt.Presto
      }, e = b.getFirstMatch(/presto\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  /* Gecko */
  {
    test(n) {
      const t = n.test(/gecko/i), e = n.test(/like gecko/i);
      return t && !e;
    },
    describe(n) {
      const t = {
        name: Rt.Gecko
      }, e = b.getFirstMatch(/gecko\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  /* Blink */
  {
    test: [/(apple)?webkit\/537\.36/i],
    describe() {
      return {
        name: Rt.Blink
      };
    }
  },
  /* WebKit */
  {
    test: [/(apple)?webkit/i],
    describe(n) {
      const t = {
        name: Rt.WebKit
      }, e = b.getFirstMatch(/webkit\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  }
];
class La {
  /**
   * Create instance of Parser
   *
   * @param {String} UA User-Agent string
   * @param {Boolean|ClientHints} [skipParsingOrHints=false] Either a boolean to skip parsing,
   * or a ClientHints object containing User-Agent Client Hints data
   * @param {ClientHints} [clientHints] User-Agent Client Hints data (navigator.userAgentData)
   *
   * @throw {Error} in case of empty UA String
   *
   * @constructor
   */
  constructor(t, e = !1, i = null) {
    if (t == null || t === "")
      throw new Error("UserAgent parameter can't be empty");
    this._ua = t;
    let s = !1;
    typeof e == "boolean" ? (s = e, this._hints = i) : e != null && typeof e == "object" ? this._hints = e : this._hints = null, this.parsedResult = {}, s !== !0 && this.parse();
  }
  /**
   * Get Client Hints data
   * @return {ClientHints|null}
   *
   * @public
   * @example
   * const parser = Bowser.getParser(UA, clientHints);
   * const hints = parser.getHints();
   * console.log(hints.platform); // 'Windows'
   * console.log(hints.mobile); // false
   */
  getHints() {
    return this._hints;
  }
  /**
   * Check if a brand exists in Client Hints brands array
   * @param {string} brandName The brand name to check for
   * @return {boolean}
   *
   * @public
   * @example
   * const parser = Bowser.getParser(UA, clientHints);
   * if (parser.hasBrand('Google Chrome')) {
   *   console.log('Chrome detected!');
   * }
   */
  hasBrand(t) {
    if (!this._hints || !Array.isArray(this._hints.brands))
      return !1;
    const e = t.toLowerCase();
    return this._hints.brands.some(
      (i) => i.brand && i.brand.toLowerCase() === e
    );
  }
  /**
   * Get brand version from Client Hints
   * @param {string} brandName The brand name to get version for
   * @return {string|undefined}
   *
   * @public
   * @example
   * const parser = Bowser.getParser(UA, clientHints);
   * const version = parser.getBrandVersion('Google Chrome');
   * console.log(version); // '131'
   */
  getBrandVersion(t) {
    if (!this._hints || !Array.isArray(this._hints.brands))
      return;
    const e = t.toLowerCase(), i = this._hints.brands.find(
      (s) => s.brand && s.brand.toLowerCase() === e
    );
    return i ? i.version : void 0;
  }
  /**
   * Get UserAgent string of current Parser instance
   * @return {String} User-Agent String of the current <Parser> object
   *
   * @public
   */
  getUA() {
    return this._ua;
  }
  /**
   * Test a UA string for a regexp
   * @param {RegExp} regex
   * @return {Boolean}
   */
  test(t) {
    return t.test(this._ua);
  }
  /**
   * Get parsed browser object
   * @return {Object}
   */
  parseBrowser() {
    this.parsedResult.browser = {};
    const t = b.find(kv, (e) => {
      if (typeof e.test == "function")
        return e.test(this);
      if (Array.isArray(e.test))
        return e.test.some((i) => this.test(i));
      throw new Error("Browser's test function is not valid");
    });
    return t && (this.parsedResult.browser = t.describe(this.getUA(), this)), this.parsedResult.browser;
  }
  /**
   * Get parsed browser object
   * @return {Object}
   *
   * @public
   */
  getBrowser() {
    return this.parsedResult.browser ? this.parsedResult.browser : this.parseBrowser();
  }
  /**
   * Get browser's name
   * @return {String} Browser's name or an empty string
   *
   * @public
   */
  getBrowserName(t) {
    return t ? String(this.getBrowser().name).toLowerCase() || "" : this.getBrowser().name || "";
  }
  /**
   * Get browser's version
   * @return {String} version of browser
   *
   * @public
   */
  getBrowserVersion() {
    return this.getBrowser().version;
  }
  /**
   * Get OS
   * @return {Object}
   *
   * @example
   * this.getOS();
   * {
   *   name: 'macOS',
   *   version: '10.11.12'
   * }
   */
  getOS() {
    return this.parsedResult.os ? this.parsedResult.os : this.parseOS();
  }
  /**
   * Parse OS and save it to this.parsedResult.os
   * @return {*|{}}
   */
  parseOS() {
    this.parsedResult.os = {};
    const t = b.find(Lv, (e) => {
      if (typeof e.test == "function")
        return e.test(this);
      if (Array.isArray(e.test))
        return e.test.some((i) => this.test(i));
      throw new Error("Browser's test function is not valid");
    });
    return t && (this.parsedResult.os = t.describe(this.getUA())), this.parsedResult.os;
  }
  /**
   * Get OS name
   * @param {Boolean} [toLowerCase] return lower-cased value
   * @return {String} name of the OS — macOS, Windows, Linux, etc.
   */
  getOSName(t) {
    const { name: e } = this.getOS();
    return t ? String(e).toLowerCase() || "" : e || "";
  }
  /**
   * Get OS version
   * @return {String} full version with dots ('10.11.12', '5.6', etc)
   */
  getOSVersion() {
    return this.getOS().version;
  }
  /**
   * Get parsed platform
   * @return {{}}
   */
  getPlatform() {
    return this.parsedResult.platform ? this.parsedResult.platform : this.parsePlatform();
  }
  /**
   * Get platform name
   * @param {Boolean} [toLowerCase=false]
   * @return {*}
   */
  getPlatformType(t = !1) {
    const { type: e } = this.getPlatform();
    return t ? String(e).toLowerCase() || "" : e || "";
  }
  /**
   * Get parsed platform
   * @return {{}}
   */
  parsePlatform() {
    this.parsedResult.platform = {};
    const t = b.find(xv, (e) => {
      if (typeof e.test == "function")
        return e.test(this);
      if (Array.isArray(e.test))
        return e.test.some((i) => this.test(i));
      throw new Error("Browser's test function is not valid");
    });
    return t && (this.parsedResult.platform = t.describe(this.getUA())), this.parsedResult.platform;
  }
  /**
   * Get parsed engine
   * @return {{}}
   */
  getEngine() {
    return this.parsedResult.engine ? this.parsedResult.engine : this.parseEngine();
  }
  /**
   * Get engines's name
   * @return {String} Engines's name or an empty string
   *
   * @public
   */
  getEngineName(t) {
    return t ? String(this.getEngine().name).toLowerCase() || "" : this.getEngine().name || "";
  }
  /**
   * Get parsed platform
   * @return {{}}
   */
  parseEngine() {
    this.parsedResult.engine = {};
    const t = b.find(Av, (e) => {
      if (typeof e.test == "function")
        return e.test(this);
      if (Array.isArray(e.test))
        return e.test.some((i) => this.test(i));
      throw new Error("Browser's test function is not valid");
    });
    return t && (this.parsedResult.engine = t.describe(this.getUA())), this.parsedResult.engine;
  }
  /**
   * Parse full information about the browser
   * @returns {Parser}
   */
  parse() {
    return this.parseBrowser(), this.parseOS(), this.parsePlatform(), this.parseEngine(), this;
  }
  /**
   * Get parsed result
   * @return {ParsedResult}
   */
  getResult() {
    return b.assign({}, this.parsedResult);
  }
  /**
   * Check if parsed browser matches certain conditions
   *
   * @param {Object} checkTree It's one or two layered object,
   * which can include a platform or an OS on the first layer
   * and should have browsers specs on the bottom-laying layer
   *
   * @returns {Boolean|undefined} Whether the browser satisfies the set conditions or not.
   * Returns `undefined` when the browser is no described in the checkTree object.
   *
   * @example
   * const browser = Bowser.getParser(window.navigator.userAgent);
   * if (browser.satisfies({chrome: '>118.01.1322' }))
   * // or with os
   * if (browser.satisfies({windows: { chrome: '>118.01.1322' } }))
   * // or with platforms
   * if (browser.satisfies({desktop: { chrome: '>118.01.1322' } }))
   */
  satisfies(t) {
    const e = {};
    let i = 0;
    const s = {};
    let o = 0;
    if (Object.keys(t).forEach((a) => {
      const l = t[a];
      typeof l == "string" ? (s[a] = l, o += 1) : typeof l == "object" && (e[a] = l, i += 1);
    }), i > 0) {
      const a = Object.keys(e), l = b.find(a, (d) => this.isOS(d));
      if (l) {
        const d = this.satisfies(e[l]);
        if (d !== void 0)
          return d;
      }
      const u = b.find(
        a,
        (d) => this.isPlatform(d)
      );
      if (u) {
        const d = this.satisfies(e[u]);
        if (d !== void 0)
          return d;
      }
    }
    if (o > 0) {
      const a = Object.keys(s), l = b.find(a, (u) => this.isBrowser(u, !0));
      if (l !== void 0)
        return this.compareVersion(s[l]);
    }
  }
  /**
   * Check if the browser name equals the passed string
   * @param {string} browserName The string to compare with the browser name
   * @param [includingAlias=false] The flag showing whether alias will be included into comparison
   * @returns {boolean}
   */
  isBrowser(t, e = !1) {
    const i = this.getBrowserName().toLowerCase();
    let s = t.toLowerCase();
    const o = b.getBrowserTypeByAlias(s);
    return e && o && (s = o.toLowerCase()), s === i;
  }
  compareVersion(t) {
    let e = [0], i = t, s = !1;
    const o = this.getBrowserVersion();
    if (typeof o == "string")
      return t[0] === ">" || t[0] === "<" ? (i = t.substr(1), t[1] === "=" ? (s = !0, i = t.substr(2)) : e = [], t[0] === ">" ? e.push(1) : e.push(-1)) : t[0] === "=" ? i = t.substr(1) : t[0] === "~" && (s = !0, i = t.substr(1)), e.indexOf(
        b.compareVersions(o, i, s)
      ) > -1;
  }
  /**
   * Check if the OS name equals the passed string
   * @param {string} osName The string to compare with the OS name
   * @returns {boolean}
   */
  isOS(t) {
    return this.getOSName(!0) === String(t).toLowerCase();
  }
  /**
   * Check if the platform type equals the passed string
   * @param {string} platformType The string to compare with the platform type
   * @returns {boolean}
   */
  isPlatform(t) {
    return this.getPlatformType(!0) === String(t).toLowerCase();
  }
  /**
   * Check if the engine name equals the passed string
   * @param {string} engineName The string to compare with the engine name
   * @returns {boolean}
   */
  isEngine(t) {
    return this.getEngineName(!0) === String(t).toLowerCase();
  }
  /**
   * Is anything? Check if the browser is called "anything",
   * the OS called "anything" or the platform called "anything"
   * @param {String} anything
   * @param [includingAlias=false] The flag showing whether alias will be included into comparison
   * @returns {Boolean}
   */
  is(t, e = !1) {
    return this.isBrowser(t, e) || this.isOS(t) || this.isPlatform(t);
  }
  /**
   * Check if any of the given values satisfies this.is(anything)
   * @param {String[]} anythings
   * @returns {Boolean}
   */
  some(t = []) {
    return t.some((e) => this.is(e));
  }
}
class Ev {
  /**
   * Creates a {@link Parser} instance
   *
   * @param {String} UA UserAgent string
   * @param {Boolean|Object} [skipParsingOrHints=false] Either a boolean to skip parsing,
   * or a ClientHints object (navigator.userAgentData)
   * @param {Object} [clientHints] User-Agent Client Hints data (navigator.userAgentData)
   * @returns {Parser}
   * @throws {Error} when UA is not a String
   *
   * @example
   * const parser = Bowser.getParser(window.navigator.userAgent);
   * const result = parser.getResult();
   *
   * @example
   * // With User-Agent Client Hints
   * const parser = Bowser.getParser(
   *   window.navigator.userAgent,
   *   window.navigator.userAgentData
   * );
   */
  static getParser(t, e = !1, i = null) {
    if (typeof t != "string")
      throw new Error("UserAgent should be a string");
    return new La(t, e, i);
  }
  /**
   * Creates a {@link Parser} instance and runs {@link Parser.getResult} immediately
   *
   * @param {String} UA UserAgent string
   * @param {Object} [clientHints] User-Agent Client Hints data (navigator.userAgentData)
   * @return {ParsedResult}
   *
   * @example
   * const result = Bowser.parse(window.navigator.userAgent);
   *
   * @example
   * // With User-Agent Client Hints
   * const result = Bowser.parse(
   *   window.navigator.userAgent,
   *   window.navigator.userAgentData
   * );
   */
  static parse(t, e = null) {
    return new La(t, e).getResult();
  }
  static get BROWSER_MAP() {
    return dc;
  }
  static get ENGINE_MAP() {
    return Rt;
  }
  static get OS_MAP() {
    return it;
  }
  static get PLATFORMS_MAP() {
    return O;
  }
}
const Bn = Ev.getParser(
  globalThis.navigator.userAgent
).getResult(), Xe = "unknown", xa = (...n) => n.filter(Boolean).join(" ").trim() || Xe;
function hc() {
  const n = xa(Bn.os?.name, Bn.os?.version), t = xa(
    Bn.browser?.name,
    Bn.browser?.version
  ), e = (() => {
    const r = GM_info?.scriptHandler, a = GM_info?.version;
    return r && a ? `${r} v${a}` : r || a || Xe;
  })(), i = GM_info?.script?.version ?? Xe, s = GM_info?.script?.name ?? Xe, o = globalThis?.location?.href ?? Xe;
  return {
    os: n,
    browser: t,
    loader: e,
    scriptVersion: i,
    scriptName: s,
    url: o
  };
}
class Vv {
  constructor({
    loggedIn: t = !1,
    username: e = "unnamed",
    avatarId: i = "0/0-0"
  } = {}) {
    c(this, "container");
    c(this, "accountWrapper");
    c(this, "buttons");
    c(this, "usernameEl");
    c(this, "avatarEl");
    c(this, "avatarImg");
    c(this, "actionButton");
    c(this, "refreshButton");
    c(this, "tokenButton");
    c(this, "onClick", new U());
    c(this, "onRefresh", new U());
    c(this, "onClickSecret", new U());
    c(this, "events", {
      click: this.onClick,
      "click:secret": this.onClickSecret,
      refresh: this.onRefresh
    });
    c(this, "_loggedIn");
    c(this, "_username");
    c(this, "_avatarId");
    this._loggedIn = t, this._username = e, this._avatarId = i;
    const s = this.createElements();
    this.container = s.container, this.accountWrapper = s.accountWrapper, this.buttons = s.buttons, this.usernameEl = s.usernameEl, this.avatarEl = s.avatarEl, this.avatarImg = s.avatarImg, this.actionButton = s.actionButton, this.refreshButton = s.refreshButton, this.tokenButton = s.tokenButton;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-account"]), e = L.createEl("vot-block", ["vot-account-wrapper"]);
    e.hidden = !this._loggedIn;
    const i = L.createEl("img", [
      "vot-account-avatar-img"
    ]);
    i.src = `${rr}/${this._avatarId}/islands-retina-middle`, i.loading = "lazy", i.alt = "user avatar";
    const s = L.createEl(
      "vot-block",
      ["vot-account-avatar"],
      i
    ), o = L.createEl("vot-block", ["vot-account-username"]);
    o.textContent = this._username, e.append(s, o);
    const r = L.createEl("vot-block", ["vot-account-buttons"]), a = L.createOutlinedButton(this.buttonText);
    a.addEventListener("click", () => {
      this.onClick.dispatch();
    });
    const l = L.createIconButton(mv, {
      ariaLabel: p.get("VOTLoginViaToken")
    });
    l.hidden = this._loggedIn, l.addEventListener("click", () => {
      this.onClickSecret.dispatch();
    });
    const u = L.createIconButton(gv, {
      ariaLabel: p.get("VOTRefresh")
    });
    return u.addEventListener("click", () => {
      this.onRefresh.dispatch();
    }), r.append(a, l, u), t.append(e, r), {
      container: t,
      accountWrapper: e,
      buttons: r,
      usernameEl: o,
      avatarImg: i,
      avatarEl: s,
      actionButton: a,
      refreshButton: u,
      tokenButton: l
    };
  }
  addEventListener(t, e) {
    return Ht(this.events, t, e), this;
  }
  removeEventListener(t, e) {
    return $t(this.events, t, e), this;
  }
  get buttonText() {
    return this._loggedIn ? p.get("VOTLogout") : p.get("VOTLogin");
  }
  get loggedIn() {
    return this._loggedIn;
  }
  set loggedIn(t) {
    this._loggedIn = t, this.accountWrapper.hidden = !this._loggedIn, this.actionButton.textContent = this.buttonText, this.tokenButton.hidden = this._loggedIn;
  }
  get avatarId() {
    return this._avatarId;
  }
  set avatarId(t) {
    this._avatarId = t ?? "0/0-0", this.avatarImg.src = `${rr}/${this._avatarId}/islands-retina-middle`;
  }
  get username() {
    return this._username;
  }
  set username(t) {
    this._username = t ?? "unnamed", this.usernameEl.textContent = this._username;
  }
  set hidden(t) {
    mt(this.container, t);
  }
  get hidden() {
    return pt(this.container);
  }
}
class X {
  constructor({
    labelHtml: t,
    checked: e = !1,
    isSubCheckbox: i = !1
  }) {
    c(this, "container");
    c(this, "input");
    c(this, "label");
    c(this, "onChange", new U());
    c(this, "events", {
      change: this.onChange
    });
    c(this, "_labelHtml");
    c(this, "_checked");
    c(this, "_isSubCheckbox");
    this._labelHtml = t, this._checked = e, this._isSubCheckbox = i;
    const s = this.createElements();
    this.container = s.container, this.input = s.input, this.label = s.label;
  }
  createElements() {
    const t = L.createEl("label", ["vot-checkbox"]);
    this._isSubCheckbox && t.classList.add("vot-checkbox-sub");
    const e = document.createElement("input");
    e.type = "checkbox", e.checked = this._checked, e.addEventListener("change", () => {
      this._checked = e.checked, this.onChange.dispatch(this._checked);
    });
    const i = L.createEl("span");
    return ht(this._labelHtml, i), t.append(e, i), { container: t, input: e, label: i };
  }
  addEventListener(t, e) {
    return Ht(this.events, "change", e), this;
  }
  removeEventListener(t, e) {
    return $t(this.events, "change", e), this;
  }
  set hidden(t) {
    mt(this.container, t);
  }
  get hidden() {
    return pt(this.container);
  }
  get disabled() {
    return this.input.disabled;
  }
  set disabled(t) {
    this.input.disabled = t;
  }
  get checked() {
    return this._checked;
  }
  /**
   * If you set a different new value, it will trigger the change event
   */
  set checked(t) {
    this._checked !== t && (this._checked = this.input.checked = t, this.onChange.dispatch(this._checked));
  }
}
class Cv {
  constructor({ titleHtml: t }) {
    c(this, "container");
    c(this, "header");
    c(this, "arrowIcon");
    c(this, "onClick", new U());
    c(this, "events", {
      click: this.onClick
    });
    c(this, "_titleHtml");
    this._titleHtml = t;
    const e = this.createElements();
    this.container = e.container, this.header = e.header, this.arrowIcon = e.arrowIcon;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-details"]);
    L.makeButtonLike(t);
    const e = L.createEl("vot-block");
    e.append(this._titleHtml);
    const i = L.createEl("vot-block", ["vot-details-arrow-icon"]);
    return ht(uc, i), t.append(e, i), t.addEventListener("click", () => {
      this.onClick.dispatch();
    }), {
      container: t,
      header: e,
      arrowIcon: i
    };
  }
  addEventListener(t, e) {
    return Ht(this.events, "click", e), this;
  }
  removeEventListener(t, e) {
    return $t(this.events, "click", e), this;
  }
  set hidden(t) {
    mt(this.container, t);
  }
  get hidden() {
    return pt(this.container);
  }
}
class Aa {
  constructor({ labelHtml: t, key: e = null }) {
    c(this, "container");
    c(this, "button");
    c(this, "onChange", new U());
    c(this, "events", {
      change: this.onChange
    });
    c(this, "_labelHtml");
    c(this, "_key");
    // Currently held keys while recording.
    c(this, "pressedKeys");
    // Union of all keys pressed during the recording session.
    c(this, "comboKeys");
    c(this, "recording", !1);
    c(this, "keydownHandle", (t) => {
      if (!(!this.recording || t.repeat)) {
        if (t.preventDefault(), t.code === "Escape") {
          this.key = null, this.button.textContent = this.keyText, this.stopRecordingKeys();
          return;
        }
        this.pressedKeys.add(t.code), this.comboKeys.add(t.code), this.button.textContent = Fn(this.pressedKeys);
      }
    });
    c(this, "keyupOrBlurHandle", (t) => {
      this.recording && (t && (this.pressedKeys.delete(t.code), this.button.textContent = this.pressedKeys.size ? Fn(this.pressedKeys) : Fn(this.comboKeys), this.pressedKeys.size) || (this.key = this.comboKeys.size ? Iv(this.comboKeys) : null, this.stopRecordingKeys()));
    });
    c(this, "blurHandle", () => {
      this.keyupOrBlurHandle();
    });
    this._labelHtml = t, this._key = e, this.pressedKeys = /* @__PURE__ */ new Set(), this.comboKeys = /* @__PURE__ */ new Set();
    const i = this.createElements();
    this.container = i.container, this.button = i.button;
  }
  stopRecordingKeys() {
    this.recording = !1, document.removeEventListener("keydown", this.keydownHandle), document.removeEventListener("keyup", this.keyupOrBlurHandle), globalThis.removeEventListener("blur", this.blurHandle), delete this.button.dataset.status, this.pressedKeys.clear(), this.comboKeys.clear();
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-hotkey"]), e = L.createEl("vot-block", ["vot-hotkey-label"]);
    e.textContent = this._labelHtml;
    const i = L.createEl("vot-block", ["vot-hotkey-button"]);
    return L.makeButtonLike(i), i.textContent = this.keyText, i.addEventListener("click", () => {
      if (this.recording) {
        this.stopRecordingKeys(), this.button.textContent = this.keyText;
        return;
      }
      i.dataset.status = "active", this.recording = !0, this.pressedKeys.clear(), this.comboKeys.clear(), this.button.textContent = p.get(
        "PressTheKeyCombination"
      ), document.addEventListener("keydown", this.keydownHandle), document.addEventListener("keyup", this.keyupOrBlurHandle), globalThis.addEventListener("blur", this.blurHandle);
    }), t.append(e, i), { container: t, button: i, label: e };
  }
  addEventListener(t, e) {
    return Ht(this.events, "change", e), this;
  }
  removeEventListener(t, e) {
    return $t(this.events, "change", e), this;
  }
  set hidden(t) {
    mt(this.container, t);
  }
  get hidden() {
    return pt(this.container);
  }
  get key() {
    return this._key;
  }
  get keyText() {
    return this._key ? Fn(this._key) : p.get("None");
  }
  /**
   * If you set a different new value, it will trigger the change event
   */
  set key(t) {
    this._key !== t && (this._key = t, this.button.textContent = this.keyText, this.onChange.dispatch(this._key));
  }
}
function Iv(n) {
  return (Array.isArray(n) ? n : Array.from(n)).map((e) => e.replace("Key", "").replace("Digit", "")).join("+");
}
function Fn(n) {
  let t;
  typeof n == "string" ? t = n.split("+").filter(Boolean) : Array.isArray(n) ? t = n : t = Array.from(n);
  const e = (s) => {
    switch (s) {
      case "ControlLeft":
      case "ControlRight":
      case "Control":
        return "Ctrl";
      case "ShiftLeft":
      case "ShiftRight":
      case "Shift":
        return "Shift";
      case "AltLeft":
      case "AltRight":
      case "Alt":
        return "Alt";
      case "MetaLeft":
      case "MetaRight":
      case "Meta":
        return "Meta";
      case "Space":
        return "Space";
      case "ArrowUp":
        return "↑";
      case "ArrowDown":
        return "↓";
      case "ArrowLeft":
        return "←";
      case "ArrowRight":
        return "→";
      default:
        return s.replace("Key", "").replace("Digit", "");
    }
  }, i = (s) => {
    const o = e(s);
    return o === "Ctrl" ? 0 : o === "Alt" ? 1 : o === "Shift" ? 2 : o === "Meta" ? 3 : 10;
  };
  return t.slice().sort((s, o) => i(s) - i(o)).map(e).join("+");
}
const Pv = [
  "click:bugReport",
  "click:resetSettings",
  "update:account",
  "change:autoTranslate",
  "change:autoSubtitles",
  "change:showVideoVolume",
  "change:audioBooster",
  "change:syncVolume",
  "change:useLivelyVoice",
  "change:subtitlesHighlightWords",
  "change:subtitlesSmartLayout",
  "select:subtitlesFontFamily",
  "change:proxyWorkerHost",
  "change:useNewAudioPlayer",
  "change:onlyBypassMediaCSP",
  "change:showPiPButton",
  "input:subtitlesMaxLength",
  "input:subtitlesFontSize",
  "input:subtitlesBackgroundOpacity",
  "input:autoHideButtonDelay",
  "select:proxyTranslationStatus",
  "select:translationTextService",
  "select:buttonPosition",
  "select:menuLanguage"
];
function Mv() {
  const n = {};
  for (const t of Pv)
    n[t] = new U();
  return n;
}
const Ov = 30, fc = {
  "default-sans": "Default Sans",
  arial: "Arial",
  helvetica: "Helvetica",
  roboto: "Roboto",
  verdana: "Verdana",
  "open-sans": "Open Sans",
  poppins: "Poppins",
  lato: "Lato",
  montserrat: "Montserrat",
  barlow: "Barlow"
};
function Ea(n) {
  return ii(n) ? fc[n] : Ee(n) ?? "Default Sans";
}
const gi = class gi {
  constructor({ globalPortal: t, data: e = {}, videoHandler: i }) {
    c(this, "globalPortal");
    c(this, "initialized", !1);
    c(this, "data");
    c(this, "videoHandler");
    c(this, "suppressSubtitlesSmartLayoutCheckboxChange", !1);
    c(this, "events", Mv());
    c(this, "oauthMessageListenerBound", !1);
    c(this, "persistTimerIds", {});
    c(this, "dialog");
    c(this, "accountButton");
    c(this, "accountButtonRefreshTooltip");
    c(this, "accountButtonTokenTooltip");
    c(this, "autoTranslateCheckbox");
    c(this, "autoSubtitlesCheckbox");
    c(this, "dontTranslateLanguagesCheckbox");
    c(this, "dontTranslateLanguagesSelect");
    c(this, "autoSetVolumeSliderLabel");
    c(this, "autoSetVolumeCheckbox");
    c(this, "smartDuckingCheckbox");
    c(this, "autoSetVolumeSlider");
    c(this, "showVideoVolumeSliderCheckbox");
    c(this, "audioBoosterCheckbox");
    c(this, "audioBoosterTooltip");
    c(this, "syncVolumeCheckbox");
    c(this, "downloadWithNameCheckbox");
    c(this, "sendNotifyOnCompleteCheckbox");
    c(this, "useLivelyVoiceCheckbox");
    c(this, "useLivelyVoiceTooltip");
    c(this, "useAudioDownloadCheckbox");
    c(this, "useAudioDownloadCheckboxLabel");
    c(this, "useAudioDownloadCheckboxTooltip");
    c(this, "subtitlesDownloadFormatSelectLabel");
    c(this, "subtitlesDownloadFormatSelect");
    c(this, "subtitlesHighlightWordsCheckbox");
    c(this, "subtitlesSmartLayoutCheckbox");
    c(this, "subtitlesMaxLengthSliderLabel");
    c(this, "subtitlesMaxLengthSlider");
    c(this, "subtitlesFontSizeSliderLabel");
    c(this, "subtitlesFontSizeSlider");
    c(this, "subtitlesFontFamilySelectLabel");
    c(this, "subtitlesFontFamilySelect");
    c(this, "subtitlesBackgroundOpacitySliderLabel");
    c(this, "subtitlesBackgroundOpacitySlider");
    c(this, "translateHotkeyButton");
    c(this, "subtitlesHotkeyButton");
    c(this, "proxyWorkerHostTextfield");
    c(this, "proxyTranslationStatusSelectLabel");
    c(this, "proxyTranslationStatusSelectTooltip");
    c(this, "proxyTranslationStatusSelect");
    c(this, "translateAPIErrorsCheckbox");
    c(this, "useNewAudioPlayerCheckbox");
    c(this, "useNewAudioPlayerTooltip");
    c(this, "onlyBypassMediaCSPCheckbox");
    c(this, "onlyBypassMediaCSPTooltip");
    c(this, "translationTextServiceLabel");
    c(this, "translationTextServiceSelect");
    c(this, "translationTextServiceTooltip");
    c(this, "detectServiceLabel");
    c(this, "detectServiceSelect");
    c(this, "showPiPButtonCheckbox");
    c(this, "autoHideButtonDelaySliderLabel");
    c(this, "autoHideButtonDelaySlider");
    c(this, "buttonPositionSelectLabel");
    c(this, "buttonPositionSelect");
    c(this, "buttonPositionTooltip");
    c(this, "menuLanguageSelectLabel");
    c(this, "menuLanguageSelect");
    c(this, "bugReportButton");
    c(this, "resetSettingsButton");
    this.globalPortal = t, this.data = e, this.videoHandler = i;
  }
  isInitialized() {
    return this.initialized;
  }
  bindOAuthMessageListener() {
    this.oauthMessageListenerBound || (this.oauthMessageListenerBound = !0, globalThis.addEventListener("message", async (t) => {
      const e = t.data;
      if (!e || typeof e != "object" || e.source !== "vot-auth") return;
      if (t.origin !== yn) {
        V.log("[VOT] Ignoring OAuth message from unexpected origin:", t.origin);
        return;
      }
      if (e.type === "error") {
        V.log("[VOT] OAuth error:", e.error, e.error_description);
        return;
      }
      if (e.type !== "code") return;
      const i = sessionStorage.getItem("vot-yandex-oauth-state") ?? void 0;
      if (!(!e.state || !i || e.state !== i)) {
        try {
          const s = await Zh(e.code);
          await Qh(s), this.data.account = {
            ...this.data.account ?? {},
            token: s.access_token,
            expires: Date.now() + s.expires_in * 1e3
          }, V.log("[VOT] OAuth login success");
        } catch (s) {
          console.error("[VOT] OAuth token exchange failed:", s);
          return;
        }
        if (this.isInitialized())
          try {
            this.updateAccountInfo();
          } catch (s) {
            console.warn("[VOT] Failed to update account UI:", s);
          }
      }
    }));
  }
  createAccordionSection(t, e = {}) {
    const i = L.createEl("vot-block", ["vot-settings-section"]), s = new Cv({ titleHtml: t });
    s.container.classList.add("vot-settings-section-header");
    const o = typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`, r = `vot-settings-section-header-${o}`, a = `vot-settings-section-content-${o}`;
    s.container.id = r;
    const l = L.createEl("vot-block", ["vot-settings-section-content"]);
    l.id = a, l.setAttribute("role", "region"), l.setAttribute("aria-labelledby", r), s.container.setAttribute("aria-controls", a);
    const u = (h) => {
      s.container.dataset.open = h ? "true" : "false", s.container.setAttribute("aria-expanded", h ? "true" : "false"), l.hidden = !h;
    }, d = () => s.container.dataset.open === "true";
    return u(!!e.open), s.addEventListener("click", () => {
      const h = s.container.dataset.open === "true";
      u(!h);
    }), i.append(s.container, l), {
      title: t,
      container: i,
      header: s.container,
      content: l,
      setOpen: u,
      getOpen: d
    };
  }
  setSubtitlesSmartLayout(t) {
    this.data.subtitlesSmartLayout = t, C.set("subtitlesSmartLayout", t), this.subtitlesSmartLayoutCheckbox?.checked !== t && (this.suppressSubtitlesSmartLayoutCheckboxChange = !0, this.subtitlesSmartLayoutCheckbox.checked = t, this.suppressSubtitlesSmartLayoutCheckboxChange = !1), this.events["change:subtitlesSmartLayout"].dispatch(t);
  }
  scheduleStoragePersist(t, e) {
    const i = this.persistTimerIds[t];
    i !== void 0 && globalThis.clearTimeout(i), this.persistTimerIds[t] = globalThis.setTimeout(() => {
      this.persistTimerIds[t] = void 0, C.set(t, e);
    }, gi.PERSIST_DELAY_MS);
  }
  flushStoragePersists() {
    for (const t of Object.keys(this.persistTimerIds)) {
      const e = this.persistTimerIds[t];
      if (e === void 0) continue;
      globalThis.clearTimeout(e), this.persistTimerIds[t] = void 0;
      const i = this.data[t];
      typeof i == "number" && C.set(t, i);
    }
  }
  bindPersistedSetting({
    control: t,
    event: e,
    apply: i,
    storageKey: s,
    readPersistedValue: o,
    logLabel: r,
    dispatch: a,
    afterPersist: l
  }) {
    t.addEventListener(e, async (u) => {
      i(u), await C.set(s, o()), l && await l(u), a?.(u);
    });
  }
  initUI() {
    if (this.isInitialized())
      throw new Error("[VOT] SettingsView is already initialized");
    this.dialog = new Ts({
      titleHtml: p.get("VOTSettings")
    }), this.globalPortal.appendChild(this.dialog.container);
    const t = this.createAccordionSection(
      p.get("VOTMyAccount"),
      { open: !0 }
    ), e = this.createAccordionSection(
      p.get("translationSettings"),
      { open: !0 }
    ), i = this.createAccordionSection(
      p.get("subtitlesSettings")
    ), s = this.createAccordionSection(
      p.get("hotkeysSettings")
    ), o = this.createAccordionSection(
      p.get("proxySettings")
    ), r = this.createAccordionSection(
      p.get("miscSettings")
    ), a = this.createAccordionSection(
      p.get("appearance")
    ), l = this.createAccordionSection(
      p.get("aboutExtension")
    ), u = [
      t,
      e,
      i,
      s,
      o,
      r,
      a,
      l
    ];
    this.dialog.bodyContainer.append(
      ...u.map((B) => B.container)
    ), this.accountButton = new Vv({
      avatarId: this.data.account?.avatarId,
      username: this.data.account?.username,
      loggedIn: !!this.data.account?.token
    }), C.isSupportOnlyLS ? (this.accountButton.refreshButton.setAttribute("disabled", "true"), this.accountButton.actionButton.setAttribute("disabled", "true")) : this.accountButtonRefreshTooltip = new ct({
      target: this.accountButton.refreshButton,
      content: p.get("VOTRefresh"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal
    }), this.accountButtonTokenTooltip = new ct({
      target: this.accountButton.tokenButton,
      content: p.get("VOTLoginViaToken"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal
    }), this.autoTranslateCheckbox = new X({
      labelHtml: p.get("VOTAutoTranslate"),
      checked: this.data.autoTranslate
    }), this.autoSubtitlesCheckbox = new X({
      labelHtml: p.get("VOTAutoSubtitles"),
      checked: this.data.autoSubtitles
    });
    const d = this.data.dontTranslateLanguages ?? [];
    this.dontTranslateLanguagesCheckbox = new X({
      labelHtml: p.get("DontTranslateSelectedLanguages"),
      checked: this.data.enabledDontTranslateLanguages
    }), this.dontTranslateLanguagesSelect = new ot({
      dialogParent: this.globalPortal,
      dialogTitle: p.get("DontTranslateSelectedLanguages"),
      selectTitle: d.map((B) => p.get(`langs.${B}`)).join(", ") || p.get("DontTranslateSelectedLanguages"),
      items: ot.genLanguageItems(Pt).map((B) => ({
        ...B,
        selected: d.includes(B.value)
      })),
      multiSelect: !0,
      labelElement: this.dontTranslateLanguagesCheckbox.container
    }), this.dontTranslateLanguagesSelect.disabled = !this.dontTranslateLanguagesCheckbox.checked;
    const h = this.data.autoVolume ?? pi;
    this.autoSetVolumeSliderLabel = new Jt({
      labelText: p.get("VOTAutoSetVolume"),
      value: h
    }), this.autoSetVolumeCheckbox = new X({
      labelHtml: this.autoSetVolumeSliderLabel.container,
      checked: this.data.enabledAutoVolume ?? !0
    }), this.autoSetVolumeSlider = new Xt({
      labelHtml: this.autoSetVolumeCheckbox.container,
      value: h,
      min: 0
    });
    const f = !!this.data.syncVolume;
    this.autoSetVolumeSlider.disabled = !this.autoSetVolumeCheckbox.checked, this.smartDuckingCheckbox = new X({
      labelHtml: p.get("smartDucking"),
      checked: this.data.enabledSmartDucking ?? !0
    }), this.smartDuckingCheckbox.disabled = f || !this.autoSetVolumeCheckbox.checked, this.showVideoVolumeSliderCheckbox = new X({
      labelHtml: p.get("showVideoVolumeSlider"),
      checked: this.data.showVideoSlider
    }), this.audioBoosterCheckbox = new X({
      labelHtml: p.get("VOTAudioBooster"),
      checked: this.data.audioBooster
    }), this.videoHandler?.isAudioContextSupported || (this.audioBoosterCheckbox.disabled = !0, this.audioBoosterTooltip = new ct({
      target: this.audioBoosterCheckbox.container,
      content: p.get("VOTNeedWebAudioAPI"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal
    })), this.syncVolumeCheckbox = new X({
      labelHtml: p.get("VOTSyncVolume"),
      checked: this.data.syncVolume
    }), this.downloadWithNameCheckbox = new X({
      labelHtml: p.get("VOTDownloadWithName"),
      checked: this.data.downloadWithName
    }), this.downloadWithNameCheckbox.disabled = !cn, this.sendNotifyOnCompleteCheckbox = new X({
      labelHtml: p.get("VOTSendNotifyOnComplete"),
      checked: this.data.sendNotifyOnComplete
    }), this.useLivelyVoiceCheckbox = new X({
      labelHtml: p.get("VOTUseLivelyVoice"),
      checked: this.data.useLivelyVoice
    }), this.useLivelyVoiceTooltip = new ct({
      target: this.useLivelyVoiceCheckbox.container,
      content: p.get("VOTAccountRequired"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal,
      hidden: !!this.data.account?.token
    }), this.data.account?.token || (this.useLivelyVoiceCheckbox.disabled = !0), this.useAudioDownloadCheckboxLabel = new It({
      labelText: p.get("VOTUseAudioDownload"),
      icon: Ta
    }), this.useAudioDownloadCheckbox = new X({
      labelHtml: this.useAudioDownloadCheckboxLabel.container,
      checked: this.data.useAudioDownload
    }), cn || (this.useAudioDownloadCheckbox.disabled = !0), this.useAudioDownloadCheckboxTooltip = new ct({
      target: this.useAudioDownloadCheckboxLabel.container,
      content: p.get("VOTUseAudioDownloadWarning"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal
    }), t.content.append(this.accountButton.container), e.content.append(
      this.autoTranslateCheckbox.container,
      this.autoSubtitlesCheckbox.container,
      this.dontTranslateLanguagesSelect.container,
      this.autoSetVolumeSlider.container,
      this.smartDuckingCheckbox.container,
      this.showVideoVolumeSliderCheckbox.container,
      this.audioBoosterCheckbox.container,
      this.syncVolumeCheckbox.container,
      this.downloadWithNameCheckbox.container,
      this.sendNotifyOnCompleteCheckbox.container,
      this.useLivelyVoiceCheckbox.container,
      this.useAudioDownloadCheckbox.container
    ), this.subtitlesDownloadFormatSelectLabel = new It({
      labelText: p.get("VOTSubtitlesDownloadFormat")
    }), this.subtitlesDownloadFormatSelect = new ot({
      selectTitle: this.data.subtitlesDownloadFormat ?? p.get("VOTSubtitlesDownloadFormat"),
      dialogTitle: p.get("VOTSubtitlesDownloadFormat"),
      dialogParent: this.globalPortal,
      labelElement: this.subtitlesDownloadFormatSelectLabel.container,
      items: _b.map((B) => ({
        label: B.toUpperCase(),
        value: B,
        selected: B === this.data.subtitlesDownloadFormat
      }))
    }), this.subtitlesHighlightWordsCheckbox = new X({
      labelHtml: p.get("VOTHighlightWords"),
      checked: this.data.highlightWords
    });
    const g = this.data.subtitlesSmartLayout ?? !0;
    this.subtitlesSmartLayoutCheckbox = new X({
      labelHtml: p.get("subtitlesSmartLayout"),
      checked: g
    });
    const m = this.data.subtitlesMaxLength ?? 300;
    this.subtitlesMaxLengthSliderLabel = new Jt({
      labelText: p.get("VOTSubtitlesMaxLength"),
      labelEOL: ":",
      value: m,
      symbol: ""
    }), this.subtitlesMaxLengthSlider = new Xt({
      labelHtml: this.subtitlesMaxLengthSliderLabel.container,
      value: m,
      min: 50,
      max: 300
    });
    const v = this.data.subtitlesFontSize ?? 20;
    this.subtitlesFontSizeSliderLabel = new Jt({
      labelText: p.get("VOTSubtitlesFontSize"),
      labelEOL: ":",
      value: v,
      symbol: "px"
    }), this.subtitlesFontSizeSlider = new Xt({
      labelHtml: this.subtitlesFontSizeSliderLabel.container,
      value: v,
      min: 8,
      max: 50
    });
    const T = typeof this.data.subtitlesFontFamily == "string" ? this.data.subtitlesFontFamily : void 0, S = T && (ii(T) || Ee(T)) ? T : "default-sans", w = (B, bt = []) => {
      const Et = ic.map(
        (j) => ({
          label: fc[j],
          value: j,
          selected: j === B
        })
      ), Tt = bt.filter((j) => {
        const kt = j.toLowerCase();
        return !Et.some(
          (qt) => qt.label.toLowerCase() === kt
        );
      }).map((j) => {
        const kt = Nb(j);
        return {
          label: j,
          value: kt,
          selected: kt === B
        };
      });
      if (!ii(B) && !Tt.some((j) => j.value === B)) {
        const j = Ee(B);
        j && Tt.unshift({
          label: j,
          value: B,
          selected: !0
        });
      }
      return [...Et, ...Tt];
    };
    this.subtitlesFontFamilySelectLabel = new It({
      labelText: p.get("VOTSubtitlesFont")
    }), this.subtitlesFontFamilySelect = new ot({
      selectTitle: Ea(S),
      dialogTitle: p.get("VOTSubtitlesFont"),
      dialogParent: this.globalPortal,
      labelElement: this.subtitlesFontFamilySelectLabel.container,
      items: w(S),
      searchItemsProvider: async (B) => {
        const bt = Array.from(this.subtitlesFontFamilySelect?.selectedValues ?? [])[0] ?? S, Et = B.trim().toLowerCase();
        if (!Et)
          return w(bt);
        const j = (await Wb()).filter(
          (kt) => kt.toLowerCase().includes(Et)
        ).slice(0, Ov);
        return w(bt, j);
      }
    }), this.subtitlesFontFamilySelect.addEventListener("selectItem", (B) => {
      this.subtitlesFontFamilySelect && (this.subtitlesFontFamilySelect.updateItems(w(B)), this.subtitlesFontFamilySelect.selectTitle = Ea(B));
    });
    const x = this.data.subtitlesOpacity ?? 20;
    this.subtitlesBackgroundOpacitySliderLabel = new Jt({
      labelText: p.get("VOTSubtitlesOpacity"),
      labelEOL: ":",
      value: x,
      symbol: "%"
    }), this.subtitlesBackgroundOpacitySlider = new Xt({
      labelHtml: this.subtitlesBackgroundOpacitySliderLabel.container,
      value: x,
      min: 0,
      max: 100
    }), i.content.append(
      this.subtitlesDownloadFormatSelect.container,
      this.subtitlesFontFamilySelect.container,
      this.subtitlesHighlightWordsCheckbox.container,
      this.subtitlesSmartLayoutCheckbox.container,
      this.subtitlesMaxLengthSlider.container,
      this.subtitlesFontSizeSlider.container,
      this.subtitlesBackgroundOpacitySlider.container
    ), this.translateHotkeyButton = new Aa({
      labelHtml: p.get("translateVideo"),
      key: this.data.translationHotkey
    }), this.subtitlesHotkeyButton = new Aa({
      labelHtml: p.get("VOTSubtitles"),
      key: this.data.subtitlesHotkey
    }), s.content.append(
      this.translateHotkeyButton.container,
      this.subtitlesHotkeyButton.container
    ), this.proxyWorkerHostTextfield = new ks({
      labelHtml: p.get("VOTProxyWorkerHost"),
      value: this.data.proxyWorkerHost,
      placeholder: rn
    });
    const I = [
      p.get("VOTTranslateProxyDisabled"),
      p.get("VOTTranslateProxyEnabled"),
      p.get("VOTTranslateProxyEverything")
    ], k = this.data.translateProxyEnabled ?? 0, A = Ce && Vl.includes(Ce);
    this.proxyTranslationStatusSelectLabel = new It({
      icon: A ? Ta : void 0,
      labelText: p.get("VOTTranslateProxyStatus")
    }), A && (this.proxyTranslationStatusSelectTooltip = new ct({
      target: this.proxyTranslationStatusSelectLabel.icon,
      content: p.get("VOTTranslateProxyStatusDefault"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal
    })), this.proxyTranslationStatusSelect = new ot({
      selectTitle: I[k],
      dialogTitle: p.get("VOTTranslateProxyStatus"),
      dialogParent: this.globalPortal,
      labelElement: this.proxyTranslationStatusSelectLabel.container,
      items: I.map((B, bt) => ({
        label: B,
        value: bt.toString(),
        selected: bt === k,
        disabled: bt === 0 && Dl
      }))
    }), o.content.append(
      this.proxyWorkerHostTextfield.container,
      this.proxyTranslationStatusSelect.container
    ), this.translateAPIErrorsCheckbox = new X({
      labelHtml: p.get("VOTTranslateAPIErrors"),
      checked: this.data.translateAPIErrors ?? !0
    }), this.translateAPIErrorsCheckbox.hidden = p.lang === "ru", this.useNewAudioPlayerCheckbox = new X({
      labelHtml: p.get("VOTNewAudioPlayer"),
      checked: this.data.newAudioPlayer
    }), this.videoHandler?.isAudioContextSupported || (this.useNewAudioPlayerCheckbox.disabled = !0, this.useNewAudioPlayerTooltip = new ct({
      target: this.useNewAudioPlayerCheckbox.container,
      content: p.get("VOTNeedWebAudioAPI"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal
    }));
    const $ = this.videoHandler?.site.needBypassCSP ? `${p.get("VOTOnlyBypassMediaCSP")} (${p.get("VOTMediaCSPEnabledOnSite")})` : p.get("VOTOnlyBypassMediaCSP");
    this.onlyBypassMediaCSPCheckbox = new X({
      labelHtml: $,
      checked: this.data.onlyBypassMediaCSP,
      isSubCheckbox: !0
    }), this.videoHandler?.isAudioContextSupported || (this.onlyBypassMediaCSPTooltip = new ct({
      target: this.onlyBypassMediaCSPCheckbox.container,
      content: p.get("VOTNeedWebAudioAPI"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal
    })), this.onlyBypassMediaCSPCheckbox.disabled = !this.data.newAudioPlayer && !!this.videoHandler?.isAudioContextSupported, this.data.newAudioPlayer || (this.onlyBypassMediaCSPCheckbox.hidden = !0), this.translationTextServiceLabel = new It({
      labelText: p.get("VOTTranslationTextService"),
      icon: ka
    });
    const H = this.data.translationService ?? bi;
    this.translationTextServiceSelect = new ot({
      selectTitle: p.get(`services.${H}`),
      dialogTitle: p.get("VOTTranslationTextService"),
      dialogParent: this.globalPortal,
      labelElement: this.translationTextServiceLabel.container,
      items: Kl.map((B) => ({
        label: p.get(`services.${B}`),
        value: B,
        selected: B === H
      }))
    }), this.translationTextServiceTooltip = new ct({
      target: this.translationTextServiceLabel.icon,
      content: p.get("VOTNotAffectToVoice"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal
    }), this.detectServiceLabel = new It({
      labelText: p.get("VOTDetectService")
    });
    const _ = this.data.detectService ?? Ks;
    this.detectServiceSelect = new ot({
      selectTitle: p.get(`services.${_}`),
      dialogTitle: p.get("VOTDetectService"),
      dialogParent: this.globalPortal,
      labelElement: this.detectServiceLabel.container,
      items: Xp.map((B) => ({
        label: p.get(`services.${B}`),
        value: B,
        selected: B === _
      }))
    }), this.showPiPButtonCheckbox = new X({
      labelHtml: p.get("VOTShowPiPButton"),
      checked: this.data.showPiPButton
    }), this.showPiPButtonCheckbox.hidden = !Cl();
    const z = Math.round(
      (this.data.autoHideButtonDelay ?? Ys) / 1e3 * 10
    ) / 10;
    this.autoHideButtonDelaySliderLabel = new Jt({
      labelText: p.get("autoHideButtonDelay"),
      labelEOL: ":",
      value: z,
      symbol: ` ${p.get("secs")}`
    }), this.autoHideButtonDelaySlider = new Xt({
      labelHtml: this.autoHideButtonDelaySliderLabel.container,
      value: z,
      min: 0.1,
      max: 3,
      step: 0.1
    }), this.buttonPositionSelectLabel = new It({
      labelText: p.get("buttonPosition"),
      icon: ka
    });
    const q = this.data.buttonPos ?? "default";
    this.buttonPositionSelect = new ot({
      selectTitle: p.get(`position.${q}`),
      dialogTitle: p.get("buttonPosition"),
      labelElement: this.buttonPositionSelectLabel.container,
      dialogParent: this.globalPortal,
      items: Sv.map((B) => ({
        label: p.get(`position.${B}`),
        value: B,
        selected: B === q
      }))
    }), this.buttonPositionTooltip = new ct({
      target: this.buttonPositionSelectLabel.icon,
      content: p.get("minButtonPositionContainer"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal
    }), this.menuLanguageSelectLabel = new It({
      labelText: p.get("VOTMenuLanguage")
    }), this.menuLanguageSelect = new ot({
      selectTitle: p.get(
        `langs.${p.langOverride}`
      ),
      dialogTitle: p.get("VOTMenuLanguage"),
      labelElement: this.menuLanguageSelectLabel.container,
      dialogParent: this.globalPortal,
      items: ot.genLanguageItems(
        p.getAvailableLangs(),
        p.langOverride
      )
    }), this.bugReportButton = L.createOutlinedButton(
      p.get("VOTBugReport")
    ), this.resetSettingsButton = L.createButton(
      p.get("resetSettings")
    ), r.content.append(
      this.translateAPIErrorsCheckbox.container,
      this.useNewAudioPlayerCheckbox.container,
      this.onlyBypassMediaCSPCheckbox.container
    ), e.content.append(
      this.translationTextServiceSelect.container,
      this.detectServiceSelect.container
    ), a.content.append(
      this.showPiPButtonCheckbox.container,
      this.autoHideButtonDelaySlider.container,
      this.buttonPositionSelect.container,
      this.menuLanguageSelect.container
    );
    const Y = hc(), Mt = L.createInformation(
      `${p.get("VOTVersion")}:`,
      Y.scriptVersion || GM_info.script.version || p.get("notFound")
    ), Wt = L.createInformation(
      `${p.get("VOTAuthors")}:`,
      GM_info.script.author || "Toil, SashaXser, MrSoczekXD, mynovelhost, sodapng, Acobat12" || p.get("notFound")
    ), Ln = L.createInformation(
      `${p.get("VOTLoader")}:`,
      Y.loader
    ), Pe = L.createInformation(
      `${p.get("VOTBrowser")}:`,
      `${Y.browser} (${Y.os})`
    ), Me = new Date(
      (this.data.localeUpdatedAt ?? 0) * 1e3
    ).toLocaleString(), zt = this.data.localeHash ?? p.get("notFound"), xn = je`${zt}<br />(${p.get(
      "VOTUpdatedAt"
    )} ${Me})`, Oe = L.createInformation(
      `${p.get("VOTLocaleHash")}:`,
      xn
    ), Ot = L.createOutlinedButton(
      p.get("VOTUpdateLocaleFiles")
    );
    return Ot.addEventListener("click", async () => {
      await C.set("localeHash", ""), await p.update(!0), globalThis.location.reload();
    }), l.content.append(
      Mt.container,
      Wt.container,
      Ln.container,
      Pe.container,
      Oe.container,
      Ot
    ), this.dialog.footerContainer.append(
      this.bugReportButton,
      this.resetSettingsButton
    ), this.initialized = !0, this;
  }
  initUIEvents() {
    if (!this.isInitialized())
      throw new Error("[VOT] SettingsView isn't initialized");
    return this.bindOAuthMessageListener(), this.accountButton.addEventListener("click", async () => {
      if (C.isSupportOnlyLS) return;
      if (this.accountButton.loggedIn)
        return await C.delete("account"), this.data.account = {}, this.updateAccountInfo();
      const t = await Xh();
      globalThis.open(
        t,
        "yandex-oauth",
        "popup=yes,width=520,height=720,resizable=yes,scrollbars=yes"
      )?.focus();
    }), this.accountButton.addEventListener("click:secret", async () => {
      const t = new Ts({
        titleHtml: p.get("VOTLoginViaToken"),
        isTemp: !0
      });
      this.globalPortal.appendChild(t.container);
      const e = L.createEl(
        "vot-block",
        void 0,
        p.get("VOTYandexTokenInfo")
      ), i = new ks({
        labelHtml: p.get("VOTYandexToken"),
        value: this.data.account?.token
      });
      i.addEventListener("change", async (s) => {
        this.data.account = s ? { expires: Date.now() + 3153418e4, token: s } : {}, await C.set("account", this.data.account), this.updateAccountInfo();
      }), t.bodyContainer.append(e, i.container), t.open();
    }), this.accountButton.addEventListener("refresh", async () => {
      C.isSupportOnlyLS || (this.data.account = await C.get("account", {}), this.updateAccountInfo());
    }), this.bindPersistedSetting({
      control: this.autoTranslateCheckbox,
      event: "change",
      apply: (t) => {
        this.data.autoTranslate = t;
      },
      storageKey: "autoTranslate",
      readPersistedValue: () => this.data.autoTranslate,
      logLabel: "autoTranslate",
      dispatch: (t) => this.events["change:autoTranslate"].dispatch(t)
    }), this.bindPersistedSetting({
      control: this.autoSubtitlesCheckbox,
      event: "change",
      apply: (t) => {
        this.data.autoSubtitles = t;
      },
      storageKey: "autoSubtitles",
      readPersistedValue: () => this.data.autoSubtitles,
      logLabel: "autoSubtitles",
      dispatch: (t) => this.events["change:autoSubtitles"].dispatch(t)
    }), this.dontTranslateLanguagesCheckbox.addEventListener(
      "change",
      async (t) => {
        this.data.enabledDontTranslateLanguages = t, this.dontTranslateLanguagesSelect.disabled = !t, await C.set(
          "enabledDontTranslateLanguages",
          this.data.enabledDontTranslateLanguages
        );
      }
    ), this.dontTranslateLanguagesSelect.addEventListener(
      "selectItem",
      async (t) => {
        this.data.dontTranslateLanguages = t, await C.set(
          "dontTranslateLanguages",
          this.data.dontTranslateLanguages
        );
      }
    ), this.bindPersistedSetting({
      control: this.autoSetVolumeCheckbox,
      event: "change",
      apply: (t) => {
        this.data.enabledAutoVolume = t, this.autoSetVolumeSlider.disabled = !t, this.smartDuckingCheckbox.disabled = !t || !!this.syncVolumeCheckbox?.checked;
      },
      storageKey: "enabledAutoVolume",
      readPersistedValue: () => this.data.enabledAutoVolume,
      logLabel: "enabledAutoVolume",
      afterPersist: async () => this.videoHandler?.setupAudioSettings?.()
    }), this.bindPersistedSetting({
      control: this.smartDuckingCheckbox,
      event: "change",
      apply: (t) => {
        this.data.enabledSmartDucking = t;
      },
      storageKey: "enabledSmartDucking",
      readPersistedValue: () => this.data.enabledSmartDucking,
      logLabel: "enabledSmartDucking",
      afterPersist: async () => this.videoHandler?.setupAudioSettings?.()
    }), this.bindPersistedSetting({
      control: this.autoSetVolumeSlider,
      event: "input",
      apply: (t) => {
        this.data.autoVolume = this.autoSetVolumeSliderLabel.value = t;
      },
      storageKey: "autoVolume",
      readPersistedValue: () => this.data.autoVolume,
      logLabel: "autoVolume"
    }), this.bindPersistedSetting({
      control: this.showVideoVolumeSliderCheckbox,
      event: "change",
      apply: (t) => {
        this.data.showVideoSlider = t;
      },
      storageKey: "showVideoSlider",
      readPersistedValue: () => this.data.showVideoSlider,
      logLabel: "showVideoVolumeSlider",
      dispatch: (t) => this.events["change:showVideoVolume"].dispatch(t)
    }), this.bindPersistedSetting({
      control: this.audioBoosterCheckbox,
      event: "change",
      apply: (t) => {
        this.data.audioBooster = t;
      },
      storageKey: "audioBooster",
      readPersistedValue: () => this.data.audioBooster,
      logLabel: "audioBooster",
      dispatch: (t) => this.events["change:audioBooster"].dispatch(t)
    }), this.bindPersistedSetting({
      control: this.syncVolumeCheckbox,
      event: "change",
      apply: (t) => {
        this.data.syncVolume = t, this.autoSetVolumeSlider.disabled = !this.autoSetVolumeCheckbox?.checked, this.smartDuckingCheckbox.disabled = t || !this.autoSetVolumeCheckbox?.checked, t && this.smartDuckingCheckbox?.checked && (this.smartDuckingCheckbox.checked = !1);
      },
      storageKey: "syncVolume",
      readPersistedValue: () => this.data.syncVolume,
      logLabel: "syncVolume",
      dispatch: (t) => this.events["change:syncVolume"].dispatch(t)
    }), this.bindPersistedSetting({
      control: this.downloadWithNameCheckbox,
      event: "change",
      apply: (t) => {
        this.data.downloadWithName = t;
      },
      storageKey: "downloadWithName",
      readPersistedValue: () => this.data.downloadWithName,
      logLabel: "downloadWithName"
    }), this.bindPersistedSetting({
      control: this.sendNotifyOnCompleteCheckbox,
      event: "change",
      apply: (t) => {
        this.data.sendNotifyOnComplete = t;
      },
      storageKey: "sendNotifyOnComplete",
      readPersistedValue: () => this.data.sendNotifyOnComplete,
      logLabel: "sendNotifyOnComplete"
    }), this.bindPersistedSetting({
      control: this.useLivelyVoiceCheckbox,
      event: "change",
      apply: (t) => {
        this.data.useLivelyVoice = t;
      },
      storageKey: "useLivelyVoice",
      readPersistedValue: () => this.data.useLivelyVoice,
      logLabel: "useLivelyVoice",
      dispatch: (t) => this.events["change:useLivelyVoice"].dispatch(t)
    }), this.bindPersistedSetting({
      control: this.useAudioDownloadCheckbox,
      event: "change",
      apply: (t) => {
        this.data.useAudioDownload = t;
      },
      storageKey: "useAudioDownload",
      readPersistedValue: () => this.data.useAudioDownload,
      logLabel: "useAudioDownload"
    }), this.bindPersistedSetting({
      control: this.subtitlesDownloadFormatSelect,
      event: "selectItem",
      apply: (t) => {
        this.data.subtitlesDownloadFormat = t;
      },
      storageKey: "subtitlesDownloadFormat",
      readPersistedValue: () => this.data.subtitlesDownloadFormat,
      logLabel: "subtitlesDownloadFormat"
    }), this.bindPersistedSetting({
      control: this.subtitlesHighlightWordsCheckbox,
      event: "change",
      apply: (t) => {
        this.data.highlightWords = t;
      },
      storageKey: "highlightWords",
      readPersistedValue: () => this.data.highlightWords,
      logLabel: "highlightWords",
      dispatch: (t) => this.events["change:subtitlesHighlightWords"].dispatch(t)
    }), this.subtitlesSmartLayoutCheckbox?.addEventListener("change", (t) => {
      this.suppressSubtitlesSmartLayoutCheckboxChange || this.setSubtitlesSmartLayout(t);
    }), this.subtitlesMaxLengthSlider.addEventListener("input", (t) => {
      this.subtitlesMaxLengthSliderLabel.value = t, (this.data.subtitlesSmartLayout ?? !0) === !0 && this.setSubtitlesSmartLayout(!1), this.data.subtitlesMaxLength = t, this.scheduleStoragePersist(
        "subtitlesMaxLength",
        this.data.subtitlesMaxLength
      ), this.events["input:subtitlesMaxLength"].dispatch(t);
    }), this.subtitlesFontSizeSlider.addEventListener("input", (t) => {
      this.subtitlesFontSizeSliderLabel.value = t, (this.data.subtitlesSmartLayout ?? !0) === !0 && this.setSubtitlesSmartLayout(!1), this.data.subtitlesFontSize = t, this.scheduleStoragePersist(
        "subtitlesFontSize",
        this.data.subtitlesFontSize
      ), this.events["input:subtitlesFontSize"].dispatch(t);
    }), this.subtitlesBackgroundOpacitySlider.addEventListener("input", (t) => {
      this.subtitlesBackgroundOpacitySliderLabel.value = t, this.data.subtitlesOpacity = t, this.scheduleStoragePersist(
        "subtitlesOpacity",
        this.data.subtitlesOpacity
      ), this.events["input:subtitlesBackgroundOpacity"].dispatch(t);
    }), this.bindPersistedSetting({
      control: this.subtitlesFontFamilySelect,
      event: "selectItem",
      apply: (t) => {
        this.data.subtitlesFontFamily = t;
      },
      storageKey: "subtitlesFontFamily",
      readPersistedValue: () => this.data.subtitlesFontFamily,
      logLabel: "subtitlesFontFamily",
      dispatch: (t) => this.events["select:subtitlesFontFamily"].dispatch(t)
    }), this.bindPersistedSetting({
      control: this.translateHotkeyButton,
      event: "change",
      apply: (t) => {
        this.data.translationHotkey = t;
      },
      storageKey: "translationHotkey",
      readPersistedValue: () => this.data.translationHotkey,
      logLabel: "translationHotkey"
    }), this.bindPersistedSetting({
      control: this.subtitlesHotkeyButton,
      event: "change",
      apply: (t) => {
        this.data.subtitlesHotkey = t;
      },
      storageKey: "subtitlesHotkey",
      readPersistedValue: () => this.data.subtitlesHotkey,
      logLabel: "subtitlesHotkey"
    }), this.proxyWorkerHostTextfield.addEventListener("change", async (t) => {
      this.data.proxyWorkerHost = t || rn, await C.set("proxyWorkerHost", this.data.proxyWorkerHost), V.log(
        "proxyWorkerHost value changed. New value:",
        this.data.proxyWorkerHost
      ), this.events["change:proxyWorkerHost"].dispatch(t);
    }), this.proxyTranslationStatusSelect.addEventListener(
      "selectItem",
      async (t) => {
        this.data.translateProxyEnabled = Number.parseInt(
          t,
          10
        ), await C.set(
          "translateProxyEnabled",
          this.data.translateProxyEnabled
        ), await C.set("translateProxyEnabledDefault", !1), V.log(
          "translateProxyEnabled value changed. New value:",
          this.data.translateProxyEnabled
        ), this.events["select:proxyTranslationStatus"].dispatch(t);
      }
    ), this.bindPersistedSetting({
      control: this.translateAPIErrorsCheckbox,
      event: "change",
      apply: (t) => {
        this.data.translateAPIErrors = t;
      },
      storageKey: "translateAPIErrors",
      readPersistedValue: () => this.data.translateAPIErrors,
      logLabel: "translateAPIErrors"
    }), this.bindPersistedSetting({
      control: this.useNewAudioPlayerCheckbox,
      event: "change",
      apply: (t) => {
        this.data.newAudioPlayer = t, this.onlyBypassMediaCSPCheckbox.disabled = this.onlyBypassMediaCSPCheckbox.hidden = !t;
      },
      storageKey: "newAudioPlayer",
      readPersistedValue: () => this.data.newAudioPlayer,
      logLabel: "newAudioPlayer",
      dispatch: (t) => this.events["change:useNewAudioPlayer"].dispatch(t)
    }), this.bindPersistedSetting({
      control: this.onlyBypassMediaCSPCheckbox,
      event: "change",
      apply: (t) => {
        this.data.onlyBypassMediaCSP = t;
      },
      storageKey: "onlyBypassMediaCSP",
      readPersistedValue: () => this.data.onlyBypassMediaCSP,
      logLabel: "onlyBypassMediaCSP",
      dispatch: (t) => this.events["change:onlyBypassMediaCSP"].dispatch(t)
    }), this.bindPersistedSetting({
      control: this.translationTextServiceSelect,
      event: "selectItem",
      apply: (t) => {
        this.data.translationService = t;
      },
      storageKey: "translationService",
      readPersistedValue: () => this.data.translationService,
      logLabel: "translationService",
      dispatch: (t) => this.events["select:translationTextService"].dispatch(t)
    }), this.bindPersistedSetting({
      control: this.detectServiceSelect,
      event: "selectItem",
      apply: (t) => {
        this.data.detectService = t;
      },
      storageKey: "detectService",
      readPersistedValue: () => this.data.detectService,
      logLabel: "detectService"
    }), this.bindPersistedSetting({
      control: this.showPiPButtonCheckbox,
      event: "change",
      apply: (t) => {
        this.data.showPiPButton = t;
      },
      storageKey: "showPiPButton",
      readPersistedValue: () => this.data.showPiPButton,
      logLabel: "showPiPButton",
      dispatch: (t) => this.events["change:showPiPButton"].dispatch(t)
    }), this.autoHideButtonDelaySlider.addEventListener("input", (t) => {
      this.autoHideButtonDelaySliderLabel.value = t;
      const e = Math.round(t * 1e3);
      this.data.autoHideButtonDelay = e, this.scheduleStoragePersist(
        "autoHideButtonDelay",
        this.data.autoHideButtonDelay
      ), this.events["input:autoHideButtonDelay"].dispatch(t);
    }), this.bindPersistedSetting({
      control: this.buttonPositionSelect,
      event: "selectItem",
      apply: (t) => {
        this.data.buttonPos = t;
      },
      storageKey: "buttonPos",
      readPersistedValue: () => this.data.buttonPos,
      logLabel: "buttonPos",
      dispatch: (t) => this.events["select:buttonPosition"].dispatch(t)
    }), this.menuLanguageSelect.addEventListener("selectItem", async (t) => {
      await p.changeLang(t) && (this.data.localeUpdatedAt = await C.get("localeUpdatedAt", 0), this.events["select:menuLanguage"].dispatch(t));
    }), this.bugReportButton.addEventListener(
      "click",
      () => this.events["click:bugReport"].dispatch()
    ), this.resetSettingsButton.addEventListener(
      "click",
      () => this.events["click:resetSettings"].dispatch()
    ), this;
  }
  addEventListener(t, e) {
    return this.events[t].addListener(e), this;
  }
  removeEventListener(t, e) {
    return this.events[t].removeListener(e), this;
  }
  doReleaseUI() {
    this.dialog?.remove();
    for (const t of [
      this.accountButtonRefreshTooltip,
      this.accountButtonTokenTooltip,
      this.audioBoosterTooltip,
      this.useLivelyVoiceTooltip,
      this.useAudioDownloadCheckboxTooltip,
      this.useNewAudioPlayerTooltip,
      this.onlyBypassMediaCSPTooltip,
      this.translationTextServiceTooltip,
      this.proxyTranslationStatusSelectTooltip,
      this.buttonPositionTooltip
    ])
      t?.release();
  }
  doReleaseUIEvents() {
    this.flushStoragePersists();
    for (const t of Object.values(this.events)) t.clear();
  }
  release() {
    return this.isInitialized() ? (this.doReleaseUIEvents(), this.doReleaseUI(), this.initialized = !1, this) : this;
  }
  updateAccountInfo() {
    if (!this.isInitialized())
      throw new Error("[VOT] SettingsView isn't initialized");
    const t = !!this.data.account?.token;
    return this.accountButton.avatarId = this.data.account?.avatarId, this.useLivelyVoiceTooltip.hidden = this.accountButton.loggedIn = t, this.accountButton.username = this.data.account?.username, this.useLivelyVoiceCheckbox.disabled = !t, this.events["update:account"].dispatch(this.data.account), this;
  }
  open() {
    if (!this.isInitialized())
      throw new Error("[VOT] SettingsView isn't initialized");
    return this.dialog.open();
  }
  close() {
    if (!this.isInitialized())
      throw new Error("[VOT] SettingsView isn't initialized");
    return this.dialog.close();
  }
};
c(gi, "PERSIST_DELAY_MS", 250);
let xs = gi;
class Dv {
  constructor({
    mount: t,
    data: e = {},
    videoHandler: i,
    intervalIdleChecker: s
  }) {
    c(this, "mount");
    c(this, "translationActionInFlight", !1);
    c(this, "overlayEventsBound", !1);
    c(this, "settingsEventsBound", !1);
    c(this, "initialized", !1);
    c(this, "videoHandler");
    c(this, "intervalIdleChecker");
    c(this, "data");
    c(this, "votGlobalPortal");
    /**
     * Contains all elements over video player e.g. button, menu and etc
     */
    c(this, "votOverlayView");
    /**
     * Dialog settings menu
     */
    c(this, "votSettingsView");
    this.mount = t, this.videoHandler = i, this.data = e, this.intervalIdleChecker = s;
  }
  get root() {
    return this.mount.root;
  }
  get portalContainer() {
    return this.mount.portalContainer;
  }
  get tooltipLayoutRoot() {
    return this.mount.tooltipLayoutRoot;
  }
  getSubtitlesMountContainer() {
    return this.votOverlayView?.root ?? this.mount.subtitlesMountContainer;
  }
  isInitialized() {
    return this.initialized;
  }
  initUI() {
    if (this.isInitialized())
      throw new Error("[VOT] UIManager is already initialized");
    return this.initialized = !0, this.votGlobalPortal = L.createPortal(), this.getGlobalPortalHost(this.mount).appendChild(this.votGlobalPortal), this.votOverlayView = new Ls({
      mount: this.mount,
      globalPortal: this.votGlobalPortal,
      data: this.data,
      videoHandler: this.videoHandler,
      intervalIdleChecker: this.intervalIdleChecker
    }), this.votOverlayView.initUI(this.data.buttonPos ?? "default"), this.votSettingsView = new xs({
      globalPortal: this.votGlobalPortal,
      data: this.data,
      videoHandler: this.videoHandler
    }), this.votSettingsView.initUI(), this.videoHandler?.subtitlesWidget?.updateMount({
      container: this.getSubtitlesMountContainer(),
      tooltipLayoutRoot: this.mount.tooltipLayoutRoot
    }), this;
  }
  updateMount(t) {
    const e = this.getGlobalPortalHost(t);
    return this.votGlobalPortal?.parentElement !== e && e.appendChild(this.votGlobalPortal), this.mount = sv(this.mount, t, (i) => {
      this.votOverlayView?.updateMount(i);
    }), this.videoHandler?.subtitlesWidget?.updateMount({
      container: this.getSubtitlesMountContainer(),
      tooltipLayoutRoot: t.tooltipLayoutRoot
    }), this;
  }
  getGlobalPortalHost(t) {
    const e = document, i = e.fullscreenElement ?? e.webkitFullscreenElement;
    return !!Zs(i, [t.root], {
      allowDocumentViewport: !0
    }) ? t.root : document.documentElement;
  }
  initUIEvents() {
    if (!this.isInitialized())
      throw new Error("[VOT] UIManager isn't initialized");
    this.votOverlayView.initUIEvents(), this.overlayEventsBound || (this.bindOverlayViewEvents(), this.overlayEventsBound = !0), this.votSettingsView.initUIEvents(), this.settingsEventsBound || (this.bindSettingsViewEvents(), this.settingsEventsBound = !0);
  }
  bindOverlayViewEvents() {
    const t = this.votOverlayView;
    t && t.addEventListener("click:translate", async () => {
      await this.handleTranslationBtnClick();
    }).addEventListener("click:pip", async () => {
      if (this.videoHandler)
        try {
          await (this.videoHandler.video === document.pictureInPictureElement ? document.exitPictureInPicture() : this.videoHandler.video.requestPictureInPicture());
        } catch {
        }
    }).addEventListener("click:settings", async () => {
      this.videoHandler?.subtitlesWidget?.releaseTooltip(), this.videoHandler?.overlayVisibility?.cancel(), this.videoHandler?.overlayVisibility?.show(), this.votSettingsView.open();
    }).addEventListener("click:downloadTranslation", async () => {
      await this.handleDownloadTranslationClick();
    }).addEventListener("click:downloadSubtitles", async () => {
      await this.handleDownloadSubtitlesClick();
    }).addEventListener("input:videoVolume", (e) => {
      if (this.videoHandler) {
        if (this.videoHandler.setVideoVolume(e / 100), !this.data.syncVolume) {
          this.videoHandler.onVideoVolumeSliderSynced(e);
          return;
        }
        this.videoHandler.syncVolumeWrapper("video", e);
      }
    }).addEventListener("input:translationVolume", (e) => {
      if (!this.videoHandler)
        return;
      const i = e ?? this.data.defaultVolume ?? 100;
      if (this.videoHandler.syncTranslationPlaybackVolume(), !this.data.syncVolume) {
        this.videoHandler.onTranslationVolumeSliderSynced(i);
        return;
      }
      const s = this.videoHandler.syncVolumeWrapper(
        "translation",
        i
      );
      typeof s?.nextVideo == "number" && this.videoHandler.applyManualVideoVolumeOverride(
        s.nextVideo / 100
      );
    }).addEventListener("select:subtitles", (e) => {
      this.videoHandler && this.runDetached(
        this.videoHandler.changeSubtitlesLang(e),
        "Failed to change subtitles language"
      );
    });
  }
  bindSettingsViewEvents() {
    const t = this.votSettingsView;
    t && t.addEventListener("update:account", async (e) => {
      this.videoHandler && (this.videoHandler.votClient.apiToken = e?.token);
    }).addEventListener("change:autoTranslate", async (e) => {
      const i = this.videoHandler;
      e && i && !i.hasActiveSource() && await this.handleTranslationBtnClick();
    }).addEventListener("change:autoSubtitles", async (e) => {
      !e || !this.videoHandler?.videoData?.videoId || await this.videoHandler.enableSubtitlesForCurrentLangPair();
    }).addEventListener("change:showVideoVolume", () => {
      this.withInitializedOverlayView((e) => {
        !e.videoVolumeSlider || !e.votButton || (e.videoVolumeSlider.container.hidden = !this.data.showVideoSlider || e.votButton.status !== "success");
      });
    }).addEventListener("change:audioBooster", async () => {
      this.withInitializedOverlayView((e) => {
        if (!e.translationVolumeSlider)
          return;
        const i = e.translationVolumeSlider.value, s = this.data.audioBooster ? El : 100;
        e.translationVolumeSlider.max = s;
        const o = W(i, 0, s);
        e.translationVolumeSlider.value = o, this.videoHandler?.onTranslationVolumeSliderSynced(o), this.videoHandler?.syncTranslationPlaybackVolume();
      });
    }).addEventListener("change:syncVolume", (e) => {
      this.videoHandler && (this.videoHandler.setupAudioSettings(), e && this.withInitializedOverlayView((i) => {
        const s = i.videoVolumeSlider, o = i.translationVolumeSlider;
        !s || !o || (this.videoHandler.syncTranslationPlaybackVolume(), this.videoHandler.resetVolumeLinkState(
          Number(s.value),
          Number(o.value)
        ));
      }));
    }).addEventListener("change:useLivelyVoice", () => {
      !this.videoHandler || this.votOverlayView?.votButton?.loading === !0 || this.videoHandler.hadAsyncWait || this.runDetached(
        this.videoHandler.stopTranslate(),
        "Failed to stop translation after voice mode change"
      );
    }).addEventListener("change:subtitlesHighlightWords", (e) => {
      this.updateSubtitlesWidgetSetting(
        e,
        this.data.highlightWords,
        (i, s) => {
          i.setHighlightWords(s);
        }
      );
    }).addEventListener("change:subtitlesSmartLayout", (e) => {
      this.updateSubtitlesWidgetSetting(
        e,
        this.data.subtitlesSmartLayout,
        (i, s) => {
          i.setSmartLayout(s);
        }
      );
    }).addEventListener("input:subtitlesMaxLength", (e) => {
      this.updateSubtitlesWidgetSetting(
        e,
        this.data.subtitlesMaxLength,
        (i, s) => {
          i.setMaxLength(s);
        }
      );
    }).addEventListener("input:subtitlesFontSize", (e) => {
      this.updateSubtitlesWidgetSetting(
        e,
        this.data.subtitlesFontSize,
        (i, s) => {
          i.setFontSize(s);
        }
      );
    }).addEventListener("select:subtitlesFontFamily", (e) => {
      this.updateSubtitlesWidgetSetting(
        e,
        this.data.subtitlesFontFamily,
        (i, s) => {
          i.setFontFamily(s);
        }
      );
    }).addEventListener("input:subtitlesBackgroundOpacity", (e) => {
      this.updateSubtitlesWidgetSetting(
        e,
        this.data.subtitlesOpacity,
        (i, s) => {
          i.setOpacity(s);
        }
      );
    }).addEventListener("change:proxyWorkerHost", (e) => {
      this.videoHandler && this.runDetached(
        this.videoHandler.handleProxySettingsChanged("proxyWorkerHost"),
        "Failed to apply proxyWorkerHost change"
      );
    }).addEventListener("select:proxyTranslationStatus", () => {
      this.videoHandler && this.runDetached(
        this.videoHandler.handleProxySettingsChanged(
          "proxyTranslationStatus"
        ),
        "Failed to apply proxyTranslationStatus change"
      );
    }).addEventListener("change:useNewAudioPlayer", () => {
      this.restartAudioPlayer();
    }).addEventListener("change:onlyBypassMediaCSP", () => {
      this.restartAudioPlayer();
    }).addEventListener("select:translationTextService", () => {
      this.withSubtitlesWidget((e) => {
        e.resetTranslationContext(!0);
      });
    }).addEventListener("change:showPiPButton", () => {
      this.withInitializedOverlayView((e) => {
        e.votButton && (e.votButton.pipButton.hidden = e.votButton.separator2.hidden = !e.pipButtonVisible);
      });
    }).addEventListener("select:buttonPosition", (e) => {
      this.withInitializedOverlayView((i) => {
        const s = this.data.buttonPos ?? e, { position: o, direction: r } = i.calcButtonLayout(s);
        i.updateButtonLayout(o, r);
      });
    }).addEventListener("select:menuLanguage", async () => {
      await this.reloadMenu();
    }).addEventListener("click:bugReport", () => {
      if (!this.videoHandler)
        return;
      const e = new URLSearchParams(
        this.videoHandler.collectReportInfo()
      ).toString();
      globalThis.open(`${jd}/issues/new?${e}`, "_blank")?.focus();
    }).addEventListener("click:resetSettings", async () => {
      const e = await C.list();
      await Promise.all(e.map((i) => C.delete(i))), await C.set("compatVersion", an), globalThis.location.reload();
    });
  }
  async downloadCurrentSubtitles() {
    await this.handleDownloadSubtitlesClick();
  }
  async handleDownloadTranslationClick() {
    const t = this.votOverlayView, e = this.videoHandler;
    if (!t?.isInitialized() || !e?.downloadTranslationUrl || !e.videoData)
      return;
    const i = t.downloadTranslationButton, s = e.downloadTranslationUrl, o = this.data.downloadWithName ? ur(e.getDownloadBaseName()) : `translation_${e.videoData.videoId}`, a = { preferShare: this.isLikelyMobileDownloadContext() }, l = (u) => {
      i && (i.progress = u);
    };
    l(0);
    try {
      await this.downloadTranslationAudio(
        s,
        o,
        l,
        a
      );
    } catch (u) {
      console.error("[VOT] Download translation failed:", u), this.triggerUrlDownload(s, `${o}.mp3`) || globalThis.open(s, "_blank")?.focus();
    } finally {
      l(0);
    }
  }
  async downloadTranslationAudio(t, e, i, s) {
    const o = await nt(t, { timeout: 0 });
    if (!o.ok)
      throw new Error(`HTTP ${o.status}`);
    await nv(o, e, i, s);
  }
  async handleDownloadSubtitlesClick() {
    const t = this.videoHandler;
    if (!t?.yandexSubtitles || !t.videoData)
      return;
    const e = this.data.subtitlesDownloadFormat ?? "json", i = Jy(
      t.yandexSubtitles,
      e,
      {
        assTitle: t.videoData.localizedTitle ?? t.videoData.title ?? t.videoData.downloadTitle
      }
    ), s = new Blob(
      [
        e === "json" ? JSON.stringify(i) : i
      ],
      {
        type: "text/plain"
      }
    ), r = `${this.data.downloadWithName ? ur(t.getDownloadBaseName()) : `subtitles_${t.videoData.videoId}`}.${e}`, l = { preferShare: this.isLikelyMobileDownloadContext() };
    await Il(s, r, l);
  }
  async reloadMenu() {
    if (!this.votOverlayView?.isInitialized())
      throw new Error("[VOT] OverlayView isn't initialized");
    const t = this.votOverlayView.votButton.opacity, e = this.votOverlayView.votButton.container.hidden, i = this.votOverlayView.votMenu.hidden, s = this.data.buttonPos ?? "default", o = this.votSettingsView?.dialog?.container?.hidden === !1;
    if (await this.videoHandler?.stopTranslation(), this.release(), this.initUI(), this.initUIEvents(), !this.videoHandler)
      return this;
    try {
      const { position: a, direction: l } = this.votOverlayView.calcButtonLayout(s);
      this.votOverlayView.updateButtonLayout(a, l), this.votOverlayView.votMenu.hidden = i, this.votOverlayView.votButton.container.hidden = e, this.votOverlayView.votButton.opacity = t;
    } catch {
    }
    try {
      this.videoHandler.rebindOverlayVisibilityTargets();
    } catch {
    }
    if (o)
      try {
        this.votSettingsView?.open();
      } catch {
      }
    await this.videoHandler.updateSubtitlesLangSelect();
    const r = this.videoHandler.subtitlesWidget;
    return r && r.resetTranslationContext(!0), this;
  }
  async handleTranslationBtnClick() {
    if (!this.votOverlayView?.isInitialized())
      throw new Error("[VOT] OverlayView isn't initialized");
    const t = this.videoHandler;
    if (!t)
      return this;
    if (t.isAwaitingAutoplayRecovery())
      return await t.resumePendingAutoplayRecovery("button"), this;
    if (t.hasActiveSource())
      return await t.stopTranslation(), this;
    if (this.translationActionInFlight || this.votOverlayView.votButton.loading)
      return this;
    this.translationActionInFlight = !0;
    try {
      this.votOverlayView.votButton.status === "error" ? this.transformBtn("none", p.get("translateVideo")) : this.votOverlayView.votButton.status !== "none" && !t.hasActiveSource() && (V.log("[handleTranslationBtnClick] reset stale button state"), this.transformBtn("none", p.get("translateVideo"))), V.log("[handleTranslationBtnClick] trying execute translation"), await t.primePlaybackByGesture("translate-button");
      const e = await this.getVideoDataForTranslation(t);
      await t.videoManager.ensureDetectedLanguageForTranslation(
        e
      ), V.log(
        "[handleTranslationBtnClick] Run translateFunc",
        e.videoId
      ), await t.translateFunc(
        e.videoId,
        e.isStream,
        e.detectedLanguage,
        e.responseLanguage,
        e.translationHelp
      );
    } catch (e) {
      if (this.isAbortError(e))
        return this.transformBtn("none", p.get("translateVideo")), this;
      if (console.error("[VOT]", e), !(e instanceof Error))
        return this.transformBtn("error", String(e)), this;
      const i = e.name === "VOTLocalizedError" ? e.localizedMessage : e.message;
      this.transformBtn("error", i);
    } finally {
      this.translationActionInFlight = !1;
    }
    return this;
  }
  async getVideoDataForTranslation(t) {
    if (t.videoData?.videoId || (t.videoData = await t.getVideoData()), this.shouldRefreshVideoDataBeforeTranslation(t) && (t.videoData = await t.getVideoData()), !t.videoData?.videoId)
      throw new ft("VOTNoVideoIDFound");
    return t.videoData;
  }
  shouldRefreshVideoDataBeforeTranslation(t) {
    return t.site.host === "vk" && t.site.additionalData === "clips" || t.site.host === "douyin";
  }
  isAbortError(t) {
    return t instanceof Error && t.name === "AbortError";
  }
  isLoadingText(t) {
    const e = p.get("TranslationDelayed");
    return typeof t == "string" && (t.includes(p.get("translationTake")) || (e ? t.includes(e) : !1));
  }
  transformBtn(t, e) {
    if (!this.votOverlayView?.isInitialized())
      throw new Error("[VOT] OverlayView isn't initialized");
    return this.votOverlayView.votButton.status = t, this.votOverlayView.votButton.loading = t === "error" && this.isLoadingText(e), this.votOverlayView.votButton.setText(e), this.votOverlayView.votButtonTooltip.setContent(e), this;
  }
  release() {
    return this.isInitialized() ? (this.votOverlayView.release(), this.votSettingsView.release(), this.votGlobalPortal.remove(), this.initialized = !1, this) : this;
  }
  withInitializedOverlayView(t) {
    this.votOverlayView?.isInitialized() && t(this.votOverlayView);
  }
  withSubtitlesWidget(t) {
    const e = this.videoHandler?.subtitlesWidget;
    e && t(e);
  }
  updateSubtitlesWidgetSetting(t, e, i) {
    this.withSubtitlesWidget((s) => {
      i(s, e ?? t);
    });
  }
  runDetached(t, e) {
    t.catch((i) => {
    });
  }
  triggerUrlDownload(t, e) {
    try {
      const i = document.createElement("a");
      return i.href = t, i.download = e, i.target = "_blank", i.rel = "noopener noreferrer", i.style.display = "none", document.body.appendChild(i), i.click(), i.remove(), !0;
    } catch {
      return !1;
    }
  }
  isLikelyMobileDownloadContext() {
    return this.videoHandler?.site.additionalData === "mobile" ? !0 : typeof matchMedia == "function" && matchMedia("(pointer: coarse)").matches;
  }
  restartAudioPlayer() {
    this.restartAudioPlayerSafely();
  }
  async restartAudioPlayerSafely() {
    const t = this.videoHandler;
    if (t)
      try {
        await t.stopTranslate(), t.createPlayer();
      } catch {
      }
  }
}
class _v {
  constructor(t) {
    c(this, "deps");
    c(this, "hideDeadlineMs", 0);
    c(this, "hideArmed", !1);
    c(this, "unsubscribeChecker");
    this.deps = t, this.unsubscribeChecker = this.deps.checker.subscribe(() => {
      this.onCheckerTick();
    });
  }
  /**
   * Ensures overlay is visible immediately and returns current view.
   */
  show() {
    const t = this.getView();
    return t ? (t.updateButtonOpacity(1), t) : null;
  }
  /**
   * Cancels scheduled auto-hide.
   */
  cancel() {
    this.hideDeadlineMs = 0, this.hideArmed = !1;
  }
  release() {
    this.cancel(), this.unsubscribeChecker();
  }
  /**
   * Schedules overlay auto-hide after configured delay.
   */
  queueAutoHide() {
    if (!this.show())
      return;
    const t = this.deps.getAutoHideDelay();
    this.hideDeadlineMs = this.nowMs() + Math.max(0, t), this.hideArmed = !0, this.deps.checker.markActivity("overlay-queue-hide"), this.deps.checker.requestImmediateTick();
  }
  /**
   * Handles pointer/focus interactions originating from overlay elements.
   */
  handleOverlayInteraction(t) {
    const e = t?.type;
    if (e) {
      if (e === "focusin") {
        this.handleFocusIn();
        return;
      }
      if (e.startsWith("pointer")) {
        this.cancel(), this.show(), this.deps.checker.markActivity("overlay-interaction"), t.stopPropagation?.();
        return;
      }
      this.handleHostInteraction(t);
    }
  }
  /**
   * Handles interactions from the broader host container (video, document etc.).
   */
  handleHostInteraction(t) {
    const e = t?.type;
    if (e) {
      if (e === "focusin") {
        this.handleFocusIn();
        return;
      }
      if (e.startsWith("pointer")) {
        const i = t.target;
        this.deps.isInteractiveNode(i) && t.stopPropagation?.(), this.deps.checker.markActivity("overlay-host-pointer");
      }
      this.queueAutoHide();
    }
  }
  /**
   * Schedules hide if focus leaves overlay tree entirely.
   */
  scheduleHide(t) {
    if (!this.getView())
      return;
    const e = t?.currentTarget;
    let i = t?.relatedTarget ?? null;
    !i && typeof t?.composedPath == "function" && (i = t.composedPath()[1] ?? null);
    const s = i instanceof Node ? i : null, o = e instanceof Node ? e : null;
    s && (o?.contains(s) || this.deps.isInteractiveNode(s)) || this.queueAutoHide();
  }
  onCheckerTick() {
    if (!this.hideArmed || this.hideDeadlineMs <= 0 || this.nowMs() + 2 < this.hideDeadlineMs)
      return;
    this.hideArmed = !1;
    let e = null;
    if (typeof document < "u" && typeof document.hasFocus == "function" && document.hasFocus() && (e = document.activeElement), e && this.deps.isInteractiveNode(e))
      return;
    this.getView()?.updateButtonOpacity(0);
  }
  handleFocusIn() {
    this.cancel(), this.show(), this.deps.checker.markActivity("overlay-focus-in");
  }
  getView() {
    const t = this.deps.getOverlayView();
    return t?.isInitialized() ? t : null;
  }
  nowMs() {
    return this.deps.nowMs ? this.deps.nowMs() : typeof performance < "u" && typeof performance.now == "function" ? performance.now() : Date.now();
  }
}
const Va = {
  checkIntervalMs: 250,
  idleAfterMs: 180
};
function Rv(n, t) {
  return typeof n != "number" || !Number.isFinite(n) ? t : Math.max(1, Math.trunc(n));
}
function Bv(n, t) {
  return typeof n != "number" || !Number.isFinite(n) ? t : Math.max(0, Math.trunc(n));
}
function Fv(n = {}) {
  return {
    checkIntervalMs: Rv(
      n.checkIntervalMs,
      Va.checkIntervalMs
    ),
    idleAfterMs: Bv(
      n.idleAfterMs,
      Va.idleAfterMs
    )
  };
}
function Nv() {
  return {
    nowMs: () => typeof performance < "u" && typeof performance.now == "function" ? performance.now() : Date.now(),
    setInterval: globalThis.setInterval.bind(globalThis),
    clearInterval: globalThis.clearInterval.bind(globalThis),
    queueMicrotask: (n) => {
      if (typeof globalThis.queueMicrotask == "function") {
        globalThis.queueMicrotask(n);
        return;
      }
      Promise.resolve().then(n);
    },
    isDocumentHidden: () => typeof document < "u" && typeof document.hidden == "boolean" ? document.hidden : !1,
    onVisibilityChange: (n) => typeof document > "u" || typeof document.addEventListener != "function" ? () => {
    } : (document.addEventListener("visibilitychange", n), () => {
      typeof document.removeEventListener == "function" && document.removeEventListener("visibilitychange", n);
    })
  };
}
class Uv {
  constructor(t = {}) {
    c(this, "profile");
    c(this, "runtime");
    c(this, "subscribers", /* @__PURE__ */ new Set());
    c(this, "intervalId", null);
    c(this, "unsubscribeVisibilityChange", null);
    c(this, "running", !1);
    c(this, "destroyed", !1);
    c(this, "immediateQueued", !1);
    c(this, "currentMode", "active");
    c(this, "lastActivityAt");
    c(this, "onVisibilityChangeHandler", () => {
      this.destroyed || !this.running || (this.runtime.isDocumentHidden() ? this.clearIntervalTimer() : this.armInterval(), this.requestImmediateTick());
    });
    this.profile = Fv(t.profile), this.runtime = {
      ...Nv(),
      ...t.runtime
    }, this.lastActivityAt = this.runtime.nowMs();
  }
  start() {
    this.destroyed || this.running || (this.running = !0, this.lastActivityAt = this.runtime.nowMs(), this.subscribeVisibilityChange(), this.armInterval(), this.runTick("start"));
  }
  stop() {
    this.running && (this.running = !1, this.clearIntervalTimer(), this.immediateQueued = !1, this.unsubscribeFromVisibilityChange());
  }
  destroy() {
    this.destroyed || (this.stop(), this.subscribers.clear(), this.destroyed = !0);
  }
  subscribe(t) {
    return this.destroyed ? () => {
    } : (this.subscribers.add(t), () => {
      this.subscribers.delete(t);
    });
  }
  markActivity(t) {
    if (this.destroyed || (this.lastActivityAt = this.runtime.nowMs(), !this.running)) return;
    const e = this.resolveMode(this.lastActivityAt);
    e !== this.currentMode && (this.currentMode = e);
  }
  requestImmediateTick() {
    this.destroyed || !this.running || this.immediateQueued || (this.immediateQueued = !0, this.runtime.queueMicrotask(() => {
      this.immediateQueued = !1, !(this.destroyed || !this.running) && this.runTick("immediate");
    }));
  }
  resolveMode(t) {
    return this.runtime.isDocumentHidden() ? "hidden" : t - this.lastActivityAt >= this.profile.idleAfterMs ? "idle" : "active";
  }
  clearIntervalTimer() {
    this.intervalId !== null && (this.runtime.clearInterval(this.intervalId), this.intervalId = null);
  }
  armInterval() {
    this.intervalId === null && (this.intervalId = this.runtime.setInterval(() => {
      this.runTick("interval");
    }, this.profile.checkIntervalMs));
  }
  runTick(t) {
    if (this.destroyed || !this.running || this.subscribers.size === 0) return;
    const e = this.runtime.nowMs(), i = this.resolveMode(e);
    i !== this.currentMode && (this.currentMode = i);
    const s = {
      nowMs: e,
      mode: i,
      source: t
    };
    for (const o of this.subscribers)
      try {
        o(s);
      } catch {
      }
  }
  subscribeVisibilityChange() {
    this.unsubscribeVisibilityChange === null && (this.unsubscribeVisibilityChange = this.runtime.onVisibilityChange(
      this.onVisibilityChangeHandler
    ));
  }
  unsubscribeFromVisibilityChange() {
    this.unsubscribeVisibilityChange !== null && (this.unsubscribeVisibilityChange(), this.unsubscribeVisibilityChange = null);
  }
}
function oo(n) {
  return new Uv({ profile: n });
}
const gc = () => Date.now();
function Ji() {
  return GM_info?.script?.name || "VOT";
}
function mc(n, t) {
  try {
    return p?.get?.(n) || t;
  } catch {
    return t;
  }
}
function Hv(n, t, e) {
  if (!e) return !0;
  const i = n.get(t) ?? 0;
  return gc() - i >= e;
}
function $v(n, t) {
  n.set(t, gc());
}
function Zi(n) {
  const t = n.trim();
  if (!t) return null;
  try {
    const e = p.get(t), i = p.getDefault(t);
    return e !== t || i !== t ? e || i || t : null;
  } catch {
    return null;
  }
}
function Wv(n) {
  if (n && typeof n == "object") {
    const e = n;
    if (e.name === "VOTLocalizedError") {
      if (typeof e.localizedMessage == "string" && e.localizedMessage.trim())
        return e.localizedMessage;
      if (typeof e.unlocalizedMessage == "string") {
        const i = Zi(
          e.unlocalizedMessage
        );
        if (i) return i;
      }
    }
  }
  if (typeof n == "string") {
    const e = Zi(n);
    if (e) return e;
  }
  const t = yi(n);
  return t ? Zi(t) || t : mc("requestTranslationFailed", "Translation failed");
}
function zv(n) {
  try {
    if (typeof GM_notification == "function")
      return GM_notification(n), !0;
    const t = globalThis.GM;
    if (t !== void 0 && typeof t.notification == "function") {
      const e = {
        text: n.text,
        title: n.title,
        image: n.image,
        onclick: n.onclick,
        ondone: n.ondone
      };
      return t.notification(e), !0;
    }
  } catch {
  }
  return !1;
}
class qv {
  constructor() {
    c(this, "lastSentAt", /* @__PURE__ */ new Map());
  }
  send(t, e = {}) {
    try {
      const i = e.key || t.tag || `${t.title ?? ""}|${t.text ?? ""}`, s = e.cooldownMs ?? 0;
      if (!Hv(this.lastSentAt, i, s)) return;
      const o = {
        ...t,
        title: t.title ?? Ji()
      };
      zv(o) ? $v(this.lastSentAt, i) : V.log("[notify] unavailable", o);
    } catch {
    }
  }
  translationCompleted(t) {
    const e = mc(
      "VOTTranslationCompletedNotify",
      "The translation on the {0} has been completed!"
    ).replace("{0}", t);
    this.send(
      {
        text: e,
        title: Ji(),
        timeout: 5e3,
        silent: !0,
        tag: "VOTTranslationCompleted",
        onclick: () => {
          try {
            globalThis.focus();
          } catch {
          }
        }
      },
      { key: `translation_completed_${t}`, cooldownMs: 1e4 }
    );
  }
  translationFailed(t) {
    const { videoId: e, message: i } = t;
    if (ln(i)) return;
    const s = Wv(i), o = Ji();
    this.send(
      {
        text: s,
        title: o,
        timeout: 8e3,
        silent: !0,
        // Keep legacy tag casing so existing notification replacement/dedupe continues to work.
        tag: `VOTtranslationFailed_${e || "unknown"}`,
        onclick: () => {
          try {
            globalThis.focus();
          } catch {
          }
        }
      },
      // Errors can loop while polling; keep these non-spammy.
      { key: `translation_failed_${e || "unknown"}`, cooldownMs: 3e4 }
    );
  }
}
const Gv = ["class", "id", "title"], Kv = [
  "advertise",
  "advertisement",
  "promo",
  "sponsor",
  "banner",
  "commercial",
  "preroll",
  "midroll",
  "postroll",
  "ad-container",
  "sponsored"
], Yv = new RegExp(
  Kv.map(
    (n) => n.replaceAll(/[.*+?^${}()|[\]\\]/g, String.raw`\$&`)
  ).join("|")
), ri = /* @__PURE__ */ Symbol.for("vot.attachShadowHook"), Ke = {
  preferProbeBootstrap: !1,
  startDomObservationOnEnable: !0,
  probeStrategy: "mutation",
  probeSelectors: ["video"],
  probePollIntervalMs: 75,
  probePollTimeoutMs: 4e3,
  stopAfterFirstVideoDetected: !1,
  keepWatchingAfterVideoDetected: !0,
  observeShadowRoots: !0,
  shadowHostSelectors: []
};
function jv() {
  const n = Object.getOwnPropertyDescriptor(
    Element.prototype,
    "attachShadow"
  );
  return !n || typeof n.value != "function" ? null : n;
}
function Xv() {
  const n = globalThis, t = n[ri];
  if (t?.descriptor && t.subscribers instanceof Set)
    return t;
  const e = jv();
  if (!e) return null;
  const i = e.value, s = {
    descriptor: e,
    subscribers: /* @__PURE__ */ new Set()
  }, o = function(r) {
    const a = i.call(this, r);
    for (const l of s.subscribers)
      try {
        l(a);
      } catch {
      }
    return a;
  };
  try {
    Object.defineProperty(Element.prototype, "attachShadow", {
      ...e,
      value: o
    });
  } catch {
    return null;
  }
  return n[ri] = s, s;
}
function Jv(n) {
  const t = globalThis, e = t[ri];
  if (e && (e.subscribers.delete(n), !(e.subscribers.size > 0))) {
    try {
      Object.defineProperty(Element.prototype, "attachShadow", e.descriptor);
    } catch {
      const i = e.descriptor.value;
      typeof i == "function" && (Element.prototype.attachShadow = i);
    }
    delete t[ri];
  }
}
const Qt = class Qt {
  constructor(t = oo()) {
    c(this, "seenVideos", /* @__PURE__ */ new WeakSet());
    c(this, "activeVideos", /* @__PURE__ */ new WeakSet());
    c(this, "observedRoots", /* @__PURE__ */ new WeakSet());
    c(this, "videoListenerControllers", /* @__PURE__ */ new Map());
    c(this, "pendingAdded", /* @__PURE__ */ new Set());
    c(this, "pendingRemoved", /* @__PURE__ */ new Set());
    c(this, "flushPending", !1);
    c(this, "onVideoAdded", new U());
    c(this, "onVideoRemoved", new U());
    c(this, "observer", new MutationObserver(
      (t) => this.onMutations(t)
    ));
    c(this, "intervalIdleChecker");
    c(this, "checkerUnsubscribe", null);
    c(this, "enabled", !1);
    c(this, "attachShadowSubscriber", null);
    c(this, "onDocumentReady", null);
    c(this, "policy", Ke);
    c(this, "flushSlice", () => {
      if (!this.enabled) {
        this.pendingAdded.clear(), this.pendingRemoved.clear(), this.flushPending = !1;
        return;
      }
      const t = this.getNowMs(), e = this.processPendingAdded(t);
      this.processPendingRemoved(t, e), this.flushPending = this.pendingAdded.size > 0 || this.pendingRemoved.size > 0, this.flushPending && this.intervalIdleChecker.requestImmediateTick();
    });
    c(this, "onCheckerTick", () => {
      this.flushPending && this.flushSlice();
    });
    c(this, "scheduleFlush", () => {
      this.enabled && (this.flushPending = !0, this.intervalIdleChecker.requestImmediateTick());
    });
    c(this, "onPageShow", () => {
      const t = document.documentElement;
      t && (this.canObserveRoots() && this.observeRoot(t), this.scan(t));
    });
    c(this, "checkUrlChange", () => {
      this.stopObservingDom();
      const t = document.documentElement;
      t && (this.canObserveRoots() && this.observeRoot(t), this.scan(t));
    });
    this.intervalIdleChecker = t;
  }
  setPolicy(t) {
    this.policy = {
      ...Ke,
      ...t,
      probeSelectors: Array.isArray(t.probeSelectors) && t.probeSelectors.length > 0 ? [...t.probeSelectors] : [...Ke.probeSelectors],
      shadowHostSelectors: Array.isArray(t.shadowHostSelectors) ? [...t.shadowHostSelectors] : [...Ke.shadowHostSelectors]
    };
  }
  isYouTube() {
    const t = String(globalThis.location?.hostname || "").toLowerCase();
    return t === "youtube.com" || t.endsWith(".youtube.com") || t === "youtu.be" || t.endsWith(".youtube-nocookie.com") || t === "youtube.googleapis.com";
  }
  static containsAdKeyword(t) {
    return t.length > 0 && Yv.test(t);
  }
  isAdRelated(t) {
    for (const e of Gv) {
      const i = t.getAttribute(e);
      if (i && Qt.containsAdKeyword(i.toLowerCase()))
        return !0;
    }
    return !1;
  }
  isInsideAd(t) {
    for (let e = t.parentElement; e; e = e.parentElement)
      if (this.isAdRelated(e)) return !0;
    return !1;
  }
  getCapturedAudioTrackCount(t) {
    const e = t, i = e.captureStream ?? e.mozCaptureStream;
    if (typeof i != "function") return null;
    try {
      return i.call(t).getAudioTracks().length;
    } catch {
      return null;
    }
  }
  isLikelySilentDecorativeVideo(t) {
    if (!(t.muted || t.defaultMuted) || !t.autoplay || !t.loop || t.controls) return !1;
    const e = t;
    if (typeof e.mozHasAudio == "boolean")
      return !e.mozHasAudio;
    if ("audioTracks" in e && typeof e.audioTracks?.length == "number") {
      if (e.audioTracks.length > 0) return !1;
      const s = this.getCapturedAudioTrackCount(t);
      return s !== null ? s === 0 : !0;
    }
    const i = this.getCapturedAudioTrackCount(t);
    return i !== null ? i === 0 : !1;
  }
  hasAudio(t) {
    const e = t;
    return t.srcObject instanceof MediaStream ? t.srcObject.getAudioTracks().length > 0 : typeof e.mozHasAudio == "boolean" ? e.mozHasAudio : typeof e.webkitAudioDecodedByteCount == "number" && e.webkitAudioDecodedByteCount > 0 || "audioTracks" in e && typeof e.audioTracks?.length == "number" && e.audioTracks.length > 0 ? !0 : !this.isLikelySilentDecorativeVideo(t);
  }
  isVkLikeVideo(t) {
    const e = String(globalThis.location?.hostname || ""), i = String(t.currentSrc || t.src || "");
    return /(?:^|\.)vkvideo\.ru$|(?:^|\.)vk\.(?:com|ru)$|(?:^|\.)okcdn\.ru$/i.test(
      e
    ) || /vkvd\d+\.okcdn\.ru|\.okcdn\.ru|vkvideo\.ru|vk\.(?:com|ru)/i.test(
      i
    );
  }
  isValidVideo(t) {
    return !(this.isAdRelated(t) || this.isInsideAd(t) || !this.hasAudio(t) && !this.isVkLikeVideo(t));
  }
  stopObservingDom() {
    this.observer.disconnect(), this.observedRoots = /* @__PURE__ */ new WeakSet(), this.pendingAdded.clear(), this.pendingRemoved.clear(), this.flushPending = !1;
  }
  canObserveRoots() {
    return this.policy.startDomObservationOnEnable;
  }
  observeRoot(t) {
    this.canObserveRoots() && (this.observedRoots.has(t) || (this.observedRoots.add(t), this.observer.observe(t, { childList: !0, subtree: !0 })));
  }
  scan(t) {
    if (!this.policy.startDomObservationOnEnable) {
      this.scanTargeted(t, this.policy.probeSelectors);
      return;
    }
    this.scanDefault(t);
  }
  scanTargeted(t, e) {
    if (t instanceof HTMLVideoElement) {
      this.trackVideo(t);
      return;
    }
    if (!(t instanceof Document) && !(t instanceof DocumentFragment) && !(t instanceof Element))
      return;
    const i = /* @__PURE__ */ new Set(), s = (r) => {
      !(r instanceof HTMLVideoElement) || i.has(r) || (i.add(r), this.trackVideo(r));
    }, o = e.length > 0 ? e : Ke.probeSelectors;
    for (const r of o) {
      try {
        t instanceof Element && t.matches(r) && s(t);
      } catch {
      }
      try {
        for (const a of t.querySelectorAll(r))
          s(a);
      } catch {
      }
    }
    if (this.policy.observeShadowRoots)
      for (const r of this.policy.shadowHostSelectors) {
        let a;
        try {
          a = t.querySelectorAll(r);
        } catch {
          continue;
        }
        for (const l of a) {
          const u = l.shadowRoot;
          u && this.scanTargeted(u, o);
        }
      }
  }
  scanYouTube(t) {
    if (t instanceof HTMLVideoElement) {
      this.trackVideo(t);
      return;
    }
    if (!(t instanceof Document) && !(t instanceof DocumentFragment) && !(t instanceof Element))
      return;
    const e = [
      "video.html5-main-video",
      ".html5-video-container video",
      "#movie_player video",
      "ytd-player video",
      "#player video",
      "video"
    ];
    for (const i of e) {
      const s = t.querySelector(i);
      if (s instanceof HTMLVideoElement) {
        this.trackVideo(s);
        return;
      }
    }
  }
  scanDefault(t) {
    if (t instanceof HTMLVideoElement) {
      this.trackVideo(t);
      return;
    }
    if (t.nodeType !== Node.ELEMENT_NODE && t.nodeType !== Node.DOCUMENT_FRAGMENT_NODE && t.nodeType !== Node.DOCUMENT_NODE)
      return;
    const e = document.createTreeWalker(t, NodeFilter.SHOW_ELEMENT, {
      acceptNode: (i) => {
        const s = i, o = s.tagName === "VIDEO", r = !!s.shadowRoot;
        return o || r ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
      }
    });
    for (; e.nextNode(); ) {
      const i = e.currentNode;
      if (i instanceof HTMLVideoElement) {
        this.trackVideo(i);
        continue;
      }
      const s = i.shadowRoot;
      s && (this.observeRoot(s), this.scanDefault(s));
    }
  }
  getVideoListenerSignal(t) {
    const e = this.videoListenerControllers.get(t);
    e && e.abort();
    const i = new AbortController();
    return this.videoListenerControllers.set(t, i), i.signal;
  }
  cleanupVideoListeners(t) {
    const e = this.videoListenerControllers.get(t);
    e && (e.abort(), this.videoListenerControllers.delete(t));
  }
  cleanupAllVideoListeners() {
    for (const t of this.videoListenerControllers.values())
      t.abort();
    this.videoListenerControllers.clear();
  }
  trackVideo(t) {
    if (this.seenVideos.has(t)) return;
    this.seenVideos.add(t);
    const e = this.getVideoListenerSignal(t), i = () => {
      this.isValidVideo(t) && (this.activeVideos.has(t) || (this.activeVideos.add(t), this.onVideoAdded.dispatch(t)));
    };
    if (t.readyState >= HTMLMediaElement.HAVE_METADATA || !!(t.currentSrc || t.src || t.srcObject))
      i();
    else {
      t.addEventListener("loadedmetadata", i, {
        once: !0,
        signal: e
      }), t.addEventListener("loadeddata", i, {
        once: !0,
        signal: e
      }), t.addEventListener("canplay", i, {
        once: !0,
        signal: e
      }), t.addEventListener("playing", i, {
        once: !0,
        passive: !0,
        signal: e
      }), t.addEventListener("timeupdate", i, {
        once: !0,
        passive: !0,
        signal: e
      });
      const o = () => {
        t.readyState >= HTMLMediaElement.HAVE_METADATA && i();
      };
      t.addEventListener("play", o, {
        once: !0,
        passive: !0,
        signal: e
      });
    }
    t.addEventListener(
      "emptied",
      () => {
        t.isConnected || this.untrackVideo(t);
      },
      { passive: !0, signal: e }
    ), t.addEventListener(
      "durationchange",
      () => {
        this.activeVideos.has(t) || i();
      },
      { passive: !0, signal: e }
    );
  }
  untrackVideo(t) {
    this.cleanupVideoListeners(t), this.activeVideos.has(t) && (this.onVideoRemoved.dispatch(t), this.activeVideos.delete(t)), this.seenVideos.delete(t);
  }
  collectVideos(t) {
    const e = /* @__PURE__ */ new Set(), i = (s) => {
      for (const o of s) e.add(o);
    };
    if (t instanceof HTMLVideoElement && e.add(t), (t instanceof Document || t instanceof DocumentFragment || t instanceof Element) && i(t.querySelectorAll("video")), t instanceof Element) {
      const s = t.shadowRoot;
      s && i(s.querySelectorAll("video"));
    }
    return Array.from(e);
  }
  getNowMs() {
    return typeof performance < "u" && typeof performance.now == "function" ? performance.now() : Date.now();
  }
  isSliceBudgetReached(t, e) {
    return e >= Qt.MAX_NODES_PER_SLICE ? !0 : this.getNowMs() - t >= Qt.MAX_FLUSH_BUDGET_MS;
  }
  processPendingAdded(t) {
    let e = 0;
    for (; this.pendingAdded.size > 0; ) {
      const i = this.pendingAdded.values().next();
      if (i.done || (this.pendingAdded.delete(i.value), this.scan(i.value), e += 1, this.isSliceBudgetReached(t, e)))
        break;
    }
    return e;
  }
  processPendingRemoved(t, e) {
    let i = e;
    for (; this.pendingRemoved.size > 0 && !this.isSliceBudgetReached(t, i); ) {
      const s = this.pendingRemoved.values().next();
      if (s.done) break;
      this.pendingRemoved.delete(s.value);
      for (const o of this.collectVideos(s.value))
        o.isConnected || this.untrackVideo(o);
      i += 1;
    }
    return i;
  }
  installAttachShadowHook() {
    if (!this.canObserveRoots() || !this.policy.observeShadowRoots || this.attachShadowSubscriber) return;
    const t = Xv();
    if (!t) return;
    const e = (i) => {
      this.enabled && (this.observeRoot(i), this.pendingAdded.add(i), this.scheduleFlush());
    };
    t.subscribers.add(e), this.attachShadowSubscriber = e;
  }
  uninstallAttachShadowHook() {
    this.attachShadowSubscriber && (Jv(this.attachShadowSubscriber), this.attachShadowSubscriber = null);
  }
  enqueueAddedNode(t) {
    if (this.canObserveRoots() && this.policy.observeShadowRoots && t.nodeType === Node.ELEMENT_NODE) {
      const e = t.shadowRoot;
      e && this.observeRoot(e);
    }
    this.pendingAdded.add(t);
  }
  enqueueMutation(t) {
    for (const e of t.addedNodes)
      this.enqueueAddedNode(e);
    for (const e of t.removedNodes)
      this.pendingRemoved.add(e);
  }
  onYouTubeMutations(t) {
    for (const e of t)
      if (e.type === "childList")
        for (const i of e.addedNodes) {
          if (i instanceof HTMLVideoElement) {
            this.trackVideo(i);
            return;
          }
          if (!(i instanceof Element)) continue;
          const s = i.querySelector(
            "video.html5-main-video, .html5-video-container video, #movie_player video, ytd-player video, #player video, video"
          );
          if (s instanceof HTMLVideoElement) {
            this.trackVideo(s);
            return;
          }
        }
  }
  onMutations(t) {
    for (const e of t)
      e.type === "childList" && this.enqueueMutation(e);
    (this.pendingAdded.size > 0 || this.pendingRemoved.size > 0) && this.scheduleFlush();
  }
  enable(t) {
    if (this.enabled) return;
    this.enabled = !0;
    const e = () => {
      const o = document.documentElement, r = t && "isConnected" in t && t.isConnected ? t : o;
      r && (this.policy.startDomObservationOnEnable && this.observeRoot(o), this.scan(r));
    };
    if (!this.policy.startDomObservationOnEnable) {
      if (document.documentElement) {
        e();
        return;
      }
      const r = () => {
        document.removeEventListener("readystatechange", r), this.onDocumentReady = null, this.enabled && e();
      };
      this.onDocumentReady = r, document.addEventListener("readystatechange", r), typeof queueMicrotask == "function" ? queueMicrotask(r) : Promise.resolve().then(r);
      return;
    }
    if (this.checkerUnsubscribe?.(), this.checkerUnsubscribe = this.intervalIdleChecker.subscribe(
      this.onCheckerTick
    ), this.intervalIdleChecker.start(), this.intervalIdleChecker.markActivity("video-observer-enable"), this.installAttachShadowHook(), globalThis.addEventListener("pageshow", this.onPageShow, {
      passive: !0
    }), document.documentElement) {
      e();
      return;
    }
    const s = () => {
      document.documentElement && (document.removeEventListener("readystatechange", s), this.onDocumentReady = null, this.enabled && e());
    };
    this.onDocumentReady = s, document.addEventListener("readystatechange", s), typeof queueMicrotask == "function" ? queueMicrotask(s) : Promise.resolve().then(s);
  }
  disable() {
    this.enabled && (this.enabled = !1, globalThis.removeEventListener("pageshow", this.onPageShow), this.onDocumentReady && (document.removeEventListener("readystatechange", this.onDocumentReady), this.onDocumentReady = null), this.uninstallAttachShadowHook(), this.stopObservingDom(), this.cleanupAllVideoListeners(), this.checkerUnsubscribe?.(), this.checkerUnsubscribe = null, this.intervalIdleChecker.stop(), this.seenVideos = /* @__PURE__ */ new WeakSet(), this.activeVideos = /* @__PURE__ */ new WeakSet(), this.observedRoots = /* @__PURE__ */ new WeakSet());
  }
};
c(Qt, "MAX_FLUSH_BUDGET_MS", 6), c(Qt, "MAX_NODES_PER_SLICE", 120);
let As = Qt;
function Qi(n, t) {
  const e = At(t);
  n.lastVideoPercent = e;
}
function ts(n, t) {
  const e = Number(t);
  if (!Number.isFinite(e))
    return;
  const i = Math.max(0, Math.round(e));
  n.lastTranslationPercent = i;
}
function Zv({
  state: n,
  fromType: t,
  newVolume: e,
  currentVideo: i,
  currentTranslation: s,
  translationMin: o,
  translationMax: r
}) {
  if (n.initialized || (n.lastVideoPercent = Number(i), n.lastTranslationPercent = Number(s), n.initialized = !0), t === "video") {
    const d = At(e), h = d - At(n.lastVideoPercent);
    n.lastVideoPercent = d;
    const f = vs(
      n.lastTranslationPercent + h,
      o,
      r
    );
    return n.lastTranslationPercent = f, { nextTranslation: f };
  }
  const a = vs(
    Number.isFinite(e) ? e : s,
    o,
    r
  ), l = a - n.lastTranslationPercent;
  n.lastTranslationPercent = a;
  const u = At(n.lastVideoPercent + l);
  return n.lastVideoPercent = u, { nextVideo: u };
}
const Ca = {
  allowTouchMoveHandler: !0,
  disableContainerDrag: !1
}, Qv = {
  xvideos: {
    allowTouchMoveHandler: !1
  },
  youtube: {
    disableContainerDrag: !0
  }
};
function tw(n) {
  if (!n)
    return Ca;
  const t = Qv[n] ?? {};
  return {
    ...Ca,
    ...t
  };
}
function ew(n, t) {
  if (!t || t === n || n.aborted)
    return n;
  if (t.aborted)
    return t;
  if (typeof AbortSignal < "u" && "any" in AbortSignal)
    return AbortSignal.any([n, t]);
  const i = new AbortController(), s = () => {
    n.removeEventListener("abort", o), t.removeEventListener("abort", r);
  }, o = () => {
    s(), i.abort(n.reason);
  }, r = () => {
    s(), i.abort(t.reason);
  };
  return n.addEventListener("abort", o, { once: !0 }), t.addEventListener("abort", r, { once: !0 }), i.signal;
}
function pc(n) {
  return n === "vk" || /(?:^|\.)vkvideo\.ru$|(?:^|\.)vk\.(?:com|ru)$/i.test(
    String(globalThis.location?.hostname || "")
  );
}
function bc(n) {
  const t = (i, s, o, r) => {
    const a = ew(n, r?.signal);
    if (!r) {
      i.addEventListener(s, o, { signal: a });
      return;
    }
    const { signal: l, ...u } = r;
    i.addEventListener(s, o, {
      ...u,
      signal: a
    });
  };
  return { add: t, addMany: (i, s, o, r) => {
    for (const a of s)
      t(i, a, o, r);
  } };
}
function Ia(n, t, e) {
  n(
    t,
    ["pointerenter", "focusin"],
    (i) => e.handleOverlayInteraction(i)
  ), n(
    t,
    ["pointermove"],
    (i) => e.handleOverlayInteraction(i),
    { passive: !0 }
  ), n(
    t,
    ["pointerleave", "focusout"],
    (i) => e.scheduleHide(i)
  );
}
function Es(n, t = 0) {
  const e = typeof n == "number" ? n : Number(n);
  return Number.isFinite(e) ? At(e) : t;
}
function yc(n, t, e = {}) {
  e.skipYouTubeLikeHosts && Xl(n.site.host) || n.smartVolumeDuckingInterval === void 0 && (!n.data?.syncVolume || !n.audioPlayer?.player?.src || n.isLikelyInternalVideoVolumeChange(t) || n.syncVolumeWrapper("video", t));
}
function Pa(n, t, e) {
  const i = t.votMenu?.container;
  if (i) {
    const r = e ?? n.video.getBoundingClientRect().height;
    i.style.setProperty("--vot-container-height", `${r}px`);
  }
  const { position: s, direction: o } = t.calcButtonLayout(
    n.data?.buttonPos ?? "default"
  );
  t.updateButtonLayout(s, o);
}
function vc(n) {
  return n.replace("Key", "").replace("Digit", "");
}
function nw(n) {
  const t = /* @__PURE__ */ new Set();
  for (const e of n)
    t.add(vc(e));
  return t;
}
function Ma(n, t) {
  if (!n) return null;
  const e = t.get(n);
  if (e) return e;
  const i = n.split("+").filter(Boolean).map(vc), s = {
    parts: i,
    partsSet: new Set(i)
  };
  return t.set(n, s), s;
}
function Oa(n, t) {
  if (!t || n.size !== t.parts.length) return !1;
  for (const e of t.partsSet)
    if (!n.has(e)) return !1;
  return !0;
}
function iw(n) {
  const { self: t, overlayView: e, addMany: i } = n, s = () => {
    t.refreshOverlayMount(), Pa(t, e);
  };
  t.resizeObserver = new ResizeObserver((o) => {
    for (const r of o)
      Pa(t, e, r.contentRect.height);
  }), t.resizeObserver.observe(t.video), s(), i(
    document,
    ["fullscreenchange", "webkitfullscreenchange"],
    () => s()
  ), i(
    t.video,
    ["webkitbeginfullscreen", "webkitendfullscreen"],
    () => s()
  );
}
function sw(n) {
  const { self: t } = n;
  if (!Jl(t.site)) return;
  t.syncVolumeObserver = new MutationObserver((i) => {
    if (!t.audioPlayer?.player?.src) return;
    let s = !1, o = null;
    for (const a of i) {
      if (a.type !== "attributes" || a.attributeName !== "aria-valuenow")
        continue;
      s = !0;
      const l = a.target instanceof Element ? a.target.getAttribute("aria-valuenow") : null, u = l != null ? Number.parseFloat(l) : Number.NaN;
      Number.isFinite(u) && (o = u);
    }
    if (!s) return;
    let r;
    if (o != null)
      r = Es(o);
    else {
      const a = t.isMuted() ? 0 : t.getVideoVolume();
      r = Es(a * 100);
    }
    t.syncVideoVolumeSlider(), yc(t, r);
  });
  const e = document.querySelector(".ytp-volume-panel");
  e && t.syncVolumeObserver.observe(e, {
    attributes: !0,
    subtree: !0,
    attributeFilter: ["aria-valuenow"]
  });
}
function ow(n) {
  const { self: t } = n;
  if (t.site.host !== "youtube" || t.site.additionalData === "mobile")
    return;
  const e = async () => {
    try {
      if (!t.videoData) return;
      const o = N.getPlayer(), r = o?.getAvailableAudioTracks?.() ?? null;
      if (!Array.isArray(r) || r.length <= 1)
        return;
      const l = o?.getAudioTrack?.()?.getLanguageInfo?.()?.id, u = l && l !== "und" ? l.toLowerCase().split(/[-_.]/)[0] : void 0;
      if (!u || !Pt.includes(u)) return;
      const d = u;
      if (d === t.videoData.detectedLanguage) return;
      if (t.videoManager.rememberDetectedLanguage(
        t.videoData.videoId,
        d
      ), t.setSelectMenuValues(
        d,
        t.videoData.responseLanguage
      ), t.data?.autoTranslate && d !== t.videoData.responseLanguage) {
        V.log(
          `[VOT] Audio track language changed to ${d}, triggering auto-translation`
        );
        try {
          await t.uiManager.handleTranslationBtnClick();
        } catch (h) {
          V.log(
            "[VOT] Failed to trigger auto-translation on audio track change:",
            h
          );
        }
      }
    } catch {
    }
  }, i = N.getPlayer(), s = ["onApiChange", "onStateChange"];
  if (i?.addEventListener)
    for (const o of s)
      try {
        i.addEventListener(o, e);
      } catch {
      }
  e(), t.abortController.signal.addEventListener(
    "abort",
    () => {
      if (i?.removeEventListener)
        for (const o of s)
          try {
            i.removeEventListener(o, e);
          } catch {
          }
    },
    { once: !0 }
  );
}
function rw(n) {
  const { self: t, overlayView: e, add: i, addMany: s, platformConfig: o } = n;
  i(document, "click", (f) => {
    const g = f.target, m = e.votButton?.container, v = e.votMenu?.container, T = t.uiManager.votSettingsView?.dialog?.container, S = g && m ? m.contains(g) : !1, w = g && v ? v.contains(g) : !1, x = g ? t.container.contains(g) : !1, I = g && T ? T.contains(g) : !1, k = g instanceof Element && g.closest(".vot-dialog-temp") instanceof Element;
    S || w || I || k || (!x && !pc(t.site.host) && e.updateButtonOpacity(0), v && !v.hidden && (v.hidden = !0, t.overlayVisibility?.queueAutoHide()));
  });
  const r = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Map(), l = () => r.clear(), u = (f, g) => {
    f().catch((m) => {
    });
  };
  i(document, "keydown", (f) => {
    const g = f;
    if (g.repeat) return;
    r.add(g.code);
    const m = document.activeElement, v = m?.tagName?.toLowerCase?.() ?? "";
    if (["input", "textarea"].includes(v) || !!m?.isContentEditable) return;
    const S = nw(r);
    if (Oa(
      S,
      Ma(t.data?.translationHotkey, a)
    )) {
      l(), u(
        () => t.uiManager.handleTranslationBtnClick()
      );
      return;
    }
    Oa(
      S,
      Ma(t.data?.subtitlesHotkey, a)
    ) && (l(), u(
      () => t.toggleSubtitlesForCurrentLangPair()
    ));
  }), i(
    document,
    "keyup",
    (f) => r.delete(f.code)
  ), i(document, "blur", l), i(document, "visibilitychange", () => {
    document.hidden && l();
  }), i(globalThis, "blur", l);
  const d = /* @__PURE__ */ new Set(), h = t.getEventContainer();
  h && d.add(h), d.add(t.container), d.add(t.video);
  for (const f of d)
    s(
      f,
      ["pointerenter", "pointerdown"],
      (g) => t.overlayVisibility.handleHostInteraction(g)
    ), i(
      f,
      "pointermove",
      (g) => t.overlayVisibility.handleHostInteraction(g),
      { passive: !0 }
    ), i(
      f,
      "pointerleave",
      (g) => t.overlayVisibility.scheduleHide(g)
    );
  t.rebindOverlayVisibilityTargets(), o.allowTouchMoveHandler && i(
    document,
    "touchmove",
    (f) => t.overlayVisibility.handleHostInteraction(f),
    { passive: !0 }
  ), o.disableContainerDrag && (t.container.draggable = !1);
}
function aw(n) {
  const { self: t, overlayView: e, add: i } = n, s = async () => {
    try {
      await t.setCanPlay();
    } catch {
    }
  };
  let o = !1;
  const r = () => {
    o || (o = !0, queueMicrotask(async () => {
      o = !1, await s();
    }));
  };
  i(t.video, "canplay", () => {
    t.site.host === "rutube" && t.video.src || r();
  });
  const a = async () => {
    let l;
    try {
      l = await wl(t.site, {
        fetchFn: nt,
        video: t.video
      });
    } catch {
    }
    t.videoData && l && l === t.videoData.videoId || t.site.host === "custom" && Js() || zl(t, e, {
      clearVideoData: !0,
      hideMenu: !0
    });
  };
  i(t.video, "emptied", () => {
    a().catch((l) => {
    });
  }), ob(t.site.host) || i(t.video, "volumechange", () => {
    t.syncVideoVolumeSlider();
    const l = t.uiManager.votOverlayView;
    if (!l?.isInitialized()) return;
    const u = Es(
      l.videoVolumeSlider.value
    );
    yc(t, u, {
      skipYouTubeLikeHosts: !0
    });
  }), t.site.host === "youtube" && !t.site.additionalData && i(document, "yt-page-data-updated", () => {
    globalThis.location.pathname.startsWith("/shorts/") && r();
  });
}
function lw() {
  const n = this.uiManager.votOverlayView;
  if (!n?.subtitlesSelect) return;
  const { add: t, addMany: e } = bc(this.abortController.signal), i = {
    self: this,
    overlayView: n,
    platformConfig: tw(this.site.host),
    add: t,
    addMany: e
  };
  iw(i), sw(i), ow(i), rw(i), aw(i);
}
function cw() {
  this.overlayVisibilityTargetsAbortController?.abort(), this.overlayVisibilityTargetsAbortController = new AbortController();
  const { signal: n } = this.overlayVisibilityTargetsAbortController, t = this.uiManager?.votOverlayView?.votButton?.container, e = this.uiManager?.votOverlayView?.votMenu?.container;
  if (!t || !e || !this.overlayVisibility) return;
  const i = this.overlayVisibility, { addMany: s } = bc(n);
  Ia(s, t, i), Ia(s, e, i);
}
function uw(n) {
  if (!(n instanceof Node)) return !1;
  const t = this.uiManager?.votOverlayView, e = t?.votButton?.container, i = t?.votMenu?.container;
  return e instanceof Node && e.contains(n) || i instanceof Node && i.contains(n);
}
function dw() {
  if (pc(this.site.host))
    return 6e4;
  const n = this.data?.autoHideButtonDelay;
  return typeof n == "number" && Number.isFinite(n) ? n : Ys;
}
function hw() {
  this.resizeObserver?.disconnect(), this.overlayVisibilityTargetsAbortController?.abort(), this.overlayVisibilityTargetsAbortController = void 0, Jl(this.site) && this.syncVolumeObserver?.disconnect();
}
let Ce;
function fw(n) {
  Ce = n;
}
const sn = class sn {
  constructor() {
    c(this, "popup", null);
    c(this, "isBound", !1);
    c(this, "geometrySaveTimer", null);
    c(this, "ownerId", null);
    c(this, "onTranslate");
    c(this, "onTurnOff");
    c(this, "onSettings");
    c(this, "onDownload");
    c(this, "onDownloadSubtitles");
    c(this, "onToggleSubtitles");
    c(this, "onVideoVolumeChange");
    c(this, "onTranslationVolumeChange");
    c(this, "onFromLanguageChange");
    c(this, "onToLanguageChange");
    c(this, "onAutoTranslateChange");
    c(this, "onAutoSubtitlesChange");
    c(this, "onSyncVolumeChange");
    c(this, "onShowVideoSliderChange");
    c(this, "onAudioBoosterChange");
    c(this, "onAutoVolumeChange");
    c(this, "onSmartDuckingChange");
  }
  open() {
    if (this.popup && !this.popup.closed) {
      try {
        this.popup.focus();
      } catch {
      }
      return;
    }
    const t = this.readGeometry(), e = this.buildPopupFeatures(t);
    let i = null;
    try {
      i = window.open("about:blank", "vot_overlay", e);
    } catch (at) {
      console.warn("[VOT] popup open failed", at);
      return;
    }
    if (!i)
      return;
    this.popup = i;
    const s = this.popup.document;
    for (s.title = "VOT"; s.firstChild; ) s.removeChild(s.firstChild);
    const o = s.createElement("html"), r = s.createElement("head"), a = s.createElement("meta");
    a.setAttribute("charset", "utf-8");
    const l = s.createElement("title");
    l.textContent = "VOT";
    const u = s.createElement("style");
    u.textContent = `
      :root {
        color-scheme: dark;
        --vot-bg: #0f172a;
        --vot-card: #111827;
        --vot-card-2: #1f2937;
        --vot-text: #f9fafb;
        --vot-muted: rgba(248, 250, 252, 0.72);
        --vot-border: rgba(255,255,255,0.08);
        --vot-accent: #2563eb;
        --vot-accent-2: #1d4ed8;
        --vot-success: #059669;
        --vot-warning: #d97706;
        --vot-danger: #dc2626;
      }
      * { box-sizing: border-box; }
      body {
        margin: 0;
        min-height: 100vh;
        padding: 14px;
        font-family: Arial, sans-serif;
        background:
          radial-gradient(circle at top right, rgba(37,99,235,.14), transparent 34%),
          linear-gradient(180deg, #0b1220, var(--vot-bg));
        color: var(--vot-text);
      }
      .vot-card {
        display: flex;
        flex-direction: column;
        gap: 12px;
        border: 1px solid var(--vot-border);
        border-radius: 16px;
        padding: 14px;
        background: linear-gradient(180deg, rgba(255,255,255,.045), rgba(255,255,255,.025));
        box-shadow: 0 16px 36px rgba(0,0,0,.28);
      }
      .vot-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
      }
      .vot-title-wrap { display: flex; flex-direction: column; gap: 3px; }
      .vot-title { font-size: 13px; opacity: .82; font-weight: 700; }
      .vot-subtitle { font-size: 11px; color: var(--vot-muted); }
      .vot-badge {
        border-radius: 999px;
        padding: 6px 10px;
        font-size: 11px;
        font-weight: 700;
        background: rgba(255,255,255,.08);
        color: var(--vot-text);
      }
      .vot-badge[data-status="loading"] { background: rgba(217,119,6,.18); color: #fbbf24; }
      .vot-badge[data-status="success"] { background: rgba(5,150,105,.18); color: #34d399; }
      .vot-badge[data-status="error"] { background: rgba(220,38,38,.18); color: #fca5a5; }
      .vot-row { display: flex; gap: 8px; align-items: center; }
      .vot-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
      .vot-field { display: flex; flex-direction: column; gap: 6px; }
      .vot-label { font-size: 12px; color: var(--vot-muted); }
      .vot-select,
      button {
        border: 1px solid rgba(255,255,255,.06);
        border-radius: 12px;
        padding: 10px 12px;
        font-size: 14px;
        background: var(--vot-card-2);
        color: var(--vot-text);
      }
      .vot-select { width: 100%; }
      button {
        cursor: pointer;
        font-weight: 600;
        transition: transform .12s ease, background .12s ease, opacity .12s ease;
      }
      button:hover { background: #273244; }
      button:active { transform: translateY(1px); }
      button:disabled, input:disabled, select:disabled { cursor: not-allowed; opacity: .45; }
      #vot-main-btn { flex: 1; background: var(--vot-accent); border-color: transparent; }
      #vot-main-btn:hover { background: var(--vot-accent-2); }
      #vot-main-btn[data-mode="turn-off"] { background: var(--vot-danger); }
      #vot-main-btn[data-mode="turn-off"]:hover { background: #b91c1c; }
      #vot-subtitles-btn[data-active="true"] {
        background: rgba(37,99,235,.18);
        border-color: rgba(96,165,250,.35);
      }
      #vot-download-btn:disabled { text-decoration: line-through; }
      #vot-status { font-size: 12px; opacity: .92; }
      #vot-hint { font-size: 12px; color: var(--vot-muted); line-height: 1.35; }
      .vot-slider-head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
      }
      .vot-slider-value { font-size: 12px; color: var(--vot-muted); }
      input[type="range"] { width: 100%; accent-color: var(--vot-accent); }
      .vot-toggle-row { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
      .vot-toggle {
        display: flex; align-items: center; gap: 8px;
        padding: 10px 12px; border-radius: 12px;
        background: rgba(255,255,255,.05); border: 1px solid rgba(255,255,255,.06);
      }
      .vot-toggle input { margin: 0; }
    `, r.append(a, l, u);
    const d = s.createElement("body"), h = s.createElement("div");
    h.className = "vot-card";
    const f = s.createElement("div");
    f.className = "vot-header";
    const g = s.createElement("div");
    g.className = "vot-title-wrap";
    const m = s.createElement("div");
    m.className = "vot-title", m.textContent = "Voice Over Translation";
    const v = s.createElement("div");
    v.className = "vot-subtitle", v.textContent = "Popup mode for Google-hosted players.", g.append(m, v);
    const T = s.createElement("div");
    T.id = "vot-badge", T.className = "vot-badge", T.dataset.status = "none", T.textContent = "idle", f.append(g, T);
    const S = s.createElement("div");
    S.className = "vot-row";
    const w = s.createElement("button");
    w.id = "vot-main-btn", w.textContent = "Translate video", S.append(w);
    const x = s.createElement("div");
    x.className = "vot-grid";
    const I = s.createElement("div");
    I.className = "vot-field";
    const k = s.createElement("div");
    k.className = "vot-label", k.textContent = "From";
    const A = s.createElement("select");
    A.id = "vot-from-lang", A.className = "vot-select", I.append(k, A);
    const $ = s.createElement("div");
    $.className = "vot-field";
    const H = s.createElement("div");
    H.className = "vot-label", H.textContent = "To";
    const _ = s.createElement("select");
    _.id = "vot-to-lang", _.className = "vot-select", $.append(H, _), x.append(I, $);
    const z = s.createElement("div");
    z.className = "vot-toggle-row";
    const q = s.createElement("label");
    q.className = "vot-toggle";
    const Y = s.createElement("input");
    Y.type = "checkbox", Y.id = "vot-auto-translate";
    const Mt = s.createElement("span");
    Mt.textContent = "Auto translate", q.append(Y, Mt);
    const kn = s.createElement("label");
    kn.className = "vot-toggle";
    const Wt = s.createElement("input");
    Wt.type = "checkbox", Wt.id = "vot-auto-subtitles";
    const Ln = s.createElement("span");
    Ln.textContent = "Auto subtitles", kn.append(Wt, Ln), z.append(q, kn);
    const Pe = s.createElement("div");
    Pe.className = "vot-toggle-row";
    const Me = s.createElement("label");
    Me.className = "vot-toggle";
    const zt = s.createElement("input");
    zt.type = "checkbox", zt.id = "vot-sync-volume";
    const xn = s.createElement("span");
    xn.textContent = "Sync volume", Me.append(zt, xn);
    const Oe = s.createElement("label");
    Oe.className = "vot-toggle";
    const Ot = s.createElement("input");
    Ot.type = "checkbox", Ot.id = "vot-show-video-slider";
    const B = s.createElement("span");
    B.textContent = "Video slider", Oe.append(Ot, B), Pe.append(Me, Oe);
    const bt = s.createElement("div");
    bt.className = "vot-toggle-row";
    const Et = s.createElement("label");
    Et.className = "vot-toggle";
    const Tt = s.createElement("input");
    Tt.type = "checkbox", Tt.id = "vot-audio-booster";
    const j = s.createElement("span");
    j.textContent = "Audio booster", Et.append(Tt, j);
    const kt = s.createElement("label");
    kt.className = "vot-toggle";
    const qt = s.createElement("input");
    qt.type = "checkbox", qt.id = "vot-auto-volume";
    const po = s.createElement("span");
    po.textContent = "Auto volume", kt.append(qt, po), bt.append(Et, kt);
    const Ti = s.createElement("div");
    Ti.className = "vot-toggle-row";
    const ki = s.createElement("label");
    ki.className = "vot-toggle";
    const De = s.createElement("input");
    De.type = "checkbox", De.id = "vot-smart-ducking";
    const bo = s.createElement("span");
    bo.textContent = "Smart ducking", ki.append(De, bo), Ti.append(ki);
    const Li = s.createElement("div");
    Li.className = "vot-row";
    const An = s.createElement("button");
    An.id = "vot-subtitles-btn", An.textContent = "Subtitles";
    const _e = s.createElement("button");
    _e.id = "vot-download-btn", _e.textContent = "Download MP3";
    const En = s.createElement("button");
    En.id = "vot-download-subtitles-btn", En.textContent = "Download subtitles", Li.append(An, _e, En);
    const xi = s.createElement("div");
    xi.className = "vot-field";
    const Ai = s.createElement("div");
    Ai.className = "vot-slider-head";
    const Vn = s.createElement("div");
    Vn.id = "vot-video-volume-label", Vn.className = "vot-label", Vn.textContent = "Video volume";
    const Re = s.createElement("div");
    Re.id = "vot-video-volume-value", Re.className = "vot-slider-value", Re.textContent = "100%", Ai.append(Vn, Re);
    const Vt = s.createElement("input");
    Vt.id = "vot-video-volume", Vt.type = "range", Vt.min = "0", Vt.max = "100", Vt.value = "100", xi.append(Ai, Vt);
    const Ei = s.createElement("div");
    Ei.className = "vot-field";
    const Vi = s.createElement("div");
    Vi.className = "vot-slider-head";
    const Cn = s.createElement("div");
    Cn.id = "vot-translation-volume-label", Cn.className = "vot-label", Cn.textContent = "Translation volume";
    const Be = s.createElement("div");
    Be.id = "vot-translation-volume-value", Be.className = "vot-slider-value", Be.textContent = "100%", Vi.append(Cn, Be);
    const Ct = s.createElement("input");
    Ct.id = "vot-translation-volume", Ct.type = "range", Ct.min = "0", Ct.max = "300", Ct.value = "100", Ei.append(Vi, Ct);
    const Ci = s.createElement("div");
    Ci.id = "vot-status", Ci.textContent = "Status: none";
    const Ii = s.createElement("div");
    Ii.id = "vot-hint", Ii.textContent = "Popup mode for Google-hosted players.", h.append(
      f,
      S,
      x,
      z,
      Pe,
      bt,
      Ti,
      Li,
      xi,
      Ei,
      Ci,
      Ii
    ), d.append(h), o.append(r, d), s.appendChild(o), w.addEventListener("click", () => {
      w.dataset.mode === "turn-off" ? this.onTurnOff?.() : this.onTranslate?.();
    }), _e.addEventListener("click", () => this.onDownload?.()), En.addEventListener("click", () => this.onDownloadSubtitles?.()), An.addEventListener("click", () => this.onToggleSubtitles?.()), Vt.addEventListener("input", () => {
      Re.textContent = `${Vt.value}%`, this.onVideoVolumeChange?.(Number(Vt.value));
    }), Ct.addEventListener("input", () => {
      Be.textContent = `${Ct.value}%`, this.onTranslationVolumeChange?.(Number(Ct.value));
    }), A.addEventListener("change", () => this.onFromLanguageChange?.(A.value)), _.addEventListener("change", () => this.onToLanguageChange?.(_.value)), Y.addEventListener("change", () => this.onAutoTranslateChange?.(Y.checked)), Wt.addEventListener("change", () => this.onAutoSubtitlesChange?.(Wt.checked)), zt.addEventListener("change", () => this.onSyncVolumeChange?.(zt.checked)), Ot.addEventListener("change", () => this.onShowVideoSliderChange?.(Ot.checked)), Tt.addEventListener("change", () => this.onAudioBoosterChange?.(Tt.checked)), qt.addEventListener("change", () => this.onAutoVolumeChange?.(qt.checked)), De.addEventListener("change", () => this.onSmartDuckingChange?.(De.checked)), s.addEventListener("keydown", (at) => {
      const Nc = at.target instanceof HTMLInputElement || at.target instanceof HTMLSelectElement || at.target instanceof HTMLTextAreaElement;
      if (at.key === "Escape") {
        at.preventDefault(), this.close();
        return;
      }
      if (at.key === "Enter" && !Nc) {
        at.preventDefault(), w.dataset.mode === "turn-off" ? this.onTurnOff?.() : this.onTranslate?.();
        return;
      }
      (at.ctrlKey || at.metaKey) && at.key.toLowerCase() === "d" && (at.preventDefault(), _e.disabled || this.onDownload?.());
    }), this.attachGeometryPersistence(this.popup);
  }
  bind() {
    this.isBound || (this.isBound = !0);
  }
  setOwner(t) {
    this.ownerId = t;
  }
  isOpen() {
    return !!(this.popup && !this.popup.closed);
  }
  isOwner(t) {
    return this.ownerId === t;
  }
  setHandlers(t) {
    this.onTranslate = t.onTranslate, this.onTurnOff = t.onTurnOff, this.onSettings = t.onSettings, this.onDownload = t.onDownload, this.onDownloadSubtitles = t.onDownloadSubtitles, this.onToggleSubtitles = t.onToggleSubtitles, this.onVideoVolumeChange = t.onVideoVolumeChange, this.onTranslationVolumeChange = t.onTranslationVolumeChange, this.onFromLanguageChange = t.onFromLanguageChange, this.onToLanguageChange = t.onToLanguageChange, this.onAutoTranslateChange = t.onAutoTranslateChange, this.onAutoSubtitlesChange = t.onAutoSubtitlesChange, this.onSyncVolumeChange = t.onSyncVolumeChange, this.onShowVideoSliderChange = t.onShowVideoSliderChange, this.onAudioBoosterChange = t.onAudioBoosterChange, this.onAutoVolumeChange = t.onAutoVolumeChange, this.onSmartDuckingChange = t.onSmartDuckingChange;
  }
  updateState(t) {
    if (!this.popup || this.popup.closed) return;
    const e = this.getEl("vot-main-btn"), i = this.getEl("vot-subtitles-btn"), s = this.getEl("vot-download-btn"), o = this.getEl("vot-download-subtitles-btn"), r = this.getEl("vot-status"), a = this.getEl("vot-hint"), l = this.getEl("vot-from-lang"), u = this.getEl("vot-to-lang"), d = this.getEl("vot-badge"), h = this.getEl("vot-video-volume"), f = this.getEl("vot-video-volume-value"), g = this.getEl("vot-translation-volume"), m = this.getEl("vot-translation-volume-value"), v = this.getEl("vot-auto-translate"), T = this.getEl("vot-auto-subtitles"), S = this.getEl("vot-sync-volume"), w = this.getEl("vot-show-video-slider"), x = this.getEl("vot-audio-booster"), I = this.getEl("vot-auto-volume"), k = this.getEl("vot-smart-ducking");
    this.popup.document.body.style.display = t.visible ? "block" : "none";
    const A = t.status === "loading";
    e && (e.textContent = t.label, e.dataset.mode = t.status === "success" ? "turn-off" : "translate", e.disabled = A), d && (d.dataset.status = t.status, d.textContent = this.getBadgeText(t.status)), i && (i.dataset.active = String(!!t.subtitlesEnabled), i.textContent = t.subtitlesEnabled ? "Subtitles: on" : "Subtitles: off"), s && (s.disabled = !t.canDownload || A, s.title = t.canDownload ? "Download translated audio" : "Translation audio is not available yet"), o && (o.disabled = !t.canDownloadSubtitles || A, o.title = t.canDownloadSubtitles ? "Download subtitles" : "Subtitles are not available yet"), r && (r.textContent = `Status: ${t.status}`), a && (a.textContent = t.hint ?? "Popup mode for Google-hosted players."), l && this.renderSelectOptions(l, t.fromLangOptions ?? [], t.fromLangValue, t.fromLangLabel), u && this.renderSelectOptions(u, t.toLangOptions ?? [], t.toLangValue, t.toLangLabel), l && (l.disabled = A), u && (u.disabled = A), i && (i.disabled = A), v && (v.checked = !!t.autoTranslateEnabled, v.disabled = A), T && (T.checked = !!t.autoSubtitlesEnabled, T.disabled = A), S && (S.checked = !!t.syncVolumeEnabled, S.disabled = A), w && (w.checked = !!t.showVideoSliderEnabled, w.disabled = A), x && (x.checked = !!t.audioBoosterEnabled, x.disabled = A), I && (I.checked = !!t.autoVolumeEnabled, I.disabled = A), k && (k.checked = !!t.smartDuckingEnabled, k.disabled = A || !t.autoVolumeEnabled), h && typeof t.videoVolume == "number" && (h.value = String(Math.max(0, Math.min(100, Math.round(t.videoVolume)))), h.disabled = A || t.showVideoSliderEnabled === !1, f && (f.textContent = `${h.value}%`)), g && typeof t.translationVolume == "number" && (g.value = String(Math.max(0, Math.min(Number(g.max), Math.round(t.translationVolume)))), g.disabled = t.canAdjustTranslationVolume === !1 || A, m && (m.textContent = `${g.value}%`));
  }
  close() {
    this.geometrySaveTimer && (clearTimeout(this.geometrySaveTimer), this.geometrySaveTimer = null);
    try {
      this.persistGeometry(), this.popup?.close();
    } catch {
    }
    this.popup = null;
  }
  renderSelectOptions(t, e, i, s) {
    const o = JSON.stringify(e);
    if ((t.dataset.signature ?? "") !== o) {
      for (; t.firstChild; )
        t.removeChild(t.firstChild);
      for (const r of e) {
        const a = t.ownerDocument.createElement("option");
        a.value = r.value, a.textContent = r.label, t.appendChild(a);
      }
      t.dataset.signature = o;
    }
    if (i && Array.from(t.options).some((r) => r.value === i))
      t.value = i;
    else if (s) {
      if (!Array.from(t.options).some(
        (a) => a.value === (i ?? "")
      )) {
        const a = t.ownerDocument.createElement("option");
        a.value = i ?? "", a.textContent = s, t.appendChild(a);
      }
      t.value = i ?? "";
    } else t.options.length > 0 && (t.selectedIndex = 0);
  }
  getEl(t) {
    return !this.popup || this.popup.closed ? null : this.popup.document.getElementById(t);
  }
  getBadgeText(t) {
    switch (t) {
      case "loading":
        return "loading";
      case "success":
        return "active";
      case "error":
        return "error";
      default:
        return "idle";
    }
  }
  buildPopupFeatures(t) {
    const e = t ?? { width: 500, height: 520, left: 120, top: 120 };
    return [
      `width=${e.width}`,
      `height=${e.height}`,
      `left=${e.left}`,
      `top=${e.top}`,
      "resizable=yes",
      "scrollbars=yes"
    ].join(",");
  }
  readGeometry() {
    try {
      const t = window.localStorage.getItem(sn.GEOMETRY_STORAGE_KEY);
      if (!t) return null;
      const e = JSON.parse(t);
      return [e.width, e.height, e.left, e.top].some((i) => typeof i != "number") ? null : {
        width: Math.max(420, Math.round(e.width)),
        height: Math.max(420, Math.round(e.height)),
        left: Math.round(e.left),
        top: Math.round(e.top)
      };
    } catch {
      return null;
    }
  }
  attachGeometryPersistence(t) {
    t.addEventListener("beforeunload", () => {
      this.persistGeometry(), this.popup = null;
    }), t.addEventListener("resize", () => this.scheduleGeometryPersist()), t.addEventListener("move", () => this.scheduleGeometryPersist());
  }
  scheduleGeometryPersist() {
    this.geometrySaveTimer && clearTimeout(this.geometrySaveTimer), this.geometrySaveTimer = setTimeout(() => {
      this.geometrySaveTimer = null, this.persistGeometry();
    }, 200);
  }
  persistGeometry() {
    if (!(!this.popup || this.popup.closed))
      try {
        const t = {
          width: this.popup.outerWidth,
          height: this.popup.outerHeight,
          left: this.popup.screenX,
          top: this.popup.screenY
        };
        window.localStorage.setItem(sn.GEOMETRY_STORAGE_KEY, JSON.stringify(t));
      } catch {
      }
  }
};
c(sn, "GEOMETRY_STORAGE_KEY", "vot-popup-overlay-geometry");
let Vs = sn, es = null;
async function gw() {
  Ce || (es ?? (es = (async () => {
    try {
      const e = (await (await nt(
        "https://cloudflare-dns.com/cdn-cgi/trace",
        {
          timeout: 7e3
        }
      )).text()).split(`
`).find((i) => i.startsWith("loc="));
      fw(e?.slice(4, 6).toUpperCase());
    } catch (n) {
      console.error("[VOT] Error getting country:", n);
    }
  })().finally(() => {
    es = null;
  })), await es);
}
async function mw() {
  if (this.initialized) return;
  const n = this.isAudioContextSupported;
  this.data = await C.getValues({
    autoTranslate: !1,
    autoSubtitles: !1,
    dontTranslateLanguages: [Wn],
    enabledDontTranslateLanguages: !0,
    enabledAutoVolume: !0,
    enabledSmartDucking: !0,
    autoVolume: pi,
    buttonPos: "default",
    showVideoSlider: !0,
    syncVolume: !1,
    downloadWithName: cn,
    sendNotifyOnComplete: !1,
    subtitlesMaxLength: 300,
    subtitlesSmartLayout: !0,
    highlightWords: !0,
    subtitlesFontSize: 20,
    subtitlesFontFamily: "default-sans",
    subtitlesOpacity: 20,
    subtitlesDownloadFormat: "srt",
    responseLanguage: Wn,
    defaultVolume: 100,
    onlyBypassMediaCSP: n,
    newAudioPlayer: n,
    showPiPButton: !1,
    translateAPIErrors: !0,
    translationService: bi,
    detectService: Ks,
    translationHotkey: null,
    subtitlesHotkey: null,
    m3u8ProxyHost: qd,
    proxyWorkerHost: rn,
    translateProxyEnabled: 0,
    translateProxyEnabledDefault: !0,
    audioBooster: !1,
    useLivelyVoice: !1,
    autoHideButtonDelay: Ys,
    // Audio download now uses direct network requests (GM_fetch/GM_xmlhttpRequest).
    useAudioDownload: cn,
    compatVersion: "",
    account: {},
    localeHash: "",
    localeUpdatedAt: 0
  }), this.data.compatVersion !== an && (this.data = await Gh(this.data), await C.set("compatVersion", an));
  try {
    if (Wn === "en" && this.data?.enabledDontTranslateLanguages && Array.isArray(this.data?.dontTranslateLanguages) && this.data.dontTranslateLanguages.length === 1 && this.data.dontTranslateLanguages[0] === "en" && typeof this.data.responseLanguage == "string" && this.data.responseLanguage !== "en") {
      const t = this.data.responseLanguage;
      this.data.dontTranslateLanguages = [t], await C.set(
        "dontTranslateLanguages",
        this.data.dontTranslateLanguages
      );
    }
  } catch {
  }
  if (this.uiManager.data = this.data, console.log("[VOT] data from db:", this.data), this.data.translateProxyEnabled, await gw(), Ce && Vl.includes(Ce) && this.data.translateProxyEnabledDefault && (this.data.translateProxyEnabled = 2), V.log(
    "translateProxyEnabled",
    this.data.translateProxyEnabled,
    this.data.translateProxyEnabledDefault
  ), await this.initVOTClient(), this.uiManager.initUI(), this.uiManager.initUIEvents(), gs()) {
    const t = globalThis.__votPopupOverlayBridge ?? new Vs();
    globalThis.__votPopupOverlayBridge = t, this.popupOverlayBridge = t, this.popupOverlayBridge.setOwner(this.popupOwnerId), this.popupOverlayBridge.bind(), this.popupOverlayBridge.setHandlers({
      onTranslate: () => {
        this.popupOverlayBridge?.isOwner(this.popupOwnerId) && this.uiManager.handleTranslationBtnClick();
      },
      onTurnOff: () => {
        this.popupOverlayBridge?.isOwner(this.popupOwnerId) && this.stopTranslation();
      },
      onDownload: () => {
        this.uiManager.handleDownloadTranslationClick?.();
      },
      onDownloadSubtitles: () => {
        this.uiManager.handleDownloadSubtitlesClick?.();
      },
      onToggleSubtitles: () => {
        (async () => {
          try {
            this.resetSubtitlesWidget(), await this.ensureSubtitlesForCurrentLangPair(), await this.toggleSubtitlesForCurrentLangPair();
          } finally {
            this.syncPopupOverlayState({
              subtitlesEnabled: !!(this.yandexSubtitles && Array.isArray(this.yandexSubtitles.subtitles) && this.yandexSubtitles.subtitles.length > 0),
              canDownloadSubtitles: !!this.yandexSubtitles
            });
          }
        })();
      },
      onFromLanguageChange: (e) => {
        this.videoData && (this.videoData.detectedLanguage = e, this.videoManager.rememberUserLanguageSelection(this.videoData.videoId, e)), this.setSelectMenuValues(e, this.videoData?.responseLanguage ?? this.translateToLang), this.syncPopupOverlayState({ fromLangValue: e });
      },
      onToLanguageChange: (e) => {
        this.translateToLang = e, this.videoData && (this.videoData.responseLanguage = e), this.data.responseLanguage = e, C.set("responseLanguage", e), this.setSelectMenuValues(this.videoData?.detectedLanguage ?? this.translateFromLang, e), this.syncPopupOverlayState({ toLangValue: e });
      },
      onAutoTranslateChange: (e) => {
        this.data.autoTranslate = e, C.set("autoTranslate", e), this.syncPopupOverlayState({ autoTranslateEnabled: e });
      },
      onAutoSubtitlesChange: (e) => {
        this.data.autoSubtitles = e, C.set("autoSubtitles", e), this.syncPopupOverlayState({ autoSubtitlesEnabled: e });
      },
      onSyncVolumeChange: (e) => {
        this.data.syncVolume = e, C.set("syncVolume", e), this.syncPopupOverlayState({ syncVolumeEnabled: e });
      },
      onShowVideoSliderChange: (e) => {
        this.data.showVideoSlider = e, C.set("showVideoSlider", e), this.uiManager.votOverlayView?.videoVolumeSlider && (this.uiManager.votOverlayView.videoVolumeSlider.hidden = !e || this.uiManager.votOverlayView.votButton?.status !== "success"), this.syncPopupOverlayState({ showVideoSliderEnabled: e });
      },
      onAudioBoosterChange: (e) => {
        this.data.audioBooster = e, C.set("audioBooster", e);
        const i = this.uiManager.votOverlayView?.translationVolumeSlider;
        i && (i.max = e ? 300 : 100, !e && Number(i.value) > 100 && (i.value = 100, this.audioPlayer?.player && (this.audioPlayer.player.volume = 1), this.data.defaultVolume = 100)), this.syncPopupOverlayState({
          audioBoosterEnabled: e,
          translationVolume: Number(this.uiManager.votOverlayView?.translationVolumeSlider?.value ?? this.data.defaultVolume ?? 100)
        });
      },
      onAutoVolumeChange: (e) => {
        this.data.enabledAutoVolume = e, C.set("enabledAutoVolume", e), this.setupAudioSettings(), this.syncPopupOverlayState({ autoVolumeEnabled: e });
      },
      onSmartDuckingChange: (e) => {
        this.data.enabledSmartDucking = e, C.set("enabledSmartDucking", e), this.syncPopupOverlayState({ smartDuckingEnabled: e });
      },
      onVideoVolumeChange: (e) => {
        this.setVideoVolume(e / 100), this.onVideoVolumeSliderSynced(e), this.uiManager.votOverlayView?.videoVolumeSlider && (this.uiManager.votOverlayView.videoVolumeSlider.value = e), this.syncPopupOverlayState({ videoVolume: e });
      },
      onTranslationVolumeChange: (e) => {
        this.data.defaultVolume = e, this.audioPlayer?.player && (this.audioPlayer.player.volume = e / 100), this.onTranslationVolumeSliderSynced(e), this.uiManager.votOverlayView?.translationVolumeSlider && (this.uiManager.votOverlayView.translationVolumeSlider.value = e), this.syncPopupOverlayState({ translationVolume: e });
      }
    }), this.uiManager.votOverlayView?.votButton?.container && (this.uiManager.votOverlayView.votButton.container.style.display = "none"), this.syncPopupOverlayState({
      status: "none",
      label: p.get("translateVideo"),
      hint: "Popup mode for Google-hosted players."
    });
  }
  this.translateToLang = this.data.responseLanguage ?? "ru", this.initExtraEvents(), this.site.host === "custom" && this.overlayVisibility?.queueAutoHide(), this.initialized = !0;
}
function pw(n, t = "Operation timed out") {
  return new Promise(
    (e, i) => setTimeout(() => i(new Error(t)), n)
  );
}
const bw = "und", yw = /* @__PURE__ */ new Map(), vw = /* @__PURE__ */ new Map(), ww = (n) => {
  if (n)
    try {
      return Intl.getCanonicalLocales(n)[0];
    } catch {
      return;
    }
}, Sw = (n) => {
  const t = ww(n);
  if (t)
    return Intl.Segmenter.supportedLocalesOf([t])[0];
}, wc = (n, t) => {
  const e = Sw(n), i = `${t}:${e ?? bw}`, s = t === "sentence" ? vw : yw, o = s.get(i);
  if (o) return o;
  const r = new Intl.Segmenter(e, { granularity: t });
  return s.set(i, r), r;
}, Sc = (n, t) => n ? Array.from(wc(t, "word").segment(n), (e) => ({
  text: e.segment,
  index: e.index,
  isWordLike: !!e.isWordLike
})) : [], Tw = (n, t) => n ? Array.from(wc(t, "sentence").segment(n), (e) => ({
  text: e.segment,
  index: e.index
})) : [], ai = /\s/u, kw = /^[,.:;!?%)\]}>В»]/u, Lw = /[([{'"В«вЂћ-]$/u, Da = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/u, Tc = (n) => !!n.trim(), xw = (n, t) => {
  const e = n.at(-1) ?? "", i = t[0] ?? "";
  return !(!e || !i || ai.test(e) || ai.test(i) || Lw.test(n) || kw.test(t) || Da.test(e) && Da.test(i));
}, Aw = (n) => {
  let t = "", e = "";
  const i = [];
  for (const s of n) {
    const o = s.text.trim();
    if (!o) continue;
    t && xw(e, o) && (t += " ");
    const r = t.length;
    t += o;
    const a = t.length;
    i.push({
      line: {
        ...s,
        text: o
      },
      text: o,
      start: r,
      end: a
    }), e = o;
  }
  return { streamText: t, spans: i };
}, Ew = (n, t, e) => {
  let i = t, s = e;
  for (; i < s && ai.test(n[i] ?? ""); )
    i += 1;
  for (; s > i && ai.test(n[s - 1] ?? ""); )
    s -= 1;
  return i >= s ? null : {
    start: i,
    end: s
  };
}, Vw = (n, t, e) => {
  const i = Math.max(t, n.start), s = Math.min(e, n.end);
  if (i >= s)
    return null;
  const o = i - n.start, r = s - n.start, a = n.text.slice(o, r);
  if (!a)
    return null;
  const l = Math.max(n.text.length, 1), u = n.line.startMs + Math.round(n.line.durationMs * o / l), d = n.line.startMs + Math.round(n.line.durationMs * r / l);
  return {
    text: a,
    startMs: u,
    durationMs: Math.max(0, d - u),
    isWordLike: Tc(a)
  };
}, Cw = (n, t, e) => {
  const i = e.index, s = i + e.text.length, o = Ew(n, i, s);
  if (!o)
    return null;
  const r = n.slice(o.start, o.end);
  if (!Tc(r))
    return null;
  const a = [];
  let l = "0";
  for (const h of t) {
    const f = Vw(h, o.start, o.end);
    f && (a.length === 0 && (l = h.line.speakerId), a.push(f));
  }
  if (!a.length)
    return null;
  const u = Math.min(...a.map((h) => h.startMs)), d = Math.max(
    ...a.map((h) => h.startMs + Math.max(0, h.durationMs))
  );
  return {
    text: r,
    startMs: u,
    durationMs: Math.max(0, d - u),
    speakerId: l,
    tokens: a
  };
}, Iw = (n, t) => {
  const { streamText: e, spans: i } = Aw(n);
  if (!e || !i.length)
    return [];
  const o = Tw(e, t).map((r) => Cw(e, i, r)).filter((r) => r !== null);
  return o.length ? o : i.map(({ line: r }) => r);
}, Pw = (n) => n === "json" || n === "srt" || n === "vtt" || n === "ass", Mw = (n) => !!(n && typeof n == "object"), Ow = (n) => typeof n == "number" && Number.isFinite(n) ? n : 0, li = (n) => Math.max(0, Ow(n)), Dw = (n) => Mw(n) ? typeof n.source == "string" && Pw(n.format) && typeof n.language == "string" && typeof n.url == "string" && (n.translatedFromLanguage === void 0 || typeof n.translatedFromLanguage == "string") && (n.isAutoGenerated === void 0 || typeof n.isAutoGenerated == "boolean") : !1, _w = (n, t, e) => {
  const i = n.subtitles;
  if (!Array.isArray(i) || i.length === 0) return null;
  const s = t ?? e;
  if (s) {
    const o = i.find(
      (a) => a.language === s && typeof a.translatedFromLanguage == "string"
    );
    if (o) return o;
    const r = i.find((a) => a.language === s);
    if (r) return r;
  }
  return i[0] ?? null;
}, kc = (n) => {
  try {
    return new URL(n, globalThis.location.href).toString();
  } catch {
    return String(n || "");
  }
}, Rw = (n, t) => {
  const e = kc(t);
  if (!e)
    return !1;
  try {
    if (typeof n.isDirectMediaUrl == "function") {
      if (!n.isDirectMediaUrl(e))
        return !1;
    } else
      return !1;
    return new URL(e).hostname !== globalThis.location.hostname;
  } catch {
    return !1;
  }
}, Bw = (n, t) => {
  try {
    return String(t?.host || globalThis.location?.hostname || "") === "custom" ? !0 : Rw(n, t?.url);
  } catch {
    return !0;
  }
}, Fw = (n) => {
  const t = N.getPoToken();
  if (!t) return n;
  let e = t;
  for (let o = 0; o < 10; o += 1) {
    let r;
    try {
      r = decodeURIComponent(e);
    } catch {
      break;
    }
    if (r === e)
      break;
    e = r;
  }
  const i = N.getDeviceParams(), s = typeof i == "string" ? i.replace(/^[?&]+/u, "") : "";
  try {
    const o = new URL(n);
    if (o.searchParams.set("potc", "1"), o.searchParams.set("pot", e), s) {
      const r = new URLSearchParams(s);
      for (const [a, l] of r.entries())
        o.searchParams.set(a, l);
    }
    return o.toString();
  } catch {
    const o = n.includes("?") ? "&" : "?", r = s ? `&${s}` : "";
    return `${n}${o}potc=1&pot=${encodeURIComponent(e)}${r}`;
  }
}, _a = (n, t) => n - t, Nn = (n, t) => n < t ? -1 : n > t ? 1 : 0, Nw = (n, t) => {
  const e = Math.min(n.length, t.length);
  for (let i = 0; i < e; i += 1) {
    const s = n[i] - t[i];
    if (s !== 0) return s;
  }
  return n.length !== t.length ? n.length - t.length : 0;
}, Uw = (n, t, e) => n ? t === 0 ? e ? 1 : 0 : e ? 0 : 1 : 0, Hw = (n, t, e, i) => !n || !t || e === i ? 0 : 1, $w = (n, t) => {
  const e = n.source === "yandex", i = e ? 0 : 1, s = n.language === Xs ? 0 : 1, o = !!n.translatedFromLanguage, r = t && n.language === t ? 0 : 1, a = Uw(
    e,
    r,
    o
  ), l = Hw(
    e,
    o,
    n.translatedFromLanguage,
    t
  ), u = e && !o ? r : 0, d = e ? 0 : +!!n.isAutoGenerated;
  return [
    i,
    s,
    a,
    l,
    u,
    d
  ];
}, Ww = (n, t, e) => ({
  descriptor: n,
  index: t,
  rank: $w(n, e),
  language: n.language,
  translatedFromLanguage: n.translatedFromLanguage ?? "",
  source: n.source,
  url: n.url,
  isAutoGenerated: +!!n.isAutoGenerated
}), zw = (n, t) => {
  const e = n.map(
    (i, s) => Ww(i, s, t)
  );
  return e.sort((i, s) => {
    const o = Nw(i.rank, s.rank);
    if (o !== 0) return o;
    const r = Nn(i.language, s.language) || Nn(
      i.translatedFromLanguage,
      s.translatedFromLanguage
    ) || Nn(i.source, s.source) || Nn(i.url, s.url) || _a(i.isAutoGenerated, s.isAutoGenerated);
    return r !== 0 ? r : _a(i.index, s.index);
  }), e.map((i) => i.descriptor);
}, qw = (n, t) => typeof n == "boolean" ? n : !!t.trim(), Gw = (n) => {
  if (!n || typeof n != "object")
    return {
      text: "",
      startMs: 0,
      durationMs: 0,
      isWordLike: !1
    };
  const t = n, e = typeof t.text == "string" ? t.text : "";
  return {
    text: e,
    startMs: li(t.startMs),
    durationMs: li(t.durationMs),
    isWordLike: qw(t.isWordLike, e)
  };
}, Kw = (n) => {
  if (!n || typeof n != "object")
    return {
      text: "",
      startMs: 0,
      durationMs: 0,
      speakerId: "0",
      tokens: []
    };
  const t = n, e = Array.isArray(t.tokens) ? t.tokens.map(Gw) : [];
  return {
    text: typeof t.text == "string" ? t.text : "",
    startMs: li(t.startMs),
    durationMs: li(t.durationMs),
    speakerId: typeof t.speakerId == "string" ? t.speakerId : "0",
    tokens: e
  };
}, Ra = (n) => {
  if (!n || typeof n != "object")
    return { format: "json", subtitles: [] };
  const t = n, e = Array.isArray(t.subtitles) ? t.subtitles.map(Kw) : [];
  return { format: t.format ?? "json", subtitles: e };
}, Yw = /<(?:\d{1,2}:)?\d{2}:\d{2}(?:[.,]\d{1,3})?>/gu, jw = 120, Xw = /\s+([,.:;!?])/gu, Jw = /[ \t]*\n[ \t]*/gu, Zw = /[ \t]{2,}/gu, Qw = /\n{3,}/gu, tS = /\s+/gu;
let ns = null;
const eS = (n) => {
  if (!n.includes("<")) return n;
  if (typeof document < "u") {
    ns || (ns = document.createElement("template"));
    const t = ns;
    return t.innerHTML = n, t.content.textContent ?? "";
  }
  return n.replaceAll(/<\/?[^>]+>/gu, "");
}, Ba = (n) => {
  let t = n;
  return t.includes("<") && (t = eS(
    t.replaceAll(Yw, "")
  )), t.replaceAll(Xw, "$1").replaceAll(Jw, `
`).replaceAll(Zw, " ").replaceAll(Qw, `

`).trim();
}, nS = (n) => n.toLowerCase().replaceAll(tS, " ").trim(), iS = (n, t) => !t || n.tStartMs + n.dDurationMs <= t.tStartMs ? Math.max(0, n.dDurationMs) : Math.max(0, t.tStartMs - n.tStartMs), sS = (n, t, e) => {
  const i = [];
  let s = "", o = e;
  for (let r = 0; r < t.length; r += 1) {
    const a = t[r], l = typeof a.utf8 == "string" ? a.utf8 : "";
    if (!l) continue;
    const u = Math.max(0, a.tOffsetMs ?? 0);
    let d = e;
    const h = t[r + 1];
    if (h?.tOffsetMs !== void 0) {
      const g = Math.max(u, h.tOffsetMs);
      d = Math.max(0, g - u), o = Math.max(o - d, 0);
    }
    let f = Math.max(0, o);
    h && (f = Math.max(0, d)), i.push({
      text: l,
      startMs: n.tStartMs + u,
      durationMs: f,
      isWordLike: !!l.trim()
    }), s += l;
  }
  return { text: s, sourceTokens: i };
}, oS = (n) => n.durationMs > 0, rS = (n) => n.text ? Ve(n.text) : n.tokens.length ? Ve(
  n.tokens.map((t) => t.text).join("")
) : "", Cs = (n, t, e) => {
  if (!n.length) return [];
  const i = Math.max(0, e), s = n.map((l) => Math.max(l.length, 1)), o = s.reduce((l, u) => l + u, 0), r = new Array(s.length + 1).fill(0);
  for (let l = 0; l < s.length; l += 1)
    r[l + 1] = r[l] + s[l];
  const a = [];
  for (let l = 0; l < n.length; l += 1) {
    const u = Math.round(i * r[l] / o), d = l === n.length - 1 ? i : Math.round(i * r[l + 1] / o);
    a.push({
      startMs: t + u,
      durationMs: Math.max(0, d - u)
    });
  }
  return a;
}, aS = (n) => {
  const t = [];
  let e = 0;
  for (let i = 0; i < n.length; i += 1)
    n[i] === `
` && (e < i && t.push({
      text: n.slice(e, i),
      startOffset: e,
      endOffset: i
    }), t.push({
      text: `
`,
      startOffset: i,
      endOffset: i + 1
    }), e = i + 1);
  return e < n.length && t.push({
    text: n.slice(e),
    startOffset: e,
    endOffset: n.length
  }), t.length ? t : [
    {
      text: n,
      startOffset: 0,
      endOffset: n.length
    }
  ];
}, lS = (n, t) => {
  const e = [];
  for (const i of n) {
    const s = Ve(i.text);
    if (!s || !oS(i)) continue;
    const o = Sc(s, t).filter(
      (a) => a.isWordLike && a.text.trim()
    );
    if (!o.length) continue;
    const r = Cs(
      o.map((a) => a.text),
      i.startMs,
      i.durationMs
    );
    e.push(...r);
  }
  return e;
}, cS = (n, t, e) => {
  if (!e) return [];
  const i = t.language, s = n.metadata?.styledSpans ?? wn(n.metadata?.rawText ?? n.text ?? e).styledSpans, o = Sc(e, i);
  if (!o.length) return [];
  const r = Cs(
    o.map((h) => h.text),
    n.startMs,
    n.durationMs
  ), a = [];
  for (let h = 0; h < o.length; h += 1) {
    const f = o[h], g = r[h]?.startMs ?? n.startMs, m = r[h]?.durationMs ?? 0, v = aS(f.text);
    if (v.length === 1 && v[0].text === f.text) {
      a.push({
        text: f.text,
        startMs: g,
        durationMs: m,
        isWordLike: f.isWordLike,
        style: ya(
          s,
          f.index,
          f.index + f.text.length
        )
      });
      continue;
    }
    const T = Cs(
      v.map((S) => S.text === `
` ? "" : S.text),
      g,
      m
    );
    for (let S = 0; S < v.length; S += 1) {
      const w = v[S], x = w.text === `
`;
      a.push({
        text: w.text,
        startMs: T[S]?.startMs ?? g,
        durationMs: x ? 0 : T[S]?.durationMs ?? 0,
        isWordLike: !x && f.isWordLike,
        style: x ? void 0 : ya(
          s,
          f.index + w.startOffset,
          f.index + w.endOffset
        )
      });
    }
  }
  const l = lS(n.tokens, i);
  if (!l.length) return a;
  const u = a.reduce((h, f, g) => (f.isWordLike && f.text.trim() && h.push(g), h), []);
  if (!u.length) return a;
  const d = u.length;
  for (let h = 0; h < d; h += 1) {
    const f = u[h], g = Math.floor(
      h * l.length / d
    ), m = l[Math.min(g, l.length - 1)];
    a[f] = {
      ...a[f],
      startMs: m.startMs,
      durationMs: m.durationMs
    };
  }
  return a;
}, uS = async (n, t) => {
  const e = await nt(n, { timeout: 7e3 });
  if (t === "vtt" || t === "srt" || t === "ass") {
    const i = await e.text();
    return jy(i, t);
  }
  return e.json();
}, dS = (n, t) => {
  if (t.source === "youtube")
    return Ie.formatYoutubeSubtitles(
      n,
      !!t.isAutoGenerated
    );
  if (t.format === "srt" || t.format === "vtt" || t.format === "ass")
    return Sa(Ra(n));
  const e = Ra(n);
  return t.source === "vk" && t.format === "json" ? Ie.cleanJsonSubtitles(e) : Sa(e);
}, hS = (n, t) => {
  const e = Ie.autoMerge(n, t);
  return {
    ...e,
    subtitles: Ie.processTokens(e, t)
  };
}, fS = (n) => {
  const t = [], e = /* @__PURE__ */ new Set();
  for (const i of n.subtitles ?? [])
    i.language && !e.has(i.language) && (e.add(i.language), t.push({
      source: "yandex",
      format: "json",
      language: i.language,
      url: i.url
    })), i.translatedLanguage && t.push({
      source: "yandex",
      format: "json",
      language: i.translatedLanguage,
      translatedFromLanguage: i.language,
      url: i.translatedUrl ?? i.url
    });
  return t;
}, Ie = {
  processTokens(n, t) {
    const e = [];
    for (const i of n.subtitles) {
      const s = rS(i), o = cS(i, t, s);
      e.push({
        ...i,
        text: s,
        tokens: o
      });
    }
    return e;
  },
  formatYoutubeSubtitles(n, t = !1) {
    const e = n.events ?? [];
    if (!e.length)
      return console.error("[VOT] Invalid YouTube subtitles format:", n), { format: "json", subtitles: [] };
    const i = [];
    for (let s = 0; s < e.length; s += 1) {
      const o = e[s], r = o.segs;
      if (!r?.length) continue;
      const a = e[s + 1], l = iS(o, a), { text: u, sourceTokens: d } = sS(
        o,
        r,
        l
      ), h = u.trim();
      h && i.push({
        text: h,
        startMs: o.tStartMs,
        durationMs: l,
        speakerId: "0",
        tokens: t ? d : []
      });
    }
    return {
      format: "json",
      subtitles: i
    };
  },
  autoMerge(n, t) {
    return !t.isAutoGenerated || n.subtitles.length < 2 || !n.subtitles.some((e) => e.tokens.length > 0) ? n : {
      ...n,
      subtitles: Iw(
        n.subtitles,
        t.language
      )
    };
  },
  cleanJsonSubtitles(n) {
    const t = (o) => o.startMs + Math.max(0, o.durationMs), e = (o) => {
      let r = 0;
      for (const a of o)
        r += a.text.length;
      return r;
    }, i = [];
    for (const o of n.subtitles) {
      const r = Ba(o.text);
      if (!r) continue;
      const a = [];
      for (const l of o.tokens) {
        const u = Ba(l.text);
        u && a.push({
          ...l,
          text: u
        });
      }
      i.push({
        line: {
          ...o,
          text: r,
          tokens: a
        },
        comparableText: nS(r),
        tokensTextLength: e(a)
      });
    }
    const s = [];
    for (const o of i) {
      const {
        line: r,
        comparableText: a,
        tokensTextLength: l
      } = o;
      if (!a) continue;
      const u = s.at(-1);
      if (!u) {
        s.push(o);
        continue;
      }
      const d = t(u.line), h = t(r), f = u.comparableText === a, g = r.startMs <= d + jw;
      if (!f || !g) {
        s.push(o);
        continue;
      }
      const m = Math.min(u.line.startMs, r.startMs), v = Math.max(d, h), T = l >= u.tokensTextLength ? r.tokens : u.line.tokens;
      u.line = {
        ...u.line,
        startMs: m,
        durationMs: Math.max(0, v - m),
        tokens: T
      }, u.tokensTextLength = Math.max(
        u.tokensTextLength,
        l
      );
    }
    return {
      ...n,
      subtitles: s.map(({ line: o }) => o)
    };
  },
  async fetchSubtitles(n, t, e) {
    const i = Dw(n) ? n : _w(
      n,
      t,
      e
    );
    if (!i)
      return { format: "json", subtitles: [] };
    const { source: s, format: o } = i;
    let { url: r } = i;
    s === "youtube" && (r = Fw(r));
    try {
      const a = await uS(r, o), l = dS(a, i), u = hS(
        l,
        i
      );
      return V.log("[VOT] Processed subtitles:", u), u;
    } catch (a) {
      return console.error("[VOT] Failed to process subtitles:", a), { format: "json", subtitles: [] };
    }
  },
  async getSubtitles(n, t) {
    const {
      host: e,
      url: i,
      detectedLanguage: s,
      videoId: o,
      duration: r,
      subtitles: a = []
    } = t;
    try {
      const l = {
        videoData: {
          host: e,
          url: i,
          videoId: o,
          duration: r
        },
        requestLang: s
      }, u = n, h = Bw(
        u,
        t
      ) && typeof u.getSubtitlesYAImpl == "function" ? u.getSubtitlesYAImpl({
        videoData: {
          ...t,
          url: kc(t.url)
        },
        requestLang: s,
        headers: {}
      }) : n.getSubtitles(l), g = await Promise.race([
        h,
        pw(5e3, "Timeout")
      ]);
      V.log("[VOT] Subtitles response:", g), g.waiting && console.error("[VOT] Failed to get Yandex subtitles");
      const v = [...fS(g), ...a];
      return zw(v, s);
    } catch (l) {
      let u = "Error in getSubtitles function";
      throw l instanceof Error && l.message === "Timeout" && (u = "Failed to get Yandex subtitles: timeout"), console.error(`[VOT] ${u}`, l), l;
    }
  }
}, Is = "https://vtrans.s3-private.mds.yandex.net/tts/prod/", ci = "/video-translation/audio-proxy/", Fa = "https://brosubs.s3-private.mds.yandex.net/vtrans/", gS = "/video-subtitles/subtitles-proxy/";
function ro(n) {
  return n ?? rn;
}
function Lc(n) {
  return n.translateProxyEnabled === 2;
}
function mS(n, t) {
  return !Lc(t) || !n.startsWith(Is) ? n : n.replace(
    Is,
    `https://${ro(t.proxyWorkerHost)}${ci}`
  );
}
function pS(n) {
  const t = String(n || "");
  if (!t) return t;
  try {
    const e = new URL(t);
    return e.pathname.startsWith(ci) ? (e.host = "vtrans.s3-private.mds.yandex.net", e.pathname = `/tts/prod/${e.pathname.slice(ci.length).replace(/^\/+/, "")}`, e.protocol = "https:", e.toString()) : t;
  } catch {
    return t;
  }
}
function bS(n, t) {
  return n.startsWith(Is) || n.startsWith(
    `https://${ro(t.proxyWorkerHost)}${ci}`
  );
}
function yS(n, t) {
  if (!Lc(t) || !n.startsWith(Fa))
    return n;
  const e = n.slice(Fa.length);
  return `https://${ro(t.proxyWorkerHost)}${gS}${e}`;
}
const ut = "disabled", vS = /* @__PURE__ */ new Set([
  "srt",
  "vtt",
  "ass",
  "json"
]), wS = /^\d+$/u, Ps = /* @__PURE__ */ new WeakMap(), Na = /* @__PURE__ */ new WeakMap();
function Ua() {
  return /(?:^|\.)vkvideo\.ru$|(?:^|\.)vk\.(?:com|ru)$/i.test(
    String(globalThis.location.hostname || "")
  );
}
function SS(n) {
  const t = n.videoData;
  if (!t?.videoId)
    return null;
  const e = lo(n);
  if (!e)
    return null;
  const i = ao(n);
  return i ? n.getSubtitlesCacheKey(
    t.videoId,
    e,
    i
  ) : null;
}
function ao(n) {
  const t = n.videoData;
  return n.getPreferredSubtitlesLanguage(
    t?.detectedLanguage,
    t?.responseLanguage
  ) ?? t?.responseLanguage ?? n.translateToLang;
}
function lo(n) {
  const t = String(
    n.videoData?.detectedLanguage || ""
  ).trim().toLowerCase();
  if (t && t !== "auto")
    return t;
  const e = String(n.translateFromLang || "").trim().toLowerCase();
  return e && e !== "auto" ? e : "auto";
}
function TS(n) {
  return n !== null && typeof n == "object";
}
function co(n) {
  if (!TS(n))
    return null;
  const t = n, e = t.format;
  return typeof t.source != "string" || typeof t.language != "string" || typeof t.url != "string" || typeof e != "string" || !vS.has(e) ? null : {
    source: t.source,
    format: e,
    language: t.language,
    url: t.url,
    translatedFromLanguage: typeof t.translatedFromLanguage == "string" ? t.translatedFromLanguage : void 0,
    isAutoGenerated: typeof t.isAutoGenerated == "boolean" ? t.isAutoGenerated : void 0
  };
}
function xc(n) {
  const t = [];
  for (let e = 0; e < n.length; e += 1) {
    const i = co(n[e]);
    i && t.push({
      descriptor: i,
      index: e
    });
  }
  return t;
}
function kS(n) {
  return {
    index: n.index,
    language: n.descriptor.language,
    translatedFromLanguage: n.descriptor.translatedFromLanguage ?? "",
    source: n.descriptor.source,
    isAutoGenerated: !!n.descriptor.isAutoGenerated,
    url: n.descriptor.url
  };
}
function en(n) {
  const t = globalThis;
  if (n.tracks && (t.__VOT_SUBTITLE_TRACKS__ = n.tracks), "selected" in n) {
    t.__VOT_LAST_SUBTITLE_TRACK__ = n.selected;
    const e = typeof n.selected?.effectiveUrl == "string" ? n.selected.effectiveUrl : null;
    t.__PVL_LAST_TRANSLATED_SUBTITLES_URL = e, t.__VOT_LAST_EXTERNAL_SUBTITLE_URL__ = e;
  }
}
function LS(n, t) {
  const e = t.map(kS);
  en({ tracks: e });
  const i = e.map(
    (s) => [
      s.index,
      s.language,
      s.translatedFromLanguage,
      s.source,
      s.isAutoGenerated ? "1" : "0",
      s.url
    ].join("|")
  ).join("||");
  Na.get(n) !== i && Na.set(n, i);
}
function Ms(...n) {
  const t = [], e = /* @__PURE__ */ new Set();
  for (const i of n)
    for (const s of i) {
      const o = co(s);
      if (!o)
        continue;
      const r = [
        o.source,
        o.language,
        o.translatedFromLanguage ?? "",
        o.url
      ].join("|");
      e.has(r) || (e.add(r), t.push(o));
    }
  return t;
}
function xS(n) {
  if (!wS.test(n))
    return null;
  const t = Number(n);
  return Number.isSafeInteger(t) ? t : null;
}
function AS(n, t) {
  return !Number.isInteger(t) || t < 0 || t >= n.length ? null : co(n[t]);
}
function ES(n) {
  const t = (Ps.get(n) ?? 0) + 1;
  return Ps.set(n, t), t;
}
function VS(n, t) {
  return Ps.get(n) === t;
}
function CS() {
  return {
    label: p.get("VOTSubtitlesDisabled"),
    value: ut,
    selected: !0,
    disabled: !1
  };
}
function IS(n, t = ut) {
  const e = [
    {
      ...CS(),
      selected: t === ut
    }
  ];
  for (const { descriptor: i, index: s } of n)
    e.push({
      label: PS(i),
      value: String(s),
      selected: String(s) === t,
      disabled: !1
    });
  return e;
}
function Ac(n) {
  const e = n[Symbol.iterator]().next();
  return e.done ? void 0 : e.value;
}
function PS(n) {
  const t = p.getLangLabel(n.language), e = n.translatedFromLanguage ? ` ${p.get("VOTTranslatedFrom")} ${p.getLangLabel(
    n.translatedFromLanguage
  )}` : "", i = n.source === "yandex" ? "" : `, ${globalThis.location.hostname}`, s = n.isAutoGenerated ? ` (${p.get("VOTAutogenerated")})` : "";
  return `${t}${e}${i}${s}`;
}
function mn(n) {
  return (n ?? "").toLowerCase();
}
function ui(n) {
  return mn(n).split(/[-_]/)[0];
}
function Dt(n, t) {
  if (!n || !t) return !1;
  const e = mn(n), i = mn(t);
  return e === i || ui(e) === ui(i);
}
function MS(n, t, e) {
  if (!n.length) return null;
  const i = mn(t), s = mn(e), o = i === "auto" || i === "", r = ui(i), a = ui(s), l = (w) => w.source === "yandex", u = (w) => !!w.isAutoGenerated, d = (w, x, I) => Dt(w.language, I) ? o ? !0 : Dt(w.translatedFromLanguage, x) : !1, h = (w, x) => Dt(w.language, x) ? w.translatedFromLanguage ? Dt(w.translatedFromLanguage, x) : !0 : !1, f = (w) => n.find(({ descriptor: x }) => w(x))?.index ?? null, g = () => {
    const w = f(
      (x) => !l(x) && Dt(x.language, s) && !u(x)
    );
    return w ?? f(
      (x) => !l(x) && Dt(x.language, s) && u(x)
    );
  }, m = f((w) => l(w) && d(w, i, s));
  if (m != null) return m;
  if (!o && r && a && r === a) {
    const w = f(
      (A) => h(A, s) && !u(A)
    );
    if (w != null) return w;
    const x = f(
      (A) => h(A, s) && u(A)
    );
    if (x != null) return x;
    const I = g();
    if (I != null) return I;
    const k = f(
      (A) => l(A) && Dt(A.language, s)
    );
    if (k != null) return k;
  }
  const v = f((w) => l(w) && Dt(w.language, s));
  if (v != null) return v;
  const T = f((w) => !l(w) && d(w, i, s));
  if (T != null) return T;
  const S = g();
  return S ?? null;
}
async function OS(n) {
  const t = ES(this), e = this.uiManager.votOverlayView;
  if (!e?.subtitlesSelect || !e.downloadSubtitlesButton)
    return this;
  if (e.subtitlesSelect.setSelectedValue(n), n === ut)
    return this.hasSubtitlesWidget() && this.subtitlesWidget?.setContent(null), e.downloadSubtitlesButton.hidden = !0, this.yandexSubtitles = null, en({ selected: null }), this;
  const i = xS(n);
  if (i == null)
    return this.hasSubtitlesWidget() && this.subtitlesWidget?.setContent(null), e.downloadSubtitlesButton.hidden = !0, this.yandexSubtitles = null, this;
  const s = AS(
    this.subtitles,
    i
  );
  if (!s)
    return this.hasSubtitlesWidget() && this.subtitlesWidget?.setContent(null), e.downloadSubtitlesButton.hidden = !0, this.yandexSubtitles = null, en({ selected: null }), this;
  let o = { ...s };
  const r = yS(o.url, {
    translateProxyEnabled: this.data?.translateProxyEnabled,
    proxyWorkerHost: this.data?.proxyWorkerHost
  });
  r !== o.url && (o = {
    ...o,
    url: r
  }, console.log(`[VOT] Subs proxied via ${o.url}`));
  const a = {
    index: i,
    language: s.language,
    translatedFromLanguage: s.translatedFromLanguage ?? "",
    source: s.source,
    isAutoGenerated: !!s.isAutoGenerated,
    originalUrl: s.url,
    effectiveUrl: o.url
  };
  en({ selected: a });
  let l;
  try {
    l = await Ie.fetchSubtitles(o);
  } catch (d) {
    return console.error("[VOT][subtitles][fetch failed]", o, d), this;
  }
  return VS(this, t) ? Array.isArray(l.subtitles) && l.subtitles.length > 0 ? (this.yandexSubtitles = l, this.getSubtitlesWidget().setContent(
    this.yandexSubtitles,
    o.language
  ), e.downloadSubtitlesButton.hidden = !1, this) : (this.hasSubtitlesWidget() && this.subtitlesWidget?.setContent(null), e.subtitlesSelect.setSelectedValue(ut), e.downloadSubtitlesButton.hidden = !0, this.yandexSubtitles = null, this) : this;
}
async function DS() {
  const n = this.uiManager.votOverlayView;
  if (!n?.subtitlesSelect)
    return;
  const t = xc(this.subtitles);
  LS(this, t);
  const e = Ac(n.subtitlesSelect.selectedValues) ?? ut, i = e !== ut && this.hasSubtitlesWidget(), s = e === ut || t.some(({ index: a }) => String(a) === e), o = i && s ? e : ut, r = IS(
    t,
    o
  );
  n.subtitlesSelect.updateItems(r), n.subtitlesSelect.setSelectedValue(o), o === ut && e !== ut && (this.hasSubtitlesWidget() && this.subtitlesWidget?.setContent(null), n.downloadSubtitlesButton.hidden = !0, this.yandexSubtitles = null, en({ selected: null }));
}
async function Ec() {
  const n = SS(this);
  if (!n)
    return (this.subtitlesCacheKey !== null || this.subtitles.length > 0) && (this.subtitles = [], this.subtitlesCacheKey = null, await this.updateSubtitlesLangSelect()), this;
  if (this.subtitlesCacheKey === n && this.subtitles.length > 0)
    return this;
  const t = Array.isArray(this.videoData?.subtitles) ? this.videoData.subtitles : [], e = this.cacheManager.getSubtitles(n);
  return e !== void 0 && e.length > 0 ? (this.subtitles = Ms(
    t,
    Array.isArray(e) ? e : []
  ), this.subtitlesCacheKey = n, await this.updateSubtitlesLangSelect(), this) : (await this.loadSubtitles(), this);
}
async function _S() {
  if (!this.uiManager.votOverlayView?.subtitlesSelect) return this;
  try {
    await Ec.call(this);
  } catch (s) {
    return Ua() && console.warn("[VOT][VK probe] auto subtitles failed", s), this;
  }
  const t = lo(this) ?? this.translateFromLang, e = ao(this);
  if (!e)
    return this;
  const i = MS(
    xc(this.subtitles),
    t,
    e
  );
  return i == null ? (Ua() && console.warn("[VOT][VK probe] no suitable subtitles after load", {
    count: this.subtitles?.length || 0,
    fromLang: t,
    toLang: e,
    subtitles: this.subtitles
  }), this) : (await this.changeSubtitlesLang(ut), await this.changeSubtitlesLang(String(i)), this);
}
async function RS() {
  const n = this.uiManager.votOverlayView;
  if (!n?.subtitlesSelect) return this;
  const t = Ac(
    n.subtitlesSelect.selectedValues
  );
  return t && t !== ut ? (await this.changeSubtitlesLang(ut), this) : (await this.enableSubtitlesForCurrentLangPair(), this);
}
async function BS() {
  if (!this.videoData?.videoId) {
    console.error(
      `[VOT] ${p.getDefault("VOTNoVideoIDFound")}`
    ), this.subtitles = [], this.subtitlesCacheKey = null;
    return;
  }
  const n = ao(this);
  if (!n) {
    this.subtitles = [], this.subtitlesCacheKey = null, await this.updateSubtitlesLangSelect();
    return;
  }
  const t = lo(this);
  if (!t) {
    this.subtitles = [], this.subtitlesCacheKey = null, await this.updateSubtitlesLangSelect();
    return;
  }
  const e = this.getSubtitlesCacheKey(
    this.videoData.videoId,
    t,
    n
  ), i = Array.isArray(this.videoData.subtitles) ? this.videoData.subtitles : [];
  try {
    let s = this.cacheManager.getSubtitles(e);
    if (s === void 0 || s.length === 0) {
      let r = this.subtitlesLoadPromises.get(e);
      r === void 0 && (r = Ie.getSubtitles(
        this.votClient,
        {
          ...this.videoData,
          detectedLanguage: t,
          responseLanguage: n
        }
      ), this.subtitlesLoadPromises.set(e, r));
      try {
        s = await r, s = Array.isArray(s) ? s : [], s.length > 0 ? this.cacheManager.setSubtitles(e, s) : this.cacheManager.deleteSubtitles?.(e);
      } finally {
        this.subtitlesLoadPromises.get(e) === r && this.subtitlesLoadPromises.delete(e);
      }
    }
    const o = Array.isArray(s) ? s : [];
    this.subtitles = Ms(i, o), this.subtitlesCacheKey = e;
  } catch (s) {
    console.error("[VOT] Failed to load subtitles:", s), this.subtitles = Ms(i), this.subtitlesCacheKey = e;
  }
  await this.updateSubtitlesLangSelect();
}
const Yn = 0, jn = 1, Si = Object.freeze({
  tickMs: 50,
  thresholdOnRms: 0.012,
  thresholdOffRms: 9e-3,
  rmsAttackTauMs: 60,
  rmsReleaseTauMs: 240,
  holdMs: 520,
  attackTauMs: 110,
  releaseTauMs: 600,
  maxDownPerSec: 3.5,
  maxUpPerSec: 0.9,
  rmsMissingGraceMs: 200,
  maxDtMs: 250,
  externalBaselineDelta01: 0.02,
  unduckTolerance01: 0.01,
  volumeStep01: ei,
  applyDeltaThreshold01: ei / 2
});
function uo(n) {
  return {
    isDucked: !1,
    speechGateOpen: !1,
    rmsEnvelope: 0,
    baseline: se(n),
    lastApplied: void 0,
    lastTickAt: 0,
    lastSoundAt: 0,
    rmsMissingSinceAt: null
  };
}
function FS() {
  return uo();
}
function NS(n, t, e = Si) {
  const i = US(t), s = se(n.volumeOnStart);
  if (!n.translationActive)
    return {
      kind: "stop",
      runtime: i,
      restoreVolume: i.baseline ?? s
    };
  const o = Number.isFinite(n.nowMs) ? n.nowMs : Date.now(), r = i.lastTickAt || o, a = W(o - r, 0, e.maxDtMs), l = a / 1e3;
  i.lastTickAt = o;
  const u = Ut(n.rms), d = u ? W(n.rms, Yn, jn) : 0, h = i.rmsEnvelope, f = d > h ? e.rmsAttackTauMs : e.rmsReleaseTauMs, g = f > 0 ? -Math.expm1(-a / f) : 1;
  i.rmsEnvelope = W(
    h + (d - h) * g,
    Yn,
    jn
  );
  let m = i.speechGateOpen;
  n.audioIsPlaying && !u ? (i.rmsMissingSinceAt ?? (i.rmsMissingSinceAt = o), m && (i.lastSoundAt = o), i.rmsMissingSinceAt !== null && o - i.rmsMissingSinceAt >= e.rmsMissingGraceMs && (m = !0, i.lastSoundAt = o)) : (i.rmsMissingSinceAt = null, m ? n.audioIsPlaying && i.rmsEnvelope >= e.thresholdOffRms ? i.lastSoundAt = o : o - i.lastSoundAt > e.holdMs && (m = !1) : n.audioIsPlaying && i.rmsEnvelope >= e.thresholdOnRms && (m = !0, i.lastSoundAt = o)), i.speechGateOpen = m;
  const v = se(n.currentVideoVolume);
  if (!Ut(v))
    return { kind: "noop", runtime: i };
  i.isDucked && Ut(i.lastApplied) && Math.abs(v - i.lastApplied) > e.externalBaselineDelta01 && (i.baseline = v), i.isDucked || (i.baseline = v);
  const T = i.baseline ?? s ?? v;
  if (i.baseline = T, !n.hostVideoActive)
    return i.lastApplied = v, { kind: "noop", runtime: i };
  const S = se(n.duckingTarget01) ?? T, w = Math.min(T, S);
  let x = T;
  m ? (i.isDucked || (i.isDucked = !0), x = w) : i.isDucked && Math.abs(T - v) < e.unduckTolerance01 && (i.isDucked = !1);
  const I = x < v ? e.attackTauMs : e.releaseTauMs, k = I > 0 ? -Math.expm1(-a / I) : 1;
  let A = v + (x - v) * k;
  const $ = (x < v ? e.maxDownPerSec : e.maxUpPerSec) * l;
  $ > 0 && (A = W(
    A,
    v - $,
    v + $
  )), A = W(A, Yn, jn);
  const H = eb(
    A,
    v,
    x,
    e.volumeStep01
  ), _ = e.applyDeltaThreshold01;
  return Math.abs(H - v) < _ ? (i.lastApplied = H, { kind: "noop", runtime: i }) : !Ut(i.lastApplied) || Math.abs(H - i.lastApplied) >= _ ? (i.lastApplied = H, {
    kind: "apply",
    runtime: i,
    volume01: H
  }) : { kind: "noop", runtime: i };
}
function US(n) {
  return {
    isDucked: !!n.isDucked,
    speechGateOpen: !!n.speechGateOpen,
    rmsEnvelope: se(n.rmsEnvelope) ?? 0,
    baseline: se(n.baseline),
    lastApplied: se(n.lastApplied),
    lastTickAt: Ut(n.lastTickAt) ? n.lastTickAt : 0,
    lastSoundAt: Ut(n.lastSoundAt) ? n.lastSoundAt : 0,
    rmsMissingSinceAt: Ut(n.rmsMissingSinceAt) ? n.rmsMissingSinceAt : null
  };
}
function se(n) {
  if (Ut(n))
    return W(n, Yn, jn);
}
function Ut(n) {
  return typeof n == "number" && Number.isFinite(n);
}
const HS = Si.tickMs, Ha = 1200, $S = 100, $a = 1, ho = 4e3, di = /* @__PURE__ */ new WeakMap();
function Vc(n) {
  const t = String(n?.name ?? ""), e = String(
    n?.message ?? n ?? ""
  );
  return t === "AbortError" || e.includes(
    "The fetching process for the media resource was aborted"
  ) || e.includes("media resource was aborted by the user agent");
}
function is(n) {
  if (!n || typeof n != "object") return !1;
  const t = n;
  return typeof t.connect == "function" && typeof t.disconnect == "function";
}
function Wa(n) {
  return Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0;
}
function WS(n) {
  return Number.isFinite(n) ? Math.max(0, n) : 0;
}
function zS(n, t, e) {
  const i = e?.currentTime;
  if (typeof i == "number" && Number.isFinite(i)) {
    try {
      typeof n.cancelAndHoldAtTime == "function" ? n.cancelAndHoldAtTime(i) : typeof n.cancelScheduledValues == "function" && n.cancelScheduledValues(i);
    } catch {
    }
    if (typeof n.setValueAtTime == "function") {
      n.setValueAtTime(t, i);
      return;
    }
  }
  n.value = t;
}
function qS(n, t) {
  if (!n) return;
  const e = n.gainNode;
  e?.gain && zS(
    e.gain,
    WS(t),
    e.context
  ), typeof n.volume == "number" && (n.volume = Wa(t));
  const i = Sn(n);
  i && (i.volume = Wa(t));
}
function Cc(n, t, e) {
  const i = typeof t == "number" && Number.isFinite(t) ? t : e;
  typeof i != "number" || !Number.isFinite(i) || qS(n, i / 100);
}
function Sn(n) {
  return n?.audio ?? n?.audioElement;
}
function GS() {
  return p.lang === "ru" ? "Запустить звук перевода" : "Start translated audio";
}
function KS() {
  return p.lang === "ru" ? "Браузер заблокировал автозапуск перевода. Нажмите на страницу или на кнопку ещё раз." : "Browser autoplay blocked translated audio. Click the page or the button again.";
}
function Ic(n, t) {
  const e = globalThis;
  if (!t) {
    try {
      e.__VOT_PENDING_AUTOPLAY_RECOVERY__ = null;
    } catch {
    }
    return;
  }
  try {
    e.__VOT_PENDING_AUTOPLAY_RECOVERY__ = {
      ...t,
      siteHost: n.site.host,
      pageUrl: globalThis.location.href
    };
  } catch {
  }
}
function pn(n) {
  try {
    n.pendingAutoplayRecoveryAbortController?.abort();
  } catch {
  }
  n.pendingAutoplayRecoveryAbortController = void 0, n.pendingAutoplayRecovery = null, Ic(n, null);
}
function YS(n) {
  return !!(n.readyState >= HTMLMediaElement.HAVE_METADATA || n.currentTime > 0 || Number.isFinite(n.duration) && n.duration > 0);
}
function Pc(n) {
  return !!(n?.gainNode || n?.audioSource || n?.mediaElementSource);
}
function Un(n, t, e) {
  return !(t.paused || t.readyState < 2 || t.error || (n.audioPlayer?.audioContext?.state ?? n.audioContext?.state) === "suspended" && Pc(e));
}
function jS(n) {
  const t = n.audioPlayer?.player, e = Sn(t), i = String(t?.currentSrc || t?.src || ""), s = n.audioPlayer?.audioContext?.state ?? n.audioContext?.state;
  return !t || !e || !i || !n.video || n.video.paused || e.error ? !1 : s === "suspended" && Pc(t) ? !0 : e.paused && YS(e);
}
async function Mc(n, t) {
  const e = n.pendingAutoplayRecovery;
  if (!e)
    return !1;
  const i = {
    gen: e.gen,
    videoId: e.videoId
  };
  if (n.isActionStale(i))
    return pn(n), !1;
  V.log("[VOT][audio] retrying translated audio after user gesture", {
    trigger: t,
    sourceUrl: e.sourceUrl,
    videoId: e.videoId
  });
  const s = n.audioPlayer?.player, o = String(s?.currentSrc || s?.src || ""), r = hi(
    n,
    e.sourceUrl
  ), a = hi(
    n,
    o
  );
  return r && a !== r && (await fi(
    n,
    e.sourceUrl,
    i
  )).status !== "success" ? !1 : (await go(n), await Se(n, i), await mo(
    n,
    i,
    1800
  ) ? (pn(n), n.transformBtn("success", p.get("disableTranslate")), n.syncPopupOverlayState({
    hint: n.downloadTranslationUrl ? "Translated audio is ready for download." : "Waiting for translated audio."
  }), !0) : (V.log(
    "[VOT][audio] translated audio still did not start after gesture",
    {
      trigger: t,
      sourceUrl: e.sourceUrl
    }
  ), !1));
}
function XS(n, t, e) {
  pn(n);
  const i = {
    gen: e?.gen ?? n.actionsGeneration,
    videoId: e?.videoId ?? n.videoData?.videoId ?? "",
    sourceUrl: t,
    createdAt: Date.now()
  }, s = new AbortController(), o = [
    "pointerdown",
    "touchstart",
    "click",
    "keydown"
  ], r = (a) => {
    V.log(
      "[VOT][audio] user gesture detected while autoplay recovery is pending",
      {
        type: a.type,
        sourceUrl: t,
        videoId: i.videoId
      }
    ), Mc(
      n,
      `gesture:${a.type}`
    );
  };
  n.pendingAutoplayRecovery = i, n.pendingAutoplayRecoveryAbortController = s, Ic(n, i);
  for (const a of o)
    document.addEventListener(a, r, {
      capture: !0,
      passive: a !== "keydown",
      signal: s.signal
    });
}
async function Se(n, t) {
  if (n.isActionStale(t))
    return;
  const e = n.audioPlayer?.player, i = Sn(e), s = n.video, o = !!(e?.currentSrc || e?.src);
  if (!(!e || !s || s.paused || !o)) {
    try {
      e.lipSync?.("play");
    } catch {
    }
    try {
      await e.play?.();
    } catch {
    }
    if (i) {
      try {
        i.currentTime = s.currentTime;
      } catch {
      }
      try {
        i.playbackRate = s.playbackRate;
      } catch {
      }
      try {
        await i.play();
      } catch {
      }
    }
  }
}
function JS(n = !1) {
  const t = !!this.pendingAutoplayRecovery;
  pn(this), n && t && this.hasActiveSource() && this.transformBtn("success", p.get("disableTranslate"));
}
function ZS() {
  return !!this.pendingAutoplayRecovery;
}
async function QS(n = "manual") {
  if (!this.pendingAutoplayRecovery)
    return !1;
  if (this.pendingAutoplayRecoveryPromise)
    return await this.pendingAutoplayRecoveryPromise;
  const t = Mc(this, n).finally(
    () => {
      this.pendingAutoplayRecoveryPromise === t && (this.pendingAutoplayRecoveryPromise = null);
    }
  );
  return this.pendingAutoplayRecoveryPromise = t, await t;
}
function tT() {
  const n = this.audioPlayer?.player, t = this.uiManager.votOverlayView?.translationVolumeSlider?.value;
  Cc(n, t, this.data?.defaultVolume);
}
async function eT(n = "manual") {
  try {
    this.audioPlayer || this.createPlayer();
    const t = await go(this);
    V.log("[VOT][audio] primed playback context from user gesture", {
      trigger: n,
      result: t,
      player: this.audioPlayer?.player?.constructor?.name ?? "unknown"
    });
  } catch {
  }
}
function Oc() {
  return typeof performance < "u" && typeof performance.now == "function" ? performance.now() : Date.now();
}
function fo(n) {
  return n.data?.syncVolume || !n.data?.enabledAutoVolume ? "off" : n.data?.enabledSmartDucking ?? !0 ? "smart" : "classic";
}
async function go(n) {
  const t = n.audioPlayer?.audioContext;
  if (!t || t.state !== "suspended") return "not-needed";
  const e = 1500, i = (async () => {
    try {
      return await t.resume(), "resumed";
    } catch {
      return "failed";
    }
  })();
  let s;
  const o = new Promise((a) => {
    s = setTimeout(() => a("timeout"), e);
  }), r = await Promise.race([i, o]);
  return s !== void 0 && clearTimeout(s), r;
}
async function nn(n, t) {
  if (!t || !n.audioPlayer) return;
  const e = n.audioPlayer.player, i = String(e.currentSrc || e.src || ""), s = n.proxifyAudio(
    n.unproxifyAudio(i)
  ), o = n.proxifyAudio(
    n.unproxifyAudio(t)
  );
  if (s === o)
    try {
      await e.clear(), e.src = "", V.log("[updateTranslation] cleared stale partially-applied source");
    } catch {
    }
}
function nT(n) {
  return n.audioPlayer?.audioContext ?? n.audioContext;
}
function Dc(n) {
  if (n.connectedInputNode && n.analyser)
    try {
      n.connectedInputNode.disconnect(n.analyser);
    } catch {
    }
  if (n.connectedInputNode = void 0, n.createdMediaSource)
    try {
      n.createdMediaSource.disconnect();
    } catch {
    }
  if (n.createdMediaSource = void 0, n.analyser)
    try {
      n.analyser.disconnect();
    } catch {
    }
  n.analyser = void 0, n.analyserFloatData = void 0, n.analyserData = void 0, n.mediaElement = void 0, n.audioContext = void 0, n.mediaSourceCreationFailed = !1;
}
function iT(n) {
  const t = di.get(n);
  t && (Dc(t), di.delete(n));
}
function sT(n, t, e, i) {
  if (is(n?.gainNode)) return n.gainNode;
  if (is(n?.audioSource)) return n.audioSource;
  if (is(n?.mediaElementSource)) return n.mediaElementSource;
  if (!(i.mediaSourceCreationFailed && i.mediaElement === t && i.audioContext === e)) {
    if (i.createdMediaSource && i.mediaElement === t && i.audioContext === e)
      return i.createdMediaSource;
    try {
      const s = e.createMediaElementSource(t);
      return i.createdMediaSource = s, i.mediaSourceCreationFailed = !1, s;
    } catch {
      i.mediaSourceCreationFailed = !0;
      return;
    }
  }
}
function oT(n, t, e) {
  const i = nT(n);
  if (!i) return;
  let s = di.get(n);
  if (s || (s = {}, di.set(n, s)), (s.mediaElement && s.mediaElement !== e || s.audioContext && s.audioContext !== i) && Dc(s), s.mediaElement = e, s.audioContext = i, !s.analyser) {
    const a = i.createAnalyser();
    a.fftSize = 512, s.analyser = a;
  }
  const o = sT(
    t,
    e,
    i,
    s
  ), r = s.analyser;
  if (!(!o || !r)) {
    if (s.connectedInputNode !== o) {
      if (s.connectedInputNode)
        try {
          s.connectedInputNode.disconnect(r);
        } catch {
        }
      try {
        o.connect(r), s.connectedInputNode = o;
      } catch {
        return;
      }
    }
    return { analyser: r, state: s };
  }
}
function rT(n) {
  return {
    isDucked: n.smartVolumeIsDucked,
    speechGateOpen: n.smartVolumeSpeechGateOpen,
    rmsEnvelope: n.smartVolumeRmsEnvelope,
    baseline: n.smartVolumeDuckingBaseline,
    lastApplied: n.smartVolumeLastApplied,
    lastTickAt: n.smartVolumeLastTickAt,
    lastSoundAt: n.smartVolumeLastSoundAt,
    rmsMissingSinceAt: n.smartVolumeRmsMissingSinceAt
  };
}
function bn(n, t) {
  n.smartVolumeIsDucked = t.isDucked, n.smartVolumeSpeechGateOpen = t.speechGateOpen, n.smartVolumeRmsEnvelope = t.rmsEnvelope, n.smartVolumeDuckingBaseline = t.baseline, n.smartVolumeLastApplied = t.lastApplied, n.smartVolumeLastTickAt = t.lastTickAt, n.smartVolumeLastSoundAt = t.lastSoundAt, n.smartVolumeRmsMissingSinceAt = t.rmsMissingSinceAt;
}
function Tn(n, t = {}) {
  const { restoreVolume: e } = t;
  n.smartVolumeDuckingInterval !== void 0 && (clearTimeout(n.smartVolumeDuckingInterval), n.smartVolumeDuckingInterval = void 0);
  const i = typeof e == "number" ? e : n.smartVolumeDuckingBaseline ?? n.volumeOnStart;
  if (typeof i == "number" && (typeof e == "number" || n.smartVolumeIsDucked))
    try {
      n.setVideoVolume(i);
    } catch {
    }
  iT(n), bn(n, FS());
}
function _c(n) {
  typeof globalThis > "u" || n.smartVolumeDuckingInterval !== void 0 && (n.smartVolumeDuckingInterval = globalThis.setTimeout(() => {
    if (n.smartVolumeDuckingInterval !== void 0) {
      try {
        cT(n);
      } catch {
        Tn(n);
        return;
      }
      n.smartVolumeDuckingInterval !== void 0 && _c(n);
    }
  }, HS));
}
function aT(n) {
  if (typeof globalThis > "u" || n.smartVolumeDuckingInterval !== void 0 || fo(n) !== "smart") return;
  const t = n.getVideoVolume(), e = typeof n.smartVolumeDuckingBaseline == "number" ? n.smartVolumeDuckingBaseline : t, i = uo(e);
  if (Number.isFinite(t) && Number.isFinite(e) && t < e - Si.externalBaselineDelta01) {
    const s = Oc();
    i.isDucked = !0, i.speechGateOpen = !0, i.lastApplied = t, i.lastSoundAt = s;
  }
  bn(n, i), n.smartVolumeDuckingInterval = globalThis.setTimeout(() => {
  }, 0), clearTimeout(n.smartVolumeDuckingInterval), _c(n);
}
function lT(n, t) {
  const e = n.audioPlayer?.player, i = oT(n, e, t);
  if (!i) return;
  const { analyser: s, state: o } = i;
  try {
    if (typeof s.getFloatTimeDomainData == "function") {
      let l = o.analyserFloatData;
      l?.length !== s.fftSize && (l = new Float32Array(s.fftSize), o.analyserFloatData = l), s.getFloatTimeDomainData(l);
      let u = 0;
      for (const d of l)
        u += d * d;
      return W(Math.sqrt(u / l.length), 0, 1);
    }
    let r = o.analyserData;
    r?.length !== s.fftSize && (r = new Uint8Array(s.fftSize), o.analyserData = r), s.getByteTimeDomainData(r);
    let a = 0;
    for (const l of r) {
      const u = (l - 128) / 128;
      a += u * u;
    }
    return W(Math.sqrt(a / r.length), 0, 1);
  } catch {
    return;
  }
}
function cT(n) {
  if (fo(n) !== "smart") {
    Fc.call(n);
    return;
  }
  const t = n.audioPlayer?.player, e = Sn(t), i = !!e && !e.paused && !e.muted && // Treat near-zero volume as inactive.
  (e.volume ?? 1) > 1e-3, s = Oc(), o = n.getVideoVolume(), r = n.video, a = !(r && (r.paused || r.ended)), l = W(n.data?.autoVolume ?? pi, 0, 100) / 100;
  n.smartVolumeDuckingTarget = l;
  const u = i && e ? lT(n, e) : 0, d = NS(
    {
      nowMs: s,
      translationActive: n.hasActiveSource(),
      audioIsPlaying: i,
      rms: u,
      currentVideoVolume: o,
      hostVideoActive: a,
      duckingTarget01: l,
      volumeOnStart: n.volumeOnStart
    },
    rT(n),
    Si
  );
  switch (d.kind) {
    case "stop":
      Tn(n, {
        restoreVolume: d.restoreVolume
      });
      return;
    case "apply":
      n.setVideoVolume(d.volume01), bn(n, d.runtime);
      return;
    case "noop":
      bn(n, d.runtime);
      return;
    default:
      throw new TypeError("Unhandled smart ducking decision");
  }
}
function uT(n, t) {
  return t.aborted ? Promise.resolve() : new Promise((e) => {
    const i = setTimeout(() => {
      t.removeEventListener("abort", s), e();
    }, n), s = () => {
      clearTimeout(i), t.removeEventListener("abort", s), e();
    };
    t.addEventListener("abort", s, { once: !0 });
  });
}
async function za(n, t, e) {
  const i = n.actionsAbortController.signal, s = n.isMultiMethodS3(t) ? {
    method: "HEAD",
    signal: i,
    timeout: Ha
  } : {
    // Some S3 providers reject HEAD while supporting range probes.
    headers: {
      range: "bytes=0-0"
    },
    signal: i,
    timeout: Ha
  };
  for (let o = 1; o <= $a; o++) {
    if (n.isActionStale(e)) return !1;
    try {
      const r = await nt(t, s);
      if (n.isActionStale(e)) return !1;
      if (V.log("[validateAudioUrl] probe response", {
        audioUrl: t,
        attempt: o,
        ok: r.ok,
        status: r.status
      }), r.ok) return !0;
    } catch {
      if (n.isActionStale(e) || i.aborted)
        return !1;
    }
    if (o < $a && (n.isActionStale(e) || i.aborted || (await uT($S, i), n.isActionStale(e) || i.aborted)))
      return !1;
  }
  return !1;
}
async function dT(n, t) {
  if (this.isActionStale(t))
    return n;
  const e = String(n || ""), i = this.unproxifyAudio(e), s = this.proxifyAudio(i), o = this.audioPlayer?.player?.currentSrc || this.audioPlayer?.player?.src || "", r = this.proxifyAudio(
    this.unproxifyAudio(o)
  );
  return s === r || this.site.host === "yandexdisk" || this.site.host === "googledrive" || this.isMultiMethodS3(e) || this.isMultiMethodS3(i) || i.includes("vtrans.s3-private.mds.yandex.net") || i.includes("/tts/prod/") || await za(this, n, t) ? n : i !== n && await za(
    this,
    i,
    t
  ) ? i : n;
}
function hT() {
  if (!this.videoData || this.videoData.isStream || !this.hasActiveSource()) return;
  clearTimeout(this.translationRefreshTimeout);
  const n = Math.max(3e4, Ml - 300 * 1e3);
  this.translationRefreshTimeout = setTimeout(() => {
    this.refreshTranslationAudio().catch((t) => {
    });
  }, n);
}
async function Rc(n, t) {
  const e = await Mp({
    requester: n.translationHandler,
    request: {
      videoData: t.videoData,
      requestLang: t.requestLang,
      responseLang: t.responseLang,
      translationHelp: t.translationHelp,
      useAudioDownload: !!n.data?.useAudioDownload,
      signal: n.actionsAbortController.signal
    },
    actionContext: t.actionContext,
    isActionStale: (i) => n.isActionStale(i),
    updateTranslation: (i, s) => n.updateTranslation(i, s),
    scheduleTranslationRefresh: () => n.scheduleTranslationRefresh()
  });
  return e ? (t.onBeforeCache && await t.onBeforeCache(e), Op({
    cacheKey: t.cacheKey,
    setTranslation: (i, s) => n.cacheManager.setTranslation(i, s),
    videoId: t.cacheVideoId,
    requestLang: t.cacheRequestLang,
    responseLang: t.cacheResponseLang,
    fallbackUrl: e.url,
    downloadTranslationUrl: n.downloadTranslationUrl,
    usedLivelyVoice: e.usedLivelyVoice
  }), e) : null;
}
async function fT() {
  if (!this.videoData || this.videoData.isStream || !this.hasActiveSource() || this.isRefreshingTranslation) return;
  const n = this.videoData.videoId;
  if (!n) return;
  this.actionsAbortController?.signal?.aborted && this.resetActionsAbortController("refreshTranslationAudio"), this.isRefreshingTranslation = !0;
  const t = { gen: this.actionsGeneration, videoId: n }, e = to(
    this.videoData.translationHelp
  );
  try {
    if (!await Rc(this, {
      videoData,
      requestLang: resolvedReqLang,
      responseLang: resLang,
      translationHelp: e,
      actionContext: t,
      cacheKey,
      cacheVideoId: VIDEO_ID,
      cacheRequestLang: resolvedReqLang,
      cacheResponseLang: responseLang,
      onBeforeCache: async () => {
        const s = this.videoData ? this.getSubtitlesCacheKey(
          VIDEO_ID,
          this.videoData.detectedLanguage,
          this.videoData.responseLanguage
        ) : null;
        (s ? this.cacheManager.getSubtitles(s) : null)?.some(
          (r) => r.source === "yandex" && r.translatedFromLanguage === videoData.detectedLanguage && r.language === videoData.responseLanguage
        ) || (s && this.cacheManager.deleteSubtitles(s), this.subtitles = [], this.subtitlesCacheKey = null);
      }
    })) return;
  } finally {
    this.isRefreshingTranslation = !1;
  }
}
function gT(n) {
  return mS(n, {
    translateProxyEnabled: this.data?.translateProxyEnabled,
    proxyWorkerHost: this.data?.proxyWorkerHost
  });
}
function mT(n) {
  return pS(n);
}
async function pT(n = "proxySettingsChanged") {
  try {
    this.cacheManager.clear(), this.activeTranslation = null;
  } catch {
  }
  try {
    await this.stopTranslation();
  } catch {
  }
  await this.initVOTClient();
}
function bT(n) {
  return bS(n, {
    proxyWorkerHost: this.data?.proxyWorkerHost
  });
}
function hi(n, t) {
  return n.proxifyAudio(n.unproxifyAudio(t));
}
async function fi(n, t, e) {
  const i = n.audioPlayer.player.src !== t;
  let s = null;
  i && (n.audioPlayer.player.src = t, s = t);
  try {
    if (i)
      try {
        await n.audioPlayer.init();
      } catch (r) {
        if (!Vc(r) || n.isActionStale(e))
          throw r;
        if (V.log(
          "[updateTranslation] transient media abort, retrying init once",
          {
            sourceUrl: t,
            error: r
          }
        ), await new Promise((l) => setTimeout(l, 200)), n.isActionStale(e))
          return await nn(
            n,
            s
          ), {
            status: "stale",
            didSetSource: i,
            appliedSourceUrl: s
          };
        String(
          n.audioPlayer.player.currentSrc || n.audioPlayer.player.src || ""
        ) || (n.audioPlayer.player.src = t), await n.audioPlayer.init();
      }
    if (n.isActionStale(e))
      return await nn(n, s), {
        status: "stale",
        didSetSource: i,
        appliedSourceUrl: s
      };
    const o = await go(n);
    return o === "timeout" ? V.log(
      "[updateTranslation] continuing after AudioContext resume timeout"
    ) : o === "failed" && V.log(
      "[updateTranslation] AudioContext resume failed, continue without deferred resume"
    ), n.isActionStale(e) ? (await nn(n, s), {
      status: "stale",
      didSetSource: i,
      appliedSourceUrl: s
    }) : (!n.video.paused && n.audioPlayer.player.src && await Se(n, e), {
      status: "success",
      didSetSource: i,
      appliedSourceUrl: s
    });
  } catch (o) {
    return {
      status: "error",
      didSetSource: i,
      appliedSourceUrl: s,
      error: o
    };
  }
}
async function mo(n, t, e = ho) {
  const i = n.audioPlayer?.player, s = Sn(i);
  return !i || !String(i.currentSrc || i.src || "") ? !1 : !s || Un(n, s, i) || (await Se(n, t), Un(n, s, i)) ? !0 : await new Promise((r) => {
    let a = !1;
    const l = (m) => {
      a || (a = !0, g(), r(m));
    }, u = () => {
      Se(n, t), l(!0);
    }, d = () => l(!1), h = () => {
      Se(n, t), Un(n, s, i) && l(!0);
    }, f = setTimeout(() => {
      Se(n, t), l(Un(n, s, i));
    }, e), g = () => {
      clearTimeout(f), s.removeEventListener("playing", u), s.removeEventListener("canplay", h), s.removeEventListener("loadeddata", h), s.removeEventListener("loadedmetadata", h), s.removeEventListener("error", d);
    };
    s.addEventListener("playing", u, { once: !0 }), s.addEventListener("canplay", h, { once: !0 }), s.addEventListener("loadeddata", h, { once: !0 }), s.addEventListener("loadedmetadata", h, { once: !0 }), s.addEventListener("error", d, { once: !0 }), n.isActionStale(t) && l(!1);
  });
}
function Bc(n) {
  const t = n.video;
  return !!(t && !t.paused && !t.ended);
}
async function qa(n, t, e) {
  try {
    await n.audioPlayer?.player?.clear();
  } catch {
  }
  try {
    n.audioPlayer?.player && (n.audioPlayer.player.src = "");
  } catch {
  }
  try {
    n.createPlayer();
  } catch {
    return !1;
  }
  return await new Promise((s) => setTimeout(s, 150)), n.isActionStale(e) || (await fi(
    n,
    t,
    e
  )).status !== "success" || Bc(n) && !await mo(
    n,
    e,
    ho
  ) ? !1 : (n.setupAudioSettings(), n.transformBtn("success", p.get("disableTranslate")), n.afterUpdateTranslation(t), this.data?.autoSubtitles && (setTimeout(() => {
    this.enableSubtitlesForCurrentLangPair();
  }, 1500), setTimeout(() => {
    this.enableSubtitlesForCurrentLangPair();
  }, 5e3)), !0);
}
async function yT(n, t) {
  if (await this.waitForPendingStopTranslate(), this.isActionStale(t)) return;
  pn(this), this.audioPlayer || this.createPlayer(), this.audioPlayer.audioContext?.state === "closed" && this.createPlayer();
  const e = hi(this, n), i = this.audioPlayer.player.currentSrc || this.audioPlayer.player.src || "", s = hi(this, i);
  let o = e;
  if (e !== s && (o = await this.validateAudioUrl(
    e,
    t
  )), this.isActionStale(t)) return;
  this.externalTranslationSourceUrl = null;
  let r = await fi(
    this,
    o,
    t
  ), a = r.appliedSourceUrl;
  if (r.status === "error" && r.didSetSource && !this.isActionStale(t)) {
    const l = this.unproxifyAudio(o);
    if (l !== o)
      try {
        V.log(
          "[updateTranslation] proxied audio init failed, retrying direct URL"
        );
        const u = await this.validateAudioUrl(
          l,
          t
        );
        if (this.isActionStale(t)) {
          await nn(
            this,
            a
          );
          return;
        }
        o = u, r = await fi(
          this,
          u,
          t
        ), a = r.appliedSourceUrl;
      } catch (u) {
        r = {
          status: "error",
          didSetSource: !0,
          appliedSourceUrl: a,
          error: u
        };
      }
  }
  if (r.status !== "stale") {
    if (r.status === "error") {
      if (V.log("this.audioPlayer.init() error", r.error), Vc(r.error) && (V.log(
        "[updateTranslation] media abort detected, recreating player and retrying once",
        r.error
      ), await qa(
        this,
        o,
        t
      )))
        return;
      await nn(this, a);
      try {
        await this.audioPlayer?.player?.clear();
      } catch {
      }
      try {
        this.audioPlayer?.player && (this.audioPlayer.player.src = "");
      } catch {
      }
      this.downloadTranslationUrl = null;
      const l = Ol(r.error);
      throw this.transformBtn("error", l), r.error instanceof Error ? r.error : new Error(l);
    }
    if (Bc(this) && !await mo(
      this,
      t,
      ho
    )) {
      if (jt(this.site.host, this.videoData?.host)) {
        this.setupAudioSettings(), this.transformBtn(
          "success",
          p.get("disableTranslate")
        ), this.afterUpdateTranslation(o), this.data?.autoSubtitles && (setTimeout(() => {
          this.enableSubtitlesForCurrentLangPair();
        }, 1500), setTimeout(() => {
          this.enableSubtitlesForCurrentLangPair();
        }, 5e3));
        return;
      }
      if (jS(this)) {
        V.log(
          "[VOT][audio] translated audio is waiting for a user gesture",
          {
            sourceUrl: o,
            videoId: t?.videoId ?? this.videoData?.videoId
          }
        ), XS(this, o, t), this.setupAudioSettings(), this.transformBtn("success", GS()), this.afterUpdateTranslation(o), this.data?.autoSubtitles && (setTimeout(() => {
          this.enableSubtitlesForCurrentLangPair();
        }, 1500), setTimeout(() => {
          this.enableSubtitlesForCurrentLangPair();
        }, 5e3)), this.syncPopupOverlayState({
          hint: KS()
        });
        return;
      }
      if (await qa(
        this,
        o,
        t
      ))
        return;
      try {
        await this.audioPlayer?.player?.clear();
      } catch {
      }
      try {
        this.audioPlayer?.player && (this.audioPlayer.player.src = "");
      } catch {
      }
      throw this.downloadTranslationUrl = null, this.transformBtn("error", "Translated audio did not start"), new Error("Translated audio did not start");
    }
    this.setupAudioSettings(), this.transformBtn("success", p.get("disableTranslate")), this.afterUpdateTranslation(o);
  }
}
async function vT(n, t, e, i, s) {
  await this.waitForPendingStopTranslate(), await this.videoValidator(), this.actionsAbortController?.signal?.aborted && this.resetActionsAbortController("translateFunc");
  const o = this.uiManager.votOverlayView;
  if (!o?.votButton)
    return;
  if (o.votButton.loading = !0, this.hadAsyncWait = !1, this.volumeOnStart = this.getVideoVolume(), !n) {
    await this.updateTranslationErrorMsg(
      new ft("VOTNoVideoIDFound"),
      this.actionsAbortController.signal
    );
    return;
  }
  const r = this.videoData;
  if (!r) {
    await this.updateTranslationErrorMsg(
      new ft("VOTNoVideoIDFound"),
      this.actionsAbortController.signal
    );
    return;
  }
  const a = n;
  if (this.lastTranslationVideoId !== a) {
    V.log("[translateFunc] video changed, recreating player", {
      prev: this.lastTranslationVideoId,
      next: a
    }), this.resetActionsAbortController("translateFunc video changed");
    try {
      await this.audioPlayer?.player?.clear();
    } catch {
    }
    try {
      this.audioPlayer?.player && (this.audioPlayer.player.src = "");
    } catch {
    }
    try {
      this.translationRefreshTimeout !== void 0 && (clearTimeout(this.translationRefreshTimeout), this.translationRefreshTimeout = void 0);
    } catch {
    }
    this.downloadTranslationUrl = null, this.activeTranslation = null, this.hadAsyncWait = !1, Tn(this, {
      restoreVolume: this.smartVolumeDuckingBaseline ?? this.volumeOnStart
    }), this.smartVolumeDuckingBaseline = void 0;
    try {
      this.createPlayer();
    } catch {
    }
    this.lastTranslationVideoId = a;
  }
  const l = to(s);
  await this.videoManager.ensureDetectedLanguageForTranslation(r);
  const u = e === "auto" && r.detectedLanguage !== "auto" ? r.detectedLanguage : e, d = this.getTranslationCacheKey(
    n,
    u,
    i,
    l
  ), h = `video_${d}`;
  if (this.activeTranslation?.key === h) {
    await this.activeTranslation.promise;
    return;
  }
  const f = {
    gen: this.actionsGeneration,
    videoId: n
  }, g = (async () => {
    if (this.isActionStale(f))
      return;
    const m = u, v = i, T = async (x) => await $l({
      url: x,
      actionContext: f,
      isActionStale: (I) => this.isActionStale(I),
      updateTranslation: (I, k) => this.updateTranslation(I, k),
      scheduleTranslationRefresh: () => this.scheduleTranslationRefresh()
    }), S = this.cacheManager.getTranslation(d);
    if (S?.url) {
      try {
        if (await T(S.url) && this.hasActiveSource()) {
          V.log("[translateFunc] Cached translation was received");
          return;
        }
        V.log(
          "[translateFunc] Cached translation did not activate source, dropping cache and requesting fresh URL"
        );
      } catch {
      }
      typeof this.cacheManager.deleteTranslation == "function" ? this.cacheManager.deleteTranslation(d) : this.cacheManager.clear();
    }
    await Rc(this, {
      videoData: r,
      requestLang: m,
      responseLang: v,
      translationHelp: l,
      actionContext: f,
      cacheKey: d,
      cacheVideoId: n,
      cacheRequestLang: u,
      cacheResponseLang: i,
      onBeforeCache: async () => {
        const x = this.videoData ? this.getSubtitlesCacheKey(
          n,
          this.videoData.detectedLanguage,
          this.videoData.responseLanguage
        ) : null;
        (x ? this.cacheManager.getSubtitles(x) : null)?.some(
          (k) => k.source === "yandex" && k.translatedFromLanguage === r.detectedLanguage && k.language === r.responseLanguage
        ) || (x && this.cacheManager.deleteSubtitles(x), this.subtitles = [], this.subtitlesCacheKey = null);
      }
    });
  })();
  this.activeTranslation = {
    key: h,
    promise: g
  };
  try {
    return await g;
  } catch (m) {
    throw this.hadAsyncWait = ps({
      aborted: this.actionsAbortController.signal.aborted,
      translateApiErrorsEnabled: !!this.data?.translateAPIErrors,
      hadAsyncWait: this.hadAsyncWait,
      videoId: n,
      error: m,
      notify: (v) => this.notifier.translationFailed(v)
    }), m;
  } finally {
    this.activeTranslation?.promise === g && (this.activeTranslation = null);
    const m = this.uiManager.votOverlayView?.votButton;
    !this.activeTranslation && m?.loading && !this.hasActiveSource() && this.transformBtn("none", p.get("translateVideo"));
  }
}
function wT() {
  return rb(this.site.host);
}
function Fc() {
  Cc(
    this.audioPlayer?.player,
    this.uiManager.votOverlayView?.translationVolumeSlider?.value,
    this.data?.defaultVolume
  );
  const n = fo(this);
  if (n === "off") {
    Tn(this, {
      restoreVolume: this.smartVolumeDuckingBaseline ?? this.volumeOnStart
    });
    return;
  }
  const t = W(this.data.autoVolume ?? pi, 0, 100) / 100;
  if (this.smartVolumeDuckingTarget = t, !this.hasActiveSource())
    return;
  if (n === "smart") {
    aT(this);
    return;
  }
  this.smartVolumeDuckingInterval !== void 0 && (clearTimeout(this.smartVolumeDuckingInterval), this.smartVolumeDuckingInterval = void 0), typeof this.smartVolumeDuckingBaseline != "number" && (this.smartVolumeDuckingBaseline = this.getVideoVolume());
  const e = this.smartVolumeDuckingBaseline ?? this.getVideoVolume();
  this.setVideoVolume(Math.min(e, t)), bn(
    this,
    uo(this.smartVolumeDuckingBaseline)
  ), this.smartVolumeIsDucked = !0;
}
function ST(n) {
  if (!this.data?.enabledAutoVolume || !this.hasActiveSource()) return;
  const t = Math.max(0, Math.min(1, n));
  this.smartVolumeDuckingBaseline = t, this.smartVolumeLastApplied = t;
}
const TT = new Set(mi), kT = (n) => TT.has(n), LT = Promise.resolve();
/(?:^|\.)vkvideo\.ru$|(?:^|\.)vk\.(?:com|ru)$/i.test(location.hostname) && (iu(), Ul());
class xT {
  /**
   * Constructs a new VideoHandler instance.
   * @param {HTMLVideoElement} video The video element to handle.
   * @param {HTMLElement} container The container element for the video.
   * @param {Object} site The site object associated with the video.
   */
  constructor(t, e, i) {
    c(this, "video");
    c(this, "container");
    c(this, "site");
    // Public API / core state
    c(this, "translateFromLang", "auto");
    c(this, "translateToLang", Wn);
    c(this, "data");
    c(this, "videoData");
    c(this, "firstPlay", !0);
    c(this, "audioContext");
    c(this, "votClient");
    c(this, "audioPlayer");
    c(this, "abortController");
    c(this, "actionsAbortController");
    /** Increments whenever we reset/abort translation actions to invalidate stale async work */
    c(this, "actionsGeneration", 0);
    c(this, "notifier", new qv());
    c(this, "cacheManager");
    c(this, "votSessionStorage", new Th());
    /**
     * In-flight subtitles list requests, keyed by subtitles cache key.
     *
     * Prevents duplicate parallel requests when the subtitles hotkey is spammed
     * before the first request resolves.
     */
    c(this, "subtitlesLoadPromises", /* @__PURE__ */ new Map());
    c(this, "downloadTranslationUrl", null);
    c(this, "translationRefreshTimeout");
    c(this, "isRefreshingTranslation", !1);
    c(this, "autoRetry");
    // streamPing?: ReturnType<typeof setInterval>;
    c(this, "votOpts");
    c(this, "volumeOnStart");
    /**
     * syncVolume (link translation and video volume) runtime state.
     * We keep last-known slider values to apply deltas reliably.
     */
    c(this, "volumeLinkState", {
      initialized: !1,
      lastVideoPercent: 0,
      lastTranslationPercent: 0
    });
    /**
     * Used to ignore our own programmatic video-volume updates when observing
     * external UIs (e.g. YouTube volume panel aria mutations).
     */
    c(this, "internalVideoVolumeSetAt", 0);
    c(this, "internalVideoVolumeSetPercent", null);
    c(this, "internalVideoVolumeSuppressionMs", 250);
    c(this, "internalVideoVolumeSetHistory", []);
    c(this, "internalVideoVolumeSetHistoryLimit", 48);
    // Smart auto-volume ducking state. Used to lower the original video volume
    // only while the translated track has audible sound (not during silence).
    c(this, "smartVolumeDuckingInterval");
    c(this, "smartVolumeDuckingTarget", 0.2);
    c(this, "smartVolumeDuckingBaseline");
    c(this, "smartVolumeLastApplied");
    // Internal smoothing state for Smart Auto-Volume ducking.
    c(this, "smartVolumeLastTickAt", 0);
    c(this, "smartVolumeLastSoundAt", 0);
    c(this, "smartVolumeRmsMissingSinceAt", null);
    /** Smoothed translated-track RMS envelope (0..1). */
    c(this, "smartVolumeRmsEnvelope", 0);
    /**
     * Internal speech gate state for Smart Auto-Volume ducking.
     *
     * This is a debounced/hysteresis-based boolean that tracks whether the
     * translated track is considered "audible" for the purpose of ducking.
     */
    c(this, "smartVolumeSpeechGateOpen", !1);
    c(this, "smartVolumeIsDucked", !1);
    c(this, "longWaitingResCount", 0);
    c(this, "hadAsyncWait", !1);
    // Available subtitle tracks for the current video. The subtitles UI widget
    // maintains its own internal line/token representation.
    c(this, "subtitles", []);
    c(this, "subtitlesCacheKey", null);
    c(this, "subtitlesWidget");
    c(this, "activeTranslation", null);
    c(this, "lastTranslationVideoId", null);
    c(this, "externalTranslationSourceUrl", null);
    c(this, "pendingAutoplayRecovery", null);
    c(this, "pendingAutoplayRecoveryAbortController");
    c(this, "pendingAutoplayRecoveryPromise", null);
    /**
     * In-flight async teardown for translation/audio player cleanup.
     * New translation starts should wait for this to avoid clear/init races.
     */
    c(this, "stopTranslatePromise", null);
    // Managers
    c(this, "interactionChecker");
    c(this, "uiManager");
    c(this, "overlayVisibility");
    c(this, "popupOverlayBridge");
    c(this, "popupOwnerId", Math.random().toString(36).slice(2));
    c(this, "overlayVisibilityTargetsAbortController");
    c(this, "translationOrchestrator");
    c(this, "lifecycleController");
    c(this, "translationHandler");
    c(this, "videoManager");
    // Subtitles received directly from API (Yandex) when available
    c(this, "yandexSubtitles", null);
    // Observers / listeners
    c(this, "resizeObserver");
    c(this, "syncVolumeObserver");
    // Init guard
    c(this, "initialized", !1);
    c(this, "onPrimaryAttachReady");
    /**
     * Cached overlay mount points (root/portal). Recomputed when container changes.
     * Avoids doing the same DOM/style walks multiple times per lifecycle update.
     */
    c(this, "mountCache");
    /**
     * In-memory cache for translated error strings (RU -> UI language).
     * This avoids repeated translation API calls during retry loops when the
     * same backend message is emitted multiple times.
     */
    c(this, "errorTranslationCache", /* @__PURE__ */ new Map());
    /**
     * Re-attach overlayVisibility listeners to the *current* overlay button/menu elements.
     *
     * The overlay UI gets recreated in some flows (e.g. menu language change),
     * so listeners that were attached to the old DOM nodes must be re-bound.
     */
    c(this, "rebindOverlayVisibilityTargets", cw);
    /**
     * Changes subtitles language based on user selection.
     * @param {string} subs The subtitles selection value.
     */
    c(this, "changeSubtitlesLang", OS);
    /**
     * Updates the subtitles selection options.
     */
    c(this, "updateSubtitlesLangSelect", DS);
    /**
     * Ensures the in-memory subtitles list matches the current language-pair cache key.
     */
    c(this, "ensureSubtitlesForCurrentLangPair", Ec);
    /**
     * Loads subtitles for the current video.
     */
    c(this, "loadSubtitles", BS);
    c(this, "refreshTranslationAudio", fT);
    /**
     * Called when proxy-related settings are changed at runtime.
     *
     * - Clears in-memory caches so old failures/URLs don't persist.
     * - Cancels any in-flight translation work.
     * - Best-effort refreshes the active audio source so the new proxy host/mode
     *   takes effect immediately.
     */
    c(this, "handleProxySettingsChanged", pT);
    /**
     * Updates the translation audio source.
     * @param {string} audioUrl The audio URL.
     */
    c(this, "updateTranslation", yT);
    /**
     * Stops translation and synchronizes volume.
     */
    c(this, "stopTranslation", async () => {
      this.translationOrchestrator?.reset(), this.overlayVisibility?.cancel(), await this.stopTranslate(), this.syncVideoVolumeSlider();
    });
    /**
     * Releases extra event listeners.
     */
    c(this, "releaseExtraEvents", hw);
    this.video = t, this.container = e, this.site = i, this.abortController = new AbortController(), this.actionsAbortController = new AbortController(), this.cacheManager = new kh(), this.interactionChecker = oo(), this.interactionChecker.start();
    const s = () => this, o = this.getOverlayMount(e);
    this.uiManager = new Dv({
      mount: o,
      data: this.data,
      videoHandler: this,
      intervalIdleChecker: this.interactionChecker
    }), this.overlayVisibility = new _v({
      checker: this.interactionChecker,
      getOverlayView: () => this.uiManager.votOverlayView ?? null,
      getAutoHideDelay: () => this.getAutoHideDelay(),
      isInteractiveNode: (a) => this.isOverlayInteractiveNode(a)
    }), this.translationOrchestrator = new _p({
      isFirstPlay: () => this.firstPlay,
      setFirstPlay: (a) => {
        this.firstPlay = a;
      },
      isAutoTranslateEnabled: () => !!this.data?.autoTranslate,
      getVideoId: () => this.videoData?.videoId,
      scheduleAutoTranslate: () => this.runAutoTranslate(),
      isMobileYouTubeMuted: () => this.site.host === "youtube" && this.site.additionalData === "mobile" && this.video.muted,
      setMuteWatcher: (a) => {
        let l = !1;
        const u = () => {
          l || (l = !0, this.video.removeEventListener("volumechange", d), a());
        }, d = () => {
          this.video.muted || u();
        };
        this.video.addEventListener("volumechange", d, {
          signal: this.abortController.signal
        }), queueMicrotask(() => {
          this.video.muted || u();
        });
      }
    });
    const r = {
      get video() {
        return s().video;
      },
      get site() {
        return s().site;
      },
      get container() {
        return s().container;
      },
      set container(a) {
        s().container !== a && (s().container = a, s().uiManager.updateMount(s().getOverlayMount(a)));
      },
      get firstPlay() {
        return s().firstPlay;
      },
      set firstPlay(a) {
        s().firstPlay = a;
      },
      stopTranslation: () => this.stopTranslation(),
      get uiManager() {
        return s().uiManager;
      },
      getVideoData: () => this.getVideoData(),
      cacheManager: {
        getSubtitles: (a) => s().cacheManager.getSubtitles(a)
      },
      getSubtitlesCacheKey: (a, l, u) => this.getSubtitlesCacheKey(a, l, u),
      updateSubtitlesLangSelect: () => this.updateSubtitlesLangSelect(),
      enableSubtitlesForCurrentLangPair: () => this.enableSubtitlesForCurrentLangPair(),
      setSelectMenuValues: (a, l) => this.setSelectMenuValues(a, l),
      get translateToLang() {
        return s().translateToLang;
      },
      set translateToLang(a) {
        kT(a) && (s().translateToLang = a);
      },
      get data() {
        return s().data ?? {};
      },
      get subtitles() {
        return s().subtitles;
      },
      set subtitles(a) {
        s().subtitles = a;
      },
      get subtitlesCacheKey() {
        return s().subtitlesCacheKey;
      },
      set subtitlesCacheKey(a) {
        s().subtitlesCacheKey = a;
      },
      get videoData() {
        return s().videoData;
      },
      set videoData(a) {
        s().videoData = a;
      },
      get actionsAbortController() {
        return s().actionsAbortController;
      },
      set actionsAbortController(a) {
        s().actionsAbortController = a;
      },
      resetActionsAbortController: (a) => this.resetActionsAbortController(a),
      initVOTClient: () => this.initVOTClient(),
      translationOrchestrator: this.translationOrchestrator,
      resetSubtitlesWidget: () => this.resetSubtitlesWidget(),
      queueOverlayAutoHide: () => this.overlayVisibility?.queueAutoHide(),
      onPrimaryAttachReady: () => this.onPrimaryAttachReady?.()
    };
    this.lifecycleController = new Fp(r), this.translationHandler = new Dp(this), this.videoManager = new Tb(this);
  }
  /**
   * Returns fullscreen root for overlay if the active fullscreen session belongs
   * to the current video/container. Otherwise returns null.
   */
  getFullscreenOverlayRoot() {
    const t = document, e = t.fullscreenElement ?? t.webkitFullscreenElement;
    return Zs(e, [this.container]);
  }
  getOverlayMountPoints(t = this.container) {
    const e = this.getFullscreenOverlayRoot(), { base: i, root: s, portalContainer: o, subtitlesMountContainer: r } = Fm({
      container: t,
      site: this.site,
      fullscreenRoot: e
    }), a = this.mountCache;
    return a?.container === t && a.base === i && a.subtitlesMountContainer === r && a.fullscreenRoot === e && (a.root.isConnected ?? document.documentElement.contains(a.root)) ? {
      root: a.root,
      portalContainer: a.portalContainer,
      subtitlesMountContainer: a.subtitlesMountContainer,
      fullscreenRoot: a.fullscreenRoot
    } : (this.mountCache = {
      container: t,
      base: i,
      root: s,
      portalContainer: o,
      subtitlesMountContainer: r,
      fullscreenRoot: e
    }, { root: s, portalContainer: o, subtitlesMountContainer: r, fullscreenRoot: e });
  }
  getOverlayMount(t = this.container) {
    const { root: e, portalContainer: i, subtitlesMountContainer: s, fullscreenRoot: o } = this.getOverlayMountPoints(t);
    return {
      root: e,
      portalContainer: i,
      subtitlesMountContainer: s,
      tooltipLayoutRoot: o ?? this.tooltipLayoutRoot
    };
  }
  /**
   * Builds a stable cache key for translations.
   *
   * NOTE: Keep this in sync with CacheManager expectations.
   * @param {string} videoId
   * @param {string} from
   * @param {string} to
   */
  getTranslationCacheKey(t, e, i, s) {
    const o = this.getRequestLangForTranslation(
      e,
      i
    ), r = this.isLivelyVoiceAllowed(o, i) && this.data?.useLivelyVoice, a = s == null ? "" : ch(s), l = a ? ds(a) : "0";
    return `${t}_${o}_${i}_${r}_${l}`;
  }
  /**
   * Builds a stable cache key for subtitles.
   *
   * Bugfix: subtitles cache key must match the key used by loadSubtitles().
   * @param {string} videoId
   * @param {string} detectedLanguage
   * @param {string} responseLanguage
   */
  getSubtitlesCacheKey(t, e, i) {
    return `${t}_${e}_${i}_${!!this.data?.useLivelyVoice}`;
  }
  getPreferredSubtitlesLanguage(t = this.videoData?.detectedLanguage ?? "auto", e = this.videoData?.responseLanguage ?? this.translateToLang) {
    const i = (s) => {
      const o = String(s || "").trim().toLowerCase();
      if (!(!o || o === "auto"))
        return o;
    };
    return i(e) ?? i(t);
  }
  isActionStale(t) {
    return t ? this.actionsGeneration !== t.gen || this.videoData?.videoId !== t.videoId : !1;
  }
  updateVOTClientRequestSignal() {
    this.votClient && (this.votClient.fetchOpts = {
      ...this.votClient.fetchOpts ?? {},
      signal: this.actionsAbortController.signal
    });
  }
  resetActionsAbortController(t) {
    try {
      this.actionsAbortController?.abort(t);
    } catch {
    }
    this.actionsAbortController = new AbortController(), this.actionsGeneration++, this.updateVOTClientRequestSignal();
  }
  /**
   * Lazily creates the subtitles widget.
   * @returns {SubtitlesWidget}
   */
  getSubtitlesWidget() {
    if (!this.subtitlesWidget) {
      const { subtitlesMountContainer: t } = this.getOverlayMountPoints(), e = this.site.host === "googledrive" ? t : this.uiManager.votOverlayView?.root ?? t;
      this.subtitlesWidget = new vy(
        this.video,
        e,
        this.interactionChecker,
        this.tooltipLayoutRoot
      ), this.data && (this.subtitlesWidget.setSmartLayout(
        typeof this.data.subtitlesSmartLayout == "boolean" ? this.data.subtitlesSmartLayout : !0
      ), typeof this.data.subtitlesMaxLength == "number" && this.subtitlesWidget.setMaxLength(this.data.subtitlesMaxLength), typeof this.data.highlightWords == "boolean" && this.subtitlesWidget.setHighlightWords(this.data.highlightWords), typeof this.data.subtitlesFontSize == "number" && this.subtitlesWidget.setFontSize(this.data.subtitlesFontSize), typeof this.data.subtitlesFontFamily == "string" && this.subtitlesWidget.setFontFamily(
        this.data.subtitlesFontFamily
      ), typeof this.data.subtitlesOpacity == "number" && this.subtitlesWidget.setOpacity(this.data.subtitlesOpacity));
    }
    return this.subtitlesWidget;
  }
  /**
   * Determines whether subtitles widget is initialized\.
   * @returns {boolean}
   */
  hasSubtitlesWidget() {
    return !!this.subtitlesWidget;
  }
  resetSubtitlesWidget() {
    this.hasSubtitlesWidget() && (this.subtitlesWidget?.release(), this.subtitlesWidget = void 0);
  }
  /**
   * Root element for overlay UI (buttons/menu) so it remains clickable on players
   * that disable pointer events on inner layers.
   */
  get uiRoot() {
    return this.getOverlayMountPoints().root;
  }
  /**
   * Determines the DOM container used for overlay portals.
   * @returns {HTMLElement}
   */
  get portalContainer() {
    return this.getOverlayMountPoints().portalContainer;
  }
  /**
   * Determines the root element used for tooltip layout calculations.
   * @returns {HTMLElement | undefined}
   */
  get tooltipLayoutRoot() {
    switch (this.site.host) {
      case "kickstarter":
        return document.getElementById("react-project-header") ?? void 0;
      case "custom":
        return;
      default:
        return this.container;
    }
  }
  /**
   * Returns the container element for event listeners.
   * @returns {HTMLElement} The event container.
   */
  getEventContainer() {
    return this.site.eventSelector ? ti(
      this.video,
      this.site.eventSelector
    ) ?? this.container : this.container;
  }
  /**
   * Run auto translate using orchestrator dependencies.
   */
  async runAutoTranslate() {
    await this.videoManager.videoValidator(), await this.uiManager.handleTranslationBtnClick();
  }
  /**
   * Lazily initializes and returns the AudioContext.
   * @returns {AudioContext | undefined}
   */
  getAudioContext() {
    if (this.audioContext) return this.audioContext;
    if (this.isAudioContextSupported)
      try {
        return this.audioContext = zs(), this.audioContext;
      } catch (t) {
        console.warn("[VOT] Failed to init AudioContext, falling back:", t);
        return;
      }
  }
  get isAudioContextSupported() {
    return globalThis.AudioContext !== void 0 || globalThis.webkitAudioContext !== void 0;
  }
  /**
   * Determines if audio should be preferred.
   * @returns {boolean} True if audio is preferred.
   */
  getPreferAudio() {
    const t = this.site.host, e = this.videoData?.host, i = this.videoData?.isStream ?? !1;
    if (jt(t, e) || i)
      return !0;
    const s = !!this.getAudioContext(), o = this.data;
    return Nm({
      siteHost: t,
      videoHost: e,
      isStream: i,
      hasAudioContext: s,
      newAudioPlayer: o?.newAudioPlayer,
      onlyBypassMediaCSP: o?.onlyBypassMediaCSP,
      needBypassCSP: this.site.needBypassCSP
    });
  }
  /**
   * Creates the audio player.
   * @returns {VideoHandler} The VideoHandler instance.
   */
  createPlayer() {
    const t = this.getPreferAudio();
    if (this.audioPlayer = new Om({
      video: this.video,
      // DEBUG_MODE is injected at build-time.
      debug: !1,
      fetchFn: nt,
      fetchOpts: {
        timeout: 0
      },
      preferAudio: t
    }), t) {
      const e = this.audioPlayer.audioContext;
      if (this.audioPlayer.audioContext = void 0, e && e.state !== "closed" && e.close().catch(() => {
      }), this.audioContext && this.audioContext.state !== "closed") {
        const i = this.audioContext;
        this.audioContext = void 0, i.close().catch(() => {
        });
      }
    }
    return this;
  }
  /**
   * Returns true if a detected external volume update is very likely caused by
   * our own recent programmatic setVideoVolume call.
   */
  isLikelyInternalVideoVolumeChange(t) {
    const e = Date.now(), i = this.internalVideoVolumeSetHistory;
    if (i.length > 0) {
      let o = 0, r = !1;
      for (const a of i)
        e - a.at > a.suppressMs || (i[o++] = a, !r && Math.abs(t - a.percent) <= 1 && (r = !0));
      return i.length = o, r;
    }
    return this.internalVideoVolumeSetPercent === null || e - this.internalVideoVolumeSetAt > this.internalVideoVolumeSuppressionMs ? !1 : Math.abs(t - this.internalVideoVolumeSetPercent) <= 1;
  }
  callModule(t, ...e) {
    return t.call(this, ...e);
  }
  callModuleAsync(t, ...e) {
    return t.call(this, ...e);
  }
  /**
   * Initializes the VideoHandler: loads settings, UI, video data, events, etc.
   * @returns {Promise<void>}
   */
  init() {
    return mw.call(this);
  }
  /**
   * Initializes the VOT client.
   * @returns {VideoHandler} This instance.
   */
  async initVOTClient() {
    const t = this.data?.translateProxyEnabled ? this.data?.proxyWorkerHost ?? rn : zd;
    this.votOpts = {
      fetchFn: nt,
      fetchOpts: {
        signal: this.actionsAbortController.signal,
        forceGmXhr: !0
      },
      apiToken: this.data?.account?.token,
      hostVOT: Gd,
      host: t
    }, this.votClient = new (this.data?.translateProxyEnabled ? ku : Tu)(this.votOpts), this.votClient.sessions = await this.votSessionStorage.restore(
      t,
      this.votClient.sessions
    );
    const e = this.votClient.getSession.bind(this.votClient);
    return this.votClient.getSession = async (i) => {
      const s = await e(i);
      return await this.votSessionStorage.persist(
        t,
        this.votClient.sessions
      ), s;
    }, this;
  }
  /**
   * Sets the translation button state and text.
   * @param {string} status The new status.
   * @param {string} text The text to display.
   * @returns {VideoHandler} This instance.
   */
  transformBtn(t, e) {
    return this.uiManager.transformBtn(t, e), this.syncPopupOverlayState({
      status: t,
      label: e,
      hint: this.site.host === "youtube" || globalThis.location.hostname === "youtube.googleapis.com" ? "Google embedded player popup mode." : "Google-hosted player popup mode."
    }), this;
  }
  syncPopupOverlayState(t = {}) {
    if (!gs() || !this.popupOverlayBridge?.isOwner(this.popupOwnerId))
      return;
    if (!this.popupOverlayBridge.isOpen())
      try {
        this.popupOverlayBridge.open();
      } catch (g) {
        console.warn("[VOT] popup open skipped", g);
        return;
      }
    const e = this.uiManager.votOverlayView, i = this.videoData?.detectedLanguage ?? this.translateFromLang ?? "auto", s = this.videoData?.responseLanguage ?? this.translateToLang ?? "ru", o = p.getLangLabel(i) || i, r = p.getLangLabel(s) || s, a = Number(
      e?.videoVolumeSlider?.value ?? Math.round(this.getVideoVolume() * 100)
    ), l = Number(
      e?.translationVolumeSlider?.value ?? this.data?.defaultVolume ?? 100
    ), u = e?.subtitlesSelect ? Array.from(e.subtitlesSelect.selectedValues)[0] : void 0, d = !!(this.yandexSubtitles && u && u !== "disabled"), h = ["auto", ...Pt].map((g) => ({
      value: g,
      label: g === "auto" ? p.get("langs.auto") : p.getLangLabel(g)
    })), f = mi.map((g) => ({
      value: g,
      label: p.getLangLabel(g)
    }));
    this.popupOverlayBridge?.updateState({
      visible: !0,
      status: e?.votButton?.status ?? "none",
      label: e?.votButton?.label?.textContent ?? p.get("translateVideo"),
      canDownload: !!this.downloadTranslationUrl,
      canDownloadSubtitles: !!this.yandexSubtitles,
      hint: "Popup mode for Google-hosted players.",
      fromLangLabel: o,
      toLangLabel: r,
      fromLangValue: i,
      toLangValue: s,
      fromLangOptions: h,
      toLangOptions: f,
      subtitlesEnabled: d,
      videoVolume: a,
      translationVolume: l,
      canAdjustTranslationVolume: !!this.hasActiveSource(),
      autoTranslateEnabled: !!this.data?.autoTranslate,
      autoSubtitlesEnabled: !!this.data?.autoSubtitles,
      syncVolumeEnabled: !!this.data?.syncVolume,
      showVideoSliderEnabled: this.data?.showVideoSlider !== !1,
      audioBoosterEnabled: !!this.data?.audioBooster,
      autoVolumeEnabled: this.data?.enabledAutoVolume !== !1,
      smartDuckingEnabled: this.data?.enabledSmartDucking !== !1,
      ...t
    });
  }
  /**
   * @returns {boolean} True if the extension audio player has active audio source
   */
  hasActiveSource() {
    return !!(this.audioPlayer?.player?.src || this.externalTranslationSourceUrl);
  }
  isAwaitingAutoplayRecovery() {
    return this.callModule(ZS);
  }
  clearPendingAutoplayRecovery(t = !1) {
    this.callModule(JS, t);
  }
  resumePendingAutoplayRecovery(t = "manual") {
    return this.callModuleAsync(QS, t);
  }
  primePlaybackByGesture(t = "manual") {
    return this.callModuleAsync(eT, t);
  }
  /**
   * Initializes extra event listeners (resize, click outside, keydown, etc.).
   */
  initExtraEvents() {
    return this.callModule(lw);
  }
  /**
   * Recomputes overlay mount points and rebinds interaction targets.
   *
   * Used when fullscreen state changes without changing `this.container`
   * (common for players inside Shadow DOM).
   */
  refreshOverlayMount() {
    this.mountCache = void 0;
    const t = this.getOverlayMount(this.container), e = !cc(this.uiManager.mount, t);
    this.uiManager.updateMount(t), e && this.rebindOverlayVisibilityTargets();
  }
  /**
   * Called when the video can play.
   */
  setCanPlay() {
    return this.lifecycleController.setCanPlay();
  }
  isOverlayInteractiveNode(t) {
    return this.callModule(uw, t);
  }
  /**
   * Schedules hiding the overlay button with guard checks for internal navigation.
   */
  getAutoHideDelay() {
    return this.callModule(dw);
  }
  /**
   * Enables subtitles that match the currently selected language pair (from -> to).
   *
   * Used by the subtitles hotkey: prefers Yandex captions for the exact pair,
   * then falls back to any captions in the target language.
   */
  enableSubtitlesForCurrentLangPair() {
    return this.callModuleAsync(_S);
  }
  /**
   * Toggles subtitles for the current video.
   *
   * - If subtitles are enabled, this disables them.
   * - If subtitles are disabled, this enables the best subtitles track for the
   *   current language pair.
   */
  toggleSubtitlesForCurrentLangPair() {
    return this.callModuleAsync(RS);
  }
  getRequestLangForTranslation(t, e) {
    return this.data?.useLivelyVoice && this.data?.account?.token && e === "ru" ? "en" : t;
  }
  isLivelyVoiceAllowed(t = this.videoData?.detectedLanguage ?? "auto", e = this.videoData?.responseLanguage ?? this.translateToLang) {
    return !(this.getRequestLangForTranslation(
      t,
      e
    ) !== "en" || e !== "ru" || !this.data?.account?.token);
  }
  /**
   * Gets the video volume.
   * @returns {number} The video volume (0.0 - 1.0).
   */
  getVideoVolume() {
    return this.videoManager.getVideoVolume();
  }
  /**
   * Sets the video volume.
   * @param {number} volume A number between 0 and 1.
   * @returns {VideoHandler} This instance.
   */
  setVideoVolume(t, e = {}) {
    const i = ne(t), s = typeof e.suppressSyncMs == "number" && Number.isFinite(e.suppressSyncMs) ? Math.max(0, e.suppressSyncMs) : this.internalVideoVolumeSuppressionMs, o = Date.now(), r = Yl(i);
    return this.internalVideoVolumeSetAt = o, this.internalVideoVolumeSetPercent = r, this.internalVideoVolumeSetHistory.push({
      at: o,
      percent: r,
      suppressMs: s
    }), this.internalVideoVolumeSetHistory.length > this.internalVideoVolumeSetHistoryLimit && this.internalVideoVolumeSetHistory.splice(
      0,
      this.internalVideoVolumeSetHistory.length - this.internalVideoVolumeSetHistoryLimit
    ), this.videoManager.setVideoVolume(i), this;
  }
  /**
   * Keeps internal syncVolume state aligned with observed/programmatic video-volume changes.
   */
  onVideoVolumeSliderSynced(t) {
    const e = At(t);
    if (!this.volumeLinkState.initialized) {
      Qi(this.volumeLinkState, e);
      return;
    }
    this.data?.syncVolume && this.hasActiveSource() && !this.isLikelyInternalVideoVolumeChange(e) || Qi(this.volumeLinkState, e);
  }
  /**
   * Keeps internal translation-volume snapshot aligned when syncVolume is
   * temporarily disabled, so re-enabling link mode does not apply stale deltas.
   */
  onTranslationVolumeSliderSynced(t) {
    if (!this.volumeLinkState.initialized) {
      ts(this.volumeLinkState, t);
      return;
    }
    ts(this.volumeLinkState, t);
  }
  /**
   * Re-seeds syncVolume baseline from current UI slider values.
   * Useful when toggling syncVolume on/off to avoid stale delta state.
   */
  resetVolumeLinkState(t, e) {
    Qi(this.volumeLinkState, t), ts(this.volumeLinkState, e), this.volumeLinkState.initialized = !0;
  }
  /**
   * Checks if the video is muted.
   * @returns {boolean} True if muted.
   */
  isMuted() {
    return this.videoManager.isMuted();
  }
  /**
   * Syncs the video volume slider.
   */
  syncVideoVolumeSlider() {
    this.videoManager.syncVideoVolumeSlider(), this.syncPopupOverlayState();
  }
  /**
   * Sets language select menu values.
   * @param {string} from Source language.
   * @param {string} to Target language.
   */
  setSelectMenuValues(t, e) {
    this.videoManager.setSelectMenuValues(
      t,
      e
    ), this.syncPopupOverlayState();
  }
  /**
   * Keeps translation and video sliders linked (syncVolume option).
   *
   * The implementation is delta-based: when the user changes one slider, the
   * other slider moves by the same delta. This preserves the relative
   * difference between volumes and works with "audio booster" (translation can
   * exceed 100%).
   */
  syncVolumeWrapper(t, e) {
    const i = this.uiManager.votOverlayView;
    if (!i?.isInitialized())
      return;
    const s = i.videoVolumeSlider, o = i.translationVolumeSlider;
    if (!s || !o)
      return;
    const { nextVideo: r, nextTranslation: a } = Zv({
      state: this.volumeLinkState,
      fromType: t,
      newVolume: e,
      currentVideo: Number(s.value),
      currentTranslation: Number(o.value),
      translationMin: o.min,
      translationMax: o.max
    });
    if (typeof a == "number") {
      o.value = a, this.audioPlayer?.player && (this.audioPlayer.player.volume = a / 100);
      return;
    }
    typeof r == "number" && (s.value = r, this.setVideoVolume(r / 100));
  }
  /**
   * Retrieves video data.
   * @returns {Promise<Object>} The video data object.
   */
  getVideoData() {
    return this.videoManager.getVideoData();
  }
  sanitizeDownloadName(t) {
    return t.replace(/\.(mp4|mkv|mov|webm|avi|m4v|mp3|srt|vtt|json)$/iu, "").replace(/[<>:"/\\|?*\x00-\x1F]/g, "_").replace(/\s+/g, " ").trim();
  }
  getDownloadBaseName() {
    const t = typeof this.videoData?.downloadTitle == "string" && this.videoData.downloadTitle.trim() ? this.videoData.downloadTitle : void 0, e = typeof this.videoData?.title == "string" && this.videoData.title.trim() ? this.videoData.title : void 0, i = typeof this.videoData?.videoTitle == "string" && this.videoData.videoTitle.trim() ? this.videoData.videoTitle : void 0, s = t || e || i || `translation-${this.videoData?.videoId ?? "audio"}`;
    return this.sanitizeDownloadName(s);
  }
  /**
   * Validates the video.
   * @returns {Promise<boolean>} True if valid.
   */
  videoValidator() {
    return this.videoManager.videoValidator();
  }
  /**
   * Stops translation and resets UI elements.
   */
  stopTranslate() {
    if (this.stopTranslatePromise !== null)
      return this.stopTranslatePromise;
    const e = (async () => {
      if (this.clearPendingAutoplayRecovery(), this.externalTranslationSourceUrl = null, this.audioPlayer?.player) {
        try {
          this.audioPlayer.player.removeVideoEvents(), this.audioPlayer.player.src = "", await this.audioPlayer.player.clear();
        } catch {
        }
        V.log("audioPlayer after stopTranslate", this.audioPlayer);
      }
      this.activeTranslation = null;
      const i = this.uiManager.votOverlayView;
      i && (i.videoVolumeSlider && (i.videoVolumeSlider.hidden = !0), i.translationVolumeSlider && (i.translationVolumeSlider.hidden = !0), i.downloadTranslationButton && (i.downloadTranslationButton.hidden = !0)), this.downloadTranslationUrl = null, this.longWaitingResCount = 0, this.hadAsyncWait = !1, this.transformBtn("none", p.get("translateVideo")), this.syncPopupOverlayState({
        status: "none",
        label: p.get("translateVideo"),
        canDownload: !1,
        hint: "Translation audio is not available yet."
      }), V.log(`Volume on start: ${this.volumeOnStart}`);
      const s = typeof this.smartVolumeDuckingBaseline == "number" ? this.smartVolumeDuckingBaseline : this.volumeOnStart;
      Tn(this, { restoreVolume: s }), this.volumeOnStart = void 0, this.autoRetry !== void 0 && (clearTimeout(this.autoRetry), this.autoRetry = void 0), this.translationRefreshTimeout !== void 0 && (clearTimeout(this.translationRefreshTimeout), this.translationRefreshTimeout = void 0), this.resetActionsAbortController("stopTranslate");
    })().finally(() => {
      this.stopTranslatePromise === e && (this.stopTranslatePromise = null);
    });
    return this.stopTranslatePromise = e, e;
  }
  waitForPendingStopTranslate() {
    return this.stopTranslatePromise ?? LT;
  }
  /**
   * Updates the translation error message on the UI.
   * @param {string|Error} errorMessage The error message.
   */
  async updateTranslationErrorMsg(t, e) {
    if (e?.aborted)
      return;
    const i = p.get("translationTake"), s = p.lang;
    if (this.longWaitingResCount = t === p.get("translationTakeAboutMinute") ? this.longWaitingResCount + 1 : 0, V.log("longWaitingResCount", this.longWaitingResCount), this.longWaitingResCount > Xd && (t = new ft("TranslationDelayed")), t?.name === "VOTLocalizedError")
      this.transformBtn("error", t.localizedMessage);
    else if (t instanceof Error)
      this.transformBtn("error", t?.message);
    else if (this.data?.translateAPIErrors && s !== "ru" && !t?.includes(i)) {
      const o = this.uiManager.votOverlayView;
      if (!o?.votButton)
        return;
      const r = Array.isArray(t) ? t.join(" ") : String(t), a = `${s}:${r}`, l = this.errorTranslationCache.get(a);
      if (l)
        this.transformBtn("error", l);
      else {
        o.votButton.loading = !0;
        const u = await ys(r, "ru", s), d = Array.isArray(u) ? u.join(`
`) : String(u);
        if (e?.aborted)
          return;
        if (this.errorTranslationCache.set(a, d), this.errorTranslationCache.size > 50) {
          const h = this.errorTranslationCache.keys().next().value;
          h && this.errorTranslationCache.delete(h);
        }
        this.transformBtn("error", d);
      }
      if (e?.aborted)
        return;
    } else {
      const o = Array.isArray(t) ? t.join(`
`) : String(t ?? "");
      this.transformBtn("error", o);
    }
    e?.aborted || [
      "Подготавливаем перевод",
      "Видео передано в обработку",
      "Ожидаем перевод видео",
      "Загружаем переведенное аудио"
    ].includes(t) && this.uiManager.votOverlayView?.votButton && (this.uiManager.votOverlayView.votButton.loading = !0);
  }
  /**
   * Called after translation is updated.
   * @param {string} audioUrl The URL of the translation audio.
   */
  afterUpdateTranslation(t) {
    const e = this.uiManager.votOverlayView;
    if (!e?.votButton)
      return;
    const i = e.votButton.container.dataset.status === "success";
    if (e.videoVolumeSlider && (e.videoVolumeSlider.hidden = !this.data?.showVideoSlider || !i), e.translationVolumeSlider && (e.translationVolumeSlider.hidden = !i), e.videoVolumeSlider && e.translationVolumeSlider ? (this.volumeLinkState.lastVideoPercent = Number(
      e.videoVolumeSlider.value
    ), this.volumeLinkState.lastTranslationPercent = Number(
      e.translationVolumeSlider.value
    ), this.volumeLinkState.initialized = !0) : this.volumeLinkState.initialized = !1, this.videoData && !this.videoData.isStream && (e.downloadTranslationButton && (e.downloadTranslationButton.hidden = !1), this.downloadTranslationUrl = t), V.log(
      "afterUpdateTranslation downloadTranslationUrl",
      this.downloadTranslationUrl
    ), this.syncTranslationPlaybackVolume(), this.syncPopupOverlayState({
      status: i ? "success" : "none",
      label: i ? "Turn off" : p.get("translateVideo"),
      canDownload: !!this.downloadTranslationUrl,
      canDownloadSubtitles: !!this.yandexSubtitles,
      hint: this.downloadTranslationUrl ? "Translated audio is ready for download." : "Waiting for translated audio."
    }), i && this.site.host === "vk" && this.videoData?.videoId) {
      const s = this.getSubtitlesCacheKey(
        this.videoData.videoId,
        this.videoData.detectedLanguage,
        this.videoData.responseLanguage
      );
      this.cacheManager.deleteSubtitles(s), this.subtitles = [], this.subtitlesCacheKey = null, (async () => {
        try {
          await this.loadSubtitles(), this.data?.autoSubtitles && await this.enableSubtitlesForCurrentLangPair();
        } catch (o) {
          V.log("[VOT][VK subtitles] failed to refresh after translation", {
            error: o,
            videoId: this.videoData?.videoId
          });
        }
      })();
    }
    this.data?.sendNotifyOnComplete && this.hadAsyncWait && i && (this.notifier.translationCompleted(globalThis.location.hostname), this.hadAsyncWait = !1);
  }
  /**
   * Validates the audio URL by sending a request.
   * @param {string} audioUrl The audio URL to validate.
   * @returns {Promise<string>} The valid audio URL.
   */
  validateAudioUrl(t, e) {
    return this.callModuleAsync(dT, t, e);
  }
  scheduleTranslationRefresh() {
    this.callModule(hT);
  }
  /**
   * Proxifies the audio URL if needed.
   * @param {string} audioUrl The original audio URL.
   * @returns {string} The proxified audio URL.
   */
  proxifyAudio(t) {
    return this.callModule(gT, t);
  }
  /**
   * Reverts a previously proxified audio URL back to the original Yandex S3 URL.
   *
   * This allows us to re-apply proxy settings when the proxy host/mode changes
   * without permanently "locking in" the old proxy host in the current player
   * src.
   */
  unproxifyAudio(t) {
    return this.callModule(mT, t);
  }
  isMultiMethodS3(t) {
    return this.callModule(bT, t);
  }
  /**
   * Translates the video/audio.
   * @param {string} VIDEO_ID The video ID.
   * @param {boolean} isStream Whether the video is a stream.
   * @param {string} requestLang Source language.
   * @param {string} responseLang Target language.
   * @param {any} translationHelp Optional translation helper data.
   */
  translateFunc(t, e, i, s, o) {
    return vT.call(
      this,
      t,
      e,
      i,
      s,
      o
    );
  }
  /**
   * used for enable audio downloader on this hosts
   */
  isYouTubeHosts() {
    return this.callModule(wT);
  }
  canUploadAudioForCurrentSite() {
    const t = this.site.host, e = String(
      this.videoData?.url || this.video?.currentSrc || this.video?.src || ""
    );
    return (() => {
      if (!e)
        return jt(t, this.videoData?.host);
      try {
        const s = new URL(
          e,
          globalThis.location.href
        ).toString();
        return this.votClient.isDirectMediaUrl(s) ? jt(t, this.videoData?.host) || new URL(s).hostname !== globalThis.location.hostname : jt(t, this.videoData?.host);
      } catch {
        return jt(t, this.videoData?.host);
      }
    })() ? !0 : this.data?.useAudioDownload ? t === "youtube" || t === "invidious" || t === "piped" || t === "yandexdisk" || t === "custom" || t === "vk" : !1;
  }
  /**
   * Configures audio settings such as volume.
   */
  setupAudioSettings() {
    return this.callModule(Fc);
  }
  syncTranslationPlaybackVolume() {
    return this.callModule(tT);
  }
  applyManualVideoVolumeOverride(t) {
    return this.callModule(ST, t);
  }
  /**
   * Handles video source change events.
   */
  handleSrcChanged() {
    return this.lifecycleController.handleSrcChanged();
  }
  /**
   * Releases resources and removes event listeners.
   */
  async release() {
    this.initialized = !1;
    try {
      await this.stopTranslation();
    } catch {
    }
    this.lifecycleController?.teardown(), this.abortController?.abort(), this.abortController = new AbortController(), this.overlayVisibility?.release(), this.releaseExtraEvents(), this.hasSubtitlesWidget() && (this.subtitlesWidget?.release(), this.subtitlesWidget = void 0), this.interactionChecker?.destroy(), this.uiManager.release(), gs() && this.popupOverlayBridge?.isOwner(this.popupOwnerId) && this.popupOverlayBridge.close(), this.popupOverlayBridge = void 0;
  }
  /**
   * Collects report information for bug reporting.
   * @returns {Object} Report info object.
   */
  collectReportInfo() {
    const t = hc(), e = this.videoData?.detectedLanguage ?? "unknown", i = this.videoData?.responseLanguage ?? "unknown", s = `<details>
<summary>Autogenerated by VOT:</summary>
<ul>
  <li>OS: ${t.os}</li>
  <li>Browser: ${t.browser}</li>
  <li>Loader: ${t.loader}</li>
  <li>Script version: ${t.scriptVersion}</li>
  <li>URL: <code>${t.url}</code></li>
  <li>Lang: <code>${e}</code> -> <code>${i}</code> (Lively voice: ${this.data?.useLivelyVoice ?? !1} | Audio download: ${this.data?.useAudioDownload ?? !1})</li>
  <li>Player: ${this.data?.newAudioPlayer ? "New" : "Old"} (CSP only: ${this.data?.onlyBypassMediaCSP ?? !1})</li>
  <li>Proxying mode: ${this.data?.translateProxyEnabled ?? 0}</li>
</ul>
</details>`;
    return {
      assignees: "Acobat12",
      template: `1-bug-report-${p.lang === "ru" ? "ru" : "en"}.yml`,
      os: t.os,
      "script-version": t.scriptVersion,
      "additional-info": s
    };
  }
}
const AT = oo(), Hn = new As(AT), ET = /* @__PURE__ */ new WeakMap();
let Ye = null;
const _t = Fd();
function VT(n) {
  try {
    const e = new URL(n, globalThis.location.origin).pathname;
    return /\/file\/d\/([^/]+)/.exec(e)?.[1] || /\/videos\/d\/([^/]+)/.exec(e)?.[1] || /\/d\/([^/]+)/.exec(e)?.[1];
  } catch {
    return;
  }
}
function CT(n) {
  return typeof n != "string" ? void 0 : n.replace(/\s*-\s*Google Drive\s*$/i, "").replace(/\s*-\s*Google Диск\s*$/i, "").trim() || void 0;
}
function IT() {
  const n = Array.from(
    document.querySelectorAll('[data-is-tooltip-wrapper="true"] > span')
  ).map((s) => s.textContent?.trim() ?? "").find((s) => /\.(mp4|mkv|mov|webm|avi|m4v)$/i.test(s)) || "", t = document.querySelector('h1, [role="heading"], div[role="heading"]')?.textContent?.trim() || "", e = document.querySelector('meta[property="og:title"], meta[name="title"]')?.getAttribute("content")?.trim() || "", i = String(document.title || "").trim();
  return CT(
    n || t || e || i
  );
}
async function PT() {
  const n = globalThis.location.hostname;
  if (n !== "drive.google.com" && n !== "docs.google.com")
    return;
  const t = VT(globalThis.location.href);
  if (!t)
    return;
  const e = IT();
  if (e)
    try {
      await C.set(`googledrive:title:${t}`, e);
    } catch (i) {
      console.warn("[VOT] failed to persist Google Drive title", i);
    }
}
function MT() {
  return {
    frame: Qn() ? "iframe" : "top",
    host: globalThis.location.hostname || "unknown",
    path: globalThis.location.pathname || "/"
  };
}
function Lt(n, t) {
  const e = MT(), i = {
    host: e.host,
    path: e.path
  };
  t && Object.assign(i, t), console.log(`[VOT][bootstrap][${e.frame}] ${n}`, i);
}
function Ga(n, t) {
  const e = t.hostname, i = (s) => {
    if (s instanceof RegExp) return s.test(e);
    if (typeof s == "string") return e.includes(s);
    if (typeof s == "function")
      try {
        return !!s(t);
      } catch {
        return !1;
      }
    return !1;
  };
  return Array.isArray(n.match) ? n.match.some(i) : i(n.match);
}
function Ka() {
  if (!Ye) {
    const n = Od(), t = new URL(globalThis.location.href), e = n.filter((r) => Ga(r, t));
    Ye = [...wm.filter((r) => Ga(r, t)), ...e];
    const s = {
      host: "custom",
      url: "stub",
      selector: lt,
      eventSelector: lt,
      rawResult: !0,
      priority: -1e3
    };
    Ye.some(
      (r) => String(r.host) === "custom" && r.selector === lt
    ) || Ye.push(s);
  }
  return Ye;
}
function OT(n, t) {
  if (n.selector) {
    const i = ti(t, n.selector);
    if (i)
      return i;
  }
  const e = ti(
    t,
    lt
  );
  return e || t.parentElement;
}
function DT() {
  const n = String(globalThis.location.hostname || "").toLowerCase();
  return n === "youtube.com" || n.endsWith(".youtube.com") || n === "youtu.be" || n.endsWith(".youtube-nocookie.com") || n.endsWith(".youtubekids.com") || n === "youtube.googleapis.com";
}
function _T() {
  return !DT();
}
async function RT() {
  await PT(), _T() && Ul();
  const n = Qn(), t = Mm({
    isIframe: Qn(),
    origin: globalThis.location.origin,
    authOrigin: yn
  });
  if (t === "skip") {
    Lt("Skipping bootstrap for non-runnable iframe");
    return;
  }
  n && document.visibilityState === "hidden" && (Lt("Hidden iframe detected; delaying bootstrap until visible"), await new Promise((s) => {
    const o = () => {
      document.visibilityState !== "hidden" && (document.removeEventListener("visibilitychange", o), s());
    };
    document.addEventListener("visibilitychange", o), setTimeout(() => {
      document.removeEventListener("visibilitychange", o), s();
    }, 1500);
  })), Lt("Loading extension"), t === "auth-eager" ? Ar("auth-page", Lt).catch((s) => {
    console.error("[VOT] Failed to activate runtime", s);
  }) : Lt("Lazy bootstrap enabled; waiting for video detection"), pm({
    videoObserver: Hn,
    videosWrappers: ET,
    ensureRuntimeActivated: (s) => Ar(s, Lt),
    getServicesCached: Ka,
    findContainer: OT,
    createVideoHandler: (s, o, r) => new xT(s, o, r)
  });
  const e = Ka(), i = Im({
    hostname: globalThis.location.hostname,
    services: e
  });
  if (Hn.setPolicy(i), i.preferProbeBootstrap) {
    Lt("Lightweight video probe enabled", {
      strategy: i.probeStrategy,
      selectors: i.probeSelectors.join(", ")
    }), Ud({
      strategy: i.probeStrategy,
      selectors: i.probeSelectors,
      pollIntervalMs: i.probePollIntervalMs,
      pollTimeoutMs: i.probePollTimeoutMs,
      onVideoDetected: (s, o) => {
        Lt("Probe detected candidate video", { reason: s }), Hn.enable(o);
      }
    });
    return;
  }
  Hn.enable();
}
const Ya = "data-vot-bootstrap-active";
if (document.documentElement.hasAttribute(Ya))
  Lt("dom bootstrap already initialized, skipping duplicate run");
else if (document.documentElement.setAttribute(Ya, "1"), _t.status === "booting" || _t.status === "booted")
  Lt("bootstrap already initialized, skipping duplicate run", {
    status: _t.status
  });
else {
  const n = async () => {
    try {
      await RT(), _t.status = "booted";
    } catch (t) {
      _t.status = "failed", _t.error = t, console.error("[VOT]", t);
    }
  };
  _t.status = "booting", _t.promise = n();
}
export {
  xT as VideoHandler,
  Ce as countryCode,
  hc as getEnvironmentInfo
};
