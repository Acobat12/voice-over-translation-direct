const x = () => {
}, it = x, st = x, ut = x, c = { log: it, warn: st, error: ut };
function at(t) {
  const e = /* @__PURE__ */ new WeakSet();
  try {
    return JSON.stringify(t, (r, o) => typeof o != "object" || o === null ? o : e.has(o) ? "[Circular]" : (e.add(o), o)) ?? null;
  } catch {
    return null;
  }
}
function j(t, e = "Unknown error") {
  if (t instanceof Error)
    return t.message || e;
  if (typeof t == "string")
    return t || e;
  if (t == null)
    return e;
  if (typeof t == "object") {
    const n = t;
    if (typeof n?.data?.message == "string" && n.data.message)
      return n.data.message;
    if (typeof n?.error?.message == "string" && n.error.message)
      return n.error.message;
    if (typeof n?.message == "string" && n.message)
      return n.message;
    const r = at(t);
    if (r && r !== "{}")
      return r;
    const o = t.constructor?.name;
    return o ? `[${o}]` : e;
  }
  return typeof t == "number" || typeof t == "boolean" || typeof t == "bigint" ? `${t}` : typeof t == "symbol" ? t.description ? `Symbol(${t.description})` : "Symbol" : typeof t == "function" ? t.name ? `[Function ${t.name}]` : "[Function]" : e;
}
const lt = {
  alphabet: "base64url"
}, N = typeof Uint8Array.prototype.toBase64 == "function" ? Uint8Array.prototype.toBase64 : null, R = Uint8Array.fromBase64;
function ct(t) {
  const e = String(t).replaceAll(/\s+/g, ""), n = e.length % 4;
  if (n === 1)
    throw new TypeError("Invalid base64 input.");
  return n === 0 ? e : e + "=".repeat(4 - n);
}
function ft(t) {
  let e = "";
  for (const n of t)
    e += String.fromCharCode(n);
  return e;
}
function yt(t) {
  const e = globalThis.atob;
  if (typeof e != "function")
    throw new TypeError("Base64 decoder is not available in this environment.");
  const n = e(t), r = new Uint8Array(n.length);
  for (let o = 0; o < n.length; o += 1)
    r[o] = n.charCodeAt(o);
  return r;
}
function mt(t) {
  const e = globalThis.btoa;
  if (typeof e != "function")
    throw new TypeError("Base64 encoder is not available in this environment.");
  return e(ft(t));
}
function gt(t) {
  const e = ct(t), n = e.replaceAll("-", "+").replaceAll("_", "/");
  if (typeof R != "function")
    return yt(n);
  const r = e.includes("-") || e.includes("_"), o = e.includes("+") || e.includes("/");
  return r && !o ? R(e, lt) : R(
    r && o ? n : e
  );
}
function v(t) {
  return typeof N == "function" ? N.call(t) : mt(t);
}
function P(t) {
  return gt(t);
}
const U = 1e7, pt = 12, dt = 2;
function _(t) {
  return t !== null && typeof t == "object";
}
function ht(t) {
  return k(t) === "[object Object]";
}
function k(t) {
  try {
    return Object.prototype.toString.call(t);
  } catch {
    return null;
  }
}
function S(t) {
  return k(t) === "[object ArrayBuffer]";
}
function Tt(t) {
  try {
    const e = t?.constructor?.name;
    return typeof e == "string" ? e : null;
  } catch {
    return null;
  }
}
function d(t, e) {
  try {
    const n = t?.[e];
    return typeof n == "string" ? n : null;
  } catch {
    return null;
  }
}
function q(t) {
  if (k(t) === "[object Blob]") return !0;
  if (!t || typeof t != "object") return !1;
  try {
    const n = t, r = typeof n.arrayBuffer == "function", o = typeof n.slice == "function", s = typeof n.size == "number", i = typeof n.type == "string";
    return (r || o) && s && i;
  } catch {
    return !1;
  }
}
function bt(t) {
  try {
    return JSON.stringify(t);
  } catch {
    return null;
  }
}
function O(t) {
  if (typeof t != "number" || !Number.isFinite(t)) return null;
  const e = Math.trunc(t);
  return e < 0 || e > U ? null : e;
}
function M(t) {
  return typeof t != "number" || !Number.isFinite(t) ? null : Math.trunc(t) & 255;
}
function E(t) {
  const e = t.length;
  if (e > U) return null;
  const n = new Uint8Array(e);
  for (let r = 0; r < e; r += 1) {
    const o = M(t[r]);
    if (o === null) return null;
    n[r] = o;
  }
  return n;
}
function Y(t) {
  return new Uint8Array(
    t.buffer,
    t.byteOffset,
    t.byteLength
  );
}
function _t(t) {
  return Y(t).slice();
}
function Et(t) {
  if (t === "") return null;
  const e = Number(t);
  return !Number.isFinite(e) || !Number.isInteger(e) || e < 0 ? null : e;
}
function $(t) {
  if (!_(t)) return !1;
  const e = t;
  return e.__votExtBody === !0 && typeof e.b64 == "string";
}
function X(t) {
  return {
    __votExtBody: !0,
    kind: "bytes",
    b64: v(t)
  };
}
function Bt(t, e) {
  return {
    __votExtBody: !0,
    kind: "blob",
    b64: v(t),
    mime: e
  };
}
async function St(t) {
  if (!_(t)) return null;
  try {
    const e = t;
    if (typeof e.arrayBuffer == "function")
      return { ab: await e.arrayBuffer(), mime: d(e, "type") };
  } catch {
  }
  if (typeof Response < "u")
    try {
      return { ab: await new Response(t).arrayBuffer(), mime: d(t, "type") };
    } catch {
    }
  if (typeof Blob < "u" && q(t))
    try {
      return { ab: await t.arrayBuffer(), mime: d(t, "type") };
    } catch {
    }
  return null;
}
function K(t, e = 0) {
  if (e > dt || !_(t)) return null;
  const n = t;
  if (S(t))
    return new Uint8Array(t);
  try {
    if (ArrayBuffer.isView(t))
      return _t(t);
  } catch {
  }
  if (Array.isArray(t))
    return E(t);
  if (n.type === "Buffer" && Array.isArray(n.data)) {
    const i = E(n.data);
    if (i) return i;
  }
  if (Array.isArray(n.data)) {
    const i = E(n.data);
    if (i) return i;
  }
  if (Array.isArray(n.bytes)) {
    const i = E(n.bytes);
    if (i) return i;
  }
  if (typeof n.b64 == "string")
    try {
      return P(n.b64);
    } catch {
    }
  if (typeof n.base64 == "string")
    try {
      return P(n.base64);
    } catch {
    }
  const r = O(n.byteLength), o = O(n.byteOffset ?? 0);
  if (r !== null && o !== null) {
    const i = n.buffer;
    if (S(i))
      try {
        return new Uint8Array(
          i,
          o,
          r
        ).slice();
      } catch {
      }
    if (i && i !== t) {
      const a = K(
        i,
        e + 1
      );
      if (a) {
        if (o > a.byteLength) return null;
        const u = Math.min(
          a.byteLength,
          o + r
        );
        return a.slice(o, u);
      }
    }
  }
  const s = O(n.length);
  if (s !== null) {
    const i = n, a = new Uint8Array(s);
    for (let u = 0; u < s; u += 1) {
      const l = M(i[u]);
      if (l === null)
        return null;
      a[u] = l;
    }
    return a;
  }
  if (ht(t)) {
    const i = Object.keys(n);
    if (!i.length) return null;
    const a = new Array(i.length);
    let u = -1;
    for (let f = 0; f < i.length; f += 1) {
      const m = Et(i[f]);
      if (m === null || m > U) return null;
      a[f] = m, m > u && (u = m);
    }
    const l = new Uint8Array(u + 1);
    for (let f = 0; f < i.length; f += 1) {
      const m = i[f], z = M(n[m]);
      if (z === null) return null;
      l[a[f]] = z;
    }
    return l;
  }
  return null;
}
function W(t) {
  return K(t);
}
function w(t) {
  const e = t === null ? "null" : typeof t, n = k(t), r = Tt(t);
  if (t == null)
    return { kind: "empty", jsType: e, tag: n, ctor: r };
  if (typeof t == "string")
    return { kind: "string", jsType: e, tag: n, ctor: r, textLength: t.length };
  if ($(t))
    return {
      kind: `serialized:${typeof t.kind == "string" && t.kind ? t.kind : "bytes"}`,
      jsType: e,
      tag: n,
      ctor: r,
      base64Length: t.b64.length,
      mime: d(t, "mime")
    };
  if (S(t))
    return {
      kind: "ArrayBuffer",
      jsType: e,
      tag: n,
      ctor: r,
      byteLength: t.byteLength
    };
  try {
    if (ArrayBuffer.isView(t)) {
      const s = t;
      return {
        kind: r ? `TypedArray:${r}` : "TypedArray",
        jsType: e,
        tag: n,
        ctor: r,
        byteLength: s.byteLength
      };
    }
  } catch {
  }
  if (q(t))
    return {
      kind: "BlobLike",
      jsType: e,
      tag: n,
      ctor: r,
      byteLength: typeof t.size == "number" ? Number(t.size) : -1,
      mime: d(t, "type")
    };
  const o = W(t);
  if (o)
    return {
      kind: "coerced-bytes",
      jsType: e,
      tag: n,
      ctor: r,
      byteLength: o.byteLength
    };
  if (_(t)) {
    const s = Object.keys(t);
    return {
      kind: "object",
      jsType: e,
      tag: n,
      ctor: r,
      keyCount: s.length,
      keys: s.slice(0, pt)
    };
  }
  return { kind: "primitive", jsType: e, tag: n, ctor: r };
}
async function wt(t) {
  if (t == null || typeof t == "string") return t;
  if ($(t))
    return t.kind === "blob" ? {
      __votExtBody: !0,
      kind: "blob",
      b64: t.b64,
      mime: d(t, "mime")
    } : {
      __votExtBody: !0,
      kind: "bytes",
      b64: t.b64
    };
  if (S(t))
    return X(new Uint8Array(t));
  try {
    if (ArrayBuffer.isView(t))
      return X(Y(t));
  } catch {
  }
  const e = await St(t);
  if (e)
    return Bt(new Uint8Array(e.ab), e.mime);
  const n = W(t);
  if (n)
    return X(n);
  const r = w(t);
  try {
    console.warn(
      "[VOT Extension] Unsupported GM_xmlhttpRequest body type; coercing fallback.",
      r
    );
  } catch {
  }
  if (_(t)) {
    const o = bt(t);
    if (typeof o == "string") return o;
  }
  return String(t);
}
const J = "__VOT_EXT_BRIDGE__", Q = "VOT_EXT_REQ", Z = "VOT_EXT_RES", tt = "VOT_EXT_XHR_START", L = "VOT_EXT_XHR_ABORT", et = "VOT_EXT_XHR_ACK", nt = "VOT_EXT_XHR_EVENT", V = "VOT_EXT_NOTIFY", At = /* @__PURE__ */ new Set([
  Q,
  Z,
  V,
  tt,
  L,
  et,
  nt
]);
function kt(t) {
  return !!(t && typeof t == "object" && t[J] === !0 && typeof t.type == "string" && At.has(t.type));
}
function Rt(t) {
  return { ...t, [J]: !0 };
}
function Ot(t) {
  return Rt(t);
}
const C = "__VOT_EXT_PRELUDE_BOOTED__", Xt = 1e3, Mt = 15e3, Vt = typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now().toString(36)}_${Math.random().toString(36).slice(2)}`;
function T(t) {
  return t && typeof t == "object" ? t : {};
}
function xt(t) {
  if (t == null) return;
  const e = Number(t);
  return Number.isFinite(e) ? e : void 0;
}
function p(t) {
  globalThis.postMessage(Ot(t), "*");
}
function D(t) {
  const e = T(t);
  return {
    title: e.title != null ? String(e.title) : void 0,
    text: e.text != null ? String(e.text) : void 0,
    image: e.image != null ? String(e.image) : void 0,
    silent: !!e.silent,
    timeout: xt(e.timeout),
    tag: e.tag != null ? String(e.tag) : void 0
  };
}
let F = 0;
const A = /* @__PURE__ */ new Map();
function rt() {
  return F += 1, `${Vt}_${F.toString(36)}`;
}
function g(t, e = {}) {
  const n = rt();
  return new Promise((r, o) => {
    const s = globalThis.setTimeout(() => {
      A.delete(n), o(new Error(`VOT bridge timeout for ${t}`));
    }, Mt);
    A.set(n, {
      resolve: (i) => r(i),
      reject: o,
      timeoutId: s
    }), p({ type: Q, id: n, action: t, payload: e });
  });
}
const y = /* @__PURE__ */ new Map();
function h(t, e) {
  try {
    typeof t == "function" && t(e);
  } catch (n) {
    console.error("[VOT Extension] GM_xmlhttpRequest callback error", n);
  }
}
function B(t, e, n, r, o) {
  return (s) => {
    if (h(e[t], s), !n.isSettled) {
      if (n.isSettled = !0, t === "onload") {
        r(s);
        return;
      }
      o(s);
    }
  };
}
function b(t) {
  const e = y.get(t);
  return e ? (e.settled = !0, y.delete(t), e.timeoutId !== null && clearTimeout(e.timeoutId), e.callbacks) : null;
}
function ot(t, e) {
  e.timeoutId !== null && (clearTimeout(e.timeoutId), e.timeoutId = null), !(e.settled || !e.acknowledged || !Number.isFinite(e.timeoutMs) || e.timeoutMs <= 0) && (e.timeoutId = globalThis.setTimeout(() => {
    const n = y.get(t);
    if (!n || n.settled) return;
    c.warn("[VOT EXT][prelude] GM_xmlhttpRequest timeout fallback fired", {
      requestId: t,
      timeoutMs: n.timeoutMs,
      state: "terminal",
      lastBridgeEventAt: n.lastBridgeEventAt || null
    });
    const r = b(t);
    if (r) {
      try {
        p({ type: L, requestId: t });
      } catch {
      }
      h(r.ontimeout, {
        finalUrl: String(n.callbacks.url || ""),
        readyState: 4,
        status: 0,
        statusText: "",
        responseHeaders: "",
        response: null,
        responseText: "",
        error: "Timeout"
      });
    }
  }, e.timeoutMs + Xt));
}
function H(t) {
  return {
    method: t.method,
    url: t.url,
    headers: t.headers,
    data: w(t.data),
    timeout: t.timeout,
    responseType: t.responseType,
    anonymous: t.anonymous,
    withCredentials: t.withCredentials
  };
}
async function Ut(t) {
  const e = w(t.data), n = await wt(t.data), r = w(n);
  return c.log("[VOT EXT][prelude] GM_xmlhttpRequest body serialized", {
    url: t.url,
    method: t.method,
    from: e,
    to: r
  }), typeof n == "string" && /^\[object [^\]]+\]$/.test(n.trim()) && c.warn("[VOT EXT][prelude] suspicious serialized body string", {
    url: t.url,
    method: t.method,
    serializedBody: n,
    sourceBody: e
  }), {
    method: t.method,
    url: t.url,
    headers: t.headers,
    data: n,
    timeout: t.timeout,
    responseType: t.responseType,
    anonymous: t.anonymous,
    withCredentials: t.withCredentials
  };
}
function I(t) {
  const e = T(t);
  return {
    status: e.status ?? null,
    statusText: e.statusText ?? null,
    readyState: e.readyState ?? null,
    finalUrl: e.finalUrl ?? null
  };
}
function Lt(t, e) {
  return {
    finalUrl: String(t.url ?? ""),
    readyState: 4,
    status: 0,
    statusText: "",
    responseHeaders: "",
    response: null,
    responseText: "",
    error: e
  };
}
function It() {
  globalThis.GM_notification = (e) => {
    try {
      p({
        type: V,
        details: D(e)
      });
    } catch {
    }
  }, globalThis.GM_addStyle = (e) => {
    const n = document.createElement("style");
    return n.textContent = String(e ?? ""), (document.head || document.documentElement).appendChild(n), n;
  }, globalThis.GM_xmlhttpRequest = (e) => {
    const n = rt(), r = T(e), o = Number(r.timeout ?? 0), s = {
      callbacks: r,
      timeoutId: null,
      timeoutMs: Number.isFinite(o) ? o : 0,
      acknowledged: !1,
      settled: !1,
      lastBridgeEventAt: 0
    };
    y.set(n, s);
    let i = !0;
    return c.log("[VOT EXT][prelude] GM_xmlhttpRequest", {
      requestId: n,
      state: "created",
      timeoutMs: s.timeoutMs,
      details: H(r)
    }), (async () => {
      try {
        if (!i || !y.has(n)) return;
        const u = await Ut(r);
        if (!i || !y.has(n)) return;
        c.log("[VOT EXT][prelude] GM_xmlhttpRequest post TYPE_XHR_START", {
          requestId: n,
          details: H(r)
        }), p({
          type: tt,
          requestId: n,
          details: u
        });
      } catch (u) {
        if (!i || !y.has(n)) return;
        i = !1;
        const l = j(u);
        h(
          b(n)?.onerror,
          Lt(r, l)
        );
      }
    })(), {
      abort: () => {
        i && (i = !1, b(n), p({ type: L, requestId: n }));
      }
    };
  };
  const t = (e) => {
    const n = T(e);
    let r = null;
    const o = new Promise((s, i) => {
      const a = { ...n }, u = { isSettled: !1 };
      a.onload = B(
        "onload",
        n,
        u,
        s,
        i
      ), a.onerror = B(
        "onerror",
        n,
        u,
        s,
        i
      ), a.ontimeout = B(
        "ontimeout",
        n,
        u,
        s,
        i
      ), a.onabort = B(
        "onabort",
        n,
        u,
        s,
        i
      );
      const l = globalThis.GM_xmlhttpRequest(a);
      r = l && typeof l.abort == "function" ? l.abort.bind(l) : null;
    });
    return o.abort = () => {
      try {
        r?.();
      } catch {
      }
    }, o;
  };
  globalThis.GM = {
    getValue: (e, n) => g("gm_getValue", { key: e, def: n }),
    setValue: (e, n) => g("gm_setValue", { key: e, value: n }),
    deleteValue: (e) => g("gm_deleteValue", { key: e }),
    listValues: () => g("gm_listValues"),
    getValues: (e) => g("gm_getValues", { defaults: e }),
    notification: (e) => {
      p({
        type: V,
        details: D(e)
      });
    },
    // GM4 promise API (Tampermonkey-style)
    xmlHttpRequest: (e) => t(e)
  }, globalThis.GM_info = {
    script: {
      name: "VOT Extension",
      version: "0.0.0"
    },
    scriptHandler: "VOT Extension",
    version: "0.0.0"
  };
}
function zt() {
  globalThis.addEventListener("message", (t) => {
    if (t.source !== globalThis.window) return;
    const e = t.data;
    kt(e) && (Nt(e) || Pt(e) || Ht(e));
  });
}
function Nt(t) {
  if (t.type !== Z) return !1;
  const e = String(t.id ?? ""), n = A.get(e);
  return n && (A.delete(e), clearTimeout(n.timeoutId), t.ok ? n.resolve(t.result) : n.reject(new Error(j(t.error ?? "Bridge error")))), !0;
}
function Pt(t) {
  if (t.type !== et) return !1;
  const e = String(t.requestId ?? ""), n = y.get(e);
  return n && (n.acknowledged = !0, n.lastBridgeEventAt = Date.now(), ot(e, n), c.log("[VOT EXT][prelude] XHR acknowledged", {
    requestId: e,
    state: "acknowledged",
    timeoutMs: n.timeoutMs,
    payload: t.payload ?? null
  })), !0;
}
function Ct(t, e, n) {
  c.log("[VOT EXT][prelude] XHR event", {
    requestId: t,
    state: e === "progress" ? "in_flight" : "terminal",
    kind: e,
    ...I(n.response ?? n.error ?? n.progress)
  });
}
function Dt(t, e, n) {
  c.log("[VOT EXT][prelude] XHR terminal load", {
    requestId: t,
    state: "terminal",
    ...I(n.response)
  }), h(e.onload, n.response), b(t);
}
function Ft(t, e, n, r) {
  const o = r === "error" ? c.error : c.warn, i = {
    error: "onerror",
    timeout: "ontimeout",
    abort: "onabort"
  }[r];
  o(`[VOT EXT][prelude] XHR terminal ${r}`, {
    requestId: t,
    state: "terminal",
    ...I(n.error),
    error: n?.error?.error ?? null
  }), h(e[i], n.error), b(t);
}
function Ht(t) {
  if (t.type !== nt) return;
  const e = String(t.requestId ?? ""), n = y.get(e);
  if (!n) return;
  const r = n.callbacks, o = T(t.payload), s = String(o.type ?? "");
  if (Ct(e, s, o), s === "progress") {
    n.lastBridgeEventAt = Date.now(), ot(e, n), h(r.onprogress, o.progress);
    return;
  }
  if (s === "load") {
    Dt(e, r, o);
    return;
  }
  if (s === "error" || s === "timeout" || s === "abort") {
    Ft(e, r, o, s);
    return;
  }
}
const G = globalThis;
if (!G[C]) {
  G[C] = !0;
  const t = async () => {
    It(), zt();
    try {
      const { manifest: e } = await g("handshake"), n = globalThis.GM_info;
      e?.name && (n.script.name = e.name), e?.version && (n.script.version = e.version, n.version = e.version);
    } catch {
    }
  };
  (async () => {
    try {
      await t();
    } catch {
    }
  })();
}
