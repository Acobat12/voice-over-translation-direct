const G = () => {
}, Le = G, ke = G, xe = G, S = { log: Le, warn: ke, error: xe }, Ne = {
  alphabet: "base64url"
}, ce = typeof Uint8Array.prototype.toBase64 == "function" ? Uint8Array.prototype.toBase64 : null, V = Uint8Array.fromBase64;
function Re(e) {
  const t = String(e).replaceAll(/\s+/g, ""), r = t.length % 4;
  if (r === 1)
    throw new TypeError("Invalid base64 input.");
  return r === 0 ? t : t + "=".repeat(4 - r);
}
function Ue(e) {
  let t = "";
  for (const r of e)
    t += String.fromCharCode(r);
  return t;
}
function _e(e) {
  const t = globalThis.atob;
  if (typeof t != "function")
    throw new TypeError("Base64 decoder is not available in this environment.");
  const r = t(e), n = new Uint8Array(r.length);
  for (let o = 0; o < r.length; o += 1)
    n[o] = r.charCodeAt(o);
  return n;
}
function je(e) {
  const t = globalThis.btoa;
  if (typeof t != "function")
    throw new TypeError("Base64 encoder is not available in this environment.");
  return t(Ue(e));
}
function De(e) {
  const t = Re(e), r = t.replaceAll("-", "+").replaceAll("_", "/");
  if (typeof V != "function")
    return _e(r);
  const n = t.includes("-") || t.includes("_"), o = t.includes("+") || t.includes("/");
  return n && !o ? V(t, Ne) : V(
    n && o ? r : t
  );
}
function ge(e) {
  return typeof ce == "function" ? ce.call(e) : je(e);
}
function Ce(e) {
  return ge(new Uint8Array(e));
}
function U(e) {
  return De(e);
}
const J = 1e7, Ie = 12, Fe = 2;
function _(e) {
  return e !== null && typeof e == "object";
}
function He(e) {
  return j(e) === "[object Object]";
}
function j(e) {
  try {
    return Object.prototype.toString.call(e);
  } catch {
    return null;
  }
}
function q(e) {
  return j(e) === "[object ArrayBuffer]";
}
function Pe(e) {
  try {
    const t = e?.constructor?.name;
    return typeof t == "string" ? t : null;
  } catch {
    return null;
  }
}
function ue(e, t) {
  try {
    const r = e?.[t];
    return typeof r == "string" ? r : null;
  } catch {
    return null;
  }
}
function Me(e) {
  if (j(e) === "[object Blob]") return !0;
  if (!e || typeof e != "object") return !1;
  try {
    const r = e, n = typeof r.arrayBuffer == "function", o = typeof r.slice == "function", s = typeof r.size == "number", i = typeof r.type == "string";
    return (n || o) && s && i;
  } catch {
    return !1;
  }
}
function Ve(e) {
  try {
    return JSON.stringify(e);
  } catch {
    return null;
  }
}
function z(e) {
  if (typeof e != "number" || !Number.isFinite(e)) return null;
  const t = Math.trunc(e);
  return t < 0 || t > J ? null : t;
}
function Y(e) {
  return typeof e != "number" || !Number.isFinite(e) ? null : Math.trunc(e) & 255;
}
function R(e) {
  const t = e.length;
  if (t > J) return null;
  const r = new Uint8Array(t);
  for (let n = 0; n < t; n += 1) {
    const o = Y(e[n]);
    if (o === null) return null;
    r[n] = o;
  }
  return r;
}
function ze(e) {
  return new Uint8Array(
    e.buffer,
    e.byteOffset,
    e.byteLength
  );
}
function Xe(e) {
  return ze(e).slice();
}
function $e(e) {
  if (e === "") return null;
  const t = Number(e);
  return !Number.isFinite(t) || !Number.isInteger(t) || t < 0 ? null : t;
}
function me(e) {
  if (!_(e)) return !1;
  const t = e;
  return t.__votExtBody === !0 && typeof t.b64 == "string";
}
function be(e, t = 0) {
  if (t > Fe || !_(e)) return null;
  const r = e;
  if (q(e))
    return new Uint8Array(e);
  try {
    if (ArrayBuffer.isView(e))
      return Xe(e);
  } catch {
  }
  if (Array.isArray(e))
    return R(e);
  if (r.type === "Buffer" && Array.isArray(r.data)) {
    const i = R(r.data);
    if (i) return i;
  }
  if (Array.isArray(r.data)) {
    const i = R(r.data);
    if (i) return i;
  }
  if (Array.isArray(r.bytes)) {
    const i = R(r.bytes);
    if (i) return i;
  }
  if (typeof r.b64 == "string")
    try {
      return U(r.b64);
    } catch {
    }
  if (typeof r.base64 == "string")
    try {
      return U(r.base64);
    } catch {
    }
  const n = z(r.byteLength), o = z(r.byteOffset ?? 0);
  if (n !== null && o !== null) {
    const i = r.buffer;
    if (q(i))
      try {
        return new Uint8Array(
          i,
          o,
          n
        ).slice();
      } catch {
      }
    if (i && i !== e) {
      const c = be(
        i,
        t + 1
      );
      if (c) {
        if (o > c.byteLength) return null;
        const l = Math.min(
          c.byteLength,
          o + n
        );
        return c.slice(o, l);
      }
    }
  }
  const s = z(r.length);
  if (s !== null) {
    const i = r, c = new Uint8Array(s);
    for (let l = 0; l < s; l += 1) {
      const g = Y(i[l]);
      if (g === null)
        return null;
      c[l] = g;
    }
    return c;
  }
  if (He(e)) {
    const i = Object.keys(r);
    if (!i.length) return null;
    const c = new Array(i.length);
    let l = -1;
    for (let m = 0; m < i.length; m += 1) {
      const a = $e(i[m]);
      if (a === null || a > J) return null;
      c[m] = a, a > l && (l = a);
    }
    const g = new Uint8Array(l + 1);
    for (let m = 0; m < i.length; m += 1) {
      const a = i[m], f = Y(r[a]);
      if (f === null) return null;
      g[c[m]] = f;
    }
    return g;
  }
  return null;
}
function K(e) {
  return be(e);
}
function T(e) {
  const t = e === null ? "null" : typeof e, r = j(e), n = Pe(e);
  if (e == null)
    return { kind: "empty", jsType: t, tag: r, ctor: n };
  if (typeof e == "string")
    return { kind: "string", jsType: t, tag: r, ctor: n, textLength: e.length };
  if (me(e))
    return {
      kind: `serialized:${typeof e.kind == "string" && e.kind ? e.kind : "bytes"}`,
      jsType: t,
      tag: r,
      ctor: n,
      base64Length: e.b64.length,
      mime: ue(e, "mime")
    };
  if (q(e))
    return {
      kind: "ArrayBuffer",
      jsType: t,
      tag: r,
      ctor: n,
      byteLength: e.byteLength
    };
  try {
    if (ArrayBuffer.isView(e)) {
      const s = e;
      return {
        kind: n ? `TypedArray:${n}` : "TypedArray",
        jsType: t,
        tag: r,
        ctor: n,
        byteLength: s.byteLength
      };
    }
  } catch {
  }
  if (Me(e))
    return {
      kind: "BlobLike",
      jsType: t,
      tag: r,
      ctor: n,
      byteLength: typeof e.size == "number" ? Number(e.size) : -1,
      mime: ue(e, "type")
    };
  const o = K(e);
  if (o)
    return {
      kind: "coerced-bytes",
      jsType: t,
      tag: r,
      ctor: n,
      byteLength: o.byteLength
    };
  if (_(e)) {
    const s = Object.keys(e);
    return {
      kind: "object",
      jsType: t,
      tag: r,
      ctor: n,
      keyCount: s.length,
      keys: s.slice(0, Ie)
    };
  }
  return { kind: "primitive", jsType: t, tag: r, ctor: n };
}
function qe(e) {
  if (e == null) return;
  if (typeof e == "string") return e;
  if (me(e)) {
    const r = U(e.b64);
    if ((typeof e.kind == "string" && e.kind ? e.kind : "bytes") === "blob") {
      const o = e.mime, s = r.buffer;
      return typeof o == "string" && o ? new Blob([s], { type: o }) : new Blob([s]);
    }
    return r;
  }
  const t = K(e);
  if (t)
    return t;
  if (_(e)) {
    const r = Ve(e);
    if (typeof r == "string") return r;
  }
  return String(e);
}
const Ye = "vot_gm_xhr", W = globalThis.browser, we = globalThis.chrome, h = W ?? we ?? null, We = !!W && h === W;
function Se() {
  const e = we?.runtime?.lastError ?? h?.runtime?.lastError;
  return e?.message ? String(e.message) : null;
}
async function D(e, t = [], r = {}) {
  if (typeof e != "function")
    throw new TypeError("WebExtension API is not available");
  const n = r.mapCbArgs, o = r.rejectOnLastError !== !1;
  return We ? await e(...t) : await new Promise((s, i) => {
    try {
      e(...t, (...c) => {
        const l = o ? Se() : null;
        l ? i(new Error(l)) : s(n ? n(...c) : c[0]);
      });
    } catch (c) {
      i(c);
    }
  });
}
async function Ge(e, t) {
  const r = h?.notifications, n = r?.create;
  !r || typeof n != "function" || await D(n.bind(r), [e, t], {
    mapCbArgs: () => {
    }
  });
}
async function Je(e) {
  const t = h?.notifications, r = t?.clear;
  !t || typeof r != "function" || await D(r.bind(t), [e], {
    mapCbArgs: () => {
    },
    rejectOnLastError: !1
  });
}
async function Ke(e, t) {
  const r = h?.windows, n = r?.update;
  !r || typeof n != "function" || await D(n.bind(r), [e, t], {
    mapCbArgs: () => {
    },
    rejectOnLastError: !1
  });
}
async function Qe(e, t) {
  const r = h?.tabs, n = r?.update;
  !r || typeof n != "function" || await D(n.bind(r), [e, t], {
    mapCbArgs: () => {
    },
    rejectOnLastError: !1
  });
}
const Ze = "api.browser.yandex.ru", et = /* @__PURE__ */ new Set([
  "sec-ch-ua",
  "sec-ch-ua-mobile",
  "sec-ch-ua-platform",
  "sec-ch-ua-full-version-list"
]), Te = [
  "sec-ch-ua-full-version",
  "sec-ch-ua-platform-version",
  "sec-ch-ua-arch",
  "sec-ch-ua-bitness",
  "sec-ch-ua-model",
  "sec-ch-ua-wow64"
], tt = new Set(Te);
function rt(e) {
  return String(e || "") === Ze;
}
function k(e) {
  return String(e || "").trim();
}
function nt(e) {
  const t = k(e).toLowerCase();
  return t ? !!(t === "origin" || t === "referer" || tt.has(t) || t.startsWith("sec-ch-ua") && !et.has(t)) : !1;
}
function ot(e) {
  const t = {};
  for (const [r, n] of Object.entries(e || {})) {
    const o = k(r);
    o && (nt(o) || (t[o] = String(n)));
  }
  return t;
}
const it = 512 * 1024, le = 9001, fe = 9002, de = 9003, X = /* @__PURE__ */ new Map();
let $ = Promise.resolve();
function Q() {
  return !!h?.declarativeNetRequest?.updateSessionRules;
}
function st(e) {
  const r = h?.declarativeNetRequest?.updateSessionRules;
  if (typeof r != "function")
    return Promise.resolve();
  try {
    const n = r({
      addRules: e.addRules || [],
      removeRuleIds: e.removeRuleIds || []
    });
    if (n && typeof n.then == "function")
      return n;
  } catch {
  }
  return new Promise((n, o) => {
    try {
      r(
        {
          addRules: e.addRules || [],
          removeRuleIds: e.removeRuleIds || []
        },
        () => {
          const s = Se();
          s ? o(new Error(s)) : n();
        }
      );
    } catch (s) {
      o(s);
    }
  });
}
function at(e) {
  const t = k(e).toLowerCase();
  return t ? !!(t.startsWith("sec-") || t.startsWith("proxy-") || t === "user-agent" || t === "origin" || t === "referer") : !1;
}
function Z(e) {
  const t = e.map(
    (r) => [
      `${k(String(r.header)).toLowerCase()}:${String(r.operation)}`,
      String("value" in r ? r.value : "")
    ]
  ).sort((r, n) => r[0].localeCompare(n[0]));
  return JSON.stringify(t);
}
function ee(e, t, r) {
  return t === X.get(e) ? Promise.resolve() : ($ = $.catch(() => {
  }).then(async () => {
    t !== X.get(e) && (await st({
      removeRuleIds: [e],
      addRules: [r]
    }), X.set(e, t));
  }), $);
}
async function ct(e, t) {
  if (!Q()) return;
  let r = "";
  try {
    r = new URL(e).hostname;
  } catch {
    return;
  }
  if (!rt(r)) return;
  const n = [
    // Must be absent in the known-good request capture.
    { header: "Origin", operation: "remove" },
    // Not present in the capture; remove if added by caller/stack.
    { header: "Referer", operation: "remove" },
    ...Te.map(
      (c) => ({ header: c, operation: "remove" })
    )
  ], o = ot(t);
  for (const [c, l] of Object.entries(o))
    n.push({
      header: k(c),
      operation: "set",
      value: String(l)
    });
  const s = Z(n);
  await ee(le, s, {
    id: le,
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: n
    },
    condition: {
      // Anchor at the URL start to avoid accidental matches.
      urlFilter: "|https://api.browser.yandex.ru/",
      // Extension-initiated fetch()/XHR can show up as "xmlhttprequest"
      // in Chromium.
      resourceTypes: ["xmlhttprequest"],
      // Only match requests not associated with a tab (service worker).
      tabIds: [-1]
    }
  });
}
function ut(e) {
  try {
    const t = new URL(e);
    return t.protocol === "https:" && t.hostname === "www.youtube.com" && t.pathname.startsWith("/youtubei/");
  } catch {
    return !1;
  }
}
function lt(e) {
  try {
    const t = new URL(e), r = t.hostname.toLowerCase();
    return t.protocol === "https:" && (r === "googlevideo.com" || r.endsWith(".googlevideo.com"));
  } catch {
    return !1;
  }
}
async function ft(e) {
  if (!Q() || !ut(e)) return;
  const t = [
    { header: "Origin", operation: "remove" },
    { header: "x-client-data", operation: "remove" },
    { header: "x-goog-visitor-id", operation: "remove" }
  ], r = JSON.stringify({
    v: 2,
    headers: Z(t)
  });
  await ee(fe, r, {
    id: fe,
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: t
    },
    condition: {
      urlFilter: "|https://www.youtube.com/youtubei/",
      resourceTypes: ["xmlhttprequest"],
      // Scope header mutations to service-worker initiated requests.
      tabIds: [-1]
    }
  });
}
async function dt(e) {
  if (!Q() || !lt(e)) return;
  const t = [
    { header: "x-client-data", operation: "remove" }
  ], r = JSON.stringify({
    v: 1,
    headers: Z(t)
  });
  await ee(
    de,
    r,
    {
      id: de,
      priority: 1,
      action: {
        type: "modifyHeaders",
        requestHeaders: t
      },
      condition: {
        urlFilter: "||googlevideo.com/",
        resourceTypes: ["xmlhttprequest"],
        // Scope header mutations to service-worker initiated requests.
        tabIds: [-1]
      }
    }
  );
}
function Ae(e) {
  if (e instanceof Error) return e.message;
  if (e && typeof e == "object")
    try {
      return JSON.stringify(e);
    } catch {
      return Object.prototype.toString.call(e);
    }
  try {
    return String(e);
  } catch {
    return "Unknown error";
  }
}
function yt(e) {
  return Array.from(e.entries()).map(([t, r]) => `${t}: ${r}`).join(`\r
`);
}
function pt(e) {
  const t = {};
  if (!e) return t;
  for (const [r, n] of Object.entries(e))
    n !== void 0 && (typeof n == "string" || typeof n == "number" || typeof n == "boolean") && (t[String(r)] = String(n));
  return t;
}
function ye(e, t) {
  return {
    finalUrl: e,
    readyState: 4,
    status: 0,
    statusText: "",
    responseHeaders: "",
    response: null,
    responseText: "",
    error: t
  };
}
function ht(e, t) {
  const r = t.toLowerCase();
  for (const [n, o] of Object.entries(e))
    if (String(n).toLowerCase() === r) return String(o);
}
function gt(e) {
  const t = String(e || "").toLowerCase();
  return t ? t.includes("application/x-protobuf") || t.includes("application/protobuf") || t.includes("application/octet-stream") : !1;
}
function mt(e) {
  const t = String(e || "");
  if (!t || /\s/.test(t) || !/^[A-Za-z0-9+/=_-]+$/.test(t) || !/[+/=_-]/.test(t)) return null;
  const r = t.replaceAll("-", "+").replaceAll("_", "/"), n = r.length % 4;
  if (n === 1) return null;
  const o = n === 0 ? r : `${r}${"=".repeat(4 - n)}`;
  try {
    return U(o);
  } catch {
    return null;
  }
}
function bt(e) {
  const t = String(e || ""), r = new Uint8Array(t.length);
  for (let n = 0; n < t.length; n += 1)
    r[n] = (t.codePointAt(n) ?? 0) & 255;
  return r;
}
function wt(e) {
  return /^\[object [^\]]+\]$/.test(String(e || "").trim());
}
let pe = 0;
h?.runtime?.onConnect?.addListener?.((e) => {
  if (!e || typeof e != "object") return;
  const t = e;
  if (t.name !== Ye || typeof t.onDisconnect?.addListener != "function" || typeof t.onMessage?.addListener != "function" || typeof t.postMessage != "function")
    return;
  const r = (g) => {
    t.postMessage?.(g);
  };
  pe += 1;
  const n = pe;
  let o = null, s = null, i = !1, c = !1;
  const l = () => {
    s !== null && (clearTimeout(s), s = null);
  };
  t.onDisconnect.addListener(() => {
    l();
    try {
      o?.abort();
    } catch {
    }
  }), t.onMessage.addListener(async (g) => {
    if (!g || typeof g != "object") return;
    if (g.type === "abort") {
      i = !0;
      try {
        o?.abort();
      } catch {
      }
      return;
    }
    if (g.type !== "start") return;
    const m = i && o === null;
    i = !1;
    const { details: a } = g, f = a.url, b = (a.method || "GET").toUpperCase(), x = pt(a.headers), te = {}, C = {};
    for (const [p, E] of Object.entries(x))
      at(p) ? C[p] = E : te[p] = E;
    const I = Number(a.timeout || 0), w = String(a.responseType || "text").toLowerCase();
    if (S.log("[VOT EXT][background][xhr] start", {
      xhrSessionId: n,
      state: "in_flight",
      url: f,
      method: b,
      responseType: w,
      timeoutMs: I,
      headerCount: Object.keys(x).length,
      headerNames: Object.keys(x),
      forbiddenHeaderNames: Object.keys(C),
      body: T(a.data)
    }), m) {
      const p = {
        finalUrl: f,
        readyState: 4,
        status: 0,
        statusText: "",
        responseHeaders: "",
        response: null,
        responseText: "",
        error: "Aborted"
      };
      try {
        r({ type: "abort", state: "terminal", error: p });
      } catch {
      }
      return;
    }
    c = !1, o = new AbortController(), I > 0 && (s = setTimeout(() => {
      c = !0;
      try {
        o?.abort();
      } catch {
      }
    }, I));
    let F = "include";
    (a.anonymous || a.withCredentials === !1) && (F = "omit");
    try {
      let p;
      a.nocache ? p = "no-store" : a.revalidate && (p = "no-cache");
      const E = a.redirect === "error" || a.redirect === "manual" ? a.redirect : "follow", v = b !== "GET" && b !== "HEAD";
      try {
        await dt(f), await ft(f), await ct(f, C);
      } catch (d) {
        console.warn(
          "[VOT Extension] Failed to apply DNR header rules; requests may break:",
          d
        );
      }
      let u = v ? qe(a.data) : void 0, O;
      const re = () => (O !== void 0 || (O = K(a.data)), O), ne = ht(x, "content-type"), H = gt(ne);
      if (S.log("[VOT EXT][background][xhr] body decoded", {
        xhrSessionId: n,
        url: f,
        method: b,
        contentType: ne ?? null,
        isProtobufRequest: H,
        sourceBody: T(a.data),
        decodedBody: T(u)
      }), v && H && u == null) {
        const d = re();
        d && (u = d, S.warn(
          "[VOT EXT][background][xhr] protobuf body recovered from raw payload",
          {
            xhrSessionId: n,
            url: f,
            method: b,
            recoveredBody: T(u)
          }
        ));
      }
      if (v && typeof u == "string" && H) {
        if (wt(u)) {
          const d = re();
          d && (u = d, S.warn(
            "[VOT EXT][background][xhr] recovered protobuf body from object-like string fallback",
            {
              xhrSessionId: n,
              url: f,
              method: b,
              sourceBody: T(a.data),
              recoveredBody: T(d)
            }
          ));
        }
        if (typeof u == "string") {
          const d = mt(u);
          u = d ?? bt(u), S.log(
            "[VOT EXT][background][xhr] protobuf string converted to bytes",
            {
              xhrSessionId: n,
              url: f,
              method: b,
              strategy: d ? "base64" : "latin1",
              convertedBody: T(u)
            }
          );
        }
      }
      S.log("[VOT EXT][background][xhr] fetch dispatch", {
        xhrSessionId: n,
        url: f,
        method: b,
        credentials: F,
        redirect: E,
        cache: p ?? "default",
        body: T(u)
      });
      const P = {
        method: b,
        headers: te,
        redirect: E,
        credentials: F,
        signal: o.signal
      };
      u !== void 0 && (P.body = u), p !== void 0 && (P.cache = p);
      const y = await fetch(f, P);
      S.log("[VOT EXT][background][xhr] fetch response received", {
        xhrSessionId: n,
        url: y.url || f,
        method: b,
        status: y.status,
        statusText: y.statusText,
        responseType: w,
        contentType: y.headers.get("content-type") || null,
        contentLength: y.headers.get("content-length") || null
      });
      const Be = yt(y.headers), oe = y.url || f, ie = y.headers.get("content-type") || "", se = (d) => ({
        finalUrl: oe,
        readyState: d,
        status: y.status,
        statusText: y.statusText,
        responseHeaders: Be
      }), Ee = w === "arraybuffer" || w === "blob" || w === "stream";
      let A, B, N;
      if (Ee) {
        const d = Number(y.headers.get("content-length") || 0);
        if (!!y.body && (!Number.isFinite(d) || d > it)) {
          let L = 0;
          const ae = Number.isFinite(d) ? d : 0, ve = y.body.getReader();
          for (; ; ) {
            const { done: Oe, value: M } = await ve.read();
            if (Oe) break;
            M && (L += M.byteLength, r({
              type: "progress",
              state: "in_flight",
              progress: {
                ...se(3),
                loaded: L,
                total: ae,
                lengthComputable: ae > 0,
                chunkB64: ge(M)
              }
            }));
          }
          A = void 0;
        } else {
          const L = await y.arrayBuffer();
          L.byteLength > 0 && (N = Ce(L)), A = void 0;
        }
      } else if (w === "json") {
        B = await y.text();
        try {
          A = JSON.parse(B);
        } catch {
          A = null;
        }
      } else
        B = await y.text(), A = B;
      l(), S.log("[VOT EXT][background][xhr] terminal", {
        xhrSessionId: n,
        state: "terminal",
        kind: "load",
        url: oe,
        status: y.status,
        responseType: w,
        responseBody: T(A),
        responseTextLength: B?.length ?? 0,
        responseB64Length: N?.length ?? 0
      }), r({
        type: "load",
        state: "terminal",
        response: {
          ...se(4),
          responseType: w,
          ...ie ? { contentType: ie } : {},
          ...N ? { responseB64: N } : {},
          response: A,
          ...typeof B == "string" ? { responseText: B } : {}
        }
      });
    } catch (p) {
      if (l(), i || c || p instanceof DOMException && p.name === "AbortError") {
        let u;
        c ? u = "timeout" : u = "abort";
        const O = ye(
          f,
          u === "timeout" ? "Timeout" : "Aborted"
        );
        try {
          r({ type: u, state: "terminal", error: O });
        } catch {
        }
        return;
      }
      const v = ye(f, Ae(p));
      r({
        type: "error",
        state: "terminal",
        error: v
      }), S.error("[VOT EXT][background][xhr] terminal", {
        xhrSessionId: n,
        state: "terminal",
        kind: "error",
        url: f,
        method: b,
        responseType: w,
        error: v.error
      });
    }
  });
});
function St(e) {
  return !e || typeof e != "object" ? !1 : e.type === "gm_notification";
}
function Tt(e) {
  const t = e && typeof e == "object" ? e : {}, r = Number(t.timeout ?? 0);
  return {
    title: t.title != null ? String(t.title) : "",
    text: t.text != null ? String(t.text) : "",
    silent: !!t.silent,
    timeout: Number.isFinite(r) && r > 0 ? r : 0
  };
}
function At(e) {
  const t = e.tab?.id, r = e.tab?.windowId, n = typeof t == "number" ? t : -1, o = typeof r == "number" ? r : -1, s = typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}:${Math.random().toString(36).slice(2)}`;
  return `vot:${n}:${o}:${s}`;
}
function Bt(e) {
  const t = typeof h?.runtime?.getBrowserInfo == "function", n = {
    type: "basic",
    iconUrl: h?.runtime?.getURL ? h.runtime.getURL("icons/icon-128.png") : "icons/icon-128.png",
    title: e.title || "VOT",
    message: e.text
  };
  return t || (n.silent = e.silent), n;
}
function he(e, t) {
  if (typeof e == "function")
    try {
      e(t);
    } catch {
    }
}
h?.runtime?.onMessage?.addListener?.(
  (e, t, r) => {
    if (!St(e)) return;
    const n = Tt(e.details), o = At(t), s = Bt(n);
    return (async () => {
      try {
        await Ge(o, s), n.timeout > 0 && setTimeout(() => {
          Je(o);
        }, n.timeout), he(r, { ok: !0 });
      } catch (i) {
        he(r, {
          ok: !1,
          error: Ae(i)
        });
      }
    })(), !0;
  }
);
h?.notifications?.onClicked?.addListener?.((e) => {
  if (!e.startsWith("vot:")) return;
  const t = e.split(":");
  if (t.length < 3) return;
  const r = Number(t[1]), n = Number(t[2]);
  Number.isFinite(n) && n >= 0 && Ke(n, { focused: !0 }), Number.isFinite(r) && r >= 0 && Qe(r, { active: !0 });
});
export {
  At as createBridgeNotificationId,
  Bt as createBridgeNotificationOptions,
  St as isGmNotificationMessage,
  Tt as normalizeGmNotificationDetails
};
