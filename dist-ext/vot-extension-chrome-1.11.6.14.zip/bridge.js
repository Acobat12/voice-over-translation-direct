(function() {
	//#region src/utils/debug.ts
	var log = (...text) => {
		console.log("%c[VOT DEBUG]", "background: #3700ffff; color: #fff; padding: 5px;", ...text);
	};
	var warn = (...text) => {
		console.warn("%c[VOT DEBUG]", "background: #e1ff00ff; color: #fff; padding: 5px;", ...text);
	};
	var error = (...text) => {
		console.error("%c[VOT DEBUG]", "background: #F2452D; color: #fff; padding: 5px;", ...text);
	};
	var debug = {
		log,
		warn,
		error
	};
	//#endregion
	//#region src/utils/errors.ts
	/**
	* Small error helpers used across the project.
	*/
	function stringifyUnknownObject(value) {
		const seen = /* @__PURE__ */ new WeakSet();
		try {
			return JSON.stringify(value, (_key, currentValue) => {
				if (typeof currentValue !== "object" || currentValue === null) return currentValue;
				if (seen.has(currentValue)) return "[Circular]";
				seen.add(currentValue);
				return currentValue;
			}) ?? null;
		} catch {
			return null;
		}
	}
	function toErrorMessage(error, fallback = "Unknown error") {
		if (error instanceof Error) return error.message || fallback;
		if (typeof error === "string") return error || fallback;
		if (error === null || error === void 0) return fallback;
		if (typeof error === "object") {
			const anyErr = error;
			if (typeof anyErr?.data?.message === "string" && anyErr.data.message) return anyErr.data.message;
			if (typeof anyErr?.error?.message === "string" && anyErr.error.message) return anyErr.error.message;
			if (typeof anyErr?.message === "string" && anyErr.message) return anyErr.message;
			const serialized = stringifyUnknownObject(error);
			if (serialized && serialized !== "{}") return serialized;
			const ctorName = error.constructor?.name;
			return ctorName ? `[${ctorName}]` : fallback;
		}
		if (typeof error === "number" || typeof error === "boolean" || typeof error === "bigint") return `${error}`;
		if (typeof error === "symbol") return error.description ? `Symbol(${error.description})` : "Symbol";
		if (typeof error === "function") return error.name ? `[Function ${error.name}]` : "[Function]";
		return fallback;
	}
	//#endregion
	//#region src/extension/base64.ts
	var BASE64URL_DECODE_OPTIONS = { alphabet: "base64url" };
	var nativeToBase64 = typeof Uint8Array.prototype.toBase64 === "function" ? Uint8Array.prototype.toBase64 : null;
	var nativeFromBase64 = Uint8Array.fromBase64;
	function normalizeBase64Input(input) {
		const withoutWhitespace = String(input).replaceAll(/\s+/g, "");
		const remainder = withoutWhitespace.length % 4;
		if (remainder === 1) throw new TypeError("Invalid base64 input.");
		if (remainder === 0) return withoutWhitespace;
		return withoutWhitespace + "=".repeat(4 - remainder);
	}
	function bytesToBinaryString(bytes) {
		let binary = "";
		for (const byte of bytes) binary += String.fromCharCode(byte);
		return binary;
	}
	function decodeWithLegacyBase64Normalized(normalizedBase64) {
		const atobFn = globalThis.atob;
		if (typeof atobFn !== "function") throw new TypeError("Base64 decoder is not available in this environment.");
		const binary = atobFn(normalizedBase64);
		const out = new Uint8Array(binary.length);
		for (let i = 0; i < binary.length; i += 1) out[i] = binary.charCodeAt(i);
		return out;
	}
	function encodeWithLegacyBase64(bytes) {
		const btoaFn = globalThis.btoa;
		if (typeof btoaFn !== "function") throw new TypeError("Base64 encoder is not available in this environment.");
		return btoaFn(bytesToBinaryString(bytes));
	}
	function decodeBase64ToBytes(input) {
		const normalized = normalizeBase64Input(input);
		const normalizedStandard = normalized.replaceAll("-", "+").replaceAll("_", "/");
		if (typeof nativeFromBase64 !== "function") return decodeWithLegacyBase64Normalized(normalizedStandard);
		const hasUrlAlphabet = normalized.includes("-") || normalized.includes("_");
		const hasStandardAlphabet = normalized.includes("+") || normalized.includes("/");
		if (hasUrlAlphabet && !hasStandardAlphabet) return nativeFromBase64(normalized, BASE64URL_DECODE_OPTIONS);
		return nativeFromBase64(hasUrlAlphabet && hasStandardAlphabet ? normalizedStandard : normalized);
	}
	function bytesViewToArrayBuffer(bytes) {
		const { buffer, byteOffset, byteLength } = bytes;
		if (buffer instanceof ArrayBuffer) {
			if (byteOffset === 0 && byteLength === buffer.byteLength) return buffer;
			return buffer.slice(byteOffset, byteOffset + byteLength);
		}
		const out = new ArrayBuffer(byteLength);
		new Uint8Array(out).set(bytes);
		return out;
	}
	function bytesToBase64(bytes) {
		if (typeof nativeToBase64 === "function") return nativeToBase64.call(bytes);
		return encodeWithLegacyBase64(bytes);
	}
	function base64ToBytes(b64) {
		return decodeBase64ToBytes(b64);
	}
	function base64ToArrayBuffer(b64) {
		return bytesViewToArrayBuffer(base64ToBytes(b64));
	}
	//#endregion
	//#region src/extension/bodySerialization.ts
	var MAX_RECOVERABLE_BYTES = 1e7;
	var DEBUG_KEYS_LIMIT = 12;
	var MAX_COERCE_DEPTH = 2;
	function isObjectLike(v) {
		return v !== null && typeof v === "object";
	}
	function isPlainObject(v) {
		return safeObjectTag(v) === "[object Object]";
	}
	function safeObjectTag(v) {
		try {
			return Object.prototype.toString.call(v);
		} catch {
			return null;
		}
	}
	function isArrayBufferLike(v) {
		return safeObjectTag(v) === "[object ArrayBuffer]";
	}
	function safeConstructorName(v) {
		try {
			const ctorName = v?.constructor?.name;
			return typeof ctorName === "string" ? ctorName : null;
		} catch {
			return null;
		}
	}
	function safeStringProp(obj, key) {
		try {
			const value = obj?.[key];
			return typeof value === "string" ? value : null;
		} catch {
			return null;
		}
	}
	function isBlobLike(v) {
		if (safeObjectTag(v) === "[object Blob]") return true;
		if (!v || typeof v !== "object") return false;
		try {
			const anyVal = v;
			const hasBuffer = typeof anyVal.arrayBuffer === "function";
			const hasSlice = typeof anyVal.slice === "function";
			const hasSize = typeof anyVal.size === "number";
			const hasType = typeof anyVal.type === "string";
			return (hasBuffer || hasSlice) && hasSize && hasType;
		} catch {
			return false;
		}
	}
	function safeJsonStringify(value) {
		try {
			return JSON.stringify(value);
		} catch {
			return null;
		}
	}
	function toSafeLength(value) {
		if (typeof value !== "number" || !Number.isFinite(value)) return null;
		const n = Math.trunc(value);
		if (n < 0 || n > MAX_RECOVERABLE_BYTES) return null;
		return n;
	}
	function toByte(value) {
		if (typeof value !== "number" || !Number.isFinite(value)) return null;
		return Math.trunc(value) & 255;
	}
	function toUint8FromNumericArray(values) {
		const len = values.length;
		if (len > MAX_RECOVERABLE_BYTES) return null;
		const out = new Uint8Array(len);
		for (let i = 0; i < len; i += 1) {
			const byte = toByte(values[i]);
			if (byte === null) return null;
			out[i] = byte;
		}
		return out;
	}
	function viewAsBytes(view) {
		return new Uint8Array(view.buffer, view.byteOffset, view.byteLength);
	}
	function copyArrayBufferView(view) {
		return viewAsBytes(view).slice();
	}
	function parseNonNegativeIntegerKey(key) {
		if (key === "") return null;
		const n = Number(key);
		if (!Number.isFinite(n) || !Number.isInteger(n) || n < 0) return null;
		return n;
	}
	function isSerializedBodyEnvelope(v) {
		if (!isObjectLike(v)) return false;
		const envelope = v;
		return envelope.__votExtBody === true && typeof envelope.b64 === "string";
	}
	function isBodySerializedForPort(body) {
		if (body === null || body === void 0) return true;
		if (typeof body === "string") return true;
		return isSerializedBodyEnvelope(body);
	}
	function createSerializedBytes(bytes) {
		return {
			__votExtBody: true,
			kind: "bytes",
			b64: bytesToBase64(bytes)
		};
	}
	function createSerializedBlob(bytes, mime) {
		return {
			__votExtBody: true,
			kind: "blob",
			b64: bytesToBase64(bytes),
			mime
		};
	}
	async function tryReadBlobBody(body) {
		if (!isObjectLike(body)) return null;
		try {
			const anyBody = body;
			if (typeof anyBody.arrayBuffer === "function") return {
				ab: await anyBody.arrayBuffer(),
				mime: safeStringProp(anyBody, "type")
			};
		} catch {}
		if (typeof Response !== "undefined") try {
			return {
				ab: await new Response(body).arrayBuffer(),
				mime: safeStringProp(body, "type")
			};
		} catch {}
		if (typeof Blob !== "undefined" && isBlobLike(body)) try {
			return {
				ab: await body.arrayBuffer(),
				mime: safeStringProp(body, "type")
			};
		} catch {}
		return null;
	}
	function tryCoerceByteLikeObjectToUint8Array(v, depth = 0) {
		if (depth > MAX_COERCE_DEPTH) return null;
		if (!isObjectLike(v)) return null;
		const obj = v;
		if (isArrayBufferLike(v)) return new Uint8Array(v);
		try {
			if (ArrayBuffer.isView(v)) return copyArrayBufferView(v);
		} catch {}
		if (Array.isArray(v)) return toUint8FromNumericArray(v);
		if (obj.type === "Buffer" && Array.isArray(obj.data)) {
			const fromBufferJson = toUint8FromNumericArray(obj.data);
			if (fromBufferJson) return fromBufferJson;
		}
		if (Array.isArray(obj.data)) {
			const fromData = toUint8FromNumericArray(obj.data);
			if (fromData) return fromData;
		}
		if (Array.isArray(obj.bytes)) {
			const fromBytes = toUint8FromNumericArray(obj.bytes);
			if (fromBytes) return fromBytes;
		}
		if (typeof obj.b64 === "string") try {
			return base64ToBytes(obj.b64);
		} catch {}
		if (typeof obj.base64 === "string") try {
			return base64ToBytes(obj.base64);
		} catch {}
		const byteLength = toSafeLength(obj.byteLength);
		const byteOffset = toSafeLength(obj.byteOffset ?? 0);
		if (byteLength !== null && byteOffset !== null) {
			const rawBuffer = obj.buffer;
			if (isArrayBufferLike(rawBuffer)) try {
				return new Uint8Array(rawBuffer, byteOffset, byteLength).slice();
			} catch {}
			if (rawBuffer && rawBuffer !== v) {
				const recoveredBuffer = tryCoerceByteLikeObjectToUint8Array(rawBuffer, depth + 1);
				if (recoveredBuffer) {
					if (byteOffset > recoveredBuffer.byteLength) return null;
					const end = Math.min(recoveredBuffer.byteLength, byteOffset + byteLength);
					return recoveredBuffer.slice(byteOffset, end);
				}
			}
		}
		const length = toSafeLength(obj.length);
		if (length !== null) {
			const indexed = obj;
			const out = new Uint8Array(length);
			for (let i = 0; i < length; i += 1) {
				const byte = toByte(indexed[i]);
				if (byte === null) return null;
				out[i] = byte;
			}
			return out;
		}
		if (isPlainObject(v)) {
			const keys = Object.keys(obj);
			if (!keys.length) return null;
			const indexes = new Array(keys.length);
			let max = -1;
			for (let i = 0; i < keys.length; i += 1) {
				const idx = parseNonNegativeIntegerKey(keys[i]);
				if (idx === null || idx > MAX_RECOVERABLE_BYTES) return null;
				indexes[i] = idx;
				if (idx > max) max = idx;
			}
			const out = new Uint8Array(max + 1);
			for (let i = 0; i < keys.length; i += 1) {
				const key = keys[i];
				const byte = toByte(obj[key]);
				if (byte === null) return null;
				out[indexes[i]] = byte;
			}
			return out;
		}
		return null;
	}
	function coerceBodyToBytes(body) {
		return tryCoerceByteLikeObjectToUint8Array(body);
	}
	function summarizeBodyForDebug(body) {
		const jsType = body === null ? "null" : typeof body;
		const tag = safeObjectTag(body);
		const ctor = safeConstructorName(body);
		if (body === null || body === void 0) return {
			kind: "empty",
			jsType,
			tag,
			ctor
		};
		if (typeof body === "string") return {
			kind: "string",
			jsType,
			tag,
			ctor,
			textLength: body.length
		};
		if (isSerializedBodyEnvelope(body)) return {
			kind: `serialized:${typeof body.kind === "string" && body.kind ? body.kind : "bytes"}`,
			jsType,
			tag,
			ctor,
			base64Length: body.b64.length,
			mime: safeStringProp(body, "mime")
		};
		if (isArrayBufferLike(body)) return {
			kind: "ArrayBuffer",
			jsType,
			tag,
			ctor,
			byteLength: body.byteLength
		};
		try {
			if (ArrayBuffer.isView(body)) {
				const view = body;
				return {
					kind: ctor ? `TypedArray:${ctor}` : "TypedArray",
					jsType,
					tag,
					ctor,
					byteLength: view.byteLength
				};
			}
		} catch {}
		if (isBlobLike(body)) return {
			kind: "BlobLike",
			jsType,
			tag,
			ctor,
			byteLength: typeof body.size === "number" ? Number(body.size) : -1,
			mime: safeStringProp(body, "type")
		};
		const coerced = coerceBodyToBytes(body);
		if (coerced) return {
			kind: "coerced-bytes",
			jsType,
			tag,
			ctor,
			byteLength: coerced.byteLength
		};
		if (isObjectLike(body)) {
			const keys = Object.keys(body);
			return {
				kind: "object",
				jsType,
				tag,
				ctor,
				keyCount: keys.length,
				keys: keys.slice(0, DEBUG_KEYS_LIMIT)
			};
		}
		return {
			kind: "primitive",
			jsType,
			tag,
			ctor
		};
	}
	/**
	* Serialize a GM_xmlhttpRequest body so it can be transported over
	* `postMessage` / extension messaging.
	*/
	async function serializeBodyForPort(body) {
		if (body === null || body === void 0) return body;
		if (typeof body === "string") return body;
		if (isSerializedBodyEnvelope(body)) {
			if (body.kind === "blob") return {
				__votExtBody: true,
				kind: "blob",
				b64: body.b64,
				mime: safeStringProp(body, "mime")
			};
			return {
				__votExtBody: true,
				kind: "bytes",
				b64: body.b64
			};
		}
		if (isArrayBufferLike(body)) return createSerializedBytes(new Uint8Array(body));
		try {
			if (ArrayBuffer.isView(body)) return createSerializedBytes(viewAsBytes(body));
		} catch {}
		const blobData = await tryReadBlobBody(body);
		if (blobData) return createSerializedBlob(new Uint8Array(blobData.ab), blobData.mime);
		const recovered = coerceBodyToBytes(body);
		if (recovered) return createSerializedBytes(recovered);
		const summary = summarizeBodyForDebug(body);
		try {
			console.warn("[VOT Extension] Unsupported GM_xmlhttpRequest body type; coercing fallback.", summary);
		} catch {}
		if (isObjectLike(body)) {
			const json = safeJsonStringify(body);
			if (typeof json === "string") return json;
		}
		return String(body);
	}
	//#endregion
	//#region src/extension/constants.ts
	var MARK = "__VOT_EXT_BRIDGE__";
	var TYPE_REQ = "VOT_EXT_REQ";
	var TYPE_RES = "VOT_EXT_RES";
	var TYPE_XHR_START = "VOT_EXT_XHR_START";
	var TYPE_XHR_ABORT = "VOT_EXT_XHR_ABORT";
	var TYPE_XHR_ACK = "VOT_EXT_XHR_ACK";
	var TYPE_XHR_EVENT = "VOT_EXT_XHR_EVENT";
	var TYPE_NOTIFY = "VOT_EXT_NOTIFY";
	var PORT_NAME = "vot_gm_xhr";
	var BRIDGE_MESSAGE_TYPES = /* @__PURE__ */ new Set([
		TYPE_REQ,
		TYPE_RES,
		TYPE_NOTIFY,
		TYPE_XHR_START,
		TYPE_XHR_ABORT,
		TYPE_XHR_ACK,
		TYPE_XHR_EVENT
	]);
	function isOurMessage(data) {
		return Boolean(data && typeof data === "object" && data["__VOT_EXT_BRIDGE__"] === true && typeof data.type === "string" && BRIDGE_MESSAGE_TYPES.has(data.type));
	}
	//#endregion
	//#region src/extension/bridgeTransport.ts
	function isArrayBuffer(value) {
		return typeof ArrayBuffer !== "undefined" && value instanceof ArrayBuffer;
	}
	function getTransferables(payload) {
		if (payload.type !== "VOT_EXT_XHR_EVENT") return [];
		const eventPayload = payload.payload;
		const progressChunk = eventPayload?.progress?.chunk;
		const responseBody = eventPayload?.response?.response;
		if (!isArrayBuffer(progressChunk)) return isArrayBuffer(responseBody) ? [responseBody] : [];
		if (!isArrayBuffer(responseBody) || responseBody === progressChunk) return [progressChunk];
		return [progressChunk, responseBody];
	}
	function markMessage(payload) {
		return {
			...payload,
			[MARK]: true
		};
	}
	function toPageMessage(payload) {
		return {
			message: markMessage(payload),
			transfer: getTransferables(payload)
		};
	}
	//#endregion
	//#region src/extension/webext.ts
	var browserNamespace = globalThis.browser;
	var chromeNamespace = globalThis.chrome;
	var ext = browserNamespace ?? chromeNamespace ?? null;
	var isBrowserNamespace = !!browserNamespace && ext === browserNamespace;
	function lastErrorMessage() {
		const err = chromeNamespace?.runtime?.lastError ?? ext?.runtime?.lastError;
		return err?.message ? String(err.message) : null;
	}
	async function callAsync(fn, args = [], opts = {}) {
		if (typeof fn !== "function") throw new TypeError("WebExtension API is not available");
		const mapCbArgs = opts.mapCbArgs;
		const rejectOnLastError = opts.rejectOnLastError !== false;
		if (isBrowserNamespace) return await fn(...args);
		return await new Promise((resolve, reject) => {
			try {
				fn(...args, (...cbArgs) => {
					const err = rejectOnLastError ? lastErrorMessage() : null;
					if (err) reject(new Error(err));
					else resolve(mapCbArgs ? mapCbArgs(...cbArgs) : cbArgs[0]);
				});
			} catch (e) {
				reject(e);
			}
		});
	}
	async function storageGet(keys) {
		const area = ext?.storage?.local;
		return await callAsync(area?.get?.bind(area), [keys]);
	}
	async function storageSet(items) {
		const area = ext?.storage?.local;
		await callAsync(area?.set?.bind(area), [items], { mapCbArgs: () => void 0 });
	}
	async function storageRemove(keys) {
		const area = ext?.storage?.local;
		await callAsync(area?.remove?.bind(area), [keys], { mapCbArgs: () => void 0 });
	}
	//#endregion
	//#region src/extension/yandexHeaders.ts
	var YANDEX_API_HOST = "api.browser.yandex.ru";
	var ALLOWED_UA_CH_HEADERS = /* @__PURE__ */ new Set([
		"sec-ch-ua",
		"sec-ch-ua-mobile",
		"sec-ch-ua-platform",
		"sec-ch-ua-full-version-list"
	]);
	var SUPPRESSED_UA_CH_HEADERS_SET = /* @__PURE__ */ new Set([
		"sec-ch-ua-full-version",
		"sec-ch-ua-platform-version",
		"sec-ch-ua-arch",
		"sec-ch-ua-bitness",
		"sec-ch-ua-model",
		"sec-ch-ua-wow64"
	]);
	function isYandexApiHostname(hostname) {
		return String(hostname || "") === YANDEX_API_HOST;
	}
	function normalizeHeaderName(name) {
		return String(name || "").trim();
	}
	function shouldStripYandexHeader(name) {
		const normalized = normalizeHeaderName(name).toLowerCase();
		if (!normalized) return false;
		if (normalized === "origin" || normalized === "referer") return true;
		if (SUPPRESSED_UA_CH_HEADERS_SET.has(normalized)) return true;
		if (normalized.startsWith("sec-ch-ua") && !ALLOWED_UA_CH_HEADERS.has(normalized)) return true;
		return false;
	}
	//#endregion
	//#region src/extension/bridge.ts
	var BRIDGE_BOOT_KEY = "__VOT_EXT_BRIDGE_BOOTED__";
	function injectPageModule(fileName) {
		const parent = document.head ?? document.documentElement;
		if (!parent) {
			console.error("[VOT Extension] bridge: missing document root");
			return;
		}
		const script = document.createElement("script");
		script.type = "module";
		script.src = ext.runtime?.getURL(fileName);
		script.addEventListener("error", () => {
			console.error(`[VOT Extension] bridge: failed to inject ${fileName}`);
		}, { once: true });
		parent.appendChild(script);
	}
	var UA_CH_CACHE_TTL_MS = 600 * 1e3;
	var UA_CH_HIGH_ENTROPY_HINTS = ["fullVersionList"];
	var TERMINAL_XHR_EVENT_TYPES = /* @__PURE__ */ new Set([
		"load",
		"error",
		"timeout",
		"abort"
	]);
	var cachedUaChHeaders = Object.freeze({});
	var cachedUaChHeadersExpiresAt = 0;
	var cachedUaChHeadersPromise = null;
	var ESCAPED_DOUBLE_QUOTE = String.raw`\"`;
	function escapeHeaderValue(value) {
		return value.replaceAll("\"", ESCAPED_DOUBLE_QUOTE);
	}
	function formatUaBrands(brands) {
		return brands.filter((b) => b && typeof b.brand === "string" && typeof b.version === "string").map((b) => `"${escapeHeaderValue(b.brand)}";v="${escapeHeaderValue(b.version)}"`).join(", ");
	}
	/**
	* Return the minimal UA-CH header set required by the valid request capture.
	*
	* Important: do NOT include other high-entropy UA-CH headers (arch/bitness/
	* platform-version/full-version/model). Those extra headers were present in
	* the invalid request capture and must not be emitted.
	*/
	async function getUaChHeaders() {
		const uaData = navigator?.userAgentData;
		if (!uaData) return {};
		const headers = {};
		const brands = Array.isArray(uaData.brands) && uaData.brands || Array.isArray(uaData.uaList) && uaData.uaList || [];
		if (brands.length) headers["sec-ch-ua"] = formatUaBrands(brands);
		if (typeof uaData.mobile === "boolean") headers["sec-ch-ua-mobile"] = uaData.mobile ? "?1" : "?0";
		if (typeof uaData.platform === "string" && uaData.platform) headers["sec-ch-ua-platform"] = `"${escapeHeaderValue(uaData.platform)}"`;
		try {
			const high = await uaData.getHighEntropyValues?.(UA_CH_HIGH_ENTROPY_HINTS);
			if (Array.isArray(high?.fullVersionList) && high.fullVersionList.length) headers["sec-ch-ua-full-version-list"] = formatUaBrands(high.fullVersionList);
		} catch {}
		return headers;
	}
	function freezeHeaders(headers) {
		return Object.freeze({ ...headers });
	}
	async function getCachedUaChHeaders() {
		if (Date.now() < cachedUaChHeadersExpiresAt) return cachedUaChHeaders;
		if (cachedUaChHeadersPromise !== null) return await cachedUaChHeadersPromise;
		cachedUaChHeadersPromise = (async () => {
			const headers = freezeHeaders(await getUaChHeaders());
			cachedUaChHeaders = headers;
			cachedUaChHeadersExpiresAt = Date.now() + UA_CH_CACHE_TTL_MS;
			return headers;
		})();
		try {
			return await cachedUaChHeadersPromise;
		} finally {
			cachedUaChHeadersPromise = null;
		}
	}
	function ensureHeadersObject(details) {
		const raw = details?.headers;
		if (!raw || typeof raw !== "object") {
			const headers = {};
			details.headers = headers;
			return headers;
		}
		const headers = raw;
		for (const [name, value] of Object.entries(headers)) {
			if (typeof value === "string") continue;
			if (typeof value === "number" || typeof value === "boolean") {
				headers[name] = String(value);
				continue;
			}
			delete headers[name];
		}
		details.headers = headers;
		return headers;
	}
	function stripYandexHeaders(headers) {
		for (const headerName of Object.keys(headers)) if (shouldStripYandexHeader(headerName)) delete headers[headerName];
	}
	function mergeHeadersIfMissing(headers, additions) {
		const existingNames = /* @__PURE__ */ new Set();
		for (const name of Object.keys(headers)) existingNames.add(name.toLowerCase());
		for (const [name, value] of Object.entries(additions)) {
			if (!value) continue;
			const normalizedName = name.toLowerCase();
			if (existingNames.has(normalizedName)) continue;
			headers[name] = value;
			existingNames.add(normalizedName);
		}
	}
	function getHostname(url) {
		if (!url) return "";
		try {
			return new URL(url).hostname;
		} catch {
			return "";
		}
	}
	function postToPage(payload) {
		const { message, transfer } = toPageMessage(payload);
		if (transfer.length) {
			globalThis.postMessage(message, "*", transfer);
			return;
		}
		globalThis.postMessage(message, "*");
	}
	var xhrPorts = /* @__PURE__ */ new Map();
	function disconnectPortSafely(port) {
		try {
			port.disconnect();
		} catch {}
	}
	function settleXhrPort(requestId, state) {
		state.settled = true;
		disconnectPortSafely(state.port);
		xhrPorts.delete(requestId);
	}
	function isRequestStateActive(requestId, expectedState) {
		const currentState = xhrPorts.get(requestId);
		return currentState === expectedState && !currentState.settled;
	}
	function toLifecycleState(kind) {
		return kind === "progress" ? "in_flight" : "terminal";
	}
	function postXhrEvent(requestId, payload) {
		const kind = String(payload?.type ?? "");
		postToPage({
			type: TYPE_XHR_EVENT,
			requestId,
			payload: {
				...payload,
				state: toLifecycleState(kind)
			}
		});
	}
	function makeBridgeXhrError(details, error) {
		return {
			finalUrl: String(details?.url || ""),
			readyState: 4,
			status: 0,
			statusText: "",
			responseHeaders: "",
			response: null,
			responseText: "",
			error
		};
	}
	function concatArrayBuffers(chunks, totalBytes) {
		const out = new Uint8Array(totalBytes);
		let offset = 0;
		for (const ab of chunks) {
			const u8 = new Uint8Array(ab);
			out.set(u8, offset);
			offset += u8.byteLength;
		}
		return out.buffer;
	}
	function resolveBinaryResponseBuffer(directResponse, chunks, totalBytes, fallbackB64) {
		if (directResponse instanceof ArrayBuffer) return directResponse;
		if (totalBytes > 0) return concatArrayBuffers(chunks, totalBytes);
		if (typeof fallbackB64 === "string" && fallbackB64.length > 0) return base64ToArrayBuffer(fallbackB64);
		return /* @__PURE__ */ new ArrayBuffer(0);
	}
	async function startXhr(requestId, details) {
		const normalizedRequestId = String(requestId || "");
		const safeDetails = details ?? {};
		try {
			if (!normalizedRequestId) throw new Error("Missing requestId for bridge XHR");
			requestId = normalizedRequestId;
			if (xhrPorts.has(requestId)) {
				debug.warn("[VOT EXT][bridge] replacing active XHR request", { requestId });
				abortXhr(requestId);
			}
			debug.log("[VOT EXT][bridge] startXhr", {
				requestId,
				url: safeDetails?.url,
				method: safeDetails?.method,
				responseType: safeDetails?.responseType,
				timeoutMs: Number(safeDetails?.timeout ?? 0),
				headerCount: safeDetails?.headers && typeof safeDetails.headers === "object" ? Object.keys(safeDetails.headers).length : 0,
				body: summarizeBodyForDebug(safeDetails?.data)
			});
			const connected = ext?.runtime?.connect?.({ name: PORT_NAME });
			if (!connected || typeof connected !== "object") throw new Error("Bridge port is not available");
			const port = connected;
			const responseType = String(safeDetails?.responseType || "text").toLowerCase();
			const state = {
				port,
				responseType,
				chunks: [],
				totalBytes: 0,
				settled: false
			};
			xhrPorts.set(requestId, state);
			postToPage({
				type: TYPE_XHR_ACK,
				requestId,
				payload: {
					state: "acknowledged",
					timeoutMs: Number(safeDetails?.timeout ?? 0),
					responseType,
					ts: Date.now()
				}
			});
			port.onMessage.addListener((msg) => {
				const st = xhrPorts.get(requestId);
				if (!st || st.settled) return;
				if (!msg || typeof msg !== "object") return;
				debug.log("[VOT EXT][bridge] port message", {
					requestId,
					kind: msg.type ?? "unknown",
					state: msg.state ?? null,
					status: msg.response?.status ?? msg.error?.status ?? msg.progress?.status ?? null,
					loaded: msg.progress?.loaded ?? null,
					total: msg.progress?.total ?? null
				});
				if (msg.type === "progress" && msg.progress) {
					const b64 = msg.progress.chunkB64;
					if (typeof b64 === "string" && b64.length) {
						const ab = base64ToArrayBuffer(b64);
						const aggregateCopy = ab.slice(0);
						st.chunks.push(aggregateCopy);
						st.totalBytes += aggregateCopy.byteLength;
						msg.progress.chunk = ab;
						delete msg.progress.chunkB64;
					}
				}
				if (msg.type === "load" && msg.response) {
					const rt = String(msg.response.responseType || st.responseType || "text").toLowerCase();
					if (rt === "arraybuffer" || rt === "blob") {
						const directResponse = msg.response.response;
						const fallbackB64 = msg.response.responseB64;
						const ab = resolveBinaryResponseBuffer(directResponse, st.chunks, st.totalBytes, fallbackB64);
						delete msg.response.responseB64;
						st.chunks.length = 0;
						st.totalBytes = 0;
						if (rt === "blob") {
							const ct = msg.response.contentType || msg.response.mime || void 0;
							msg.response.response = ct ? new Blob([ab], { type: String(ct) }) : new Blob([ab]);
						} else msg.response.response = ab;
					}
				}
				postXhrEvent(requestId, msg);
				if (TERMINAL_XHR_EVENT_TYPES.has(String(msg.type ?? ""))) {
					debug.log("[VOT EXT][bridge] terminal event", {
						requestId,
						kind: msg.type,
						status: msg.response?.status ?? msg.error?.status ?? null
					});
					settleXhrPort(requestId, st);
				}
			});
			port.onDisconnect.addListener(() => {
				const st = xhrPorts.get(requestId);
				if (!st || st.settled) return;
				debug.warn("[VOT EXT][bridge] port disconnected before terminal event", {
					requestId,
					url: safeDetails?.url ?? null
				});
				settleXhrPort(requestId, st);
				postXhrEvent(requestId, {
					type: "error",
					error: makeBridgeXhrError(safeDetails, "Bridge port disconnected before response")
				});
			});
			const urlStr = String(safeDetails?.url ?? "");
			if (isYandexApiHostname(getHostname(urlStr))) {
				const headers = ensureHeadersObject(safeDetails);
				stripYandexHeaders(headers);
				const uaCh = await getCachedUaChHeaders();
				if (!isRequestStateActive(requestId, state)) return;
				mergeHeadersIfMissing(headers, uaCh);
				debug.log("[VOT EXT][bridge] yandex header normalization", {
					requestId,
					url: urlStr,
					headerCount: Object.keys(headers).length,
					headerNames: Object.keys(headers)
				});
			}
			if (!isRequestStateActive(requestId, state)) return;
			const data = isBodySerializedForPort(safeDetails?.data) ? safeDetails.data : await serializeBodyForPort(safeDetails?.data);
			const serializedBodySummary = summarizeBodyForDebug(data);
			debug.log("[VOT EXT][bridge] serialized body", {
				requestId,
				url: safeDetails?.url ?? null,
				from: summarizeBodyForDebug(safeDetails?.data),
				to: serializedBodySummary
			});
			if (!isRequestStateActive(requestId, state)) return;
			const serializedDetails = {
				...safeDetails,
				data,
				responseType: safeDetails?.responseType
			};
			debug.log("[VOT EXT][bridge] post start to background", {
				requestId,
				url: serializedDetails.url,
				method: serializedDetails.method,
				responseType: serializedDetails.responseType,
				body: serializedBodySummary
			});
			state.port.postMessage({
				type: "start",
				details: serializedDetails
			});
		} catch (error) {
			const requestKey = normalizedRequestId || requestId;
			const st = xhrPorts.get(requestKey);
			if (st && !st.settled) settleXhrPort(requestKey, st);
			const errorMessage = toErrorMessage(error);
			debug.log("[VOT EXT][bridge] startXhr error", {
				requestId: requestKey,
				error: errorMessage,
				lastError: ext?.runtime?.lastError ?? null
			});
			if (requestKey) postXhrEvent(requestKey, {
				type: "error",
				error: makeBridgeXhrError(safeDetails, errorMessage)
			});
		}
	}
	function abortXhr(requestId) {
		const st = xhrPorts.get(requestId);
		if (!st || st.settled) return;
		st.settled = true;
		debug.warn("[VOT EXT][bridge] abortXhr", { requestId });
		try {
			st.port.postMessage({ type: "abort" });
		} catch {}
		disconnectPortSafely(st.port);
		xhrPorts.delete(requestId);
	}
	async function handleRequest(action, payload) {
		switch (action) {
			case "handshake": return {
				manifest: ext?.runtime?.getManifest?.() ?? {},
				id: ext?.runtime?.id ?? null
			};
			case "gm_getValue": {
				const key = String(payload?.key ?? "");
				const def = payload?.def;
				return (await storageGet({ [key]: def }))[key];
			}
			case "gm_setValue":
				await storageSet({ [String(payload?.key ?? "")]: payload?.value });
				return true;
			case "gm_deleteValue":
				await storageRemove(String(payload?.key ?? ""));
				return true;
			case "gm_listValues": {
				const items = await storageGet(null);
				return Object.keys(items ?? {});
			}
			case "gm_getValues": return await storageGet(payload?.defaults ?? {});
			default: throw new Error(`Unknown bridge action: ${action}`);
		}
	}
	function sendResponse(id, ok, result, error) {
		postToPage({
			type: TYPE_RES,
			id,
			ok,
			result,
			error
		});
	}
	var bridgeGlobal = globalThis;
	if (bridgeGlobal[BRIDGE_BOOT_KEY]) debug.log("[VOT EXT][bridge] already initialized");
	else {
		bridgeGlobal[BRIDGE_BOOT_KEY] = true;
		if (!ext?.runtime || !ext?.storage?.local) console.warn("[VOT Extension] bridge: missing WebExtension APIs");
		else {
			injectPageModule("prelude.module.js");
			injectPageModule("content.module.js");
			globalThis.addEventListener("message", async (event) => {
				if (event.source !== globalThis.window) return;
				const data = event.data;
				if (!isOurMessage(data)) return;
				try {
					if (data.type === "VOT_EXT_REQ") {
						sendResponse(String(data.id ?? ""), true, await handleRequest(String(data.action ?? ""), data.payload ?? {}));
						return;
					}
					if (data.type === "VOT_EXT_NOTIFY") {
						ext?.runtime?.sendMessage?.({
							type: "gm_notification",
							details: data.details
						});
						return;
					}
					if (data.type === "VOT_EXT_XHR_START") {
						startXhr(String(data.requestId ?? ""), data.details ?? {});
						return;
					}
					if (data.type === "VOT_EXT_XHR_ABORT") {
						abortXhr(String(data.requestId ?? ""));
						return;
					}
				} catch (err) {
					if (data?.type === "VOT_EXT_REQ") sendResponse(String(data.id ?? ""), false, void 0, err instanceof Error ? err.message : String(err));
					else console.error("[VOT Extension] bridge error", err);
				}
			});
		}
	}
	//#endregion
})();

//# sourceMappingURL=bridge.js.map