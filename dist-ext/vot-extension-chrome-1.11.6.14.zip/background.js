//#region src/utils/debug.ts
var log = (...text) => {
	console.log("%c[VOT DEBUG]", "background: #3700ffff; color: #fff; padding: 5px;", ...text);
};
var warn = (...text) => {
	console.warn("%c[VOT DEBUG]", "background: #e1ff00ff; color: #fff; padding: 5px;", ...text);
};
var error = (...text) => {
	console.error("%c[VOT DEBUG]", "background: #F2452D; color: #fff; padding: 5px;", ...text);
};
var debug = {
	log,
	warn,
	error
};
//#endregion
//#region src/extension/base64.ts
var BASE64URL_DECODE_OPTIONS = { alphabet: "base64url" };
var nativeToBase64 = typeof Uint8Array.prototype.toBase64 === "function" ? Uint8Array.prototype.toBase64 : null;
var nativeFromBase64 = Uint8Array.fromBase64;
function normalizeBase64Input(input) {
	const withoutWhitespace = String(input).replaceAll(/\s+/g, "");
	const remainder = withoutWhitespace.length % 4;
	if (remainder === 1) throw new TypeError("Invalid base64 input.");
	if (remainder === 0) return withoutWhitespace;
	return withoutWhitespace + "=".repeat(4 - remainder);
}
function bytesToBinaryString(bytes) {
	let binary = "";
	for (const byte of bytes) binary += String.fromCharCode(byte);
	return binary;
}
function decodeWithLegacyBase64Normalized(normalizedBase64) {
	const atobFn = globalThis.atob;
	if (typeof atobFn !== "function") throw new TypeError("Base64 decoder is not available in this environment.");
	const binary = atobFn(normalizedBase64);
	const out = new Uint8Array(binary.length);
	for (let i = 0; i < binary.length; i += 1) out[i] = binary.charCodeAt(i);
	return out;
}
function encodeWithLegacyBase64(bytes) {
	const btoaFn = globalThis.btoa;
	if (typeof btoaFn !== "function") throw new TypeError("Base64 encoder is not available in this environment.");
	return btoaFn(bytesToBinaryString(bytes));
}
function decodeBase64ToBytes(input) {
	const normalized = normalizeBase64Input(input);
	const normalizedStandard = normalized.replaceAll("-", "+").replaceAll("_", "/");
	if (typeof nativeFromBase64 !== "function") return decodeWithLegacyBase64Normalized(normalizedStandard);
	const hasUrlAlphabet = normalized.includes("-") || normalized.includes("_");
	const hasStandardAlphabet = normalized.includes("+") || normalized.includes("/");
	if (hasUrlAlphabet && !hasStandardAlphabet) return nativeFromBase64(normalized, BASE64URL_DECODE_OPTIONS);
	return nativeFromBase64(hasUrlAlphabet && hasStandardAlphabet ? normalizedStandard : normalized);
}
function bytesToBase64(bytes) {
	if (typeof nativeToBase64 === "function") return nativeToBase64.call(bytes);
	return encodeWithLegacyBase64(bytes);
}
function arrayBufferToBase64(ab) {
	return bytesToBase64(new Uint8Array(ab));
}
function base64ToBytes(b64) {
	return decodeBase64ToBytes(b64);
}
//#endregion
//#region src/extension/bodySerialization.ts
var MAX_RECOVERABLE_BYTES = 1e7;
var DEBUG_KEYS_LIMIT = 12;
var MAX_COERCE_DEPTH = 2;
function isObjectLike(v) {
	return v !== null && typeof v === "object";
}
function isPlainObject(v) {
	return safeObjectTag(v) === "[object Object]";
}
function safeObjectTag(v) {
	try {
		return Object.prototype.toString.call(v);
	} catch {
		return null;
	}
}
function isArrayBufferLike(v) {
	return safeObjectTag(v) === "[object ArrayBuffer]";
}
function safeConstructorName(v) {
	try {
		const ctorName = v?.constructor?.name;
		return typeof ctorName === "string" ? ctorName : null;
	} catch {
		return null;
	}
}
function safeStringProp(obj, key) {
	try {
		const value = obj?.[key];
		return typeof value === "string" ? value : null;
	} catch {
		return null;
	}
}
function isBlobLike(v) {
	if (safeObjectTag(v) === "[object Blob]") return true;
	if (!v || typeof v !== "object") return false;
	try {
		const anyVal = v;
		const hasBuffer = typeof anyVal.arrayBuffer === "function";
		const hasSlice = typeof anyVal.slice === "function";
		const hasSize = typeof anyVal.size === "number";
		const hasType = typeof anyVal.type === "string";
		return (hasBuffer || hasSlice) && hasSize && hasType;
	} catch {
		return false;
	}
}
function safeJsonStringify(value) {
	try {
		return JSON.stringify(value);
	} catch {
		return null;
	}
}
function toSafeLength(value) {
	if (typeof value !== "number" || !Number.isFinite(value)) return null;
	const n = Math.trunc(value);
	if (n < 0 || n > MAX_RECOVERABLE_BYTES) return null;
	return n;
}
function toByte(value) {
	if (typeof value !== "number" || !Number.isFinite(value)) return null;
	return Math.trunc(value) & 255;
}
function toUint8FromNumericArray(values) {
	const len = values.length;
	if (len > MAX_RECOVERABLE_BYTES) return null;
	const out = new Uint8Array(len);
	for (let i = 0; i < len; i += 1) {
		const byte = toByte(values[i]);
		if (byte === null) return null;
		out[i] = byte;
	}
	return out;
}
function viewAsBytes(view) {
	return new Uint8Array(view.buffer, view.byteOffset, view.byteLength);
}
function copyArrayBufferView(view) {
	return viewAsBytes(view).slice();
}
function parseNonNegativeIntegerKey(key) {
	if (key === "") return null;
	const n = Number(key);
	if (!Number.isFinite(n) || !Number.isInteger(n) || n < 0) return null;
	return n;
}
function isSerializedBodyEnvelope(v) {
	if (!isObjectLike(v)) return false;
	const envelope = v;
	return envelope.__votExtBody === true && typeof envelope.b64 === "string";
}
function tryCoerceByteLikeObjectToUint8Array(v, depth = 0) {
	if (depth > MAX_COERCE_DEPTH) return null;
	if (!isObjectLike(v)) return null;
	const obj = v;
	if (isArrayBufferLike(v)) return new Uint8Array(v);
	try {
		if (ArrayBuffer.isView(v)) return copyArrayBufferView(v);
	} catch {}
	if (Array.isArray(v)) return toUint8FromNumericArray(v);
	if (obj.type === "Buffer" && Array.isArray(obj.data)) {
		const fromBufferJson = toUint8FromNumericArray(obj.data);
		if (fromBufferJson) return fromBufferJson;
	}
	if (Array.isArray(obj.data)) {
		const fromData = toUint8FromNumericArray(obj.data);
		if (fromData) return fromData;
	}
	if (Array.isArray(obj.bytes)) {
		const fromBytes = toUint8FromNumericArray(obj.bytes);
		if (fromBytes) return fromBytes;
	}
	if (typeof obj.b64 === "string") try {
		return base64ToBytes(obj.b64);
	} catch {}
	if (typeof obj.base64 === "string") try {
		return base64ToBytes(obj.base64);
	} catch {}
	const byteLength = toSafeLength(obj.byteLength);
	const byteOffset = toSafeLength(obj.byteOffset ?? 0);
	if (byteLength !== null && byteOffset !== null) {
		const rawBuffer = obj.buffer;
		if (isArrayBufferLike(rawBuffer)) try {
			return new Uint8Array(rawBuffer, byteOffset, byteLength).slice();
		} catch {}
		if (rawBuffer && rawBuffer !== v) {
			const recoveredBuffer = tryCoerceByteLikeObjectToUint8Array(rawBuffer, depth + 1);
			if (recoveredBuffer) {
				if (byteOffset > recoveredBuffer.byteLength) return null;
				const end = Math.min(recoveredBuffer.byteLength, byteOffset + byteLength);
				return recoveredBuffer.slice(byteOffset, end);
			}
		}
	}
	const length = toSafeLength(obj.length);
	if (length !== null) {
		const indexed = obj;
		const out = new Uint8Array(length);
		for (let i = 0; i < length; i += 1) {
			const byte = toByte(indexed[i]);
			if (byte === null) return null;
			out[i] = byte;
		}
		return out;
	}
	if (isPlainObject(v)) {
		const keys = Object.keys(obj);
		if (!keys.length) return null;
		const indexes = new Array(keys.length);
		let max = -1;
		for (let i = 0; i < keys.length; i += 1) {
			const idx = parseNonNegativeIntegerKey(keys[i]);
			if (idx === null || idx > MAX_RECOVERABLE_BYTES) return null;
			indexes[i] = idx;
			if (idx > max) max = idx;
		}
		const out = new Uint8Array(max + 1);
		for (let i = 0; i < keys.length; i += 1) {
			const key = keys[i];
			const byte = toByte(obj[key]);
			if (byte === null) return null;
			out[indexes[i]] = byte;
		}
		return out;
	}
	return null;
}
function coerceBodyToBytes(body) {
	return tryCoerceByteLikeObjectToUint8Array(body);
}
function summarizeBodyForDebug(body) {
	const jsType = body === null ? "null" : typeof body;
	const tag = safeObjectTag(body);
	const ctor = safeConstructorName(body);
	if (body === null || body === void 0) return {
		kind: "empty",
		jsType,
		tag,
		ctor
	};
	if (typeof body === "string") return {
		kind: "string",
		jsType,
		tag,
		ctor,
		textLength: body.length
	};
	if (isSerializedBodyEnvelope(body)) return {
		kind: `serialized:${typeof body.kind === "string" && body.kind ? body.kind : "bytes"}`,
		jsType,
		tag,
		ctor,
		base64Length: body.b64.length,
		mime: safeStringProp(body, "mime")
	};
	if (isArrayBufferLike(body)) return {
		kind: "ArrayBuffer",
		jsType,
		tag,
		ctor,
		byteLength: body.byteLength
	};
	try {
		if (ArrayBuffer.isView(body)) {
			const view = body;
			return {
				kind: ctor ? `TypedArray:${ctor}` : "TypedArray",
				jsType,
				tag,
				ctor,
				byteLength: view.byteLength
			};
		}
	} catch {}
	if (isBlobLike(body)) return {
		kind: "BlobLike",
		jsType,
		tag,
		ctor,
		byteLength: typeof body.size === "number" ? Number(body.size) : -1,
		mime: safeStringProp(body, "type")
	};
	const coerced = coerceBodyToBytes(body);
	if (coerced) return {
		kind: "coerced-bytes",
		jsType,
		tag,
		ctor,
		byteLength: coerced.byteLength
	};
	if (isObjectLike(body)) {
		const keys = Object.keys(body);
		return {
			kind: "object",
			jsType,
			tag,
			ctor,
			keyCount: keys.length,
			keys: keys.slice(0, DEBUG_KEYS_LIMIT)
		};
	}
	return {
		kind: "primitive",
		jsType,
		tag,
		ctor
	};
}
/**
* Decode a previously serialized body into a fetch/XHR-compatible BodyInit.
*/
function decodeSerializedBody(body) {
	if (body === null || body === void 0) return void 0;
	if (typeof body === "string") return body;
	if (isSerializedBodyEnvelope(body)) {
		const bytes = base64ToBytes(body.b64);
		if ((typeof body.kind === "string" && body.kind ? body.kind : "bytes") === "blob") {
			const mime = body.mime;
			const ab = bytes.buffer;
			return typeof mime === "string" && mime ? new Blob([ab], { type: mime }) : new Blob([ab]);
		}
		return bytes;
	}
	const recovered = coerceBodyToBytes(body);
	if (recovered) return recovered;
	if (isObjectLike(body)) {
		const json = safeJsonStringify(body);
		if (typeof json === "string") return json;
	}
	return String(body);
}
//#endregion
//#region src/extension/webext.ts
var browserNamespace = globalThis.browser;
var chromeNamespace = globalThis.chrome;
var ext = browserNamespace ?? chromeNamespace ?? null;
var isBrowserNamespace = !!browserNamespace && ext === browserNamespace;
function lastErrorMessage() {
	const err = chromeNamespace?.runtime?.lastError ?? ext?.runtime?.lastError;
	return err?.message ? String(err.message) : null;
}
async function callAsync(fn, args = [], opts = {}) {
	if (typeof fn !== "function") throw new TypeError("WebExtension API is not available");
	const mapCbArgs = opts.mapCbArgs;
	const rejectOnLastError = opts.rejectOnLastError !== false;
	if (isBrowserNamespace) return await fn(...args);
	return await new Promise((resolve, reject) => {
		try {
			fn(...args, (...cbArgs) => {
				const err = rejectOnLastError ? lastErrorMessage() : null;
				if (err) reject(new Error(err));
				else resolve(mapCbArgs ? mapCbArgs(...cbArgs) : cbArgs[0]);
			});
		} catch (e) {
			reject(e);
		}
	});
}
async function notificationsCreate(notificationId, options) {
	const api = ext?.notifications;
	const createFn = api?.create;
	if (!api || typeof createFn !== "function") return;
	await callAsync(createFn.bind(api), [notificationId, options], { mapCbArgs: () => void 0 });
}
async function notificationsClear(notificationId) {
	const api = ext?.notifications;
	const clearFn = api?.clear;
	if (!api || typeof clearFn !== "function") return;
	await callAsync(clearFn.bind(api), [notificationId], {
		mapCbArgs: () => void 0,
		rejectOnLastError: false
	});
}
async function windowsUpdate(windowId, updateInfo) {
	const api = ext?.windows;
	const updateFn = api?.update;
	if (!api || typeof updateFn !== "function") return;
	await callAsync(updateFn.bind(api), [windowId, updateInfo], {
		mapCbArgs: () => void 0,
		rejectOnLastError: false
	});
}
async function tabsUpdate(tabId, updateInfo) {
	const api = ext?.tabs;
	const updateFn = api?.update;
	if (!api || typeof updateFn !== "function") return;
	await callAsync(updateFn.bind(api), [tabId, updateInfo], {
		mapCbArgs: () => void 0,
		rejectOnLastError: false
	});
}
//#endregion
//#region src/extension/yandexHeaders.ts
var YANDEX_API_HOST = "api.browser.yandex.ru";
var ALLOWED_UA_CH_HEADERS = /* @__PURE__ */ new Set([
	"sec-ch-ua",
	"sec-ch-ua-mobile",
	"sec-ch-ua-platform",
	"sec-ch-ua-full-version-list"
]);
var SUPPRESSED_UA_CH_HEADERS = [
	"sec-ch-ua-full-version",
	"sec-ch-ua-platform-version",
	"sec-ch-ua-arch",
	"sec-ch-ua-bitness",
	"sec-ch-ua-model",
	"sec-ch-ua-wow64"
];
var SUPPRESSED_UA_CH_HEADERS_SET = new Set(SUPPRESSED_UA_CH_HEADERS);
function isYandexApiHostname(hostname) {
	return String(hostname || "") === YANDEX_API_HOST;
}
function normalizeHeaderName(name) {
	return String(name || "").trim();
}
function shouldStripYandexHeader(name) {
	const normalized = normalizeHeaderName(name).toLowerCase();
	if (!normalized) return false;
	if (normalized === "origin" || normalized === "referer") return true;
	if (SUPPRESSED_UA_CH_HEADERS_SET.has(normalized)) return true;
	if (normalized.startsWith("sec-ch-ua") && !ALLOWED_UA_CH_HEADERS.has(normalized)) return true;
	return false;
}
function filterYandexHeadersForDnr(headers) {
	const result = {};
	for (const [k, v] of Object.entries(headers || {})) {
		const key = normalizeHeaderName(k);
		if (!key) continue;
		if (shouldStripYandexHeader(key)) continue;
		result[key] = String(v);
	}
	return result;
}
//#endregion
//#region src/extension/background.ts
var MAX_INLINE_BINARY_RESPONSE_BYTES = 512 * 1024;
/**
* Some request headers are "forbidden" for fetch()/XHR (e.g. `Sec-*` and
* `User-Agent`). Userscript managers (Tampermonkey/Violentmonkey) can still
* send these headers via extension-level request interception.
*
* Our MV3 extension background uses `fetch()` to implement GM_xmlhttpRequest,
* which means these headers get silently stripped and no-proxy mode breaks for
* endpoints that expect them.
*
* In MV3, the supported way to modify such headers is
* `chrome.declarativeNetRequest` ("modifyHeaders"). We install/update a
* **session** rule scoped to requests that don't originate from a tab
* (TAB_ID_NONE), i.e. service-worker initiated requests.
*/
var DNR_RULE_ID_YANDEX_HEADERS = 9001;
var DNR_RULE_ID_YOUTUBEI_ORIGIN = 9002;
var DNR_RULE_ID_GOOGLEVIDEO_HEADERS = 9003;
var dnrAppliedSignatures = /* @__PURE__ */ new Map();
var dnrRuleUpdateQueue = Promise.resolve();
function hasDnr() {
	return Boolean(ext?.declarativeNetRequest?.updateSessionRules);
}
function updateSessionRules(args) {
	const updateSessionRulesFn = (ext?.declarativeNetRequest)?.updateSessionRules;
	if (typeof updateSessionRulesFn !== "function") return Promise.resolve();
	try {
		const maybe = updateSessionRulesFn({
			addRules: args.addRules || [],
			removeRuleIds: args.removeRuleIds || []
		});
		if (maybe && typeof maybe.then === "function") return maybe;
	} catch {}
	return new Promise((resolve, reject) => {
		try {
			updateSessionRulesFn({
				addRules: args.addRules || [],
				removeRuleIds: args.removeRuleIds || []
			}, () => {
				const err = lastErrorMessage();
				if (err) reject(new Error(err));
				else resolve();
			});
		} catch (e) {
			reject(e);
		}
	});
}
function isForbiddenToSetViaFetch(headerName) {
	const n = normalizeHeaderName(headerName).toLowerCase();
	if (!n) return false;
	if (n.startsWith("sec-")) return true;
	if (n.startsWith("proxy-")) return true;
	if (n === "user-agent") return true;
	if (n === "origin") return true;
	if (n === "referer") return true;
	return false;
}
function signatureFromDnrRequestHeaders(requestHeaders) {
	const entries = requestHeaders.map((h) => [`${normalizeHeaderName(String(h.header)).toLowerCase()}:${String(h.operation)}`, String("value" in h ? h.value : "")]).sort((a, b) => a[0].localeCompare(b[0]));
	return JSON.stringify(entries);
}
function queueDnrSessionRuleUpdate(ruleId, signature, rule) {
	if (signature === dnrAppliedSignatures.get(ruleId)) return Promise.resolve();
	dnrRuleUpdateQueue = dnrRuleUpdateQueue.catch(() => void 0).then(async () => {
		if (signature === dnrAppliedSignatures.get(ruleId)) return;
		await updateSessionRules({
			removeRuleIds: [ruleId],
			addRules: [rule]
		});
		dnrAppliedSignatures.set(ruleId, signature);
	});
	return dnrRuleUpdateQueue;
}
async function ensureDnrHeaderRuleForYandex(url, forbiddenHeaders) {
	if (!hasDnr()) return;
	let hostname = "";
	try {
		hostname = new URL(url).hostname;
	} catch {
		return;
	}
	if (!isYandexApiHostname(hostname)) return;
	const requestHeaders = [
		{
			header: "Origin",
			operation: "remove"
		},
		{
			header: "Referer",
			operation: "remove"
		},
		...SUPPRESSED_UA_CH_HEADERS.map((h) => ({
			header: h,
			operation: "remove"
		}))
	];
	const headersToSet = filterYandexHeadersForDnr(forbiddenHeaders);
	for (const [header, value] of Object.entries(headersToSet)) requestHeaders.push({
		header: normalizeHeaderName(header),
		operation: "set",
		value: String(value)
	});
	await queueDnrSessionRuleUpdate(DNR_RULE_ID_YANDEX_HEADERS, signatureFromDnrRequestHeaders(requestHeaders), {
		id: DNR_RULE_ID_YANDEX_HEADERS,
		priority: 1,
		action: {
			type: "modifyHeaders",
			requestHeaders
		},
		condition: {
			urlFilter: "|https://api.browser.yandex.ru/",
			resourceTypes: ["xmlhttprequest"],
			tabIds: [-1]
		}
	});
}
function isYoutubeiApiUrl(url) {
	try {
		const parsed = new URL(url);
		return parsed.protocol === "https:" && parsed.hostname === "www.youtube.com" && parsed.pathname.startsWith("/youtubei/");
	} catch {
		return false;
	}
}
function isGooglevideoUrl(url) {
	try {
		const parsed = new URL(url);
		const host = parsed.hostname.toLowerCase();
		return parsed.protocol === "https:" && (host === "googlevideo.com" || host.endsWith(".googlevideo.com"));
	} catch {
		return false;
	}
}
async function ensureDnrOriginStripRuleForYoutubei(url) {
	if (!hasDnr()) return;
	if (!isYoutubeiApiUrl(url)) return;
	const requestHeaders = [
		{
			header: "Origin",
			operation: "remove"
		},
		{
			header: "x-client-data",
			operation: "remove"
		},
		{
			header: "x-goog-visitor-id",
			operation: "remove"
		}
	];
	await queueDnrSessionRuleUpdate(DNR_RULE_ID_YOUTUBEI_ORIGIN, JSON.stringify({
		v: 2,
		headers: signatureFromDnrRequestHeaders(requestHeaders)
	}), {
		id: DNR_RULE_ID_YOUTUBEI_ORIGIN,
		priority: 1,
		action: {
			type: "modifyHeaders",
			requestHeaders
		},
		condition: {
			urlFilter: "|https://www.youtube.com/youtubei/",
			resourceTypes: ["xmlhttprequest"],
			tabIds: [-1]
		}
	});
}
async function ensureDnrStripRuleForGooglevideo(url) {
	if (!hasDnr()) return;
	if (!isGooglevideoUrl(url)) return;
	const requestHeaders = [{
		header: "x-client-data",
		operation: "remove"
	}];
	await queueDnrSessionRuleUpdate(DNR_RULE_ID_GOOGLEVIDEO_HEADERS, JSON.stringify({
		v: 1,
		headers: signatureFromDnrRequestHeaders(requestHeaders)
	}), {
		id: DNR_RULE_ID_GOOGLEVIDEO_HEADERS,
		priority: 1,
		action: {
			type: "modifyHeaders",
			requestHeaders
		},
		condition: {
			urlFilter: "||googlevideo.com/",
			resourceTypes: ["xmlhttprequest"],
			tabIds: [-1]
		}
	});
}
function asErrorMessage(err) {
	if (err instanceof Error) return err.message;
	if (err && typeof err === "object") try {
		return JSON.stringify(err);
	} catch {
		return Object.prototype.toString.call(err);
	}
	try {
		return String(err);
	} catch {
		return "Unknown error";
	}
}
function formatHeaders(headers) {
	return Array.from(headers.entries()).map(([k, v]) => `${k}: ${v}`).join("\r\n");
}
function toHeaderRecord(input) {
	const out = {};
	if (!input) return out;
	for (const [k, v] of Object.entries(input)) {
		if (v === void 0) continue;
		if (typeof v === "string" || typeof v === "number" || typeof v === "boolean") out[String(k)] = String(v);
	}
	return out;
}
function createTerminalXhrError(url, error) {
	return {
		finalUrl: url,
		readyState: 4,
		status: 0,
		statusText: "",
		responseHeaders: "",
		response: null,
		responseText: "",
		error
	};
}
function getHeader(headers, name) {
	const needle = name.toLowerCase();
	for (const [k, v] of Object.entries(headers)) if (String(k).toLowerCase() === needle) return String(v);
}
function isProtobufContentType(contentType) {
	const ct = String(contentType || "").toLowerCase();
	if (!ct) return false;
	return ct.includes("application/x-protobuf") || ct.includes("application/protobuf") || ct.includes("application/octet-stream");
}
function tryDecodeStrictBase64Payload(s) {
	const str = String(s || "");
	if (!str || /\s/.test(str)) return null;
	if (!/^[A-Za-z0-9+/=_-]+$/.test(str)) return null;
	if (!/[+/=_-]/.test(str)) return null;
	const normalized = str.replaceAll("-", "+").replaceAll("_", "/");
	const remainder = normalized.length % 4;
	if (remainder === 1) return null;
	const padded = remainder === 0 ? normalized : `${normalized}${"=".repeat(4 - remainder)}`;
	try {
		return base64ToBytes(padded);
	} catch {
		return null;
	}
}
function latin1StringToBytes(s) {
	const str = String(s || "");
	const out = new Uint8Array(str.length);
	for (let i = 0; i < str.length; i += 1) out[i] = (str.codePointAt(i) ?? 0) & 255;
	return out;
}
function looksLikeObjectToStringPayload(value) {
	return /^\[object [^\]]+\]$/.test(String(value || "").trim());
}
var xhrSessionSeq = 0;
ext?.runtime?.onConnect?.addListener?.((port) => {
	if (!port || typeof port !== "object") return;
	const typedPort = port;
	if (typedPort.name !== "vot_gm_xhr") return;
	if (typeof typedPort.onDisconnect?.addListener !== "function" || typeof typedPort.onMessage?.addListener !== "function" || typeof typedPort.postMessage !== "function") return;
	const safePostMessage = (payload) => {
		typedPort.postMessage?.(payload);
	};
	xhrSessionSeq += 1;
	const xhrSessionId = xhrSessionSeq;
	let controller = null;
	let timeoutId = null;
	let abortedByUser = false;
	let timedOut = false;
	const cleanup = () => {
		if (timeoutId !== null) {
			clearTimeout(timeoutId);
			timeoutId = null;
		}
	};
	typedPort.onDisconnect.addListener(() => {
		cleanup();
		debug.warn("[VOT EXT][background][xhr] port disconnected", { xhrSessionId });
		try {
			controller?.abort();
		} catch {}
	});
	typedPort.onMessage.addListener(async (msg) => {
		if (!msg || typeof msg !== "object") return;
		if (msg.type === "abort") {
			abortedByUser = true;
			debug.warn("[VOT EXT][background][xhr] abort requested", { xhrSessionId });
			try {
				controller?.abort();
			} catch {}
			return;
		}
		if (msg.type !== "start") return;
		const shouldAbortImmediately = abortedByUser && controller === null;
		abortedByUser = false;
		const { details } = msg;
		const url = details.url;
		const method = (details.method || "GET").toUpperCase();
		const allHeaders = toHeaderRecord(details.headers);
		const headers = {};
		const forbiddenHeaders = {};
		for (const [k, v] of Object.entries(allHeaders)) if (isForbiddenToSetViaFetch(k)) forbiddenHeaders[k] = v;
		else headers[k] = v;
		const timeout = Number(details.timeout || 0);
		const responseType = String(details.responseType || "text").toLowerCase();
		debug.log("[VOT EXT][background][xhr] start", {
			xhrSessionId,
			state: "in_flight",
			url,
			method,
			responseType,
			timeoutMs: timeout,
			headerCount: Object.keys(allHeaders).length,
			headerNames: Object.keys(allHeaders),
			forbiddenHeaderNames: Object.keys(forbiddenHeaders),
			body: summarizeBodyForDebug(details.data)
		});
		if (shouldAbortImmediately) {
			const errorObj = {
				finalUrl: url,
				readyState: 4,
				status: 0,
				statusText: "",
				responseHeaders: "",
				response: null,
				responseText: "",
				error: "Aborted"
			};
			try {
				safePostMessage({
					type: "abort",
					state: "terminal",
					error: errorObj
				});
			} catch {}
			return;
		}
		timedOut = false;
		controller = new AbortController();
		if (timeout > 0) timeoutId = setTimeout(() => {
			timedOut = true;
			try {
				controller?.abort();
			} catch {}
		}, timeout);
		let credentials = "include";
		if (details.anonymous || details.withCredentials === false) credentials = "omit";
		try {
			let cache;
			if (details.nocache) cache = "no-store";
			else if (details.revalidate) cache = "no-cache";
			const redirect = details.redirect === "error" || details.redirect === "manual" ? details.redirect : "follow";
			const isBodyAllowed = method !== "GET" && method !== "HEAD";
			try {
				await ensureDnrStripRuleForGooglevideo(url);
				await ensureDnrOriginStripRuleForYoutubei(url);
				await ensureDnrHeaderRuleForYandex(url, forbiddenHeaders);
			} catch (e) {
				console.warn("[VOT Extension] Failed to apply DNR header rules; requests may break:", e);
			}
			let body = isBodyAllowed ? decodeSerializedBody(details.data) : void 0;
			let recoveredBodyFromDetails;
			const getRecoveredBodyFromDetails = () => {
				if (recoveredBodyFromDetails !== void 0) return recoveredBodyFromDetails;
				recoveredBodyFromDetails = coerceBodyToBytes(details.data);
				return recoveredBodyFromDetails;
			};
			const contentType = getHeader(allHeaders, "content-type");
			const isProtobufRequest = isProtobufContentType(contentType);
			debug.log("[VOT EXT][background][xhr] body decoded", {
				xhrSessionId,
				url,
				method,
				contentType: contentType ?? null,
				isProtobufRequest,
				sourceBody: summarizeBodyForDebug(details.data),
				decodedBody: summarizeBodyForDebug(body)
			});
			if (isBodyAllowed && isProtobufRequest && (body === void 0 || body === null)) {
				const recovered = getRecoveredBodyFromDetails();
				if (recovered) {
					body = recovered;
					debug.warn("[VOT EXT][background][xhr] protobuf body recovered from raw payload", {
						xhrSessionId,
						url,
						method,
						recoveredBody: summarizeBodyForDebug(body)
					});
				}
			}
			if (isBodyAllowed && typeof body === "string" && isProtobufRequest) {
				if (looksLikeObjectToStringPayload(body)) {
					const recovered = getRecoveredBodyFromDetails();
					if (recovered) {
						body = recovered;
						debug.warn("[VOT EXT][background][xhr] recovered protobuf body from object-like string fallback", {
							xhrSessionId,
							url,
							method,
							sourceBody: summarizeBodyForDebug(details.data),
							recoveredBody: summarizeBodyForDebug(recovered)
						});
					}
				}
				if (typeof body === "string") {
					const maybeBase64Bytes = tryDecodeStrictBase64Payload(body);
					body = maybeBase64Bytes ?? latin1StringToBytes(body);
					debug.log("[VOT EXT][background][xhr] protobuf string converted to bytes", {
						xhrSessionId,
						url,
						method,
						strategy: maybeBase64Bytes ? "base64" : "latin1",
						convertedBody: summarizeBodyForDebug(body)
					});
				}
			}
			debug.log("[VOT EXT][background][xhr] fetch dispatch", {
				xhrSessionId,
				url,
				method,
				credentials,
				redirect,
				cache: cache ?? "default",
				body: summarizeBodyForDebug(body)
			});
			const requestInit = {
				method,
				headers,
				redirect,
				credentials,
				signal: controller.signal
			};
			if (body !== void 0) requestInit.body = body;
			if (cache !== void 0) requestInit.cache = cache;
			const res = await fetch(url, requestInit);
			debug.log("[VOT EXT][background][xhr] fetch response received", {
				xhrSessionId,
				url: res.url || url,
				method,
				status: res.status,
				statusText: res.statusText,
				responseType,
				contentType: res.headers.get("content-type") || null,
				contentLength: res.headers.get("content-length") || null
			});
			const responseHeaders = formatHeaders(res.headers);
			const finalUrl = res.url || url;
			const responseContentType = res.headers.get("content-type") || "";
			const makeBase = (readyState) => ({
				finalUrl,
				readyState,
				status: res.status,
				statusText: res.statusText,
				responseHeaders
			});
			const wantBinary = responseType === "arraybuffer" || responseType === "blob" || responseType === "stream";
			let response;
			let responseText;
			let responseB64;
			if (wantBinary) {
				const contentLength = Number(res.headers.get("content-length") || 0);
				if (!!res.body && (!Number.isFinite(contentLength) || contentLength > MAX_INLINE_BINARY_RESPONSE_BYTES)) {
					let loaded = 0;
					const total = Number.isFinite(contentLength) ? contentLength : 0;
					const reader = res.body.getReader();
					while (true) {
						const { done, value } = await reader.read();
						if (done) break;
						if (!value) continue;
						loaded += value.byteLength;
						safePostMessage({
							type: "progress",
							state: "in_flight",
							progress: {
								...makeBase(3),
								loaded,
								total,
								lengthComputable: total > 0,
								chunkB64: bytesToBase64(value)
							}
						});
					}
					response = void 0;
				} else {
					const ab = await res.arrayBuffer();
					if (ab.byteLength > 0) responseB64 = arrayBufferToBase64(ab);
					response = void 0;
				}
			} else if (responseType === "json") {
				responseText = await res.text();
				try {
					response = JSON.parse(responseText);
				} catch {
					response = null;
				}
			} else {
				responseText = await res.text();
				response = responseText;
			}
			cleanup();
			debug.log("[VOT EXT][background][xhr] terminal", {
				xhrSessionId,
				state: "terminal",
				kind: "load",
				url: finalUrl,
				status: res.status,
				responseType,
				responseBody: summarizeBodyForDebug(response),
				responseTextLength: responseText?.length ?? 0,
				responseB64Length: responseB64?.length ?? 0
			});
			safePostMessage({
				type: "load",
				state: "terminal",
				response: {
					...makeBase(4),
					responseType,
					...responseContentType ? { contentType: responseContentType } : {},
					...responseB64 ? { responseB64 } : {},
					response,
					...typeof responseText === "string" ? { responseText } : {}
				}
			});
		} catch (err) {
			cleanup();
			if (abortedByUser || timedOut || err instanceof DOMException && err.name === "AbortError") {
				let kind;
				if (timedOut) kind = "timeout";
				else kind = "abort";
				const errorObj = createTerminalXhrError(url, kind === "timeout" ? "Timeout" : "Aborted");
				try {
					safePostMessage({
						type: kind,
						state: "terminal",
						error: errorObj
					});
				} catch {}
				debug.warn("[VOT EXT][background][xhr] terminal", {
					xhrSessionId,
					state: "terminal",
					kind,
					url,
					method,
					responseType
				});
				return;
			}
			const errorObj = createTerminalXhrError(url, asErrorMessage(err));
			safePostMessage({
				type: "error",
				state: "terminal",
				error: errorObj
			});
			debug.error("[VOT EXT][background][xhr] terminal", {
				xhrSessionId,
				state: "terminal",
				kind: "error",
				url,
				method,
				responseType,
				error: errorObj.error
			});
		}
	});
});
function isGmNotificationMessage(msg) {
	if (!msg || typeof msg !== "object") return false;
	return msg.type === "gm_notification";
}
function normalizeGmNotificationDetails(details) {
	const raw = details && typeof details === "object" ? details : {};
	const timeoutRaw = Number(raw.timeout ?? 0);
	return {
		title: raw.title != null ? String(raw.title) : "",
		text: raw.text != null ? String(raw.text) : "",
		silent: Boolean(raw.silent),
		timeout: Number.isFinite(timeoutRaw) && timeoutRaw > 0 ? timeoutRaw : 0
	};
}
function createBridgeNotificationId(sender) {
	const tabId = sender.tab?.id;
	const windowId = sender.tab?.windowId;
	return `vot:${typeof tabId === "number" ? tabId : -1}:${typeof windowId === "number" ? windowId : -1}:${typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}:${Math.random().toString(36).slice(2)}`}`;
}
function createBridgeNotificationOptions(details) {
	const isFirefox = typeof (ext?.runtime)?.getBrowserInfo === "function";
	const options = {
		type: "basic",
		iconUrl: ext?.runtime?.getURL ? ext.runtime.getURL("icons/icon-128.png") : "icons/icon-128.png",
		title: details.title || "VOT",
		message: details.text
	};
	if (!isFirefox) options.silent = details.silent;
	return options;
}
function sendNotificationResponse(sendResponse, payload) {
	if (typeof sendResponse !== "function") return;
	try {
		sendResponse(payload);
	} catch {}
}
ext?.runtime?.onMessage?.addListener?.((msg, sender, sendResponse) => {
	if (!isGmNotificationMessage(msg)) return;
	const details = normalizeGmNotificationDetails(msg.details);
	const notificationId = createBridgeNotificationId(sender);
	const options = createBridgeNotificationOptions(details);
	(async () => {
		try {
			await notificationsCreate(notificationId, options);
			if (details.timeout > 0) setTimeout(() => {
				notificationsClear(notificationId);
			}, details.timeout);
			sendNotificationResponse(sendResponse, { ok: true });
		} catch (error) {
			debug.error("[VOT EXT][background] Failed to create notification", error);
			sendNotificationResponse(sendResponse, {
				ok: false,
				error: asErrorMessage(error)
			});
		}
	})();
	return true;
});
ext?.notifications?.onClicked?.addListener?.((notificationId) => {
	if (!notificationId.startsWith("vot:")) return;
	const parts = notificationId.split(":");
	if (parts.length < 3) return;
	const tabId = Number(parts[1]);
	const windowId = Number(parts[2]);
	if (Number.isFinite(windowId) && windowId >= 0) windowsUpdate(windowId, { focused: true });
	if (Number.isFinite(tabId) && tabId >= 0) tabsUpdate(tabId, { active: true });
});
//#endregion
export { createBridgeNotificationId, createBridgeNotificationOptions, isGmNotificationMessage, normalizeGmNotificationDetails };

//# sourceMappingURL=background.js.map