//#region src/utils/debug.ts
var log = (...text) => {
	console.log("%c[VOT DEBUG]", "background: #3700ffff; color: #fff; padding: 5px;", ...text);
};
var warn = (...text) => {
	console.warn("%c[VOT DEBUG]", "background: #e1ff00ff; color: #fff; padding: 5px;", ...text);
};
var error = (...text) => {
	console.error("%c[VOT DEBUG]", "background: #F2452D; color: #fff; padding: 5px;", ...text);
};
var debug = {
	log,
	warn,
	error
};
//#endregion
//#region src/utils/errors.ts
/**
* Small error helpers used across the project.
*/
function stringifyUnknownObject(value) {
	const seen = /* @__PURE__ */ new WeakSet();
	try {
		return JSON.stringify(value, (_key, currentValue) => {
			if (typeof currentValue !== "object" || currentValue === null) return currentValue;
			if (seen.has(currentValue)) return "[Circular]";
			seen.add(currentValue);
			return currentValue;
		}) ?? null;
	} catch {
		return null;
	}
}
function toErrorMessage(error, fallback = "Unknown error") {
	if (error instanceof Error) return error.message || fallback;
	if (typeof error === "string") return error || fallback;
	if (error === null || error === void 0) return fallback;
	if (typeof error === "object") {
		const anyErr = error;
		if (typeof anyErr?.data?.message === "string" && anyErr.data.message) return anyErr.data.message;
		if (typeof anyErr?.error?.message === "string" && anyErr.error.message) return anyErr.error.message;
		if (typeof anyErr?.message === "string" && anyErr.message) return anyErr.message;
		const serialized = stringifyUnknownObject(error);
		if (serialized && serialized !== "{}") return serialized;
		const ctorName = error.constructor?.name;
		return ctorName ? `[${ctorName}]` : fallback;
	}
	if (typeof error === "number" || typeof error === "boolean" || typeof error === "bigint") return `${error}`;
	if (typeof error === "symbol") return error.description ? `Symbol(${error.description})` : "Symbol";
	if (typeof error === "function") return error.name ? `[Function ${error.name}]` : "[Function]";
	return fallback;
}
//#endregion
//#region src/extension/base64.ts
var BASE64URL_DECODE_OPTIONS = { alphabet: "base64url" };
var nativeToBase64 = typeof Uint8Array.prototype.toBase64 === "function" ? Uint8Array.prototype.toBase64 : null;
var nativeFromBase64 = Uint8Array.fromBase64;
function normalizeBase64Input(input) {
	const withoutWhitespace = String(input).replaceAll(/\s+/g, "");
	const remainder = withoutWhitespace.length % 4;
	if (remainder === 1) throw new TypeError("Invalid base64 input.");
	if (remainder === 0) return withoutWhitespace;
	return withoutWhitespace + "=".repeat(4 - remainder);
}
function bytesToBinaryString(bytes) {
	let binary = "";
	for (const byte of bytes) binary += String.fromCharCode(byte);
	return binary;
}
function decodeWithLegacyBase64Normalized(normalizedBase64) {
	const atobFn = globalThis.atob;
	if (typeof atobFn !== "function") throw new TypeError("Base64 decoder is not available in this environment.");
	const binary = atobFn(normalizedBase64);
	const out = new Uint8Array(binary.length);
	for (let i = 0; i < binary.length; i += 1) out[i] = binary.charCodeAt(i);
	return out;
}
function encodeWithLegacyBase64(bytes) {
	const btoaFn = globalThis.btoa;
	if (typeof btoaFn !== "function") throw new TypeError("Base64 encoder is not available in this environment.");
	return btoaFn(bytesToBinaryString(bytes));
}
function decodeBase64ToBytes(input) {
	const normalized = normalizeBase64Input(input);
	const normalizedStandard = normalized.replaceAll("-", "+").replaceAll("_", "/");
	if (typeof nativeFromBase64 !== "function") return decodeWithLegacyBase64Normalized(normalizedStandard);
	const hasUrlAlphabet = normalized.includes("-") || normalized.includes("_");
	const hasStandardAlphabet = normalized.includes("+") || normalized.includes("/");
	if (hasUrlAlphabet && !hasStandardAlphabet) return nativeFromBase64(normalized, BASE64URL_DECODE_OPTIONS);
	return nativeFromBase64(hasUrlAlphabet && hasStandardAlphabet ? normalizedStandard : normalized);
}
function bytesToBase64(bytes) {
	if (typeof nativeToBase64 === "function") return nativeToBase64.call(bytes);
	return encodeWithLegacyBase64(bytes);
}
function base64ToBytes(b64) {
	return decodeBase64ToBytes(b64);
}
//#endregion
//#region src/extension/bodySerialization.ts
var MAX_RECOVERABLE_BYTES = 1e7;
var DEBUG_KEYS_LIMIT = 12;
var MAX_COERCE_DEPTH = 2;
function isObjectLike(v) {
	return v !== null && typeof v === "object";
}
function isPlainObject(v) {
	return safeObjectTag(v) === "[object Object]";
}
function safeObjectTag(v) {
	try {
		return Object.prototype.toString.call(v);
	} catch {
		return null;
	}
}
function isArrayBufferLike(v) {
	return safeObjectTag(v) === "[object ArrayBuffer]";
}
function safeConstructorName(v) {
	try {
		const ctorName = v?.constructor?.name;
		return typeof ctorName === "string" ? ctorName : null;
	} catch {
		return null;
	}
}
function safeStringProp(obj, key) {
	try {
		const value = obj?.[key];
		return typeof value === "string" ? value : null;
	} catch {
		return null;
	}
}
function isBlobLike(v) {
	if (safeObjectTag(v) === "[object Blob]") return true;
	if (!v || typeof v !== "object") return false;
	try {
		const anyVal = v;
		const hasBuffer = typeof anyVal.arrayBuffer === "function";
		const hasSlice = typeof anyVal.slice === "function";
		const hasSize = typeof anyVal.size === "number";
		const hasType = typeof anyVal.type === "string";
		return (hasBuffer || hasSlice) && hasSize && hasType;
	} catch {
		return false;
	}
}
function safeJsonStringify(value) {
	try {
		return JSON.stringify(value);
	} catch {
		return null;
	}
}
function toSafeLength(value) {
	if (typeof value !== "number" || !Number.isFinite(value)) return null;
	const n = Math.trunc(value);
	if (n < 0 || n > MAX_RECOVERABLE_BYTES) return null;
	return n;
}
function toByte(value) {
	if (typeof value !== "number" || !Number.isFinite(value)) return null;
	return Math.trunc(value) & 255;
}
function toUint8FromNumericArray(values) {
	const len = values.length;
	if (len > MAX_RECOVERABLE_BYTES) return null;
	const out = new Uint8Array(len);
	for (let i = 0; i < len; i += 1) {
		const byte = toByte(values[i]);
		if (byte === null) return null;
		out[i] = byte;
	}
	return out;
}
function viewAsBytes(view) {
	return new Uint8Array(view.buffer, view.byteOffset, view.byteLength);
}
function copyArrayBufferView(view) {
	return viewAsBytes(view).slice();
}
function parseNonNegativeIntegerKey(key) {
	if (key === "") return null;
	const n = Number(key);
	if (!Number.isFinite(n) || !Number.isInteger(n) || n < 0) return null;
	return n;
}
function isSerializedBodyEnvelope(v) {
	if (!isObjectLike(v)) return false;
	const envelope = v;
	return envelope.__votExtBody === true && typeof envelope.b64 === "string";
}
function createSerializedBytes(bytes) {
	return {
		__votExtBody: true,
		kind: "bytes",
		b64: bytesToBase64(bytes)
	};
}
function createSerializedBlob(bytes, mime) {
	return {
		__votExtBody: true,
		kind: "blob",
		b64: bytesToBase64(bytes),
		mime
	};
}
async function tryReadBlobBody(body) {
	if (!isObjectLike(body)) return null;
	try {
		const anyBody = body;
		if (typeof anyBody.arrayBuffer === "function") return {
			ab: await anyBody.arrayBuffer(),
			mime: safeStringProp(anyBody, "type")
		};
	} catch {}
	if (typeof Response !== "undefined") try {
		return {
			ab: await new Response(body).arrayBuffer(),
			mime: safeStringProp(body, "type")
		};
	} catch {}
	if (typeof Blob !== "undefined" && isBlobLike(body)) try {
		return {
			ab: await body.arrayBuffer(),
			mime: safeStringProp(body, "type")
		};
	} catch {}
	return null;
}
function tryCoerceByteLikeObjectToUint8Array(v, depth = 0) {
	if (depth > MAX_COERCE_DEPTH) return null;
	if (!isObjectLike(v)) return null;
	const obj = v;
	if (isArrayBufferLike(v)) return new Uint8Array(v);
	try {
		if (ArrayBuffer.isView(v)) return copyArrayBufferView(v);
	} catch {}
	if (Array.isArray(v)) return toUint8FromNumericArray(v);
	if (obj.type === "Buffer" && Array.isArray(obj.data)) {
		const fromBufferJson = toUint8FromNumericArray(obj.data);
		if (fromBufferJson) return fromBufferJson;
	}
	if (Array.isArray(obj.data)) {
		const fromData = toUint8FromNumericArray(obj.data);
		if (fromData) return fromData;
	}
	if (Array.isArray(obj.bytes)) {
		const fromBytes = toUint8FromNumericArray(obj.bytes);
		if (fromBytes) return fromBytes;
	}
	if (typeof obj.b64 === "string") try {
		return base64ToBytes(obj.b64);
	} catch {}
	if (typeof obj.base64 === "string") try {
		return base64ToBytes(obj.base64);
	} catch {}
	const byteLength = toSafeLength(obj.byteLength);
	const byteOffset = toSafeLength(obj.byteOffset ?? 0);
	if (byteLength !== null && byteOffset !== null) {
		const rawBuffer = obj.buffer;
		if (isArrayBufferLike(rawBuffer)) try {
			return new Uint8Array(rawBuffer, byteOffset, byteLength).slice();
		} catch {}
		if (rawBuffer && rawBuffer !== v) {
			const recoveredBuffer = tryCoerceByteLikeObjectToUint8Array(rawBuffer, depth + 1);
			if (recoveredBuffer) {
				if (byteOffset > recoveredBuffer.byteLength) return null;
				const end = Math.min(recoveredBuffer.byteLength, byteOffset + byteLength);
				return recoveredBuffer.slice(byteOffset, end);
			}
		}
	}
	const length = toSafeLength(obj.length);
	if (length !== null) {
		const indexed = obj;
		const out = new Uint8Array(length);
		for (let i = 0; i < length; i += 1) {
			const byte = toByte(indexed[i]);
			if (byte === null) return null;
			out[i] = byte;
		}
		return out;
	}
	if (isPlainObject(v)) {
		const keys = Object.keys(obj);
		if (!keys.length) return null;
		const indexes = new Array(keys.length);
		let max = -1;
		for (let i = 0; i < keys.length; i += 1) {
			const idx = parseNonNegativeIntegerKey(keys[i]);
			if (idx === null || idx > MAX_RECOVERABLE_BYTES) return null;
			indexes[i] = idx;
			if (idx > max) max = idx;
		}
		const out = new Uint8Array(max + 1);
		for (let i = 0; i < keys.length; i += 1) {
			const key = keys[i];
			const byte = toByte(obj[key]);
			if (byte === null) return null;
			out[indexes[i]] = byte;
		}
		return out;
	}
	return null;
}
function coerceBodyToBytes(body) {
	return tryCoerceByteLikeObjectToUint8Array(body);
}
function summarizeBodyForDebug(body) {
	const jsType = body === null ? "null" : typeof body;
	const tag = safeObjectTag(body);
	const ctor = safeConstructorName(body);
	if (body === null || body === void 0) return {
		kind: "empty",
		jsType,
		tag,
		ctor
	};
	if (typeof body === "string") return {
		kind: "string",
		jsType,
		tag,
		ctor,
		textLength: body.length
	};
	if (isSerializedBodyEnvelope(body)) return {
		kind: `serialized:${typeof body.kind === "string" && body.kind ? body.kind : "bytes"}`,
		jsType,
		tag,
		ctor,
		base64Length: body.b64.length,
		mime: safeStringProp(body, "mime")
	};
	if (isArrayBufferLike(body)) return {
		kind: "ArrayBuffer",
		jsType,
		tag,
		ctor,
		byteLength: body.byteLength
	};
	try {
		if (ArrayBuffer.isView(body)) {
			const view = body;
			return {
				kind: ctor ? `TypedArray:${ctor}` : "TypedArray",
				jsType,
				tag,
				ctor,
				byteLength: view.byteLength
			};
		}
	} catch {}
	if (isBlobLike(body)) return {
		kind: "BlobLike",
		jsType,
		tag,
		ctor,
		byteLength: typeof body.size === "number" ? Number(body.size) : -1,
		mime: safeStringProp(body, "type")
	};
	const coerced = coerceBodyToBytes(body);
	if (coerced) return {
		kind: "coerced-bytes",
		jsType,
		tag,
		ctor,
		byteLength: coerced.byteLength
	};
	if (isObjectLike(body)) {
		const keys = Object.keys(body);
		return {
			kind: "object",
			jsType,
			tag,
			ctor,
			keyCount: keys.length,
			keys: keys.slice(0, DEBUG_KEYS_LIMIT)
		};
	}
	return {
		kind: "primitive",
		jsType,
		tag,
		ctor
	};
}
/**
* Serialize a GM_xmlhttpRequest body so it can be transported over
* `postMessage` / extension messaging.
*/
async function serializeBodyForPort(body) {
	if (body === null || body === void 0) return body;
	if (typeof body === "string") return body;
	if (isSerializedBodyEnvelope(body)) {
		if (body.kind === "blob") return {
			__votExtBody: true,
			kind: "blob",
			b64: body.b64,
			mime: safeStringProp(body, "mime")
		};
		return {
			__votExtBody: true,
			kind: "bytes",
			b64: body.b64
		};
	}
	if (isArrayBufferLike(body)) return createSerializedBytes(new Uint8Array(body));
	try {
		if (ArrayBuffer.isView(body)) return createSerializedBytes(viewAsBytes(body));
	} catch {}
	const blobData = await tryReadBlobBody(body);
	if (blobData) return createSerializedBlob(new Uint8Array(blobData.ab), blobData.mime);
	const recovered = coerceBodyToBytes(body);
	if (recovered) return createSerializedBytes(recovered);
	const summary = summarizeBodyForDebug(body);
	try {
		console.warn("[VOT Extension] Unsupported GM_xmlhttpRequest body type; coercing fallback.", summary);
	} catch {}
	if (isObjectLike(body)) {
		const json = safeJsonStringify(body);
		if (typeof json === "string") return json;
	}
	return String(body);
}
//#endregion
//#region src/extension/constants.ts
var MARK = "__VOT_EXT_BRIDGE__";
var TYPE_REQ = "VOT_EXT_REQ";
var TYPE_RES = "VOT_EXT_RES";
var TYPE_XHR_START = "VOT_EXT_XHR_START";
var TYPE_XHR_ABORT = "VOT_EXT_XHR_ABORT";
var TYPE_XHR_ACK = "VOT_EXT_XHR_ACK";
var TYPE_XHR_EVENT = "VOT_EXT_XHR_EVENT";
var TYPE_NOTIFY = "VOT_EXT_NOTIFY";
var BRIDGE_MESSAGE_TYPES = /* @__PURE__ */ new Set([
	TYPE_REQ,
	TYPE_RES,
	TYPE_NOTIFY,
	TYPE_XHR_START,
	TYPE_XHR_ABORT,
	TYPE_XHR_ACK,
	TYPE_XHR_EVENT
]);
function isOurMessage(data) {
	return Boolean(data && typeof data === "object" && data["__VOT_EXT_BRIDGE__"] === true && typeof data.type === "string" && BRIDGE_MESSAGE_TYPES.has(data.type));
}
//#endregion
//#region src/extension/bridgeTransport.ts
function markMessage(payload) {
	return {
		...payload,
		[MARK]: true
	};
}
function toBridgeMessage(payload) {
	return markMessage(payload);
}
//#endregion
//#region src/extension/prelude.ts
var PRELUDE_BOOT_KEY = "__VOT_EXT_PRELUDE_BOOTED__";
var XHR_FALLBACK_TIMEOUT_GRACE_MS = 1e3;
var BRIDGE_REQUEST_TIMEOUT_MS = 15e3;
var REQUEST_ID_PREFIX = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now().toString(36)}_${Math.random().toString(36).slice(2)}`;
function asRecord(value) {
	return value && typeof value === "object" ? value : {};
}
function toFiniteNumber(value) {
	if (value == null) return void 0;
	const parsed = Number(value);
	return Number.isFinite(parsed) ? parsed : void 0;
}
/**
* Extension prelude script (MAIN world content script).
*
* Why MAIN world?
* - The VOT codebase relies on page-context events and direct media controls on
*   some sites (YouTube subtitles/lang detection, VK Video, NicoNico, etc.).
* - MAIN world scripts do not have WebExtension APIs, so we expose a tiny userscript-like API
*   surface by talking to `src/extension/bridge.ts` via globalThis.postMessage.
*/
function postToBridge(payload) {
	globalThis.postMessage(toBridgeMessage(payload), "*");
}
function sanitizeNotificationDetails(details) {
	const d = asRecord(details);
	return {
		title: d.title != null ? String(d.title) : void 0,
		text: d.text != null ? String(d.text) : void 0,
		image: d.image != null ? String(d.image) : void 0,
		silent: !!d.silent,
		timeout: toFiniteNumber(d.timeout),
		tag: d.tag != null ? String(d.tag) : void 0
	};
}
var seq = 0;
var pending = /* @__PURE__ */ new Map();
function makeId() {
	seq += 1;
	return `${REQUEST_ID_PREFIX}_${seq.toString(36)}`;
}
function request(action, payload = {}) {
	const id = makeId();
	return new Promise((resolve, reject) => {
		const timeoutId = globalThis.setTimeout(() => {
			pending.delete(id);
			reject(/* @__PURE__ */ new Error(`VOT bridge timeout for ${action}`));
		}, BRIDGE_REQUEST_TIMEOUT_MS);
		pending.set(id, {
			resolve: (value) => resolve(value),
			reject,
			timeoutId
		});
		postToBridge({
			type: TYPE_REQ,
			id,
			action,
			payload
		});
	});
}
var xhrCallbacks = /* @__PURE__ */ new Map();
function callXhrCallback(fn, arg) {
	try {
		if (typeof fn === "function") fn(arg);
	} catch (err) {
		console.error("[VOT Extension] GM_xmlhttpRequest callback error", err);
	}
}
function createXhrSettleHandler(callbackName, original, settleState, resolve, reject) {
	return (value) => {
		callXhrCallback(original[callbackName], value);
		if (settleState.isSettled) return;
		settleState.isSettled = true;
		if (callbackName === "onload") {
			resolve(value);
			return;
		}
		reject(value);
	};
}
function popXhrCallbacks(requestId) {
	const state = xhrCallbacks.get(requestId);
	if (!state) return null;
	state.settled = true;
	xhrCallbacks.delete(requestId);
	if (state.timeoutId !== null) clearTimeout(state.timeoutId);
	return state.callbacks;
}
function armXhrFallbackWatchdog(requestId, state) {
	if (state.timeoutId !== null) {
		clearTimeout(state.timeoutId);
		state.timeoutId = null;
	}
	if (state.settled || !state.acknowledged || !Number.isFinite(state.timeoutMs) || state.timeoutMs <= 0) return;
	state.timeoutId = globalThis.setTimeout(() => {
		const current = xhrCallbacks.get(requestId);
		if (!current || current.settled) return;
		debug.warn("[VOT EXT][prelude] GM_xmlhttpRequest timeout fallback fired", {
			requestId,
			timeoutMs: current.timeoutMs,
			state: "terminal",
			lastBridgeEventAt: current.lastBridgeEventAt || null
		});
		const callbackFns = popXhrCallbacks(requestId);
		if (!callbackFns) return;
		try {
			postToBridge({
				type: TYPE_XHR_ABORT,
				requestId
			});
		} catch {}
		callXhrCallback(callbackFns.ontimeout, {
			finalUrl: String(current.callbacks.url || ""),
			readyState: 4,
			status: 0,
			statusText: "",
			responseHeaders: "",
			response: null,
			responseText: "",
			error: "Timeout"
		});
	}, state.timeoutMs + XHR_FALLBACK_TIMEOUT_GRACE_MS);
}
function toSerializableXhrDetails(details) {
	return {
		method: details.method,
		url: details.url,
		headers: details.headers,
		data: summarizeBodyForDebug(details.data),
		timeout: details.timeout,
		responseType: details.responseType,
		anonymous: details.anonymous,
		withCredentials: details.withCredentials
	};
}
async function toBridgeXhrDetails(details) {
	const sourceBodySummary = summarizeBodyForDebug(details.data);
	const serializedData = await serializeBodyForPort(details.data);
	const serializedBodySummary = summarizeBodyForDebug(serializedData);
	debug.log("[VOT EXT][prelude] GM_xmlhttpRequest body serialized", {
		url: details.url,
		method: details.method,
		from: sourceBodySummary,
		to: serializedBodySummary
	});
	if (typeof serializedData === "string" && /^\[object [^\]]+\]$/.test(serializedData.trim())) debug.warn("[VOT EXT][prelude] suspicious serialized body string", {
		url: details.url,
		method: details.method,
		serializedBody: serializedData,
		sourceBody: sourceBodySummary
	});
	return {
		method: details.method,
		url: details.url,
		headers: details.headers,
		data: serializedData,
		timeout: details.timeout,
		responseType: details.responseType,
		anonymous: details.anonymous,
		withCredentials: details.withCredentials
	};
}
function extractXhrStatus(data) {
	const src = asRecord(data);
	return {
		status: src.status ?? null,
		statusText: src.statusText ?? null,
		readyState: src.readyState ?? null,
		finalUrl: src.finalUrl ?? null
	};
}
function makeXhrTerminalErrorPayload(callbacks, error) {
	return {
		finalUrl: String(callbacks.url ?? ""),
		readyState: 4,
		status: 0,
		statusText: "",
		responseHeaders: "",
		response: null,
		responseText: "",
		error
	};
}
function installPageGmPolyfills() {
	globalThis.GM_notification = (details) => {
		try {
			postToBridge({
				type: TYPE_NOTIFY,
				details: sanitizeNotificationDetails(details)
			});
		} catch {}
	};
	globalThis.GM_addStyle = (css) => {
		const style = document.createElement("style");
		style.textContent = String(css ?? "");
		(document.head || document.documentElement).appendChild(style);
		return style;
	};
	globalThis.GM_xmlhttpRequest = (details) => {
		const requestId = makeId();
		const callbacks = asRecord(details);
		const timeoutMs = Number(callbacks.timeout ?? 0);
		const callbackState = {
			callbacks,
			timeoutId: null,
			timeoutMs: Number.isFinite(timeoutMs) ? timeoutMs : 0,
			acknowledged: false,
			settled: false,
			lastBridgeEventAt: 0
		};
		xhrCallbacks.set(requestId, callbackState);
		let active = true;
		debug.log("[VOT EXT][prelude] GM_xmlhttpRequest", {
			requestId,
			state: "created",
			timeoutMs: callbackState.timeoutMs,
			details: toSerializableXhrDetails(callbacks)
		});
		const startRequest = async () => {
			try {
				if (!active || !xhrCallbacks.has(requestId)) return;
				const requestDetails = await toBridgeXhrDetails(callbacks);
				if (!active || !xhrCallbacks.has(requestId)) return;
				debug.log("[VOT EXT][prelude] GM_xmlhttpRequest post TYPE_XHR_START", {
					requestId,
					details: toSerializableXhrDetails(callbacks)
				});
				postToBridge({
					type: TYPE_XHR_START,
					requestId,
					details: requestDetails
				});
			} catch (err) {
				if (!active || !xhrCallbacks.has(requestId)) return;
				active = false;
				const errorMsg = toErrorMessage(err);
				debug.log("[VOT EXT][prelude] GM_xmlhttpRequest start error", {
					requestId,
					error: errorMsg
				});
				callXhrCallback(popXhrCallbacks(requestId)?.onerror, makeXhrTerminalErrorPayload(callbacks, errorMsg));
			}
		};
		startRequest();
		return { abort: () => {
			if (!active) return;
			active = false;
			debug.warn("[VOT EXT][prelude] GM_xmlhttpRequest abort called", { requestId });
			popXhrCallbacks(requestId);
			postToBridge({
				type: TYPE_XHR_ABORT,
				requestId
			});
		} };
	};
	const gmPromiseXmlHttpRequest = (details) => {
		const original = asRecord(details);
		let abortFn = null;
		const p = new Promise((resolve, reject) => {
			const wrapped = { ...original };
			const settleState = { isSettled: false };
			wrapped.onload = createXhrSettleHandler("onload", original, settleState, resolve, reject);
			wrapped.onerror = createXhrSettleHandler("onerror", original, settleState, resolve, reject);
			wrapped.ontimeout = createXhrSettleHandler("ontimeout", original, settleState, resolve, reject);
			wrapped.onabort = createXhrSettleHandler("onabort", original, settleState, resolve, reject);
			const ctrl = globalThis.GM_xmlhttpRequest(wrapped);
			abortFn = ctrl && typeof ctrl.abort === "function" ? ctrl.abort.bind(ctrl) : null;
		});
		p.abort = () => {
			try {
				abortFn?.();
			} catch {}
		};
		return p;
	};
	globalThis.GM = {
		getValue: (key, def) => request("gm_getValue", {
			key,
			def
		}),
		setValue: (key, value) => request("gm_setValue", {
			key,
			value
		}),
		deleteValue: (key) => request("gm_deleteValue", { key }),
		listValues: () => request("gm_listValues"),
		getValues: (defaults) => request("gm_getValues", { defaults }),
		notification: (details) => {
			postToBridge({
				type: TYPE_NOTIFY,
				details: sanitizeNotificationDetails(details)
			});
		},
		xmlHttpRequest: (details) => gmPromiseXmlHttpRequest(details)
	};
	globalThis.GM_info = {
		script: {
			name: "VOT Extension",
			version: "0.0.0"
		},
		scriptHandler: "VOT Extension",
		version: "0.0.0"
	};
}
function wireMessageHandlers() {
	globalThis.addEventListener("message", (event) => {
		if (event.source !== globalThis.window) return;
		const data = event.data;
		if (!isOurMessage(data)) return;
		if (handlePromiseResponse(data)) return;
		if (handleXhrAck(data)) return;
		handleXhrEvent(data);
	});
}
function handlePromiseResponse(data) {
	if (data.type !== "VOT_EXT_RES") return false;
	const id = String(data.id ?? "");
	const item = pending.get(id);
	if (!item) return true;
	pending.delete(id);
	clearTimeout(item.timeoutId);
	if (data.ok) item.resolve(data.result);
	else item.reject(new Error(toErrorMessage(data.error ?? "Bridge error")));
	return true;
}
function handleXhrAck(data) {
	if (data.type !== "VOT_EXT_XHR_ACK") return false;
	const requestId = String(data.requestId ?? "");
	const state = xhrCallbacks.get(requestId);
	if (!state) return true;
	state.acknowledged = true;
	state.lastBridgeEventAt = Date.now();
	armXhrFallbackWatchdog(requestId, state);
	debug.log("[VOT EXT][prelude] XHR acknowledged", {
		requestId,
		state: "acknowledged",
		timeoutMs: state.timeoutMs,
		payload: data.payload ?? null
	});
	return true;
}
function logXhrEvent(requestId, kind, payload) {
	debug.log("[VOT EXT][prelude] XHR event", {
		requestId,
		state: kind === "progress" ? "in_flight" : "terminal",
		kind,
		...extractXhrStatus(payload.response ?? payload.error ?? payload.progress)
	});
}
function finalizeXhrLoad(requestId, callbacks, payload) {
	debug.log("[VOT EXT][prelude] XHR terminal load", {
		requestId,
		state: "terminal",
		...extractXhrStatus(payload.response)
	});
	callXhrCallback(callbacks.onload, payload.response);
	popXhrCallbacks(requestId);
}
function finalizeXhrFailure(requestId, callbacks, payload, kind) {
	const logger = kind === "error" ? debug.error : debug.warn;
	const callbackName = {
		error: "onerror",
		timeout: "ontimeout",
		abort: "onabort"
	}[kind];
	logger(`[VOT EXT][prelude] XHR terminal ${kind}`, {
		requestId,
		state: "terminal",
		...extractXhrStatus(payload.error),
		error: payload?.error?.error ?? null
	});
	callXhrCallback(callbacks[callbackName], payload.error);
	popXhrCallbacks(requestId);
}
function handleXhrEvent(data) {
	if (data.type !== "VOT_EXT_XHR_EVENT") return;
	const requestId = String(data.requestId ?? "");
	const state = xhrCallbacks.get(requestId);
	if (!state) return;
	const callbacks = state.callbacks;
	const payload = asRecord(data.payload);
	const kind = String(payload.type ?? "");
	logXhrEvent(requestId, kind, payload);
	if (kind === "progress") {
		state.lastBridgeEventAt = Date.now();
		armXhrFallbackWatchdog(requestId, state);
		callXhrCallback(callbacks.onprogress, payload.progress);
		return;
	}
	if (kind === "load") {
		finalizeXhrLoad(requestId, callbacks, payload);
		return;
	}
	if (kind === "error" || kind === "timeout" || kind === "abort") {
		finalizeXhrFailure(requestId, callbacks, payload, kind);
		return;
	}
	debug.warn("[VOT EXT][prelude] unexpected XHR bridge event", {
		requestId,
		kind,
		payload
	});
}
var preludeGlobal = globalThis;
if (preludeGlobal[PRELUDE_BOOT_KEY]) debug.log("[VOT EXT][prelude] already initialized");
else {
	preludeGlobal[PRELUDE_BOOT_KEY] = true;
	const initializePrelude = async () => {
		installPageGmPolyfills();
		wireMessageHandlers();
		try {
			const { manifest } = await request("handshake");
			const gmInfo = globalThis.GM_info;
			if (manifest?.name) gmInfo.script.name = manifest.name;
			if (manifest?.version) {
				gmInfo.script.version = manifest.version;
				gmInfo.version = manifest.version;
			}
		} catch {}
	};
	(async () => {
		try {
			await initializePrelude();
		} catch {}
	})();
}
//#endregion

//# sourceMappingURL=prelude.module.js.map