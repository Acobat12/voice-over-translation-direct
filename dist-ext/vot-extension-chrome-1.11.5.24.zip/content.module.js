var wc = Object.defineProperty;
var Sc = (n, t, e) => t in n ? wc(n, t, { enumerable: !0, configurable: !0, writable: !0, value: e }) : n[t] = e;
var u = (n, t, e) => Sc(n, typeof t != "symbol" ? t + "" : t, e);
const et = {
  host: "api.browser.yandex.ru",
  hostVOT: "vot.toil.cc/v1",
  hostWorker: "vot-worker.toil.cc",
  mediaProxy: "media-proxy.toil.cc",
  userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 YaBrowser/25.4.0.0 Safari/537.36",
  componentVersion: "25.6.0.2259",
  hmac: "bt8xH3VOlb4mqf0nqAibnDOoiPlXsisf",
  defaultDuration: 343,
  minChunkSize: 5295308,
  loggerLevel: 1,
  version: "2.4.12"
};
var De;
(function(n) {
  n[n.DEBUG = 0] = "DEBUG", n[n.INFO = 1] = "INFO", n[n.WARN = 2] = "WARN", n[n.ERROR = 3] = "ERROR", n[n.SILENCE = 4] = "SILENCE";
})(De || (De = {}));
const Ct = class Ct {
  static canLog(t) {
    return et.loggerLevel <= t;
  }
  static log(...t) {
    Ct.canLog(De.DEBUG) && console.log(Ct.prefix, ...t);
  }
  static info(...t) {
    Ct.canLog(De.INFO) && console.info(Ct.prefix, ...t);
  }
  static warn(...t) {
    Ct.canLog(De.WARN) && console.warn(Ct.prefix, ...t);
  }
  static error(...t) {
    Ct.canLog(De.ERROR) && console.error(Ct.prefix, ...t);
  }
};
u(Ct, "prefix", `[vot.js v${et.version}]`);
let D = Ct;
function Tc() {
  let n = 0, t = 0;
  for (let i = 0; i < 28; i += 7) {
    let s = this.buf[this.pos++];
    if (n |= (s & 127) << i, (s & 128) == 0)
      return this.assertBounds(), [n, t];
  }
  let e = this.buf[this.pos++];
  if (n |= (e & 15) << 28, t = (e & 112) >> 4, (e & 128) == 0)
    return this.assertBounds(), [n, t];
  for (let i = 3; i <= 31; i += 7) {
    let s = this.buf[this.pos++];
    if (t |= (s & 127) << i, (s & 128) == 0)
      return this.assertBounds(), [n, t];
  }
  throw new Error("invalid varint");
}
function Ki(n, t, e) {
  for (let o = 0; o < 28; o = o + 7) {
    const r = n >>> o, a = !(!(r >>> 7) && t == 0), l = (a ? r | 128 : r) & 255;
    if (e.push(l), !a)
      return;
  }
  const i = n >>> 28 & 15 | (t & 7) << 4, s = t >> 3 != 0;
  if (e.push((s ? i | 128 : i) & 255), !!s) {
    for (let o = 3; o < 31; o = o + 7) {
      const r = t >>> o, a = !!(r >>> 7), l = (a ? r | 128 : r) & 255;
      if (e.push(l), !a)
        return;
    }
    e.push(t >>> 31 & 1);
  }
}
const ni = 4294967296;
function Fo(n) {
  const t = n[0] === "-";
  t && (n = n.slice(1));
  const e = 1e6;
  let i = 0, s = 0;
  function o(r, a) {
    const l = Number(n.slice(r, a));
    s *= e, i = i * e + l, i >= ni && (s = s + (i / ni | 0), i = i % ni);
  }
  return o(-24, -18), o(-18, -12), o(-12, -6), o(-6), t ? xl(i, s) : Js(i, s);
}
function kc(n, t) {
  let e = Js(n, t);
  const i = e.hi & 2147483648;
  i && (e = xl(e.lo, e.hi));
  const s = Al(e.lo, e.hi);
  return i ? "-" + s : s;
}
function Al(n, t) {
  if ({ lo: n, hi: t } = Lc(n, t), t <= 2097151)
    return String(ni * t + n);
  const e = n & 16777215, i = (n >>> 24 | t << 8) & 16777215, s = t >> 16 & 65535;
  let o = e + i * 6777216 + s * 6710656, r = i + s * 8147497, a = s * 2;
  const l = 1e7;
  return o >= l && (r += Math.floor(o / l), o %= l), r >= l && (a += Math.floor(r / l), r %= l), a.toString() + No(r) + No(o);
}
function Lc(n, t) {
  return { lo: n >>> 0, hi: t >>> 0 };
}
function Js(n, t) {
  return { lo: n | 0, hi: t | 0 };
}
function xl(n, t) {
  return t = ~t, n ? n = ~n + 1 : t += 1, Js(n, t);
}
const No = (n) => {
  const t = String(n);
  return "0000000".slice(t.length) + t;
};
function Uo(n, t) {
  if (n >= 0) {
    for (; n > 127; )
      t.push(n & 127 | 128), n = n >>> 7;
    t.push(n);
  } else {
    for (let e = 0; e < 9; e++)
      t.push(n & 127 | 128), n = n >> 7;
    t.push(1);
  }
}
function Ac() {
  let n = this.buf[this.pos++], t = n & 127;
  if ((n & 128) == 0)
    return this.assertBounds(), t;
  if (n = this.buf[this.pos++], t |= (n & 127) << 7, (n & 128) == 0)
    return this.assertBounds(), t;
  if (n = this.buf[this.pos++], t |= (n & 127) << 14, (n & 128) == 0)
    return this.assertBounds(), t;
  if (n = this.buf[this.pos++], t |= (n & 127) << 21, (n & 128) == 0)
    return this.assertBounds(), t;
  n = this.buf[this.pos++], t |= (n & 15) << 28;
  for (let e = 5; (n & 128) !== 0 && e < 10; e++)
    n = this.buf[this.pos++];
  if ((n & 128) != 0)
    throw new Error("invalid varint");
  return this.assertBounds(), t >>> 0;
}
const Ot = /* @__PURE__ */ xc();
function xc() {
  const n = new DataView(new ArrayBuffer(8));
  if (typeof BigInt == "function" && typeof n.getBigInt64 == "function" && typeof n.getBigUint64 == "function" && typeof n.setBigInt64 == "function" && typeof n.setBigUint64 == "function" && (!!globalThis.Deno || typeof process != "object" || typeof process.env != "object" || process.env.BUF_BIGINT_DISABLE !== "1")) {
    const e = BigInt("-9223372036854775808"), i = BigInt("9223372036854775807"), s = BigInt("0"), o = BigInt("18446744073709551615");
    return {
      zero: BigInt(0),
      supported: !0,
      parse(r) {
        const a = typeof r == "bigint" ? r : BigInt(r);
        if (a > i || a < e)
          throw new Error(`invalid int64: ${r}`);
        return a;
      },
      uParse(r) {
        const a = typeof r == "bigint" ? r : BigInt(r);
        if (a > o || a < s)
          throw new Error(`invalid uint64: ${r}`);
        return a;
      },
      enc(r) {
        return n.setBigInt64(0, this.parse(r), !0), {
          lo: n.getInt32(0, !0),
          hi: n.getInt32(4, !0)
        };
      },
      uEnc(r) {
        return n.setBigInt64(0, this.uParse(r), !0), {
          lo: n.getInt32(0, !0),
          hi: n.getInt32(4, !0)
        };
      },
      dec(r, a) {
        return n.setInt32(0, r, !0), n.setInt32(4, a, !0), n.getBigInt64(0, !0);
      },
      uDec(r, a) {
        return n.setInt32(0, r, !0), n.setInt32(4, a, !0), n.getBigUint64(0, !0);
      }
    };
  }
  return {
    zero: "0",
    supported: !1,
    parse(e) {
      return typeof e != "string" && (e = e.toString()), $o(e), e;
    },
    uParse(e) {
      return typeof e != "string" && (e = e.toString()), Ho(e), e;
    },
    enc(e) {
      return typeof e != "string" && (e = e.toString()), $o(e), Fo(e);
    },
    uEnc(e) {
      return typeof e != "string" && (e = e.toString()), Ho(e), Fo(e);
    },
    dec(e, i) {
      return kc(e, i);
    },
    uDec(e, i) {
      return Al(e, i);
    }
  };
}
function $o(n) {
  if (!/^-?[0-9]+$/.test(n))
    throw new Error("invalid int64: " + n);
}
function Ho(n) {
  if (!/^[0-9]+$/.test(n))
    throw new Error("invalid uint64: " + n);
}
const Yi = /* @__PURE__ */ Symbol.for("@bufbuild/protobuf/text-encoding");
function Vl() {
  if (globalThis[Yi] == null) {
    const n = new globalThis.TextEncoder(), t = new globalThis.TextDecoder();
    globalThis[Yi] = {
      encodeUtf8(e) {
        return n.encode(e);
      },
      decodeUtf8(e) {
        return t.decode(e);
      },
      checkUtf8(e) {
        try {
          return encodeURIComponent(e), !0;
        } catch {
          return !1;
        }
      }
    };
  }
  return globalThis[Yi];
}
var jt;
(function(n) {
  n[n.Varint = 0] = "Varint", n[n.Bit64 = 1] = "Bit64", n[n.LengthDelimited = 2] = "LengthDelimited", n[n.StartGroup = 3] = "StartGroup", n[n.EndGroup = 4] = "EndGroup", n[n.Bit32 = 5] = "Bit32";
})(jt || (jt = {}));
const Vc = 34028234663852886e22, Cc = -34028234663852886e22, Ec = 4294967295, Ic = 2147483647, Pc = -2147483648;
class Z {
  constructor(t = Vl().encodeUtf8) {
    this.encodeUtf8 = t, this.stack = [], this.chunks = [], this.buf = [];
  }
  /**
   * Return all bytes written and reset this writer.
   */
  finish() {
    this.buf.length && (this.chunks.push(new Uint8Array(this.buf)), this.buf = []);
    let t = 0;
    for (let s = 0; s < this.chunks.length; s++)
      t += this.chunks[s].length;
    let e = new Uint8Array(t), i = 0;
    for (let s = 0; s < this.chunks.length; s++)
      e.set(this.chunks[s], i), i += this.chunks[s].length;
    return this.chunks = [], e;
  }
  /**
   * Start a new fork for length-delimited data like a message
   * or a packed repeated field.
   *
   * Must be joined later with `join()`.
   */
  fork() {
    return this.stack.push({ chunks: this.chunks, buf: this.buf }), this.chunks = [], this.buf = [], this;
  }
  /**
   * Join the last fork. Write its length and bytes, then
   * return to the previous state.
   */
  join() {
    let t = this.finish(), e = this.stack.pop();
    if (!e)
      throw new Error("invalid state, fork stack empty");
    return this.chunks = e.chunks, this.buf = e.buf, this.uint32(t.byteLength), this.raw(t);
  }
  /**
   * Writes a tag (field number and wire type).
   *
   * Equivalent to `uint32( (fieldNo << 3 | type) >>> 0 )`.
   *
   * Generated code should compute the tag ahead of time and call `uint32()`.
   */
  tag(t, e) {
    return this.uint32((t << 3 | e) >>> 0);
  }
  /**
   * Write a chunk of raw bytes.
   */
  raw(t) {
    return this.buf.length && (this.chunks.push(new Uint8Array(this.buf)), this.buf = []), this.chunks.push(t), this;
  }
  /**
   * Write a `uint32` value, an unsigned 32 bit varint.
   */
  uint32(t) {
    for (Wo(t); t > 127; )
      this.buf.push(t & 127 | 128), t = t >>> 7;
    return this.buf.push(t), this;
  }
  /**
   * Write a `int32` value, a signed 32 bit varint.
   */
  int32(t) {
    return ji(t), Uo(t, this.buf), this;
  }
  /**
   * Write a `bool` value, a variant.
   */
  bool(t) {
    return this.buf.push(t ? 1 : 0), this;
  }
  /**
   * Write a `bytes` value, length-delimited arbitrary data.
   */
  bytes(t) {
    return this.uint32(t.byteLength), this.raw(t);
  }
  /**
   * Write a `string` value, length-delimited data converted to UTF-8 text.
   */
  string(t) {
    let e = this.encodeUtf8(t);
    return this.uint32(e.byteLength), this.raw(e);
  }
  /**
   * Write a `float` value, 32-bit floating point number.
   */
  float(t) {
    Mc(t);
    let e = new Uint8Array(4);
    return new DataView(e.buffer).setFloat32(0, t, !0), this.raw(e);
  }
  /**
   * Write a `double` value, a 64-bit floating point number.
   */
  double(t) {
    let e = new Uint8Array(8);
    return new DataView(e.buffer).setFloat64(0, t, !0), this.raw(e);
  }
  /**
   * Write a `fixed32` value, an unsigned, fixed-length 32-bit integer.
   */
  fixed32(t) {
    Wo(t);
    let e = new Uint8Array(4);
    return new DataView(e.buffer).setUint32(0, t, !0), this.raw(e);
  }
  /**
   * Write a `sfixed32` value, a signed, fixed-length 32-bit integer.
   */
  sfixed32(t) {
    ji(t);
    let e = new Uint8Array(4);
    return new DataView(e.buffer).setInt32(0, t, !0), this.raw(e);
  }
  /**
   * Write a `sint32` value, a signed, zigzag-encoded 32-bit varint.
   */
  sint32(t) {
    return ji(t), t = (t << 1 ^ t >> 31) >>> 0, Uo(t, this.buf), this;
  }
  /**
   * Write a `fixed64` value, a signed, fixed-length 64-bit integer.
   */
  sfixed64(t) {
    let e = new Uint8Array(8), i = new DataView(e.buffer), s = Ot.enc(t);
    return i.setInt32(0, s.lo, !0), i.setInt32(4, s.hi, !0), this.raw(e);
  }
  /**
   * Write a `fixed64` value, an unsigned, fixed-length 64 bit integer.
   */
  fixed64(t) {
    let e = new Uint8Array(8), i = new DataView(e.buffer), s = Ot.uEnc(t);
    return i.setInt32(0, s.lo, !0), i.setInt32(4, s.hi, !0), this.raw(e);
  }
  /**
   * Write a `int64` value, a signed 64-bit varint.
   */
  int64(t) {
    let e = Ot.enc(t);
    return Ki(e.lo, e.hi, this.buf), this;
  }
  /**
   * Write a `sint64` value, a signed, zig-zag-encoded 64-bit varint.
   */
  sint64(t) {
    const e = Ot.enc(t), i = e.hi >> 31, s = e.lo << 1 ^ i, o = (e.hi << 1 | e.lo >>> 31) ^ i;
    return Ki(s, o, this.buf), this;
  }
  /**
   * Write a `uint64` value, an unsigned 64-bit varint.
   */
  uint64(t) {
    const e = Ot.uEnc(t);
    return Ki(e.lo, e.hi, this.buf), this;
  }
}
class N {
  constructor(t, e = Vl().decodeUtf8) {
    this.decodeUtf8 = e, this.varint64 = Tc, this.uint32 = Ac, this.buf = t, this.len = t.length, this.pos = 0, this.view = new DataView(t.buffer, t.byteOffset, t.byteLength);
  }
  /**
   * Reads a tag - field number and wire type.
   */
  tag() {
    let t = this.uint32(), e = t >>> 3, i = t & 7;
    if (e <= 0 || i < 0 || i > 5)
      throw new Error("illegal tag: field no " + e + " wire type " + i);
    return [e, i];
  }
  /**
   * Skip one element and return the skipped data.
   *
   * When skipping StartGroup, provide the tags field number to check for
   * matching field number in the EndGroup tag.
   */
  skip(t, e) {
    let i = this.pos;
    switch (t) {
      case jt.Varint:
        for (; this.buf[this.pos++] & 128; )
          ;
        break;
      // @ts-ignore TS7029: Fallthrough case in switch -- ignore instead of expect-error for compiler settings without noFallthroughCasesInSwitch: true
      case jt.Bit64:
        this.pos += 4;
      case jt.Bit32:
        this.pos += 4;
        break;
      case jt.LengthDelimited:
        let s = this.uint32();
        this.pos += s;
        break;
      case jt.StartGroup:
        for (; ; ) {
          const [o, r] = this.tag();
          if (r === jt.EndGroup) {
            if (e !== void 0 && o !== e)
              throw new Error("invalid end group tag");
            break;
          }
          this.skip(r, o);
        }
        break;
      default:
        throw new Error("cant skip wire type " + t);
    }
    return this.assertBounds(), this.buf.subarray(i, this.pos);
  }
  /**
   * Throws error if position in byte array is out of range.
   */
  assertBounds() {
    if (this.pos > this.len)
      throw new RangeError("premature EOF");
  }
  /**
   * Read a `int32` field, a signed 32 bit varint.
   */
  int32() {
    return this.uint32() | 0;
  }
  /**
   * Read a `sint32` field, a signed, zigzag-encoded 32-bit varint.
   */
  sint32() {
    let t = this.uint32();
    return t >>> 1 ^ -(t & 1);
  }
  /**
   * Read a `int64` field, a signed 64-bit varint.
   */
  int64() {
    return Ot.dec(...this.varint64());
  }
  /**
   * Read a `uint64` field, an unsigned 64-bit varint.
   */
  uint64() {
    return Ot.uDec(...this.varint64());
  }
  /**
   * Read a `sint64` field, a signed, zig-zag-encoded 64-bit varint.
   */
  sint64() {
    let [t, e] = this.varint64(), i = -(t & 1);
    return t = (t >>> 1 | (e & 1) << 31) ^ i, e = e >>> 1 ^ i, Ot.dec(t, e);
  }
  /**
   * Read a `bool` field, a variant.
   */
  bool() {
    let [t, e] = this.varint64();
    return t !== 0 || e !== 0;
  }
  /**
   * Read a `fixed32` field, an unsigned, fixed-length 32-bit integer.
   */
  fixed32() {
    return this.view.getUint32((this.pos += 4) - 4, !0);
  }
  /**
   * Read a `sfixed32` field, a signed, fixed-length 32-bit integer.
   */
  sfixed32() {
    return this.view.getInt32((this.pos += 4) - 4, !0);
  }
  /**
   * Read a `fixed64` field, an unsigned, fixed-length 64 bit integer.
   */
  fixed64() {
    return Ot.uDec(this.sfixed32(), this.sfixed32());
  }
  /**
   * Read a `fixed64` field, a signed, fixed-length 64-bit integer.
   */
  sfixed64() {
    return Ot.dec(this.sfixed32(), this.sfixed32());
  }
  /**
   * Read a `float` field, 32-bit floating point number.
   */
  float() {
    return this.view.getFloat32((this.pos += 4) - 4, !0);
  }
  /**
   * Read a `double` field, a 64-bit floating point number.
   */
  double() {
    return this.view.getFloat64((this.pos += 8) - 8, !0);
  }
  /**
   * Read a `bytes` field, length-delimited arbitrary data.
   */
  bytes() {
    let t = this.uint32(), e = this.pos;
    return this.pos += t, this.assertBounds(), this.buf.subarray(e, e + t);
  }
  /**
   * Read a `string` field, length-delimited data converted to UTF-8 text.
   */
  string() {
    return this.decodeUtf8(this.bytes());
  }
}
function ji(n) {
  if (typeof n == "string")
    n = Number(n);
  else if (typeof n != "number")
    throw new Error("invalid int32: " + typeof n);
  if (!Number.isInteger(n) || n > Ic || n < Pc)
    throw new Error("invalid int32: " + n);
}
function Wo(n) {
  if (typeof n == "string")
    n = Number(n);
  else if (typeof n != "number")
    throw new Error("invalid uint32: " + typeof n);
  if (!Number.isInteger(n) || n > Ec || n < 0)
    throw new Error("invalid uint32: " + n);
}
function Mc(n) {
  if (typeof n == "string") {
    const t = n;
    if (n = Number(n), Number.isNaN(n) && t !== "NaN")
      throw new Error("invalid float32: " + t);
  } else if (typeof n != "number")
    throw new Error("invalid float32: " + typeof n);
  if (Number.isFinite(n) && (n > Vc || n < Cc))
    throw new Error("invalid float32: " + n);
}
var vt;
(function(n) {
  n[n.NO_CONNECTION = 0] = "NO_CONNECTION", n[n.TRANSLATING = 10] = "TRANSLATING", n[n.STREAMING = 20] = "STREAMING", n[n.UNRECOGNIZED = -1] = "UNRECOGNIZED";
})(vt || (vt = {}));
function Oc(n) {
  switch (n) {
    case 0:
    case "NO_CONNECTION":
      return vt.NO_CONNECTION;
    case 10:
    case "TRANSLATING":
      return vt.TRANSLATING;
    case 20:
    case "STREAMING":
      return vt.STREAMING;
    default:
      return vt.UNRECOGNIZED;
  }
}
function Dc(n) {
  switch (n) {
    case vt.NO_CONNECTION:
      return "NO_CONNECTION";
    case vt.TRANSLATING:
      return "TRANSLATING";
    case vt.STREAMING:
      return "STREAMING";
    case vt.UNRECOGNIZED:
    default:
      return "UNRECOGNIZED";
  }
}
function zo() {
  return { target: "", targetUrl: "" };
}
const xe = {
  encode(n, t = new Z()) {
    return n.target !== "" && t.uint32(10).string(n.target), n.targetUrl !== "" && t.uint32(18).string(n.targetUrl), t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = zo();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.target = e.string();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.targetUrl = e.string();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      target: x(n.target) ? globalThis.String(n.target) : "",
      targetUrl: x(n.targetUrl) ? globalThis.String(n.targetUrl) : ""
    };
  },
  toJSON(n) {
    const t = {};
    return n.target !== "" && (t.target = n.target), n.targetUrl !== "" && (t.targetUrl = n.targetUrl), t;
  },
  create(n) {
    return xe.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = zo();
    return t.target = n.target ?? "", t.targetUrl = n.targetUrl ?? "", t;
  }
};
function qo() {
  return {
    url: "",
    deviceId: void 0,
    firstRequest: !1,
    duration: 0,
    unknown0: 0,
    language: "",
    forceSourceLang: !1,
    unknown1: 0,
    translationHelp: [],
    wasStream: !1,
    responseLanguage: "",
    unknown2: 0,
    unknown3: 0,
    bypassCache: !1,
    useLivelyVoice: !1,
    videoTitle: ""
  };
}
const Cl = {
  encode(n, t = new Z()) {
    n.url !== "" && t.uint32(26).string(n.url), n.deviceId !== void 0 && t.uint32(34).string(n.deviceId), n.firstRequest !== !1 && t.uint32(40).bool(n.firstRequest), n.duration !== 0 && t.uint32(49).double(n.duration), n.unknown0 !== 0 && t.uint32(56).int32(n.unknown0), n.language !== "" && t.uint32(66).string(n.language), n.forceSourceLang !== !1 && t.uint32(72).bool(n.forceSourceLang), n.unknown1 !== 0 && t.uint32(80).int32(n.unknown1);
    for (const e of n.translationHelp)
      xe.encode(e, t.uint32(90).fork()).join();
    return n.wasStream !== !1 && t.uint32(104).bool(n.wasStream), n.responseLanguage !== "" && t.uint32(114).string(n.responseLanguage), n.unknown2 !== 0 && t.uint32(120).int32(n.unknown2), n.unknown3 !== 0 && t.uint32(128).int32(n.unknown3), n.bypassCache !== !1 && t.uint32(136).bool(n.bypassCache), n.useLivelyVoice !== !1 && t.uint32(144).bool(n.useLivelyVoice), n.videoTitle !== "" && t.uint32(154).string(n.videoTitle), t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = qo();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 3: {
          if (o !== 26)
            break;
          s.url = e.string();
          continue;
        }
        case 4: {
          if (o !== 34)
            break;
          s.deviceId = e.string();
          continue;
        }
        case 5: {
          if (o !== 40)
            break;
          s.firstRequest = e.bool();
          continue;
        }
        case 6: {
          if (o !== 49)
            break;
          s.duration = e.double();
          continue;
        }
        case 7: {
          if (o !== 56)
            break;
          s.unknown0 = e.int32();
          continue;
        }
        case 8: {
          if (o !== 66)
            break;
          s.language = e.string();
          continue;
        }
        case 9: {
          if (o !== 72)
            break;
          s.forceSourceLang = e.bool();
          continue;
        }
        case 10: {
          if (o !== 80)
            break;
          s.unknown1 = e.int32();
          continue;
        }
        case 11: {
          if (o !== 90)
            break;
          s.translationHelp.push(xe.decode(e, e.uint32()));
          continue;
        }
        case 13: {
          if (o !== 104)
            break;
          s.wasStream = e.bool();
          continue;
        }
        case 14: {
          if (o !== 114)
            break;
          s.responseLanguage = e.string();
          continue;
        }
        case 15: {
          if (o !== 120)
            break;
          s.unknown2 = e.int32();
          continue;
        }
        case 16: {
          if (o !== 128)
            break;
          s.unknown3 = e.int32();
          continue;
        }
        case 17: {
          if (o !== 136)
            break;
          s.bypassCache = e.bool();
          continue;
        }
        case 18: {
          if (o !== 144)
            break;
          s.useLivelyVoice = e.bool();
          continue;
        }
        case 19: {
          if (o !== 154)
            break;
          s.videoTitle = e.string();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      url: x(n.url) ? globalThis.String(n.url) : "",
      deviceId: x(n.deviceId) ? globalThis.String(n.deviceId) : void 0,
      firstRequest: x(n.firstRequest) ? globalThis.Boolean(n.firstRequest) : !1,
      duration: x(n.duration) ? globalThis.Number(n.duration) : 0,
      unknown0: x(n.unknown0) ? globalThis.Number(n.unknown0) : 0,
      language: x(n.language) ? globalThis.String(n.language) : "",
      forceSourceLang: x(n.forceSourceLang) ? globalThis.Boolean(n.forceSourceLang) : !1,
      unknown1: x(n.unknown1) ? globalThis.Number(n.unknown1) : 0,
      translationHelp: globalThis.Array.isArray(n?.translationHelp) ? n.translationHelp.map((t) => xe.fromJSON(t)) : [],
      wasStream: x(n.wasStream) ? globalThis.Boolean(n.wasStream) : !1,
      responseLanguage: x(n.responseLanguage) ? globalThis.String(n.responseLanguage) : "",
      unknown2: x(n.unknown2) ? globalThis.Number(n.unknown2) : 0,
      unknown3: x(n.unknown3) ? globalThis.Number(n.unknown3) : 0,
      bypassCache: x(n.bypassCache) ? globalThis.Boolean(n.bypassCache) : !1,
      useLivelyVoice: x(n.useLivelyVoice) ? globalThis.Boolean(n.useLivelyVoice) : !1,
      videoTitle: x(n.videoTitle) ? globalThis.String(n.videoTitle) : ""
    };
  },
  toJSON(n) {
    const t = {};
    return n.url !== "" && (t.url = n.url), n.deviceId !== void 0 && (t.deviceId = n.deviceId), n.firstRequest !== !1 && (t.firstRequest = n.firstRequest), n.duration !== 0 && (t.duration = n.duration), n.unknown0 !== 0 && (t.unknown0 = Math.round(n.unknown0)), n.language !== "" && (t.language = n.language), n.forceSourceLang !== !1 && (t.forceSourceLang = n.forceSourceLang), n.unknown1 !== 0 && (t.unknown1 = Math.round(n.unknown1)), n.translationHelp?.length && (t.translationHelp = n.translationHelp.map((e) => xe.toJSON(e))), n.wasStream !== !1 && (t.wasStream = n.wasStream), n.responseLanguage !== "" && (t.responseLanguage = n.responseLanguage), n.unknown2 !== 0 && (t.unknown2 = Math.round(n.unknown2)), n.unknown3 !== 0 && (t.unknown3 = Math.round(n.unknown3)), n.bypassCache !== !1 && (t.bypassCache = n.bypassCache), n.useLivelyVoice !== !1 && (t.useLivelyVoice = n.useLivelyVoice), n.videoTitle !== "" && (t.videoTitle = n.videoTitle), t;
  },
  create(n) {
    return Cl.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = qo();
    return t.url = n.url ?? "", t.deviceId = n.deviceId ?? void 0, t.firstRequest = n.firstRequest ?? !1, t.duration = n.duration ?? 0, t.unknown0 = n.unknown0 ?? 0, t.language = n.language ?? "", t.forceSourceLang = n.forceSourceLang ?? !1, t.unknown1 = n.unknown1 ?? 0, t.translationHelp = n.translationHelp?.map((e) => xe.fromPartial(e)) || [], t.wasStream = n.wasStream ?? !1, t.responseLanguage = n.responseLanguage ?? "", t.unknown2 = n.unknown2 ?? 0, t.unknown3 = n.unknown3 ?? 0, t.bypassCache = n.bypassCache ?? !1, t.useLivelyVoice = n.useLivelyVoice ?? !1, t.videoTitle = n.videoTitle ?? "", t;
  }
};
function Go() {
  return {
    url: void 0,
    duration: void 0,
    status: 0,
    remainingTime: void 0,
    unknown0: void 0,
    translationId: "",
    language: void 0,
    message: void 0,
    isLivelyVoice: !1,
    unknown2: void 0,
    shouldRetry: void 0,
    unknown3: void 0
  };
}
const El = {
  encode(n, t = new Z()) {
    return n.url !== void 0 && t.uint32(10).string(n.url), n.duration !== void 0 && t.uint32(17).double(n.duration), n.status !== 0 && t.uint32(32).int32(n.status), n.remainingTime !== void 0 && t.uint32(40).int32(n.remainingTime), n.unknown0 !== void 0 && t.uint32(48).int32(n.unknown0), n.translationId !== "" && t.uint32(58).string(n.translationId), n.language !== void 0 && t.uint32(66).string(n.language), n.message !== void 0 && t.uint32(74).string(n.message), n.isLivelyVoice !== !1 && t.uint32(80).bool(n.isLivelyVoice), n.unknown2 !== void 0 && t.uint32(88).int32(n.unknown2), n.shouldRetry !== void 0 && t.uint32(96).int32(n.shouldRetry), n.unknown3 !== void 0 && t.uint32(104).int32(n.unknown3), t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Go();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.url = e.string();
          continue;
        }
        case 2: {
          if (o !== 17)
            break;
          s.duration = e.double();
          continue;
        }
        case 4: {
          if (o !== 32)
            break;
          s.status = e.int32();
          continue;
        }
        case 5: {
          if (o !== 40)
            break;
          s.remainingTime = e.int32();
          continue;
        }
        case 6: {
          if (o !== 48)
            break;
          s.unknown0 = e.int32();
          continue;
        }
        case 7: {
          if (o !== 58)
            break;
          s.translationId = e.string();
          continue;
        }
        case 8: {
          if (o !== 66)
            break;
          s.language = e.string();
          continue;
        }
        case 9: {
          if (o !== 74)
            break;
          s.message = e.string();
          continue;
        }
        case 10: {
          if (o !== 80)
            break;
          s.isLivelyVoice = e.bool();
          continue;
        }
        case 11: {
          if (o !== 88)
            break;
          s.unknown2 = e.int32();
          continue;
        }
        case 12: {
          if (o !== 96)
            break;
          s.shouldRetry = e.int32();
          continue;
        }
        case 13: {
          if (o !== 104)
            break;
          s.unknown3 = e.int32();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      url: x(n.url) ? globalThis.String(n.url) : void 0,
      duration: x(n.duration) ? globalThis.Number(n.duration) : void 0,
      status: x(n.status) ? globalThis.Number(n.status) : 0,
      remainingTime: x(n.remainingTime) ? globalThis.Number(n.remainingTime) : void 0,
      unknown0: x(n.unknown0) ? globalThis.Number(n.unknown0) : void 0,
      translationId: x(n.translationId) ? globalThis.String(n.translationId) : "",
      language: x(n.language) ? globalThis.String(n.language) : void 0,
      message: x(n.message) ? globalThis.String(n.message) : void 0,
      isLivelyVoice: x(n.isLivelyVoice) ? globalThis.Boolean(n.isLivelyVoice) : !1,
      unknown2: x(n.unknown2) ? globalThis.Number(n.unknown2) : void 0,
      shouldRetry: x(n.shouldRetry) ? globalThis.Number(n.shouldRetry) : void 0,
      unknown3: x(n.unknown3) ? globalThis.Number(n.unknown3) : void 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.url !== void 0 && (t.url = n.url), n.duration !== void 0 && (t.duration = n.duration), n.status !== 0 && (t.status = Math.round(n.status)), n.remainingTime !== void 0 && (t.remainingTime = Math.round(n.remainingTime)), n.unknown0 !== void 0 && (t.unknown0 = Math.round(n.unknown0)), n.translationId !== "" && (t.translationId = n.translationId), n.language !== void 0 && (t.language = n.language), n.message !== void 0 && (t.message = n.message), n.isLivelyVoice !== !1 && (t.isLivelyVoice = n.isLivelyVoice), n.unknown2 !== void 0 && (t.unknown2 = Math.round(n.unknown2)), n.shouldRetry !== void 0 && (t.shouldRetry = Math.round(n.shouldRetry)), n.unknown3 !== void 0 && (t.unknown3 = Math.round(n.unknown3)), t;
  },
  create(n) {
    return El.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Go();
    return t.url = n.url ?? void 0, t.duration = n.duration ?? void 0, t.status = n.status ?? 0, t.remainingTime = n.remainingTime ?? void 0, t.unknown0 = n.unknown0 ?? void 0, t.translationId = n.translationId ?? "", t.language = n.language ?? void 0, t.message = n.message ?? void 0, t.isLivelyVoice = n.isLivelyVoice ?? !1, t.unknown2 = n.unknown2 ?? void 0, t.shouldRetry = n.shouldRetry ?? void 0, t.unknown3 = n.unknown3 ?? void 0, t;
  }
};
function Ko() {
  return { status: 0, remainingTime: void 0, message: void 0, unknown0: void 0 };
}
const Vt = {
  encode(n, t = new Z()) {
    return n.status !== 0 && t.uint32(8).int32(n.status), n.remainingTime !== void 0 && t.uint32(16).int32(n.remainingTime), n.message !== void 0 && t.uint32(26).string(n.message), n.unknown0 !== void 0 && t.uint32(32).int32(n.unknown0), t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Ko();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 8)
            break;
          s.status = e.int32();
          continue;
        }
        case 2: {
          if (o !== 16)
            break;
          s.remainingTime = e.int32();
          continue;
        }
        case 3: {
          if (o !== 26)
            break;
          s.message = e.string();
          continue;
        }
        case 4: {
          if (o !== 32)
            break;
          s.unknown0 = e.int32();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      status: x(n.status) ? globalThis.Number(n.status) : 0,
      remainingTime: x(n.remainingTime) ? globalThis.Number(n.remainingTime) : void 0,
      message: x(n.message) ? globalThis.String(n.message) : void 0,
      unknown0: x(n.unknown0) ? globalThis.Number(n.unknown0) : void 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.status !== 0 && (t.status = Math.round(n.status)), n.remainingTime !== void 0 && (t.remainingTime = Math.round(n.remainingTime)), n.message !== void 0 && (t.message = n.message), n.unknown0 !== void 0 && (t.unknown0 = Math.round(n.unknown0)), t;
  },
  create(n) {
    return Vt.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Ko();
    return t.status = n.status ?? 0, t.remainingTime = n.remainingTime ?? void 0, t.message = n.message ?? void 0, t.unknown0 = n.unknown0 ?? void 0, t;
  }
};
function Yo() {
  return { url: "", duration: 0, language: "", responseLanguage: "" };
}
const Il = {
  encode(n, t = new Z()) {
    return n.url !== "" && t.uint32(10).string(n.url), n.duration !== 0 && t.uint32(17).double(n.duration), n.language !== "" && t.uint32(26).string(n.language), n.responseLanguage !== "" && t.uint32(34).string(n.responseLanguage), t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Yo();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.url = e.string();
          continue;
        }
        case 2: {
          if (o !== 17)
            break;
          s.duration = e.double();
          continue;
        }
        case 3: {
          if (o !== 26)
            break;
          s.language = e.string();
          continue;
        }
        case 4: {
          if (o !== 34)
            break;
          s.responseLanguage = e.string();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      url: x(n.url) ? globalThis.String(n.url) : "",
      duration: x(n.duration) ? globalThis.Number(n.duration) : 0,
      language: x(n.language) ? globalThis.String(n.language) : "",
      responseLanguage: x(n.responseLanguage) ? globalThis.String(n.responseLanguage) : ""
    };
  },
  toJSON(n) {
    const t = {};
    return n.url !== "" && (t.url = n.url), n.duration !== 0 && (t.duration = n.duration), n.language !== "" && (t.language = n.language), n.responseLanguage !== "" && (t.responseLanguage = n.responseLanguage), t;
  },
  create(n) {
    return Il.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Yo();
    return t.url = n.url ?? "", t.duration = n.duration ?? 0, t.language = n.language ?? "", t.responseLanguage = n.responseLanguage ?? "", t;
  }
};
function jo() {
  return { default: void 0, cloning: void 0 };
}
const Pl = {
  encode(n, t = new Z()) {
    return n.default !== void 0 && Vt.encode(n.default, t.uint32(10).fork()).join(), n.cloning !== void 0 && Vt.encode(n.cloning, t.uint32(18).fork()).join(), t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = jo();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.default = Vt.decode(e, e.uint32());
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.cloning = Vt.decode(e, e.uint32());
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      default: x(n.default) ? Vt.fromJSON(n.default) : void 0,
      cloning: x(n.cloning) ? Vt.fromJSON(n.cloning) : void 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.default !== void 0 && (t.default = Vt.toJSON(n.default)), n.cloning !== void 0 && (t.cloning = Vt.toJSON(n.cloning)), t;
  },
  create(n) {
    return Pl.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = jo();
    return t.default = n.default !== void 0 && n.default !== null ? Vt.fromPartial(n.default) : void 0, t.cloning = n.cloning !== void 0 && n.cloning !== null ? Vt.fromPartial(n.cloning) : void 0, t;
  }
};
function Xo() {
  return { audioFile: new Uint8Array(0), fileId: "" };
}
const Ve = {
  encode(n, t = new Z()) {
    return n.audioFile.length !== 0 && t.uint32(18).bytes(n.audioFile), n.fileId !== "" && t.uint32(10).string(n.fileId), t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Xo();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 2: {
          if (o !== 18)
            break;
          s.audioFile = e.bytes();
          continue;
        }
        case 1: {
          if (o !== 10)
            break;
          s.fileId = e.string();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      audioFile: x(n.audioFile) ? Ul(n.audioFile) : new Uint8Array(0),
      fileId: x(n.fileId) ? globalThis.String(n.fileId) : ""
    };
  },
  toJSON(n) {
    const t = {};
    return n.audioFile.length !== 0 && (t.audioFile = $l(n.audioFile)), n.fileId !== "" && (t.fileId = n.fileId), t;
  },
  create(n) {
    return Ve.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Xo();
    return t.audioFile = n.audioFile ?? new Uint8Array(0), t.fileId = n.fileId ?? "", t;
  }
};
function Jo() {
  return { audioFile: new Uint8Array(0), chunkId: 0 };
}
const Ce = {
  encode(n, t = new Z()) {
    return n.audioFile.length !== 0 && t.uint32(18).bytes(n.audioFile), n.chunkId !== 0 && t.uint32(8).int32(n.chunkId), t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Jo();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 2: {
          if (o !== 18)
            break;
          s.audioFile = e.bytes();
          continue;
        }
        case 1: {
          if (o !== 8)
            break;
          s.chunkId = e.int32();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      audioFile: x(n.audioFile) ? Ul(n.audioFile) : new Uint8Array(0),
      chunkId: x(n.chunkId) ? globalThis.Number(n.chunkId) : 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.audioFile.length !== 0 && (t.audioFile = $l(n.audioFile)), n.chunkId !== 0 && (t.chunkId = Math.round(n.chunkId)), t;
  },
  create(n) {
    return Ce.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Jo();
    return t.audioFile = n.audioFile ?? new Uint8Array(0), t.chunkId = n.chunkId ?? 0, t;
  }
};
function Zo() {
  return { audioBuffer: void 0, audioPartsLength: 0, fileId: "", version: 0 };
}
const Ee = {
  encode(n, t = new Z()) {
    return n.audioBuffer !== void 0 && Ce.encode(n.audioBuffer, t.uint32(10).fork()).join(), n.audioPartsLength !== 0 && t.uint32(16).int32(n.audioPartsLength), n.fileId !== "" && t.uint32(26).string(n.fileId), n.version !== 0 && t.uint32(32).int32(n.version), t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Zo();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.audioBuffer = Ce.decode(e, e.uint32());
          continue;
        }
        case 2: {
          if (o !== 16)
            break;
          s.audioPartsLength = e.int32();
          continue;
        }
        case 3: {
          if (o !== 26)
            break;
          s.fileId = e.string();
          continue;
        }
        case 4: {
          if (o !== 32)
            break;
          s.version = e.int32();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      audioBuffer: x(n.audioBuffer) ? Ce.fromJSON(n.audioBuffer) : void 0,
      audioPartsLength: x(n.audioPartsLength) ? globalThis.Number(n.audioPartsLength) : 0,
      fileId: x(n.fileId) ? globalThis.String(n.fileId) : "",
      version: x(n.version) ? globalThis.Number(n.version) : 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.audioBuffer !== void 0 && (t.audioBuffer = Ce.toJSON(n.audioBuffer)), n.audioPartsLength !== 0 && (t.audioPartsLength = Math.round(n.audioPartsLength)), n.fileId !== "" && (t.fileId = n.fileId), n.version !== 0 && (t.version = Math.round(n.version)), t;
  },
  create(n) {
    return Ee.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Zo();
    return t.audioBuffer = n.audioBuffer !== void 0 && n.audioBuffer !== null ? Ce.fromPartial(n.audioBuffer) : void 0, t.audioPartsLength = n.audioPartsLength ?? 0, t.fileId = n.fileId ?? "", t.version = n.version ?? 0, t;
  }
};
function Qo() {
  return { translationId: "", url: "", partialAudioInfo: void 0, audioInfo: void 0 };
}
const bs = {
  encode(n, t = new Z()) {
    return n.translationId !== "" && t.uint32(10).string(n.translationId), n.url !== "" && t.uint32(18).string(n.url), n.partialAudioInfo !== void 0 && Ee.encode(n.partialAudioInfo, t.uint32(34).fork()).join(), n.audioInfo !== void 0 && Ve.encode(n.audioInfo, t.uint32(50).fork()).join(), t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = Qo();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.translationId = e.string();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.url = e.string();
          continue;
        }
        case 4: {
          if (o !== 34)
            break;
          s.partialAudioInfo = Ee.decode(e, e.uint32());
          continue;
        }
        case 6: {
          if (o !== 50)
            break;
          s.audioInfo = Ve.decode(e, e.uint32());
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      translationId: x(n.translationId) ? globalThis.String(n.translationId) : "",
      url: x(n.url) ? globalThis.String(n.url) : "",
      partialAudioInfo: x(n.partialAudioInfo) ? Ee.fromJSON(n.partialAudioInfo) : void 0,
      audioInfo: x(n.audioInfo) ? Ve.fromJSON(n.audioInfo) : void 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.translationId !== "" && (t.translationId = n.translationId), n.url !== "" && (t.url = n.url), n.partialAudioInfo !== void 0 && (t.partialAudioInfo = Ee.toJSON(n.partialAudioInfo)), n.audioInfo !== void 0 && (t.audioInfo = Ve.toJSON(n.audioInfo)), t;
  },
  create(n) {
    return bs.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = Qo();
    return t.translationId = n.translationId ?? "", t.url = n.url ?? "", t.partialAudioInfo = n.partialAudioInfo !== void 0 && n.partialAudioInfo !== null ? Ee.fromPartial(n.partialAudioInfo) : void 0, t.audioInfo = n.audioInfo !== void 0 && n.audioInfo !== null ? Ve.fromPartial(n.audioInfo) : void 0, t;
  }
};
function tr() {
  return { status: 0, remainingChunks: [] };
}
const Ml = {
  encode(n, t = new Z()) {
    n.status !== 0 && t.uint32(8).int32(n.status);
    for (const e of n.remainingChunks)
      t.uint32(18).string(e);
    return t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = tr();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 8)
            break;
          s.status = e.int32();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.remainingChunks.push(e.string());
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      status: x(n.status) ? globalThis.Number(n.status) : 0,
      remainingChunks: globalThis.Array.isArray(n?.remainingChunks) ? n.remainingChunks.map((t) => globalThis.String(t)) : []
    };
  },
  toJSON(n) {
    const t = {};
    return n.status !== 0 && (t.status = Math.round(n.status)), n.remainingChunks?.length && (t.remainingChunks = n.remainingChunks), t;
  },
  create(n) {
    return Ml.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = tr();
    return t.status = n.status ?? 0, t.remainingChunks = n.remainingChunks?.map((e) => e) || [], t;
  }
};
function er() {
  return { language: "", url: "", unknown0: 0, translatedLanguage: "", translatedUrl: "", unknown1: 0, unknown2: 0 };
}
const Ie = {
  encode(n, t = new Z()) {
    return n.language !== "" && t.uint32(10).string(n.language), n.url !== "" && t.uint32(18).string(n.url), n.unknown0 !== 0 && t.uint32(24).int32(n.unknown0), n.translatedLanguage !== "" && t.uint32(34).string(n.translatedLanguage), n.translatedUrl !== "" && t.uint32(42).string(n.translatedUrl), n.unknown1 !== 0 && t.uint32(48).int32(n.unknown1), n.unknown2 !== 0 && t.uint32(56).int32(n.unknown2), t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = er();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.language = e.string();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.url = e.string();
          continue;
        }
        case 3: {
          if (o !== 24)
            break;
          s.unknown0 = e.int32();
          continue;
        }
        case 4: {
          if (o !== 34)
            break;
          s.translatedLanguage = e.string();
          continue;
        }
        case 5: {
          if (o !== 42)
            break;
          s.translatedUrl = e.string();
          continue;
        }
        case 6: {
          if (o !== 48)
            break;
          s.unknown1 = e.int32();
          continue;
        }
        case 7: {
          if (o !== 56)
            break;
          s.unknown2 = e.int32();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      language: x(n.language) ? globalThis.String(n.language) : "",
      url: x(n.url) ? globalThis.String(n.url) : "",
      unknown0: x(n.unknown0) ? globalThis.Number(n.unknown0) : 0,
      translatedLanguage: x(n.translatedLanguage) ? globalThis.String(n.translatedLanguage) : "",
      translatedUrl: x(n.translatedUrl) ? globalThis.String(n.translatedUrl) : "",
      unknown1: x(n.unknown1) ? globalThis.Number(n.unknown1) : 0,
      unknown2: x(n.unknown2) ? globalThis.Number(n.unknown2) : 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.language !== "" && (t.language = n.language), n.url !== "" && (t.url = n.url), n.unknown0 !== 0 && (t.unknown0 = Math.round(n.unknown0)), n.translatedLanguage !== "" && (t.translatedLanguage = n.translatedLanguage), n.translatedUrl !== "" && (t.translatedUrl = n.translatedUrl), n.unknown1 !== 0 && (t.unknown1 = Math.round(n.unknown1)), n.unknown2 !== 0 && (t.unknown2 = Math.round(n.unknown2)), t;
  },
  create(n) {
    return Ie.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = er();
    return t.language = n.language ?? "", t.url = n.url ?? "", t.unknown0 = n.unknown0 ?? 0, t.translatedLanguage = n.translatedLanguage ?? "", t.translatedUrl = n.translatedUrl ?? "", t.unknown1 = n.unknown1 ?? 0, t.unknown2 = n.unknown2 ?? 0, t;
  }
};
function nr() {
  return { url: "", language: "" };
}
const Ol = {
  encode(n, t = new Z()) {
    return n.url !== "" && t.uint32(10).string(n.url), n.language !== "" && t.uint32(18).string(n.language), t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = nr();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.url = e.string();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.language = e.string();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      url: x(n.url) ? globalThis.String(n.url) : "",
      language: x(n.language) ? globalThis.String(n.language) : ""
    };
  },
  toJSON(n) {
    const t = {};
    return n.url !== "" && (t.url = n.url), n.language !== "" && (t.language = n.language), t;
  },
  create(n) {
    return Ol.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = nr();
    return t.url = n.url ?? "", t.language = n.language ?? "", t;
  }
};
function ir() {
  return { waiting: !1, subtitles: [] };
}
const Dl = {
  encode(n, t = new Z()) {
    n.waiting !== !1 && t.uint32(8).bool(n.waiting);
    for (const e of n.subtitles)
      Ie.encode(e, t.uint32(18).fork()).join();
    return t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = ir();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 8)
            break;
          s.waiting = e.bool();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.subtitles.push(Ie.decode(e, e.uint32()));
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      waiting: x(n.waiting) ? globalThis.Boolean(n.waiting) : !1,
      subtitles: globalThis.Array.isArray(n?.subtitles) ? n.subtitles.map((t) => Ie.fromJSON(t)) : []
    };
  },
  toJSON(n) {
    const t = {};
    return n.waiting !== !1 && (t.waiting = n.waiting), n.subtitles?.length && (t.subtitles = n.subtitles.map((e) => Ie.toJSON(e))), t;
  },
  create(n) {
    return Dl.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = ir();
    return t.waiting = n.waiting ?? !1, t.subtitles = n.subtitles?.map((e) => Ie.fromPartial(e)) || [], t;
  }
};
function sr() {
  return { url: "", timestamp: "" };
}
const Pe = {
  encode(n, t = new Z()) {
    return n.url !== "" && t.uint32(10).string(n.url), n.timestamp !== "" && t.uint32(18).string(n.timestamp), t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = sr();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.url = e.string();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.timestamp = e.string();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      url: x(n.url) ? globalThis.String(n.url) : "",
      timestamp: x(n.timestamp) ? globalThis.String(n.timestamp) : ""
    };
  },
  toJSON(n) {
    const t = {};
    return n.url !== "" && (t.url = n.url), n.timestamp !== "" && (t.timestamp = n.timestamp), t;
  },
  create(n) {
    return Pe.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = sr();
    return t.url = n.url ?? "", t.timestamp = n.timestamp ?? "", t;
  }
};
function or() {
  return { url: "", language: "", responseLanguage: "", unknown0: 0, unknown1: 0 };
}
const _l = {
  encode(n, t = new Z()) {
    return n.url !== "" && t.uint32(10).string(n.url), n.language !== "" && t.uint32(18).string(n.language), n.responseLanguage !== "" && t.uint32(26).string(n.responseLanguage), n.unknown0 !== 0 && t.uint32(40).int32(n.unknown0), n.unknown1 !== 0 && t.uint32(48).int32(n.unknown1), t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = or();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.url = e.string();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.language = e.string();
          continue;
        }
        case 3: {
          if (o !== 26)
            break;
          s.responseLanguage = e.string();
          continue;
        }
        case 5: {
          if (o !== 40)
            break;
          s.unknown0 = e.int32();
          continue;
        }
        case 6: {
          if (o !== 48)
            break;
          s.unknown1 = e.int32();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      url: x(n.url) ? globalThis.String(n.url) : "",
      language: x(n.language) ? globalThis.String(n.language) : "",
      responseLanguage: x(n.responseLanguage) ? globalThis.String(n.responseLanguage) : "",
      unknown0: x(n.unknown0) ? globalThis.Number(n.unknown0) : 0,
      unknown1: x(n.unknown1) ? globalThis.Number(n.unknown1) : 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.url !== "" && (t.url = n.url), n.language !== "" && (t.language = n.language), n.responseLanguage !== "" && (t.responseLanguage = n.responseLanguage), n.unknown0 !== 0 && (t.unknown0 = Math.round(n.unknown0)), n.unknown1 !== 0 && (t.unknown1 = Math.round(n.unknown1)), t;
  },
  create(n) {
    return _l.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = or();
    return t.url = n.url ?? "", t.language = n.language ?? "", t.responseLanguage = n.responseLanguage ?? "", t.unknown0 = n.unknown0 ?? 0, t.unknown1 = n.unknown1 ?? 0, t;
  }
};
function rr() {
  return { interval: 0, translatedInfo: void 0, pingId: void 0 };
}
const Rl = {
  encode(n, t = new Z()) {
    return n.interval !== 0 && t.uint32(8).int32(n.interval), n.translatedInfo !== void 0 && Pe.encode(n.translatedInfo, t.uint32(18).fork()).join(), n.pingId !== void 0 && t.uint32(24).int32(n.pingId), t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = rr();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 8)
            break;
          s.interval = e.int32();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.translatedInfo = Pe.decode(e, e.uint32());
          continue;
        }
        case 3: {
          if (o !== 24)
            break;
          s.pingId = e.int32();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      interval: x(n.interval) ? Oc(n.interval) : 0,
      translatedInfo: x(n.translatedInfo) ? Pe.fromJSON(n.translatedInfo) : void 0,
      pingId: x(n.pingId) ? globalThis.Number(n.pingId) : void 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.interval !== 0 && (t.interval = Dc(n.interval)), n.translatedInfo !== void 0 && (t.translatedInfo = Pe.toJSON(n.translatedInfo)), n.pingId !== void 0 && (t.pingId = Math.round(n.pingId)), t;
  },
  create(n) {
    return Rl.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = rr();
    return t.interval = n.interval ?? 0, t.translatedInfo = n.translatedInfo !== void 0 && n.translatedInfo !== null ? Pe.fromPartial(n.translatedInfo) : void 0, t.pingId = n.pingId ?? void 0, t;
  }
};
function ar() {
  return { pingId: 0 };
}
const Bl = {
  encode(n, t = new Z()) {
    return n.pingId !== 0 && t.uint32(8).int32(n.pingId), t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = ar();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 8)
            break;
          s.pingId = e.int32();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return { pingId: x(n.pingId) ? globalThis.Number(n.pingId) : 0 };
  },
  toJSON(n) {
    const t = {};
    return n.pingId !== 0 && (t.pingId = Math.round(n.pingId)), t;
  },
  create(n) {
    return Bl.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = ar();
    return t.pingId = n.pingId ?? 0, t;
  }
};
function lr() {
  return { uuid: "", module: "" };
}
const Fl = {
  encode(n, t = new Z()) {
    return n.uuid !== "" && t.uint32(10).string(n.uuid), n.module !== "" && t.uint32(18).string(n.module), t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = lr();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.uuid = e.string();
          continue;
        }
        case 2: {
          if (o !== 18)
            break;
          s.module = e.string();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      uuid: x(n.uuid) ? globalThis.String(n.uuid) : "",
      module: x(n.module) ? globalThis.String(n.module) : ""
    };
  },
  toJSON(n) {
    const t = {};
    return n.uuid !== "" && (t.uuid = n.uuid), n.module !== "" && (t.module = n.module), t;
  },
  create(n) {
    return Fl.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = lr();
    return t.uuid = n.uuid ?? "", t.module = n.module ?? "", t;
  }
};
function ur() {
  return { secretKey: "", expires: 0 };
}
const Nl = {
  encode(n, t = new Z()) {
    return n.secretKey !== "" && t.uint32(10).string(n.secretKey), n.expires !== 0 && t.uint32(16).int32(n.expires), t;
  },
  decode(n, t) {
    const e = n instanceof N ? n : new N(n);
    let i = t === void 0 ? e.len : e.pos + t;
    const s = ur();
    for (; e.pos < i; ) {
      const o = e.uint32();
      switch (o >>> 3) {
        case 1: {
          if (o !== 10)
            break;
          s.secretKey = e.string();
          continue;
        }
        case 2: {
          if (o !== 16)
            break;
          s.expires = e.int32();
          continue;
        }
      }
      if ((o & 7) === 4 || o === 0)
        break;
      e.skip(o & 7);
    }
    return s;
  },
  fromJSON(n) {
    return {
      secretKey: x(n.secretKey) ? globalThis.String(n.secretKey) : "",
      expires: x(n.expires) ? globalThis.Number(n.expires) : 0
    };
  },
  toJSON(n) {
    const t = {};
    return n.secretKey !== "" && (t.secretKey = n.secretKey), n.expires !== 0 && (t.expires = Math.round(n.expires)), t;
  },
  create(n) {
    return Nl.fromPartial(n ?? {});
  },
  fromPartial(n) {
    const t = ur();
    return t.secretKey = n.secretKey ?? "", t.expires = n.expires ?? 0, t;
  }
};
function Ul(n) {
  if (globalThis.Buffer)
    return Uint8Array.from(globalThis.Buffer.from(n, "base64"));
  {
    const t = globalThis.atob(n), e = new Uint8Array(t.length);
    for (let i = 0; i < t.length; ++i)
      e[i] = t.charCodeAt(i);
    return e;
  }
}
function $l(n) {
  if (globalThis.Buffer)
    return globalThis.Buffer.from(n).toString("base64");
  {
    const t = [];
    return n.forEach((e) => {
      t.push(globalThis.String.fromCharCode(e));
    }), globalThis.btoa(t.join(""));
  }
}
function x(n) {
  return n != null;
}
const { componentVersion: vs } = et, Zs = new TextEncoder();
function _c() {
  const n = globalThis.crypto ?? (typeof window < "u" ? window.crypto : void 0);
  if (!n?.subtle)
    throw new Error("Web Crypto API is not available in this browser context");
  return n;
}
async function Hl(n, t, e) {
  const i = _c(), s = await i.subtle.importKey(
    "raw",
    Zs.encode(t),
    { name: "HMAC", hash: { name: n } },
    !1,
    ["sign", "verify"]
  );
  return i.subtle.sign("HMAC", s, e);
}
async function ws(n) {
  const t = await Hl("SHA-256", et.hmac, n);
  return new Uint8Array(t).reduce(
    (e, i) => e + i.toString(16).padStart(2, "0"),
    ""
  );
}
async function Te(n, t, e, i) {
  const { secretKey: s, uuid: o } = t, r = `${o}:${i}:${vs}`, a = Zs.encode(r), l = await ws(a);
  if (n === "Ya-Summary")
    return {
      [`X-${n}-Sk`]: s,
      [`X-${n}-Token`]: `${l}:${r}`
    };
  const c = await ws(e);
  return {
    [`${n}-Signature`]: c,
    [`Sec-${n}-Sk`]: s,
    [`Sec-${n}-Token`]: `${l}:${r}`
  };
}
function Rc() {
  const n = "0123456789ABCDEF";
  let t = "";
  for (let e = 0; e < 32; e += 1)
    t += n[Math.floor(Math.random() * 16)];
  return t;
}
async function Bc(n, t) {
  try {
    const e = Zs.encode(t), i = await Hl("SHA-1", n, e);
    return btoa(String.fromCharCode(...new Uint8Array(i)));
  } catch (e) {
    return D.error(e), !1;
  }
}
const Wl = {
  "sec-ch-ua": `"Chromium";v="134", "YaBrowser";v="${vs.slice(0, 5)}", "Not?A_Brand";v="24", "Yowser";v="2.5"`,
  "sec-ch-ua-full-version-list": `"Chromium";v="134.0.6998.543", "YaBrowser";v="${vs}", "Not?A_Brand";v="24.0.0.0", "Yowser";v="2.5"`,
  "Sec-Fetch-Mode": "no-cors"
}, Fc = {
  afr: "af",
  aka: "ak",
  alb: "sq",
  amh: "am",
  ara: "ar",
  arm: "hy",
  asm: "as",
  aym: "ay",
  aze: "az",
  baq: "eu",
  bel: "be",
  ben: "bn",
  bos: "bs",
  bul: "bg",
  bur: "my",
  cat: "ca",
  chi: "zh",
  cos: "co",
  cze: "cs",
  dan: "da",
  div: "dv",
  dut: "nl",
  eng: "en",
  epo: "eo",
  est: "et",
  ewe: "ee",
  fin: "fi",
  fre: "fr",
  fry: "fy",
  geo: "ka",
  ger: "de",
  gla: "gd",
  gle: "ga",
  glg: "gl",
  gre: "el",
  grn: "gn",
  guj: "gu",
  hat: "ht",
  hau: "ha",
  hin: "hi",
  hrv: "hr",
  hun: "hu",
  ibo: "ig",
  ice: "is",
  ind: "id",
  ita: "it",
  jav: "jv",
  jpn: "ja",
  kan: "kn",
  kaz: "kk",
  khm: "km",
  kin: "rw",
  kir: "ky",
  kor: "ko",
  kur: "ku",
  lao: "lo",
  lat: "la",
  lav: "lv",
  lin: "ln",
  lit: "lt",
  ltz: "lb",
  lug: "lg",
  mac: "mk",
  mal: "ml",
  mao: "mi",
  mar: "mr",
  may: "ms",
  mlg: "mg",
  mlt: "mt",
  mon: "mn",
  nep: "ne",
  nor: "no",
  nya: "ny",
  ori: "or",
  orm: "om",
  pan: "pa",
  per: "fa",
  pol: "pl",
  por: "pt",
  pus: "ps",
  que: "qu",
  rum: "ro",
  rus: "ru",
  san: "sa",
  sin: "si",
  slo: "sk",
  slv: "sl",
  smo: "sm",
  sna: "sn",
  snd: "sd",
  som: "so",
  sot: "st",
  spa: "es",
  srp: "sr",
  sun: "su",
  swa: "sw",
  swe: "sv",
  tam: "ta",
  tat: "tt",
  tel: "te",
  tgk: "tg",
  tha: "th",
  tir: "ti",
  tso: "ts",
  tuk: "tk",
  tur: "tr",
  uig: "ug",
  ukr: "uk",
  urd: "ur",
  uzb: "uz",
  vie: "vi",
  wel: "cy",
  xho: "xh",
  yid: "yi",
  yor: "yo",
  zul: "zu"
};
async function zl(n, t = {
  headers: {
    "User-Agent": et.userAgent
  }
}) {
  const { timeout: e = 3e3, ...i } = t, s = new AbortController(), o = setTimeout(() => s.abort(), e), r = await fetch(n, {
    signal: s.signal,
    ...i
  });
  return clearTimeout(o), r;
}
function Nc() {
  return Math.floor(Date.now() / 1e3);
}
function X(n) {
  return n.length === 3 ? Fc[n] : n.toLowerCase().split(/[_;-]/)[0].trim();
}
function Et(n, t = "mp4") {
  const e = `https://${et.mediaProxy}/v1/proxy/video.${t}?format=base64&force=true`;
  return n instanceof URL ? `${e}&url=${btoa(n.href)}&origin=${n.origin}&referer=${n.origin}` : `${e}&url=${btoa(n)}`;
}
class dt {
  static encodeTranslationRequest(t, e, i, s, o, { forceSourceLang: r = !1, wasStream: a = !1, videoTitle: l = "", bypassCache: c = !1, useLivelyVoice: d = !1, firstRequest: h = !0 } = {}) {
    return Cl.encode({
      url: t,
      firstRequest: h,
      duration: e,
      unknown0: 1,
      language: i,
      forceSourceLang: r,
      unknown1: 0,
      translationHelp: o ?? [],
      responseLanguage: s,
      wasStream: a,
      unknown2: 1,
      unknown3: 2,
      bypassCache: c,
      useLivelyVoice: d,
      videoTitle: l
    }).finish();
  }
  static decodeTranslationResponse(t) {
    return El.decode(new Uint8Array(t));
  }
  static encodeTranslationCacheRequest(t, e, i, s) {
    return Il.encode({
      url: t,
      duration: e,
      language: i,
      responseLanguage: s
    }).finish();
  }
  static decodeTranslationCacheResponse(t) {
    return Pl.decode(new Uint8Array(t));
  }
  static isPartialAudioBuffer(t) {
    return "chunkId" in t;
  }
  static encodeTranslationAudioRequest(t, e, i, s) {
    return s && dt.isPartialAudioBuffer(i) ? bs.encode({
      url: t,
      translationId: e,
      partialAudioInfo: {
        ...s,
        audioBuffer: i
      }
    }).finish() : bs.encode({
      url: t,
      translationId: e,
      audioInfo: i
    }).finish();
  }
  static decodeTranslationAudioResponse(t) {
    return Ml.decode(new Uint8Array(t));
  }
  static encodeSubtitlesRequest(t, e) {
    return Ol.encode({
      url: t,
      language: e
    }).finish();
  }
  static decodeSubtitlesResponse(t) {
    return Dl.decode(new Uint8Array(t));
  }
  static encodeStreamPingRequest(t) {
    return Bl.encode({
      pingId: t
    }).finish();
  }
  static encodeStreamRequest(t, e, i) {
    return _l.encode({
      url: t,
      language: e,
      responseLanguage: i,
      unknown0: 1,
      unknown1: 0
    }).finish();
  }
  static decodeStreamResponse(t) {
    return Rl.decode(new Uint8Array(t));
  }
}
class cr {
  static encodeSessionRequest(t, e) {
    return Fl.encode({
      uuid: t,
      module: e
    }).finish();
  }
  static decodeSessionResponse(t) {
    return Nl.decode(new Uint8Array(t));
  }
}
var ft;
(function(n) {
  n[n.FAILED = 0] = "FAILED", n[n.FINISHED = 1] = "FINISHED", n[n.WAITING = 2] = "WAITING", n[n.LONG_WAITING = 3] = "LONG_WAITING", n[n.PART_CONTENT = 5] = "PART_CONTENT", n[n.AUDIO_REQUESTED = 6] = "AUDIO_REQUESTED", n[n.SESSION_REQUIRED = 7] = "SESSION_REQUIRED";
})(ft || (ft = {}));
var wn;
(function(n) {
  n.WEB_API_VIDEO_SRC_FROM_IFRAME = "web_api_video_src_from_iframe", n.WEB_API_VIDEO_SRC = "web_api_video_src", n.WEB_API_GET_ALL_GENERATING_URLS_DATA_FROM_IFRAME = "web_api_get_all_generating_urls_data_from_iframe", n.WEB_API_GET_ALL_GENERATING_URLS_DATA_FROM_IFRAME_TMP_EXP = "web_api_get_all_generating_urls_data_from_iframe_tmp_exp", n.WEB_API_REPLACED_FETCH_INSIDE_IFRAME = "web_api_replaced_fetch_inside_iframe", n.ANDROID_API = "android_api", n.WEB_API_SLOW = "web_api_slow", n.WEB_API_STEAL_SIG_AND_N = "web_api_steal_sig_and_n", n.WEB_API_COMBINED = "web_api_get_all_generating_urls_data_from_iframe,web_api_steal_sig_and_n";
})(wn || (wn = {}));
var b;
(function(n) {
  n.custom = "custom", n.directlink = "custom", n.youtube = "youtube", n.piped = "piped", n.invidious = "invidious", n.vk = "vk", n.nine_gag = "nine_gag", n.gag = "nine_gag", n.twitch = "twitch", n.proxitok = "proxitok", n.tiktok = "tiktok", n.vimeo = "vimeo", n.xvideos = "xvideos", n.pornhub = "pornhub", n.twitter = "twitter", n.x = "twitter", n.rumble = "rumble", n.facebook = "facebook", n.rutube = "rutube", n.coub = "coub", n.bilibili = "bilibili", n.mail_ru = "mailru", n.mailru = "mailru", n.bitchute = "bitchute", n.eporner = "eporner", n.peertube = "peertube", n.dailymotion = "dailymotion", n.trovo = "trovo", n.yandexdisk = "yandexdisk", n.ok_ru = "okru", n.okru = "okru", n.googledrive = "googledrive", n.bannedvideo = "bannedvideo", n.weverse = "weverse", n.newgrounds = "newgrounds", n.egghead = "egghead", n.youku = "youku", n.archive = "archive", n.kodik = "kodik", n.patreon = "patreon", n.reddit = "reddit", n.kick = "kick", n.apple_developer = "apple_developer", n.appledeveloper = "apple_developer", n.poketube = "poketube", n.epicgames = "epicgames", n.odysee = "odysee", n.coursehunterLike = "coursehunterLike", n.sap = "sap", n.watchpornto = "watchpornto", n.linkedin = "linkedin", n.ricktube = "ricktube", n.incestflix = "incestflix", n.porntn = "porntn", n.dzen = "dzen", n.cloudflarestream = "cloudflarestream", n.loom = "loom", n.rtnews = "rtnews", n.bitview = "bitview", n.thisvid = "thisvid", n.ign = "ign", n.bunkr = "bunkr", n.imdb = "imdb", n.telegram = "telegram";
})(b || (b = {}));
function dr(n, t, e) {
  return n === b.patreon ? {
    service: "mux",
    videoId: new URL(e).pathname.slice(1)
  } : {
    service: n,
    videoId: t
  };
}
class ot extends Error {
  constructor(e, i = void 0) {
    super(e);
    u(this, "data");
    this.data = i, this.name = "VOTJSError", this.message = e;
  }
}
class Uc {
  constructor({ host: t = et.host, fetchFn: e = zl, fetchOpts: i = {}, headers: s = {} } = {}) {
    u(this, "host");
    u(this, "schema");
    u(this, "fetch");
    u(this, "fetchOpts");
    u(this, "sessions", {});
    u(this, "userAgent", et.userAgent);
    u(this, "headers", {
      "User-Agent": this.userAgent,
      Accept: "application/x-protobuf",
      "Accept-Language": "en",
      "Content-Type": "application/x-protobuf",
      Pragma: "no-cache",
      "Cache-Control": "no-cache"
    });
    u(this, "hostSchemaRe", /(http(s)?):\/\//);
    const o = this.hostSchemaRe.exec(t)?.[1];
    this.host = o ? t.replace(`${o}://`, "") : t, this.schema = o ?? "https", this.fetch = e, this.fetchOpts = i, this.headers = { ...this.headers, ...s };
  }
  async request(t, e, i = {}, s = "POST") {
    const o = this.getOpts(new Blob([e]), i, s);
    try {
      const r = await this.fetch(`${this.schema}://${this.host}${t}`, o), a = await r.arrayBuffer();
      return {
        success: r.status === 200,
        data: a
      };
    } catch (r) {
      return {
        success: !1,
        data: r?.message
      };
    }
  }
  async requestJSON(t, e = null, i = {}, s = "POST") {
    const o = this.getOpts(e, {
      "Content-Type": "application/json",
      ...i
    }, s);
    try {
      const r = await this.fetch(`${this.schema}://${this.host}${t}`, o), a = await r.json();
      return {
        success: r.status === 200,
        data: a
      };
    } catch (r) {
      return {
        success: !1,
        data: r?.message
      };
    }
  }
  getOpts(t, e = {}, i = "POST") {
    return {
      method: i,
      headers: {
        ...this.headers,
        ...e
      },
      body: t,
      ...this.fetchOpts
    };
  }
  async getSession(t) {
    const e = Nc(), i = this.sessions[t];
    if (i && i.timestamp + i.expires > e)
      return i;
    const { secretKey: s, expires: o, uuid: r } = await this.createSession(t);
    return this.sessions[t] = {
      secretKey: s,
      expires: o,
      timestamp: e,
      uuid: r
    }, this.sessions[t];
  }
  async createSession(t) {
    const e = Rc(), i = cr.encodeSessionRequest(e, t), s = await this.request("/session/create", i, {
      "Vtrans-Signature": await ws(i)
    });
    if (!s.success)
      throw new ot("Failed to request create session", s);
    return {
      ...cr.decodeSessionResponse(s.data),
      uuid: e
    };
  }
}
let ql = class extends Uc {
  constructor({ host: e, hostVOT: i = et.hostVOT, fetchFn: s, fetchOpts: o, requestLang: r = "en", responseLang: a = "ru", apiToken: l, headers: c } = {}) {
    super({
      host: e,
      fetchFn: s,
      fetchOpts: o,
      headers: c
    });
    u(this, "hostVOT");
    u(this, "schemaVOT");
    u(this, "apiToken");
    u(this, "requestLang");
    u(this, "responseLang");
    u(this, "paths", {
      videoTranslation: "/video-translation/translate",
      videoTranslationFailAudio: "/video-translation/fail-audio-js",
      videoTranslationAudio: "/video-translation/audio",
      videoTranslationCache: "/video-translation/cache",
      videoSubtitles: "/video-subtitles/get-subtitles",
      streamPing: "/stream-translation/ping-stream",
      streamTranslation: "/stream-translation/translate-stream"
    });
    u(this, "headersVOT", {
      "User-Agent": `vot.js/${et.version}`,
      "Content-Type": "application/json",
      Pragma: "no-cache",
      "Cache-Control": "no-cache"
    });
    const d = this.hostSchemaRe.exec(i)?.[1];
    this.hostVOT = d ? i.replace(`${d}://`, "") : i, this.schemaVOT = d ?? "https", this.requestLang = r, this.responseLang = a, this.apiToken = l;
  }
  isCustomLink(e) {
    return !!(/\.(m3u8|m4(a|v)|mpd)/.exec(e) ?? /^https:\/\/cdn\.qstv\.on\.epicgames\.com/.exec(e));
  }
  get apiTokenHeader() {
    return this.apiToken ? {
      Authorization: `OAuth ${this.apiToken}`
    } : {};
  }
  async requestVOT(e, i, s = {}) {
    const o = this.getOpts(JSON.stringify(i), {
      ...this.headersVOT,
      ...s
    });
    try {
      const r = await this.fetch(`${this.schemaVOT}://${this.hostVOT}${e}`, o), a = await r.json();
      return {
        success: r.status === 200,
        data: a
      };
    } catch (r) {
      return {
        success: !1,
        data: r?.message
      };
    }
  }
  async translateVideoYAImpl({ videoData: e, requestLang: i = this.requestLang, responseLang: s = this.responseLang, translationHelp: o = null, headers: r = {}, extraOpts: a = {}, shouldSendFailedAudio: l = !0 }) {
    const { url: c, duration: d = et.defaultDuration } = e, h = await this.getSession("video-translation"), f = dt.encodeTranslationRequest(c, d, i, s, o, a), g = this.paths.videoTranslation, m = await Te("Vtrans", h, f, g), v = a.useLivelyVoice ? this.apiTokenHeader : {}, S = await this.request(g, f, {
      ...m,
      ...v,
      ...r
    });
    if (!S.success)
      throw new ot("Failed to request video translation", S);
    const T = dt.decodeTranslationResponse(S.data);
    D.log("translateVideo", T);
    const { status: w, translationId: A } = T;
    switch (w) {
      case ft.FAILED:
        throw new ot("Yandex couldn't translate video", T);
      case ft.FINISHED:
      case ft.PART_CONTENT:
        if (!T.url)
          throw new ot("Audio link wasn't received from Yandex response", T);
        return {
          translationId: A,
          translated: !0,
          url: T.url,
          status: w,
          remainingTime: T.remainingTime ?? -1
        };
      case ft.WAITING:
      case ft.LONG_WAITING:
        return {
          translationId: A,
          translated: !1,
          status: w,
          remainingTime: T.remainingTime
        };
      case ft.AUDIO_REQUESTED:
        return c.startsWith("https://youtu.be/") && l ? (await this.requestVtransFailAudio(c), await this.requestVtransAudio(c, T.translationId, {
          audioFile: new Uint8Array(),
          fileId: wn.WEB_API_GET_ALL_GENERATING_URLS_DATA_FROM_IFRAME
        }), await this.translateVideoYAImpl({
          videoData: e,
          requestLang: i,
          responseLang: s,
          translationHelp: o,
          headers: r,
          shouldSendFailedAudio: !1
        })) : {
          translationId: A,
          translated: !1,
          status: w,
          remainingTime: T.remainingTime ?? -1
        };
      case ft.SESSION_REQUIRED:
        throw new ot("Yandex auth required to translate video. See docs for more info", T);
      default:
        throw D.error("Unknown response", T), new ot("Unknown response from Yandex", T);
    }
  }
  async translateVideoVOTImpl({ url: e, videoId: i, service: s, requestLang: o = this.requestLang, responseLang: r = this.responseLang, headers: a = {}, provider: l = "yandex" }) {
    const c = dr(s, i, e), d = await this.requestVOT(this.paths.videoTranslation, {
      provider: l,
      service: c.service,
      video_id: c.videoId,
      from_lang: o,
      to_lang: r,
      raw_video: e
    }, {
      ...a
    });
    if (!d.success)
      throw new ot("Failed to request video translation", d);
    const h = d.data;
    switch (h.status) {
      case "failed":
        throw new ot("Yandex couldn't translate video", h);
      case "success":
        if (!h.translated_url)
          throw new ot("Audio link wasn't received from VOT response", h);
        return {
          translationId: String(h.id),
          translated: !0,
          url: h.translated_url,
          status: 1,
          remainingTime: -1
        };
      case "waiting":
        return {
          translationId: "",
          translated: !1,
          remainingTime: h.remaining_time,
          status: 2,
          message: h.message
        };
    }
  }
  async requestVtransFailAudio(e) {
    const i = await this.requestJSON(this.paths.videoTranslationFailAudio, JSON.stringify({
      video_url: e
    }), void 0, "PUT");
    if (!i.data || typeof i.data == "string" || i.data.status !== 1)
      throw new ot("Failed to request to fake video translation fail audio js", i);
    return i;
  }
  async requestVtransAudio(e, i, s, o, r = {}) {
    const a = await this.getSession("video-translation"), l = dt.isPartialAudioBuffer(s) ? dt.encodeTranslationAudioRequest(e, i, s, o) : dt.encodeTranslationAudioRequest(e, i, s, void 0), c = this.paths.videoTranslationAudio, d = await Te("Vtrans", a, l, c), h = await this.request(c, l, {
      ...d,
      ...r
    }, "PUT");
    if (!h.success)
      throw new ot("Failed to request video translation audio", h);
    return dt.decodeTranslationAudioResponse(h.data);
  }
  async translateVideoCache({ videoData: e, requestLang: i = this.requestLang, responseLang: s = this.responseLang, headers: o = {} }) {
    const { url: r, duration: a = et.defaultDuration } = e, l = await this.getSession("video-translation"), c = dt.encodeTranslationCacheRequest(r, a, i, s), d = this.paths.videoTranslationCache, h = await Te("Vtrans", l, c, d), f = await this.request(d, c, {
      ...h,
      ...o
    }, "POST");
    if (!f.success)
      throw new ot("Failed to request video translation cache", f);
    return dt.decodeTranslationCacheResponse(f.data);
  }
  async translateVideo({ videoData: e, requestLang: i = this.requestLang, responseLang: s = this.responseLang, translationHelp: o = null, headers: r = {}, extraOpts: a = {}, shouldSendFailedAudio: l = !0 }) {
    const { url: c, videoId: d, host: h } = e;
    return this.isCustomLink(c) ? await this.translateVideoVOTImpl({
      url: c,
      videoId: d,
      service: h,
      requestLang: i,
      responseLang: s,
      headers: r,
      provider: a.useLivelyVoice ? "yandex_lively" : "yandex"
    }) : await this.translateVideoYAImpl({
      videoData: e,
      requestLang: i,
      responseLang: s,
      translationHelp: o,
      headers: r,
      extraOpts: a,
      shouldSendFailedAudio: l
    });
  }
  async getSubtitlesYAImpl({ videoData: e, requestLang: i = this.requestLang, headers: s = {} }) {
    const { url: o } = e, r = await this.getSession("video-translation"), a = dt.encodeSubtitlesRequest(o, i), l = this.paths.videoSubtitles, c = await Te("Vsubs", r, a, l), d = await this.request(l, a, {
      ...c,
      ...s
    });
    if (!d.success)
      throw new ot("Failed to request video subtitles", d);
    const h = dt.decodeSubtitlesResponse(d.data), f = h.subtitles.map((g) => {
      const { language: m, url: v, translatedLanguage: S, translatedUrl: T } = g;
      return {
        language: m,
        url: v,
        translatedLanguage: S,
        translatedUrl: T
      };
    });
    return {
      waiting: h.waiting,
      subtitles: f
    };
  }
  async getSubtitlesVOTImpl({ url: e, videoId: i, service: s, headers: o = {} }) {
    const r = dr(s, i, e), a = await this.requestVOT(this.paths.videoSubtitles, {
      provider: "yandex",
      service: r.service,
      video_id: r.videoId
    }, o);
    if (!a.success)
      throw new ot("Failed to request video subtitles", a);
    const l = a.data;
    return {
      waiting: !1,
      subtitles: l.reduce((d, h) => {
        if (!h.lang_from)
          return d;
        const f = l.find((g) => g.lang === h.lang_from);
        return f && d.push({
          language: f.lang,
          url: f.subtitle_url,
          translatedLanguage: h.lang,
          translatedUrl: h.subtitle_url
        }), d;
      }, [])
    };
  }
  async getSubtitles({ videoData: e, requestLang: i = this.requestLang, headers: s = {} }) {
    const { url: o, videoId: r, host: a } = e;
    return this.isCustomLink(o) ? await this.getSubtitlesVOTImpl({
      url: o,
      videoId: r,
      service: a,
      headers: s
    }) : await this.getSubtitlesYAImpl({
      videoData: e,
      requestLang: i,
      headers: s
    });
  }
  async pingStream({ pingId: e, headers: i = {} }) {
    const s = await this.getSession("video-translation"), o = dt.encodeStreamPingRequest(e), r = this.paths.streamPing, a = await Te("Vtrans", s, o, r), l = await this.request(r, o, {
      ...a,
      ...i
    });
    if (!l.success)
      throw new ot("Failed to request stream ping", l);
    return !0;
  }
  async translateStream({ videoData: e, requestLang: i = this.requestLang, responseLang: s = this.responseLang, headers: o = {} }) {
    const { url: r } = e;
    if (this.isCustomLink(r))
      throw new ot("Unsupported video URL for getting stream translation");
    const a = await this.getSession("video-translation"), l = dt.encodeStreamRequest(r, i, s), c = this.paths.streamTranslation, d = await Te("Vtrans", a, l, c), h = await this.request(c, l, {
      ...d,
      ...o
    });
    if (!h.success)
      throw new ot("Failed to request stream translation", h);
    const f = dt.decodeStreamResponse(h.data), g = f.interval;
    switch (g) {
      case vt.NO_CONNECTION:
      case vt.TRANSLATING:
        return {
          translated: !1,
          interval: g,
          message: g === vt.NO_CONNECTION ? "streamNoConnectionToServer" : "translationTakeFewMinutes"
        };
      case vt.STREAMING:
        return {
          translated: !0,
          interval: g,
          pingId: f.pingId,
          result: f.translatedInfo
        };
      default:
        throw D.error("Unknown response", f), new ot("Unknown response from Yandex", f);
    }
  }
}, $c = class extends ql {
  constructor(t = {}) {
    t.host = t.host ?? et.hostWorker, super(t);
  }
  async request(t, e, i = {}, s = "POST") {
    const o = this.getOpts(JSON.stringify({
      headers: {
        ...this.headers,
        ...i
      },
      body: Array.from(e)
    }), {
      "Content-Type": "application/json"
    }, s);
    try {
      const r = await this.fetch(`${this.schema}://${this.host}${t}`, o), a = await r.arrayBuffer();
      return {
        success: r.status === 200,
        data: a
      };
    } catch (r) {
      return {
        success: !1,
        data: r?.message
      };
    }
  }
  async requestJSON(t, e = null, i = {}, s = "POST") {
    const o = this.getOpts(JSON.stringify({
      headers: {
        ...this.headers,
        "Content-Type": "application/json",
        Accept: "application/json",
        ...i
      },
      body: e
    }), {
      Accept: "application/json",
      "Content-Type": "application/json"
    }, s);
    try {
      const r = await this.fetch(`${this.schema}://${this.host}${t}`, o), a = await r.json();
      return {
        success: r.status === 200,
        data: a
      };
    } catch (r) {
      return {
        success: !1,
        data: r?.message
      };
    }
  }
};
class Hc extends ql {
  constructor(t) {
    super(t), this.headers = {
      ...Wl,
      ...this.headers
    };
  }
}
class Wc extends $c {
  constructor(t) {
    super(t), this.headers = {
      ...Wl,
      ...this.headers
    };
  }
}
class ci extends Error {
  constructor(t) {
    super(t), this.name = "VideoDataError", this.message = t;
  }
}
const zc = /(file:\/\/(\/)?|(http(s)?:\/\/)(127\.0\.0\.1|localhost|192\.168\.(\d){1,3}\.(\d){1,3}))/, qc = [
  "yewtu.be",
  "yt.artemislena.eu",
  "invidious.flokinet.to",
  "iv.melmac.space",
  "inv.nadeko.net",
  "inv.tux.pizza",
  "invidious.private.coffee",
  "yt.drgnz.club",
  "vid.puffyan.us",
  "invidious.dhusch.de"
], Gc = [
  "piped.video",
  "piped.tokhmi.xyz",
  "piped.moomoo.me",
  "piped.syncpundit.io",
  "piped.mha.fi",
  "watch.whatever.social",
  "piped.garudalinux.org",
  "efy.piped.pages.dev",
  "watch.leptons.xyz",
  "piped.lunar.icu",
  "yt.dc09.ru",
  "piped.mint.lgbt",
  "il.ax",
  "piped.privacy.com.de",
  "piped.esmailelbob.xyz",
  "piped.projectsegfau.lt",
  "piped.in.projectsegfau.lt",
  "piped.us.projectsegfau.lt",
  "piped.privacydev.net",
  "piped.palveluntarjoaja.eu",
  "piped.smnz.de",
  "piped.adminforge.de",
  "piped.qdi.fi",
  "piped.hostux.net",
  "piped.chauvet.pro",
  "piped.jotoma.de",
  "piped.pfcd.me",
  "piped.frontendfriendly.xyz"
], Kc = [
  "proxitok.pabloferreiro.es",
  "proxitok.pussthecat.org",
  "tok.habedieeh.re",
  "proxitok.esmailelbob.xyz",
  "proxitok.privacydev.net",
  "tok.artemislena.eu",
  "tok.adminforge.de",
  "tt.vern.cc",
  "cringe.whatever.social",
  "proxitok.lunar.icu",
  "proxitok.privacy.com.de"
], Yc = [
  "peertube.1312.media",
  "tube.shanti.cafe",
  "bee-tube.fr",
  "video.sadmin.io",
  "dalek.zone",
  "review.peertube.biz",
  "peervideo.club",
  "tube.la-dina.net",
  "peertube.tmp.rcp.tf",
  "peertube.su",
  "video.blender.org",
  "videos.viorsan.com",
  "tube-sciences-technologies.apps.education.fr",
  "tube-numerique-educatif.apps.education.fr",
  "tube-arts-lettres-sciences-humaines.apps.education.fr",
  "beetoons.tv",
  "comics.peertube.biz",
  "makertube.net"
], jc = [
  "poketube.fun",
  "pt.sudovanilla.org",
  "poke.ggtyler.dev",
  "poke.uk2.littlekai.co.uk",
  "poke.blahai.gay"
], Xc = ["ricktube.ru"], Jc = ["coursehunter.net", "coursetrain.net"];
var tt;
(function(n) {
  n.udemy = "udemy", n.coursera = "coursera", n.douyin = "douyin", n.artstation = "artstation", n.kickstarter = "kickstarter", n.oraclelearn = "oraclelearn", n.deeplearningai = "deeplearningai", n.netacad = "netacad";
})(tt || (tt = {}));
({
  ...b,
  ...tt
});
const Zc = [
  {
    additionalData: "mobile",
    host: b.youtube,
    url: "https://youtu.be/",
    match: /^m.youtube.com$/,
    selector: ".player-container",
    needExtraData: !0
  },
  {
    host: b.youtube,
    url: "https://youtu.be/",
    match: /^(www.)?youtube(-nocookie|kids)?.com$/,
    selector: ".html5-video-container:not(#inline-player *)",
    needExtraData: !0
  },
  {
    host: b.invidious,
    url: "https://youtu.be/",
    match: qc,
    selector: "#player",
    needBypassCSP: !0
  },
  {
    host: b.piped,
    url: "https://youtu.be/",
    match: Gc,
    selector: ".shaka-video-container",
    needBypassCSP: !0
  },
  {
    host: b.poketube,
    url: "https://youtu.be/",
    match: jc,
    selector: ".video-player-container"
  },
  {
    host: b.ricktube,
    url: "https://youtu.be/",
    match: Xc,
    selector: "#oframeplayer > pjsdiv:has(video)"
  },
  {
    additionalData: "mobile",
    host: b.vk,
    url: "https://vk.com/video?z=",
    match: [/^m.vk.(com|ru)$/, /^m.vkvideo.ru$/],
    selector: "vk-video-player",
    shadowRoot: !0,
    needExtraData: !0
  },
  {
    additionalData: "clips",
    host: b.vk,
    url: "https://vk.com/video?z=",
    match: /^(www.|m.)?vk.(com|ru)$/,
    selector: 'div[data-testid="clipcontainer-video"]',
    needExtraData: !0
  },
  {
    host: b.vk,
    url: "https://vk.com/video?z=",
    match: [/^(www.|m.)?vk.(com|ru)$/, /^(www.|m.)?vkvideo.ru$/],
    selector: ".videoplayer_media",
    needExtraData: !0
  },
  {
    host: b.nine_gag,
    url: "https://9gag.com/gag/",
    match: /^9gag.com$/,
    selector: ".video-post",
    needExtraData: !0
  },
  {
    host: b.twitch,
    url: "https://twitch.tv/",
    match: [
      /^m.twitch.tv$/,
      /^(www.)?twitch.tv$/,
      /^clips.twitch.tv$/,
      /^player.twitch.tv$/
    ],
    needExtraData: !0,
    selector: ".video-ref, main > div > section > div > div > div"
  },
  {
    host: b.proxitok,
    url: "https://www.tiktok.com/",
    match: Kc,
    selector: ".column.has-text-centered"
  },
  {
    host: b.tiktok,
    url: "https://www.tiktok.com/",
    match: /^(www.)?tiktok.com$/,
    selector: null
  },
  {
    host: tt.douyin,
    url: "https://www.douyin.com/",
    match: /^(www.)?douyin.com/,
    selector: ".xg-video-container",
    needExtraData: !0,
    needBypassCSP: !0
  },
  {
    host: b.vimeo,
    url: "https://vimeo.com/",
    match: /^vimeo.com$/,
    needExtraData: !0,
    selector: ".player"
  },
  {
    host: b.vimeo,
    url: "https://player.vimeo.com/",
    match: /^player.vimeo.com$/,
    additionalData: "embed",
    needExtraData: !0,
    needBypassCSP: !0,
    selector: ".player"
  },
  {
    host: b.xvideos,
    url: "https://www.xvideos.com/",
    match: [
      /^(www.)?xvideos(-ar)?.com$/,
      /^(www.)?xvideos(\d\d\d).com$/,
      /^(www.)?xv-ru.com$/
    ],
    selector: "#hlsplayer",
    needBypassCSP: !0
  },
  {
    host: b.pornhub,
    url: "https://rt.pornhub.com/view_video.php?viewkey=",
    match: /^[a-z]+.pornhub.(com|org)$/,
    selector: ".mainPlayerDiv > .video-element-wrapper-js > div",
    eventSelector: ".mgp_eventCatcher"
  },
  {
    additionalData: "embed",
    host: b.pornhub,
    url: "https://rt.pornhub.com/view_video.php?viewkey=",
    match: (n) => /^[a-z]+.pornhub.(com|org)$/.exec(n.host) && n.pathname.startsWith("/embed/"),
    selector: "#player"
  },
  {
    host: b.twitter,
    url: "https://twitter.com/i/status/",
    match: /^(twitter|x).com$/,
    selector: 'div[data-testid="videoComponent"] > div:nth-child(1) > div',
    eventSelector: 'div[data-testid="videoPlayer"]',
    needBypassCSP: !0
  },
  {
    host: b.rumble,
    url: "https://rumble.com/",
    match: /^rumble.com$/,
    selector: "#videoPlayer > .videoPlayer-Rumble-cls > div"
  },
  {
    host: b.facebook,
    url: "https://facebook.com/",
    match: (n) => n.host.includes("facebook.com") && n.pathname.includes("/videos/"),
    selector: 'div[role="main"] div[data-pagelet$="video" i]',
    needBypassCSP: !0
  },
  {
    additionalData: "reels",
    host: b.facebook,
    url: "https://facebook.com/",
    match: (n) => n.host.includes("facebook.com") && n.pathname.includes("/reel/"),
    selector: 'div[role="main"]',
    needBypassCSP: !0
  },
  {
    host: b.rutube,
    url: "https://rutube.ru/video/",
    match: /^rutube.ru$/,
    selector: ".video-player > div > div > div:nth-child(2)"
  },
  {
    additionalData: "embed",
    host: b.rutube,
    url: "https://rutube.ru/video/",
    match: /^rutube.ru$/,
    selector: "#app > div > div"
  },
  {
    host: b.bilibili,
    url: "https://www.bilibili.com/",
    match: /^(www|m|player).bilibili.com$/,
    selector: ".bpx-player-video-wrap"
  },
  {
    additionalData: "old",
    host: b.bilibili,
    url: "https://www.bilibili.com/",
    match: /^(www|m).bilibili.com$/,
    selector: null
  },
  {
    host: b.mailru,
    url: "https://my.mail.ru/",
    match: /^my.mail.ru$/,
    selector: "#b-video-wrapper"
  },
  {
    host: b.bitchute,
    url: "https://www.bitchute.com/video/",
    match: /^(www.)?bitchute.com$/,
    selector: ".video-js"
  },
  {
    host: b.eporner,
    url: "https://www.eporner.com/",
    match: /^(www.)?eporner.com$/,
    selector: ".vjs-v7"
  },
  {
    host: b.peertube,
    url: "stub",
    match: Yc,
    selector: ".vjs-v7"
  },
  {
    host: b.dailymotion,
    url: "https://dai.ly/",
    match: /^geo([\d]+)?.dailymotion.com$/,
    selector: ".player"
  },
  {
    host: b.trovo,
    url: "https://trovo.live/s/",
    match: /^trovo.live$/,
    selector: ".player-video"
  },
  {
    host: b.yandexdisk,
    url: "https://yadi.sk/",
    match: /^disk.yandex.(ru|kz|com(\.(am|ge|tr))?|by|az|co\.il|ee|lt|lv|md|net|tj|tm|uz)$/,
    selector: ".video-player__player > div:nth-child(1)",
    eventSelector: ".video-player__player",
    needBypassCSP: !0,
    needExtraData: !0
  },
  {
    host: b.okru,
    url: "https://ok.ru/video/",
    match: /^ok.ru$/,
    selector: "vk-video-player",
    shadowRoot: !0
  },
  {
    host: b.googledrive,
    url: "https://drive.google.com/file/d/",
    match: /^youtube.googleapis.com$/,
    selector: ".html5-video-container"
  },
  {
    host: b.bannedvideo,
    url: "https://madmaxworld.tv/watch?id=",
    match: /^(www.)?banned.video|madmaxworld.tv$/,
    selector: ".vjs-v7",
    needExtraData: !0
  },
  {
    host: b.weverse,
    url: "https://weverse.io/",
    match: /^weverse.io$/,
    selector: ".webplayer-internal-source-wrapper",
    needExtraData: !0
  },
  {
    host: b.newgrounds,
    url: "https://www.newgrounds.com/",
    match: /^(www.)?newgrounds.com$/,
    selector: ".ng-video-player"
  },
  {
    host: b.egghead,
    url: "https://egghead.io/",
    match: /^egghead.io$/,
    selector: ".cueplayer-react-video-holder"
  },
  {
    host: b.youku,
    url: "https://v.youku.com/",
    match: /^v.youku.com$/,
    selector: "#ykPlayer"
  },
  {
    host: b.archive,
    url: "https://archive.org/details/",
    match: /^archive.org$/,
    selector: ".jw-media"
  },
  {
    host: b.kodik,
    url: "stub",
    match: /^kodik.(info|biz|cc)$/,
    selector: ".fp-player",
    needExtraData: !0
  },
  {
    host: b.patreon,
    url: "stub",
    match: /^(www.)?patreon.com$/,
    selector: 'div[data-tag="post-card"] div[elevation="subtle"] > div > div > div > div',
    needExtraData: !0
  },
  {
    additionalData: "old",
    host: b.reddit,
    url: "stub",
    match: /^old.reddit.com$/,
    selector: ".reddit-video-player-root",
    needExtraData: !0,
    needBypassCSP: !0
  },
  {
    host: b.reddit,
    url: "stub",
    match: /^(www.|new.)?reddit.com$/,
    selector: "div[slot=post-media-container]",
    shadowRoot: !0,
    needExtraData: !0,
    needBypassCSP: !0
  },
  {
    host: b.kick,
    url: "https://kick.com/",
    match: /^kick.com$/,
    selector: "#injected-embedded-channel-player-video > div",
    needExtraData: !0
  },
  {
    host: b.appledeveloper,
    url: "https://developer.apple.com/",
    match: /^developer.apple.com$/,
    selector: ".developer-video-player",
    needExtraData: !0,
    needBypassCSP: !0
  },
  {
    host: b.epicgames,
    url: "https://dev.epicgames.com/community/learning/",
    match: /^dev.epicgames.com$/,
    selector: ".vjs-v7",
    needExtraData: !0
  },
  {
    host: b.odysee,
    url: "stub",
    match: /^odysee.com$/,
    selector: ".vjs-v7",
    needExtraData: !0
  },
  {
    host: b.coursehunterLike,
    url: "stub",
    match: Jc,
    selector: "#oframeplayer > pjsdiv:has(video)",
    needExtraData: !0
  },
  {
    host: b.sap,
    url: "https://learning.sap.com/courses/",
    match: /^learning.sap.com$/,
    selector: ".playkit-container",
    eventSelector: ".playkit-player",
    needExtraData: !0,
    needBypassCSP: !0
  },
  {
    host: tt.udemy,
    url: "https://www.udemy.com/",
    match: /udemy.com$/,
    selector: 'div[data-purpose="curriculum-item-viewer-content"] > section > div > div > div > div:nth-of-type(2)',
    needExtraData: !0
  },
  {
    host: tt.coursera,
    url: "https://www.coursera.org/",
    match: /coursera.org$/,
    selector: ".vjs-v8",
    needExtraData: !0
  },
  {
    host: b.watchpornto,
    url: "https://watchporn.to/",
    match: /^watchporn.to$/,
    selector: ".fp-player"
  },
  {
    host: b.linkedin,
    url: "https://www.linkedin.com/learning/",
    match: /^(www.)?linkedin.com$/,
    selector: ".vjs-v7",
    needExtraData: !0,
    needBypassCSP: !0
  },
  {
    host: b.incestflix,
    url: "https://www.incestflix.net/watch/",
    match: /^(www.)?incestflix.(net|to|com)$/,
    selector: "#incflix-stream",
    needExtraData: !0
  },
  {
    host: b.porntn,
    url: "https://porntn.com/videos/",
    match: /^porntn.com$/,
    selector: ".fp-player",
    needExtraData: !0
  },
  {
    host: b.dzen,
    url: "https://dzen.ru/video/watch/",
    match: /^dzen.ru$/,
    selector: ".zen-ui-video-video-player"
  },
  {
    host: b.cloudflarestream,
    url: "stub",
    match: /^(watch|embed|iframe|customer-[^.]+).cloudflarestream.com$/,
    selector: null
  },
  {
    host: b.loom,
    url: "https://www.loom.com/share/",
    match: /^(www.)?loom.com$/,
    selector: ".VideoLayersContainer",
    needExtraData: !0,
    needBypassCSP: !0
  },
  {
    host: tt.artstation,
    url: "https://www.artstation.com/learning/",
    match: /^(www.)?artstation.com$/,
    selector: ".vjs-v7",
    needExtraData: !0
  },
  {
    host: b.rtnews,
    url: "https://www.rt.com/",
    match: /^(www.)?rt.com$/,
    selector: ".jw-media",
    needExtraData: !0
  },
  {
    host: b.bitview,
    url: "https://www.bitview.net/watch?v=",
    match: /^(www.)?bitview.net$/,
    selector: ".vlScreen",
    needExtraData: !0
  },
  {
    host: tt.kickstarter,
    url: "https://www.kickstarter.com/",
    match: /^(www.)?kickstarter.com/,
    selector: ".ksr-video-player",
    needExtraData: !0
  },
  {
    host: b.thisvid,
    url: "https://thisvid.com/",
    match: /^(www.)?thisvid.com$/,
    selector: ".fp-player"
  },
  {
    additionalData: "regional",
    host: b.ign,
    url: "https://de.ign.com/",
    match: /^(\w{2}.)?ign.com$/,
    needExtraData: !0,
    selector: ".video-container"
  },
  {
    host: b.ign,
    url: "https://www.ign.com/",
    match: /^(www.)?ign.com$/,
    selector: ".player",
    needExtraData: !0
  },
  {
    host: b.bunkr,
    url: "https://bunkr.site/",
    match: /^bunkr\.(site|black|cat|media|red|site|ws|org|s[kiu]|c[ir]|fi|p[hks]|ru|la|is|to|a[cx])$/,
    needExtraData: !0,
    selector: ".plyr__video-wrapper"
  },
  {
    host: b.imdb,
    url: "https://www.imdb.com/video/",
    match: /^(www\.)?imdb\.com$/,
    selector: ".jw-media"
  },
  {
    host: b.telegram,
    url: "https://t.me/",
    match: (n) => /^web\.telegram\.org$/.test(n.hostname) && n.pathname.startsWith("/k"),
    selector: ".ckin__player"
  },
  {
    host: tt.oraclelearn,
    url: "https://mylearn.oracle.com/ou/course/",
    match: /^mylearn\.oracle\.com/,
    selector: ".vjs-v7",
    needExtraData: !0,
    needBypassCSP: !0
  },
  {
    host: tt.deeplearningai,
    url: "https://learn.deeplearning.ai/courses/",
    match: /^learn(-dev|-staging)?\.deeplearning\.ai/,
    selector: ".lesson-video-player",
    needExtraData: !0
  },
  {
    host: tt.netacad,
    url: "https://www.netacad.com/",
    match: /^(www\.)?netacad\.com/,
    selector: ".vjs-v8",
    needExtraData: !0
  },
  {
    host: b.custom,
    url: "stub",
    match: (n) => /([^.]+)\.(mp4|webm)/.test(n.pathname),
    rawResult: !0
  }
];
class $ extends Error {
  constructor(t) {
    super(t), this.name = "VideoHelper", this.message = t;
  }
}
class M {
  constructor({ fetchFn: t = zl, extraInfo: e = !0, referer: i = document.referrer ?? `${window.location.origin}/`, origin: s = window.location.origin, service: o, video: r, language: a = "en" } = {}) {
    u(this, "API_ORIGIN", window.location.origin);
    u(this, "fetch");
    u(this, "extraInfo");
    u(this, "referer");
    u(this, "origin");
    u(this, "service");
    u(this, "video");
    u(this, "language");
    this.fetch = t, this.extraInfo = e, this.referer = i, this.origin = /^(http(s)?):\/\//.test(String(s)) ? s : window.location.origin, this.service = o, this.video = r, this.language = a;
  }
  async getVideoData(t) {
  }
  async getVideoId(t) {
  }
  returnBaseData(t) {
    if (this.service)
      return {
        url: this.service.url + t,
        videoId: t,
        host: this.service.host,
        duration: void 0
      };
  }
}
class Qc extends M {
  constructor() {
    super(...arguments);
    u(this, "API_ORIGIN", "https://developer.apple.com");
  }
  async getVideoData(e) {
    try {
      const i = document.querySelector("meta[property='og:video']")?.content;
      if (!i)
        throw new $("Failed to find content url");
      return {
        url: i
      };
    } catch (i) {
      D.error(`Failed to get apple developer video data by video ID: ${e}`, i.message);
      return;
    }
  }
  async getVideoId(e) {
    return /videos\/play\/([^/]+)\/([\d]+)/.exec(e.pathname)?.[0];
  }
}
class td extends M {
  async getVideoId(t) {
    return /(details|embed)\/([^/]+)/.exec(t.pathname)?.[2];
  }
}
class ed extends M {
  constructor() {
    super(...arguments);
    u(this, "API_ORIGIN", "https://www.artstation.com/api/v2/learning");
  }
  getCSRFToken() {
    return document.querySelector('meta[name="public-csrf-token"]')?.content;
  }
  async getCourseInfo(e) {
    try {
      return await (await this.fetch(`${this.API_ORIGIN}/courses/${e}/autoplay.json`, {
        method: "POST",
        headers: {
          "PUBLIC-CSRF-TOKEN": this.getCSRFToken()
        }
      })).json();
    } catch (i) {
      return D.error(`Failed to get artstation course info by courseId: ${e}.`, i.message), !1;
    }
  }
  async getVideoUrl(e) {
    try {
      return (await (await this.fetch(`${this.API_ORIGIN}/quicksilver/video_url.json?chapter_id=${e}`)).json()).url.replace("qsep://", "https://");
    } catch (i) {
      return D.error(`Failed to get artstation video url by chapterId: ${e}.`, i.message), !1;
    }
  }
  async getVideoData(e) {
    const [, i, , , s] = e.split("/"), o = await this.getCourseInfo(i);
    if (!o)
      return;
    const r = o.chapters.find((f) => f.hash_id === s);
    if (!r)
      return;
    const a = await this.getVideoUrl(r.id);
    if (!a)
      return;
    const { title: l, duration: c, subtitles: d } = r, h = d.filter((f) => f.format === "vtt").map((f) => ({
      language: X(f.locale),
      source: "artstation",
      format: "vtt",
      url: f.file_url
    }));
    return {
      url: a,
      title: l,
      duration: c,
      subtitles: h
    };
  }
  async getVideoId(e) {
    return /courses\/(\w{3,5})\/([^/]+)\/chapters\/(\w{3,5})/.exec(e.pathname)?.[0];
  }
}
class nd extends M {
  constructor() {
    super(...arguments);
    u(this, "API_ORIGIN", "https://api.banned.video");
  }
  async getVideoInfo(e) {
    try {
      return await (await this.fetch(`${this.API_ORIGIN}/graphql`, {
        method: "POST",
        body: JSON.stringify({
          operationName: "GetVideo",
          query: `query GetVideo($id: String!) {
            getVideo(id: $id) {
              title
              description: summary
              duration: videoDuration
              videoUrl: directUrl
              isStream: live
            }
          }`,
          variables: {
            id: e
          }
        }),
        headers: {
          "User-Agent": "bannedVideoFrontEnd",
          "apollographql-client-name": "banned-web",
          "apollographql-client-version": "1.3",
          "content-type": "application/json"
        }
      })).json();
    } catch (i) {
      return console.error(`Failed to get bannedvideo video info by videoId: ${e}.`, i.message), !1;
    }
  }
  async getVideoData(e) {
    const i = await this.getVideoInfo(e);
    if (!i)
      return;
    const { videoUrl: s, duration: o, isStream: r, description: a, title: l } = i.data.getVideo;
    return {
      url: s,
      duration: o,
      isStream: r,
      title: l,
      description: a
    };
  }
  async getVideoId(e) {
    return e.searchParams.get("id") ?? void 0;
  }
}
class id extends M {
  async getVideoId(t) {
    const e = /bangumi\/play\/([^/]+)/.exec(t.pathname)?.[0];
    if (e)
      return e;
    const i = t.searchParams.get("bvid");
    if (i)
      return `video/${i}`;
    let s = /video\/([^/]+)/.exec(t.pathname)?.[0];
    return s && t.searchParams.get("p") !== null && (s += `/?p=${t.searchParams.get("p")}`), s;
  }
}
class sd extends M {
  async getVideoId(t) {
    return /(video|embed)\/([^/]+)/.exec(t.pathname)?.[2];
  }
}
class od extends M {
  async getVideoData(t) {
    try {
      const e = document.querySelector(".vlScreen > video")?.src;
      if (!e)
        throw new $("Failed to find video URL");
      return {
        url: e
      };
    } catch (e) {
      D.error(`Failed to get Bitview data by videoId: ${t}`, e.message);
      return;
    }
  }
  async getVideoId(t) {
    return t.searchParams.get("v");
  }
}
class rd extends M {
  async getVideoData(t) {
    const e = document.querySelector('#player > source[type="video/mp4"]')?.src;
    if (e)
      return {
        url: e
      };
  }
  async getVideoId(t) {
    return /\/f\/([^/]+)/.exec(t.pathname)?.[1];
  }
}
class ad extends M {
  async getVideoId(t) {
    return t.pathname + t.search;
  }
}
class ld extends M {
  constructor() {
    super(...arguments);
    u(this, "API_ORIGIN", this.origin ?? "https://coursehunter.net");
  }
  async getCourseId() {
    const e = window.course_id;
    return e !== void 0 ? String(e) : document.querySelector('input[name="course_id"]')?.value;
  }
  async getLessonsData(e) {
    const i = window.lessons;
    if (i?.length)
      return i;
    try {
      return await (await this.fetch(`${this.API_ORIGIN}/api/v1/course/${e}/lessons`)).json();
    } catch (s) {
      D.error(`Failed to get CoursehunterLike lessons data by courseId: ${e}, because ${s.message}`);
      return;
    }
  }
  getLessondId(e) {
    let i = e.split("?lesson=")?.[1];
    return i || (i = document.querySelector(".lessons-item_active")?.dataset?.index, i) ? +i : 1;
  }
  async getVideoData(e) {
    const i = await this.getCourseId();
    if (!i)
      return;
    const s = await this.getLessonsData(i);
    if (!s)
      return;
    const o = this.getLessondId(e), r = s?.[o - 1], { file: a, duration: l, title: c } = r;
    if (a)
      return {
        url: Et(a),
        duration: l,
        title: c
      };
  }
  async getVideoId(e) {
    const i = /course\/([^/]+)/.exec(e.pathname)?.[0];
    return i ? i + e.search : void 0;
  }
}
class pe extends M {
  constructor() {
    super(...arguments);
    u(this, "SUBTITLE_SOURCE", "videojs");
    u(this, "SUBTITLE_FORMAT", "vtt");
  }
  static getPlayer() {
    return document.querySelector(".video-js")?.player;
  }
  getVideoDataByPlayer(e) {
    try {
      const i = pe.getPlayer();
      if (!i)
        throw new Error(`Video player doesn't have player option, videoId ${e}`);
      const s = i.duration(), o = Array.isArray(i.currentSources) ? i.currentSources : i.getCache()?.sources, { tracks_: r } = i.textTracks(), a = o.find((c) => c.type === "video/mp4" || c.type === "video/webm");
      if (!a)
        throw new Error(`Failed to find video url for videoID ${e}`);
      const l = r.filter((c) => c.src && c.kind !== "metadata").map((c) => ({
        language: X(c.language),
        source: this.SUBTITLE_SOURCE,
        format: this.SUBTITLE_FORMAT,
        url: c.src
      }));
      return {
        url: a.src,
        duration: s,
        subtitles: l
      };
    } catch (i) {
      D.error("Failed to get videojs video data", i.message);
      return;
    }
  }
}
const Bt = [
  "auto",
  "ru",
  "en",
  "zh",
  "ko",
  "lt",
  "lv",
  "ar",
  "fr",
  "it",
  "es",
  "de",
  "ja"
], Pi = ["ru", "en", "kk"];
class Qs extends pe {
  constructor() {
    super(...arguments);
    u(this, "API_ORIGIN", "https://www.coursera.org/api");
    u(this, "SUBTITLE_SOURCE", "coursera");
  }
  async getCourseData(e) {
    try {
      return (await (await this.fetch(`${this.API_ORIGIN}/onDemandCourses.v1/${e}`)).json())?.elements?.[0];
    } catch (i) {
      D.error(`Failed to get course data by courseId: ${e}`, i.message);
      return;
    }
  }
  static getPlayer() {
    return pe.getPlayer();
  }
  async getVideoData(e) {
    const i = this.getVideoDataByPlayer(e);
    if (!i)
      return;
    const { options_: s } = Qs.getPlayer() ?? {};
    !i.subtitles?.length && s && (i.subtitles = s.tracks.map((g) => ({
      url: g.src,
      language: X(g.srclang),
      source: this.SUBTITLE_SOURCE,
      format: this.SUBTITLE_FORMAT
    })));
    const o = s?.courseId;
    if (!o)
      return i;
    let r = "en";
    const a = await this.getCourseData(o);
    if (a) {
      const { primaryLanguageCodes: [g] } = a;
      r = g ? X(g) : "en";
    }
    Bt.includes(r) || (r = "en");
    const c = (i.subtitles.find((g) => g.language === r) ?? i.subtitles?.[0])?.url;
    c || D.warn("Failed to find any subtitle file");
    const { url: d, duration: h } = i, f = c ? [
      {
        target: "subtitles_file_url",
        targetUrl: c
      },
      {
        target: "video_file_url",
        targetUrl: d
      }
    ] : null;
    return {
      ...c ? {
        url: this.service?.url + e,
        translationHelp: f
      } : {
        url: d,
        translationHelp: f
      },
      detectedLanguage: r,
      duration: h
    };
  }
  async getVideoId(e) {
    return (/learn\/([^/]+)\/lecture\/([^/]+)/.exec(e.pathname) ?? /lecture\/([^/]+)\/([^/]+)/.exec(e.pathname))?.[0];
  }
}
class ud extends M {
  async getVideoId(t) {
    const i = Array.from(document.querySelectorAll("*")).filter((s) => s.innerHTML.trim().includes(".m3u8"))?.[1]?.lastChild?.src;
    return i ? /\/video\/(\w+)\.m3u8/.exec(i)?.[1] : void 0;
  }
}
class cd extends M {
  async getVideoData(t) {
    if (!this.video)
      return;
    const e = this.video.querySelector('source[type="application/x-mpegurl"]')?.src;
    if (e)
      return {
        url: e
      };
  }
  async getVideoId(t) {
    return /courses\/(([^/]+)\/lesson\/([^/]+)\/([^/]+))/.exec(t.pathname)?.[1];
  }
}
class di extends M {
  static getPlayer() {
    if (!(typeof player > "u"))
      return player;
  }
  async getVideoData(t) {
    const e = di.getPlayer();
    if (!e)
      return;
    const { config: { url: i, duration: s, lang: o, isLive: r } } = e;
    if (!i)
      return;
    const a = i.find((l) => l.src.includes("www.douyin.com/aweme/v1/play/"));
    if (a)
      return {
        url: Et(a.src),
        duration: s,
        isStream: r,
        ...Bt.includes(o) ? { detectedLanguage: o } : {}
      };
  }
  async getVideoId(t) {
    const e = /video\/([\d]+)/.exec(t.pathname)?.[0];
    return e || di.getPlayer()?.config.vid;
  }
}
class dd extends M {
  async getVideoId(t) {
    return /video\/watch\/([^/]+)/.exec(t.pathname)?.[1];
  }
}
class hd extends M {
  async getVideoId(t) {
    return t.pathname.slice(1);
  }
}
class fd extends M {
  constructor() {
    super(...arguments);
    u(this, "API_ORIGIN", "https://dev.epicgames.com/community/api/learning");
  }
  async getPostInfo(e) {
    try {
      return await (await this.fetch(`${this.API_ORIGIN}/post.json?hash_id=${e}`)).json();
    } catch (i) {
      return D.error(`Failed to get epicgames post info by videoId: ${e}.`, i.message), !1;
    }
  }
  getVideoBlock() {
    const e = /videoUrl\s?=\s"([^"]+)"?/, i = Array.from(document.body.querySelectorAll("script")).find((a) => e.exec(a.innerHTML));
    if (!i)
      return;
    const s = i.innerHTML.trim(), o = e.exec(s)?.[1]?.replace("qsep://", "https://");
    if (!o)
      return;
    let r = /sources\s?=\s(\[([^\]]+)\])?/.exec(s)?.[1];
    if (!r)
      return {
        playlistUrl: o,
        subtitles: []
      };
    try {
      r = (r.replace(/src:(\s)+?(videoUrl)/g, 'src:"removed"').substring(0, r.lastIndexOf("},")) + "]").split(`
`).map((c) => c.replace(/([^\s]+):\s?(?!.*\1)/, '"$1":')).join(`
`);
      const l = JSON.parse(r).filter((c) => c.type === "captions");
      return {
        playlistUrl: o,
        subtitles: l
      };
    } catch {
      return {
        playlistUrl: o,
        subtitles: []
      };
    }
  }
  async getVideoData(e) {
    const i = e.split(":")?.[1], s = await this.getPostInfo(i);
    if (!s)
      return;
    const o = this.getVideoBlock();
    if (!o)
      return;
    const { playlistUrl: r, subtitles: a } = o, { title: l, description: c } = s, d = a.map((h) => ({
      language: X(h.srclang),
      source: "epicgames",
      format: "vtt",
      url: h.src
    }));
    return {
      url: r,
      title: l,
      description: c,
      subtitles: d
    };
  }
  async getVideoId(e) {
    return new Promise((i) => {
      const s = "https://dev.epicgames.com", o = btoa(window.location.href);
      window.addEventListener("message", (r) => {
        if (r.origin !== s || !(typeof r.data == "string" && r.data.startsWith("getVideoId:")))
          return;
        const a = r.data.replace("getVideoId:", "");
        return i(a);
      }), window.top.postMessage(`getVideoId:${o}`, s);
    });
  }
}
class gd extends M {
  async getVideoId(t) {
    return /video-([^/]+)\/([^/]+)/.exec(t.pathname)?.[0];
  }
}
class md extends M {
  async getVideoId(t) {
    return t.pathname.slice(1);
  }
}
class pd extends M {
  getPlayerData() {
    return document.querySelector("#movie_player")?.getVideoData?.call() ?? void 0;
  }
  async getVideoId(t) {
    return this.getPlayerData()?.video_id;
  }
}
class yd extends M {
  getVideoDataBySource(t) {
    const e = document.querySelector('.icms.video > source[type="video/mp4"][data-quality="360"]')?.src;
    return e ? {
      url: Et(e)
    } : this.returnBaseData(t);
  }
  getVideoDataByNext(t) {
    try {
      const e = document.getElementById("__NEXT_DATA__")?.textContent;
      if (!e)
        throw new ci("Not found __NEXT_DATA__ content");
      const i = JSON.parse(e), { props: { pageProps: { page: { description: s, title: o, video: { videoMetadata: { duration: r }, assets: a } } } } } = i, l = a.find((c) => c.height === 360 && c.url.includes(".mp4"))?.url;
      if (!l)
        throw new ci("Not found video URL in assets");
      return {
        url: Et(l),
        duration: r,
        title: o,
        description: s
      };
    } catch (e) {
      return D.warn(`Failed to get ign video data by video ID: ${t}, because ${e.message}. Using clear link instead...`), this.returnBaseData(t);
    }
  }
  async getVideoData(t) {
    return document.getElementById("__NEXT_DATA__") ? this.getVideoDataByNext(t) : this.getVideoDataBySource(t);
  }
  async getVideoId(t) {
    return /([^/]+)\/([\d]+)\/video\/([^/]+)/.exec(t.pathname)?.[0] ?? /\/videos\/([^/]+)/.exec(t.pathname)?.[0];
  }
}
class bd extends M {
  async getVideoId(t) {
    return /video\/([^/]+)/.exec(t.pathname)?.[1];
  }
}
class vd extends M {
  async getVideoData(t) {
    try {
      const e = document.querySelector("#incflix-stream source:first-of-type");
      if (!e)
        throw new $("Failed to find source element");
      const i = e.getAttribute("src");
      if (!i)
        throw new $("Failed to find source link");
      const s = new URL(i.startsWith("//") ? `https:${i}` : i);
      return s.searchParams.append("media-proxy", "video.mp4"), {
        url: Et(s)
      };
    } catch (e) {
      D.error(`Failed to get Incestflix data by videoId: ${t}`, e.message);
      return;
    }
  }
  async getVideoId(t) {
    return /\/watch\/([^/]+)/.exec(t.pathname)?.[1];
  }
}
class wd extends M {
  constructor() {
    super(...arguments);
    u(this, "API_ORIGIN", "https://kick.com/api");
  }
  async getClipInfo(e) {
    try {
      const s = await (await this.fetch(`${this.API_ORIGIN}/v2/clips/${e}`)).json(), { clip_url: o, duration: r, title: a } = s.clip;
      return {
        url: o,
        duration: r,
        title: a
      };
    } catch (i) {
      D.error(`Failed to get kick clip info by clipId: ${e}.`, i.message);
      return;
    }
  }
  async getVideoInfo(e) {
    try {
      const s = await (await this.fetch(`${this.API_ORIGIN}/v1/video/${e}`)).json(), { source: o, livestream: r } = s, { session_title: a, duration: l } = r;
      return {
        url: o,
        duration: Math.round(l / 1e3),
        title: a
      };
    } catch (i) {
      D.error(`Failed to get kick video info by videoId: ${e}.`, i.message);
      return;
    }
  }
  async getVideoData(e) {
    return e.startsWith("videos") ? await this.getVideoInfo(e.replace("videos/", "")) : await this.getClipInfo(e.replace("clips/", ""));
  }
  async getVideoId(e) {
    return /([^/]+)\/((videos|clips)\/([^/]+))/.exec(e.pathname)?.[2];
  }
}
class Sd extends M {
  async getVideoData(t) {
    try {
      const e = document.querySelector(".ksr-video-player > video"), i = e?.querySelector("source[type^='video/mp4']")?.src;
      if (!i)
        throw new $("Failed to find video URL");
      const s = e?.querySelectorAll("track") ?? [];
      return {
        url: i,
        subtitles: Array.from(s).reduce((o, r) => {
          const a = r.getAttribute("srclang"), l = r.getAttribute("src");
          return !a || !l || o.push({
            language: X(a),
            url: l,
            format: "vtt",
            source: "kickstarter"
          }), o;
        }, [])
      };
    } catch (e) {
      D.error(`Failed to get Kickstarter data by videoId: ${t}`, e.message);
      return;
    }
  }
  async getVideoId(t) {
    return t.pathname.slice(1);
  }
}
class Td extends M {
  constructor() {
    super(...arguments);
    u(this, "API_ORIGIN", window.location.origin);
  }
  getSecureData(e) {
    try {
      const [i, s, o] = e.split("/").filter((m) => m), r = Array.from(document.getElementsByTagName("script")), a = r.filter((m) => m.innerHTML.includes(`videoId = "${s}"`) || m.innerHTML.includes(`serialId = Number(${s})`));
      if (!a.length)
        throw new $("Failed to find secure script");
      const l = /'{[^']+}'/.exec(a[0].textContent.trim())?.[0];
      if (!l)
        throw new $("Secure json wasn't found in secure script");
      const c = JSON.parse(l.replaceAll("'", ""));
      if (i !== "serial")
        return {
          videoType: i,
          videoId: s,
          hash: o,
          ...c
        };
      const d = r.find((m) => m.innerHTML.includes("var videoInfo = {}"))?.textContent?.trim();
      if (!d)
        throw new $("Failed to find videoInfo content");
      const h = /videoInfo\.type\s+?=\s+?'([^']+)'/.exec(d)?.[1], f = /videoInfo\.id\s+?=\s+?'([^']+)'/.exec(d)?.[1], g = /videoInfo\.hash\s+?=\s+?'([^']+)'/.exec(d)?.[1];
      if (!h || !f || !g)
        throw new $("Failed to parse videoInfo content");
      return {
        videoType: h,
        videoId: f,
        hash: g,
        ...c
      };
    } catch (i) {
      return D.error(`Failed to get kodik secure data by videoPath: ${e}.`, i.message), !1;
    }
  }
  async getFtor(e) {
    const { videoType: i, videoId: s, hash: o, d: r, d_sign: a, pd: l, pd_sign: c, ref: d, ref_sign: h } = e;
    try {
      return await (await this.fetch(this.API_ORIGIN + "/ftor", {
        method: "POST",
        headers: {
          "User-Agent": et.userAgent,
          Origin: this.API_ORIGIN,
          Referer: `${this.API_ORIGIN}/${i}/${s}/${o}/360p`
        },
        body: new URLSearchParams({
          d: r,
          d_sign: a,
          pd: l,
          pd_sign: c,
          ref: decodeURIComponent(d),
          ref_sign: h,
          bad_user: "false",
          cdn_is_working: "true",
          info: "{}",
          type: i,
          hash: o,
          id: s
        })
      })).json();
    } catch (f) {
      return D.error(`Failed to get kodik video data (type: ${i}, id: ${s}, hash: ${o})`, f.message), !1;
    }
  }
  decryptUrl(e) {
    return "https:" + atob(e.replace(/[a-zA-Z]/g, function(s) {
      const o = s.charCodeAt(0) + 18, r = s <= "Z" ? 90 : 122;
      return String.fromCharCode(r >= o ? o : o - 26);
    }));
  }
  async getVideoData(e) {
    const i = this.getSecureData(e);
    if (!i)
      return;
    const s = await this.getFtor(i);
    if (!s)
      return;
    const r = Object.entries(s.links[s.default.toString()]).find(([, a]) => a.type === "application/x-mpegURL")?.[1];
    if (r)
      return {
        url: r.src.startsWith("//") ? `https:${r.src}` : this.decryptUrl(r.src)
      };
  }
  async getVideoId(e) {
    return /\/(uv|video|seria|episode|season|serial)\/([^/]+)\/([^/]+)\/([\d]+)p/.exec(e.pathname)?.[0];
  }
}
class kd extends pe {
  constructor() {
    super(...arguments);
    u(this, "SUBTITLE_SOURCE", "linkedin");
  }
  async getVideoData(e) {
    const i = this.getVideoDataByPlayer(e);
    if (!i)
      return;
    const { url: s, duration: o, subtitles: r } = i;
    return {
      url: Et(new URL(s)),
      duration: o,
      subtitles: r
    };
  }
  async getVideoId(e) {
    return /\/learning\/(([^/]+)\/([^/]+))/.exec(e.pathname)?.[1];
  }
}
var hr;
(function(n) {
  n.Channel = "Channel", n.Video = "Video";
})(hr || (hr = {}));
class Ld extends M {
  getClientVersion() {
    if (!(typeof SENTRY_RELEASE > "u"))
      return SENTRY_RELEASE.id;
  }
  async getVideoData(t) {
    try {
      const e = this.getClientVersion();
      if (!e)
        throw new $("Failed to get client version");
      const i = await this.fetch("https://www.loom.com/graphql", {
        headers: {
          "User-Agent": et.userAgent,
          "content-type": "application/json",
          "x-loom-request-source": `loom_web_${e}`,
          "apollographql-client-name": "web",
          "apollographql-client-version": e,
          "Alt-Used": "www.loom.com"
        },
        body: `{"operationName":"FetchCaptions","variables":{"videoId":"${t}"},"query":"query FetchCaptions($videoId: ID!, $password: String) {\\n  fetchVideoTranscript(videoId: $videoId, password: $password) {\\n    ... on VideoTranscriptDetails {\\n      id\\n      captions_source_url\\n      language\\n      __typename\\n    }\\n    ... on GenericError {\\n      message\\n      __typename\\n    }\\n    __typename\\n  }\\n}"}`,
        method: "POST"
      });
      if (i.status !== 200)
        throw new $("Failed to get data from graphql");
      const o = (await i.json()).data.fetchVideoTranscript;
      if (o.__typename === "GenericError")
        throw new $(o.message);
      return {
        url: this.service.url + t,
        subtitles: [
          {
            format: "vtt",
            language: X(o.language),
            source: "loom",
            url: o.captions_source_url
          }
        ]
      };
    } catch (e) {
      return D.error(`Failed to get Loom video data, because: ${e.message}`), this.returnBaseData(t);
    }
  }
  async getVideoId(t) {
    return /(embed|share)\/([^/]+)?/.exec(t.pathname)?.[2];
  }
}
class Ad extends M {
  constructor() {
    super(...arguments);
    u(this, "API_ORIGIN", "https://my.mail.ru");
  }
  async getVideoMeta(e) {
    try {
      return await (await this.fetch(`${this.API_ORIGIN}/+/video/meta/${e}?xemail=&ajax_call=1&func_name=&mna=&mnb=&ext=1&_=${(/* @__PURE__ */ new Date()).getTime()}`)).json();
    } catch (i) {
      D.error("Failed to get mail.ru video data", i.message);
      return;
    }
  }
  async getVideoId(e) {
    const i = e.pathname;
    if (/\/(v|mail|bk|inbox)\//.exec(i))
      return i.slice(1);
    const s = /video\/embed\/([^/]+)/.exec(i)?.[1];
    if (!s)
      return;
    const o = await this.getVideoMeta(s);
    if (o)
      return o.meta.url.replace("//my.mail.ru/", "");
  }
}
class xd extends pe {
  constructor() {
    super(...arguments);
    u(this, "SUBTITLE_SOURCE", "netacad");
  }
  async getVideoData(e) {
    const i = this.getVideoDataByPlayer(e);
    if (!i)
      return;
    const { url: s, duration: o, subtitles: r } = i;
    return {
      url: Et(new URL(s)),
      duration: o,
      subtitles: r
    };
  }
  async getVideoId(e) {
    return e.pathname + e.search;
  }
}
class Vd extends M {
  async getVideoId(t) {
    return /([^/]+)\/(view)\/([^/]+)/.exec(t.pathname)?.[0];
  }
}
class Cd extends M {
  async getVideoData(t) {
    const e = this.returnBaseData(t);
    if (!e)
      return e;
    try {
      if (!this.video)
        throw new Error("Video element not found");
      const i = this.video.querySelector('source[type^="video/mp4"], source[type^="video/webm"]')?.src;
      if (!i || !/^https?:\/\//.test(i))
        throw new Error("Video source not found");
      return {
        ...e,
        translationHelp: [
          {
            target: "video_file_url",
            targetUrl: i
          }
        ]
      };
    } catch {
      return e;
    }
  }
  async getVideoId(t) {
    return /gag\/([^/]+)/.exec(t.pathname)?.[1];
  }
}
class Ed extends M {
  constructor() {
    super(...arguments);
    u(this, "API_ORIGIN", "https://odysee.com");
  }
  async getVideoData(e) {
    try {
      const s = await (await this.fetch(`${this.API_ORIGIN}/${e}`)).text(), o = /"contentUrl":(\s)?"([^"]+)"/.exec(s)?.[2];
      if (!o)
        throw new $("Odysee url doesn't parsed");
      return { url: o };
    } catch (i) {
      D.error(`Failed to get odysee video data by video ID: ${e}`, i.message);
      return;
    }
  }
  async getVideoId(e) {
    return e.pathname.slice(1);
  }
}
class Id extends M {
  async getVideoId(t) {
    return /\/video\/(\d+)/.exec(t.pathname)?.[1];
  }
}
class Pd extends pe {
  constructor() {
    super(...arguments);
    u(this, "SUBTITLE_SOURCE", "oraclelearn");
  }
  async getVideoData(e) {
    const i = this.getVideoDataByPlayer(e);
    if (!i)
      return;
    const { url: s, duration: o, subtitles: r } = i, a = this.returnBaseData(e), l = Et(new URL(s));
    return a ? {
      url: a.url,
      duration: o,
      subtitles: r,
      translationHelp: [
        {
          target: "video_file_url",
          targetUrl: l
        }
      ]
    } : {
      url: l,
      duration: o,
      subtitles: r
    };
  }
  async getVideoId(e) {
    return /\/ou\/course\/(([^/]+)\/(\d+)\/(\d+))/.exec(e.pathname)?.[1];
  }
}
class Md extends M {
  constructor() {
    super(...arguments);
    u(this, "API_ORIGIN", "https://www.patreon.com/api");
  }
  async getPosts(e) {
    try {
      return await (await this.fetch(`${this.API_ORIGIN}/posts/${e}?json-api-use-default-includes=false`)).json();
    } catch (i) {
      return D.error(`Failed to get patreon posts by postId: ${e}.`, i.message), !1;
    }
  }
  async getVideoData(e) {
    const i = await this.getPosts(e);
    if (!i)
      return;
    const s = i.data.attributes.post_file.url;
    if (s)
      return {
        url: s
      };
  }
  async getVideoId(e) {
    const i = /posts\/([^/]+)/.exec(e.pathname)?.[1];
    if (i)
      return i.replace(/[^\d.]/g, "");
  }
}
class Od extends M {
  async getVideoId(t) {
    return /\/w\/([^/]+)/.exec(t.pathname)?.[0];
  }
}
class Dd extends M {
  async getVideoId(t) {
    return t.searchParams.get("viewkey") ?? /embed\/([^/]+)/.exec(t.pathname)?.[1];
  }
}
class _d extends M {
  async getVideoData(t) {
    try {
      if (typeof flashvars > "u")
        return;
      const { rnd: e, video_url: i, video_title: s } = flashvars;
      if (!i || !e)
        throw new $("Failed to find video source or rnd");
      const o = new URL(i);
      o.searchParams.append("rnd", e), D.log("PornTN get_file link", o.href);
      const r = await this.fetch(o.href, { method: "head" }), a = new URL(r.url);
      return D.log("PornTN cdn link", a.href), {
        url: Et(a),
        title: s
      };
    } catch (e) {
      D.error(`Failed to get PornTN data by videoId: ${t}`, e.message);
      return;
    }
  }
  async getVideoId(t) {
    return /\/videos\/(([^/]+)\/([^/]+))/.exec(t.pathname)?.[1];
  }
}
class Rd extends M {
  constructor() {
    super(...arguments);
    u(this, "API_ORIGIN", "https://www.reddit.com");
  }
  async getContentUrl(e) {
    return this.service?.additionalData !== "old" ? document.querySelector("shreddit-player-2")?.src : document.querySelector("[data-hls-url]")?.dataset.hlsUrl?.replaceAll("&amp;", "&");
  }
  async getVideoData(e) {
    try {
      const i = await this.getContentUrl(e);
      if (!i)
        throw new $("Failed to find content url");
      return {
        url: decodeURIComponent(i)
      };
    } catch (i) {
      D.error(`Failed to get reddit video data by video ID: ${e}`, i.message);
      return;
    }
  }
  async getVideoId(e) {
    return /\/r\/(([^/]+)\/([^/]+)\/([^/]+)\/([^/]+))/.exec(e.pathname)?.[1];
  }
}
class Bd extends M {
  async getVideoData(t) {
    const e = document.querySelector(".jw-video, .media__video_noscript");
    if (!e)
      return;
    let i = e.getAttribute("src");
    if (i)
      return i.endsWith(".MP4") && (i = Et(i)), {
        videoId: t,
        url: i
      };
  }
  async getVideoId(t) {
    return t.pathname.slice(1);
  }
}
class Fd extends M {
  async getVideoId(t) {
    return t.pathname.slice(1);
  }
}
class Nd extends M {
  async getVideoId(t) {
    return /(?:video|embed)\/([^/]+)/.exec(t.pathname)?.[1];
  }
}
class Ud extends M {
  constructor() {
    super(...arguments);
    u(this, "API_ORIGIN", "https://learning.sap.com/");
  }
  async requestKaltura(e, i, s) {
    const o = "html5:v3.17.22", r = "3.3.0";
    try {
      return await (await this.fetch(`https://${e}/api_v3/service/multirequest`, {
        method: "POST",
        body: JSON.stringify({
          1: {
            service: "session",
            action: "startWidgetSession",
            widgetId: `_${i}`
          },
          2: {
            service: "baseEntry",
            action: "list",
            ks: "{1:result:ks}",
            filter: { redirectFromEntryId: s },
            responseProfile: {
              type: 1,
              fields: "id,referenceId,name,description,dataUrl,duration,flavorParamsIds,type,dvrStatus,externalSourceType,createdAt,updatedAt,endDate,plays,views,downloadUrl,creatorId"
            }
          },
          3: {
            service: "baseEntry",
            action: "getPlaybackContext",
            entryId: "{2:result:objects:0:id}",
            ks: "{1:result:ks}",
            contextDataParams: {
              objectType: "KalturaContextDataParams",
              flavorTags: "all"
            }
          },
          apiVersion: r,
          format: 1,
          ks: "",
          clientTag: o,
          partnerId: i
        }),
        headers: {
          "Content-Type": "application/json"
        }
      })).json();
    } catch (a) {
      D.error("Failed to request kaltura data", a.message);
      return;
    }
  }
  async getKalturaData(e) {
    try {
      const i = document.querySelector('script[data-nscript="beforeInteractive"]');
      if (!i)
        throw new $("Failed to find script element");
      const s = /https:\/\/([^"]+)\/p\/([^"]+)\/embedPlaykitJs\/uiconf_id\/([^"]+)/.exec(i?.src);
      if (!s)
        throw new $(`Failed to get sap data for videoId: ${e}`);
      const [, o, r] = s;
      let a = document.querySelector("#shadow")?.firstChild?.getAttribute("id");
      if (!a) {
        const l = document.querySelector("#__NEXT_DATA__");
        if (!l)
          throw new $("Failed to find next data element");
        a = /"sourceId":\s?"([^"]+)"/.exec(l.innerText)?.[1];
      }
      if (!o || Number.isNaN(+r) || !a)
        throw new $(`One of the necessary parameters for getting a link to a sap video in wasn't found for ${e}. Params: kalturaDomain = ${o}, partnerId = ${r}, entryId = ${a}`);
      return await this.requestKaltura(o, r, a);
    } catch (i) {
      D.error("Failed to get kaltura data", i.message);
      return;
    }
  }
  async getVideoData(e) {
    const i = await this.getKalturaData(e);
    if (!i)
      return;
    const [, s, o] = i, { duration: r } = s.objects[0], a = o.sources.find((c) => c.format === "url" && c.protocols === "http,https" && c.url.includes(".mp4"))?.url;
    if (!a)
      return;
    const l = o.playbackCaptions.map((c) => ({
      language: X(c.languageCode),
      source: "sap",
      format: "vtt",
      url: c.webVttUrl,
      isAutoGenerated: c.label.includes("auto-generated")
    }));
    return {
      url: a,
      subtitles: l,
      duration: r
    };
  }
  async getVideoId(e) {
    return /((courses|learning-journeys)\/([^/]+)(\/[^/]+)?)/.exec(e.pathname)?.[1];
  }
}
class to extends M {
  static getMediaViewer() {
    if (!(typeof appMediaViewer > "u"))
      return appMediaViewer;
  }
  async getVideoId(t) {
    const e = to.getMediaViewer();
    if (!e || e.live)
      return;
    const i = e.target.message;
    if (i.peer_id._ !== "peerChannel")
      return;
    const s = i.media;
    if (s._ !== "messageMediaDocument" || s.document.type !== "video")
      return;
    const o = i.mid & 4294967295;
    return `${await e.managers.appPeersManager.getPeerUsername(i.peerId)}/${o}`;
  }
}
class $d extends M {
  async getVideoId(t) {
    return /(videos|embed)\/[^/]+/.exec(t.pathname)?.[0];
  }
}
class fr extends M {
  async getVideoId(t) {
    return /([^/]+)\/video\/([^/]+)/.exec(t.pathname)?.[0];
  }
}
class Hd extends M {
  async getVideoId(t) {
    const e = t.searchParams.get("vid"), i = /([^/]+)\/([\d]+)/.exec(t.pathname)?.[0];
    if (!(!e || !i))
      return `${i}?vid=${e}`;
  }
}
class Wd extends M {
  constructor() {
    super(...arguments);
    u(this, "API_ORIGIN", "https://clips.twitch.tv");
  }
  async getClipLink(e, i) {
    const s = document.querySelector("script[type='application/ld+json']"), o = e.slice(1);
    if (s) {
      const d = JSON.parse(s.innerText)["@graph"].find((f) => f["@type"] === "VideoObject")?.creator.url;
      if (!d)
        throw new $("Failed to find channel link");
      return `${d.replace("https://www.twitch.tv/", "")}/clip/${o}`;
    }
    const r = o === "embed", a = document.querySelector(r ? ".tw-link[data-test-selector='stream-info-card-component__stream-avatar-link']" : ".clips-player a:not([class])");
    return a ? `${a.href.replace("https://www.twitch.tv/", "")}/clip/${r ? i : o}` : void 0;
  }
  async getVideoData(e) {
    const i = document.querySelector('[data-a-target="stream-title"], [data-test-selector="stream-info-card-component__subtitle"]')?.innerText, s = !!document.querySelector('[data-a-target="animated-channel-viewers-count"], .channel-status-info--live, .top-bar--pointer-enabled .tw-channel-status-text-indicator');
    return {
      url: this.service.url + e,
      isStream: s,
      title: i
    };
  }
  async getVideoId(e) {
    const i = e.pathname;
    if (/^m\.twitch\.tv$/.test(i))
      return /videos\/([^/]+)/.exec(e.href)?.[0] ?? i.slice(1);
    if (/^player\.twitch\.tv$/.test(e.hostname))
      return `videos/${e.searchParams.get("video")}`;
    const s = /([^/]+)\/(?:clip)\/([^/]+)/.exec(i);
    if (s)
      return s[0];
    if (/^clips\.twitch\.tv$/.test(e.hostname))
      return await this.getClipLink(i, e.searchParams.get("clip"));
    const r = /(?:videos)\/([^/]+)/.exec(i);
    if (r)
      return r[0];
    const a = document.querySelector(".home-offline-hero .tw-link");
    if (a?.href) {
      const l = new URL(a.href);
      return /(?:videos)\/([^/]+)/.exec(l.pathname)?.[0];
    }
    return document.querySelector(".persistent-player") ? i : void 0;
  }
}
class zd extends M {
  async getVideoId(t) {
    const e = /status\/([^/]+)/.exec(t.pathname)?.[1];
    if (e)
      return e;
    const s = this.video?.closest('[data-testid="tweet"]')?.querySelector('a[role="link"][aria-label]')?.href;
    return s ? /status\/([^/]+)/.exec(s)?.[1] : void 0;
  }
}
class qd extends M {
  constructor() {
    super(...arguments);
    u(this, "API_ORIGIN", "https://www.udemy.com/api-2.0");
  }
  getModuleData() {
    const i = document.querySelector(".ud-app-loader[data-module-id='course-taking']")?.dataset?.moduleArgs;
    if (i)
      return JSON.parse(i);
  }
  getLectureId() {
    return /learn\/lecture\/([^/]+)/.exec(window.location.pathname)?.[1];
  }
  isErrorData(e) {
    return Object.hasOwn(e, "error");
  }
  async getLectureData(e, i) {
    try {
      const o = await (await this.fetch(`${this.API_ORIGIN}/users/me/subscribed-courses/${e}/lectures/${i}/?` + new URLSearchParams({
        "fields[lecture]": "title,description,asset",
        "fields[asset]": "length,media_sources,captions"
      }).toString())).json();
      if (this.isErrorData(o))
        throw new $(o.detail ?? "unknown error");
      return o;
    } catch (s) {
      D.error(`Failed to get lecture data by courseId: ${e} and lectureId: ${i}`, s.message);
      return;
    }
  }
  async getCourseLang(e) {
    try {
      const s = await (await this.fetch(`${this.API_ORIGIN}/users/me/subscribed-courses/${e}?` + new URLSearchParams({
        "fields[course]": "locale"
      }).toString())).json();
      if (this.isErrorData(s))
        throw new $(s.detail ?? "unknown error");
      return s;
    } catch (i) {
      D.error(`Failed to get course lang by courseId: ${e}`, i.message);
      return;
    }
  }
  findVideoUrl(e) {
    return e?.find((i) => i.type === "video/mp4")?.src;
  }
  findSubtitleUrl(e, i) {
    return (e?.find((o) => X(o.locale_id) === i) ?? e?.find((o) => X(o.locale_id) === "en") ?? e?.[0])?.url;
  }
  async getVideoData(e) {
    const i = this.getModuleData();
    if (!i)
      return;
    const { courseId: s } = i, o = this.getLectureId();
    if (D.log(`[Udemy] courseId: ${s}, lectureId: ${o}`), !o)
      return;
    const r = await this.getLectureData(s, o);
    if (!r)
      return;
    const { title: a, description: l, asset: c } = r, { length: d, media_sources: h, captions: f } = c, g = this.findVideoUrl(h);
    if (!g) {
      D.log("Failed to find .mp4 video file in media_sources", h);
      return;
    }
    let m = "en";
    const v = await this.getCourseLang(s);
    if (v) {
      const { locale: { locale: T } } = v;
      m = T ? X(T) : m;
    }
    Bt.includes(m) || (m = "en");
    const S = this.findSubtitleUrl(f, m);
    return S || D.log("Failed to find subtitle file in captions", f), {
      ...S ? {
        url: this.service?.url + e,
        translationHelp: [
          {
            target: "subtitles_file_url",
            targetUrl: S
          },
          {
            target: "video_file_url",
            targetUrl: g
          }
        ],
        detectedLanguage: m
      } : {
        url: g,
        translationHelp: null
      },
      duration: d,
      title: a,
      description: l
    };
  }
  async getVideoId(e) {
    return e.pathname.slice(1);
  }
}
class Gd extends M {
  constructor() {
    super(...arguments);
    u(this, "API_KEY", "");
    u(this, "DEFAULT_SITE_ORIGIN", "https://vimeo.com");
    u(this, "SITE_ORIGIN", this.service?.url?.slice(0, -1) ?? this.DEFAULT_SITE_ORIGIN);
  }
  isErrorData(e) {
    return Object.hasOwn(e, "error");
  }
  isPrivatePlayer() {
    return this.referer && !this.referer.includes("vimeo.com") && this.origin.endsWith("player.vimeo.com");
  }
  async getViewerData() {
    try {
      const i = await (await this.fetch("https://vimeo.com/_next/viewer")).json(), { apiUrl: s, jwt: o } = i;
      return this.API_ORIGIN = `https://${s}`, this.API_KEY = `jwt ${o}`, i;
    } catch (e) {
      return D.error("Failed to get default viewer data.", e.message), !1;
    }
  }
  async getVideoInfo(e) {
    try {
      const i = new URLSearchParams({
        fields: "name,link,description,duration"
      }).toString(), o = await (await this.fetch(`${this.API_ORIGIN}/videos/${e}?${i}`, {
        headers: {
          Authorization: this.API_KEY
        }
      })).json();
      if (this.isErrorData(o))
        throw new Error(o.developer_message ?? o.error);
      return o;
    } catch (i) {
      return D.error(`Failed to get video info by video ID: ${e}`, i.message), !1;
    }
  }
  async getPrivateVideoSource(e) {
    try {
      const { default_cdn: i, cdns: s } = e.dash, o = s[i].url, r = await this.fetch(o);
      if (r.status !== 200)
        throw new $(await r.text());
      const a = await r.json(), l = new URL(a.base_url, o), c = a.audio.find((m) => m.mime_type === "audio/mp4" && m.format === "dash");
      if (!c)
        throw new $("Failed to find video data");
      const d = c.segments?.[0]?.url;
      if (!d)
        throw new $("Failed to find first segment url");
      const [h, f] = d.split("?", 2), g = new URLSearchParams(f);
      return g.delete("range"), new URL(`${c.base_url}${h}?${g.toString()}`, l).href;
    } catch (i) {
      return D.error("Failed to get private video source", i.message), !1;
    }
  }
  async getPrivateVideoInfo(e) {
    try {
      if (typeof playerConfig > "u")
        return;
      const i = await this.getPrivateVideoSource(playerConfig.request.files);
      if (!i)
        throw new $("Failed to get private video source");
      const { video: { title: s, duration: o }, request: { text_tracks: r } } = playerConfig;
      return {
        url: `${this.SITE_ORIGIN}/${e}`,
        video_url: i,
        title: s,
        duration: o,
        subs: r
      };
    } catch (i) {
      return D.error(`Failed to get private video info by video ID: ${e}`, i.message), !1;
    }
  }
  async getSubsInfo(e) {
    try {
      const i = new URLSearchParams({
        per_page: "100",
        fields: "language,type,link"
      }).toString(), o = await (await this.fetch(`${this.API_ORIGIN}/videos/${e}/texttracks?${i}`, {
        headers: {
          Authorization: this.API_KEY
        }
      })).json();
      if (this.isErrorData(o))
        throw new Error(o.developer_message ?? o.error);
      return o.data;
    } catch (i) {
      return D.error(`Failed to get subtitles info by video ID: ${e}`, i.message), [];
    }
  }
  async getVideoData(e) {
    if (this.isPrivatePlayer()) {
      const f = await this.getPrivateVideoInfo(e);
      if (!f)
        return;
      const { url: g, subs: m, video_url: v, title: S, duration: T } = f, w = m.map((P) => ({
        language: X(P.lang),
        source: "vimeo",
        format: "vtt",
        url: this.SITE_ORIGIN + P.url,
        isAutoGenerated: P.lang.includes("autogenerated")
      })), A = w.length ? [
        { target: "video_file_url", targetUrl: v },
        { target: "subtitles_file_url", targetUrl: w[0].url }
      ] : null;
      return {
        ...A ? {
          url: g,
          translationHelp: A
        } : {
          url: v
        },
        subtitles: w,
        title: S,
        duration: T
      };
    }
    if (!this.extraInfo)
      return this.returnBaseData(e);
    if (e.includes("/") && (e = e.replace("/", ":")), !await this.getViewerData())
      return this.returnBaseData(e);
    const o = await this.getVideoInfo(e);
    if (!o)
      return this.returnBaseData(e);
    const a = (await this.getSubsInfo(e)).map((f) => ({
      language: X(f.language),
      source: "vimeo",
      format: "vtt",
      url: f.link,
      isAutoGenerated: f.language.includes("autogen")
    })), { link: l, duration: c, name: d, description: h } = o;
    return {
      url: l,
      title: d,
      description: h,
      subtitles: a,
      duration: c
    };
  }
  async getVideoId(e) {
    const i = /video\/[^/]+$/.exec(e.pathname)?.[0];
    if (this.isPrivatePlayer())
      return i;
    if (i) {
      const o = e.searchParams.get("h"), r = i.replace("video/", "");
      return o ? `${r}/${o}` : r;
    }
    const s = /channels\/[^/]+\/([^/]+)/.exec(e.pathname)?.[1] ?? /groups\/[^/]+\/videos\/([^/]+)/.exec(e.pathname)?.[1] ?? /(showcase|album)\/[^/]+\/video\/([^/]+)/.exec(e.pathname)?.[2];
    return s || /([^/]+\/)?[^/]+$/.exec(e.pathname)?.[0];
  }
}
const Kd = (n) => new Promise((t) => setTimeout(t, n));
class eo extends M {
  static getPlayer() {
    if (!(typeof Videoview > "u"))
      return Videoview?.getPlayerObject?.call(void 0);
  }
  async getVideoData(t) {
    const e = await this.waitForPlayerWithSubs();
    if (!e)
      return this.returnBaseData(t);
    try {
      const { description: i, duration: s, md_title: o } = e.vars, a = new DOMParser().parseFromString(i, "text/html"), l = Array.from(a.body.childNodes).filter((d) => d.nodeName !== "BR").map((d) => d.textContent).join(`
`);
      let c;
      return Object.hasOwn(e.vars, "subs") && (c = e.vars.subs.map((d) => ({
        language: X(d.lang),
        source: "vk",
        format: "vtt",
        url: d.url,
        isAutoGenerated: !!d.is_auto
      }))), {
        url: this.service.url + t,
        title: o,
        description: l,
        duration: s,
        subtitles: c
      };
    } catch (i) {
      return D.error(`Failed to get VK video data, because: ${i.message}`), this.returnBaseData(t);
    }
  }
  async waitForPlayerWithSubs(t = 3e3) {
    const e = Date.now();
    let i;
    for (; Date.now() - e < t; ) {
      const s = eo.getPlayer();
      i = s;
      const o = s?.vars?.subs;
      if (Array.isArray(o) && o.length > 0)
        return s;
      await Kd(200);
    }
    return i;
  }
  async getVideoId(t) {
    const e = /^\/(video|clip)-?\d{8,9}_\d{9}$/.exec(t.pathname);
    if (e)
      return e[0].slice(1);
    const i = /\/playlist\/[^/]+\/(video-?\d{8,9}_\d{9})/.exec(t.pathname);
    if (i)
      return i[1];
    const s = t.searchParams.get("z");
    if (s)
      return s.split("/")[0];
    const o = t.searchParams.get("oid"), r = t.searchParams.get("id");
    if (o && r)
      return `video-${Math.abs(parseInt(o))}_${r}`;
  }
}
class Yd extends M {
  async getVideoId(t) {
    return /(video|embed)\/(\d+)(\/[^/]+\/)?/.exec(t.pathname)?.[0];
  }
}
class jd extends M {
  constructor() {
    super(...arguments);
    u(this, "API_ORIGIN", "https://global.apis.naver.com/weverse/wevweb");
    u(this, "API_APP_ID", "be4d79eb8fc7bd008ee82c8ec4ff6fd4");
    u(this, "API_HMAC_KEY", "1b9cb6378d959b45714bec49971ade22e6e24e42");
    u(this, "HEADERS", {
      Accept: "application/json, text/plain, */*",
      Origin: "https://weverse.io",
      Referer: "https://weverse.io/"
    });
  }
  getURLData() {
    return {
      appId: this.API_APP_ID,
      language: "en",
      os: "WEB",
      platform: "WEB",
      wpf: "pc"
    };
  }
  async createHash(e) {
    const i = Date.now(), s = e.substring(0, Math.min(255, e.length)) + i, o = await Bc(this.API_HMAC_KEY, s);
    if (!o)
      throw new $("Failed to get weverse HMAC signature");
    return {
      wmsgpad: i.toString(),
      wmd: o
    };
  }
  async getHashURLParams(e) {
    const i = await this.createHash(e);
    return new URLSearchParams(i).toString();
  }
  async getPostPreview(e) {
    const i = `/post/v1.0/post-${e}/preview?` + new URLSearchParams({
      fieldSet: "postForPreview",
      ...this.getURLData()
    }).toString();
    try {
      const s = await this.getHashURLParams(i);
      return await (await this.fetch(this.API_ORIGIN + i + "&" + s, {
        headers: this.HEADERS
      })).json();
    } catch (s) {
      return D.error(`Failed to get weverse post preview by postId: ${e}`, s.message), !1;
    }
  }
  async getVideoInKey(e) {
    const i = `/video/v1.1/vod/${e}/inKey?` + new URLSearchParams({
      gcc: "RU",
      ...this.getURLData()
    }).toString();
    try {
      const s = await this.getHashURLParams(i);
      return await (await this.fetch(this.API_ORIGIN + i + "&" + s, {
        method: "POST",
        headers: this.HEADERS
      })).json();
    } catch (s) {
      return D.error(`Failed to get weverse InKey by videoId: ${e}`, s.message), !1;
    }
  }
  async getVideoInfo(e, i, s) {
    const o = Date.now();
    try {
      const r = new URLSearchParams({
        key: i,
        sid: s,
        nonce: o.toString(),
        devt: "html5_pc",
        prv: "N",
        aup: "N",
        stpb: "N",
        cpl: "en",
        env: "prod",
        lc: "en",
        adi: JSON.stringify([
          {
            adSystem: null
          }
        ]),
        adu: "/"
      }).toString();
      return await (await this.fetch(`https://global.apis.naver.com/rmcnmv/rmcnmv/vod/play/v2.0/${e}?` + r, {
        headers: this.HEADERS
      })).json();
    } catch (r) {
      return D.error(`Failed to get weverse video info (infraVideoId: ${e}, inkey: ${i}, serviceId: ${s}`, r.message), !1;
    }
  }
  extractVideoInfo(e) {
    return e.find((i) => i.useP2P === !1 && i.source.includes(".mp4"));
  }
  async getVideoData(e) {
    const i = await this.getPostPreview(e);
    if (!i)
      return;
    const { videoId: s, serviceId: o, infraVideoId: r } = i.extension.video;
    if (!(s && o && r))
      return;
    const a = await this.getVideoInKey(s);
    if (!a)
      return;
    const l = await this.getVideoInfo(r, a.inKey, o);
    if (!l)
      return;
    const c = this.extractVideoInfo(l.videos.list);
    if (c)
      return {
        url: c.source,
        duration: c.duration
      };
  }
  async getVideoId(e) {
    return /([^/]+)\/(live|media)\/([^/]+)/.exec(e.pathname)?.[3];
  }
}
class Xd extends M {
  async getVideoId(t) {
    return /[^/]+\/[^/]+$/.exec(t.pathname)?.[0];
  }
}
class Jd extends M {
  constructor() {
    super(...arguments);
    u(this, "API_ORIGIN", window.location.origin);
    u(this, "CLIENT_PREFIX", "/client/disk");
    u(this, "INLINE_PREFIX", "/i/");
    u(this, "DISK_PREFIX", "/d/");
  }
  isErrorData(e) {
    return Object.hasOwn(e, "error");
  }
  async getClientVideoData(e) {
    const s = new URL(window.location.href).searchParams.get("idDialog");
    if (!s)
      return;
    const o = document.querySelector("#preloaded-data");
    if (o)
      try {
        const r = JSON.parse(o.innerText), { idClient: a, sk: l } = r.config, d = await (await this.fetch(this.API_ORIGIN + "/models-v2?m=mpfs/info", {
          method: "POST",
          body: JSON.stringify({
            apiMethod: "mpfs/info",
            connection_id: a,
            requestParams: {
              path: s
            },
            sk: l
          }),
          headers: {
            "Content-Type": "application/json"
          }
        })).json();
        if (this.isErrorData(d))
          throw new $(d.error?.message ?? d.error?.code);
        if (d?.type !== "file")
          throw new $("Failed to get resource info");
        const { meta: { short_url: h, video_info: f }, name: g } = d;
        if (!f)
          throw new $("There's no video open right now");
        if (!h)
          throw new $("Access to the video is limited");
        const m = this.clearTitle(g), v = Math.round(f.duration / 1e3);
        return {
          url: h,
          title: m,
          duration: v
        };
      } catch (r) {
        D.error(`Failed to get yandex disk video data by video ID: ${e}, because ${r.message}`);
        return;
      }
  }
  clearTitle(e) {
    return e.replace(/(\.[^.]+)$/, "");
  }
  getBodyHash(e, i) {
    const s = JSON.stringify({
      hash: e,
      sk: i
    });
    return encodeURIComponent(s);
  }
  async fetchList(e, i) {
    const s = this.getBodyHash(e, i), r = await (await this.fetch(this.API_ORIGIN + "/public/api/fetch-list", {
      method: "POST",
      body: s
    })).json();
    if (Object.hasOwn(r, "error"))
      throw new $("Failed to fetch folder list");
    return r.resources;
  }
  async getDownloadUrl(e, i) {
    const s = this.getBodyHash(e, i), r = await (await this.fetch(this.API_ORIGIN + "/public/api/download-url", {
      method: "POST",
      body: s
    })).json();
    if (r.error)
      throw new $("Failed to get download url");
    return r.data.url;
  }
  async getDiskVideoData(e) {
    try {
      const i = document.getElementById("store-prefetch");
      if (!i)
        throw new $("Failed to get prefetch data");
      const s = e.split("/").slice(3);
      if (!s.length)
        throw new $("Failed to find video file path");
      const o = JSON.parse(i.innerText), { resources: r, rootResourceId: a, environment: { sk: l } } = o, c = r[a], d = s.length - 1, h = s.filter((O, Q) => Q !== d).join("/");
      let f = Object.values(r);
      h.includes("/") && (f = await this.fetchList(`${c.hash}:/${h}`, l));
      const g = f.find((O) => O.name === s[d]);
      if (!g)
        throw new $("Failed to find resource");
      if (g && g.type === "dir")
        throw new $("Path is dir, but expected file");
      const { meta: { short_url: m, mediatype: v, videoDuration: S }, path: T, name: w } = g;
      if (v !== "video")
        throw new $("Resource isn't a video");
      const A = this.clearTitle(w), P = Math.round(S / 1e3);
      if (m)
        return {
          url: m,
          duration: P,
          title: A
        };
      const _ = await this.getDownloadUrl(T, l);
      return {
        url: Et(new URL(_)),
        duration: P,
        title: A
      };
    } catch (i) {
      D.error(`Failed to get yandex disk video data by disk video ID: ${e}`, i.message);
      return;
    }
  }
  async getVideoData(e) {
    return e.startsWith(this.INLINE_PREFIX) || /^\/d\/([^/]+)$/.exec(e) ? {
      url: this.service.url + e.slice(1)
    } : (e = decodeURIComponent(e), e.startsWith(this.CLIENT_PREFIX) ? await this.getClientVideoData(e) : await this.getDiskVideoData(e));
  }
  async getVideoId(e) {
    if (e.pathname.startsWith(this.CLIENT_PREFIX))
      return e.pathname + e.search;
    const i = /\/i\/([^/]+)/.exec(e.pathname)?.[0];
    return i || (/\/d\/([^/]+)/.exec(e.pathname) ? e.pathname : void 0);
  }
}
class Zd extends M {
  async getVideoId(t) {
    return /v_show\/id_[\w=]+/.exec(t.pathname)?.[0];
  }
}
let Dt = class J extends M {
  static isMobile() {
    return /^m\.youtube\.com$/.test(window.location.hostname);
  }
  static getPlayer() {
    return window.location.pathname.startsWith("/shorts/") && !J.isMobile() ? document.querySelector("#shorts-player") : document.querySelector("#movie_player");
  }
  static getPlayerResponse() {
    return J.getPlayer()?.getPlayerResponse?.call(void 0);
  }
  static getPlayerData() {
    return J.getPlayer()?.getVideoData?.call(void 0);
  }
  static getVolume() {
    const t = J.getPlayer();
    return t?.getVolume ? t.getVolume() / 100 : 1;
  }
  static setVolume(t) {
    const e = J.getPlayer();
    return e?.setVolume ? (e.setVolume(Math.round(t * 100)), !0) : !1;
  }
  static isMuted() {
    const t = J.getPlayer();
    return t?.isMuted ? t.isMuted() : !1;
  }
  static videoSeek(t, e) {
    D.log("videoSeek", e);
    const s = (J.getPlayer()?.getProgressState()?.seekableEnd ?? t.currentTime) - e;
    t.currentTime = s;
  }
  static getPoToken() {
    const t = J.getPlayer();
    if (!t)
      return;
    const e = t.getAudioTrack?.call(void 0);
    if (!e?.captionTracks?.length)
      return;
    const i = e.captionTracks.find((s) => s.url.includes("&pot="));
    if (i)
      return /&pot=([^&]+)/.exec(i.url)?.[1];
  }
  static getGlobalConfig() {
    return typeof yt < "u" ? yt?.config_ : typeof ytcfg < "u" ? ytcfg?.data_ : void 0;
  }
  static getDeviceParams() {
    const t = J.getGlobalConfig();
    if (!t)
      return "c=WEB";
    const e = t.INNERTUBE_CONTEXT?.client, i = new URLSearchParams(t.DEVICE);
    return i.delete("ceng"), i.delete("cengver"), i.set("c", e?.clientName ?? t.INNERTUBE_CLIENT_NAME), i.set("cver", e?.clientVersion ?? t.INNERTUBE_CLIENT_VERSION), i.set("cplayer", "UNIPLAYER"), i.toString();
  }
  static getSubtitles(t) {
    const i = J.getPlayerResponse()?.captions?.playerCaptionsTracklistRenderer;
    if (!i)
      return [];
    const s = i.captionTracks ?? [], r = (i.translationLanguages ?? []).find((d) => d.languageCode === t), l = s.find((d) => d?.kind === "asr")?.languageCode ?? "en", c = s.reduce((d, h) => {
      if (!("languageCode" in h))
        return d;
      const f = h.languageCode ? X(h.languageCode) : void 0, g = h.baseUrl;
      if (!f || !g)
        return d;
      const m = `${g.startsWith("http") ? g : `${window.location.origin}/${g}`}&fmt=json3`;
      return d.push({
        source: "youtube",
        format: "json",
        language: f,
        isAutoGenerated: h?.kind === "asr",
        url: m
      }), r && h.isTranslatable && h.languageCode === l && t !== f && d.push({
        source: "youtube",
        format: "json",
        language: t,
        isAutoGenerated: h?.kind === "asr",
        translatedFromLanguage: f,
        url: `${m}&tlang=${t}`
      }), d;
    }, []);
    return D.log("youtube subtitles:", c), c;
  }
  static getLanguage() {
    if (!J.isMobile()) {
      const s = J.getPlayer()?.getAudioTrack?.call(void 0)?.getLanguageInfo();
      if (s && s.id !== "und")
        return X(s.id.split(".")[0]);
    }
    const e = J.getPlayerResponse()?.captions?.playerCaptionsTracklistRenderer.captionTracks.find((i) => i.kind === "asr" && i.languageCode);
    return e ? X(e.languageCode) : void 0;
  }
  async getVideoData(t) {
    const { title: e } = J.getPlayerData() ?? {}, { shortDescription: i, isLive: s, title: o } = J.getPlayerResponse()?.videoDetails ?? {}, r = J.getSubtitles(this.language);
    let a = J.getLanguage();
    a && !Bt.includes(a) && (a = void 0);
    const l = J.getPlayer()?.getDuration?.call(void 0) ?? void 0;
    return {
      url: this.service.url + t,
      isStream: s,
      title: o,
      localizedTitle: e,
      detectedLanguage: a,
      description: i,
      subtitles: r,
      duration: l
    };
  }
  async getVideoId(t) {
    if (t.hostname === "youtu.be" && (t.search = `?v=${t.pathname.replace("/", "")}`, t.pathname = "/watch"), t.searchParams.has("enablejsapi")) {
      const e = J.getPlayer()?.getVideoUrl();
      t = e ? new URL(e) : t;
    }
    return /(?:watch|embed|shorts|live)\/([^/]+)/.exec(t.pathname)?.[1] ?? t.searchParams.get("v");
  }
};
const Gl = {
  [b.mailru]: Ad,
  [b.weverse]: jd,
  [b.kodik]: Td,
  [b.patreon]: Md,
  [b.reddit]: Rd,
  [b.bannedvideo]: nd,
  [b.kick]: wd,
  [b.appledeveloper]: Qc,
  [b.epicgames]: fd,
  [b.odysee]: Ed,
  [b.coursehunterLike]: ld,
  [b.twitch]: Wd,
  [b.sap]: Ud,
  [b.linkedin]: kd,
  [b.vimeo]: Gd,
  [b.yandexdisk]: Jd,
  [b.vk]: eo,
  [b.trovo]: Hd,
  [b.incestflix]: vd,
  [b.porntn]: _d,
  [b.googledrive]: pd,
  [b.bilibili]: id,
  [b.xvideos]: Xd,
  [b.watchpornto]: Yd,
  [b.archive]: td,
  [b.dailymotion]: ud,
  [b.youku]: Zd,
  [b.egghead]: hd,
  [b.newgrounds]: Vd,
  [b.okru]: Id,
  [b.peertube]: Od,
  [b.eporner]: gd,
  [b.bitchute]: sd,
  [b.rutube]: Nd,
  [b.facebook]: md,
  [b.rumble]: Fd,
  [b.twitter]: zd,
  [b.pornhub]: Dd,
  [b.tiktok]: fr,
  [b.proxitok]: fr,
  [b.nine_gag]: Cd,
  [b.youtube]: Dt,
  [b.ricktube]: Dt,
  [b.invidious]: Dt,
  [b.poketube]: Dt,
  [b.piped]: Dt,
  [b.dzen]: dd,
  [b.cloudflarestream]: ad,
  [b.loom]: Ld,
  [b.rtnews]: Bd,
  [b.bitview]: od,
  [b.thisvid]: $d,
  [b.ign]: yd,
  [b.bunkr]: rd,
  [b.imdb]: bd,
  [b.telegram]: to,
  [tt.udemy]: qd,
  [tt.coursera]: Qs,
  [tt.douyin]: di,
  [tt.artstation]: ed,
  [tt.kickstarter]: Sd,
  [tt.oraclelearn]: Pd,
  [tt.deeplearningai]: cd,
  [tt.netacad]: xd
};
class Kl {
  constructor(t = {}) {
    u(this, "helpersData");
    this.helpersData = t;
  }
  getHelper(t) {
    return new Gl[t](this.helpersData);
  }
}
function Qd() {
  if (zc.exec(window.location.href))
    return [];
  const n = window.location.hostname, t = new URL(window.location.href), e = (i) => i instanceof RegExp ? i.test(n) : typeof i == "string" ? n.includes(i) : typeof i == "function" ? i(t) : !1;
  return Zc.filter((i) => (Array.isArray(i.match) ? i.match.some(e) : e(i.match)) && i.host && i.url);
}
async function Yl(n, t = {}) {
  const e = new URL(window.location.href), i = n.host;
  return Object.keys(Gl).includes(i) ? await new Kl(t).getHelper(i).getVideoId(e) : i === b.custom ? e.href : void 0;
}
async function th(n, t = {}) {
  const e = await Yl(n, t);
  if (!e)
    throw new ci(`Entered unsupported link: "${n.host}"`);
  const i = window.location.origin;
  if ([
    b.peertube,
    b.coursehunterLike,
    b.cloudflarestream
  ].includes(n.host) && (n.url = i), n.rawResult)
    return {
      url: e,
      videoId: e,
      host: n.host,
      duration: void 0
    };
  if (!n.needExtraData)
    return {
      url: n.url + e,
      videoId: e,
      host: n.host,
      duration: void 0
    };
  const o = await new Kl({
    ...t,
    service: n,
    origin: i
  }).getHelper(n.host).getVideoData(e);
  if (!o)
    throw new ci(`Failed to get video raw url for ${n.host}`);
  return {
    ...o,
    videoId: e,
    host: n.host
  };
}
const cn = {
  version: "1.0.6",
  debug: !1,
  fetchFn: fetch.bind(window)
}, lt = {
  log: (...n) => {
    if (cn.debug)
      return console.log(`%c✦ chaimu.js v${cn.version} ✦`, "background: #000; color: #fff; padding: 0 8px", ...n);
  }
}, gr = [
  "playing",
  "ratechange",
  "play",
  "waiting",
  "pause",
  "seeked"
];
function no() {
  const n = window.AudioContext || window.webkitAudioContext;
  return n ? new n() : void 0;
}
class io {
  constructor(t, e) {
    u(this, "chaimu");
    u(this, "fetch");
    u(this, "_src");
    u(this, "fetchOpts");
    u(this, "handleVideoEvent", (t) => (lt.log(`handle video ${t.type}`), this.lipSync(t.type), this));
    this.chaimu = t, this._src = e, this.fetch = this.chaimu.fetchFn, this.fetchOpts = this.chaimu.fetchOpts;
  }
  async init() {
    return this;
  }
  async clear() {
    return this;
  }
  lipSync(t = !1) {
    return this;
  }
  removeVideoEvents() {
    for (const t of gr)
      this.chaimu.video?.removeEventListener(t, this.handleVideoEvent);
    return this;
  }
  addVideoEvents() {
    for (const t of gr)
      this.chaimu.video?.addEventListener(t, this.handleVideoEvent);
    return this;
  }
  async play() {
    return this;
  }
  async pause() {
    return this;
  }
  get name() {
    return this.constructor.name;
  }
  set src(t) {
    this._src = t;
  }
  get src() {
    return this._src;
  }
  get currentSrc() {
    return this._src;
  }
  set volume(t) {
  }
  get volume() {
    return 0;
  }
  get playbackRate() {
    return 0;
  }
  set playbackRate(t) {
  }
  get currentTime() {
    return 0;
  }
}
u(io, "name", "BasePlayer");
class jl extends io {
  constructor(e, i) {
    super(e, i);
    u(this, "audio");
    u(this, "gainNode");
    u(this, "audioSource");
    u(this, "audioErrorHandle", (e) => {
      e instanceof DOMException && e.name === "NotAllowedError" ? console.warn("[AudioPlayer] autoplay blocked, waiting for user gesture") : console.error("[AudioPlayer]", e);
    });
    this.updateAudio();
  }
  initAudioBooster() {
    return this.chaimu.audioContext ? (this.disconnectAudioNodes(), this.gainNode = this.chaimu.audioContext.createGain(), this.gainNode.connect(this.chaimu.audioContext.destination), this.audioSource = this.chaimu.audioContext.createMediaElementSource(this.audio), this.audioSource.connect(this.gainNode), this) : this;
  }
  disconnectAudioNodes() {
    this.audioSource && (this.audioSource.disconnect(), this.audioSource = void 0), this.gainNode && (this.gainNode.disconnect(), this.gainNode = void 0);
  }
  updateAudio() {
    return this.audio = new Audio(this.src), this.audio.crossOrigin = "anonymous", this;
  }
  async init() {
    return this.updateAudio(), this.initAudioBooster(), this;
  }
  lipSync(e = !1) {
    if (lt.log("[AudioPlayer] lipsync video", this.chaimu.video), !this.chaimu.video)
      return this;
    if (this.audio.currentTime = this.chaimu.video.currentTime, this.audio.playbackRate = this.chaimu.video.playbackRate, !e)
      return lt.log("[AudioPlayer] lipsync mode isn't set"), this;
    switch (lt.log(`[AudioPlayer] lipsync mode is ${e}`), e) {
      case "play":
      case "playing":
      case "seeked":
        return this.chaimu.video.paused || this.syncPlay(), this;
      case "pause":
      case "waiting":
        return this.pause(), this;
      default:
        return this;
    }
  }
  async clear() {
    return this.audio.pause(), this.audio.src = "", this.audio.removeAttribute("src"), this.disconnectAudioNodes(), this;
  }
  syncPlay() {
    return lt.log("[AudioPlayer] sync play called"), this.audio && this.audio.play().catch(this.audioErrorHandle), this;
  }
  async play() {
    return lt.log("[AudioPlayer] play called"), this.audio && await this.audio.play().catch(this.audioErrorHandle), this;
  }
  async pause() {
    return lt.log("[AudioPlayer] pause called"), this.audio && this.audio.pause(), this;
  }
  set src(e) {
    if (this._src = e, !e) {
      this.clear();
      return;
    }
    this.audio.src = e;
  }
  get src() {
    return this._src;
  }
  get currentSrc() {
    return this.audio.currentSrc;
  }
  set volume(e) {
    if (this.gainNode) {
      this.gainNode.gain.value = e;
      return;
    }
    this.audio.volume = e;
  }
  get volume() {
    return this.gainNode ? this.gainNode.gain.value : this.audio.volume;
  }
  get playbackRate() {
    return this.audio.playbackRate;
  }
  set playbackRate(e) {
    this.audio.playbackRate = e;
  }
  get currentTime() {
    return this.audio.currentTime;
  }
}
u(jl, "name", "AudioPlayer");
class Xl extends io {
  constructor() {
    super(...arguments);
    u(this, "audioBuffer");
    u(this, "audioElement");
    u(this, "mediaElementSource");
    u(this, "gainNode");
    u(this, "blobUrl");
    u(this, "isClearing", !1);
    u(this, "isInitializing", !1);
    u(this, "clearingPromise");
  }
  async fetchAudio() {
    if (!this._src)
      throw new Error("No audio source provided");
    if (!this.chaimu.audioContext)
      throw new Error("No audio context available");
    lt.log(`[ChaimuPlayer] Fetching audio from ${this._src}...`);
    let e;
    try {
      const i = await this.fetch(this._src, this.fetchOpts);
      lt.log("[ChaimuPlayer] Decoding fetched audio...");
      const s = await i.arrayBuffer(), o = new Blob([s]);
      e = URL.createObjectURL(o), this.audioBuffer = await this.chaimu.audioContext.decodeAudioData(s), this.blobUrl && URL.revokeObjectURL(this.blobUrl), this.blobUrl = e, e = void 0;
    } catch (i) {
      throw e && URL.revokeObjectURL(e), new Error(`Failed to fetch audio file, because ${i.message}`);
    }
    return this;
  }
  initAudioBooster() {
    return this.chaimu.audioContext ? (this.disconnectAudioNodes(), this.gainNode = this.chaimu.audioContext.createGain(), this) : this;
  }
  disconnectAudioNodes() {
    this.mediaElementSource && (this.mediaElementSource.disconnect(), this.mediaElementSource = void 0), this.gainNode && (this.gainNode.disconnect(), this.gainNode = void 0);
  }
  async init() {
    if (this.isInitializing)
      throw new Error("Initialization already in progress");
    this.isInitializing = !0;
    try {
      return await this.fetchAudio(), this.initAudioBooster(), this.createAudioElement(), this;
    } finally {
      this.isInitializing = !1;
    }
  }
  createAudioElement() {
    if (!this.chaimu.audioContext)
      throw new Error("No audio context available");
    if (!this.blobUrl)
      throw new Error("No blob URL available.");
    const e = new Audio(this.blobUrl);
    e.crossOrigin = "anonymous", "preservesPitch" in e && (e.preservesPitch = !0, "mozPreservesPitch" in e && (e.mozPreservesPitch = !0), "webkitPreservesPitch" in e && (e.webkitPreservesPitch = !0)), this.audioElement = e, this.mediaElementSource = this.chaimu.audioContext.createMediaElementSource(e), this.mediaElementSource.connect(this.gainNode), this.gainNode.connect(this.chaimu.audioContext.destination);
  }
  lipSync(e = !1) {
    if (lt.log("[ChaimuPlayer] lipsync video", this.chaimu.video, this), !this.chaimu.video)
      return this;
    if (!e)
      return lt.log("[ChaimuPlayer] lipsync mode isn't set"), this;
    switch (lt.log(`[ChaimuPlayer] lipsync mode is ${e}`), e) {
      case "play":
      case "playing":
      case "ratechange":
      case "seeked":
        return this.chaimu.video.paused || this.start(), this;
      case "pause":
      case "waiting":
        return this.pause(), this;
      default:
        return this;
    }
  }
  async reopenCtx() {
    if (!this.chaimu.audioContext)
      throw new Error("No audio context available");
    try {
      this.chaimu.audioContext.state !== "closed" && await this.chaimu.audioContext.close();
    } catch (e) {
      lt.log("[ChaimuPlayer] Failed to close audio context:", e);
    }
    return this.chaimu.audioContext = no(), this;
  }
  async clear() {
    if (this.isClearing && this.clearingPromise)
      return this.clearingPromise;
    if (!this.chaimu.audioContext)
      throw new Error("No audio context available");
    return lt.log("clear audio context"), this.isClearing = !0, this.clearingPromise = (async () => {
      try {
        await this.pause(), this.audioElement && (this.audioElement.pause(), this.audioElement = void 0), this.blobUrl && (URL.revokeObjectURL(this.blobUrl), this.blobUrl = void 0), this.disconnectAudioNodes();
        const e = this.gainNode ? this.gainNode.gain.value : 1;
        return await this.reopenCtx(), this.chaimu.audioContext && (this.initAudioBooster(), this.volume = e), this;
      } finally {
        this.isClearing = !1, this.clearingPromise = void 0;
      }
    })(), this.clearingPromise;
  }
  async start() {
    if (!this.chaimu.audioContext)
      throw new Error("No audio context available");
    if (!this.audioElement)
      throw new Error("Audio element is missing");
    return this.isClearing && this.clearingPromise && (lt.log("The other cleaner is still running, waiting..."), await this.clearingPromise), lt.log("starting audio via HTMLAudioElement"), await this.play(), this.chaimu.video && (this.audioElement.currentTime = this.chaimu.video.currentTime, this.audioElement.playbackRate = this.chaimu.video.playbackRate), this.audioElement.play().catch((e) => lt.log("[ChaimuPlayer] Play audioElement failed:", e)), this;
  }
  async pause() {
    if (!this.chaimu.audioContext)
      throw new Error("No audio context available");
    return this.audioElement && this.audioElement.pause(), this.chaimu.audioContext.state === "running" && await this.chaimu.audioContext.suspend(), this;
  }
  async play() {
    if (!this.chaimu.audioContext)
      throw new Error("No audio context available");
    return await this.chaimu.audioContext.resume(), this;
  }
  set src(e) {
    this._src = e;
  }
  get src() {
    return this._src;
  }
  get currentSrc() {
    return this._src;
  }
  set volume(e) {
    this.gainNode && (this.gainNode.gain.value = e);
  }
  get volume() {
    return this.gainNode ? this.gainNode.gain.value : 0;
  }
  set playbackRate(e) {
    this.audioElement && (this.audioElement.playbackRate = e);
  }
  get playbackRate() {
    return this.audioElement ? this.audioElement.playbackRate : this.chaimu.video?.playbackRate ?? 1;
  }
  get currentTime() {
    return this.chaimu.video?.currentTime ?? 0;
  }
}
u(Xl, "name", "ChaimuPlayer");
const eh = "__VOT_MAIN_BOOT_STATE__";
function nh(n) {
  return n === "idle" || n === "booting" || n === "booted" || n === "failed";
}
function ih(n) {
  return !n || typeof n != "object" ? !1 : nh(n.status);
}
function sh(n = eh) {
  const t = globalThis, e = t[n];
  if (ih(e))
    return e;
  const i = {
    status: "idle",
    promise: null,
    error: null
  };
  return t[n] = i, i;
}
function oh(n) {
  return n instanceof HTMLVideoElement ? n : null;
}
function mr(n, t) {
  for (const e of t)
    try {
      const i = oh(n.querySelector(e));
      if (i)
        return i;
    } catch {
    }
  return null;
}
function pr(n, t) {
  if (typeof n.querySelector != "function")
    return !1;
  try {
    return !!n.querySelector(t);
  } catch {
    return !1;
  }
}
function yr(n, t) {
  if (n.nodeType !== Node.ELEMENT_NODE && n.nodeType !== Node.DOCUMENT_FRAGMENT_NODE && n.nodeType !== Node.DOCUMENT_NODE)
    return !1;
  const e = n;
  for (const i of t) {
    if (n instanceof Element)
      try {
        if (n.matches(i))
          return !0;
      } catch {
      }
    if (pr(e, i) || n instanceof Element && n.shadowRoot && pr(n.shadowRoot, i))
      return !0;
  }
  return !1;
}
function rh(n) {
  let t = !0, e = null, i = null, s = null, o = null;
  const r = n.selectors?.filter((w) => String(w || "").trim()) ?? [], a = r.length > 0 ? r : ["video"], l = n.strategy ?? "mutation", c = Math.max(25, Math.trunc(n.pollIntervalMs ?? 75)), d = Math.max(
    250,
    Math.trunc(n.pollTimeoutMs ?? 4e3)
  ), h = Date.now() + d, f = /^(m|music)\.youtube\.com$/i.test(
    String(globalThis.location.hostname || "")
  ), g = () => {
    t && (f && console.log(
      "[VOT][mobile-overlay][probe] cleanup lightweight video probe",
      {
        strategy: l
      }
    ), t = !1, i?.disconnect(), i = null, e = null, o !== null && (clearTimeout(o), o = null), s && (document.removeEventListener("readystatechange", s), s = null));
  }, m = (w, A) => {
    t && (f && console.log(
      "[VOT][mobile-overlay][probe] activate lightweight video probe",
      {
        reason: w,
        hasVideo: !!A,
        src: A?.currentSrc || A?.src || ""
      }
    ), g(), n.onVideoDetected(w, A));
  }, v = () => {
    const w = mr(document, a);
    return w ? (m("probe-existing-video", w), !0) : yr(document, a) ? (m("probe-existing-video"), !0) : !1;
  }, S = () => {
    t && (v() || Date.now() >= h || (o = globalThis.setTimeout(S, c)));
  }, T = () => {
    if (!t || i)
      return;
    i = new MutationObserver((A) => {
      for (const P of A)
        if (P.type === "childList")
          for (const _ of P.addedNodes) {
            if (_ instanceof HTMLVideoElement) {
              m("probe-video-added", _);
              return;
            }
            if (_ instanceof Document || _ instanceof DocumentFragment || _ instanceof Element) {
              const O = mr(_, a);
              if (O) {
                m("probe-video-added", O);
                return;
              }
            }
            if (yr(_, a)) {
              m("probe-video-added");
              return;
            }
          }
    });
    const w = document.documentElement;
    if (!w) {
      s = () => {
        if (!t || e)
          return;
        const A = document.documentElement;
        if (A) {
          if (s && document.removeEventListener("readystatechange", s), s = null, e = A, l === "mutation") {
            i?.observe(A, { childList: !0, subtree: !0 }), v();
            return;
          }
          S();
        }
      }, document.addEventListener("readystatechange", s);
      return;
    }
    if (e = w, l === "mutation") {
      i.observe(w, { childList: !0, subtree: !0 });
      return;
    }
    S();
  };
  return v() || T(), g;
}
const ah = "api.browser.yandex.ru", lh = "media-proxy.toil.cc/v1/proxy/m3u8", Sn = "vot-worker.kload.workers.dev", uh = "https://vot.toil.cc/v1", ch = "https://translate-backend.transly.workers.dev/v2", dh = "https://rust-server-531j.onrender.com/detect", Jl = "b4dd2893e5ec40bf835cc0615b2992e3", On = "https://oauth.yandex.ru", so = "/verification_code", Zl = `${On}${so}`, br = "https://avatars.mds.yandex.net/get-yapic", Ql = "Acobat12/voice-over-translation-direct", vr = `https://raw.githubusercontent.com/${Ql}`, hh = `https://github.com/${Ql}`, Mi = 15, tu = 900, fh = 5, Oi = "yandexbrowser", oo = "yandexbrowser", eu = ["UA", "LV", "LT"], ro = 1e3, Tn = "2025-05-09", gh = [
  "autoTranslate",
  "autoSubtitles",
  "dontTranslateLanguages",
  "enabledDontTranslateLanguages",
  "enabledAutoVolume",
  "enabledSmartDucking",
  "autoVolume",
  "buttonPos",
  "showVideoSlider",
  "syncVolume",
  "downloadWithName",
  "sendNotifyOnComplete",
  "subtitlesMaxLength",
  "subtitlesSmartLayout",
  "highlightWords",
  "subtitlesFontSize",
  "subtitlesFontFamily",
  "subtitlesOpacity",
  "subtitlesDownloadFormat",
  "responseLanguage",
  "defaultVolume",
  "onlyBypassMediaCSP",
  "newAudioPlayer",
  "showPiPButton",
  "translateAPIErrors",
  "translationService",
  "detectService",
  "translationHotkey",
  "subtitlesHotkey",
  "m3u8ProxyHost",
  "proxyWorkerHost",
  "translateProxyEnabled",
  "translateProxyEnabledDefault",
  "audioBooster",
  "useLivelyVoice",
  "autoHideButtonDelay",
  "useAudioDownload",
  "compatVersion",
  "localePhrases",
  "localeLang",
  "localeHash",
  "localeVersion",
  "localeUpdatedAt",
  "localeLangOverride",
  "account"
], ao = () => {
}, mh = ao, ph = ao, yh = ao, C = { log: mh, warn: ph, error: yh };
function bh() {
  return navigator.language?.substring(0, 2).toLowerCase() || "en";
}
const vh = /* @__PURE__ */ new Set([
  "uk",
  "be",
  "bg",
  "mk",
  "sr",
  "bs",
  "hr",
  "sl",
  "pl",
  "sk",
  "cs"
]);
function wh(n) {
  return Pi.includes(n) ? n : vh.has(n) ? "ru" : "en";
}
const lo = bh(), ii = wh(lo), wr = 3e4, Sh = /[\\/:*?"'<>|]+/g, Th = /^https?:\/\//i, kh = /-{2,}/g, Lh = /^[.\s-]+|[.\s-]+$/g;
function Sr() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
function Ah(n) {
  let t = "";
  for (let e = 0; e < n.length; e++) {
    const i = n.codePointAt(e) ?? 0;
    i >= 32 && i !== 127 && (t += n[e]);
  }
  return t;
}
function xh(n) {
  const t = /* @__PURE__ */ new WeakSet();
  return JSON.stringify(n, (e, i) => {
    if (i && typeof i == "object") {
      if (t.has(i))
        return "[Circular]";
      if (t.add(i), Array.isArray(i))
        return i;
      const s = {}, o = Object.keys(i).sort(
        (r, a) => r.localeCompare(a)
      );
      for (const r of o)
        s[r] = i[r];
      return s;
    }
    return i;
  });
}
function Ss(n) {
  let t = 2166136261, e = 0;
  for (; e < n.length; ) {
    const i = n.codePointAt(e) ?? 0;
    t ^= i, t = Math.imul(t, 16777619), e += i > 65535 ? 2 : 1;
  }
  return (t >>> 0).toString(36);
}
const nu = () => !!document.pictureInPictureEnabled;
async function Vh(n, t) {
  try {
    const e = await n.createWritable();
    return await e.write(t), await e.close(), !0;
  } catch {
    return !1;
  }
}
async function Ch(n, t) {
  const e = typeof navigator > "u" ? void 0 : navigator;
  if (!e?.share || typeof File > "u")
    return "unsupported";
  let i;
  try {
    i = new File([n], t, {
      type: n.type || "application/octet-stream"
    });
  } catch {
    return "unsupported";
  }
  if (typeof e.canShare == "function" && !e.canShare({ files: [i] }))
    return "unsupported";
  try {
    return await e.share({ files: [i], title: t }), "shared";
  } catch (s) {
    return s instanceof DOMException && s.name === "AbortError" ? "shared" : "error";
  }
}
function Eh(n, t) {
  const e = URL.createObjectURL(n), i = document.createElement("a");
  i.href = e, i.download = t, i.rel = "noopener noreferrer", i.target = "_blank", i.style.position = "fixed", i.style.left = "-9999px", i.style.top = "0", (document.body ?? document.documentElement).append(i);
  try {
    return i.click(), !0;
  } catch {
    return !1;
  } finally {
    i.remove(), Ih(e);
  }
}
async function iu(n, t, e = {}) {
  return e.fileHandle && await Vh(e.fileHandle, n) || e.preferShare && await Ch(n, t) === "shared" ? !0 : Eh(n, t);
}
function Ih(n, t = wr) {
  const e = Number.isFinite(t) && t >= 0 ? t : wr;
  globalThis.setTimeout(() => URL.revokeObjectURL(n), e);
}
function Tr(n) {
  const t = n.trim();
  return t && Ah(t).replace(Th, "").replaceAll(Sh, "-").replaceAll(kh, "-").replaceAll(Lh, "") || Sr();
}
const kr = () => Math.floor(Date.now() / 1e3), Ph = (n) => n ? Object.fromEntries(new Headers(n).entries()) : {};
function K(n, t = 0, e = 100) {
  const i = Math.min(t, e), s = Math.max(t, e);
  return Math.min(Math.max(n, i), s);
}
function su(n) {
  const t = {}, e = Object.entries(n);
  for (; e.length; ) {
    const i = e.pop();
    if (!i) continue;
    const [s, o] = i;
    if (o === void 0) continue;
    if (!(o !== null && typeof o == "object" && !Array.isArray(o))) {
      t[s] = o;
      continue;
    }
    for (const [a, l] of Object.entries(o))
      e.push([`${s}.${a}`, l]);
  }
  return t;
}
const ou = 7200 * 1e3, Lr = "x-vot-cache-created-at", Xe = "x-vot-cache-key", Mh = "vot-http-cache-v1", Oh = 500, Dh = "VOTSession", Xi = {
  translation: "translationExpiresAt",
  subtitles: "subtitlesExpiresAt"
};
function _h() {
  return Math.floor(Date.now() / 1e3);
}
function Rh(n) {
  if (!n || typeof n != "object")
    return !1;
  const t = n;
  return typeof t.expires == "number" && Number.isFinite(t.expires) && typeof t.timestamp == "number" && Number.isFinite(t.timestamp) && typeof t.uuid == "string" && t.uuid.length > 0 && typeof t.secretKey == "string" && t.secretKey.length > 0;
}
function Bh(n) {
  if (!n || typeof n != "object")
    return {};
  const t = _h(), e = Object.entries(n).flatMap(
    ([i, s]) => Rh(s) ? s.timestamp + s.expires <= t ? [] : [[i, s]] : []
  );
  return Object.fromEntries(e);
}
function Fh(n) {
  if (!n || typeof n != "object")
    return !1;
  const t = n;
  return typeof t.expiresAt == "number" && Number.isFinite(t.expiresAt) && typeof t.secretKey == "string" && t.secretKey.length > 0 && typeof t.uuid == "string" && t.uuid.length > 0;
}
class Nh {
  constructor(t = I) {
    this.storage = t;
  }
  getStorageKey(t) {
    return Dh;
  }
  async restore(t, e = {}) {
    const i = this.getStorageKey(t), s = await this.storage.getRaw(i);
    if (!Fh(s))
      return e;
    const o = Date.now();
    if (s.expiresAt <= o)
      return await this.storage.deleteRaw(i), e;
    const r = Math.max(
      1,
      Math.ceil((s.expiresAt - o) / 1e3)
    );
    return {
      ...e,
      "video-translation": {
        secretKey: s.secretKey,
        uuid: s.uuid,
        expires: r,
        timestamp: Math.floor(o / 1e3)
      }
    };
  }
  async persist(t, e) {
    const i = this.getStorageKey(t), s = Bh(e)["video-translation"];
    if (!s) {
      await this.storage.deleteRaw(i);
      return;
    }
    await this.storage.setRaw(i, {
      secretKey: s.secretKey,
      uuid: s.uuid,
      expiresAt: (s.timestamp + s.expires) * 1e3
    });
  }
}
class Uh {
  constructor() {
    u(this, "cache", /* @__PURE__ */ new Map());
  }
  /**
   * Clears all cached entries.
   *
   * Used when runtime settings change (e.g. proxy mode/host), because cached
   * translation URLs and especially previous failures can become stale.
   */
  clear() {
    this.cache.clear();
  }
  getTranslation(t) {
    return this.getValue(t, "translation");
  }
  setTranslation(t, e) {
    this.setValue(t, "translation", e);
  }
  getSubtitles(t) {
    return this.getValue(t, "subtitles");
  }
  setSubtitles(t, e) {
    this.setValue(t, "subtitles", e);
  }
  deleteSubtitles(t) {
    this.deleteValue(t, "subtitles");
  }
  getValue(t, e) {
    const i = Date.now(), s = this.cache.get(t);
    if (!s) return;
    const o = Xi[e], r = s[o];
    if (r !== void 0 && r <= i) {
      s[e] = void 0, s[o] = void 0, this.evictIfEmpty(t, s);
      return;
    }
    return s[e];
  }
  setValue(t, e, i) {
    const s = Date.now(), o = this.getOrCreateEntry(t), r = s + ou, a = Xi[e];
    o[e] = i, o[a] = r;
  }
  deleteValue(t, e) {
    const i = this.cache.get(t);
    if (!i) return;
    const s = Xi[e];
    i[e] = void 0, i[s] = void 0, this.evictIfEmpty(t, i);
  }
  evictIfEmpty(t, e) {
    e.translation === void 0 && e.subtitles === void 0 && this.cache.delete(t);
  }
  getOrCreateEntry(t) {
    const e = this.cache.get(t);
    if (e) return e;
    const i = {};
    return this.cache.set(t, i), i;
  }
}
class $h {
  constructor() {
    u(this, "memoryCache", /* @__PURE__ */ new Map());
    u(this, "inFlightRequests", /* @__PURE__ */ new Map());
  }
  async execute(t, e, i) {
    if (!e || e.ttlMs <= 0)
      return i();
    const s = e.key ?? this.buildDefaultCacheKey(t);
    if (!s)
      return i();
    const o = this.normalizeMethod(t.method), r = e.ttlMs, a = e.cacheName || Mh, l = e.useMemory !== !1, c = e.useCacheApi !== !1 && o === "GET" && this.supportsCacheApi(), d = c ? Ss(s) : "", h = e.dedupe !== !1, f = e.allowStaleOnError !== !1, g = Date.now();
    let m;
    if (l) {
      const w = this.readMemoryCache(s, g);
      if (w.fresh)
        return w.fresh;
      m = w.stale ?? m;
    }
    if (c) {
      const w = await this.readCacheApi(
        a,
        t.url,
        d,
        r,
        g,
        f
      );
      if (w.fresh)
        return l && this.writeMemoryCache(
          s,
          w.fresh.clone(),
          w.expiresAt ?? g + r
        ), w.fresh;
      m = m ?? w.stale;
    }
    const v = async () => {
      const w = await i();
      if (!w.ok)
        return w;
      const A = Date.now(), P = this.computeExpiresAt(A, r);
      if (l && this.writeMemoryCache(s, w.clone(), P), c) {
        const _ = this.toStorableResponse(w.clone(), A);
        await this.writeCacheApi(a, t.url, d, _);
      }
      return w;
    };
    if (!h)
      try {
        return await v();
      } catch (w) {
        if (f && m)
          return m;
        throw w;
      }
    const S = this.inFlightRequests.get(s);
    if (S !== void 0)
      return (await S).clone();
    const T = (async () => {
      try {
        return await v();
      } catch (w) {
        if (f && m)
          return m.clone();
        throw w;
      }
    })();
    this.inFlightRequests.set(s, T);
    try {
      return (await T).clone();
    } finally {
      this.inFlightRequests.delete(s);
    }
  }
  computeExpiresAt(t, e) {
    if (!Number.isFinite(e) || e <= 0)
      return t;
    const i = Number.MAX_SAFE_INTEGER - t;
    return e >= i ? Number.MAX_SAFE_INTEGER : t + e;
  }
  normalizeMethod(t) {
    return (t || "GET").toUpperCase();
  }
  resolveBodyKey(t) {
    if (t == null) return "";
    if (typeof t == "string") return t;
    if (t instanceof URLSearchParams) return t.toString();
  }
  buildDefaultCacheKey(t) {
    const e = this.normalizeMethod(t.method);
    if (e === "GET" || e === "HEAD")
      return `${e}:${t.url}`;
    const i = this.resolveBodyKey(t.body);
    if (i !== void 0)
      return `${e}:${t.url}#${Ss(i)}`;
  }
  supportsCacheApi() {
    return typeof caches < "u" && typeof caches.open == "function";
  }
  readCreatedAtMs(t) {
    const e = t.headers.get(Lr);
    if (!e) return null;
    const i = Number(e);
    return Number.isFinite(i) ? i : null;
  }
  ensureVaryByCacheKey(t) {
    const e = t.get("vary");
    if (!e) {
      t.set("vary", Xe);
      return;
    }
    const i = new Set(
      e.split(",").map((s) => s.trim().toLowerCase())
    );
    !i.has("*") && !i.has(Xe) && t.set("vary", `${e}, ${Xe}`);
  }
  toStorableResponse(t, e) {
    const i = new Headers(t.headers);
    return i.set(Lr, String(e)), this.ensureVaryByCacheKey(i), new Response(t.body, {
      status: t.status,
      statusText: t.statusText,
      headers: i
    });
  }
  readMemoryCache(t, e) {
    const i = this.memoryCache.get(t);
    return i ? i.expiresAt > e ? (this.touchMemoryCache(t, i), {
      fresh: i.response.clone(),
      expiresAt: i.expiresAt
    }) : (this.memoryCache.delete(t), {
      stale: i.response.clone(),
      expiresAt: i.expiresAt
    }) : {};
  }
  touchMemoryCache(t, e) {
    this.memoryCache.delete(t), this.memoryCache.set(t, e);
  }
  trimMemoryCache() {
    for (; this.memoryCache.size > Oh; ) {
      const t = this.memoryCache.keys().next().value;
      if (typeof t != "string") break;
      this.memoryCache.delete(t);
    }
  }
  writeMemoryCache(t, e, i) {
    this.memoryCache.has(t) && this.memoryCache.delete(t), this.memoryCache.set(t, {
      response: e,
      expiresAt: i
    }), this.trimMemoryCache();
  }
  async readCacheApi(t, e, i, s, o, r) {
    try {
      const a = new Request(e, {
        method: "GET",
        headers: {
          [Xe]: i
        }
      }), l = await caches.open(t), c = await l.match(a);
      if (!c) return {};
      const d = this.readCreatedAtMs(c);
      if (d === null)
        return await l.delete(a), {};
      const h = this.computeExpiresAt(d, s);
      if (h > o)
        return {
          fresh: c.clone(),
          expiresAt: h
        };
      if (!r)
        return await l.delete(a), {};
      const f = c.clone();
      return await l.delete(a), {
        stale: f,
        expiresAt: h
      };
    } catch {
      return {};
    }
  }
  async writeCacheApi(t, e, i, s) {
    try {
      const o = new Request(e, {
        method: "GET",
        headers: {
          [Xe]: i
        }
      });
      await (await caches.open(t)).put(o, s);
    } catch {
    }
  }
}
const Hh = new $h();
async function Wh(n, t, e) {
  return Hh.execute(n, t, e);
}
function zh(n) {
  const t = /* @__PURE__ */ new WeakSet();
  try {
    return JSON.stringify(n, (i, s) => typeof s != "object" || s === null ? s : t.has(s) ? "[Circular]" : (t.add(s), s)) ?? null;
  } catch {
    return null;
  }
}
function ru(n, t = "Unknown error") {
  if (n instanceof Error)
    return n.message || t;
  if (typeof n == "string")
    return n || t;
  if (n == null)
    return t;
  if (typeof n == "object") {
    const e = n;
    if (typeof e?.data?.message == "string" && e.data.message)
      return e.data.message;
    if (typeof e?.error?.message == "string" && e.error.message)
      return e.error.message;
    if (typeof e?.message == "string" && e.message)
      return e.message;
    const i = zh(n);
    if (i && i !== "{}")
      return i;
    const s = n.constructor?.name;
    return s ? `[${s}]` : t;
  }
  return typeof n == "number" || typeof n == "boolean" || typeof n == "bigint" ? `${n}` : typeof n == "symbol" ? n.description ? `Symbol(${n.description})` : "Symbol" : typeof n == "function" ? n.name ? `[Function ${n.name}]` : "[Function]" : t;
}
function ce(n) {
  return ru(n, "");
}
function kn(n) {
  const t = n;
  return typeof DOMException < "u" && t instanceof DOMException && t.name === "AbortError" || t instanceof Error && t.name === "AbortError" || t?.message === "AbortError";
}
function ye(n = "Aborted") {
  try {
    return new DOMException(n, "AbortError");
  } catch {
    const t = new Error(n);
    return t.name = "AbortError", t;
  }
}
const Ts = new AbortController().signal;
function Ji(n) {
  const t = n.throwIfAborted;
  if (typeof t == "function")
    try {
      t.call(n);
      return;
    } catch (e) {
      throw n.aborted || kn(e) ? ye() : e instanceof Error ? e : new Error(String(e));
    }
  if (n.aborted)
    throw ye();
}
function qh(n, t) {
  if (!(Number.isFinite(n) && n > 0))
    return {
      signal: t ?? Ts,
      cleanup: () => {
      }
    };
  const i = new AbortController();
  let s;
  const o = () => {
    s !== void 0 && (clearTimeout(s), s = void 0), i.abort(t?.reason);
  };
  return t && (t.addEventListener("abort", o, { once: !0 }), t.aborted && o()), i.signal.aborted || (s = setTimeout(() => {
    i.abort(ye("Timeout")), s = void 0;
  }, n)), {
    signal: i.signal,
    cleanup: () => {
      s !== void 0 && (clearTimeout(s), s = void 0), t?.removeEventListener("abort", o);
    }
  };
}
const Ar = "api.browser.yandex.ru", xr = "googlevideo.com", Vr = "toil.cc", Cr = "workers.dev", Er = "onrender.com", Ir = "cloudflare-dns.com", Gh = /^([\w-]+):\s*(.+)$/, Kh = /^[a-zA-Z][a-zA-Z\d+.-]*:/;
typeof GM_info > "u" || GM_info?.scriptHandler;
const au = (
  // The extension build provides a full GM_xmlhttpRequest implementation, so
  // we should not fall into the "proxy-only" compatibility mode.
  !1
), Je = typeof GM < "u", Ln = typeof GM_xmlhttpRequest < "u";
function Yh(n) {
  const t = n.trim();
  try {
    return new URL(t).hostname.toLowerCase();
  } catch {
    if (!Kh.test(t))
      try {
        return new URL(`https://${t}`).hostname.toLowerCase();
      } catch {
      }
    return;
  }
}
function jh(n) {
  if (n != null)
    return typeof n == "string" ? n : n instanceof URLSearchParams ? n.toString() : (n instanceof FormData || n instanceof Blob || n instanceof ArrayBuffer, n);
}
function ke(n, t) {
  return n === t || n.endsWith(`.${t}`);
}
function Xh(n, t, e = !1) {
  if (e)
    return !0;
  if (!n) {
    const i = t.toLowerCase();
    return i.includes(Ar) || i.includes(xr) || i.includes(Vr) || i.includes(Cr) || i.includes(Er) || i.includes(Ir);
  }
  return ke(n, Ar) || ke(n, xr) || ke(n, Vr) || ke(n, Cr) || ke(n, Er) || ke(n, Ir);
}
function Jh(n) {
  return typeof n == "string" ? n : n instanceof URL ? n.href : n.url;
}
function Zh(n, t) {
  return t ? t.toUpperCase() : n instanceof Request ? (n.method || "GET").toUpperCase() : "GET";
}
function Qh(n) {
  return typeof n != "string" || n.length === 0 ? {} : n.split(/\r?\n/).reduce((t, e) => {
    const i = Gh.exec(e);
    if (!i)
      return t;
    const [, s, o] = i;
    return t[s] = o, t;
  }, {});
}
function tf(n) {
  const t = n;
  return typeof t?.error == "string" ? t.error : typeof t?.statusText == "string" ? t.statusText : ce(n) || "Unknown error";
}
async function Pr(n, t, e) {
  const i = Ph(e.headers);
  return await new Promise((s, o) => {
    const r = typeof GM_xmlhttpRequest > "u" ? globalThis.GM_xmlhttpRequest : GM_xmlhttpRequest;
    if (typeof r != "function") {
      o(new TypeError("GM_xmlhttpRequest is not available"));
      return;
    }
    let a = !1, l;
    const c = () => {
      l && e.signal?.removeEventListener("abort", l);
    }, d = (f) => {
      a || (a = !0, c(), o(f));
    }, h = r({
      method: e.method || "GET",
      url: n,
      responseType: "blob",
      data: jh(e.body),
      timeout: t,
      headers: i,
      onload: (f) => {
        if (a) return;
        a = !0, c();
        const g = Qh(f.responseHeaders), m = new Response(f.response, {
          status: f.status,
          statusText: typeof f.statusText == "string" ? f.statusText : "",
          headers: g
        });
        Object.defineProperty(m, "url", {
          value: f.finalUrl ?? n
        }), s(m);
      },
      ontimeout: () => d(new Error("Timeout")),
      onerror: (f) => d(new Error(tf(f))),
      onabort: () => d(ye())
    });
    if (l = () => {
      try {
        h?.abort?.();
      } catch {
      }
      d(ye());
    }, e.signal && (e.signal.addEventListener("abort", l, { once: !0 }), e.signal.aborted)) {
      l();
      return;
    }
  });
}
async function ut(n, t = {}) {
  const {
    timeout: e = 15e3,
    forceGmXhr: i = !1,
    responseCache: s,
    ...o
  } = t, r = Jh(n), a = Yh(r), l = Zh(n, o.method), c = async () => {
    if (Xh(a, r, i))
      return await Pr(r, e, o);
    const { signal: d, cleanup: h } = qh(
      e,
      o.signal
    );
    try {
      return await fetch(n, {
        ...o,
        signal: d
      });
    } catch (f) {
      if (d.aborted || kn(f))
        throw f;
      return C.log(
        "GM_fetch preventing CORS by GM_xmlhttpRequest",
        ce(f) || "Unknown error"
      ), await Pr(r, e, o);
    } finally {
      h();
    }
  };
  return s ? await Wh(
    {
      url: r,
      method: l,
      body: o.body
    },
    s,
    c
  ) : await c();
}
const ef = {
  numToBool: [
    ["autoTranslate"],
    ["dontTranslateYourLang", "enabledDontTranslateLanguages"],
    ["autoSetVolumeYandexStyle", "enabledAutoVolume"],
    ["showVideoSlider"],
    ["syncVolume"],
    ["downloadWithName"],
    ["sendNotifyOnComplete"],
    ["highlightWords"],
    ["onlyBypassMediaCSP"],
    ["newAudioPlayer"],
    ["showPiPButton"],
    ["translateAPIErrors"],
    ["audioBooster"],
    ["useNewModel", "useLivelyVoice"]
  ],
  number: [["autoVolume"]],
  array: [["dontTranslateLanguage", "dontTranslateLanguages"]],
  string: [
    ["hotkeyButton", "translationHotkey"],
    ["locale-lang-override", "localeLangOverride"],
    ["locale-lang", "localeLang"]
  ]
}, lu = Object.entries(ef).flatMap(
  ([n, t]) => t.map(([e, i]) => ({
    category: n,
    oldKey: e,
    newKey: i ?? e,
    shouldDeleteOldKey: !!i
  }))
), nf = new Map(
  lu.map((n) => [n.oldKey, n])
), sf = Array.from(
  new Set(lu.map((n) => n.oldKey))
);
function of(n) {
  const t = {};
  for (const e of n)
    t[e] = void 0;
  return t;
}
function rf(n, t) {
  switch (n) {
    case "numToBool":
    case "number":
      return typeof t == "number";
    case "array":
      return Array.isArray(t);
    case "string":
      return typeof t == "string" || t === null;
    default:
      return !1;
  }
}
function af(n, t) {
  switch (n) {
    case "string":
    case "array":
    case "number":
      return t;
    default:
      return !!t;
  }
}
function lf(n, t) {
  let e = af(n.category, t);
  return n.oldKey === "autoVolume" && typeof t == "number" && t < 1 && (e = Math.round(t * 100)), e;
}
function uf(n, t) {
  return Array.isArray(n) && Array.isArray(t) ? n.length === t.length && n.every((e, i) => Object.is(e, t[i])) : Object.is(n, t);
}
async function cf(n) {
  if (n.compatVersion === Tn)
    return n;
  const t = /* @__PURE__ */ new Set([
    ...Object.keys(n),
    ...sf
  ]), e = await I.getValues(of(t)), i = { ...n }, s = [], o = [];
  for (const [r, a] of Object.entries(e)) {
    if (a === void 0)
      continue;
    const l = nf.get(r);
    if (!l || !rf(l.category, a))
      continue;
    const c = lf(l, a);
    i[l.newKey] = c;
    const d = e[l.newKey];
    (l.shouldDeleteOldKey || !uf(d, c)) && s.push(I.set(l.newKey, c)), l.shouldDeleteOldKey && o.push(I.delete(l.oldKey));
  }
  return await Promise.all([...s, ...o]), {
    ...i,
    compatVersion: Tn
  };
}
class Mr {
  constructor() {
    u(this, "support", null);
  }
  resolveSupport() {
    if (this.support)
      return this.support;
    const t = {
      legacyGet: typeof GM_getValue == "function",
      legacySet: typeof GM_setValue == "function",
      legacyDelete: typeof GM_deleteValue == "function",
      legacyList: typeof GM_listValues == "function",
      promiseGet: Je && typeof GM?.getValue == "function",
      promiseGetValues: Je && typeof GM?.getValues == "function",
      promiseSet: Je && typeof GM?.setValue == "function",
      promiseDelete: Je && typeof GM?.deleteValue == "function",
      promiseList: Je && typeof GM?.listValues == "function"
    };
    return this.support = t, C.log(
      `[VOT Storage] GM Promises: ${t.promiseGet} | GM legacy: ${t.legacyGet}`
    ), t;
  }
  /**
   * Check if storage type is LocalStorage
   */
  get isSupportOnlyLS() {
    const t = this.resolveSupport();
    return !t.legacyGet && !t.legacySet && !t.legacyDelete && !t.legacyList && !t.promiseGet && !t.promiseGetValues && !t.promiseSet && !t.promiseDelete && !t.promiseList;
  }
  syncGetByName(t, e, i) {
    if (i.legacyGet)
      return GM_getValue(t, e);
    const s = globalThis.localStorage.getItem(t);
    if (s === null)
      return e;
    try {
      return JSON.parse(s);
    } catch {
      return e;
    }
  }
  async getRaw(t, e) {
    const i = this.resolveSupport();
    return i.promiseGet && GM.getValue ? await GM.getValue(t, e) : this.syncGetByName(t, e, i);
  }
  async get(t, e) {
    return this.getRaw(t, e);
  }
  async getValues(t) {
    const e = this.resolveSupport();
    if (e.promiseGetValues && GM.getValues)
      return await GM.getValues(t);
    const i = Object.entries(t);
    if (e.promiseGet && GM.getValue) {
      const s = await Promise.all(
        i.map(async ([o, r]) => {
          const a = await GM.getValue(o, r);
          return [o, a];
        })
      );
      return Object.fromEntries(s);
    }
    return Object.fromEntries(
      i.map(([s, o]) => [
        s,
        this.syncGetByName(s, o, e)
      ])
    );
  }
  syncSetByName(t, e, i) {
    return i.legacySet ? GM_setValue(t, e) : globalThis.localStorage.setItem(t, JSON.stringify(e));
  }
  async setRaw(t, e) {
    const i = this.resolveSupport();
    return i.promiseSet && GM.setValue ? await GM.setValue(t, e) : this.syncSetByName(t, e, i);
  }
  async set(t, e) {
    return this.setRaw(t, e);
  }
  syncDeleteByName(t, e) {
    return e.legacyDelete ? GM_deleteValue(t) : globalThis.localStorage.removeItem(t);
  }
  async deleteRaw(t) {
    const e = this.resolveSupport();
    return e.promiseDelete && GM.deleteValue ? await GM.deleteValue(t) : this.syncDeleteByName(t, e);
  }
  async delete(t) {
    return this.deleteRaw(t);
  }
  syncList(t) {
    return t.legacyList ? GM_listValues() : gh;
  }
  async list() {
    const t = this.resolveSupport();
    return t.promiseList && GM.listValues ? await GM.listValues() : this.syncList(t);
  }
}
const Or = "__VOT_STORAGE_SINGLETON__", I = (() => {
  const n = globalThis, t = n[Or];
  if (t instanceof Mr)
    return t;
  const e = new Mr();
  return n[Or] = e, e;
})();
function df() {
  const n = globalThis._userData;
  if (!n || typeof n != "object") return null;
  const t = n;
  return typeof t.avatar_id != "string" || typeof t.username != "string" || !t.avatar_id || !t.username ? null : {
    avatar_id: t.avatar_id,
    username: t.username
  };
}
function hf(n) {
  let t = "";
  for (const e of n) t += String.fromCharCode(e);
  return btoa(t).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
async function ff(n) {
  const t = new TextEncoder().encode(n), e = await crypto.subtle.digest("SHA-256", t);
  return hf(new Uint8Array(e));
}
function Dr(n = 64) {
  const t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~", e = new Uint8Array(n);
  crypto.getRandomValues(e);
  let i = "";
  for (let s = 0; s < n; s += 1)
    i += t[e[s] % t.length];
  return i;
}
async function gf() {
  const n = Dr(32), t = Dr(64), e = await ff(t);
  return sessionStorage.setItem("vot-yandex-oauth-state", n), sessionStorage.setItem("vot-yandex-oauth-code-verifier", t), `https://oauth.yandex.ru/authorize?${new URLSearchParams({
    response_type: "code",
    client_id: Jl,
    redirect_uri: Zl,
    state: n,
    code_challenge: e,
    code_challenge_method: "S256"
  }).toString()}`;
}
function mf(n, t) {
  return new Promise((e, i) => {
    GM_xmlhttpRequest({
      method: "POST",
      url: n,
      headers: {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
      },
      data: t,
      onload: (s) => {
        e({
          status: s.status,
          responseText: s.responseText || ""
        });
      },
      onerror: (s) => {
        console.error("[VOT] GM OAuth request failed:", s), i(new Error("[VOT] GM OAuth request network error"));
      },
      ontimeout: () => {
        i(new Error("[VOT] GM OAuth request timeout"));
      }
    });
  });
}
async function pf(n) {
  const t = sessionStorage.getItem("vot-yandex-oauth-code-verifier");
  if (!t)
    throw new Error("[VOT] Missing PKCE code_verifier in opener");
  const e = new URLSearchParams({
    grant_type: "authorization_code",
    code: n,
    client_id: Jl,
    code_verifier: t,
    redirect_uri: Zl
  }).toString(), i = await mf("https://oauth.yandex.ru/token", e), s = i.responseText || "";
  let o = {};
  try {
    o = s ? JSON.parse(s) : {};
  } catch {
    o = {};
  }
  if (i.status < 200 || i.status >= 300 || o?.error) {
    const r = o?.error ?? `http_${i.status}`, a = o?.error_description ? ` (${o.error_description})` : "";
    throw new Error(
      `[VOT] Failed to exchange verification code: ${r}${a}. Response: ${s}`
    );
  }
  if (!o?.access_token)
    throw new Error(
      `[VOT] access_token was not returned by Yandex. Response: ${s}`
    );
  if (typeof o.expires_in != "number")
    throw new Error(
      `[VOT] expires_in was not returned or invalid. Response: ${s}`
    );
  return {
    access_token: o.access_token,
    expires_in: o.expires_in,
    refresh_token: o.refresh_token
  };
}
async function yf(n) {
  await I.set("account", {
    token: n.access_token,
    expires: Date.now() + n.expires_in * 1e3,
    username: void 0,
    avatarId: void 0
  }), sessionStorage.removeItem("vot-yandex-oauth-state"), sessionStorage.removeItem("vot-yandex-oauth-code-verifier");
}
async function Zi(n) {
  globalThis.opener && !globalThis.opener.closed && globalThis.opener.postMessage(n, "*");
}
async function bf() {
  const n = new URLSearchParams(globalThis.location.search), t = n.get("code"), e = n.get("state") ?? void 0, i = n.get("error"), s = n.get("error_description") ?? void 0;
  if (i) {
    await Zi({
      source: "vot-auth",
      type: "error",
      error: i,
      error_description: s,
      state: e
    }), globalThis.close();
    return;
  }
  if (!t) {
    await Zi({
      source: "vot-auth",
      type: "error",
      error: "missing_code",
      state: e
    }), globalThis.close();
    return;
  }
  await Zi({
    source: "vot-auth",
    type: "code",
    code: t,
    state: e
  }), globalThis.close();
}
async function vf() {
  const n = df();
  if (!n)
    throw new Error("[VOT] Invalid user data");
  const t = await I.get("account");
  if (!t)
    throw new Error("[VOT] No account data found");
  await I.set("account", {
    ...t,
    username: n.username,
    avatarId: n.avatar_id
  });
}
async function wf() {
  if (globalThis.location.origin === On && globalThis.location.pathname === so)
    return bf();
  if (globalThis.location.pathname === "/my/profile")
    return vf();
}
function Sf() {
  return /(?:^|\.)vkvideo\.ru$|(?:^|\.)vk\.(?:com|ru)$/i.test(
    String(globalThis.location?.hostname || "")
  );
}
let _r = !1;
function uu() {
  const n = [document], t = /* @__PURE__ */ new Set([document]), e = [document];
  for (; e.length > 0; ) {
    const i = e.shift();
    if (!i)
      continue;
    const s = i instanceof Document || i instanceof ShadowRoot ? i.querySelectorAll("*") : [];
    for (const o of s) {
      const r = o.shadowRoot;
      !r || t.has(r) || (t.add(r), n.push(r), e.push(r));
    }
  }
  return n;
}
function Qi(n) {
  const t = [], e = /* @__PURE__ */ new Set();
  for (const i of uu())
    for (const s of Array.from(i.querySelectorAll(n)))
      e.has(s) || (e.add(s), t.push(s));
  return t;
}
function Rr() {
  const n = Qi(
    "vot-block.vot-segmented-button, .vot-segmented-button"
  );
  for (const s of n)
    s.hidden = !1, s.removeAttribute("hidden"), s.removeAttribute("inert"), s.classList.remove("vot-segmented-button--hidden"), s.style.setProperty("display", "flex", "important"), s.style.setProperty("opacity", "1", "important"), s.style.setProperty("pointer-events", "auto", "important"), s.style.setProperty("z-index", "2147483647", "important"), s.style.setProperty("visibility", "visible", "important");
  const t = Qi(
    ".vot-subtitles-widget, .vot-subtitles-layer"
  );
  for (const s of t)
    s.hidden = !1, s.removeAttribute("hidden"), s.style.setProperty("display", "block", "important"), s.style.setProperty("opacity", "1", "important"), s.style.setProperty("pointer-events", "none", "important"), s.style.setProperty("z-index", "2147483647", "important"), s.style.setProperty("visibility", "visible", "important");
  const e = Qi("video"), i = {
    buttons: n.length,
    subtitlesWidgets: t.length,
    videos: e.length,
    visibleVideos: e.filter((s) => {
      const o = s.getBoundingClientRect();
      return o.width > 64 && o.height > 64;
    }).length,
    href: globalThis.location.href
  };
  return globalThis.__VOT_VK_PROBE__ = i, n.length + t.length;
}
function Br() {
  for (const n of uu()) {
    const t = n instanceof Document ? n.head || n.documentElement : n instanceof ShadowRoot ? n : null;
    if (!t)
      continue;
    const e = n instanceof Document || n instanceof ShadowRoot ? n : null;
    if (e && !e.querySelector("#vot-vk-overlay-fix-style"))
      try {
        const i = document.createElement("style");
        i.id = "vot-vk-overlay-fix-style", i.textContent = `
        .vot-segmented-button {
          display: flex !important;
          opacity: 1 !important;
          pointer-events: auto !important;
          z-index: 2147483647 !important;
          visibility: visible !important;
        }

        .vot-segmented-button.vot-segmented-button--hidden {
          opacity: 1 !important;
          pointer-events: auto !important;
        }

        .vot-subtitles-layer,
        .vot-subtitles-widget {
          display: block !important;
          opacity: 1 !important;
          z-index: 2147483647 !important;
          visibility: visible !important;
        }
      `, t.appendChild(i);
      } catch {
      }
  }
}
function Tf() {
  if (Sf() && (Br(), !_r)) {
    _r = !0;
    try {
      const n = (r) => {
        console.log(
          r,
          globalThis.__VOT_VK_PROBE__
        );
      };
      let t = "";
      const e = Rr();
      console.log(
        e > 0 ? "[VOT][VK probe] overlay nodes detected" : "[VOT][VK probe] no VOT overlay nodes yet",
        globalThis.__VOT_VK_PROBE__
      );
      const i = () => {
        Br();
        const r = Rr(), a = globalThis.__VOT_VK_PROBE__, l = JSON.stringify(a);
        r > 0 && l !== t && (t = l, n("[VOT][VK probe] standard overlay refresh"));
      };
      let s = 0;
      const o = globalThis.setInterval(() => {
        s += 1, i(), s >= 160 && globalThis.clearInterval(o);
      }, 500);
      document.addEventListener(
        "visibilitychange",
        () => {
          document.hidden || i();
        },
        { passive: !0 }
      );
    } catch (n) {
      console.warn("[VOT][VK probe] failed", n);
    }
  }
}
function kf() {
  let n = null, t = null;
  const e = 3e3, i = () => {
    t !== null && (window.clearTimeout(t), t = null);
  }, s = () => {
    const a = document.querySelector(
      ".vot-segmented-button"
    );
    a && (a.hidden = !1, a.removeAttribute("hidden"), a.style.opacity = "1", a.classList.remove("vot-segmented-button--hidden"), i(), t = window.setTimeout(() => {
      const l = document.querySelector(
        ".vot-segmented-button"
      );
      l && (l.style.opacity = "0", l.classList.add("vot-segmented-button--hidden"));
    }, e));
  }, o = () => {
    const a = document.querySelector("video");
    if (!a) return;
    const l = a.closest('[class*="player"], [class*="video"], main, article') || a.parentElement || a;
    if (!l || l === n) return;
    n = l;
    const c = () => s();
    l.addEventListener("mouseenter", c, { passive: !0 }), l.addEventListener("mousemove", c, { passive: !0 }), l.addEventListener("pointerenter", c, { passive: !0 }), l.addEventListener("pointermove", c, { passive: !0 }), s();
  };
  o(), new MutationObserver(() => {
    o();
  }).observe(document.documentElement, {
    childList: !0,
    subtree: !0
  });
}
const Lf = "recommended", Af = "Translate video", xf = "Turn off", Vf = "Translation settings", Cf = "Subtitles settings", Ef = "Smart subtitle layout", If = "Reset settings", Pf = "The video is being translated", Mf = "Video language", Of = "Translation language", Df = "The translation will take", _f = "The translation will take more than an hour", Rf = "The translation will take about a minute", Bf = "The translation will take a few minutes", Ff = "The translation will take approximately {0} minutes", Nf = "The translation will take approximately {0} minutes", Uf = "Failed to request video translation", $f = "Audio link not received", Hf = "Failed to download audio", Wf = "The audio format is not supported", zf = "Start the video to translate", qf = "No audio detected", Gf = "Audio is not available yet", Kf = "Translate on open", Yf = "Subtitles on open", jf = "Don't translate from my language", Xf = "Video volume:", Jf = "Translation volume:", Zf = "Reduce video volume to", Qf = "Video volume slider", tg = "Link translation and video volume", eg = "You have disabled the translation of the video in your language", ng = "Video is too long", ig = "No video ID found", sg = "Subtitles", og = "Disabled", rg = "Subtitles max length", ag = "Highlight words", lg = "translated from", ug = "autogenerated", cg = "VOT Settings", dg = "Menu language", hg = "Authors", fg = "Version", gg = "Loader", mg = "Browser", pg = "Show PiP button", yg = { auto: "Auto", af: "Afrikaans", ak: "Akan", sq: "Albanian", am: "Amharic", ar: "Arabic", hy: "Armenian", as: "Assamese", ay: "Aymara", az: "Azerbaijani", bn: "Bangla", eu: "Basque", be: "Belarusian", bho: "Bhojpuri", bs: "Bosnian", bg: "Bulgarian", my: "Burmese", ca: "Catalan", ceb: "Cebuano", zh: "Chinese", "zh-Hans": "Chinese (Simplified)", "zh-Hant": "Chinese (Traditional)", co: "Corsican", hr: "Croatian", cs: "Czech", da: "Danish", dv: "Divehi", nl: "Dutch", en: "English", eo: "Esperanto", et: "Estonian", ee: "Ewe", fil: "Filipino", fi: "Finnish", fr: "French", gl: "Galician", lg: "Ganda", ka: "Georgian", de: "German", el: "Greek", gn: "Guarani", gu: "Gujarati", ht: "Haitian Creole", ha: "Hausa", haw: "Hawaiian", iw: "Hebrew", hi: "Hindi", hmn: "Hmong", hu: "Hungarian", is: "Icelandic", ig: "Igbo", id: "Indonesian", ga: "Irish", it: "Italian", ja: "Japanese", jv: "Javanese", kn: "Kannada", kk: "Kazakh", km: "Khmer", rw: "Kinyarwanda", ko: "Korean", kri: "Krio", ku: "Kurdish", ky: "Kyrgyz", lo: "Lao", la: "Latin", lv: "Latvian", ln: "Lingala", lt: "Lithuanian", lb: "Luxembourgish", mk: "Macedonian", mg: "Malagasy", ms: "Malay", ml: "Malayalam", mt: "Maltese", mi: "Māori", mr: "Marathi", mn: "Mongolian", ne: "Nepali", nso: "Northern Sotho", no: "Norwegian", ny: "Nyanja", or: "Odia", om: "Oromo", ps: "Pashto", fa: "Persian", pl: "Polish", pt: "Portuguese", pa: "Punjabi", qu: "Quechua", ro: "Romanian", ru: "Russian", sm: "Samoan", sa: "Sanskrit", gd: "Scottish Gaelic", sr: "Serbian", sn: "Shona", sd: "Sindhi", si: "Sinhala", sk: "Slovak", sl: "Slovenian", so: "Somali", st: "Southern Sotho", es: "Spanish", su: "Sundanese", sw: "Swahili", sv: "Swedish", tg: "Tajik", ta: "Tamil", tt: "Tatar", te: "Telugu", th: "Thai", ti: "Tigrinya", ts: "Tsonga", tr: "Turkish", tk: "Turkmen", uk: "Ukrainian", ur: "Urdu", ug: "Uyghur", uz: "Uzbek", vi: "Vietnamese", cy: "Welsh", fy: "Western Frisian", xh: "Xhosa", yi: "Yiddish", yo: "Yoruba", zu: "Zulu" }, bg = "There is no connection to the server", vg = "Search...", wg = "Translate errors from the API", Sg = "Language detection service", Tg = "Enter the proxy worker address", kg = "Enter the address of the m3u8 proxy worker", Lg = "Proxy Settings", Ag = "The translation will take approximately {0} minutes", xg = "Extended translation volume increase", Vg = "Subtitles design", Cg = "Subtitle font", Eg = "Font size of subtitles", Ig = "Transparency of the subtitle background", Pg = "The format for downloading subtitles", Mg = "Download files with the video name", Og = "Update localization files", Dg = "Locale hash", _g = "Updated at", Rg = "To enable this, you must have a Web Audio API", Bg = "Media CSP is enabled on this site", Fg = "Use it only for bypassing Media CSP", Ng = "Use the new audio player", Ug = "Use an experimental variation of Yandex voices for some videos", $g = "The translation is slightly delayed", Hg = "The translation on the {0} has been completed!", Wg = "Send a notification that the video has been translated", zg = "Report a bug", qg = "Disabled", Gg = "Enabled", Kg = "Proxy everything", Yg = "Proxying mode", jg = "Translated by {0}", Xg = "Translate stream isn't available", Jg = "Text translation service", Zg = "Doesn't affect the translation of text in voice over", Qg = "Don't translate from selected languages", tm = "Display the video volume slider", em = "Hotkeys settings", nm = "None", im = "Use lively voices. Speakers sound like native Russians.", sm = "Misc settings", om = { yandexbrowser: "Yandex Browser", msedge: "Microsoft Edge", "rust-server": "Rust Server" }, rm = "About extension", am = "Appearance", lm = "Button position in the player", um = { left: "Left", right: "Right", top: "Top", default: "Default" }, cm = "secs", dm = "Delay before hiding the translate button", hm = "not found", fm = "The button position only changes in players larger than 600 pixels.", gm = "Completely disabling proxying in your country may break the extension", mm = "Press the key combination...", pm = "Use audio download", ym = "Disabling audio downloads may affect the functionality of the extension", bm = "You need to log in to use this feature", vm = "My account", wm = "Login", Sm = "Logout", Tm = "Refresh", km = "Enter the Yandex OAuth Token", Lm = "You can manually set the account token in this field. Please note that we don't check its validity before sending a translate request", Am = "Login via token", xm = "Adaptive volume", Vm = {
  recommended: Lf,
  translateVideo: Af,
  disableTranslate: xf,
  translationSettings: Vf,
  subtitlesSettings: Cf,
  subtitlesSmartLayout: Ef,
  resetSettings: If,
  videoBeingTranslated: Pf,
  videoLanguage: Mf,
  translationLanguage: Of,
  translationTake: Df,
  translationTakeMoreThanHour: _f,
  translationTakeAboutMinute: Rf,
  translationTakeFewMinutes: Bf,
  translationTakeApproximatelyMinutes: Ff,
  translationTakeApproximatelyMinute: Nf,
  requestTranslationFailed: Uf,
  audioNotReceived: $f,
  VOTFailedDownloadAudio: Hf,
  audioFormatNotSupported: Wf,
  VOTStartVideoForTranslation: zf,
  VOTAudioNotDetected: qf,
  VOTAudioNotYetAvailable: Gf,
  VOTAutoTranslate: Kf,
  VOTAutoSubtitles: Yf,
  VOTDontTranslateYourLang: jf,
  VOTVolume: Xf,
  VOTVolumeTranslation: Jf,
  VOTAutoSetVolume: Zf,
  VOTShowVideoSlider: Qf,
  VOTSyncVolume: tg,
  VOTDisableFromYourLang: eg,
  VOTVideoIsTooLong: ng,
  VOTNoVideoIDFound: ig,
  VOTSubtitles: sg,
  VOTSubtitlesDisabled: og,
  VOTSubtitlesMaxLength: rg,
  VOTHighlightWords: ag,
  VOTTranslatedFrom: lg,
  VOTAutogenerated: ug,
  VOTSettings: cg,
  VOTMenuLanguage: dg,
  VOTAuthors: hg,
  VOTVersion: fg,
  VOTLoader: gg,
  VOTBrowser: mg,
  VOTShowPiPButton: pg,
  langs: yg,
  streamNoConnectionToServer: bg,
  searchField: vg,
  VOTTranslateAPIErrors: wg,
  VOTDetectService: Sg,
  VOTProxyWorkerHost: Tg,
  VOTM3u8ProxyHost: kg,
  proxySettings: Lg,
  translationTakeApproximatelyMinute2: Ag,
  VOTAudioBooster: xg,
  VOTSubtitlesDesign: Vg,
  VOTSubtitlesFont: Cg,
  VOTSubtitlesFontSize: Eg,
  VOTSubtitlesOpacity: Ig,
  VOTSubtitlesDownloadFormat: Pg,
  VOTDownloadWithName: Mg,
  VOTUpdateLocaleFiles: Og,
  VOTLocaleHash: Dg,
  VOTUpdatedAt: _g,
  VOTNeedWebAudioAPI: Rg,
  VOTMediaCSPEnabledOnSite: Bg,
  VOTOnlyBypassMediaCSP: Fg,
  VOTNewAudioPlayer: Ng,
  VOTUseNewModel: Ug,
  TranslationDelayed: $g,
  VOTTranslationCompletedNotify: Hg,
  VOTSendNotifyOnComplete: Wg,
  VOTBugReport: zg,
  VOTTranslateProxyDisabled: qg,
  VOTTranslateProxyEnabled: Gg,
  VOTTranslateProxyEverything: Kg,
  VOTTranslateProxyStatus: Yg,
  VOTTranslatedBy: jg,
  VOTStreamNotAvailable: Xg,
  VOTTranslationTextService: Jg,
  VOTNotAffectToVoice: Zg,
  DontTranslateSelectedLanguages: Qg,
  showVideoVolumeSlider: tm,
  hotkeysSettings: em,
  None: nm,
  VOTUseLivelyVoice: im,
  miscSettings: sm,
  services: om,
  aboutExtension: rm,
  appearance: am,
  buttonPosition: lm,
  position: um,
  secs: cm,
  autoHideButtonDelay: dm,
  notFound: hm,
  minButtonPositionContainer: fm,
  VOTTranslateProxyStatusDefault: gm,
  PressTheKeyCombination: mm,
  VOTUseAudioDownload: pm,
  VOTUseAudioDownloadWarning: ym,
  VOTAccountRequired: bm,
  VOTMyAccount: vm,
  VOTLogin: wm,
  VOTLogout: Sm,
  VOTRefresh: Tm,
  VOTYandexToken: km,
  VOTYandexTokenInfo: Lm,
  VOTLoginViaToken: Am,
  smartDucking: xm
};
var ts = ["auto", "en", "ru", "af", "am", "ar", "az", "bg", "bn", "bs", "ca", "cs", "cy", "da", "de", "el", "es", "et", "eu", "fa", "fi", "fr", "gl", "hi", "hr", "hu", "hy", "id", "it", "ja", "jv", "kk", "km", "kn", "ko", "lo", "mk", "ml", "mn", "ms", "mt", "my", "ne", "nl", "pa", "pl", "pt", "ro", "si", "sk", "sl", "sq", "sr", "su", "sv", "sw", "tr", "uk", "ur", "uz", "vi", "zh", "zu"];
const Cm = [
  "localePhrases",
  "localeLang",
  "localeHash",
  "localeVersion",
  "localeUpdatedAt",
  "localeLangOverride"
], Em = su(Vm), Fr = "master", Im = (() => {
  const n = typeof ts < "u" && Array.isArray(ts) ? ts : ["en"];
  return n.includes("auto") ? n : ["auto", ...n];
})();
function Pm(n, t) {
  return n || t || "unknown";
}
function Mm() {
  const n = "1.11.5.24", t = typeof GM_info < "u" ? String(GM_info?.script?.version || "") : "";
  return Pm(n, t);
}
class Om {
  constructor() {
    /**
     * Language used before page was reloaded
     */
    u(this, "lang");
    /**
     * Locale phrases with current language
     */
    u(this, "locale");
    u(this, "defaultLocale", Em);
    u(this, "localesUrl", `${vr}/${Fr}/src/localization/locales`);
    u(this, "hashesUrl", `${vr}/${Fr}/src/localization/hashes.json`);
    u(this, "warnedMissingKeys", /* @__PURE__ */ new Set());
    u(this, "_langOverride", "auto");
    this.lang = this.getLang(), this.locale = {};
  }
  async init() {
    const [t, e] = await Promise.all([
      I.get("localeLangOverride", "auto"),
      I.get("localePhrases", "")
    ]);
    return this._langOverride = t, this.lang = this.getLang(), this.setLocaleFromJsonString(e), this;
  }
  get langOverride() {
    return this._langOverride;
  }
  getLang() {
    return this.langOverride !== "auto" ? this.langOverride : lo;
  }
  getAvailableLangs() {
    return [...Im];
  }
  async reset() {
    return await Promise.all(Cm.map((t) => I.delete(t))), this;
  }
  buildUrl(t, e = "", i = !1) {
    const s = i ? `?timestamp=${kr()}` : "";
    return `${t}${e}${s}`;
  }
  async changeLang(t) {
    return this.langOverride === t ? !1 : (await I.set("localeLangOverride", t), this._langOverride = t, this.lang = this.getLang(), await this.update(!0), !0);
  }
  async checkUpdates(t = !1) {
    try {
      const e = await ut(this.buildUrl(this.hashesUrl, "", t), {
        forceGmXhr: !0
      });
      if (!e.ok) throw e.status;
      const i = await e.json();
      if (!i || typeof i != "object")
        throw new Error("Invalid locale hashes payload");
      const s = i[this.lang];
      return typeof s != "string" || !s || await I.get("localeHash", "") === s ? !1 : s;
    } catch (e) {
      return console.error(
        "[VOT] [localizationProvider] Failed to get locales hash:",
        e
      ), null;
    }
  }
  async update(t = !1) {
    const e = Mm(), i = await I.get(
      "localeVersion",
      ""
    );
    if (!t && i === e)
      return this;
    const s = await this.checkUpdates(t);
    if (s === null)
      return this;
    if (!s)
      return this;
    const o = kr();
    try {
      const r = await ut(
        this.buildUrl(this.localesUrl, `/${this.lang}.json`, t),
        { forceGmXhr: !0 }
      );
      if (!r.ok) throw r.status;
      const a = await r.text();
      this.setLocaleFromJsonString(a), await Promise.all([
        I.set("localePhrases", a),
        I.set("localeHash", s),
        I.set("localeLang", this.lang),
        I.set("localeVersion", e),
        I.set("localeUpdatedAt", o)
      ]);
    } catch (r) {
      console.error("[VOT] [localizationProvider] Failed to get locale:", r), this.setLocaleFromJsonString(await I.get("localePhrases", ""));
    }
    return this;
  }
  setLocaleFromJsonString(t) {
    const e = t.trim();
    if (!e)
      return this.locale = {}, this.warnedMissingKeys.clear(), this;
    try {
      const i = JSON.parse(e);
      if (!i || typeof i != "object" || Array.isArray(i))
        throw new Error("Locale payload should be a JSON object");
      this.locale = su(i);
    } catch (i) {
      console.error("[VOT] [localizationProvider]", i), this.locale = {};
    }
    return this.warnedMissingKeys.clear(), this;
  }
  getFromLocale(t, e, i = "locale") {
    return t[e] ?? this.warnMissingKey(t, e, i);
  }
  warnMissingKey(t, e, i) {
    const s = `${i}:${e}`;
    this.warnedMissingKeys.has(s) || (this.warnedMissingKeys.add(s), console.warn(
      "[VOT] [localizationProvider] locale",
      t,
      "doesn't contain key",
      e
    ));
  }
  getDefault(t) {
    return this.getFromLocale(this.defaultLocale, t, "default") ?? t;
  }
  get(t) {
    return this.getFromLocale(this.locale, t) ?? this.getDefault(t);
  }
  getLangLabel(t) {
    const e = `langs.${t}`;
    if (e in this.defaultLocale) {
      const i = this.get(e);
      if (i)
        return i;
    }
    return t.toUpperCase();
  }
}
const p = new Om();
let Nr = null;
function Dm() {
  return Nr ?? (Nr = p.init()), Nr;
}
const hi = () => globalThis.self !== globalThis.top;
function _m() {
  const t = Object.entries({
    "https://dev.epicgames.com": {
      targetOrigin: "https://dev.epicgames.com",
      dataFilter: (e) => typeof e == "string" && e.startsWith("getVideoId:"),
      extractVideoId: (e) => e.pathname.split("/").at(-2) ?? null,
      responseFormatter: (e, i) => `${typeof i == "string" ? i : ""}:${e}`
    },
    "https://www.dailymotion.com": {
      targetOrigin: "https://geo.dailymotion.com",
      dataFilter: (e) => typeof e == "string" && e.startsWith("getVideoId:"),
      extractVideoId: (e) => /(?:^|\/)video\/([^/]+)/.exec(e.pathname)?.[1],
      responseFormatter: (e) => `getVideoId:${e}`
    }
  }).find(
    ([e]) => globalThis.location.origin === e
  )?.[1];
  t && globalThis.addEventListener("message", (e) => {
    try {
      if (e.origin !== t.targetOrigin || !t.dataFilter(e.data)) return;
      const i = t.extractVideoId(
        new URL(globalThis.location.href)
      );
      if (!i) return;
      const s = t.responseFormatter(i, e.data);
      e.source && "postMessage" in e.source && e.source.postMessage(
        s,
        t.targetOrigin
      );
    } catch (i) {
      console.error("Iframe communication error:", i);
    }
  });
}
let es = !1, Ze = null, Ur = !1;
function Rm() {
  return globalThis.location.origin === On && globalThis.location.pathname === so;
}
async function $r(n, t) {
  if (!es) {
    if (Ze !== null) {
      await Ze;
      return;
    }
    Ze = (async () => {
      if (t("Activating runtime", { reason: n }), Rm()) {
        await wf(), es = !0;
        return;
      }
      hi() || (await Dm(), await p.update(), C.log(`Selected menu language: ${p.lang}`)), Ur || (Ur = !0, _m());
      function e() {
        const i = globalThis.location.hostname.toLowerCase();
        return i === "disk.yandex.ru" || i === "disk.yandex.com";
      }
      e() && kf(), Tf(), es = !0;
    })();
    try {
      await Ze;
    } finally {
      Ze = null;
    }
  }
}
const Hr = /* @__PURE__ */ new WeakSet(), Wr = /* @__PURE__ */ new WeakMap(), zr = 2200;
function qr() {
  return /(?:^|\.)vkvideo\.ru$|(?:^|\.)vk\.(?:com|ru)$/i.test(
    String(globalThis.location.hostname || "")
  );
}
function Bm() {
  return /^(m|music)\.youtube\.com$/i.test(
    String(globalThis.location.hostname || "")
  );
}
function zt(n, t) {
  Bm() && console.log(`[VOT][mobile-overlay][observer] ${n}`, t ?? {});
}
function Fm(n) {
  return String(n.host || "") === "youtube" && (n.additionalData === "mobile" || n.additionalData === "music");
}
function Gr() {
  return `${globalThis.location.origin}${globalThis.location.pathname}${globalThis.location.search}`;
}
function fi(n) {
  if (!n.isConnected)
    return !1;
  const t = n.getBoundingClientRect();
  if (t.width < 64 || t.height < 64)
    return !1;
  const e = globalThis.getComputedStyle(n);
  return !(e.display === "none" || e.visibility === "hidden" || Number(e.opacity || "1") === 0);
}
function ks(n) {
  const t = n.getBoundingClientRect();
  return Math.max(0, t.width) * Math.max(0, t.height);
}
function gi(n) {
  if (n.currentSrc || n.src || n.srcObject)
    return !0;
  const t = n.querySelector("source");
  return !!(t?.getAttribute("src") || t?.src);
}
function Nm(n) {
  const t = Array.from(n.querySelectorAll("track")).map((i, s) => {
    const o = String(
      i.src || i.getAttribute("src") || ""
    ).trim();
    if (!o)
      return null;
    let r = o;
    try {
      r = new URL(o, document.baseURI).href;
    } catch {
    }
    return {
      index: s,
      kind: String(i.kind || i.getAttribute("kind") || "").trim(),
      srclang: String(
        i.srclang || i.track?.language || i.getAttribute("srclang") || ""
      ).trim(),
      label: String(i.label || i.getAttribute("label") || "").trim(),
      url: r
    };
  }).filter((i) => !!i), e = t.map(
    (i) => [i.index, i.kind, i.srclang, i.label, i.url].join(
      "|"
    )
  ).join("||");
  if (Wr.get(n) !== e) {
    if (Wr.set(n, e), globalThis.__VOT_DETECTED_NATIVE_SUBTITLE_TRACKS__ = t, !t.length) {
      console.log(
        "[VOT][subtitles][native] no <track> subtitle URLs detected for video"
      );
      return;
    }
    console.log(
      `[VOT][subtitles][native] detected ${t.length} <track> subtitle URL(s). Inspect window.__VOT_DETECTED_NATIVE_SUBTITLE_TRACKS__.`
    ), console.table(t);
  }
}
function Um(n, t) {
  if (!n.isConnected)
    return !0;
  const e = ks(n), i = ks(t), s = fi(n), o = fi(t), r = gi(n), a = gi(t);
  return !!(!s && o || !r && a || i > e * 1.1);
}
function $m(n) {
  const {
    videoObserver: t,
    videosWrappers: e,
    ensureRuntimeActivated: i,
    getServicesCached: s,
    findContainer: o,
    createVideoHandler: r
  } = n;
  if (Hr.has(t)) return;
  Hr.add(t);
  const a = /* @__PURE__ */ new WeakSet(), l = /* @__PURE__ */ new WeakMap(), c = /* @__PURE__ */ new WeakMap(), d = /* @__PURE__ */ new WeakMap(), h = /* @__PURE__ */ new WeakMap(), f = /* @__PURE__ */ new Map();
  let g = !1;
  const m = (k) => {
    const V = c.get(k);
    return V && l.get(V) === k && l.delete(V), c.delete(k), d.delete(k), V ?? void 0;
  }, v = (k) => {
    k && h.delete(k);
  }, S = (k) => {
    let V = null, E = -1;
    for (const F of document.querySelectorAll("video")) {
      if (!(F instanceof HTMLVideoElement) || !F.isConnected || !o(k, F))
        continue;
      let H = ks(F);
      gi(F) && (H += 1e7), fi(F) && (H += 1e6), H > E && (V = F, E = H);
    }
    return V;
  }, T = (k, V) => {
    const E = f.get(k);
    if (E)
      return clearTimeout(E.timer), f.delete(k), zt("cancel delayed cleanup", {
        reason: V,
        scheduledReason: E.reason,
        pageKey: E.pageKey
      }), E;
  }, w = async (k, V) => {
    T(k, `release:${V}`);
    const E = e.get(k);
    if (E) {
      zt("release video handler", {
        reason: V,
        videoConnected: k.isConnected,
        src: k.currentSrc || k.src || ""
      });
      try {
        await E.release();
      } catch (F) {
        console.error(`[VOT] Failed to release videoHandler (${V})`, F);
      } finally {
        e.delete(k);
      }
    }
  }, A = (k) => {
    for (const V of s()) {
      const E = o(V, k);
      if (E)
        return { site: V, container: E };
    }
    return null;
  }, P = (k) => {
    const V = String(k.host);
    return V === "peertube" || V === "directlink" ? { ...k, url: globalThis.location.origin } : k;
  }, _ = (k) => k.host === "youtube" && !k.additionalData, O = (k) => {
    g || !_(k) || (g = !0, console.log(
      "[VOT][observer] disabling video discovery after first successful YouTube attach",
      {
        host: globalThis.location.hostname,
        path: globalThis.location.pathname
      }
    ), t.disable());
  }, Q = async (k, V, E, F) => {
    T(k, `reschedule:${E}`);
    const H = Gr();
    zt("schedule delayed cleanup", {
      reason: E,
      pageKey: H,
      delayMs: zr,
      videoConnected: k.isConnected,
      hasSource: gi(k)
    });
    const G = globalThis.setTimeout(async () => {
      const nt = f.get(k);
      if (!nt || nt.timer !== G)
        return;
      if (f.delete(k), k.isConnected) {
        zt("skip delayed cleanup: video reconnected", {
          reason: E,
          pageKey: H
        });
        const xt = A(k);
        xt && (c.set(k, xt.container), l.set(xt.container, k));
        try {
          await e.get(k)?.setCanPlay();
        } catch (Se) {
          console.error(
            "[VOT] Failed to restore reconnected mobile YouTube video",
            Se
          );
        }
        return;
      }
      const j = S(V);
      if (j && j !== k) {
        zt(
          "cleanup stale handler after replacement video found",
          {
            reason: E,
            pageKey: H,
            replacementSrc: j.currentSrc || j.src || ""
          }
        ), await w(k, `${E}:replacement-video-found`), await Y(F);
        return;
      }
      const Lt = Gr();
      if (Lt === H) {
        zt("keep overlay alive on same page during repaint", {
          reason: E,
          pageKey: H,
          currentPageKey: Lt,
          mode: V.additionalData
        }), await Q(
          k,
          V,
          `${E}:same-page-retry`,
          F
        );
        return;
      }
      zt("delayed cleanup expired after page change", {
        reason: E,
        pageKey: H,
        currentPageKey: Lt
      }), await w(k, `${E}:page-changed`), await Y(F);
    }, zr);
    f.set(k, {
      pageKey: H,
      reason: E,
      site: V,
      timer: G
    });
  }, Y = async (k) => {
    if (!k)
      return;
    const V = h.get(k);
    V && (h.delete(k), !(!V.isConnected || e.has(V) || a.has(V)) && await at(V));
  }, at = async (k) => {
    const V = T(
      k,
      "video-added-again"
    );
    if (e.has(k)) {
      const E = A(k);
      if (E && (c.set(k, E.container), d.set(k, E.site), l.set(E.container, k)), V)
        try {
          await e.get(k)?.setCanPlay();
        } catch (F) {
          console.error(
            "[VOT] Failed to refresh reattached mobile YouTube handler",
            F
          );
        }
      return;
    }
    if (!a.has(k)) {
      a.add(k);
      try {
        try {
          await i("video-detected");
        } catch (j) {
          console.error("[VOT] Failed to activate runtime", j);
          return;
        }
        Nm(k);
        const E = A(k);
        if (!E) {
          if (qr()) {
            const j = k.getBoundingClientRect();
            console.warn(
              "[VOT][VK probe] video detected but no site/container match",
              {
                src: k.currentSrc || k.src || "",
                w: j.width,
                h: j.height,
                path: globalThis.location.pathname
              }
            );
          }
          return;
        }
        const { site: F, container: H } = E;
        if (console.log("[VOT][source-audio] video detected", {
          host: F.host,
          path: globalThis.location.pathname,
          currentTime: Number(k.currentTime.toFixed(3)),
          paused: k.paused,
          readyState: k.readyState,
          src: k.currentSrc || k.src || ""
        }), qr()) {
          const j = k.getBoundingClientRect();
          console.log("[VOT][VK probe] matched video", {
            site: F.host,
            selector: F.selector,
            container: H?.tagName,
            classes: H?.className,
            w: j.width,
            h: j.height,
            src: k.currentSrc || k.src || ""
          });
        }
        if ((F.host === "googledrive" || globalThis.location.hostname === "youtube.googleapis.com") && !fi(k))
          return;
        const G = l.get(H);
        if (G && G !== k)
          if (G.isConnected)
            if (Um(G, k))
              await w(
                G,
                "smaller duplicate"
              ), m(G);
            else {
              h.set(H, k);
              return;
            }
          else
            await w(G, "stale container"), m(G);
        const nt = r(
          k,
          H,
          P(F)
        );
        e.set(k, nt), c.set(k, H), d.set(k, F), l.set(H, k), nt.onPrimaryAttachReady = () => {
          e.get(k) === nt && O(F);
        };
        try {
          if (await nt.init(), e.get(k) !== nt)
            return;
          try {
            await nt.setCanPlay(), e.get(k) === nt && O(F);
          } catch (j) {
            console.error("[VOT] Failed to get video data", j);
          }
        } catch (j) {
          if (e.get(k) === nt) {
            await w(k, "init failed");
            const Lt = m(k);
            v(Lt), await Y(Lt);
          }
          console.error("[VOT] Failed to initialize videoHandler", j);
        }
      } finally {
        a.delete(k);
      }
    }
  };
  t.onVideoAdded.addListener(at), t.onVideoRemoved.addListener(async (k) => {
    const V = d.get(k), E = m(k), F = E ? h.get(E) : void 0, H = V && Fm(V) && (!F || F === k);
    zt("video removed", {
      shouldDelayCleanup: H,
      hasContainer: !!E,
      pendingReplacement: !!(F && F !== k),
      videoConnected: k.isConnected,
      src: k.currentSrc || k.src || ""
    }), H && V ? await Q(k, V, "video-removed", E) : await w(k, "video removed"), a.delete(k), E && h.get(E) === k && v(E), H || await Y(E);
  });
}
function Kr(n, t) {
  const e = String(n || "").trim();
  if (!e)
    return null;
  try {
    return new URL(e, t).toString();
  } catch {
    return e;
  }
}
function uo(n = globalThis.location.href) {
  try {
    const t = new URL(n, globalThis.location.href);
    if (!/\/player\.html$/i.test(t.pathname))
      return null;
    const e = Kr(
      t.searchParams.get("src"),
      t.toString()
    ), i = Kr(
      t.searchParams.get("list"),
      t.toString()
    );
    return !e && !i ? null : {
      kind: "playlist-player",
      playerUrl: t.toString(),
      sourceUrl: e,
      playlistUrl: i,
      hasTranslationReadyCallback: !!i
    };
  } catch {
    return null;
  }
}
function Hm(n) {
  return !!uo(n.toString());
}
const Wm = [
  ".player",
  ".video-player",
  ".video_player",
  ".video-container",
  ".video-wrapper",
  ".player-container",
  ".player-wrapper",
  ".plyr",
  ".jwplayer",
  ".shaka-video-container",
  ".dplayer",
  ".artplayer",
  ".vjs-player",
  ".video-js",
  // Bilibili players
  ".bpx-player-video-wrap",
  ".squirtle-video-wrap",
  // ReactPlayer and other wrapper patterns
  ".react-player",
  ".flowplayer",
  ".fp-player",
  "[data-player]",
  "[data-player-container]",
  "[data-video-player]",
  "[data-testid*='player']",
  "[class*='player']",
  "[class*='Player']",
  "[class*='video-player']",
  "[class*='VideoPlayer']",
  "[class*='video-container']",
  "[class*='videoContainer']",
  "[id*='player']",
  "video-player",
  "video"
], q = Wm.join(", "), Yr = ".videoplayer_media, vk-video-player", zm = 'div[data-testid="clipcontainer-video"], [data-testid="clipcontainer-video"]', qm = [
  {
    host: b.vk,
    url: "https://vk.com/video?z=",
    additionalData: "mobile",
    match: [/^m\.vk\.(com|ru)$/i, /^m\.vkvideo\.ru$/i],
    selector: Yr,
    shadowRoot: !0,
    needExtraData: !0
  },
  {
    host: b.vk,
    url: "https://vk.com/video?z=",
    additionalData: "clips",
    match: /^(www\.|m\.)?vk\.(com|ru)$/i,
    selector: zm,
    needExtraData: !0
  },
  {
    host: b.vk,
    url: "https://vk.com/video?z=",
    match: [/^(www\.|m\.)?vk\.(com|ru)$/i, /^(.*\.)?vkvideo\.ru$/i],
    selector: Yr,
    needExtraData: !0
  },
  {
    host: b.custom,
    url: "stub",
    match: (n) => Hm(n),
    selector: q,
    eventSelector: q,
    rawResult: !0
  },
  {
    host: b.custom,
    url: "stub",
    match: /(^|\.)kodikplayer\.com$/i,
    selector: q
  },
  {
    host: b.custom,
    url: "stub",
    match: /(^|\.)player\.cdnvideohub\.com$/i,
    selector: q,
    rawResult: !0
  },
  {
    host: b.custom,
    url: "stub",
    match: /(^|\.)cdnvideohub\.com$/i,
    selector: q,
    rawResult: !0
  },
  {
    host: b.custom,
    url: "stub",
    match: /(^|\.)okcdn\.ru$/i,
    selector: q,
    rawResult: !0
  },
  {
    host: b.custom,
    url: "stub",
    match: /(^|\.)dailymotion\.com$/i,
    selector: q,
    eventSelector: q,
    rawResult: !0
  },
  {
    host: b.custom,
    url: "stub",
    match: /(^|\.)geo\.dailymotion\.com$/i,
    selector: q,
    eventSelector: q,
    rawResult: !0
  },
  // Rutube: fallback selector more stable than library's nth-child pattern
  {
    host: b.rutube,
    url: "https://rutube.ru/video/",
    match: /(^|\.)rutube\.ru$/i,
    selector: ".video-player, [class*='VideoPlayer'], [class*='video-player'], #app > div > div",
    rawResult: !0
  },
  // Bunny CDN embedded players
  {
    host: b.custom,
    url: "stub",
    match: /(^|\.)iframe\.mediadelivery\.net$/i,
    selector: q,
    eventSelector: q,
    rawResult: !0
  },
  {
    host: b.custom,
    url: "stub",
    match: /(^|\.)video\.bunnycdn\.com$/i,
    selector: q,
    eventSelector: q,
    rawResult: !0
  },
  // Russian streaming platforms
  {
    host: b.custom,
    url: "stub",
    match: /(^|\.)ivi\.ru$/i,
    selector: ".iv-player-container, .player-container, .vjs-v7, " + q,
    rawResult: !0
  },
  {
    host: b.custom,
    url: "stub",
    match: /(^|\.)kinopoisk\.ru$/i,
    selector: ".ott-player, [class*='player'], .yp-player, " + q,
    rawResult: !0
  },
  {
    host: b.custom,
    url: "stub",
    match: [/(^|\.)okko\.tv$/i, /(^|\.)okko\.ru$/i],
    selector: q,
    rawResult: !0
  },
  {
    host: b.custom,
    url: "stub",
    match: [/(^|\.)kion\.ru$/i],
    selector: q,
    rawResult: !0
  },
  // Kodik player subdomains (kodik.info/biz/cc already matched by library,
  // but kodik.fun, kodik.pw and others may appear)
  {
    host: b.custom,
    url: "stub",
    match: /(^|\.)kodik\.(fun|pw|io|online|me)$/i,
    selector: ".fp-player, " + q,
    rawResult: !0
  },
  // Wink (Rostelecom streaming)
  {
    host: b.custom,
    url: "stub",
    match: /(^|\.)wink\.ru$/i,
    selector: q,
    rawResult: !0
  },
  // Seasonvar and similar Russian series sites that embed video
  {
    host: b.custom,
    url: "stub",
    match: /(^|\.)seasonvar\.ru$/i,
    selector: q,
    rawResult: !0
  },
  // solodcdn (already in @match but not in extraSites)
  {
    host: b.custom,
    url: "stub",
    match: /(^|\.)solodcdn\.com$/i,
    selector: q,
    rawResult: !0
  },
  // wikianimex.ru — embeds player.cdnvideohub.com; this entry covers the case
  // where the player is rendered on the main page rather than in a cross-origin iframe
  {
    host: b.custom,
    url: "stub",
    match: [/^wikianimex\.ru$/i, /(?:^|\.)wikianimex\.ru$/i],
    selector: q,
    eventSelector: q,
    rawResult: !0
  },
  // m.ok.ru — mobile OK.ru; vot.js only matches ok.ru exactly
  {
    host: b.okru,
    url: "https://ok.ru/video/",
    match: /^m\.ok\.ru$/i,
    selector: "vk-video-player",
    shadowRoot: !0
  },
  // m.youtube.com — mobile YouTube; vot.js has a .player-container selector
  // that may not exist on some page variants; extend it with fallback selectors
  {
    host: b.youtube,
    url: "https://youtu.be/",
    match: /^m\.youtube\.com$/i,
    selector: ".player-container, #movie_player, ytm-player, #player, video",
    needExtraData: !0,
    additionalData: "mobile"
  },
  // music.youtube.com uses the same video IDs, but the player shell differs
  // enough that it should not fall back to the desktop-only YouTube helper.
  {
    host: b.youtube,
    url: "https://youtu.be/",
    match: /^music\.youtube\.com$/i,
    selector: "ytmusic-player-page, ytmusic-player, ytm-player, #player, .player-container, video",
    needExtraData: !0,
    additionalData: "music"
  }
], Gm = /* @__PURE__ */ new Set(["youtube"]), Km = /* @__PURE__ */ new Set(["youtube"]), Ym = /* @__PURE__ */ new Set(["youtube"]), jm = /* @__PURE__ */ new Set([
  "vk",
  "googledrive",
  "yandexdisk",
  "rutube",
  "okru",
  "bilibili",
  "dzen"
]), Xm = [
  /(?:^|\.)vkvideo\.ru$/i,
  /(?:^|\.)vk\.(?:com|ru)$/i,
  /^youtube\.googleapis\.com$/i,
  /^disk\.yandex\./i,
  /(?:^|\.)rutube\.ru$/i,
  /(?:^|\.)ok\.ru$/i,
  /(?:^|\.)bilibili\.(com|tv)$/i,
  /(?:^|\.)dzen\.ru$/i,
  /^player\.cdnvideohub\.com$/i,
  /(?:^|\.)wikianimex\.ru$/i,
  /(?:^|\.)kodikplayer\.com$/i,
  /(?:^|\.)kodik\.(info|biz|cc|fun|pw|io|online|me)$/i
], Jm = /* @__PURE__ */ new Set([
  "vk",
  "googledrive",
  "yandexdisk",
  "rutube",
  "okru",
  "bilibili",
  "twitter",
  "tiktok",
  "dzen",
  "kick",
  "twitch"
]), Zm = [
  /(?:^|\.)vkvideo\.ru$/i,
  /(?:^|\.)vk\.(?:com|ru)$/i,
  /^youtube\.googleapis\.com$/i,
  /^disk\.yandex\./i,
  /(?:^|\.)rutube\.ru$/i,
  /(?:^|\.)ok\.ru$/i,
  /(?:^|\.)bilibili\.(com|tv)$/i,
  /(?:^|\.)twitter\.com$/i,
  /(?:^|\.)x\.com$/i,
  /(?:^|\.)tiktok\.com$/i,
  /(?:^|\.)dzen\.ru$/i,
  /(?:^|\.)kick\.com$/i,
  /(?:^|\.)twitch\.tv$/i,
  /(?:^|\.)wikianimex\.ru$/i
];
function Qm(n) {
  return String(n.host || "").trim() === "youtube" && (n.additionalData === "mobile" || n.additionalData === "music");
}
function tp(n) {
  return n === "m.youtube.com" || n === "music.youtube.com";
}
function ep(n) {
  const t = /* @__PURE__ */ new Set();
  for (const e of n) {
    if (e.shadowRoot !== !0)
      continue;
    const i = typeof e.selector == "string" ? e.selector.trim() : "";
    i && t.add(i);
  }
  return Array.from(t);
}
function np(n, t) {
  return new Set(t.map((i) => String(i.host || "").trim())).has("youtube") || /(?:^|\.)youtube(?:-nocookie|kids)?\.com$/i.test(n) ? [
    "video.html5-main-video, .html5-video-container video, ytmusic-player video, ytm-player video, #player video, .player-container video, video"
  ] : ["video"];
}
function ip(n) {
  const t = String(n.hostname || "").trim().toLowerCase(), e = n.services, i = tp(t) || e.some((g) => Qm(g)), o = !e.some(
    (g) => !i && Gm.has(String(g.host || "").trim())
  ), r = e.some(
    (g) => Km.has(String(g.host || "").trim())
  ) ? "poll" : "mutation", a = e.some(
    (g) => !i && Ym.has(String(g.host || "").trim())
  ), l = np(t, e), c = !e.some(
    (g) => jm.has(String(g.host || "").trim())
  ) && !Xm.some(
    (g) => g.test(t)
  ), d = o ? ep(e) : [], h = d.length > 0, f = i || e.some(
    (g) => Jm.has(String(g.host || "").trim())
  ) || Zm.some(
    (g) => g.test(t)
  );
  return {
    preferProbeBootstrap: c,
    startDomObservationOnEnable: o,
    probeStrategy: r,
    probeSelectors: l,
    probePollIntervalMs: r === "poll" ? 120 : 0,
    probePollTimeoutMs: r === "poll" ? 4e3 : 0,
    stopAfterFirstVideoDetected: a,
    keepWatchingAfterVideoDetected: f,
    observeShadowRoots: h,
    shadowHostSelectors: d
  };
}
function sp(n) {
  return n.isIframe ? n.origin === "null" : !1;
}
function op(n) {
  return sp(n) ? "skip" : !n.isIframe && n.origin === n.authOrigin ? "auth-eager" : "lazy";
}
class rp {
  constructor({
    url: t,
    video: e,
    debug: i = !1,
    fetchFn: s = cn.fetchFn,
    fetchOpts: o = {},
    preferAudio: r = !1
  }) {
    u(this, "_debug", !1);
    u(this, "audioContext");
    u(this, "player");
    u(this, "video");
    u(this, "fetchFn");
    u(this, "fetchOpts");
    this._debug = cn.debug = i, this.fetchFn = s, this.fetchOpts = o, this.audioContext = r ? void 0 : no(), this.player = r ? new jl(this, t) : new Xl(this, t), this.video = e;
  }
  async init() {
    await this.player.init(), this.video && !this.video.paused && this.player.lipSync("play"), this.player.addVideoEvents();
  }
  set debug(t) {
    this._debug = cn.debug = t;
  }
  get debug() {
    return this._debug;
  }
}
function cu(n) {
  return n ? typeof ShadowRoot < "u" && n instanceof ShadowRoot ? n.host : n.parentNode ?? null : null;
}
function be(n, t) {
  let e = t;
  for (; e; ) {
    if (e === n) return !0;
    e = cu(e);
  }
  return !1;
}
function ap(n) {
  return n === document.body || n === document.documentElement;
}
function co(n, t, e = {}) {
  const { allowDocumentViewport: i = !1 } = e;
  if (!(n instanceof HTMLElement) || ap(n) && !i)
    return null;
  for (const s of t)
    if (s && (be(n, s) || be(s, n)))
      return n;
  return null;
}
function lp(n, t) {
  if (!n || !t) return null;
  const e = n instanceof Document ? null : n, i = (s) => {
    if (!s) return null;
    if (s instanceof Document) {
      if (e) {
        const a = s.querySelectorAll(t);
        for (const l of a)
          if (be(l, e))
            return l;
        return null;
      }
      return s.querySelector(t);
    }
    const o = s.closest(t);
    if (o) return o;
    const r = s.getRootNode();
    if (r instanceof ShadowRoot)
      return i(r.host);
    if (r instanceof Document)
      return i(r);
    if (r !== s) {
      const a = cu(r);
      if (a && a !== s && a instanceof Element)
        return i(a);
    }
    return null;
  };
  return i(n);
}
function up(n, t) {
  if (n !== t)
    return n;
  let e = t.parentElement;
  for (; e; ) {
    if (e !== document.body && e !== document.documentElement)
      return e;
    e = e.parentElement;
  }
  return n;
}
function An(n, t) {
  if (!t)
    return null;
  const e = lp(n, t);
  return e instanceof HTMLElement && e.isConnected && be(e, n) ? up(e, n) : null;
}
const du = /* @__PURE__ */ new Set(["youtube", "googledrive"]), cp = du, dp = /* @__PURE__ */ new Set(["rutube", "ok"]), hp = /* @__PURE__ */ new Set([
  "youtube",
  "invidious",
  "piped"
]);
function Hn(n) {
  return du.has(n);
}
function ho(n) {
  return cp.has(n);
}
function fp(n) {
  return dp.has(n);
}
function Di(n) {
  return ho(n.host) && !n.additionalData;
}
function _t(n) {
  return ho(n.host) && (n.additionalData === "mobile" || n.additionalData === "music");
}
function gp(n) {
  return hp.has(n);
}
const jr = "data-vot-mobile-youtube-overlay-root";
function mp() {
  return document.body ?? document.documentElement;
}
function pp(n) {
  const t = n.additionalData === "music" ? "music" : "mobile", e = mp();
  let i = document.querySelector(
    `[${jr}="${t}"]`
  );
  return i ? i.parentElement !== e && e.appendChild(i) : (i = document.createElement("vot-block"), i.setAttribute(jr, t), i.style.position = "fixed", i.style.left = "0", i.style.top = "0", i.style.width = "100vw", i.style.height = "100vh", i.style.margin = "0", i.style.padding = "0", i.style.border = "0", i.style.background = "transparent", i.style.overflow = "visible", i.style.pointerEvents = "none", i.style.zIndex = "2147483645", e.appendChild(i)), i;
}
function yp(n, t) {
  return n instanceof HTMLVideoElement || Di(t) ? n.parentElement ?? n : n;
}
function bp(n) {
  const t = yp(n.container, n.site), e = !n.fullscreenRoot && _t(n.site) ? pp(n.site) : null, i = n.fullscreenRoot ?? e ?? t, s = n.site.host === "googledrive" ? n.fullscreenRoot ?? document.body : n.site.host === "vk" ? n.fullscreenRoot ?? document.documentElement : e ? t : i;
  return {
    base: t,
    root: i,
    portalContainer: e ?? t,
    subtitlesMountContainer: s
  };
}
function oe(n, t) {
  return n === "custom" || t === "custom" || n === "okru" || t === "okru";
}
function vp(n) {
  return oe(n.siteHost, n.videoHost) || n.isStream || !n.hasAudioContext || !n.newAudioPlayer ? !0 : n.onlyBypassMediaCSP ? !n.needBypassCSP : !1;
}
function Ls() {
  const n = globalThis.location.hostname.toLowerCase();
  return n === "drive.google.com" || n === "youtube.googleapis.com";
}
const Xr = /* @__PURE__ */ new WeakMap(), Jr = /* @__PURE__ */ new WeakMap();
function wp(n) {
  if (n.currentSrc || n.src || n.srcObject)
    return !0;
  const t = n.querySelector("source");
  return !!(t?.getAttribute("src") || t?.src);
}
function Sp(n) {
  return !n.paused || n.currentTime > 0.01 || n.ended || n.played.length > 0;
}
function Tp(n) {
  const t = n, e = t.captureStream ?? t.mozCaptureStream;
  if (typeof e != "function")
    return null;
  try {
    return e.call(n).getAudioTracks().length;
  } catch {
    return null;
  }
}
function kp(n, t) {
  const e = n, i = [], s = t && n.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA;
  if (n.srcObject instanceof MediaStream) {
    const a = n.srcObject.getAudioTracks().length;
    return i.push(`srcObject:${a}`), {
      presence: a > 0,
      source: "srcObject",
      signals: i
    };
  }
  if (typeof e.mozHasAudio == "boolean" && (i.push(`mozHasAudio:${e.mozHasAudio}`), e.mozHasAudio))
    return {
      presence: !0,
      source: "mozHasAudio",
      signals: i
    };
  if (typeof e.webkitAudioDecodedByteCount == "number" && e.webkitAudioDecodedByteCount > 0)
    return i.push(
      `webkitAudioDecodedByteCount:${e.webkitAudioDecodedByteCount}`
    ), {
      presence: !0,
      source: "webkitAudioDecodedByteCount",
      signals: i
    };
  let o = 0;
  if ("audioTracks" in e && typeof e.audioTracks?.length == "number") {
    if (i.push(`audioTracks:${e.audioTracks.length}`), e.audioTracks.length > 0)
      return {
        presence: !0,
        source: "audioTracks",
        signals: i
      };
    s && (o += 1);
  }
  const r = Tp(n);
  if (r !== null) {
    if (i.push(`captureStream:${r}`), r > 0)
      return {
        presence: !0,
        source: "captureStream",
        signals: i
      };
    s && (o += 1);
  }
  return s && typeof e.mozHasAudio == "boolean" && e.mozHasAudio === !1 && (o += 1), s && o >= 2 ? {
    presence: !1,
    source: "negative-signals",
    signals: i
  } : {
    presence: null,
    source: "unknown",
    signals: i
  };
}
function Lp(n, t, e) {
  const i = JSON.stringify({
    audioDetected: t.audioDetected,
    detectionSource: t.detectionSource,
    signals: e.signals
  });
  Xr.get(n) !== i && (Xr.set(n, i), console.log("[VOT][source-audio] audio detected", {
    audioDetected: t.audioDetected,
    detectionSource: t.detectionSource,
    signals: e.signals,
    paused: e.paused,
    currentTime: Number(e.currentTime.toFixed(3)),
    readyState: e.readyState
  }));
  const s = JSON.stringify({
    kind: t.kind,
    ready: t.ready,
    localizationKey: t.localizationKey ?? null,
    audioDetected: t.audioDetected,
    detectionSource: t.detectionSource,
    playbackStarted: e.playbackStarted,
    hasMediaSource: e.hasMediaSource,
    readyState: e.readyState
  });
  Jr.get(n) !== s && (Jr.set(n, s), console.log("[VOT][source-audio] status selected", {
    kind: t.kind,
    ready: t.ready,
    localizationKey: t.localizationKey ?? null,
    audioDetected: t.audioDetected,
    detectionSource: t.detectionSource,
    playbackStarted: e.playbackStarted,
    hasMediaSource: e.hasMediaSource,
    paused: e.paused,
    currentTime: Number(e.currentTime.toFixed(3)),
    playedRanges: e.playedRanges,
    readyState: e.readyState
  }));
}
function hu(n) {
  const t = Sp(n), e = wp(n), i = kp(n, t);
  let s;
  return t ? i.presence === !0 ? s = {
    kind: "ready",
    ready: !0,
    audioDetected: !0,
    detectionSource: i.source
  } : i.presence === !1 ? s = {
    kind: "missing",
    ready: !1,
    audioDetected: !1,
    detectionSource: i.source,
    localizationKey: "VOTAudioNotDetected"
  } : e ? n.readyState < HTMLMediaElement.HAVE_METADATA ? s = {
    kind: "pending",
    ready: !1,
    audioDetected: null,
    detectionSource: i.source,
    localizationKey: "VOTAudioNotYetAvailable"
  } : n.readyState < HTMLMediaElement.HAVE_CURRENT_DATA ? s = {
    kind: "pending",
    ready: !1,
    audioDetected: null,
    detectionSource: i.source,
    localizationKey: "VOTAudioNotYetAvailable"
  } : s = {
    kind: "ready",
    ready: !0,
    audioDetected: i.presence,
    detectionSource: i.source
  } : s = {
    kind: "pending",
    ready: !1,
    audioDetected: null,
    detectionSource: i.source,
    localizationKey: "VOTAudioNotYetAvailable"
  } : s = {
    kind: "needsPlayback",
    ready: !1,
    audioDetected: i.presence,
    detectionSource: i.source,
    localizationKey: "VOTStartVideoForTranslation"
  }, Lp(n, s, {
    playbackStarted: t,
    hasMediaSource: e,
    readyState: n.readyState,
    paused: n.paused,
    currentTime: n.currentTime,
    playedRanges: n.played.length,
    signals: i.signals
  }), s;
}
class z {
  constructor() {
    u(this, "listeners", /* @__PURE__ */ new Set());
  }
  get size() {
    return this.listeners.size;
  }
  addListener(t) {
    return this.listeners.add(t), this;
  }
  removeListener(t) {
    return this.listeners.delete(t), this;
  }
  dispatch(...t) {
    for (const e of this.listeners)
      try {
        e(...t);
      } catch (i) {
        console.error("[VOT]", i);
      }
  }
  async dispatchAsync(...t) {
    const e = [];
    for (const s of this.listeners)
      try {
        const o = s(...t);
        o && typeof o.then == "function" && e.push(Promise.resolve(o));
      } catch (o) {
        console.error("[VOT]", o);
      }
    if (!e.length)
      return;
    const i = await Promise.allSettled(e);
    for (const s of i)
      s.status === "rejected" && console.error("[VOT]", s.reason);
  }
  clear() {
    this.listeners.clear();
  }
}
function Zr(n, t, e, i) {
  return JSON.stringify({
    downloadType: n,
    itag: t,
    minChunkSize: i,
    fileSize: e
  });
}
function fo(n) {
  return n?.toLowerCase() ?? "";
}
function fu(n) {
  const t = fo(n);
  return t.includes("audio/") && !t.includes("video/");
}
function Ap(n) {
  const t = fo(n);
  return t.includes("audio/mp4") && t.includes("mp4a.");
}
function Qr(n) {
  const t = fo(n);
  return t.includes("audio/webm") && t.includes("opus");
}
function xp(n) {
  if (!n)
    return "mp4a.40.2";
  const t = /codecs="([^"]+)"/i.exec(n);
  if (!t?.[1])
    return "mp4a.40.2";
  const e = t[1].split(",").map((i) => i.trim());
  return e.find((i) => i.toLowerCase().startsWith("mp4a.")) ?? e[0] ?? "mp4a.40.2";
}
function Vp(n, t) {
  let e = null, i = t === "max" ? -1 / 0 : 1 / 0;
  for (const s of n) {
    const o = s.bitrate ?? 0;
    (t === "max" && o > i || t === "min" && o < i) && (e = s, i = o);
  }
  return e;
}
function Cp(n, t) {
  const e = n.filter(
    (o) => fu(o.mimeType)
  );
  if (!e.length)
    throw new Error("No adaptive audio formats were found in player response");
  const i = t === "bestefficiency" ? "min" : "max", s = t === "bestefficiency" ? [
    e.filter(
      (o) => Qr(o.mimeType)
    ),
    e
  ] : [
    e.filter(
      (o) => Ap(o.mimeType)
    ),
    e.filter(
      (o) => Qr(o.mimeType)
    ),
    e
  ];
  for (const o of s) {
    if (!o.length)
      continue;
    const r = Vp(o, i);
    if (r)
      return r;
  }
  throw new Error("No adaptive audio formats were found in player response");
}
class gu extends Error {
  constructor(e = 403) {
    super(`Failed to load watch page: ${e}`);
    u(this, "status");
    this.name = "YtWatchContextForbiddenError", this.status = e;
  }
}
const Qe = /^[a-zA-Z0-9_-]{11}$/, Be = "https://www.youtube.com", Ep = "19.44.38", Ip = "1.60.19", Pp = "19.45.4", ta = [
  "ANDROID_VR",
  "ANDROID",
  "IOS",
  "WEB",
  "MWEB"
], Wn = {
  accept: "*/*",
  origin: Be,
  referer: `${Be}/`
}, ea = 256 * 1024;
function zn(n) {
  return n ? { signal: n } : {};
}
function Mp(n, t, e) {
  switch (n) {
    case "ANDROID":
    case "YTMUSIC_ANDROID":
    case "YTSTUDIO_ANDROID":
      return {
        clientName: "ANDROID",
        clientVersion: Ep,
        hl: "en",
        gl: "US",
        androidSdkVersion: 34,
        osName: "Android",
        osVersion: "14",
        platform: "MOBILE"
      };
    case "ANDROID_VR":
      return {
        clientName: "ANDROID_VR",
        clientVersion: Ip,
        hl: "en",
        gl: "US",
        androidSdkVersion: 31,
        osName: "Android",
        osVersion: "12",
        platform: "MOBILE"
      };
    case "IOS":
      return {
        clientName: "IOS",
        clientVersion: Pp,
        hl: "en",
        gl: "US",
        platform: "MOBILE",
        osName: "iPhone",
        osVersion: "18.0.0.22A3354",
        deviceMake: "Apple",
        deviceModel: "iPhone16,2"
      };
    case "MWEB":
      return {
        clientName: "MWEB",
        clientVersion: t.clientVersion,
        hl: "en",
        gl: "US",
        originalUrl: `${Be}/watch?v=${e}`
      };
    default:
      return {
        clientName: "WEB",
        clientVersion: t.clientVersion,
        hl: "en",
        gl: "US",
        utcOffsetMinutes: 0,
        originalUrl: `${Be}/watch?v=${e}`
      };
  }
}
function Op(n) {
  const t = n.trim();
  if (Qe.test(t))
    return t;
  let e;
  try {
    e = new URL(t);
  } catch {
    throw new Error(`Cannot extract YouTube video id from: ${n}`);
  }
  const i = e.hostname.toLowerCase();
  if (i === "youtu.be" || i.endsWith(".youtu.be")) {
    const l = e.pathname.split("/").find(Boolean);
    if (l && Qe.test(l))
      return l;
  }
  const s = e.searchParams.get("v");
  if (s && Qe.test(s))
    return s;
  const o = e.pathname.split("/").filter(Boolean), r = o.indexOf("shorts");
  if (r !== -1) {
    const l = o[r + 1];
    if (l && Qe.test(l))
      return l;
  }
  const a = o.indexOf("embed");
  if (a !== -1) {
    const l = o[a + 1];
    if (l && Qe.test(l))
      return l;
  }
  throw new Error(`Cannot extract YouTube video id from: ${n}`);
}
function Dp(n) {
  return n.replaceAll("\\u0026", "&").replaceAll("\\/", "/");
}
function _p(n) {
  const t = n.videoId ?? n.videoUrl;
  if (!t)
    throw new Error("Either videoId or videoUrl is required");
  return Op(t);
}
function qn(n, t) {
  for (const e of t) {
    const i = e.exec(n)?.[1];
    if (i)
      return i;
  }
}
async function Rp(n) {
  return new Uint8Array(await n.arrayBuffer());
}
function Bp(n = 16) {
  const t = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_";
  let e = "";
  if (typeof crypto < "u" && typeof crypto.getRandomValues == "function") {
    const i = new Uint8Array(n);
    crypto.getRandomValues(i);
    for (const s of i)
      e += t[s % t.length] ?? "a";
    return e;
  }
  for (let i = 0; i < n; i++)
    e += t[Math.floor(Math.random() * t.length)] ?? "a";
  return e;
}
function si(n) {
  if (!n)
    return null;
  const t = Number.parseInt(n, 10);
  return !Number.isFinite(t) || t <= 0 ? null : t;
}
function Fp(n) {
  if (!n)
    return null;
  const t = /\/(\d+)\s*$/i.exec(n);
  return si(t?.[1]);
}
function Np(n) {
  if (!n)
    return null;
  const t = /^bytes\s+(\d+)-(\d+)\/(?:\d+|\*)$/i.exec(
    n.trim()
  );
  if (!t)
    return null;
  const e = Number.parseInt(t[1] ?? "", 10), i = Number.parseInt(t[2] ?? "", 10);
  return !Number.isFinite(e) || !Number.isFinite(i) || e < 0 || i < e ? null : { start: e, end: i };
}
function Up(n, t) {
  return t - n + 1;
}
function $p(n, t, e, i) {
  const s = Up(e, i);
  if (s <= 0 || t.byteLength <= 0 || t.byteLength > s)
    return !1;
  const o = Np(
    n.headers.get("content-range")
  );
  return o ? o.start === e && o.end === e + t.byteLength - 1 : n.status === 206 ? t.byteLength === s : n.status === 200 ? e === 0 && t.byteLength === s : !1;
}
function Hp(n, t) {
  const e = n.headers.get("content-range") ?? "none", i = n.headers.get("content-length") ?? "none";
  return `status=${n.status}; bytes=${t.byteLength}; content-range=${e}; content-length=${i}`;
}
function Wp(n) {
  const t = n?.toLowerCase() ?? "";
  return t.includes("audio/webm") ? "audio/webm" : t.includes("audio/mp4") ? "audio/mp4" : "audio/aac";
}
function zp(n) {
  const t = n ? [n, ...ta] : [...ta], e = /* @__PURE__ */ new Set();
  return t.filter((i) => e.has(i) ? !1 : (e.add(i), !0));
}
let qp = class {
  constructor(t = {}) {
    u(this, "fetchFn");
    this.fetchFn = t.fetchImplementation ?? fetch;
  }
  async fetchRangeChunk(t, e, i, s) {
    const o = `bytes=${e}-${i}`, r = await this.fetchFn(t, {
      headers: {
        ...Wn,
        range: o
      },
      ...zn(s)
    });
    if (!r.ok)
      throw new Error(`Failed to download stream chunk: ${r.status}`);
    const a = await Rp(r);
    if (!$p(r, a, e, i))
      throw new Error(
        `Received unexpected stream chunk payload: ${Hp(r, a)}`
      );
    return a;
  }
  async downloadStreamByRanges(t, e, i) {
    const s = await this.resolveStreamContentLength(
      t,
      e,
      i,
      !0
    ), o = new Uint8Array(s);
    let r = 0;
    for (let a = 0; a < s; a += ea) {
      const l = Math.min(s - 1, a + ea - 1), c = await this.fetchRangeChunk(t, a, l, i);
      if (r + c.byteLength > o.byteLength)
        throw new Error(
          "Downloaded stream chunk exceeds probed stream content length"
        );
      o.set(c, r), r += c.byteLength;
    }
    return r === o.byteLength ? o : o.slice(0, r);
  }
  async downloadAudioToChunkStream(t, e) {
    if (e.chunkSize <= 0)
      throw new RangeError("Audio downloader. ytAudio. chunkSize must be > 0");
    return this.withResolvedPlayableAudioFormat(
      t,
      t.videoQuality ?? "best",
      "Chunk mode requires an adaptive audio stream format",
      "Unable to resolve streamable format for chunk mode",
      async ({ resolved: i, signal: s }) => {
        const o = await this.resolveStreamContentLength(
          i.streamUrl,
          i.chosenFormat.contentLength,
          s,
          !0
        ), r = Math.max(
          1,
          Math.ceil(o / e.chunkSize)
        );
        return {
          videoId: i.videoId,
          fileSize: o,
          itag: i.chosenFormat.itag ?? 0,
          mediaPartsLength: r,
          getMediaBuffers: async function* () {
            for (let a = 0; a < r; a++) {
              const l = a * e.chunkSize, c = Math.min(o - 1, l + e.chunkSize - 1);
              yield await this.fetchRangeChunk(
                i.streamUrl,
                l,
                c,
                s
              );
            }
          }.bind(this)
        };
      }
    );
  }
  async downloadAudioToUint8Array(t) {
    const e = [];
    let i = 0;
    const s = await this.extractAndWriteAudio(t, {
      async write(a) {
        e.push(a), i += a.byteLength;
      }
    }), o = new Uint8Array(i);
    let r = 0;
    for (const a of e)
      o.set(a, r), r += a.byteLength;
    return {
      ...s,
      bytes: o
    };
  }
  async extractAndWriteAudio(t, e) {
    return this.withResolvedPlayableAudioFormat(
      t,
      t.videoQuality ?? "bestefficiency",
      "Selected stream is not audio-only",
      "Unable to download playable stream format",
      async ({ resolved: i, signal: s }) => {
        const o = await this.downloadStreamByRanges(
          i.streamUrl,
          i.chosenFormat.contentLength,
          s
        ), r = this.getExtractionHints(i.chosenFormat);
        return await e.write(o), {
          videoId: i.videoId,
          bytesWritten: o.byteLength,
          mimeType: Wp(i.chosenFormat.mimeType),
          codec: r.codec,
          sampleRate: r.sampleRate,
          channels: r.channels
        };
      }
    );
  }
  async withResolvedPlayableAudioFormat(t, e, i, s, o) {
    const r = _p(t), { signal: a } = t, l = await this.fetchWatchContext(r, a), c = zp(t.client), d = [];
    for (const h of c)
      try {
        const f = await this.resolvePlayableFormatForClient({
          videoId: r,
          watchContext: l,
          client: h,
          quality: e,
          signal: a
        });
        if (!fu(f.chosenFormat.mimeType))
          throw new Error(i);
        return await o({ resolved: f, signal: a });
      } catch (f) {
        const g = f instanceof Error ? f.message : String(f);
        d.push(`${h}: ${g}`);
      }
    throw new Error(`${s}. Attempts: ${d.join(" | ")}`);
  }
  async resolvePlayableFormatForClient({
    videoId: t,
    watchContext: e,
    client: i,
    quality: s,
    signal: o
  }) {
    const l = ((await this.fetchPlayerResponse(
      t,
      e,
      i,
      o
    )).streamingData?.adaptiveFormats ?? []).filter(
      (h) => !!h.url
    );
    if (!l.length)
      throw new Error(
        "Player response did not contain direct adaptive audio stream URLs"
      );
    const c = Cp(
      l,
      s
    ), d = this.resolveFormatUrl(
      c,
      e.clientVersion
    );
    return {
      videoId: t,
      chosenFormat: c,
      streamUrl: d
    };
  }
  async resolveStreamContentLength(t, e, i, s = !1) {
    const o = si(e);
    if (o !== null && !s)
      return o;
    let r;
    try {
      r = await this.fetchFn(t, {
        headers: {
          ...Wn,
          range: "bytes=0-0"
        },
        ...zn(i)
      });
    } catch (d) {
      if (o !== null)
        return o;
      const h = d instanceof Error ? d.message : String(d);
      throw new Error(`Failed to probe stream content length: ${h}`);
    }
    if (!r.ok) {
      if (o !== null)
        return o;
      throw new Error(
        `Failed to probe stream content length: ${r.status}`
      );
    }
    const a = Fp(
      r.headers.get("content-range")
    ), l = si(
      r.headers.get("x-goog-stored-content-length")
    ), c = si(
      r.headers.get("content-length")
    );
    if (typeof r.body?.cancel == "function")
      try {
        await r.body.cancel();
      } catch {
      }
    return a ?? l ?? o ?? c ?? (() => {
      throw new Error("Failed to resolve stream content length");
    })();
  }
  getExtractionHints(t) {
    const e = xp(t.mimeType), i = Number.parseInt(t.audioSampleRate ?? "", 10);
    return {
      codec: e,
      sampleRate: Number.isFinite(i) && i > 0 ? i : 44100,
      channels: t.audioChannels && t.audioChannels > 0 ? t.audioChannels : 2
    };
  }
  resolveFormatUrl(t, e) {
    if (!t.url)
      throw new Error("Selected format does not contain a direct stream URL");
    const i = new URL(t.url);
    return i.searchParams.get("c") === "WEB" && i.searchParams.set("cver", e), i.searchParams.set("cpn", Bp()), i.toString();
  }
  async fetchWatchContext(t, e) {
    const i = `${Be}/watch?v=${encodeURIComponent(t)}&hl=en`, s = await this.fetchFn(i, {
      headers: Wn,
      ...zn(e)
    });
    if (!s.ok)
      throw s.status === 403 ? new gu(s.status) : new Error(`Failed to load watch page: ${s.status}`);
    const o = await s.text(), r = qn(o, [
      /"INNERTUBE_API_KEY":"([^"]+)"/,
      /["']INNERTUBE_API_KEY["']\s*:\s*"([^"]+)"/
    ]), a = qn(o, [
      /"INNERTUBE_CLIENT_VERSION":"([^"]+)"/,
      /["']INNERTUBE_CLIENT_VERSION["']\s*:\s*"([^"]+)"/
    ]), l = qn(o, [/"STS":(\d+)/, /["']STS["']\s*:\s*(\d+)/]), c = qn(o, [
      /"VISITOR_DATA":"([^"]+)"/,
      /"visitorData":"([^"]+)"/,
      /["'](?:VISITOR_DATA|visitorData)["']\s*:\s*"([^"]+)"/
    ]);
    if (!r || !a)
      throw new Error(
        "Failed to extract required player context from watch page"
      );
    const d = l ? Number.parseInt(l, 10) : void 0, h = {
      apiKey: r,
      clientVersion: a
    };
    return typeof d == "number" && Number.isFinite(d) && (h.signatureTimestamp = d), c && (h.visitorData = Dp(c)), h;
  }
  async fetchPlayerResponse(t, e, i, s) {
    const o = Mp(
      i,
      e,
      t
    );
    e.visitorData && (o.visitorData = e.visitorData);
    const r = {
      context: {
        client: o
      },
      videoId: t,
      contentCheckOk: !0,
      racyCheckOk: !0
    };
    e.signatureTimestamp && (r.playbackContext = {
      contentPlaybackContext: {
        signatureTimestamp: e.signatureTimestamp
      }
    });
    const a = `${Be}/youtubei/v1/player?key=${encodeURIComponent(e.apiKey)}`, l = await this.fetchFn(a, {
      method: "POST",
      headers: {
        ...Wn,
        "content-type": "application/json",
        ...e.visitorData ? { "x-goog-visitor-id": e.visitorData } : {}
      },
      body: JSON.stringify(r),
      ...zn(s)
    });
    if (!l.ok)
      throw new Error(
        `Player API request failed with status ${l.status}`
      );
    const c = await l.json(), d = !!c.streamingData?.formats?.length, h = !!c.streamingData?.adaptiveFormats?.length;
    if (!d && !h)
      throw new Error("Player response did not contain streaming formats");
    return c;
  }
};
const na = "bestefficiency", Gp = 3e4;
function Kp(n) {
  if (n <= 0)
    throw new RangeError("Audio downloader. ytAudio. chunkSize must be > 0");
}
function Yp({
  signal: n,
  timeoutMs: t
}) {
  return async (e, i = {}) => await ut(e, {
    ...i,
    signal: i.signal ?? n,
    forceGmXhr: !0,
    timeout: t
  });
}
function jp(n) {
  return n instanceof gu ? !0 : n instanceof Error && /failed to load watch page:\s*403/i.test(n.message);
}
async function Xp({ videoId: n, signal: t }, e = {}) {
  const i = e.chunkSize ?? et.minChunkSize;
  Kp(i);
  const s = Yp({
    signal: t,
    timeoutMs: e.fetchTimeoutMs ?? Gp
  }), o = e.createDownloader?.(s) ?? new qp({ fetchImplementation: s });
  try {
    const d = await o.downloadAudioToChunkStream(
      {
        videoId: n,
        videoQuality: na,
        signal: t
      },
      { chunkSize: i }
    );
    return {
      fileId: Zr(
        wn.WEB_API_STEAL_SIG_AND_N,
        d.itag,
        String(d.fileSize),
        i
      ),
      mediaPartsLength: d.mediaPartsLength,
      getMediaBuffers: d.getMediaBuffers
    };
  } catch (d) {
    if (jp(d))
      throw d;
    console.warn(
      "[VOT] ytAudio streaming mode failed, falling back to buffered mode",
      d
    );
  }
  const a = (await o.downloadAudioToUint8Array({
    videoId: n,
    videoQuality: na,
    signal: t
  })).bytes;
  if (!a || a.byteLength === 0)
    throw new Error("Audio downloader. ytAudio. Empty audio");
  const l = Math.max(1, Math.ceil(a.byteLength / i));
  return {
    fileId: Zr(
      wn.WEB_API_STEAL_SIG_AND_N,
      0,
      String(a.byteLength),
      i
    ),
    mediaPartsLength: l,
    async *getMediaBuffers() {
      for (let d = 0; d < a.byteLength; d += i) {
        const h = Math.min(d + i, a.byteLength);
        yield a.subarray(d, h);
      }
    }
  };
}
function ia(n, t) {
  return `local_${n}_${t}_${Date.now()}`;
}
async function Jp(n, t) {
  if (!n)
    throw new Error("[VOT] Local file: empty media src");
  if (n.startsWith("blob:")) {
    const i = await fetch(n, { signal: t });
    if (!i.ok)
      throw new Error(
        `[VOT] Local file: failed to fetch blob media: ${i.status}`
      );
    return i;
  }
  try {
    const i = await fetch(n, { signal: t });
    if (i.ok)
      return i;
  } catch {
  }
  const e = await ut(n, { signal: t, timeout: 0 });
  if (!e.ok)
    throw new Error(
      `[VOT] Local file: failed to fetch media source: ${e.status}`
    );
  return e;
}
function Zp(n) {
  const t = n.headers.get("content-length") || n.headers.get("Content-Length");
  if (!t) return null;
  const e = Number.parseInt(t, 10);
  return Number.isFinite(e) && e > 0 ? e : null;
}
async function Qp({
  signal: n
}) {
  const t = document.querySelector("video");
  if (!(t instanceof HTMLVideoElement))
    throw new Error("[VOT] Local file: video element not found");
  const e = t.querySelector("source"), i = t.currentSrc || t.src || e?.src || e?.getAttribute("src") || "";
  if (!i)
    throw new Error("[VOT] Local file: empty video src");
  const s = await Jp(i, n), o = 256 * 1024, r = Zp(s);
  if (s.body && r) {
    const h = Math.max(1, Math.ceil(r / o));
    return {
      fileId: ia(r, o),
      mediaPartsLength: h,
      async *getMediaBuffers() {
        const g = s.body?.getReader();
        let m = new Uint8Array(0);
        try {
          for (; ; ) {
            const { done: v, value: S } = await g.read();
            if (v) break;
            if (!S?.byteLength) continue;
            let T;
            m.byteLength === 0 ? T = S : (T = new Uint8Array(m.byteLength + S.byteLength), T.set(m, 0), T.set(S, m.byteLength));
            let w = 0;
            for (; T.byteLength - w >= o; )
              yield T.subarray(w, w + o), w += o;
            m = w < T.byteLength ? T.slice(w) : new Uint8Array(0);
          }
          m.byteLength && (yield m);
        } finally {
          g.releaseLock();
        }
      }
    };
  }
  const a = await s.arrayBuffer(), l = new Uint8Array(a);
  if (!l.byteLength)
    throw new Error("[VOT] Local file: empty media bytes");
  const c = Math.max(1, Math.ceil(l.byteLength / o));
  return {
    fileId: ia(l.byteLength, o),
    mediaPartsLength: c,
    async *getMediaBuffers() {
      for (let h = 0; h < l.byteLength; h += o) {
        const f = Math.min(h + o, l.byteLength);
        yield l.subarray(h, f);
      }
    }
  };
}
const ty = [
  /\.m3u8(?:$|[?#])/i,
  /\.mpd(?:$|[?#])/i,
  /master\.m3u8/i,
  /manifest/i,
  /dashplaylist/i,
  /\.mp4(?:$|[?#])/i
];
function ey(n) {
  return ty.some((t) => t.test(n));
}
let ie = null, sa = !1;
function ny(n) {
  try {
    return new URL(n, globalThis.location.href).href;
  } catch {
    return n;
  }
}
function iy(n) {
  return /\.m3u8(?:$|[?#])/i.test(n) || /\.mpd(?:$|[?#])/i.test(n) || /master\.m3u8/i.test(n) || /dashplaylist/i.test(n) || /\.mp4(?:$|[?#])/i.test(n);
}
function sy(n) {
  const t = n.toLowerCase();
  return iy(t) ? !1 : t.includes("okcdn.ru/?") || /[?&]bytes=\d+-\d+/i.test(t) || /[?&]type=\d+/i.test(t);
}
function oa(n) {
  const t = ny(n);
  if (sy(t) || !ey(t))
    return;
  if (console.log("[VOT][manifestSniffer] candidate", t), !ie) {
    ie = { url: t, seenAt: Date.now() }, console.log("[VOT][manifestSniffer] selected", ie.url);
    return;
  }
  const e = ra(ie.url);
  ra(t) >= e && (ie = { url: t, seenAt: Date.now() }, console.log("[VOT][manifestSniffer] selected", ie.url));
}
function ra(n) {
  let t = 0;
  return /\.mp4(?:$|[?#])/i.test(n) && (t += 5), /\.m3u8(?:$|[?#])/i.test(n) && (t += 4), /master\.m3u8/i.test(n) && (t += 3), /\.mpd(?:$|[?#])/i.test(n) && (t += 2), /manifest/i.test(n) && (t += 1), /dashplaylist/i.test(n) && (t += 1), /vkvd\d+\.okcdn\.ru|\.okcdn\.ru|vkvideo\.ru/i.test(n) && (t += 2), t;
}
function mu() {
  return ie?.url ?? "";
}
const aa = "__VOT_DIRECT_SOURCES__";
function la(n) {
  try {
    const t = JSON.parse(n);
    if (!t || typeof t != "object" || !("unitedVideoId" in t || "video" in t && typeof t.video == "object")) return;
    const i = globalThis[aa];
    if (i && typeof i == "object") return;
    globalThis[aa] = t, console.log("[VOT][manifestSniffer] injected __VOT_DIRECT_SOURCES__", t);
  } catch {
  }
}
function pu() {
  if (sa)
    return;
  sa = !0;
  const n = globalThis.fetch.bind(globalThis);
  globalThis.fetch = async (...e) => {
    const i = e[0], s = typeof i == "string" ? i : i instanceof Request ? i.url : String(i ?? "");
    oa(s);
    const o = await n(...e);
    return o.headers.get("content-type")?.includes("application/json") && o.clone().text().then(la).catch(() => {
    }), o;
  };
  const t = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(e, i, ...s) {
    return oa(String(i)), this.addEventListener("load", function() {
      const o = this.getResponseHeader("content-type") ?? "";
      (o.includes("application/json") || o.includes("text/javascript")) && la(this.responseText ?? "");
    }), t.call(this, e, i, ...s);
  };
}
const oy = ".videoplayer_media, vk-video-player";
function ry(n, t) {
  return `vk_${n}_${t}_${Date.now()}`;
}
function oi(n) {
  return /\.m3u8(?:$|[?#])/i.test(n);
}
function ay(n, t) {
  return new URL(n, t).toString();
}
function ri(n) {
  const t = n.querySelector("source");
  return String(
    n.currentSrc || n.src || t?.src || t?.getAttribute("src") || ""
  ).trim();
}
function yu(n) {
  const t = n.getBoundingClientRect();
  return t.width > 64 && t.height > 64;
}
function ly(n) {
  const t = /* @__PURE__ */ new Set(), e = [], i = (s) => {
    !(s instanceof HTMLVideoElement) || t.has(s) || (t.add(s), e.push(s));
  };
  i(n);
  for (const s of Array.from(document.querySelectorAll("video")))
    i(s);
  return e;
}
function ns(n, t) {
  let e = 0;
  const i = ri(n);
  return n === t && (e += 100), n.isConnected && (e += 10), yu(n) && (e += 25), n.closest(oy) && (e += 20), n.paused || (e += 8), n.readyState > 0 && (e += 8), i && (e += 4), i && !i.startsWith("blob:") && (e += 6), e;
}
function bu(n) {
  try {
    return new URL(n, globalThis.location.href).toString();
  } catch {
    return String(n || "").trim();
  }
}
function uy(n) {
  const t = bu(n);
  if (!t)
    return Number.NEGATIVE_INFINITY;
  const e = t.toLowerCase();
  let i = 0;
  return e.startsWith("blob:") && (i -= 100), /\.mp4(?:$|[?#])/i.test(t) && (i += 50), /\.m3u8(?:$|[?#])/i.test(t) && (i += 45), /master\.m3u8/i.test(t) && (i += 35), /\.mpd(?:$|[?#])/i.test(t) && (i += 30), /manifest/i.test(t) && (i += 15), /dashplaylist/i.test(t) && (i += 15), /vkvd\d+\.okcdn\.ru|\.okcdn\.ru|vkvideo\.ru/i.test(t) && (i += 10), /[?&]bytes=\d+-\d+/i.test(t) && (i -= 60), /[?&]subid=/i.test(e) && (i -= 80), /[?&]type=2(?:[&#]|$)/i.test(t) && (i -= 80), i;
}
function vu(n) {
  let t = "", e = Number.NEGATIVE_INFINITY;
  for (const i of n) {
    const s = bu(String(i || "").trim()), o = uy(s);
    o > e && (t = s, e = o);
  }
  return t;
}
function cy(n) {
  try {
    const t = new URL(n);
    return t.searchParams.delete("bytes"), t.toString();
  } catch {
    return n;
  }
}
function dy() {
  try {
    const t = performance.getEntriesByType("resource").map((e) => {
      const i = String(
        e?.name || ""
      ).trim();
      return /[?&]bytes=\d+-\d+/i.test(i) ? cy(i) : i;
    }).filter(
      (e) => /vkvd\d+\.okcdn\.ru|\.okcdn\.ru|vkvideo\.ru|vk\.(?:com|ru)/i.test(
        e
      )
    ).filter(Boolean);
    return vu(t);
  } catch {
    return "";
  }
}
async function wu(n, t) {
  try {
    const i = await fetch(n, {
      signal: t,
      credentials: "include"
    });
    if (i.ok) return i;
  } catch {
  }
  const e = await ut(n, {
    signal: t,
    timeout: 0
  });
  if (!e.ok)
    throw new Error(`[VOT] VK: failed to fetch media source: ${e.status}`);
  return e;
}
async function ua(n, t) {
  return await (await wu(n, t)).text();
}
async function ca(n, t) {
  const i = await (await wu(n, t)).arrayBuffer();
  return new Uint8Array(i);
}
function da(n, t) {
  return n.split(/\r?\n/).map((e) => e.trim()).filter((e) => e && !e.startsWith("#")).map((e) => ay(e, t));
}
async function hy(n, t) {
  const e = await ua(n, t), i = da(e, n), s = i.find((o) => oi(o));
  if (s) {
    const o = await ua(s, t);
    return da(o, s).filter(
      (r) => !oi(r)
    );
  }
  return i.filter((o) => !oi(o));
}
async function fy({
  videoId: n,
  signal: t,
  preferredVideo: e
}) {
  const i = ly(e).sort(
    (m, v) => ns(v, e) - ns(m, e)
  ), s = i[0];
  if (!(s instanceof HTMLVideoElement))
    throw new Error("[VOT] VK: video element not found");
  const o = mu(), r = dy(), a = ri(s), l = i.map((m) => ri(m)).filter((m) => m && !m.startsWith("blob:")), c = vu([
    o,
    r,
    ...l,
    a
  ]);
  if (C.log("[VOT] VK strategy currentSrc:", s.currentSrc), C.log("[VOT] VK strategy src:", s.src), C.log(
    "[VOT] VK strategy candidate videos:",
    i.map((m) => ({
      src: ri(m),
      visible: yu(m),
      paused: m.paused,
      readyState: m.readyState,
      score: ns(m, e)
    }))
  ), !c)
    throw new Error("[VOT] VK: empty video src");
  if (c.startsWith("blob:"))
    throw new Error(
      "[VOT] VK: blob source detected; need direct mp4/m3u8 URL from VK player/network"
    );
  const d = 256 * 1024;
  if (oi(c)) {
    const m = await hy(c, t);
    if (!m.length)
      throw new Error("[VOT] VK: empty m3u8 segment list");
    const v = `vk_hls_${Date.now()}`;
    return C.log("[VOT] VK strategy m3u8 segments:", m.length), {
      fileId: v,
      mediaPartsLength: m.length,
      async *getMediaBuffers() {
        for (const S of m) {
          const T = await ca(S, t);
          if (!T.byteLength)
            throw new Error("[VOT] VK: empty m3u8 segment");
          yield T;
        }
      }
    };
  }
  const h = await ca(c, t);
  if (!h.byteLength)
    throw new Error("[VOT] VK: empty media bytes");
  const f = Math.max(1, Math.ceil(h.byteLength / d)), g = ry(h.byteLength, d);
  return C.log("[VOT] VK strategy bytes:", h.byteLength), {
    fileId: g,
    mediaPartsLength: f,
    async *getMediaBuffers() {
      for (let m = 0; m < h.byteLength; m += d) {
        const v = Math.min(m + d, h.byteLength);
        yield h.subarray(m, v);
      }
    }
  };
}
function gy(n, t) {
  return `yadisk_${n}_${t}_${Date.now()}`;
}
async function my({
  videoId: n,
  signal: t
}) {
  const e = document.querySelector("video");
  if (!(e instanceof HTMLVideoElement))
    throw new Error("[VOT] Yandex Disk: video element not found");
  const i = e.currentSrc || e.src;
  if (!i)
    throw new Error("[VOT] Yandex Disk: empty video src");
  const s = await fetch(i, { signal: t });
  if (!s.ok)
    throw new Error(
      `[VOT] Yandex Disk: failed to fetch media source: ${s.status}`
    );
  C.log("[VOT] Yandex Disk strategy currentSrc:", e.currentSrc), C.log("[VOT] Yandex Disk strategy src:", e.src);
  const o = await s.arrayBuffer(), r = new Uint8Array(o);
  if (!r.byteLength)
    throw new Error("[VOT] Yandex Disk: empty audio/video bytes");
  const a = 256 * 1024, l = Math.max(1, Math.ceil(r.byteLength / a)), c = gy(r.byteLength, a);
  return C.log("[VOT] Yandex Disk strategy bytes:", r.byteLength), {
    fileId: c,
    mediaPartsLength: l,
    async *getMediaBuffers() {
      for (let d = 0; d < r.byteLength; d += a) {
        const h = Math.min(d + a, r.byteLength);
        yield r.subarray(d, h);
      }
    }
  };
}
const dn = "ytAudio", As = "vkAudio", py = {
  [dn]: Xp,
  [As]: fy,
  yandexDisk: my,
  localFile: Qp
};
function yy(n) {
  if (!Number.isInteger(n) || n < 1)
    throw new Error("Audio downloader. Invalid media parts length");
}
function ha(n) {
  if (!n || n.byteLength === 0)
    throw new Error("Audio downloader. Empty audio");
  return n;
}
async function by({
  audioDownloader: n,
  translationId: t,
  videoId: e,
  signal: i,
  preferredVideo: s
}) {
  const o = await py[n.strategy]({
    videoId: e,
    signal: i,
    preferredVideo: s
  });
  if (!o)
    throw new Error("Audio downloader. Can not get audio data");
  C.log("Audio downloader. Url found", {
    audioDownloadType: n.strategy
  });
  const { getMediaBuffers: r, mediaPartsLength: a, fileId: l } = o;
  if (yy(a), a < 2) {
    const d = r(), { value: h } = await d.next(), f = ha(h);
    await n.onDownloadedAudio.dispatchAsync(t, {
      videoId: e,
      fileId: l,
      audioData: f
    });
    return;
  }
  let c = 0;
  for await (const d of r()) {
    const h = ha(d);
    await n.onDownloadedPartialAudio.dispatchAsync(
      t,
      {
        videoId: e,
        fileId: l,
        audioData: h,
        version: 1,
        index: c,
        amount: a
      }
    ), c++;
  }
  if (c !== a)
    throw new Error(
      `Audio downloader. Expected ${a} chunks, got ${c}`
    );
}
class vy {
  constructor(t = dn) {
    u(this, "onDownloadedAudio", new z());
    u(this, "onDownloadedPartialAudio", new z());
    u(this, "onDownloadAudioError", new z());
    u(this, "strategy");
    this.strategy = t;
  }
  async runAudioDownload(t, e, i, s) {
    try {
      await by({
        audioDownloader: this,
        translationId: e,
        videoId: t,
        signal: i,
        preferredVideo: s
      }), C.log("Audio downloader. Audio download finished", {
        videoId: t
      });
    } catch (o) {
      C.error("Audio downloader. Failed to download audio", {
        videoId: t,
        error: o instanceof Error ? o.message : String(o)
      }), this.onDownloadAudioError.dispatch(t);
    }
  }
  addEventListener(t, e) {
    switch (t) {
      case "downloadedAudio":
        this.onDownloadedAudio.addListener(e);
        break;
      case "downloadedPartialAudio":
        this.onDownloadedPartialAudio.addListener(e);
        break;
      case "downloadAudioError":
        this.onDownloadAudioError.addListener(e);
        break;
    }
    return this;
  }
  removeEventListener(t, e) {
    switch (t) {
      case "downloadedAudio":
        this.onDownloadedAudio.removeListener(e);
        break;
      case "downloadedPartialAudio":
        this.onDownloadedPartialAudio.removeListener(e);
        break;
      case "downloadAudioError":
        this.onDownloadAudioError.removeListener(e);
        break;
    }
    return this;
  }
}
const wy = 0.66;
function fa(n, t) {
  let e = Math.floor(n / 60);
  if (Math.floor(n % 60) / 60 >= wy && (e += 1), e >= 60)
    return t("translationTakeMoreThanHour");
  if (e <= 1)
    return t("translationTakeAboutMinute");
  const o = String(e);
  return e !== 11 && e % 10 === 1 ? t("translationTakeApproximatelyMinute2").replace(
    "{0}",
    o
  ) : ![12, 13, 14].includes(e) && [2, 3, 4].includes(e % 10) ? t("translationTakeApproximatelyMinute").replace(
    "{0}",
    o
  ) : t("translationTakeApproximatelyMinutes").replace(
    "{0}",
    o
  );
}
class bt extends Error {
  constructor(e) {
    super(p.getDefault(e));
    u(this, "name", "VOTLocalizedError");
    /** Original (non-localized) message key. */
    u(this, "unlocalizedMessage");
    /** Resolved localized message. */
    u(this, "localizedMessage");
    this.unlocalizedMessage = e, this.localizedMessage = p.get(e);
  }
}
function go(n) {
  return n ?? null;
}
async function Sy(n, t) {
  const e = await n.translateVideoImpl(
    t.videoData,
    t.requestLang,
    t.responseLang,
    go(t.translationHelp),
    !t.useAudioDownload,
    t.signal
  );
  return e?.url ? {
    url: e.url,
    usedLivelyVoice: !!e.usedLivelyVoice
  } : null;
}
function Ty(n) {
  return {
    videoId: n.videoId,
    from: n.requestLang,
    to: n.responseLang,
    url: n.downloadTranslationUrl ?? n.fallbackUrl,
    useLivelyVoice: n.usedLivelyVoice
  };
}
async function Su(n) {
  return n.isActionStale(n.actionContext) || (await n.updateTranslation(n.url, n.actionContext), n.isActionStale(n.actionContext)) ? !1 : (n.scheduleTranslationRefresh(), !0);
}
async function ky(n) {
  const t = await Sy(n.requester, {
    videoData: n.request.videoData,
    requestLang: n.request.requestLang,
    responseLang: n.request.responseLang,
    translationHelp: n.request.translationHelp,
    useAudioDownload: n.request.useAudioDownload,
    signal: n.request.signal
  });
  return !t || !await Su({
    url: t.url,
    actionContext: n.actionContext,
    isActionStale: n.isActionStale,
    updateTranslation: n.updateTranslation,
    scheduleTranslationRefresh: n.scheduleTranslationRefresh
  }) || n.isActionStale(n.actionContext) ? null : t;
}
function Ly(n) {
  n.setTranslation(
    n.cacheKey,
    Ty({
      videoId: n.videoId,
      requestLang: n.requestLang,
      responseLang: n.responseLang,
      fallbackUrl: n.fallbackUrl,
      downloadTranslationUrl: n.downloadTranslationUrl,
      usedLivelyVoice: n.usedLivelyVoice
    })
  );
}
function xs(n) {
  return n.aborted || !n.translateApiErrorsEnabled || !n.hadAsyncWait ? n.hadAsyncWait : (n.notify({
    videoId: n.videoId,
    message: n.error
  }), !1);
}
function hn(n) {
  if (!n || typeof n != "object")
    return null;
  const t = n, e = t.data && typeof t.data == "object" ? t.data : void 0;
  return {
    name: t.name,
    message: t.message,
    data: e
  };
}
function tn(n) {
  const e = hn(n)?.data?.message;
  return typeof e == "string" && e.length > 0 ? e : void 0;
}
function ga(n, t) {
  const e = hn(n);
  if (!e || e.name !== "VOTJSError")
    return n;
  const i = typeof e.message == "string" ? e.message : "", s = typeof e.data?.message == "string" ? e.data.message : "";
  return console.log("[VOT][mapVotClientErrorForUi]", {
    siteHost: t,
    originalMessage: i,
    serverMessage: s,
    rawError: n
  }), i === "Audio link wasn't received" || i === "Audio link wasn't received from VOT response" ? new bt("audioNotReceived") : t === "yandexdisk" ? s ? new Error(s) : n : i === "Failed to request video translation" ? new bt("requestTranslationFailed") : i === "Yandex couldn't translate video" ? new bt("requestTranslationFailed") : n;
}
class Ay {
  constructor(t) {
    u(this, "videoHandler");
    u(this, "audioDownloader");
    u(this, "downloading");
    u(this, "downloadWaiters", /* @__PURE__ */ new Set());
    u(this, "requestedFailAudio", /* @__PURE__ */ new Set());
    u(this, "activeTranslationUrl");
    u(this, "activeYandexDiskResolvedVideoData");
    u(this, "onDownloadedAudio", async (t, e) => {
      if (!this.downloading)
        return;
      const { videoId: i, fileId: s, audioData: o } = e, r = this.getCanonicalUrl(i);
      try {
        console.log("[VOT] Uploading full audio", {
          translationId: t,
          videoId: i,
          fileId: s,
          size: o.byteLength,
          videoUrl: r
        }), await this.videoHandler.votClient.requestVtransAudio(
          r,
          t,
          {
            audioFile: o,
            fileId: s
          }
        );
      } catch (a) {
        console.log("[VOT] Upload full audio failed", {
          message: ce(a),
          serverMessage: tn(a),
          error: hn(a)
        }), this.finishDownloadFailure(
          new Error("Audio downloader failed while uploading full audio")
        );
        return;
      }
      this.finishDownloadSuccess();
    });
    u(this, "onDownloadedPartialAudio", async (t, e) => {
      if (!this.downloading)
        return;
      const { audioData: i, fileId: s, videoId: o, amount: r, version: a, index: l } = e, c = this.getCanonicalUrl(o);
      try {
        console.log("[VOT] Uploading audio chunk", {
          translationId: t,
          videoId: o,
          fileId: s,
          index: l,
          amount: r,
          size: i.byteLength,
          videoUrl: c
        }), await this.videoHandler.votClient.requestVtransAudio(
          c,
          t,
          {
            audioFile: i,
            chunkId: l
          },
          {
            audioPartsLength: r,
            fileId: s,
            version: a
          }
        );
      } catch (d) {
        console.log("[VOT] Upload audio chunk failed", {
          message: ce(d),
          serverMessage: tn(d),
          error: hn(d),
          index: l,
          amount: r,
          size: i.byteLength
        }), this.finishDownloadFailure(
          new Error("Audio downloader failed while uploading chunk")
        );
        return;
      }
      l === r - 1 && this.finishDownloadSuccess();
    });
    u(this, "onDownloadAudioError", async (t) => {
      if (!this.downloading)
        return;
      const e = this.getCanonicalUrl(t), i = this.videoHandler.site.host === "youtube" && !!this.videoHandler.data?.useAudioDownload;
      if (console.log("[VOT] downloadAudioError host:", this.videoHandler.site.host), console.log(
        "[VOT] downloadAudioError strategy:",
        this.audioDownloader.strategy
      ), !i) {
        this.finishDownloadFailure(
          new bt("VOTFailedDownloadAudio")
        );
        return;
      }
      try {
        this.requestedFailAudio.has(e) ? C.log("fail-audio-js request already sent for this video") : (C.log("Sending fail-audio-js request"), await this.videoHandler.votClient.requestVtransFailAudio(e), this.requestedFailAudio.add(e)), this.finishDownloadSuccess();
      } catch {
        this.finishDownloadFailure(
          new bt("VOTFailedDownloadAudio")
        );
      }
    });
    this.videoHandler = t;
    const e = this.videoHandler.site.host === "vk" ? As : this.videoHandler.site.host === "youtube" ? dn : this.videoHandler.site.host === "yandexdisk" ? "yandexDisk" : this.videoHandler.site.host === "custom" ? "localFile" : dn;
    this.audioDownloader = new vy(e), this.downloading = !1, this.audioDownloader.addEventListener("downloadedAudio", this.onDownloadedAudio).addEventListener("downloadedPartialAudio", this.onDownloadedPartialAudio).addEventListener("downloadAudioError", this.onDownloadAudioError);
  }
  normalizeUrlForRequest(t) {
    try {
      return new URL(t, globalThis.location.href).toString();
    } catch {
      return String(t || "");
    }
  }
  normalizeOdyseeDirectUrl(t) {
    try {
      if (!t)
        return t;
      const e = t.match(
        /^https:\/\/player\.odycdn\.com\/api\/v3\/streams\/free\/[^/]+\/([a-f0-9]+)\/([^/?#]+\.mp4)(?:[?#].*)?$/i
      );
      if (e) {
        const i = e[1], s = e[2];
        return `https://player.odycdn.com/v6/streams/${i}/${s}`;
      }
    } catch {
    }
    return t;
  }
  getCurrentMediaRequestUrl(t) {
    return this.normalizeUrlForRequest(
      String(
        t?.url || this.videoHandler.video?.currentSrc || this.videoHandler.video?.src || globalThis.location.href
      )
    );
  }
  isHlsManifestUrl(t) {
    return /\.m3u8(?:[?#]|$)/i.test(String(t || ""));
  }
  isCustomLinkUrl(t) {
    if (!t)
      return !1;
    try {
      return this.videoHandler.votClient.isCustomLink(t);
    } catch {
      return /\.(m3u8|m4(?:a|v)|mpd)(?:[?#]|$)/i.test(t) || /^https:\/\/cdn\.qstv\.on\.epicgames\.com/i.test(t);
    }
  }
  shouldUseCustomLinkWorkflow(t) {
    return !t || this.videoHandler.site.host !== "custom" && t.host !== "custom" ? !1 : this.isCustomLinkUrl(this.getCurrentMediaRequestUrl(t));
  }
  getM3u8ProxyEndpointUrl() {
    const t = String(this.videoHandler.data?.m3u8ProxyHost || "").trim();
    if (!t)
      return null;
    const e = /^[a-z][a-z\d+.-]*:/i.test(t) ? t : `https://${t}`;
    try {
      const i = new URL(e), s = i.pathname && i.pathname !== "/" ? i.pathname.replace(/\/+$/g, "") : "/v1/proxy/m3u8";
      return new URL(`${i.origin}${s}`);
    } catch (i) {
      return console.log("[VOT][upload] invalid m3u8 proxy host", {
        rawHost: t,
        error: i
      }), null;
    }
  }
  buildProxiedHlsUrl(t) {
    const e = this.normalizeUrlForRequest(t), i = this.getM3u8ProxyEndpointUrl();
    if (!i)
      return e;
    try {
      const s = new URL(e, globalThis.location.href), o = new URL(i.toString());
      return o.searchParams.set("format", "base64"), o.searchParams.set("force", "true"), o.searchParams.set("all", "1"), o.searchParams.set("url", btoa(s.toString())), s.origin && s.origin !== "null" && (o.searchParams.set("origin", s.origin), o.searchParams.set("referer", s.origin)), o.hash = "playlist.m3u8", o.toString();
    } catch (s) {
      return console.log("[VOT][upload] failed to build proxied hls url", {
        rawUrl: t,
        error: s
      }), e;
    }
  }
  buildCustomLinkWorkflowVideoData(t) {
    const e = this.getCurrentMediaRequestUrl(t), i = this.isHlsManifestUrl(e) ? this.buildProxiedHlsUrl(e) : e, s = typeof t.videoId == "string" && t.videoId.trim().length > 0 ? t.videoId : e;
    return console.log("[VOT][upload] custom-link workflow input", {
      originalUrl: e,
      requestUrl: i,
      host: t.host,
      proxied: i !== e,
      proxyHost: this.videoHandler.data?.m3u8ProxyHost
    }), {
      ...t,
      url: i,
      videoId: s
    };
  }
  isDirectMediaUrlCandidate(t) {
    if (!t || this.isHlsManifestUrl(t))
      return !1;
    try {
      return this.videoHandler.votClient.isDirectMediaUrl(t);
    } catch {
      return !1;
    }
  }
  isCrossOriginMediaUrl(t) {
    try {
      return new URL(t, globalThis.location.href).hostname !== globalThis.location.hostname;
    } catch {
      return !1;
    }
  }
  shouldUseLocalFileWorkflow(t) {
    if (!t)
      return !1;
    const e = this.getCurrentMediaRequestUrl(t);
    return this.isDirectMediaUrlCandidate(e) ? this.videoHandler.site.host === "custom" || t.host === "custom" ? !0 : this.isCrossOriginMediaUrl(e) : !1;
  }
  buildLocalFileWorkflowVideoData(t) {
    let e = this.getCurrentMediaRequestUrl(t);
    (this.videoHandler.site.host === "odysee" || t.host === "odysee") && (e = this.normalizeUrlForRequest(this.normalizeOdyseeDirectUrl(e)));
    const i = typeof t.videoId == "string" && t.videoId.trim().length > 0 ? t.videoId : e;
    return {
      ...t,
      host: "custom",
      url: e,
      videoId: i
    };
  }
  updateAudioDownloaderStrategy(t) {
    const e = t ? this.getCurrentMediaRequestUrl(t) : "", s = (this.videoHandler.site.host === "custom" || t?.host === "custom") && !this.isHlsManifestUrl(e) && this.isDirectMediaUrlCandidate(e) || this.shouldUseLocalFileWorkflow(t), o = this.videoHandler.site.host === "vk" || this.videoHandler.site.host === "okru" || /^player\.cdnvideohub\.com$/i.test(globalThis.location.hostname) || /(?:^|\.)okcdn\.ru$/i.test(globalThis.location.hostname) || /(?:^|\.)okcdn\.ru/i.test(e), r = s ? "localFile" : o ? As : this.videoHandler.site.host === "yandexdisk" ? "yandexDisk" : dn;
    this.audioDownloader.strategy !== r && (this.audioDownloader.strategy = r, console.log("[VOT][audio] switched downloader strategy", {
      siteHost: this.videoHandler.site.host,
      videoHost: t?.host,
      strategy: r,
      url: t?.url
    }));
  }
  isDirectResolvedUploadVideoData(t) {
    if (!t)
      return !1;
    const e = String(t.url || "");
    if (!e.length || this.isYandexDiskDownloadUrl(e))
      return !1;
    if (t.host === "yandexdisk")
      return !0;
    if (t.host === "custom")
      try {
        return this.videoHandler.votClient.isDirectMediaUrl(e);
      } catch {
        return !1;
      }
    return !1;
  }
  parseYandexDiskUrl(t) {
    const e = String(t || globalThis.location.href || "");
    try {
      const i = new URL(e, globalThis.location.href), s = i.pathname || "/", o = s.match(/^\/i\/([^/]+)$/i);
      if (o)
        return {
          mode: "file",
          origin: i.origin,
          pathname: s,
          fileId: o[1]
        };
      const r = s.match(/^\/d\/([^/]+)\/?$/i);
      if (r)
        return {
          mode: "folderRoot",
          origin: i.origin,
          pathname: s,
          folderId: r[1]
        };
      const a = s.match(/^\/d\/([^/]+)\/.+$/i);
      return a ? {
        mode: "folderFile",
        origin: i.origin,
        pathname: s,
        folderId: a[1]
      } : {
        mode: "unknown",
        origin: i.origin,
        pathname: s
      };
    } catch {
      return {
        mode: "unknown",
        origin: globalThis.location.origin,
        pathname: e.split("?")[0].split("#")[0]
      };
    }
  }
  normalizeYandexDiskPublicUrl(t) {
    const e = this.parseYandexDiskUrl(t);
    return e.mode === "file" && e.fileId ? `${e.origin}/i/${e.fileId}` : e.mode === "folderRoot" || e.mode === "folderFile" ? `${e.origin}${e.pathname}` : String(t || globalThis.location.href || "").split("?")[0].split("#")[0];
  }
  extractYandexDiskPublicTarget(t) {
    try {
      const i = new URL(t, globalThis.location.href).pathname || "/", s = "https://disk.yandex.com", o = i.match(/^\/i\/([^/?#]+)$/i);
      if (o)
        return {
          url: `${s}/i/${o[1]}`,
          videoId: `/i/${o[1]}`
        };
      const r = i.match(/^\/d\/([^/?#]+)\/?$/i);
      return r ? {
        url: `${s}/d/${r[1]}`,
        videoId: `/d/${r[1]}`
      } : null;
    } catch {
      return null;
    }
  }
  extractYandexDiskPublicTargetFromMedia() {
    const t = (o) => this.extractYandexDiskPublicTarget(String(o || "")), e = String(globalThis.location.href || ""), i = this.parseYandexDiskUrl(e);
    if (i.mode === "file" && i.fileId)
      return {
        url: `${i.origin}/i/${i.fileId}`,
        videoId: i.fileId
      };
    const s = Array.from(document.querySelectorAll("video"));
    for (const o of s) {
      const r = o, a = [
        r.currentSrc || "",
        r.src || "",
        r.getAttribute("src") || ""
      ];
      for (const c of a) {
        const d = t(c);
        if (d)
          return d;
      }
      const l = Array.from(o.querySelectorAll("source"));
      for (const c of l) {
        const d = t(c.getAttribute("src") || "");
        if (d)
          return d;
      }
    }
    return null;
  }
  isYandexDiskFolderRootTarget(t, e) {
    if (!e.folderId)
      return !1;
    const i = `${e.origin}/d/${e.folderId}`;
    return t.videoId === e.folderId || t.url === i;
  }
  async gmGetJson(t) {
    return new Promise((e, i) => {
      GM_xmlhttpRequest({
        method: "GET",
        url: t,
        headers: {
          Accept: "application/json"
        },
        onload: (s) => {
          try {
            console.log("[VOT][yandexdisk] GM response", {
              url: t,
              status: s.status,
              responseText: String(s.responseText || "").slice(0, 1e3)
            }), e(JSON.parse(s.responseText || "null"));
          } catch (o) {
            i(o);
          }
        },
        onerror: (s) => i(s),
        ontimeout: () => i(new Error("Yandex Disk public API timeout"))
      });
    });
  }
  getYandexDiskServiceVideoId(t, e) {
    try {
      const s = new URL(t, globalThis.location.href).pathname || "";
      if (/^\/i\/[^/]+$/i.test(s) || /^\/d\/.+$/i.test(s))
        return s;
    } catch {
    }
    return e || String(t || "");
  }
  extractBridgeDirectMediaTarget() {
    try {
      const t = globalThis.__VOT_DIRECT_SOURCES__ || JSON.parse(
        document?.documentElement?.dataset?.votDirectSources || "null"
      );
      if (!t || typeof t != "object")
        return null;
      const e = t, i = [
        e.hlsUrl,
        e.dashUrl,
        e.mpegLowUrl,
        e.url
      ].filter((s) => !!s);
      for (const s of i) {
        const o = this.normalizeUrlForRequest(s);
        if (o)
          try {
            if (this.videoHandler.votClient.isDirectMediaUrl(o))
              return {
                url: o,
                videoId: String(e.unitedVideoId || o),
                host: "custom",
                title: e.title || ""
              };
          } catch {
          }
      }
    } catch {
    }
    return null;
  }
  extractDirectMediaTargetFromVideo() {
    const t = document.querySelector("video");
    if (!(t instanceof HTMLVideoElement))
      return null;
    const e = [
      t.currentSrc || "",
      t.src || "",
      t.getAttribute("src") || ""
    ];
    for (const i of e) {
      const s = this.normalizeUrlForRequest(i);
      if (s)
        try {
          if (this.videoHandler.votClient.isDirectMediaUrl(s))
            return {
              url: s,
              videoId: s,
              host: "custom"
            };
        } catch {
        }
    }
    return null;
  }
  extractOdyseeMetaMediaTarget() {
    try {
      if (!/odysee\.com$/i.test(location.hostname))
        return null;
      const t = Array.from(
        document.querySelectorAll('script[type="application/ld+json"]')
      );
      for (const e of t) {
        const i = e.textContent || "";
        if (!i.includes('"contentUrl"'))
          continue;
        const s = JSON.parse(i), o = s?.contentUrl;
        if (typeof o == "string" && o) {
          const r = this.normalizeUrlForRequest(o);
          return {
            url: r,
            videoId: r,
            host: "custom",
            title: s?.name || document.title || ""
          };
        }
      }
    } catch {
    }
    return null;
  }
  async resolveYandexDiskFolderFileTargetViaApi(t) {
    if (t.mode !== "folderFile" || !t.folderId)
      return null;
    const e = t.pathname.replace(/^\/d\/[^/]+/, "") || "/";
    let i = e;
    try {
      i = decodeURIComponent(e);
    } catch {
      i = e;
    }
    const s = `${t.origin}/d/${t.folderId}`, o = new URL(
      "https://cloud-api.yandex.com/v1/disk/public/resources"
    );
    o.searchParams.set("public_key", s), o.searchParams.set("path", i);
    try {
      const r = await this.gmGetJson(o.toString());
      if (console.log("[VOT][yandexdisk] public API payload", {
        relativePathRaw: e,
        relativePath: i,
        publicKey: s,
        type: r?.type,
        path: r?.path,
        name: r?.name,
        public_url: r?.public_url,
        short_url: r?.short_url,
        file: r?.file
      }), !r || typeof r != "object")
        return null;
      if ("error" in r && r.error)
        return console.log("[VOT][yandexdisk] public API returned error", {
          error: r.error,
          message: r.message,
          description: r.description
        }), null;
      const a = [r.public_url, r.short_url].filter(
        (l) => typeof l == "string" && l.length > 0
      );
      for (const l of a) {
        const c = this.extractYandexDiskPublicTarget(l);
        if (!c)
          continue;
        if (this.isYandexDiskFolderRootTarget(c, t)) {
          console.log("[VOT][yandexdisk] skip folder-root target from API", {
            target: c,
            relativePath: i
          });
          continue;
        }
        const d = this.getYandexDiskServiceVideoId(
          c.url,
          t.pathname
        );
        return console.log("[VOT][yandexdisk] public target from API", {
          target: c,
          candidate: l,
          relativePath: i,
          serviceVideoId: d
        }), {
          url: c.url,
          videoId: d
        };
      }
      if (r.type === "file" && typeof r.file == "string" && r.file) {
        const l = this.normalizeUrlForRequest(r.file);
        return console.log("[VOT][yandexdisk] use direct file url from API", {
          directUrl: l,
          relativePath: i
        }), {
          url: l,
          videoId: l,
          host: "custom"
        };
      }
      if (r.type === "file")
        return console.log(
          "[VOT][yandexdisk] API did not return usable public target, continue fallback chain",
          {
            public_url: r.public_url,
            short_url: r.short_url,
            file: r.file,
            relativePath: i
          }
        ), null;
    } catch (r) {
      console.log("[VOT][yandexdisk] failed to resolve public target via API", {
        relativePathRaw: e,
        relativePath: i,
        publicKey: s,
        error: r
      });
    }
    return null;
  }
  isYandexDiskDownloadUrl(t) {
    try {
      return new URL(t, globalThis.location.href).hostname === "downloader.disk.yandex.ru";
    } catch {
      return !1;
    }
  }
  isYandexDiskStreamUrl(t) {
    return /^https:\/\/streaming\.disk\.yandex\.net\/.+\.m3u8(?:[?#].*)?$/i.test(
      String(t || "")
    );
  }
  extractYandexDiskStreamTargetFromPlayerState() {
    const t = (o) => {
      if (typeof o != "string")
        return null;
      const r = this.normalizeUrlForRequest(o);
      return this.isYandexDiskStreamUrl(r) ? r : null;
    }, e = /* @__PURE__ */ new WeakSet(), i = (o, r) => {
      if (r < 0)
        return null;
      const a = t(o);
      if (a)
        return a;
      if (!o || typeof o != "object")
        return null;
      const l = o;
      if (e.has(l))
        return null;
      e.add(l);
      const c = [
        "streamUrl",
        "url",
        "stream",
        "streams",
        "source",
        "sources",
        "controller",
        "state",
        "playerState",
        "playerApiState",
        "internalInitialConfig",
        "config",
        "store",
        "redux"
      ];
      for (const h of c) {
        if (!(h in l))
          continue;
        const f = i(l[h], r - 1);
        if (f)
          return f;
      }
      const d = Array.isArray(l) ? l : Object.keys(l).slice(0, 50).map((h) => l[h]);
      for (const h of d) {
        const f = i(h, r - 1);
        if (f)
          return f;
      }
      return null;
    }, s = globalThis;
    for (const o of Object.keys(s)) {
      if (!/player|state|store|redux|disk|video|ya|vh/i.test(o))
        continue;
      const r = i(s[o], 6);
      if (r)
        return console.log("[VOT][yandexdisk] use stream url from deep player state", {
          key: o,
          url: r
        }), {
          url: r,
          videoId: r,
          host: "yandexdisk"
        };
    }
    return null;
  }
  extractYandexDiskStreamTargetFromPerformance() {
    try {
      const t = performance.getEntriesByType("resource");
      console.log("[VOT][yandexdisk] inspect performance resources", {
        count: t.length
      });
      for (let e = t.length - 1; e >= 0; e -= 1) {
        const i = t[e], s = String(i?.name || ""), o = this.normalizeUrlForRequest(s);
        if (this.isYandexDiskStreamUrl(o))
          return console.log("[VOT][yandexdisk] use stream url from performance", {
            url: o
          }), {
            url: o,
            videoId: o,
            host: "yandexdisk"
          };
      }
    } catch (t) {
      console.log("[VOT][yandexdisk] failed to inspect performance resources", {
        error: t
      });
    }
    return null;
  }
  async buildYandexDiskVideoData(t) {
    const e = this.extractBridgeDirectMediaTarget();
    if (e)
      return {
        ...t,
        ...e,
        host: "custom"
      };
    const i = this.extractOdyseeMetaMediaTarget();
    if (i)
      return {
        ...t,
        ...i,
        host: "custom"
      };
    const s = this.getYandexDiskSourceUrl(t), o = this.parseYandexDiskUrl(s);
    if (console.log("[VOT][yandexdisk] build source", {
      pageUrl: globalThis.location.href,
      videoDataUrl: t.url,
      sourceUrl: s,
      parsedMode: o.mode,
      videoId: t.videoId
    }), o.mode === "file" && o.fileId) {
      const c = `${o.origin}/i/${o.fileId}`;
      return {
        ...t,
        url: c,
        videoId: this.getYandexDiskServiceVideoId(c, o.pathname),
        host: "yandexdisk"
      };
    }
    if (o.mode === "folderFile") {
      const c = await this.resolveYandexDiskFolderFileTargetViaApi(o);
      if (c) {
        const f = this.normalizeUrlForRequest(c.url), g = c.host === "custom" ? f : this.getYandexDiskServiceVideoId(f, o.pathname);
        return console.log("[VOT][yandexdisk] resolved folder file target", {
          sourceUrl: s,
          resolvedUrl: f,
          videoId: g,
          host: c.host ?? "yandexdisk"
        }), {
          ...t,
          url: f,
          videoId: g,
          host: c.host ?? "yandexdisk"
        };
      }
      const d = this.extractYandexDiskStreamTargetFromPlayerState();
      if (d)
        return {
          ...t,
          url: d.url,
          videoId: d.videoId,
          host: "yandexdisk"
        };
      const h = this.extractYandexDiskStreamTargetFromPerformance();
      if (h)
        return {
          ...t,
          url: h.url,
          videoId: h.videoId,
          host: "yandexdisk"
        };
    }
    const r = this.extractYandexDiskPublicTarget(s);
    if (r)
      return {
        ...t,
        url: r.url,
        videoId: this.getYandexDiskServiceVideoId(
          r.url,
          o.pathname
        ),
        host: "yandexdisk"
      };
    const a = this.extractYandexDiskPublicTargetFromMedia();
    if (a)
      return {
        ...t,
        url: a.url,
        videoId: this.getYandexDiskServiceVideoId(
          a.url,
          o.pathname
        ),
        host: "yandexdisk"
      };
    const l = this.extractDirectMediaTargetFromVideo();
    if (l)
      return {
        ...t,
        url: l.url,
        videoId: l.videoId,
        host: "custom"
      };
    throw new Error("Failed to build Yandex Disk translation target");
  }
  finishDownloadSuccess() {
    this.downloading = !1, this.resolveDownloadWaiters();
  }
  finishDownloadFailure(t) {
    this.downloading = !1, this.rejectDownloadWaiters(t);
  }
  getCanonicalUrl(t) {
    return this.shouldUseLocalFileWorkflow(this.videoHandler.videoData) ? this.activeTranslationUrl || this.getCurrentMediaRequestUrl(this.videoHandler.videoData) : this.videoHandler.site.host === "youtube" ? `https://youtu.be/${t}` : this.videoHandler.site.host === "yandexdisk" ? this.activeTranslationUrl || this.normalizeYandexDiskPublicUrl(
      this.videoHandler.videoData?.url || globalThis.location.href
    ) : this.videoHandler.site.host === "custom" ? this.activeTranslationUrl || this.normalizeUrlForRequest(
      String(this.videoHandler.videoData?.url || globalThis.location.href)
    ) : this.videoHandler.videoData?.url || globalThis.location.href;
  }
  isLivelyVoiceUnavailableError(t) {
    const e = ce(t);
    return !!e && e.toLowerCase().includes("обычная озвучка");
  }
  scheduleRetry(t, e, i) {
    return new Promise((s, o) => {
      let r = null;
      const a = () => {
        r !== null && clearTimeout(r), i.removeEventListener("abort", l);
      }, l = () => {
        a(), o(ye());
      };
      if (i.addEventListener("abort", l, { once: !0 }), i.aborted) {
        l();
        return;
      }
      r = setTimeout(async () => {
        if (i.aborted) {
          l();
          return;
        }
        a();
        try {
          const c = await t();
          s(c);
        } catch (c) {
          o(c);
        }
      }, e), r !== null && (this.videoHandler.autoRetry = r);
    });
  }
  async translateVideoYDImpl(t, e, i, s = null, o = Ts, r = !1) {
    let a;
    this.updateAudioDownloaderStrategy(t), (this.videoHandler.site.host === "okru" || t.host === "okru") && t.host !== "custom" && (t = {
      ...t,
      host: "custom"
    });
    const l = this.getCurrentMediaRequestUrl(t), c = !this.isHlsManifestUrl(l) && (this.videoHandler.site.host === "custom" || t.host === "custom" || this.shouldUseLocalFileWorkflow(t)), d = !c && this.shouldUseCustomLinkWorkflow(t);
    if (c)
      a = this.buildLocalFileWorkflowVideoData(t);
    else if (d)
      a = this.buildCustomLinkWorkflowVideoData(t);
    else {
      const h = this.activeYandexDiskResolvedVideoData && this.isDirectResolvedUploadVideoData(
        this.activeYandexDiskResolvedVideoData
      ) ? this.activeYandexDiskResolvedVideoData : void 0, f = this.isDirectResolvedUploadVideoData(t) ? t : void 0, g = h || f || await this.buildYandexDiskVideoData(t);
      a = {
        ...g,
        url: this.normalizeUrlForRequest(String(g.url || ""))
      };
    }
    if (a.host === "odysee" && typeof a.url == "string") {
      const h = this.normalizeOdyseeDirectUrl(
        a.url
      );
      a = h !== a.url ? {
        ...a,
        url: h,
        host: "custom"
      } : {
        ...a,
        url: this.normalizeUrlForRequest(a.url)
      };
    }
    a && typeof a.url == "string" && a.url && !/\/frame\/?$/i.test(a.url) && !/blob:/i.test(a.url) && (this.activeYandexDiskResolvedVideoData = a), this.activeTranslationUrl = a.url, console.log("[VOT][upload] translateVideoYDImpl input", {
      host: a.host,
      url: a.url,
      videoId: a.videoId
    });
    try {
      Ji(o);
      const h = !r && this.videoHandler.isLivelyVoiceAllowed(e, i) && !!this.videoHandler.data?.useLivelyVoice, f = await this.videoHandler.votClient.translateVideo({
        videoData: a,
        requestLang: e,
        responseLang: i,
        translationHelp: s,
        extraOpts: {
          useLivelyVoice: h,
          videoTitle: this.videoHandler.videoData?.title
        },
        shouldSendFailedAudio: !0
      });
      if (!f)
        throw new Error("Failed to get translation response");
      if (console.log("[VOT][upload] translate response", {
        translated: f.translated,
        status: f.status,
        remainingTime: f.remainingTime,
        message: f.message
      }), f.translated && (f.status === ft.FINISHED || f.status === ft.PART_CONTENT) && typeof f.url == "string" && f.url.length > 0)
        return { ...f, usedLivelyVoice: h };
      const g = f.message ?? p.get("translationTakeFewMinutes");
      if (await this.videoHandler.updateTranslationErrorMsg(
        f.remainingTime > 0 ? fa(
          f.remainingTime,
          (m) => p.get(m)
        ) : g,
        o
      ), f.status === ft.AUDIO_REQUESTED && this.videoHandler.canUploadAudioForCurrentSite())
        return this.videoHandler.hadAsyncWait = !0, this.downloading = !0, await this.audioDownloader.runAudioDownload(
          a.videoId,
          f.translationId,
          o,
          this.videoHandler.video
        ), await this.waitForAudioDownloadCompletion(o, 12e4), await this.translateVideoYDImpl(
          a,
          e,
          i,
          s,
          o,
          r || !h
        );
      if (f.status === ft.WAITING || f.status === ft.LONG_WAITING) {
        this.videoHandler.hadAsyncWait = !0;
        const m = a.host === "custom" ? 15e3 : 5e3;
        return this.scheduleRetry(
          () => this.translateVideoYDImpl(
            a,
            e,
            i,
            s,
            o,
            r || !h
          ),
          m,
          o
        );
      }
      throw new Error(
        typeof f.message == "string" && f.message ? f.message : "Yandex couldn't translate video"
      );
    } catch (h) {
      if (kn(h))
        return null;
      const f = ga(h, this.videoHandler.site.host);
      return await this.videoHandler.updateTranslationErrorMsg(
        tn(f) ?? f,
        o
      ), this.videoHandler.hadAsyncWait = xs({
        aborted: !!this.videoHandler.actionsAbortController?.signal?.aborted,
        translateApiErrorsEnabled: !!this.videoHandler.data?.translateAPIErrors,
        hadAsyncWait: this.videoHandler.hadAsyncWait,
        videoId: a.videoId,
        error: h,
        notify: (g) => this.videoHandler.notifier.translationFailed(g)
      }), console.error("[VOT][upload]", h), null;
    }
  }
  async translateVideoImpl(t, e, i, s = null, o = !1, r = Ts, a = !1) {
    clearTimeout(this.videoHandler.autoRetry), this.finishDownloadSuccess();
    const l = this.videoHandler.getRequestLangForTranslation(
      e,
      i
    );
    let c = a;
    const d = this.shouldUseLocalFileWorkflow(t);
    if (this.updateAudioDownloaderStrategy(t), this.videoHandler.site.host === "yandexdisk" || this.videoHandler.site.host === "custom" || t.host === "custom" || d)
      return await this.translateVideoYDImpl(
        t,
        l,
        i,
        s,
        r
      );
    let h = t;
    if (this.videoHandler.site.host === "odysee" && typeof t.url == "string") {
      const f = this.normalizeUrlForRequest(t.url), g = this.normalizeOdyseeDirectUrl(f);
      h = g !== f ? {
        ...t,
        url: g,
        host: "custom"
      } : {
        ...t,
        url: f
      };
    }
    this.shouldUseCustomLinkWorkflow(h) && (h = this.buildCustomLinkWorkflowVideoData(h)), this.activeTranslationUrl = this.videoHandler.site.host === "odysee" ? h.url : this.getCanonicalUrl(t.videoId);
    try {
      Ji(r);
      const f = this.videoHandler.isLivelyVoiceAllowed(
        l,
        i
      );
      let g = !c && f && !!this.videoHandler.data?.useLivelyVoice, m;
      for (let S = 0; S < 2; S++) {
        try {
          m = await this.videoHandler.votClient.translateVideo({
            videoData: h,
            requestLang: l,
            responseLang: i,
            translationHelp: s,
            extraOpts: {
              useLivelyVoice: g,
              videoTitle: this.videoHandler.videoData?.title
            },
            shouldSendFailedAudio: o
          }), console.log("[VOT][translate] translate response", {
            translated: m.translated,
            status: m.status,
            remainingTime: m.remainingTime,
            message: m.message,
            requestHost: h.host,
            requestUrl: h.url
          });
        } catch (T) {
          if (g && this.isLivelyVoiceUnavailableError(T)) {
            C.log(
              "[translateVideoImpl] Lively voices are unavailable. Falling back to standard translation.",
              T
            ), c = !0, g = !1;
            continue;
          }
          throw T;
        }
        if (g && this.isLivelyVoiceUnavailableError(m)) {
          C.log(
            "[translateVideoImpl] Server responded that lively voices are unavailable. Falling back to standard translation.",
            m
          ), c = !0, g = !1, m = void 0;
          continue;
        }
        break;
      }
      if (!m)
        throw new Error("Failed to get translation response");
      if (C.log("Translate video result", m), console.log("[VOT] host:", this.videoHandler.site.host), console.log("[VOT] status:", m.status), console.log("[VOT] translated:", m.translated), console.log("[VOT] remainingTime:", m.remainingTime), console.log("[VOT] translationId:", m.translationId), console.log(
        "[VOT] canUploadAudio:",
        this.videoHandler.canUploadAudioForCurrentSite()
      ), console.log("[VOT] downloader strategy:", this.audioDownloader.strategy), this.videoHandler.site.host === "vk" && this.videoHandler.canUploadAudioForCurrentSite() && m.translationId && t.videoId) {
        C.log("[VOT][VK subtitles] force audio upload", {
          videoId: t.videoId,
          translationId: m.translationId,
          strategy: this.audioDownloader.strategy
        });
        try {
          this.downloading = !0, this.audioDownloader.runAudioDownload(
            t.videoId,
            String(m.translationId),
            r,
            this.videoHandler.video
          ), await this.waitForAudioDownloadCompletion(r, 15e3);
        } catch (S) {
          C.log(
            "[VOT][VK subtitles] force audio upload failed after successful translation",
            {
              videoId: t.videoId,
              translationId: m.translationId,
              message: ce(S),
              serverMessage: tn(S),
              error: hn(S)
            }
          );
        }
      }
      if (Ji(r), m.translated && m.remainingTime < 1)
        return C.log("Video translation finished with this data: ", m), { ...m, usedLivelyVoice: g };
      const v = m.message ?? p.get("translationTakeFewMinutes");
      if (await this.videoHandler.updateTranslationErrorMsg(
        m.remainingTime > 0 ? fa(
          m.remainingTime,
          (S) => p.get(S)
        ) : v,
        r
      ), m.status === ft.AUDIO_REQUESTED && this.videoHandler.canUploadAudioForCurrentSite())
        return this.videoHandler.hadAsyncWait = !0, C.log("Start audio download"), this.downloading = !0, await this.audioDownloader.runAudioDownload(
          t.videoId,
          m.translationId,
          r,
          this.videoHandler.video
        ), C.log("waiting downloading finish"), await this.waitForAudioDownloadCompletion(
          r,
          this.audioDownloader.strategy === "yandexDisk" ? 12e4 : 15e3
        ), await this.translateVideoImpl(
          t,
          e,
          i,
          s,
          !0,
          r,
          c
        );
    } catch (f) {
      if (kn(f))
        return null;
      const g = ga(f, this.videoHandler.site.host);
      return await this.videoHandler.updateTranslationErrorMsg(
        tn(g) ?? g,
        r
      ), this.videoHandler.hadAsyncWait = xs({
        aborted: !!this.videoHandler.actionsAbortController?.signal?.aborted,
        translateApiErrorsEnabled: !!this.videoHandler.data?.translateAPIErrors,
        hadAsyncWait: this.videoHandler.hadAsyncWait,
        videoId: t.videoId,
        error: f,
        notify: (m) => this.videoHandler.notifier.translationFailed(m)
      }), console.error("[VOT]", f), null;
    }
    return this.videoHandler.hadAsyncWait = !0, this.scheduleRetry(
      () => this.translateVideoImpl(
        t,
        e,
        i,
        s,
        o,
        r,
        c
      ),
      2e4,
      r
    );
  }
  getYandexDiskSourceUrl(t) {
    const e = String(t.url || "");
    if (e && (this.isYandexDiskStreamUrl(e) || !this.isYandexDiskDownloadUrl(e) && this.parseYandexDiskUrl(e).mode !== "unknown"))
      return e;
    const i = String(globalThis.location.href || "");
    return this.parseYandexDiskUrl(i).mode !== "unknown" ? i : e || i;
  }
  waitForAudioDownloadCompletion(t, e) {
    return this.downloading ? new Promise((i, s) => {
      let o;
      const r = () => {
        l(), s(ye());
      }, a = setTimeout(() => {
        l(), s(new Error("Audio download wait timeout"));
      }, e), l = () => {
        clearTimeout(a), t.removeEventListener("abort", r), this.downloadWaiters.delete(o);
      };
      o = {
        resolve: () => {
          l(), i();
        },
        reject: (c) => {
          l(), s(c);
        }
      }, this.downloadWaiters.add(o), t.addEventListener("abort", r, { once: !0 }), t.aborted && r();
    }) : Promise.resolve();
  }
  resolveDownloadWaiters() {
    this.forEachDownloadWaiter((t) => t.resolve());
  }
  rejectDownloadWaiters(t) {
    this.forEachDownloadWaiter((e) => e.reject(t));
  }
  forEachDownloadWaiter(t) {
    if (!this.downloadWaiters.size)
      return;
    const e = Array.from(this.downloadWaiters);
    this.downloadWaiters.clear();
    for (const i of e)
      t(i);
  }
}
class xy {
  constructor(t) {
    u(this, "state", { status: "idle" });
    u(this, "deps");
    this.deps = t;
  }
  get currentState() {
    return this.state;
  }
  setState(t) {
    this.state = t;
  }
  reset() {
    this.setState({ status: "idle" });
  }
  async runAutoTranslationIfEligible() {
    if (this.state.status === "idle" && this.deps.isFirstPlay() && this.deps.isAutoTranslateEnabled() && this.deps.getVideoId()) {
      if (this.deps.isMobileYouTubeMuted?.()) {
        this.setState({ status: "deferred", reason: "muted" }), this.deps.setMuteWatcher?.(() => {
          this.setState({ status: "idle" }), this.runAutoTranslationIfEligible();
        });
        return;
      }
      this.setState({ status: "pending", reason: "auto" });
      try {
        if (!await this.deps.scheduleAutoTranslate()) {
          C.log(
            "[TranslationOrchestrator] Auto-translate prerequisites not ready yet; keeping firstPlay for retry"
          ), this.reset();
          return;
        }
        this.deps.setFirstPlay(!1), this.reset();
      } catch (t) {
        throw this.setState({ status: "error", message: t }), t;
      }
    }
  }
}
function Vy() {
  return /^(m|music)\.youtube\.com$/i.test(
    String(globalThis.location.hostname || "")
  );
}
function mi(n, t) {
  Vy() && console.log(`[VOT][mobile-overlay][lifecycle] ${n}`, t ?? {});
}
function mo(n, t = {}) {
  const { requireVideoData: e = !1, clearVideoData: i = !1 } = t;
  if (e && !n.videoData) {
    mi("skip translation reset: no videoData", {
      requireVideoData: e,
      clearVideoData: i
    });
    return;
  }
  mi("reset translation state", {
    requireVideoData: e,
    clearVideoData: i,
    hadVideoData: !!n.videoData
  }), i && (n.videoData = void 0), n.stopTranslation(), n.resetSubtitlesWidget();
}
function Tu(n, t = {}) {
  const { hideMenu: e = !1 } = t;
  mi("hide overlay", {
    hideMenu: e
  }), n?.votButton?.container && (n.votButton.container.hidden = !0), e && n?.votMenu && (n.votMenu.hidden = !0);
}
function Vs(n, t, e = {}) {
  const { requireVideoData: i, clearVideoData: s, hideMenu: o } = e;
  mi("reset and hide lifecycle", {
    requireVideoData: i,
    clearVideoData: s,
    hideMenu: o
  }), mo(n, {
    requireVideoData: i,
    clearVideoData: s
  }), Tu(t, { hideMenu: o });
}
function Cy() {
  return /(?:^|\.)vkvideo\.ru$|(?:^|\.)vk\.(?:com|ru)$/i.test(
    String(globalThis.location.hostname || "")
  );
}
class Ey {
  constructor(t) {
    u(this, "host");
    u(this, "lifecycleGeneration", 0);
    u(this, "lastSetCanPlaySourceKey", "");
    u(this, "activeSetCanPlaySourceKey", "");
    u(this, "setCanPlayRequested", !1);
    u(this, "setCanPlayLoopPromise");
    u(this, "deferredAutoStartupTimer");
    this.host = t;
  }
  isMobileYouTubeDebugHost() {
    return /^(m|music)\.youtube\.com$/i.test(
      String(globalThis.location.hostname || "")
    );
  }
  logMobileOverlay(t, e) {
    this.isMobileYouTubeDebugHost() && console.log(
      `[VOT][mobile-overlay][lifecycle-controller] ${t}`,
      e ?? {}
    );
  }
  isGracefulMobileYouTubeSite() {
    return this.host.site.host === "youtube" && (this.host.site.additionalData === "mobile" || this.host.site.additionalData === "music");
  }
  getCurrentPageKey() {
    return `${globalThis.location.origin}${globalThis.location.pathname}${globalThis.location.search}`;
  }
  shouldKeepOverlayAlive(t) {
    return this.isGracefulMobileYouTubeSite() ? this.getCurrentPageKey() === (t ?? this.getCurrentPageKey()) : !1;
  }
  isStale(t) {
    return t !== this.lifecycleGeneration;
  }
  resetActions(t) {
    if (typeof this.host.resetActionsAbortController == "function") {
      this.host.resetActionsAbortController(t);
      return;
    }
    this.host.actionsAbortController?.abort(t);
  }
  invalidateActiveSession(t) {
    this.clearDeferredAutoStartup(), this.lifecycleGeneration !== 0 && (this.lifecycleGeneration += 1, this.resetActions(`[VideoLifecycle] ${t}`), C.log(
      `[VideoLifecycle] cancelled active session (active: ${this.lifecycleGeneration})`,
      { reason: t }
    ));
  }
  startSession(t) {
    this.lifecycleGeneration += 1;
    const e = this.lifecycleGeneration;
    return this.resetActions(`[VideoLifecycle][session:${e}] ${t}`), e;
  }
  shouldAbortHandleSrcChanged(t, e) {
    return this.isStale(t) ? (C.log(
      `[VideoLifecycle][session:${t}] handleSrcChanged aborted at ${e} (active: ${this.lifecycleGeneration})`
    ), !0) : !1;
  }
  showOverlayButton(t) {
    t.votButton.container.hidden = !1, t.votButton.opacity = 1, this.host.queueOverlayAutoHide?.();
  }
  hasResolvableMediaSource() {
    const { video: t } = this.host;
    if (t.currentSrc || t.src || t.srcObject)
      return !0;
    const e = t.querySelector("source");
    return !!(e?.getAttribute("src") || e?.src);
  }
  teardown() {
    this.logMobileOverlay("teardown controller", {
      pageKey: this.getCurrentPageKey(),
      videoId: this.host.videoData?.videoId
    }), this.clearDeferredAutoStartup(), this.setCanPlayRequested = !1, this.invalidateActiveSession("teardown");
  }
  clearDeferredAutoStartup() {
    this.deferredAutoStartupTimer !== void 0 && (clearTimeout(this.deferredAutoStartupTimer), this.deferredAutoStartupTimer = void 0);
  }
  shouldDeferAutoStartup() {
    return this.host.site.host === "youtube" && !this.host.site.additionalData;
  }
  hasAutoStartupWork() {
    return !!(this.host.data.autoTranslate || this.host.data.autoSubtitles);
  }
  async runAutoStartupSequence(t, e) {
    if (e === "immediate") {
      const i = this.runAutoSubtitlesIfEnabled(t);
      if (await this.host.translationOrchestrator.runAutoTranslationIfEligible(), this.isStale(t))
        return;
      await i, this.isStale(t);
      return;
    }
    await this.host.translationOrchestrator.runAutoTranslationIfEligible(), !this.isStale(t) && (await this.runAutoSubtitlesIfEnabled(t), this.isStale(t));
  }
  scheduleDeferredAutoStartup(t, e) {
    this.hasAutoStartupWork() && (this.clearDeferredAutoStartup(), this.deferredAutoStartupTimer = globalThis.setTimeout(() => {
      this.deferredAutoStartupTimer = void 0, !this.isStale(t) && this.getCurrentSourceKey() === e && this.runAutoStartupSequence(t, "deferred").catch((i) => {
      });
    }, 800));
  }
  getCurrentSourceKey() {
    const t = this.host.video.srcObject ? "1" : "0";
    if (this.host.site.host === "youtube") {
      const i = globalThis.location.pathname;
      return `${`${globalThis.location.origin}${i}${globalThis.location.search}`}||${t}`;
    }
    const e = this.host.video.currentSrc || this.host.video.src || "";
    return `${globalThis.location.href}||${e}||${t}`;
  }
  resolveContainer() {
    const { site: t, video: e, container: i } = this.host;
    if (!t.selector)
      return e.parentElement ?? i;
    const s = An(e, t.selector);
    return s || (i.isConnected && be(i, e) ? i : e.parentElement ?? i);
  }
  async setCanPlay() {
    if (this.setCanPlayRequested = !0, this.setCanPlayLoopPromise !== void 0) {
      const e = this.getCurrentSourceKey();
      return this.activeSetCanPlaySourceKey && e !== this.activeSetCanPlaySourceKey && this.invalidateActiveSession(
        "setCanPlay source changed while previous trigger is running"
      ), await this.setCanPlayLoopPromise;
    }
    const t = (async () => {
      for (; this.setCanPlayRequested; )
        this.setCanPlayRequested = !1, await this.runSetCanPlayOnce();
    })();
    this.setCanPlayLoopPromise = t;
    try {
      await t;
    } finally {
      this.setCanPlayLoopPromise === t && (this.setCanPlayLoopPromise = void 0);
    }
  }
  async runSetCanPlayOnce() {
    const t = this.getCurrentSourceKey(), e = this.getCurrentPageKey();
    if (this.host.videoData?.videoId && t === this.lastSetCanPlaySourceKey) {
      const o = this.host.uiManager.votOverlayView;
      this.showOverlayButton(o);
      const r = this.host.syncSourceAudioAvailabilityUi({
        forceVisible: !0
      });
      if (console.log("[VOT][source-audio] status refresh after setCanPlay", {
        sourceKey: t,
        kind: r.kind,
        ready: r.ready,
        audioDetected: r.audioDetected,
        detectionSource: r.detectionSource
      }), this.shouldDeferAutoStartup())
        return;
      await this.runAutoSubtitlesIfEnabled(this.lifecycleGeneration);
      return;
    }
    let i;
    try {
      i = await this.host.getVideoData();
    } catch {
      this.host.videoData = void 0, this.logMobileOverlay("keep overlay after getVideoData failure", {
        sourceKey: t,
        pageKey: e,
        hasResolvableMediaSource: this.hasResolvableMediaSource()
      }), this.showOverlayButton(this.host.uiManager.votOverlayView), this.host.syncSourceAudioAvailabilityUi({ forceVisible: !0 });
      return;
    }
    if (this.getCurrentSourceKey() !== t)
      return;
    this.host.videoData = i, Cy() && console.log("[VOT][VK probe] videoData", {
      videoId: i?.videoId,
      host: i?.host,
      url: i?.url,
      duration: i?.duration,
      subtitles: Array.isArray(i?.subtitles) ? i.subtitles.length : null
    }), this.activeSetCanPlaySourceKey = t;
    const s = this.startSession(`setCanPlay (source: ${t})`);
    try {
      if (await this.handleSrcChanged(s, t), this.isStale(s)) {
        C.log(
          `[VideoLifecycle][session:${s}] setCanPlay aborted after src change (active: ${this.lifecycleGeneration})`
        );
        return;
      }
      if (this.shouldDeferAutoStartup()) {
        this.scheduleDeferredAutoStartup(s, t), C.log(
          `[VideoLifecycle][session:${s}] deferred auto startup scheduled`,
          { sourceKey: t }
        );
        return;
      }
      await this.runAutoStartupSequence(s, "immediate"), C.log(`[VideoLifecycle][session:${s}] setCanPlay finished`);
    } finally {
      this.activeSetCanPlaySourceKey === t && (this.activeSetCanPlaySourceKey = "");
    }
  }
  async runAutoSubtitlesIfEnabled(t) {
    if (!(!this.host.data.autoSubtitles || !this.host.videoData?.videoId))
      try {
        await this.host.enableSubtitlesForCurrentLangPair();
      } catch {
      }
  }
  async handleSrcChanged(t, e) {
    const i = typeof t == "number" ? t : this.startSession("manual handleSrcChanged"), s = typeof e == "string" && e.length > 0 ? e : this.getCurrentSourceKey(), o = this.getCurrentPageKey();
    if (this.shouldAbortHandleSrcChanged(i, "before start"))
      return;
    this.host.translationOrchestrator.reset(), this.host.firstPlay = !0;
    const r = this.host.uiManager.votOverlayView;
    this.shouldKeepOverlayAlive(o) ? (this.logMobileOverlay("reset lifecycle without hiding overlay", {
      sourceKey: s,
      pageKey: o,
      videoId: this.host.videoData?.videoId
    }), mo(this.host, { requireVideoData: !0 }), r.votMenu.hidden = !0) : Vs(this.host, r, { requireVideoData: !0 });
    const a = !this.host.video.src && !this.host.video.currentSrc && !this.host.video.srcObject;
    a && !this.shouldKeepOverlayAlive(o) ? Tu(r, { hideMenu: !0 }) : a && this.logMobileOverlay(
      "keep overlay with empty currentSrc during src change",
      {
        sourceKey: s,
        pageKey: o
      }
    );
    const l = this.resolveContainer();
    if (l !== this.host.container && (this.host.container = l), this.shouldAbortHandleSrcChanged(i, "before getVideoData") || (this.showOverlayButton(r), this.host.syncSourceAudioAvailabilityUi({ forceVisible: !0 }), this.shouldAbortHandleSrcChanged(i, "after getVideoData")))
      return;
    if (!this.host.videoData?.videoId) {
      this.logMobileOverlay("keep overlay without resolved videoId", {
        sourceKey: s,
        pageKey: o,
        hasResolvableMediaSource: this.hasResolvableMediaSource()
      }), this.showOverlayButton(r), this.host.syncSourceAudioAvailabilityUi({ forceVisible: !0 });
      return;
    }
    const c = this.host.getSubtitlesCacheKey(
      this.host.videoData.videoId,
      this.host.videoData.detectedLanguage,
      this.host.videoData.responseLanguage
    ), d = this.host.cacheManager.getSubtitles(c);
    this.host.subtitles = d ?? [], this.host.subtitlesCacheKey = d !== void 0 ? c : null, await this.host.updateSubtitlesLangSelect(), !this.shouldAbortHandleSrcChanged(i, "after subtitles update") && (this.host.translateToLang = this.host.data.responseLanguage ?? "ru", this.host.setSelectMenuValues(
      this.host.videoData.detectedLanguage,
      this.host.videoData.responseLanguage
    ), this.showOverlayButton(r), this.host.syncSourceAudioAvailabilityUi({ forceVisible: !0 }), this.lastSetCanPlaySourceKey = s, this.host.onPrimaryAttachReady?.());
  }
}
const Iy = /(?:^|\.)vkvideo\.ru$|(?:^|\.)vk\.(?:com|ru)$/i, Py = /api\.vkvideo\.ru|\/al_video\.php(?:$|[?#])|\/method\/video\.|video_ext\.php|vkvideo\.ru/i, ma = /\.(vtt|srt|ass|json)(?:$|[?#])/i, My = 15e5, Oy = 64, Cs = 600 * 1e3, pi = /* @__PURE__ */ new Map(), pa = /* @__PURE__ */ Symbol("votSniffedSubtitleUrl");
let ya = !1;
function Dy(n) {
  return Iy.test(n);
}
function is() {
  return Dy(String(globalThis.location.hostname || ""));
}
function po(n) {
  try {
    return new URL(n, globalThis.location.href).href;
  } catch {
    return n;
  }
}
function yo(n) {
  const t = n.split(/[?#]/u, 1)[0]?.toLowerCase() ?? "";
  return t.endsWith(".vtt") ? "vtt" : t.endsWith(".srt") ? "srt" : t.endsWith(".ass") ? "ass" : t.endsWith(".json") ? "json" : null;
}
function Fe(n) {
  if (typeof n != "string")
    return;
  const t = n.trim();
  if (t)
    try {
      return X(t);
    } catch {
      return t.toLowerCase().split(/[_;-]/u)[0]?.trim() || void 0;
    }
}
function bo(n) {
  try {
    const t = new URL(n, globalThis.location.href), e = t.searchParams.get("lang") || t.searchParams.get("language") || t.searchParams.get("locale") || t.searchParams.get("srclang");
    if (e)
      return Fe(e);
    const i = decodeURIComponent(t.pathname), s = /(?:^|[._/-])([a-z]{2,3}(?:-[a-z]{2,4})?)(?=\.(?:vtt|srt|ass|json)\b)/i.exec(
      i
    ) || /(?:^|[._/-])([a-z]{2,3})(?:[._-]captions?)(?=\b)/i.exec(i);
    return Fe(s?.[1]);
  } catch {
    return;
  }
}
function ku(n, t) {
  const e = String(n || "").trim(), i = String(t || "").trim();
  if (!e || !i)
    return;
  const s = Number.parseInt(e, 10);
  if (!Number.isNaN(s))
    return `video-${Math.abs(s)}_${i}`;
}
function vo(n) {
  try {
    const t = new URL(n, globalThis.location.href), e = /\/(video-?\d+_\d+)/i.exec(t.pathname) || /\/playlist\/[^/]+\/(video-?\d+_\d+)/i.exec(t.pathname);
    if (e?.[1])
      return e[1];
    const i = t.searchParams.get("z");
    if (i) {
      const r = /(video-?\d+_\d+)/i.exec(i);
      if (r?.[1])
        return r[1];
    }
    const s = t.searchParams.get("oid"), o = t.searchParams.get("id");
    if (s && o)
      return ku(s, o);
  } catch {
    return;
  }
}
function _y(n) {
  return n !== null && typeof n == "object";
}
function fn(n, t) {
  for (const e of t) {
    const i = n[e];
    if (typeof i == "string" && i.trim())
      return i.trim();
  }
}
function ba(n, t) {
  for (const e of t) {
    const i = n[e];
    if (typeof i == "number" && Number.isFinite(i))
      return String(i);
    if (typeof i == "string" && i.trim())
      return i.trim();
  }
}
function Es(n) {
  if (typeof n == "boolean")
    return n;
  if (typeof n == "number")
    return n !== 0;
  if (typeof n == "string") {
    const t = n.trim().toLowerCase();
    if (t === "true" || t === "1") return !0;
    if (t === "false" || t === "0") return !1;
  }
}
function Ry(n) {
  const t = fn(n, [
    "videoId",
    "video_id",
    "video",
    "player_id"
  ]);
  if (t) {
    const s = /(video-?\d+_\d+)/i.exec(t);
    if (s?.[1])
      return s[1];
  }
  const e = ba(n, [
    "owner_id",
    "ownerId",
    "oid",
    "video_oid"
  ]), i = ba(n, ["id", "vid", "video_id", "videoId"]);
  if (e && i)
    return ku(e, i);
}
function By(n) {
  return n === "subs" || n === "subtitles" || n === "captions" || n === "text_tracks" || n.includes("subtitle") || n.includes("caption");
}
function Fy(n, t) {
  const e = fn(n, [
    "url",
    "src",
    "file",
    "download_url",
    "downloadUrl",
    "webVttUrl",
    "webvtturl",
    "link"
  ]);
  if (!e)
    return null;
  const i = po(e), s = yo(i) ?? (t.collectionHint ? "vtt" : null);
  if (!s)
    return null;
  const o = Fe(
    fn(n, [
      "lang",
      "language",
      "lang_code",
      "language_code",
      "locale",
      "locale_id",
      "srclang",
      "code",
      "subtitles_lang"
    ]) ?? t.languageHint ?? bo(i)
  );
  return o ? {
    source: "vk",
    format: s,
    language: o,
    url: i,
    translatedFromLanguage: Fe(
      fn(n, [
        "translatedFromLanguage",
        "translated_from_language",
        "from_lang",
        "source_lang"
      ])
    ),
    isAutoGenerated: Es(
      n.is_auto ?? n.isAutoGenerated ?? n.auto_generated ?? n.autogenerated
    )
  } : null;
}
function Is(n, t, e, i, s = 0) {
  if (s > 7 || n == null)
    return;
  if (Array.isArray(n)) {
    for (const c of n.slice(0, 400))
      Is(c, t, e, i, s + 1);
    return;
  }
  if (!_y(n) || i.has(n))
    return;
  i.add(n);
  const o = n, r = t.videoId ?? Ry(o), a = t.languageHint ?? Fe(
    fn(o, [
      "subtitles_lang",
      "lang",
      "language",
      "locale",
      "locale_id"
    ])
  ), l = Fy(o, {
    ...t,
    languageHint: a
  });
  l && e.push({
    descriptor: l,
    seenAt: Date.now(),
    videoId: r
  });
  for (const [c, d] of Object.entries(o)) {
    if (d == null)
      continue;
    const h = {
      collectionHint: t.collectionHint || By(c.toLowerCase()),
      languageHint: a,
      videoId: r
    };
    Is(d, h, e, i, s + 1);
  }
}
function Ny(n) {
  return n.replace(/\\u0026/giu, "&").replace(/\\u002f/giu, "/").replace(/\\\//gu, "/");
}
function Uy(n, t) {
  const e = [], i = /* @__PURE__ */ new Set(), s = vo(t), o = Ny(n), r = (c, d, h) => {
    const f = Fe(
      c ?? bo(String(d || ""))
    ), g = typeof d == "string" ? po(d) : "", m = yo(g) ?? "vtt";
    if (!f || !g)
      return;
    const v = `${s ?? ""}|${f}|${g}`;
    i.has(v) || (i.add(v), e.push({
      videoId: s,
      seenAt: Date.now(),
      descriptor: {
        source: "vk",
        format: m,
        language: f,
        url: g,
        isAutoGenerated: h
      }
    }));
  }, a = /["'](?:lang|language|locale|subtitles_lang)["']\s*:\s*["']([a-zA-Z_-]{2,12})["'][\s\S]{0,400}?["']url["']\s*:\s*["']([^"'\\]+(?:\\.[^"'\\]*)*)["'][\s\S]{0,120}?(?:["']is_auto["']\s*:\s*(true|false|0|1))?/g, l = /["']url["']\s*:\s*["']([^"'\\]+(?:\\.[^"'\\]*)*)["'][\s\S]{0,400}?["'](?:lang|language|locale|subtitles_lang)["']\s*:\s*["']([a-zA-Z_-]{2,12})["'][\s\S]{0,120}?(?:["']is_auto["']\s*:\s*(true|false|0|1))?/g;
  for (const c of o.matchAll(a))
    r(c[1], c[2], Es(c[3]));
  for (const c of o.matchAll(l))
    r(c[2], c[1], Es(c[3]));
  return e;
}
function wo(n, t) {
  if (!t.length)
    return;
  const e = Date.now(), i = pi.get(n) ?? [], s = /* @__PURE__ */ new Map();
  for (const r of i)
    e - r.seenAt > Cs || s.set(
      [
        r.videoId ?? "",
        r.descriptor.language,
        r.descriptor.translatedFromLanguage ?? "",
        r.descriptor.url
      ].join("|"),
      r
    );
  for (const r of t)
    e - r.seenAt > Cs || s.set(
      [
        r.videoId ?? "",
        r.descriptor.language,
        r.descriptor.translatedFromLanguage ?? "",
        r.descriptor.url
      ].join("|"),
      r
    );
  const o = Array.from(s.values()).sort((r, a) => a.seenAt - r.seenAt).slice(0, Oy);
  pi.set(n, o);
}
function va(n) {
  const t = po(n), e = yo(t), i = bo(t);
  !e || !i || wo("vk", [
    {
      videoId: vo(t),
      seenAt: Date.now(),
      descriptor: {
        source: "vk",
        format: e,
        language: i,
        url: t
      }
    }
  ]);
}
function Lu(n) {
  return Py.test(n);
}
function So(n, t) {
  const e = [];
  Is(
    t,
    {
      collectionHint: !1,
      videoId: vo(n)
    },
    e,
    /* @__PURE__ */ new WeakSet()
  ), wo("vk", e);
}
function Ps(n, t) {
  if (!(!t || t.length > My)) {
    try {
      So(n, JSON.parse(t));
      return;
    } catch {
    }
    wo("vk", Uy(t, n));
  }
}
function $y(n, t) {
  const e = String(t.headers.get("content-type") || "").trim().toLowerCase();
  if (!(!Lu(n) && !(e.includes("json") && /vkvideo|vk\.com|okcdn\.ru/i.test(n)))) {
    if (e.includes("json")) {
      t.clone().json().then((i) => {
        So(n, i);
      }).catch(() => {
        t.clone().text().then((i) => {
          Ps(n, i);
        }).catch(() => {
        });
      });
      return;
    }
    t.clone().text().then((i) => {
      Ps(n, i);
    }).catch(() => {
    });
  }
}
function Hy(n, t) {
  const e = Date.now(), i = (pi.get(n) ?? []).filter(
    (r) => e - r.seenAt <= Cs
  );
  pi.set(n, i);
  const s = t ? i.filter(
    (r) => !r.videoId || r.videoId === t
  ) : i, o = /* @__PURE__ */ new Map();
  for (const r of s)
    o.set(
      [
        r.descriptor.language,
        r.descriptor.translatedFromLanguage ?? "",
        r.descriptor.url
      ].join("|"),
      r.descriptor
    );
  return Array.from(o.values());
}
function Wy() {
  if (ya)
    return;
  ya = !0;
  const n = globalThis.fetch.bind(globalThis);
  globalThis.fetch = async (...i) => {
    const s = await n(...i);
    if (!is())
      return s;
    const o = i[0], r = typeof o == "string" ? o : o instanceof Request ? o.url : String(o ?? "");
    return ma.test(r) && va(r), $y(r, s), s;
  };
  const t = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(i, s, ...o) {
    const r = String(s);
    return this[pa] = r, is() && ma.test(r) && va(r), t.call(this, i, s, ...o);
  };
  const e = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function(...i) {
    return is() && this.addEventListener(
      "load",
      () => {
        const s = this[pa];
        if (!s)
          return;
        const o = String(
          this.getResponseHeader("content-type") || ""
        ).trim().toLowerCase();
        if (!Lu(s) && !(o.includes("json") && /vkvideo|vk\.com|okcdn\.ru/i.test(s)))
          return;
        if (this.responseType === "json" && this.response) {
          So(s, this.response);
          return;
        }
        if (this.responseType !== "" && this.responseType !== "text" && this.responseType !== "json")
          return;
        const r = typeof this.responseText == "string" ? this.responseText : "";
        Ps(s, r);
      },
      { once: !0 }
    ), e.apply(this, i);
  };
}
const zy = 450, qy = new RegExp(
  [
    // URLs.
    String.raw`(?:https?:\/\/|www\.)\S+`,
    String.raw`#[^\s#]+`,
    String.raw`auto-generated\s+by\s+youtube`,
    String.raw`provided\s+to\s+youtube\s+by`,
    String.raw`released\s+on`,
    String.raw`\bpaypal\b`,
    String.raw`\b0x[a-f0-9]{40}\b`,
    // Bitcoin legacy Base58 (mainnet P2PKH/P2SH).
    String.raw`\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b`,
    // Bitcoin Bech32 / Bech32m.
    String.raw`\b(?:bc1|tb1|bcrt1)[ac-hj-np-z02-9]{11,71}\b`,
    // TON raw format.
    String.raw`\b(?:-1|0):[a-f0-9]{64}\b`
  ].join("|"),
  "giu"
), Gy = /[\p{N}\p{P}\p{S}]+/gu, Ky = /\s+/g, Yy = /\p{L}/u;
function jy(n, t) {
  return n.length <= t ? n : n.slice(0, t).trimEnd();
}
function Xy(n, t) {
  const e = `${n ?? ""} ${t ?? ""}`.trim();
  if (!e) return "";
  const i = e.normalize("NFKC").replace(qy, " ").replace(Gy, " ").replace(Ky, " ").trim();
  return Yy.test(i) ? jy(i, zy) : "";
}
const Au = 5e3, xu = Number.MAX_SAFE_INTEGER;
let Gn = null, wa = 0, Kn = null, Sa = 0;
async function Jy() {
  const n = Date.now();
  if (Gn && n - wa < Au)
    return Gn;
  const t = await I.get(
    "translationService",
    Oi
  );
  return Gn = String(t), wa = n, Gn;
}
async function Zy() {
  const n = Date.now();
  if (Kn && n - Sa < Au)
    return Kn;
  const t = await I.get("detectService", oo);
  return Kn = String(t), Sa = n, Kn;
}
const Vu = ["yandexbrowser", "msedge"], Ms = new class {
  isFOSWLYError(n) {
    return Object.hasOwn(n, "error");
  }
  async request(n, t = {}) {
    try {
      const i = await (await ut(`${ch}${n}`, {
        ...t,
        timeout: 3e3,
        forceGmXhr: !0,
        responseCache: {
          ttlMs: xu,
          cacheName: "vot-foswly-api-v1",
          allowStaleOnError: !0
        }
      })).json();
      if (this.isFOSWLYError(i))
        throw new Error(i.error);
      return i;
    } catch (e) {
      console.error(
        `[VOT] Failed to get data from FOSWLY Translate API, because ${e instanceof Error ? e.message : String(e)}`
      );
      return;
    }
  }
  async translateMultiple(n, t, e) {
    const i = await this.request(
      "/translate",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          text: n,
          lang: t,
          service: e
        })
      }
    );
    return i ? i.translations : n;
  }
  async translate(n, t, e) {
    const i = await this.request(
      `/translate?${new URLSearchParams({
        text: n,
        lang: t,
        service: e
      })}`
    );
    return i ? i.translations[0] : n;
  }
  async detect(n, t) {
    const e = await this.request(
      `/detect?${new URLSearchParams({
        text: n,
        service: t
      })}`
    );
    return e ? e.lang : "en";
  }
}(), Qy = {
  async detect(n) {
    try {
      return await (await ut(dh, {
        method: "POST",
        body: n,
        timeout: 3e3,
        forceGmXhr: !0,
        responseCache: {
          ttlMs: xu,
          cacheName: "vot-rust-detect-v1",
          allowStaleOnError: !0
        }
      })).text();
    } catch (t) {
      return console.error(
        `[VOT] Error getting lang from text, because ${t.message}`
      ), "en";
    }
  }
};
async function Os(n, t = "", e = "ru") {
  if (t && e && t === e)
    return n;
  const i = await Jy();
  switch (i) {
    case "yandexbrowser":
    case "msedge": {
      const s = t && e ? `${t}-${e}` : e;
      return Array.isArray(n) ? await Ms.translateMultiple(n, s, i) : await Ms.translate(n, s, i);
    }
    default:
      return n;
  }
}
async function tb(n) {
  const t = await Zy();
  switch (t) {
    case "yandexbrowser":
    case "msedge":
      return await Ms.detect(n, t);
    case "rust-server":
      return await Qy.detect(n);
    default:
      return "en";
  }
}
const eb = [...Vu, "rust-server"], nb = 0, ib = 100, yi = 0.01, Ta = 1e-6;
function Ne(n, t, e) {
  return !Number.isFinite(n) || e < t ? t : Math.max(t, Math.min(e, n));
}
function Ds(n, t, e) {
  return Math.trunc(Ne(n, t, e));
}
function Rt(n, t = nb, e = ib) {
  return Number.isFinite(n) ? Ds(Math.round(n), t, e) : t;
}
function Cu(n) {
  const t = Ne(n, 0, 1);
  return Rt(t * 100);
}
function sb(n) {
  return Rt(n) / 100;
}
function ob(n, t, e) {
  if (!Number.isFinite(n) || !Number.isFinite(t) || t <= 0) return n;
  const i = 1 / t, s = n * i;
  switch (e) {
    case "down":
      return Math.floor(s + Ta) / i;
    case "up":
      return Math.ceil(s - Ta) / i;
    default:
      return Math.round(s) / i;
  }
}
function fe(n, t = "nearest", e = yi) {
  const i = Ne(n, 0, 1), s = ob(i, e, t);
  return Ne(s, 0, 1);
}
function rb(n, t, e, i = yi) {
  const s = Ne(t, 0, 1), o = Ne(e, 0, 1);
  if (o < s) {
    const r = fe(n, "down", i);
    return Math.max(o, r);
  }
  if (o > s) {
    const r = fe(n, "up", i);
    return Math.min(o, r);
  }
  return fe(n, "nearest", i);
}
function ab() {
  const n = Array.from(
    document.querySelectorAll('script[type="application/ld+json"]')
  );
  for (const t of n) {
    const e = t.textContent?.trim();
    if (e)
      try {
        const i = JSON.parse(e), s = Array.isArray(i) ? i : [i];
        for (const o of s)
          if (!(!o || typeof o != "object") && o["@type"] === "VideoObject")
            return {
              contentUrl: typeof o.contentUrl == "string" ? o.contentUrl : void 0,
              embedUrl: typeof o.embedUrl == "string" ? o.embedUrl : void 0,
              pageUrl: typeof o.url == "string" ? o.url : void 0,
              title: typeof o.name == "string" ? o.name : void 0
            };
      } catch {
      }
  }
  return null;
}
function qt(n, t) {
  const e = String(n || "").trim();
  if (!e)
    return t;
  try {
    const i = new URL(e, globalThis.location.href);
    return i.hash = "", i.toString();
  } catch {
    return e;
  }
}
function Yn(n) {
  const t = n.filter(Boolean).map((s) => String(s).trim()).filter(Boolean), e = (s) => {
    const o = s.toLowerCase(), r = /\.m3u8([?#]|$)/i.test(o) || /\.mpd([?#]|$)/i.test(o);
    return o.includes("thumbnails.") || o.includes("/speech/") || o.endsWith(".jpg") || o.endsWith(".jpeg") || o.endsWith(".png") || o.endsWith(".webp") || o.includes("okcdn.ru/?") || /[?&]bytes=\d+-\d+/i.test(o) || !r && /[?&]type=\d+/i.test(o);
  }, i = t.filter((s) => !e(s));
  return i.find((s) => /\.m3u8([?#]|$)/i.test(s)) || i.find((s) => /\.mpd([?#]|$)/i.test(s)) || i.find((s) => /\.mp4([?#]|$)/i.test(s)) || i.find((s) => /\/streams\//i.test(s)) || null;
}
function lb(n) {
  const t = [
    String(n?.hlsUrl || "").trim(),
    String(n?.sources?.hlsUrl || "").trim(),
    String(n?.dashUrl || "").trim(),
    String(n?.sources?.dashUrl || "").trim(),
    String(n?.mpegLowUrl || "").trim(),
    String(n?.url || "").trim()
  ].filter(Boolean);
  return t.find((e) => /\.m3u8([?#]|$)/i.test(e)) || t.find((e) => /\.mpd([?#]|$)/i.test(e)) || t.find((e) => /\.mp4([?#]|$)/i.test(e)) || t[0] || "";
}
function Le(n) {
  const t = String(n || "").toLowerCase(), e = /\.m3u8([?#]|$)/i.test(t) || /\.mpd([?#]|$)/i.test(t);
  return !t || t.startsWith("blob:") || t.includes("thumbnails.") || t.includes("/speech/") || t.endsWith(".jpg") || t.endsWith(".jpeg") || t.endsWith(".png") || t.endsWith(".webp") || t.includes("okcdn.ru/?") || /[?&]bytes=\d+-\d+/i.test(t) || !e && /[?&]type=\d+/i.test(t);
}
async function ub(n, t) {
  const e = uo(t);
  if (e) {
    const o = performance.getEntriesByType("resource").map((d) => typeof d.name == "string" ? d.name : "").filter(Boolean), r = Yn(o), a = document.querySelector("video"), l = String(a?.currentSrc || a?.src || "").trim(), c = (Le(e.sourceUrl || "") ? "" : String(e.sourceUrl)) || (Le(l) ? "" : l) || e.playerUrl;
    return console.log("[VOT][custom][tunnel] resolved tunnel player source", {
      playerUrl: e.playerUrl,
      sourceUrl: e.sourceUrl,
      playlistUrl: e.playlistUrl,
      currentSrc: l,
      resourceUrl: r,
      resolvedUrl: c
    }), {
      url: c,
      videoId: qt(
        c || e.sourceUrl || t,
        e.sourceUrl || c || t
      ),
      title: document.title
    };
  }
  let i = globalThis.__VOT_DIRECT_SOURCES__;
  if (!i)
    try {
      const s = document.documentElement.dataset.votDirectSources;
      s && (i = JSON.parse(s));
    } catch {
    }
  if (i && typeof i == "object") {
    const s = lb(i), o = String(i.unitedVideoId || t).trim();
    if (s && !Le(s))
      return console.log("[VOT][custom][direct-sources] resolved direct source", {
        bestDirect: s,
        unitedVideoId: o
      }), {
        url: s,
        videoId: qt(
          o || s,
          s || t
        ),
        title: String(i.title || document.title || "")
      };
  }
  if (/^odysee\.com$/i.test(n)) {
    const s = ab();
    if (s?.contentUrl && /^https?:\/\//i.test(s.contentUrl))
      return console.log(
        "[VOT][custom][odysee] resolved contentUrl",
        s.contentUrl
      ), {
        url: s.contentUrl,
        videoId: t,
        title: s.title || document.title
      };
    const r = performance.getEntriesByType("resource").map((f) => typeof f.name == "string" ? f.name : "").filter(Boolean), a = (f) => {
      const g = f.toLowerCase();
      return g.includes(".jpg") || g.includes(".jpeg") || g.includes(".png") || g.includes(".webp") || g.includes("/speech/") || g.includes("thumbnails.odycdn.com");
    }, l = (f) => r.find((g) => !a(g) && f(g)) || null, c = l((f) => f.toLowerCase().includes(".m3u8")) || l((f) => f.toLowerCase().includes(".mpd")) || l((f) => f.toLowerCase().includes(".mp4")) || l((f) => f.toLowerCase().includes("/streams/"));
    if (c)
      return console.log("[VOT][custom][odysee] resolved media url", c), {
        url: c,
        videoId: t,
        title: s?.title || document.title
      };
    const d = document.querySelector("video"), h = String(d?.currentSrc || d?.src || "");
    return h && !h.startsWith("blob:") && !a(h) ? (console.log("[VOT][custom][odysee] resolved direct src", h), {
      url: h,
      videoId: t,
      title: s?.title || document.title
    }) : s?.embedUrl ? (console.log(
      "[VOT][custom][odysee] fallback embedUrl",
      s.embedUrl
    ), {
      url: s.embedUrl,
      videoId: t,
      title: s.title || document.title
    }) : (console.log("[VOT][custom][odysee] fallback page url", t), {
      url: t,
      videoId: t,
      title: s?.title || document.title
    });
  }
  if (/^player\.cdnvideohub\.com$/i.test(n) || /(^|\.)okcdn\.ru$/i.test(n)) {
    const s = String(document.referrer || "").trim(), o = document.querySelector("video"), r = String(o?.currentSrc || o?.src || "").trim();
    if (!Le(r))
      return console.log("[VOT][custom][cdnvideohub] using direct src", r), {
        url: r,
        videoId: qt(r, s || t),
        title: document.title
      };
    const l = performance.getEntriesByType("resource").map((d) => typeof d.name == "string" ? d.name : "").filter(Boolean), c = Yn(l);
    return c ? (console.log(
      "[VOT][custom][cdnvideohub] using performance resource",
      c
    ), {
      url: c,
      videoId: qt(c, s || t),
      title: document.title
    }) : /^https?:\/\/([^/]+\.)?kodik(player\.com|\.info|\.biz|\.cc|\.fun|\.pw|\.io|\.online|\.me)\//i.test(
      s
    ) ? (console.log("[VOT][custom][cdnvideohub] using kodik referrer", s), {
      url: s,
      videoId: s,
      title: document.title
    }) : (console.log(
      "[VOT][custom][cdnvideohub] no usable url found, returning null for sniffed fallback"
    ), null);
  }
  if (/(^|\.)wikianimex\.ru$/i.test(n)) {
    const s = document.querySelector("video"), o = String(s?.currentSrc || s?.src || "").trim();
    if (!Le(o))
      return console.log("[VOT][custom][wikianimex] using direct src", o), {
        url: o,
        videoId: qt(o, t),
        title: document.title
      };
    const a = performance.getEntriesByType("resource").map((d) => typeof d.name == "string" ? d.name : "").filter(Boolean), l = Yn(a);
    if (l)
      return console.log("[VOT][custom][wikianimex] using performance resource", l), {
        url: l,
        videoId: qt(l, t),
        title: document.title
      };
    const c = Array.from(document.querySelectorAll("iframe"));
    for (const d of c) {
      const h = String(d.src || d.getAttribute("src") || "").trim();
      if (!(!h || h === "about:blank" || h.startsWith("javascript:")) && /kodik(player\.com|\.info|\.biz|\.cc|\.fun|\.pw|\.io|\.online|\.me)/i.test(
        h
      ))
        return console.log("[VOT][custom][wikianimex] using kodik iframe src", h), { url: h, videoId: h, title: document.title };
    }
    return console.log(
      "[VOT][custom][wikianimex] no usable url, deferring to sniffedManifestUrl"
    ), null;
  }
  {
    const o = performance.getEntriesByType("resource").map((c) => typeof c.name == "string" ? c.name : "").filter(Boolean), r = Yn(o);
    if (r)
      return console.log("[VOT][custom][generic] resolved media url", r), {
        url: r,
        videoId: qt(r, t),
        title: document.title
      };
    const a = document.querySelector("video"), l = String(a?.currentSrc || a?.src || "");
    if (!Le(l))
      return console.log("[VOT][custom][generic] resolved direct src", l), {
        url: l,
        videoId: qt(l, t),
        title: document.title
      };
  }
  return null;
}
const cb = [
  "#movie_player",
  "ytm-player",
  "ytmusic-player",
  "#player",
  ".player-container",
  "video"
];
function ka() {
  return String(globalThis.location.hostname || "").trim().toLowerCase();
}
function gn(n) {
  return n && typeof n == "object" ? n : null;
}
function ai(n) {
  if (n) {
    if (typeof n == "string")
      try {
        return JSON.parse(n);
      } catch {
        return;
      }
    if (typeof n == "object")
      return n;
  }
}
function mn(n) {
  const t = gn(n);
  return !!(t && (typeof t.videoDetails == "object" || typeof t.captions == "object"));
}
function _s(n) {
  const t = gn(n);
  return !!(t && (typeof t.video_id == "string" || typeof t.videoId == "string" || typeof t.title == "string"));
}
function db() {
  for (const n of cb) {
    const t = document.querySelector(n);
    if (t)
      return t;
  }
  return null;
}
function hb() {
  const n = globalThis, t = ai(
    n.ytInitialPlayerResponse
  );
  if (mn(t))
    return t;
  const e = gn(n.ytplayer), i = gn(e?.config), s = gn(i?.args), o = ai(s?.player_response);
  if (mn(o))
    return o;
  const r = ai(
    i?.player_response
  );
  return mn(r) ? r : void 0;
}
function fb() {
  const t = ai(globalThis.ytInitialData);
  if (_s(t))
    return t;
}
function La(n) {
  const t = n.searchParams.get("v");
  if (t)
    return t;
  const e = n.pathname.split("/").filter(Boolean);
  for (const i of ["shorts", "embed", "live"]) {
    const s = e.indexOf(i);
    if (s !== -1) {
      const o = e[s + 1];
      if (o)
        return o;
    }
  }
  if (n.hostname === "youtu.be")
    return e[0];
}
function Eu(n) {
  return n === "mobile" || n === "music";
}
class W {
  static isMobile() {
    return ka() === "m.youtube.com";
  }
  static isMusic() {
    return ka() === "music.youtube.com";
  }
  static isMobileVariant() {
    return W.isMobile() || W.isMusic();
  }
  static getPlayer() {
    const t = Dt.getPlayer();
    return t || (W.isMobileVariant() ? db() : null);
  }
  static getPlayerResponse() {
    const t = W.getPlayer()?.getPlayerResponse?.call(void 0);
    if (mn(t))
      return t;
    const e = Dt.getPlayerResponse();
    return mn(e) ? e : hb();
  }
  static getPlayerData() {
    const t = W.getPlayer()?.getVideoData?.call(void 0);
    if (_s(t))
      return t;
    const e = Dt.getPlayerData();
    if (_s(e))
      return e;
    const i = W.getPlayerResponse();
    return i?.videoDetails?.title || i?.videoDetails?.videoId ? {
      title: i.videoDetails.title,
      videoId: i.videoDetails.videoId
    } : fb();
  }
  static getVolume() {
    const t = W.getPlayer();
    if (t?.getVolume)
      return t.getVolume() / 100;
    const e = document.querySelector("video");
    return e instanceof HTMLMediaElement ? e.volume : 1;
  }
  static setVolume(t) {
    const e = W.getPlayer();
    if (e?.setVolume)
      return e.setVolume(Math.round(t * 100));
    const i = document.querySelector("video");
    return i instanceof HTMLMediaElement ? (i.volume = t, !0) : !1;
  }
  static isMuted() {
    const t = W.getPlayer();
    if (t?.isMuted)
      return t.isMuted();
    const e = document.querySelector("video");
    return e instanceof HTMLMediaElement ? e.muted : !1;
  }
  static getVideoDuration(t) {
    const e = W.getPlayer()?.getDuration?.call(void 0);
    if (typeof e == "number" && Number.isFinite(e))
      return e;
    const i = t ?? document.querySelector("video");
    return i instanceof HTMLMediaElement && Number.isFinite(i.duration) && i.duration > 0 ? i.duration : void 0;
  }
  static getCurrentVideoId(t = new URL(globalThis.location.href)) {
    const e = W.getPlayerData(), i = W.getPlayerResponse();
    return [
      e?.videoId,
      e?.video_id,
      i?.videoDetails?.videoId,
      (() => {
        try {
          const o = W.getPlayer()?.getVideoUrl?.call(void 0);
          return o ? La(new URL(o)) : void 0;
        } catch {
          return;
        }
      })(),
      La(t)
    ].find(
      (o) => typeof o == "string" && o.trim().length > 0
    );
  }
  static getCanonicalVideoUrl(t) {
    const e = t ?? W.getCurrentVideoId();
    return e ? `https://youtu.be/${encodeURIComponent(e)}` : void 0;
  }
  static getSubtitles(t) {
    const i = W.getPlayerResponse()?.captions?.playerCaptionsTracklistRenderer;
    if (!i)
      return [];
    const s = i.captionTracks ?? [], r = (i.translationLanguages ?? []).find(
      (c) => c.languageCode === t
    ), l = s.find(
      (c) => c?.kind === "asr"
    )?.languageCode ?? "en";
    return s.reduce((c, d) => {
      if (!d.languageCode || !d.baseUrl)
        return c;
      const h = X(d.languageCode);
      if (!h)
        return c;
      const f = d.baseUrl, g = `${f.startsWith("http") ? f : `${window.location.origin}/${f}`}&fmt=json3`;
      return c.push({
        source: "youtube",
        format: "json",
        language: h,
        isAutoGenerated: d.kind === "asr",
        url: g
      }), r && d.isTranslatable && d.languageCode === l && t !== h && c.push({
        source: "youtube",
        format: "json",
        language: t,
        isAutoGenerated: d.kind === "asr",
        translatedFromLanguage: h,
        url: `${g}&tlang=${t}`
      }), c;
    }, []);
  }
  static getLanguage() {
    const t = W.getPlayer()?.getAudioTrack?.()?.getLanguageInfo?.();
    if (t?.id && t.id !== "und")
      return X(t.id.split(".")[0] ?? t.id);
    const i = W.getPlayerResponse()?.captions?.playerCaptionsTracklistRenderer?.captionTracks?.find(
      (s) => s.kind === "asr" && s.languageCode
    );
    return i?.languageCode ? X(i.languageCode) : void 0;
  }
}
const gb = {
  rutube: "ru",
  "ok.ru": "ru",
  mail_ru: "ru",
  weverse: "ko",
  niconico: "ja",
  youku: "zh",
  bilibili: "zh",
  weibo: "zh",
  zdf: "de"
}, Aa = ".ytp-volume-panel [aria-valuenow]", mb = 35, pb = 500, yb = new Set(
  Bt
), Me = /* @__PURE__ */ new Map();
function ss(n) {
  if (typeof n == "string")
    try {
      const t = new URL(n, globalThis.location.href);
      return decodeURIComponent(
        t.pathname.split("/").pop() || ""
      ).replace(/\.[^.]+$/u, "").trim() || void 0;
    } catch {
      return;
    }
}
function xa() {
  const n = Array.from(
    document.querySelectorAll('[data-is-tooltip-wrapper="true"] > span')
  ).map((o) => o.textContent?.trim() ?? "").find((o) => /\.(mp4|mkv|mov|webm|avi|m4v)$/i.test(o)) || "", t = document.querySelector('meta[property="og:title"], meta[name="title"]')?.getAttribute("content")?.trim() || "", e = document.querySelector(
    'h1, [role="heading"], div[role="heading"], [data-tooltip]'
  )?.textContent?.trim() || "", i = String(document.title || "").trim(), s = n || t || e || i;
  if (s)
    return s.replace(/\s*-\s*Google Drive\s*$/i, "").replace(/\s*-\s*Google Диск\s*$/i, "").trim();
}
function en(n) {
  if (typeof n != "string") return !0;
  const t = n.trim();
  return t ? /^youtube$/i.test(t) || /^google drive$/i.test(t) || /^google диск$/i.test(t) || /^[A-Za-z0-9_-]{20,}$/.test(t) : !0;
}
function se(n) {
  return typeof n != "string" ? void 0 : n.replace(/\s*-\s*Google Drive\s*$/i, "").replace(/\s*-\s*Google Диск\s*$/i, "").trim() || void 0;
}
async function bb(n) {
  try {
    const t = await I.get(`googledrive:title:${n}`);
    return se(t);
  } catch {
    return;
  }
}
function vb(n) {
  const t = n.split(/[?#]/u, 1)[0]?.toLowerCase() ?? "";
  return t.endsWith(".srt") ? "srt" : t.endsWith(".json") ? "json" : "vtt";
}
function wb(n) {
  return n === "custom" ? String(globalThis.location.hostname || "native").trim() || "native" : n || String(globalThis.location.hostname || "native").trim();
}
function Va(n, t) {
  const e = [], i = Array.from(n.querySelectorAll("track"));
  for (const s of i) {
    const o = String(s.kind || s.getAttribute("kind") || "").trim().toLowerCase();
    if (o === "metadata")
      continue;
    const r = String(
      s.srclang || s.track?.language || s.getAttribute("srclang") || ""
    ).trim().toLowerCase(), a = String(s.src || s.getAttribute("src") || "").trim();
    if (!r || !a)
      continue;
    let l = a;
    try {
      l = new URL(a, document.baseURI).href;
    } catch {
    }
    e.push({
      language: r,
      url: l,
      format: vb(l),
      source: t,
      isAutoGenerated: o === "captions"
    });
  }
  return e;
}
function os(n, t) {
  const e = [], i = /* @__PURE__ */ new Set(), s = (o) => {
    if (Array.isArray(o))
      for (const r of o) {
        if (!r || typeof r != "object")
          continue;
        const a = r;
        if (typeof a.language != "string" || typeof a.url != "string" || typeof a.source != "string" || typeof a.format != "string")
          continue;
        const l = [
          a.source,
          a.language,
          a.translatedFromLanguage ?? "",
          a.url
        ].join("|");
        i.has(l) || (i.add(l), e.push({
          language: a.language,
          url: a.url,
          source: a.source,
          format: a.format,
          translatedFromLanguage: typeof a.translatedFromLanguage == "string" ? a.translatedFromLanguage : void 0,
          isAutoGenerated: typeof a.isAutoGenerated == "boolean" ? a.isAutoGenerated : void 0
        }));
      }
  };
  return s(n), s(t), e;
}
function Oe(n) {
  if (typeof n != "string") return !0;
  const t = n.trim().toLowerCase();
  return t ? t === "undefined" || t === "null" || t.startsWith("blob:") || t.includes("/frame/") || /\/s\d+\/v[\d.]+\/frame\/?$/i.test(t) || t.includes("okcdn.ru/?") || /[?&]bytes=\d+-\d+/i.test(t) || /[?&]type=\d+/i.test(t) : !0;
}
function jn(n, t) {
  if (typeof n != "string")
    return !1;
  const e = n.trim();
  if (!e)
    return !1;
  if (e === t)
    return !0;
  try {
    const i = new URL(e, globalThis.location.href), s = new URL(t, globalThis.location.href);
    if (i.hash = "", s.hash = "", i.toString() === s.toString())
      return !0;
    if (i.origin !== s.origin || i.pathname !== s.pathname)
      return !1;
    const o = (r) => Array.from(r.searchParams.entries()).sort(([a, l], [c, d]) => a === c ? l.localeCompare(d) : a.localeCompare(c)).map(([a, l]) => `${a}=${l}`).join("&");
    return o(i) === o(s);
  } catch {
    return !1;
  }
}
function Rs(n) {
  if (typeof n != "string") return !0;
  const t = n.trim().toLowerCase();
  if (!t) return !0;
  const e = /\.m3u8([?#]|$)/i.test(t) || /\.mpd([?#]|$)/i.test(t);
  return t.startsWith("blob:") || t.startsWith("data:") || t.includes("/frame/") || /\/s\d+\/v[\d.]+\/frame\/?$/i.test(t) || t.includes("okcdn.ru/?") || /[?&]bytes=\d+-\d+/i.test(t) || !e && /[?&]type=\d+/i.test(t);
}
function Sb(...n) {
  for (const t of n) {
    if (typeof t != "string")
      continue;
    const e = t.trim();
    if (!(!e || Rs(e)))
      return e;
  }
  return "";
}
function Tb(n, t, e) {
  return !e || Rs(e.url) ? !1 : Rs(n) || Oe(t) || /^https?:\/\//i.test(e.url) && !/^https?:\/\//i.test(String(n || "").trim());
}
function kb(n) {
  return /^(www|m)\.bilibili\.com$/i.test(String(n || "").trim());
}
function Ae(n) {
  const t = Me.get(n);
  if (t)
    return t;
  const e = {};
  for (Me.set(n, e); Me.size > pb; ) {
    const i = Me.keys().next().value;
    if (typeof i != "string")
      break;
    Me.delete(i);
  }
  return e;
}
function de(n) {
  if (typeof n != "string") return;
  const t = n.toLowerCase().split(/[-_]/)[0];
  return yb.has(t) ? t : void 0;
}
function ge(n) {
  return !!(n && n !== "auto");
}
function Lb(n, t) {
  return Xy(typeof n == "string" ? n : "", typeof t == "string" ? t : void 0);
}
function Ab(n) {
  const t = gb[n];
  if (t)
    return t;
  if (n === "vk") {
    const e = document.getElementsByTagName("track")?.[0]?.srclang;
    return de(e);
  }
}
function xb(n) {
  if (!Array.isArray(n) || n.length === 0)
    return;
  const t = (e) => {
    for (const i of n) {
      if (!i || typeof i != "object")
        continue;
      const s = i;
      if (s.source !== "youtube" || typeof s.translatedFromLanguage == "string" || e && s.isAutoGenerated === !0)
        continue;
      const o = de(s.language);
      if (ge(o))
        return o;
    }
  };
  return t(!0) ?? t(!1);
}
async function Ca(n) {
  if (n.isStream)
    return { detectedLanguage: "auto" };
  if (n.userOverrideLanguage)
    return { detectedLanguage: n.userOverrideLanguage };
  const t = Ab(n.host);
  if (ge(t))
    return {
      detectedLanguage: t,
      cacheLanguage: t
    };
  const e = de(
    n.possibleLanguage
  );
  if (ge(e))
    return {
      detectedLanguage: e,
      cacheLanguage: e
    };
  const i = n.host === "youtube" ? xb(n.subtitles) : void 0;
  if (ge(i))
    return {
      detectedLanguage: i,
      cacheLanguage: i
    };
  if (n.cachedDetectedLanguage)
    return { detectedLanguage: n.cachedDetectedLanguage };
  if (!n.allowTextLanguageDetection)
    return { detectedLanguage: "auto" };
  const s = Lb(n.title, n.description);
  if (!s || s.length < mb)
    return { detectedLanguage: "auto" };
  const o = await n.detectLanguage(s);
  return o ? {
    detectedLanguage: o,
    cacheLanguage: o
  } : { detectedLanguage: "auto" };
}
function Ea(n) {
  const t = document.querySelector(n), e = t?.getAttribute("aria-valuenow"), i = t?.getAttribute("aria-valuemax"), s = e == null ? Number.NaN : Number.parseFloat(e), o = i == null ? Number.NaN : Number.parseFloat(i);
  return Number.isFinite(s) ? Number.isFinite(o) && o > 0 ? Rt(s / o * 100) : Rt(s) : null;
}
class Vb {
  constructor(t) {
    u(this, "videoHandler");
    this.videoHandler = t;
  }
  setDetectedLanguageCache(t, e) {
    Ae(t).detectedLanguage = e;
  }
  rememberUserLanguageSelection(t, e) {
    const i = de(e);
    if (!ge(i)) {
      const o = Me.get(t);
      o && delete o.userLanguageOverride;
      return;
    }
    const s = Ae(t);
    s.userLanguageOverride = i, s.detectedLanguage = i;
  }
  rememberDetectedLanguage(t, e) {
    const i = de(e);
    ge(i) && (this.setDetectedLanguageCache(t, i), this.videoHandler.videoData?.videoId === t && (this.videoHandler.videoData.detectedLanguage = i));
  }
  async detectLanguageSingleFlight(t, e) {
    const i = Ae(t), s = i.detectInFlight;
    if (s !== void 0)
      return s;
    const o = (async () => {
      const r = de(await tb(e));
      return ge(r) ? r : void 0;
    })();
    i.detectInFlight = o;
    try {
      return await o;
    } finally {
      i.detectInFlight === o && delete i.detectInFlight;
    }
  }
  async ensureDetectedLanguageForTranslation(t) {
    if (!t?.videoId || t.detectedLanguage !== "auto")
      return;
    const e = Ae(t.videoId), { detectedLanguage: i, cacheLanguage: s } = await Ca({
      isStream: t.isStream,
      host: this.videoHandler.site.host,
      possibleLanguage: t.detectedLanguage,
      subtitles: t.subtitles,
      userOverrideLanguage: e.userLanguageOverride,
      cachedDetectedLanguage: e.detectedLanguage,
      title: t.title,
      description: t.description,
      allowTextLanguageDetection: !0,
      detectLanguage: async (o) => await this.detectLanguageSingleFlight(t.videoId, o)
    });
    s && this.setDetectedLanguageCache(t.videoId, s), i !== "auto" && (t.detectedLanguage = i, this.videoHandler.translateFromLang === "auto" && (this.videoHandler.translateFromLang = i));
  }
  shouldUseRuntimeYouTubeHelper() {
    return this.videoHandler.site.host === "youtube" && Eu(this.videoHandler.site.additionalData);
  }
  buildRuntimeYouTubeVideoData() {
    const t = W.getCurrentVideoId();
    if (!t)
      throw new Error("Failed to resolve mobile YouTube video id");
    const e = W.getPlayerResponse(), i = W.getPlayerData(), s = W.getSubtitles(p.lang);
    let o = W.getLanguage();
    o && !Bt.includes(o) && (o = void 0);
    const r = e?.videoDetails?.title || i?.title || document.title;
    return {
      url: W.getCanonicalVideoUrl(t) || `https://www.youtube.com/watch?v=${encodeURIComponent(t)}`,
      videoId: t,
      host: "youtube",
      title: r,
      localizedTitle: i?.title || r,
      description: e?.videoDetails?.shortDescription,
      detectedLanguage: o ?? "auto",
      subtitles: s,
      duration: W.getVideoDuration(this.videoHandler.video) ?? this.videoHandler.video?.duration ?? et.defaultDuration,
      translationHelp: null,
      isStream: !!(e?.videoDetails?.isLive || e?.videoDetails?.isLiveContent)
    };
  }
  async getVideoData() {
    const t = String(globalThis.location.href || "").trim(), e = String(globalThis.location.hostname || "").trim(), i = mu(), s = String(
      this.videoHandler.video.currentSrc || this.videoHandler.video.src || ""
    ).trim(), o = Va(
      this.videoHandler.video,
      wb(this.videoHandler.site.host)
    );
    let r, a;
    try {
      a = this.shouldUseRuntimeYouTubeHelper() ? this.buildRuntimeYouTubeVideoData() : await th(this.videoHandler.site, {
        fetchFn: ut,
        video: this.videoHandler.video,
        language: p.lang
      });
    } catch (V) {
      r = V, console.warn(
        "[VOT][fallback:getVideoData] site getVideoData() failed, using DOM fallback",
        {
          siteHost: this.videoHandler.site.host,
          hostname: e,
          error: V
        }
      ), a = {
        duration: this.videoHandler.video?.duration || et.defaultDuration,
        url: "",
        videoId: "",
        host: this.videoHandler.site.host,
        title: document.title,
        translationHelp: null,
        localizedTitle: document.title,
        description: void 0,
        detectedLanguage: "auto",
        subtitles: o,
        isStream: !1
      };
    }
    let {
      duration: l,
      url: c,
      videoId: d,
      host: h,
      title: f,
      translationHelp: g = null,
      localizedTitle: m,
      description: v,
      detectedLanguage: S,
      subtitles: T,
      isStream: w = !1
    } = a;
    T = os(T, o), this.videoHandler.site.host === "vk" && (T = os(
      T,
      Hy("vk", d)
    ));
    const A = await ub(e, t), P = this.videoHandler.site.host === "youtube" ? W.getCurrentVideoId() : void 0, _ = this.videoHandler.site.host === "youtube" && P ? W.getCanonicalVideoUrl(P) : void 0;
    if (this.videoHandler.site.host === "custom" || !!r || Tb(c, d, A)) {
      const V = this.videoHandler.site.host === "bilibili" && kb(e), E = Sb(
        A?.url,
        i,
        s,
        c,
        _,
        t
      );
      if (E && !V && (c = E), Oe(d) || jn(d, t)) {
        const H = !Oe(E) && !jn(E, t) ? E : "", G = !Oe(P) && !jn(String(P || ""), t) ? String(P).trim() : "", nt = !Oe(A?.videoId) && !jn(String(A?.videoId || ""), t) ? String(A?.videoId).trim() : "";
        d = H || G || nt || t;
      }
      V ? (c = t, h = "bilibili", d = Oe(d) ? t : d) : h = this.videoHandler.site.host === "youtube" && P ? "youtube" : "custom";
      const F = A?.title || ss(c) || (typeof document.title == "string" ? document.title.trim() : void 0);
      F && (f = F, m || (m = F)), console.log("[VOT][fallback:getVideoData] using DOM/media fallback", {
        siteHost: this.videoHandler.site.host,
        sniffedManifestUrl: i,
        mediaUrl: s,
        pageUrl: t,
        resolvedFallback: A,
        finalUrl: c,
        finalVideoId: d,
        finalHost: h,
        preservedSiteRoute: V
      });
    }
    if (this.videoHandler.site.host === "googledrive") {
      T = os(
        T,
        Va(this.videoHandler.video, "googledrive")
      );
      const V = se(xa()), E = await bb(d), F = se(f), H = se(m), G = en(F) ? en(E) ? en(V) ? en(H) ? void 0 : H : V : E : F;
      G && (f = G, en(m) && (m = G));
    }
    const Q = Ae(d), { detectedLanguage: Y, cacheLanguage: at } = await Ca({
      isStream: w,
      host: this.videoHandler.site.host,
      possibleLanguage: S,
      subtitles: T,
      userOverrideLanguage: Q.userLanguageOverride,
      cachedDetectedLanguage: Q.detectedLanguage,
      title: f,
      description: v,
      allowTextLanguageDetection: !1,
      detectLanguage: async (V) => await this.detectLanguageSingleFlight(d, V)
    });
    if (at && this.setDetectedLanguageCache(d, at), h === "custom") {
      const V = ss(c) || (typeof document.title == "string" ? document.title.trim() : void 0);
      V && (f = V, m || (m = V));
    }
    const k = {
      translationHelp: g,
      isStream: w,
      duration: l || this.videoHandler.video?.duration || et.defaultDuration,
      videoId: d,
      url: c,
      host: h,
      detectedLanguage: Y,
      responseLanguage: this.videoHandler.translateToLang,
      subtitles: T,
      title: f,
      localizedTitle: m,
      description: v,
      downloadTitle: this.videoHandler.site.host === "googledrive" ? se(f) ?? se(m) ?? se(xa()) ?? d : h === "custom" ? ss(c) ?? f ?? m ?? d : m ?? f ?? d
    };
    return Q.lastLoggedDetectedLanguage !== Y && (console.log("[VOT] Detected language:", Y), Q.lastLoggedDetectedLanguage = Y), Array.isArray(k.subtitles) && k.subtitles.length > 0 && (console.log(
      `[VOT][subtitles] video data contains ${k.subtitles.length} subtitle track(s).`
    ), console.table(
      k.subtitles.map((V, E) => ({
        index: E,
        language: V.language,
        translatedFromLanguage: V.translatedFromLanguage ?? "",
        source: V.source,
        isAutoGenerated: !!V.isAutoGenerated,
        url: V.url
      }))
    )), k;
  }
  async videoValidator() {
    const t = this.videoHandler.videoData, e = this.videoHandler.data;
    if (!t || !e)
      throw new bt("VOTNoVideoIDFound");
    if (C.log("VideoValidator videoData: ", this.videoHandler.videoData), this.videoHandler.data.enabledDontTranslateLanguages && this.videoHandler.data.dontTranslateLanguages?.includes(
      this.videoHandler.videoData.detectedLanguage
    ))
      throw new bt("VOTDisableFromYourLang");
    if (this.videoHandler.videoData.isStream)
      throw new bt("VOTStreamNotAvailable");
    if (this.videoHandler.videoData.duration > 14400)
      throw new bt("VOTVideoIsTooLong");
    const i = hu(this.videoHandler.video);
    if (!i.ready)
      throw new bt(i.localizationKey);
    return !0;
  }
  /**
   * Gets current video volume (0.0 - 1.0)
   */
  getVideoVolume() {
    const t = this.videoHandler.video;
    if (t) {
      if (Hn(this.videoHandler.site.host)) {
        const e = Ea(Aa);
        if (e != null)
          return sb(e);
        const i = W.getVolume();
        if (typeof i == "number" && Number.isFinite(i))
          return fe(i);
      }
      return fe(t.volume);
    }
  }
  /**
   * Sets the video volume
   */
  setVideoVolume(t) {
    const e = fe(t);
    if (!Hn(this.videoHandler.site.host))
      return this.videoHandler.video.volume = e, this;
    try {
      const i = W.setVolume(e);
      if (typeof i == "boolean" && i || typeof i == "number" && Number.isFinite(i)) return this;
    } catch {
    }
    return this.videoHandler.video.volume = e, this;
  }
  /**
   * Checks if the video is muted
   */
  isMuted() {
    return Hn(this.videoHandler.site.host) ? W.isMuted() : this.videoHandler.video?.muted;
  }
  /**
   * Syncs the video volume slider with the actual video volume.
   */
  syncVideoVolumeSlider() {
    const t = this.videoHandler.uiManager.votOverlayView;
    if (!t?.isInitialized()) return this;
    const e = Hn(this.videoHandler.site.host) ? Ea(Aa) : null, i = this.isMuted() ? 0 : e ?? Cu(this.getVideoVolume() ?? 0);
    return t.videoVolumeSlider.value = i, this.videoHandler.onVideoVolumeSliderSynced?.(i), this;
  }
  setSelectMenuValues(t, e) {
    const i = this.videoHandler.videoData;
    if (!i)
      return this;
    const s = de(t) ?? "auto", o = `${s}->${e}`, r = Ae(i.videoId);
    r.lastLoggedLangPair !== o && (console.log(`[VOT] Set translation from ${s} to ${e}`), r.lastLoggedLangPair = o), i.detectedLanguage = s, i.responseLanguage = e, this.videoHandler.translateFromLang = s, this.videoHandler.translateToLang = e;
    const a = this.videoHandler.uiManager.votOverlayView;
    return a?.isInitialized() ? (a.languagePairSelect.fromSelect.selectTitle = p.getLangLabel(s), a.languagePairSelect.toSelect.selectTitle = p.getLangLabel(e), a.languagePairSelect.fromSelect.setSelectedValue(s), a.languagePairSelect.toSelect.setSelectedValue(e), this) : this;
  }
}
const pn = globalThis, Ia = (n) => n, bi = pn.trustedTypes, Pa = bi ? bi.createPolicy("lit-html", { createHTML: (n) => n }) : void 0, Iu = "$lit$", Jt = `lit$${Math.random().toFixed(9).slice(2)}$`, Pu = "?" + Jt, Cb = `<${Pu}>`, ve = document, xn = () => ve.createComment(""), Vn = (n) => n === null || typeof n != "object" && typeof n != "function", To = Array.isArray, Eb = (n) => To(n) || typeof n?.[Symbol.iterator] == "function", rs = `[ 	
\f\r]`, nn = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, Ma = /-->/g, Oa = />/g, ne = RegExp(`>|${rs}(?:([^\\s"'>=/]+)(${rs}*=${rs}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Da = /'/g, _a = /"/g, Mu = /^(?:script|style|textarea|title)$/i, Ou = (n) => (t, ...e) => ({ _$litType$: n, strings: t, values: e }), ln = Ou(1), St = Ou(2), Cn = /* @__PURE__ */ Symbol.for("lit-noChange"), rt = /* @__PURE__ */ Symbol.for("lit-nothing"), Ra = /* @__PURE__ */ new WeakMap(), he = ve.createTreeWalker(ve, 129);
function Du(n, t) {
  if (!To(n) || !n.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return Pa !== void 0 ? Pa.createHTML(t) : t;
}
const Ib = (n, t) => {
  const e = n.length - 1, i = [];
  let s, o = t === 2 ? "<svg>" : t === 3 ? "<math>" : "", r = nn;
  for (let a = 0; a < e; a++) {
    const l = n[a];
    let c, d, h = -1, f = 0;
    for (; f < l.length && (r.lastIndex = f, d = r.exec(l), d !== null); ) f = r.lastIndex, r === nn ? d[1] === "!--" ? r = Ma : d[1] !== void 0 ? r = Oa : d[2] !== void 0 ? (Mu.test(d[2]) && (s = RegExp("</" + d[2], "g")), r = ne) : d[3] !== void 0 && (r = ne) : r === ne ? d[0] === ">" ? (r = s ?? nn, h = -1) : d[1] === void 0 ? h = -2 : (h = r.lastIndex - d[2].length, c = d[1], r = d[3] === void 0 ? ne : d[3] === '"' ? _a : Da) : r === _a || r === Da ? r = ne : r === Ma || r === Oa ? r = nn : (r = ne, s = void 0);
    const g = r === ne && n[a + 1].startsWith("/>") ? " " : "";
    o += r === nn ? l + Cb : h >= 0 ? (i.push(c), l.slice(0, h) + Iu + l.slice(h) + Jt + g) : l + Jt + (h === -2 ? a : g);
  }
  return [Du(n, o + (n[e] || "<?>") + (t === 2 ? "</svg>" : t === 3 ? "</math>" : "")), i];
};
class En {
  constructor({ strings: t, _$litType$: e }, i) {
    let s;
    this.parts = [];
    let o = 0, r = 0;
    const a = t.length - 1, l = this.parts, [c, d] = Ib(t, e);
    if (this.el = En.createElement(c, i), he.currentNode = this.el.content, e === 2 || e === 3) {
      const h = this.el.content.firstChild;
      h.replaceWith(...h.childNodes);
    }
    for (; (s = he.nextNode()) !== null && l.length < a; ) {
      if (s.nodeType === 1) {
        if (s.hasAttributes()) for (const h of s.getAttributeNames()) if (h.endsWith(Iu)) {
          const f = d[r++], g = s.getAttribute(h).split(Jt), m = /([.?@])?(.*)/.exec(f);
          l.push({ type: 1, index: o, name: m[2], strings: g, ctor: m[1] === "." ? Mb : m[1] === "?" ? Ob : m[1] === "@" ? Db : _i }), s.removeAttribute(h);
        } else h.startsWith(Jt) && (l.push({ type: 6, index: o }), s.removeAttribute(h));
        if (Mu.test(s.tagName)) {
          const h = s.textContent.split(Jt), f = h.length - 1;
          if (f > 0) {
            s.textContent = bi ? bi.emptyScript : "";
            for (let g = 0; g < f; g++) s.append(h[g], xn()), he.nextNode(), l.push({ type: 2, index: ++o });
            s.append(h[f], xn());
          }
        }
      } else if (s.nodeType === 8) if (s.data === Pu) l.push({ type: 2, index: o });
      else {
        let h = -1;
        for (; (h = s.data.indexOf(Jt, h + 1)) !== -1; ) l.push({ type: 7, index: o }), h += Jt.length - 1;
      }
      o++;
    }
  }
  static createElement(t, e) {
    const i = ve.createElement("template");
    return i.innerHTML = t, i;
  }
}
function Ue(n, t, e = n, i) {
  if (t === Cn) return t;
  let s = i !== void 0 ? e._$Co?.[i] : e._$Cl;
  const o = Vn(t) ? void 0 : t._$litDirective$;
  return s?.constructor !== o && (s?._$AO?.(!1), o === void 0 ? s = void 0 : (s = new o(n), s._$AT(n, e, i)), i !== void 0 ? (e._$Co ?? (e._$Co = []))[i] = s : e._$Cl = s), s !== void 0 && (t = Ue(n, s._$AS(n, t.values), s, i)), t;
}
class Pb {
  constructor(t, e) {
    this._$AV = [], this._$AN = void 0, this._$AD = t, this._$AM = e;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t) {
    const { el: { content: e }, parts: i } = this._$AD, s = (t?.creationScope ?? ve).importNode(e, !0);
    he.currentNode = s;
    let o = he.nextNode(), r = 0, a = 0, l = i[0];
    for (; l !== void 0; ) {
      if (r === l.index) {
        let c;
        l.type === 2 ? c = new Dn(o, o.nextSibling, this, t) : l.type === 1 ? c = new l.ctor(o, l.name, l.strings, this, t) : l.type === 6 && (c = new _b(o, this, t)), this._$AV.push(c), l = i[++a];
      }
      r !== l?.index && (o = he.nextNode(), r++);
    }
    return he.currentNode = ve, s;
  }
  p(t) {
    let e = 0;
    for (const i of this._$AV) i !== void 0 && (i.strings !== void 0 ? (i._$AI(t, i, e), e += i.strings.length - 2) : i._$AI(t[e])), e++;
  }
}
class Dn {
  get _$AU() {
    return this._$AM?._$AU ?? this._$Cv;
  }
  constructor(t, e, i, s) {
    this.type = 2, this._$AH = rt, this._$AN = void 0, this._$AA = t, this._$AB = e, this._$AM = i, this.options = s, this._$Cv = s?.isConnected ?? !0;
  }
  get parentNode() {
    let t = this._$AA.parentNode;
    const e = this._$AM;
    return e !== void 0 && t?.nodeType === 11 && (t = e.parentNode), t;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t, e = this) {
    t = Ue(this, t, e), Vn(t) ? t === rt || t == null || t === "" ? (this._$AH !== rt && this._$AR(), this._$AH = rt) : t !== this._$AH && t !== Cn && this._(t) : t._$litType$ !== void 0 ? this.$(t) : t.nodeType !== void 0 ? this.T(t) : Eb(t) ? this.k(t) : this._(t);
  }
  O(t) {
    return this._$AA.parentNode.insertBefore(t, this._$AB);
  }
  T(t) {
    this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
  }
  _(t) {
    this._$AH !== rt && Vn(this._$AH) ? this._$AA.nextSibling.data = t : this.T(ve.createTextNode(t)), this._$AH = t;
  }
  $(t) {
    const { values: e, _$litType$: i } = t, s = typeof i == "number" ? this._$AC(t) : (i.el === void 0 && (i.el = En.createElement(Du(i.h, i.h[0]), this.options)), i);
    if (this._$AH?._$AD === s) this._$AH.p(e);
    else {
      const o = new Pb(s, this), r = o.u(this.options);
      o.p(e), this.T(r), this._$AH = o;
    }
  }
  _$AC(t) {
    let e = Ra.get(t.strings);
    return e === void 0 && Ra.set(t.strings, e = new En(t)), e;
  }
  k(t) {
    To(this._$AH) || (this._$AH = [], this._$AR());
    const e = this._$AH;
    let i, s = 0;
    for (const o of t) s === e.length ? e.push(i = new Dn(this.O(xn()), this.O(xn()), this, this.options)) : i = e[s], i._$AI(o), s++;
    s < e.length && (this._$AR(i && i._$AB.nextSibling, s), e.length = s);
  }
  _$AR(t = this._$AA.nextSibling, e) {
    for (this._$AP?.(!1, !0, e); t !== this._$AB; ) {
      const i = Ia(t).nextSibling;
      Ia(t).remove(), t = i;
    }
  }
  setConnected(t) {
    this._$AM === void 0 && (this._$Cv = t, this._$AP?.(t));
  }
}
class _i {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(t, e, i, s, o) {
    this.type = 1, this._$AH = rt, this._$AN = void 0, this.element = t, this.name = e, this._$AM = s, this.options = o, i.length > 2 || i[0] !== "" || i[1] !== "" ? (this._$AH = Array(i.length - 1).fill(new String()), this.strings = i) : this._$AH = rt;
  }
  _$AI(t, e = this, i, s) {
    const o = this.strings;
    let r = !1;
    if (o === void 0) t = Ue(this, t, e, 0), r = !Vn(t) || t !== this._$AH && t !== Cn, r && (this._$AH = t);
    else {
      const a = t;
      let l, c;
      for (t = o[0], l = 0; l < o.length - 1; l++) c = Ue(this, a[i + l], e, l), c === Cn && (c = this._$AH[l]), r || (r = !Vn(c) || c !== this._$AH[l]), c === rt ? t = rt : t !== rt && (t += (c ?? "") + o[l + 1]), this._$AH[l] = c;
    }
    r && !s && this.j(t);
  }
  j(t) {
    t === rt ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
  }
}
class Mb extends _i {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t) {
    this.element[this.name] = t === rt ? void 0 : t;
  }
}
class Ob extends _i {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t) {
    this.element.toggleAttribute(this.name, !!t && t !== rt);
  }
}
class Db extends _i {
  constructor(t, e, i, s, o) {
    super(t, e, i, s, o), this.type = 5;
  }
  _$AI(t, e = this) {
    if ((t = Ue(this, t, e, 0) ?? rt) === Cn) return;
    const i = this._$AH, s = t === rt && i !== rt || t.capture !== i.capture || t.once !== i.once || t.passive !== i.passive, o = t !== rt && (i === rt || s);
    s && this.element.removeEventListener(this.name, this, i), o && this.element.addEventListener(this.name, this, t), this._$AH = t;
  }
  handleEvent(t) {
    typeof this._$AH == "function" ? this._$AH.call(this.options?.host ?? this.element, t) : this._$AH.handleEvent(t);
  }
}
class _b {
  constructor(t, e, i) {
    this.element = t, this.type = 6, this._$AN = void 0, this._$AM = e, this.options = i;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t) {
    Ue(this, t);
  }
}
const Rb = pn.litHtmlPolyfillSupport;
Rb?.(En, Dn), (pn.litHtmlVersions ?? (pn.litHtmlVersions = [])).push("3.3.2");
const wt = (n, t, e) => {
  const i = t;
  let s = i._$litPart$;
  return s === void 0 && (i._$litPart$ = s = new Dn(t.insertBefore(xn(), null), null, void 0, {})), s._$AI(n), s;
};
function Bb() {
  if (globalThis.__votKeyboardNavInitialized) return;
  globalThis.__votKeyboardNavInitialized = !0;
  const n = document.documentElement, t = "vot-keyboard-nav", e = () => n.classList.add(t), i = () => n.classList.remove(t);
  globalThis.addEventListener(
    "keydown",
    (s) => {
      s.key === "Tab" && e();
    },
    !0
  );
  for (const s of ["pointerdown", "mousedown", "touchstart"])
    globalThis.addEventListener(s, i, {
      capture: !0,
      passive: !0
    });
}
Bb();
const L = {
  /**
   * Makes a non-native element behave like a button (keyboard + ARIA).
   *
   * We use custom tags (`vot-block`) for isolation, so we must re-add
   * basic semantics for accessibility.
   */
  makeButtonLike(n, { ariaLabel: t } = {}) {
    n.setAttribute("role", "button"), n.hasAttribute("tabindex") || (n.tabIndex = 0);
    const e = n.tabIndex, i = () => {
      n.getAttribute("disabled") === "true" ? (n.setAttribute("aria-disabled", "true"), n.tabIndex = -1) : (n.removeAttribute("aria-disabled"), n.tabIndex = e);
    };
    return i(), new MutationObserver(() => i()).observe(n, {
      attributes: !0,
      attributeFilter: ["disabled"]
    }), t && n.setAttribute("aria-label", t), n.addEventListener("keydown", (s) => {
      n.getAttribute("disabled") === "true" || n.getAttribute("aria-disabled") === "true" || (s.key === "Enter" || s.key === " ") && (s.preventDefault(), n.click());
    }), n;
  },
  /**
   * Auxiliary method for creating HTML elements
   */
  createEl(n, t = [], e = null) {
    const i = document.createElement(n);
    return t.length && i.classList.add(...t), e !== null && i.append(e), i;
  },
  /**
   * Create header element
   */
  createHeader(n, t = 4) {
    return L.createEl(
      "vot-block",
      ["vot-header", `vot-header-level-${t}`],
      n
    );
  },
  /**
   * Create information element
   */
  createInformation(n, t) {
    const e = L.createEl("vot-block", ["vot-info"]), i = L.createEl("vot-block");
    wt(n, i);
    const s = L.createEl("vot-block");
    return wt(t, s), e.append(i, s), { container: e, header: i, value: s };
  },
  /**
   * Create button
   */
  createButton(n) {
    const t = L.createEl("vot-block", ["vot-button"], n);
    return L.makeButtonLike(t);
  },
  /**
   * Create text button
   */
  createTextButton(n) {
    const t = L.createEl("vot-block", ["vot-text-button"], n);
    return L.makeButtonLike(t);
  },
  /**
   * Create outlined button
   */
  createOutlinedButton(n) {
    const t = L.createEl("vot-block", ["vot-outlined-button"], n);
    return L.makeButtonLike(t);
  },
  /**
   * Create icon button
   */
  createIconButton(n, t = {}) {
    const e = L.createEl("vot-block", ["vot-icon-button"]);
    return wt(n, e), L.makeButtonLike(e, t);
  },
  createInlineLoader() {
    return L.createEl("vot-block", ["vot-inline-loader"]);
  },
  createPortal(n = !1) {
    return L.createEl("vot-block", [`vot-portal${n ? "-local" : ""}`]);
  },
  createSubtitleInfo(n, t, e) {
    const i = L.createEl("vot-block", ["vot-subtitles-info"]);
    i.id = "vot-subtitles-info";
    const s = L.createEl(
      "vot-block",
      ["vot-subtitles-info-service"],
      p.get("VOTTranslatedBy").replace("{0}", e)
    ), o = L.createEl(
      "vot-block",
      ["vot-subtitles-info-header"],
      n
    ), r = L.createEl(
      "vot-block",
      ["vot-subtitles-info-context"],
      t
    );
    return i.append(s, o, r), {
      container: i,
      translatedWith: s,
      header: o,
      context: r
    };
  }
}, Fb = ["left", "top", "right", "bottom"], Nb = ["hover", "click"], le = class le {
  constructor({
    target: t,
    anchor: e = void 0,
    content: i = "",
    position: s = "top",
    trigger: o = "hover",
    offset: r = 4,
    maxWidth: a = void 0,
    hidden: l = !1,
    autoLayout: c = !0,
    backgroundColor: d = void 0,
    borderRadius: h = void 0,
    bordered: f = !0,
    parentElement: g = document.body,
    layoutRoot: m = document.documentElement
  }) {
    /** Whether tooltip element is currently mounted. */
    u(this, "showed", !1);
    u(this, "target");
    u(this, "anchor");
    u(this, "content");
    u(this, "position");
    u(this, "preferredPosition");
    u(this, "trigger");
    u(this, "parentElement");
    u(this, "layoutRoot");
    u(this, "offsetX");
    u(this, "offsetY");
    u(this, "_hidden");
    u(this, "autoLayout");
    u(this, "pageWidth");
    u(this, "pageHeight");
    u(this, "globalOffsetX");
    u(this, "globalOffsetY");
    u(this, "maxWidth");
    u(this, "backgroundColor");
    u(this, "borderRadius");
    u(this, "_bordered");
    u(this, "container");
    u(this, "onResizeObserver");
    u(this, "intersectionObserver");
    u(this, "scrollListening", !1);
    u(this, "positionRafId", null);
    u(this, "destroyFallbackTimerId");
    // Accessibility: link trigger -> tooltip via aria-describedby.
    u(this, "tooltipId", typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `vot-tooltip-${Math.random().toString(36).slice(2)}`);
    u(this, "prevAriaDescribedBy", null);
    u(this, "onResize", () => {
      this.schedulePositionUpdate();
    });
    u(this, "onClick", () => {
      this.showed ? this.destroy() : this.create();
    });
    u(this, "onTargetKeyDown", (t) => {
      t.key !== "Escape" || !this.showed || this.destroy();
    });
    u(this, "onScroll", () => {
      this.schedulePositionUpdate();
    });
    u(this, "onHoverPointerDown", (t) => {
      t.pointerType !== "mouse" && this.create();
    });
    u(this, "onHoverPointerUp", (t) => {
      t.pointerType !== "mouse" && this.destroy();
    });
    u(this, "onMouseEnter", () => {
      this.create();
    });
    u(this, "onMouseLeave", (t) => {
      this.isInTooltipContext(t.relatedTarget) || this.destroy();
    });
    u(this, "onTooltipMouseLeave", (t) => {
      this.isInTooltipContext(t.relatedTarget) || this.destroy();
    });
    u(this, "onIntersect", ([t]) => {
      if (!t.isIntersecting)
        return this.destroy(!0);
    });
    if (!(t instanceof HTMLElement))
      throw new TypeError("target must be a valid HTMLElement");
    this.target = t, this.anchor = e instanceof HTMLElement ? e : t, this.content = i, typeof r == "number" ? this.offsetY = this.offsetX = r : (this.offsetX = r.x, this.offsetY = r.y), this._hidden = l, this.autoLayout = c, this.trigger = le.validateTrigger(o) ? o : "hover", this.position = le.validatePos(s) ? s : "top", this.preferredPosition = this.position, this.parentElement = g, this.layoutRoot = m, this.borderRadius = h, this._bordered = f, this.maxWidth = a, this.backgroundColor = d, this.updatePageSize(), this.init();
  }
  static validatePos(t) {
    return Fb.includes(t);
  }
  static validateTrigger(t) {
    return Nb.includes(t);
  }
  setPosition(t) {
    return this.preferredPosition = le.validatePos(t) ? t : "top", this.position = this.preferredPosition, this.schedulePositionUpdate(), this;
  }
  setContent(t) {
    return this.content = t, this.container ? (this.container.replaceChildren(), typeof t == "string" ? this.container.textContent = t : this.container.append(t), this.schedulePositionUpdate(), this) : this;
  }
  /**
   * Update tooltip mount dependencies.
   * If the tooltip is currently rendered, it will be moved to the new parent.
   */
  updateMount({
    parentElement: t,
    layoutRoot: e
  }) {
    return t && this.parentElement !== t && (this.parentElement = t, this.container?.isConnected && t.appendChild(this.container)), e && this.layoutRoot !== e && (this.layoutRoot = e), this.schedulePositionUpdate(), this;
  }
  isInTooltipContext(t) {
    return t instanceof Node ? this.target.contains(t) || this.container?.contains(t) : !1;
  }
  updatePageSize() {
    if (this.layoutRoot === document.documentElement)
      this.globalOffsetX = 0, this.globalOffsetY = 0;
    else {
      const { left: t, top: e } = this.layoutRoot.getBoundingClientRect();
      this.globalOffsetX = t, this.globalOffsetY = e;
    }
    return this.pageWidth = this.layoutRoot.clientWidth || document.documentElement.clientWidth, this.pageHeight = this.layoutRoot.clientHeight || document.documentElement.clientHeight, this;
  }
  init() {
    return this.onResizeObserver = new ResizeObserver(this.onResize), this.intersectionObserver = new IntersectionObserver(this.onIntersect), this.target.addEventListener("keydown", this.onTargetKeyDown), this.trigger === "click" ? (this.target.addEventListener("pointerdown", this.onClick), this) : (this.target.addEventListener("mouseenter", this.onMouseEnter), this.target.addEventListener("mouseleave", this.onMouseLeave), this.target.addEventListener("focusin", this.onMouseEnter), this.target.addEventListener("focusout", this.onMouseLeave), this.target.addEventListener("pointerdown", this.onHoverPointerDown), this.target.addEventListener("pointerup", this.onHoverPointerUp), this);
  }
  release() {
    return this.destroy(!0), this.detachScrollListener(), this.target.removeEventListener("keydown", this.onTargetKeyDown), this.trigger === "click" ? (this.target.removeEventListener("pointerdown", this.onClick), this) : (this.target.removeEventListener("mouseenter", this.onMouseEnter), this.target.removeEventListener("mouseleave", this.onMouseLeave), this.target.removeEventListener("focusin", this.onMouseEnter), this.target.removeEventListener("focusout", this.onMouseLeave), this.target.removeEventListener("pointerdown", this.onHoverPointerDown), this.target.removeEventListener("pointerup", this.onHoverPointerUp), this);
  }
  schedulePositionUpdate() {
    this.container && this.positionRafId === null && (this.positionRafId = requestAnimationFrame(() => {
      this.positionRafId = null, this.updatePageSize(), this.updatePos();
    }));
  }
  cancelPositionUpdate() {
    this.positionRafId !== null && (cancelAnimationFrame(this.positionRafId), this.positionRafId = null);
  }
  clearDestroyFallbackTimer() {
    this.destroyFallbackTimerId !== void 0 && (globalThis.clearTimeout(this.destroyFallbackTimerId), this.destroyFallbackTimerId = void 0);
  }
  create() {
    return this.destroy(!0), this.showed = !0, this.container = L.createEl("vot-block", ["vot-tooltip"], this.content), this.bordered && this.container.classList.add("vot-tooltip-bordered"), this.container.setAttribute("role", "tooltip"), this.container.id = this.tooltipId, this.container.dataset.trigger = this.trigger, this.container.dataset.position = this.position, this.parentElement.appendChild(this.container), this.schedulePositionUpdate(), this.backgroundColor !== void 0 && (this.container.style.backgroundColor = this.backgroundColor), this.borderRadius !== void 0 && (this.container.style.borderRadius = `${this.borderRadius}px`), this.hidden ? this.container.hidden = !0 : this.syncAriaDescribedBy(!0), this.container.style.opacity = "1", this.trigger === "hover" && this.container.addEventListener("mouseleave", this.onTooltipMouseLeave), this.attachScrollListener(), this.onResizeObserver?.observe(this.layoutRoot), this.anchor !== this.layoutRoot && this.onResizeObserver?.observe(this.anchor), this.intersectionObserver?.observe(this.target), this;
  }
  updatePos() {
    if (!this.container)
      return this;
    const { top: t, left: e } = this.calcPos(this.autoLayout, this.preferredPosition), i = Math.max(0, this.pageWidth - this.offsetX * 2), s = K(this.maxWidth ?? i, 0, i);
    return this.container.style.transform = `translate(${e}px, ${t}px)`, this.container.dataset.position = this.position, this.container.style.maxWidth = `${s}px`, this;
  }
  calcPos(t = !0, e = this.preferredPosition) {
    if (!this.container)
      return { top: 0, left: 0 };
    const {
      left: i,
      right: s,
      top: o,
      bottom: r,
      width: a,
      height: l
    } = this.anchor.getBoundingClientRect(), { width: c, height: d } = this.container.getBoundingClientRect(), h = K(c, 0, this.pageWidth), f = K(d, 0, this.pageHeight), g = i - this.globalOffsetX, m = s - this.globalOffsetX, v = o - this.globalOffsetY, S = r - this.globalOffsetY;
    let T = e;
    if (t)
      switch (e) {
        case "top": {
          K(v - f - this.offsetY, 0, this.pageHeight) + this.offsetY < f && (T = "bottom");
          break;
        }
        case "right": {
          K(m + this.offsetX, 0, this.pageWidth - h) + h > this.pageWidth - this.offsetX && (T = "left");
          break;
        }
        case "bottom": {
          K(
            S + this.offsetY,
            0,
            this.pageHeight - f
          ) + f > this.pageHeight - this.offsetY && (T = "top");
          break;
        }
        case "left": {
          Math.max(0, g - h - this.offsetX) + h > g - this.offsetX && (T = "right");
          break;
        }
      }
    let w;
    switch (T) {
      case "top":
        w = {
          top: K(v - f - this.offsetY, 0, this.pageHeight),
          left: K(
            g - h / 2 + a / 2,
            this.offsetX,
            this.pageWidth - h - this.offsetX
          )
        };
        break;
      case "right":
        w = {
          top: K(
            v + (l - f) / 2,
            this.offsetY,
            this.pageHeight - f - this.offsetY
          ),
          left: K(m + this.offsetX, 0, this.pageWidth - h)
        };
        break;
      case "bottom":
        w = {
          top: K(S + this.offsetY, 0, this.pageHeight - f),
          left: K(
            g - h / 2 + a / 2,
            this.offsetX,
            this.pageWidth - h - this.offsetX
          )
        };
        break;
      case "left":
        w = {
          top: K(
            v + (l - f) / 2,
            this.offsetY,
            this.pageHeight - f - this.offsetY
          ),
          left: Math.max(0, g - h - this.offsetX)
        };
        break;
      default:
        w = { top: 0, left: 0 };
    }
    return this.position = T, {
      top: w.top + this.globalOffsetY,
      left: w.left + this.globalOffsetX
    };
  }
  destroy(t = !1) {
    if (!this.container)
      return this;
    const e = this.container;
    if (this.cancelPositionUpdate(), this.clearDestroyFallbackTimer(), this.showed = !1, this.syncAriaDescribedBy(!1), this.onResizeObserver?.disconnect(), this.intersectionObserver?.disconnect(), this.detachScrollListener(), t)
      return e.remove(), this.container = void 0, this;
    e.removeEventListener("mouseleave", this.onTooltipMouseLeave), e.style.pointerEvents = "none", e.style.opacity = "0";
    const i = () => {
      this.clearDestroyFallbackTimer(), e?.remove(), this.container === e && (this.container = void 0);
    };
    return e.addEventListener("transitionend", i, {
      once: !0
    }), e.addEventListener("transitioncancel", i, {
      once: !0
    }), this.destroyFallbackTimerId = globalThis.setTimeout(
      i,
      le.DESTROY_FALLBACK_MS
    ), this;
  }
  syncAriaDescribedBy(t) {
    const e = this.target.getAttribute("aria-describedby");
    if (this.prevAriaDescribedBy ?? (this.prevAriaDescribedBy = e), !t) {
      this.prevAriaDescribedBy === null ? this.target.removeAttribute("aria-describedby") : this.target.setAttribute("aria-describedby", this.prevAriaDescribedBy), this.prevAriaDescribedBy = null;
      return;
    }
    const i = new Set((e ?? "").split(/\s+/).filter(Boolean));
    i.add(this.tooltipId), this.target.setAttribute("aria-describedby", Array.from(i).join(" "));
  }
  set bordered(t) {
    this._bordered = t, this.container?.classList.toggle("vot-tooltip-bordered", t);
  }
  get bordered() {
    return this._bordered;
  }
  set hidden(t) {
    this._hidden = t, this.container && (this.container.hidden = t), this.showed && this.syncAriaDescribedBy(!t);
  }
  get hidden() {
    return this._hidden;
  }
  attachScrollListener() {
    this.scrollListening || (this.scrollListening = !0, document.addEventListener("scroll", this.onScroll, {
      passive: !0,
      capture: !0
    }));
  }
  detachScrollListener() {
    this.scrollListening && (this.scrollListening = !1, document.removeEventListener("scroll", this.onScroll, {
      capture: !0
    }));
  }
};
u(le, "DESTROY_FALLBACK_MS", 700);
let mt = le;
const Ub = ["srt", "vtt", "ass", "json"], _u = [
  "default-sans",
  "arial",
  "helvetica",
  "roboto",
  "verdana",
  "open-sans",
  "poppins",
  "lato",
  "montserrat",
  "barlow"
], Ba = {
  "default-sans": '"Roboto", "Segoe UI", system-ui, sans-serif',
  arial: 'Arial, "Helvetica Neue", Helvetica, sans-serif',
  helvetica: '"Helvetica Neue", Helvetica, Arial, sans-serif',
  roboto: '"Roboto", "Segoe UI", system-ui, sans-serif',
  verdana: "Verdana, Geneva, sans-serif",
  "open-sans": '"Open Sans", "Segoe UI", system-ui, sans-serif',
  poppins: '"Poppins", "Segoe UI", system-ui, sans-serif',
  lato: '"Lato", "Segoe UI", system-ui, sans-serif',
  montserrat: '"Montserrat", "Segoe UI", system-ui, sans-serif',
  barlow: '"Barlow", "Segoe UI", system-ui, sans-serif'
};
function vi(n) {
  return _u.includes(n);
}
const Bs = "google:", $b = "https://fonts.googleapis.com/css2", Hb = "https://fonts.google.com/metadata/fonts", Wb = {
  roboto: "Roboto",
  "open-sans": "Open Sans",
  poppins: "Poppins",
  lato: "Lato",
  montserrat: "Montserrat",
  barlow: "Barlow"
}, as = /* @__PURE__ */ new Set(), ls = /* @__PURE__ */ new Map();
let sn = null;
function zb(n) {
  return `${Bs}${n}`;
}
function $e(n) {
  if (n.startsWith(Bs)) {
    const t = n.slice(Bs.length).trim();
    return t.length > 0 ? t : null;
  }
  return Wb[n] ?? null;
}
function Fa(n) {
  if (vi(n))
    return Ba[n];
  const t = $e(n);
  return t ? `"${t}", "Segoe UI", system-ui, sans-serif` : Ba["default-sans"];
}
function qb(n) {
  const t = $e(n);
  if (!t)
    return null;
  const e = t.trim().replaceAll(/\s+/g, "+");
  return `${$b}?family=${e}&display=swap`;
}
function Gb(n, t) {
  const e = `vot-google-font-${n}`;
  if (document.getElementById(e))
    return;
  const i = globalThis.GM_addStyle, s = typeof i == "function" ? i(t) : document.createElement("style");
  s instanceof HTMLElement && (s.id = e, s.textContent || (s.textContent = t), s.parentElement || (document.head || document.documentElement).appendChild(s));
}
async function Kb(n, t = {}) {
  if (as.has(n))
    return;
  const e = ls.get(n);
  if (e !== void 0) {
    await e;
    return;
  }
  const i = qb(n);
  if (!i) {
    as.add(n);
    return;
  }
  const s = $e(n), o = (async () => {
    try {
      const r = await ut(i, {
        timeout: 1e4,
        forceGmXhr: t.forceGmXhr ?? !0,
        headers: {
          Accept: "text/css,*/*;q=0.1"
        }
      });
      if (!r.ok)
        throw new Error(
          `Google Fonts CSS request failed with ${r.status}`
        );
      const a = await r.text();
      if (!a.trim())
        throw new Error("Google Fonts CSS response is empty");
      Gb(n, a), as.add(n), document.fonts && s && await document.fonts.load(`500 20px "${s}"`), t.onLoaded?.();
    } catch {
    } finally {
      ls.delete(n);
    }
  })();
  ls.set(n, o), await o;
}
async function Yb() {
  return sn !== null ? await sn : (sn = (async () => {
    const n = await ut(Hb, {
      timeout: 15e3,
      forceGmXhr: Ln
    });
    if (!n.ok)
      throw new Error(
        `Google Fonts metadata request failed with ${n.status}`
      );
    const e = (await n.text()).replace(/^\)\]\}'\n?/, ""), s = JSON.parse(e).familyMetadataList?.map((o) => o.family?.trim() ?? "").filter((o) => o.length > 0);
    return Array.from(new Set(s)).sort(
      (o, r) => o.localeCompare(r)
    );
  })().catch((n) => (sn = null, [])), await sn);
}
class jb {
  constructor({ video: t, container: e }) {
    u(this, "video");
    u(this, "container");
    u(this, "fullscreenLayer", null);
    this.video = t, this.container = e;
  }
  updateContainer(t) {
    this.container = t;
  }
  getWidgetParentElement() {
    return this.shouldUseFullscreenViewportLayer() ? this.ensureFullscreenLayer() : this.container;
  }
  getLayoutRootElement() {
    return this.fullscreenLayer?.isConnected ? this.fullscreenLayer : this.container;
  }
  syncWidgetContainer(t) {
    const e = this.getWidgetParentElement();
    e === this.container && getComputedStyle(this.container).position === "static" && (this.container.style.position = "relative"), t && t.parentElement !== e && e.appendChild(t), e === this.container && this.fullscreenLayer?.parentElement && (this.fullscreenLayer.remove(), this.fullscreenLayer = null);
  }
  release() {
    this.fullscreenLayer && (this.fullscreenLayer.remove(), this.fullscreenLayer = null);
  }
  getActiveFullscreenElement() {
    const t = document, e = t.fullscreenElement ?? t.webkitFullscreenElement;
    return co(
      e,
      [this.container, this.video],
      {
        allowDocumentViewport: !0
      }
    );
  }
  isCurrentVideoInFullscreenSession() {
    const t = this.getActiveFullscreenElement();
    return t ? t === this.container || t.contains(this.container) || this.container.contains(t) ? !0 : !!(this.video && (t === this.video || t.contains(this.video) || this.video.contains(t))) : !1;
  }
  shouldUseFullscreenViewportLayer() {
    return this.isCurrentVideoInFullscreenSession();
  }
  ensureFullscreenLayer() {
    if (!this.fullscreenLayer) {
      const i = document.createElement("vot-block");
      i.classList.add("vot-subtitles-layer"), Object.assign(i.style, {
        position: "absolute",
        inset: "0",
        zIndex: "2147483647",
        pointerEvents: "none"
      }), this.fullscreenLayer = i;
    }
    const t = this.getActiveFullscreenElement(), e = t instanceof HTMLElement ? t : this.container;
    return getComputedStyle(e).position === "static" && (e.style.position = "relative"), this.fullscreenLayer.parentElement !== e && e.appendChild(this.fullscreenLayer), this.fullscreenLayer;
  }
}
function Xb(n, t) {
  return n >= t.startMs && n < t.startMs + t.durationMs;
}
function Jb(n, t) {
  let e = 0, i = t.length - 1;
  for (; e <= i; ) {
    const s = e + i >> 1, o = t[s];
    if (n < o.startMs)
      i = s - 1;
    else if (n >= o.startMs + o.durationMs)
      e = s + 1;
    else
      return s;
  }
  return -1;
}
function Xt(n, t, e) {
  return Math.max(t, Math.min(n, e));
}
function Zb(n, t, e, i, s) {
  const o = e - n, r = i - t;
  return o * o + r * r >= s * s;
}
function Na({
  anchorX: n,
  anchorY: t,
  elementWidth: e,
  elementHeight: i,
  boxWidth: s,
  boxHeight: o,
  bottomInset: r
}) {
  let a = n, l = t;
  const c = Math.max(0, o - r), d = i || 0;
  if (e) {
    let h = a - e / 2;
    const f = s - e;
    f >= 0 ? h = Xt(h, 0, f) : h = f / 2, a = h + e / 2;
  }
  return l = Xt(l, d, c), { anchorX: a, anchorY: l };
}
function Ua({
  current: n,
  candidates: t,
  thresholdPx: e
}) {
  let i = n, s = Number.POSITIVE_INFINITY;
  for (const o of t) {
    const r = Math.abs(o - n);
    r < s && (s = r, i = o);
  }
  return !Number.isFinite(s) || s > e ? { snapped: !1, value: n } : { snapped: !0, value: i };
}
const $a = (n, t) => !!n?.italic == !!t?.italic && !!n?.bold == !!t?.bold && !!n?.underline == !!t?.underline;
function Qb(n, t, e) {
  const i = [];
  let s = "", o;
  for (let r = 0; r <= t; ) {
    const a = n[r], l = a?.text ?? "";
    if (!l) {
      r += 1;
      continue;
    }
    if (l === `
`) {
      s && (i.push({
        kind: "text",
        text: s,
        style: o
      }), s = "", o = void 0), i.push({ kind: "break" }), r += 1;
      continue;
    }
    if (a.isWordLike) {
      let h = s + l;
      const f = s ? o : a.style;
      s = "", o = void 0;
      let g = r, v = !!e?.has(r) ? r : null;
      for (; v === null && g + 1 <= t; ) {
        const S = n[g + 1];
        if (!S || S.isWordLike || S.text === `
` || !$a(S.style, f))
          break;
        if (h += S.text, g += 1, e?.has(g)) {
          v = g;
          break;
        }
      }
      if (v !== null) {
        for (i.push(
          {
            kind: "word",
            text: h,
            style: f
          },
          { kind: "break" }
        ), r = v + 1; r <= t && !n[r]?.isWordLike && !n[r]?.text.trim(); )
          r += 1;
        continue;
      }
      i.push({
        kind: "word",
        text: h,
        style: f
      }), r = g + 1;
      continue;
    }
    const c = !!e?.has(r);
    if (!(l.trim().length === 0)) {
      c ? (i.push(
        {
          kind: "text",
          text: s + l,
          style: s ? o : a.style
        },
        { kind: "break" }
      ), s = "", o = void 0) : (s && !$a(o, a.style) && (i.push({
        kind: "text",
        text: s,
        style: o
      }), s = ""), s += l, o = a.style), r += 1;
      continue;
    }
    s && (i.push({
      kind: "text",
      text: s,
      style: o
    }), s = "", o = void 0), c ? i.push(
      {
        kind: "text",
        text: l,
        style: a.style
      },
      { kind: "break" }
    ) : i.push({
      kind: "text",
      text: l,
      style: a.style
    }), r += 1;
  }
  return s && i.push({
    kind: "text",
    text: s,
    style: o
  }), i;
}
const tv = 0.55;
function ev(n, t, e) {
  return Number.isNaN(n) ? t : Math.min(e, Math.max(t, n));
}
function nv(n) {
  return n < 1 ? 28 : n < 1.4 ? 32 : 42;
}
function iv(n, t) {
  const e = Math.max(1, n.w), i = Math.max(1, n.h), s = e / i;
  let o = nv(s);
  if (t) {
    const { fontSizePx: a, maxWidthPx: l } = t;
    if (Number.isFinite(a) && Number.isFinite(l) && a > 0 && l > 0) {
      const c = a * tv;
      c > 0 && (o = l / c);
    }
  }
  return { maxLength: ev(Math.round(o * 2), 50, 180) };
}
const Ha = (n) => !!(n?.isWordLike && n.text?.trim()), we = (n, t, e) => Math.min(e, Math.max(t, n)), Ru = (n, t, e) => e < t ? 0 : n[e + 1] - n[t], sv = /[.!?\u2026]+(?:["'`)\]}\u00BB\u201D\u2019]+)?$/u;
function ov(n) {
  const t = [];
  let e = "";
  for (let i = 0; i < n.length; i += 1) {
    const s = n[i];
    if (!Ha(s)) continue;
    let o = s.text, r = i, a = s.text.length, l = i + 1, c = !1, d = !1;
    for (; l < n.length; ) {
      const f = n[l];
      if (!f) {
        l += 1;
        continue;
      }
      if (Ha(f)) break;
      if (f.text === `
`) {
        r = l;
        break;
      }
      const g = f.text ?? "";
      if (o += g, !g.trim()) {
        c && (d = !0), l += 1;
        continue;
      }
      d || (r = l, c = !0, a = o.length), l += 1;
    }
    const h = o.slice(a);
    t.push({
      tokenIndex: i,
      breakAfterTokenIndex: r,
      textToNextWord: o,
      trailingGapAfterBreakText: h
    }), e && (e += ""), e += `${o}${h}${r}`;
  }
  return {
    slices: t,
    key: e
  };
}
function rv(n, t) {
  const e = n.length, i = new Array(e), s = new Array(e), o = new Array(e), r = new Array(e), a = new Array(e + 1), l = new Array(e + 1);
  a[0] = 0, l[0] = 0;
  for (let c = 0; c < e; c += 1) {
    const d = n[c].textToNextWord, h = n[c].trailingGapAfterBreakText, f = t(d), g = d.length, m = h.length, v = m ? t(h) : 0;
    i[c] = f, s[c] = g, o[c] = v, r[c] = m, a[c + 1] = a[c] + f, l[c + 1] = l[c] + g;
  }
  return {
    widths: i,
    chars: s,
    trailingGapWidths: o,
    trailingGapChars: r,
    prefixWidths: a,
    prefixChars: l
  };
}
const ko = (n, t, e) => Ru(n.prefixWidths, t, e) - (n.trailingGapWidths[e] ?? 0);
function av(n, t, e) {
  if (e < t || !n.widths.length) return 0;
  const i = we(t, 0, n.widths.length - 1), s = we(e, 0, n.widths.length - 1);
  return s < i ? 0 : ko(n, i, s);
}
const lv = (n, t, e) => Ru(n.prefixChars, t, e) - (n.trailingGapChars[e] ?? 0);
function Bu(n, t, e, i) {
  if (e < t) return !0;
  if (i <= 0) return !1;
  if (!n.widths.length) return !0;
  const s = we(t, 0, n.widths.length - 1), o = we(e, 0, n.widths.length - 1);
  if (o < s) return !0;
  const r = n.prefixWidths, a = n.trailingGapWidths, l = r[s], c = r[o + 1], d = a[o] ?? 0;
  if (c - l - d <= i)
    return !0;
  for (let h = s; h < o; h += 1) {
    const f = r[h + 1], g = f - l - (a[h] ?? 0), m = c - f - d;
    if (g <= i && m <= i)
      return !0;
  }
  return !1;
}
const uv = (n, t, e, i, s, o) => {
  const r = (n + t) / 2, a = e - n, l = e - t, c = a * a + l * l, d = n - r, h = t - r, f = d * d + h * h, m = o >= 4 && (i <= 1 || s <= 1) ? 1e9 : 0, S = o >= 6 && (i <= 2 || s <= 2) ? 2e7 : 0;
  let T = c + f + m + S;
  return n > t && (T += (n - t) / Math.max(1, e) * 0.15), T;
};
function Fu(n, t, e, i) {
  if (i <= 0 || !n.widths.length) return null;
  const s = we(t, 0, n.widths.length - 1), o = we(e, 0, n.widths.length - 1);
  if (o <= s) return null;
  const r = n.prefixWidths, a = n.trailingGapWidths, l = r[s], c = r[o + 1], d = a[o] ?? 0;
  let h = null, f = Number.POSITIVE_INFINITY;
  const g = o - s + 1;
  for (let m = s; m < o; m += 1) {
    const v = r[m + 1], S = v - l - (a[m] ?? 0), T = c - v - d;
    if (S > i || T > i) continue;
    const w = m - s + 1, A = o - m, P = uv(
      S,
      T,
      i,
      w,
      A,
      g
    );
    P < f && (f = P, h = m);
  }
  return h;
}
function Nu(n, t) {
  const e = n.widths.length;
  if (e <= 1 || t <= 0) return [];
  if (ko(n, 0, e - 1) <= t)
    return [];
  const i = Fu(n, 0, e - 1, t);
  return i === null ? [] : [i];
}
function cv(n, t) {
  const e = n.widths.length;
  if (e <= 0 || t <= 0) return null;
  let i = 0, s = e - 1, o = null;
  for (; i <= s; ) {
    const r = i + s >> 1;
    Bu(n, 0, r, t) ? (o = r, i = r + 1) : s = r - 1;
  }
  return o;
}
function dv(n, t) {
  if (t <= 0)
    return {
      breakAfterWordIndices: [],
      truncateAfterWordIndex: null
    };
  const e = n.widths.length;
  if (e <= 1)
    return {
      breakAfterWordIndices: [],
      truncateAfterWordIndex: null
    };
  if (ko(n, 0, e - 1) <= t)
    return {
      breakAfterWordIndices: [],
      truncateAfterWordIndex: null
    };
  const s = Nu(n, t);
  if (s.length)
    return {
      breakAfterWordIndices: s,
      truncateAfterWordIndex: null
    };
  const r = cv(n, t) ?? 0;
  if (r >= e - 1)
    return {
      breakAfterWordIndices: [],
      truncateAfterWordIndex: null
    };
  const a = Fu(
    n,
    0,
    r,
    t
  );
  return {
    breakAfterWordIndices: a === null ? [] : [a],
    truncateAfterWordIndex: r
  };
}
const Lo = (n) => n.endWord - n.startWord + 1, hv = (n, t) => {
  const e = [];
  let i = 0;
  for (; i < n; ) {
    let s = i;
    for (; s + 1 < n && t(i, s + 1); )
      s += 1;
    e.push({ startWord: i, endWord: s }), i = s + 1;
  }
  return e;
}, fv = (n, t, e) => {
  if (t <= 0) return !1;
  const i = n[t], s = n[t - 1];
  if (!i || !s || Lo(s) < 3) return !1;
  const o = s.endWord, r = {
    startWord: s.startWord,
    endWord: o - 1
  }, a = {
    startWord: o,
    endWord: i.endWord
  };
  return !e(r.startWord, r.endWord) || !e(a.startWord, a.endWord) ? !1 : (s.endWord = r.endWord, i.startWord = a.startWord, !0);
}, gv = (n, t, e) => {
  if (t >= n.length - 1) return !1;
  const i = n[t], s = n[t + 1];
  if (!i || !s || Lo(s) < 3) return !1;
  const o = s.startWord, r = {
    startWord: i.startWord,
    endWord: o
  }, a = {
    startWord: o + 1,
    endWord: s.endWord
  };
  return !e(r.startWord, r.endWord) || !e(a.startWord, a.endWord) ? !1 : (i.endWord = r.endWord, s.startWord = a.startWord, !0);
}, mv = (n, t) => {
  for (let e = n.length - 1; e >= 0; e -= 1)
    Lo(n[e]) === 1 && (fv(n, e, t) || gv(n, e, t));
}, pv = (n, t, e) => {
  const i = t[e];
  if (!i) return "";
  let s = "";
  for (let o = i.tokenIndex; o <= i.breakAfterTokenIndex; o += 1)
    s += n[o]?.text ?? "";
  return s.trimEnd();
}, yv = (n, t, e, i) => {
  for (let s = 0; s < n.length - 1; s += 1) {
    const o = n[s], r = n[s + 1];
    if (!o || !r) continue;
    let a = -1;
    const l = Math.max(o.startWord, o.endWord - 2);
    for (let m = o.endWord - 1; m >= l; m -= 1)
      if (sv.test(pv(t, e, m))) {
        a = m;
        break;
      }
    if (a < o.startWord) continue;
    const c = o.startWord, d = a;
    if (d - c + 1 < 3) continue;
    const f = a + 1, g = r.endWord;
    !i(c, d) || !i(f, g) || (o.endWord = d, r.startWord = f);
  }
}, bv = (n, t, e) => {
  const i = t[e];
  if (!i) return 0;
  const s = e > 0 ? t[e - 1]?.breakAfterTokenIndex ?? i.tokenIndex - 1 : -1;
  let o = we(
    s + 1,
    0,
    i.tokenIndex
  );
  for (; o < i.tokenIndex && !n[o]?.text.trim(); )
    o += 1;
  return o;
}, vv = (n, t, e) => {
  const i = [];
  for (const s of n) {
    const o = t[s.startWord], r = t[s.endWord];
    if (!o || !r) continue;
    const a = bv(e, t, s.startWord), l = r.breakAfterTokenIndex + 1, c = e[o.tokenIndex]?.startMs ?? e[a]?.startMs ?? 0, d = e[r.tokenIndex]?.startMs ?? c, h = e[r.tokenIndex]?.durationMs ?? 0, f = t[s.endWord + 1], m = (f ? e[f.tokenIndex]?.startMs : void 0) ?? d + h;
    i.push({
      startToken: a,
      endToken: l,
      startMs: c,
      endMs: m
    });
  }
  return i;
};
function wv(n, t, e, i, s) {
  const o = t.length;
  if (o === 0) return [];
  const r = Number.isFinite(s) && s > 0 ? s : null, a = (c, d) => d < c || r !== null && lv(e, c, d) > r ? !1 : Bu(e, c, d, i), l = hv(o, a);
  return mv(l, a), yv(l, n, t, a), vv(l, t, n);
}
const Sv = 8, Tv = 0.97, kv = 24;
function Wa(n) {
  if (!Number.isFinite(n) || n <= 0) return 0;
  const t = n - Sv, e = n * Tv, i = Math.min(t, e);
  return Math.max(kv, i);
}
class Lv {
  constructor(t, e, i, s = void 0) {
    u(this, "video");
    u(this, "container");
    u(this, "fullscreenLayerController");
    u(this, "tooltipLayoutRoot");
    u(this, "subtitlesContainer", null);
    u(this, "subtitlesBlock", null);
    u(this, "renderedTokenEls", []);
    u(this, "passedFlagsBuffer", []);
    u(this, "subtitles", null);
    u(this, "subtitleLang");
    u(this, "lastRenderKey", null);
    u(this, "lastActiveLineIndex", null);
    u(this, "highlightWords", !1);
    u(this, "fontSize", 20);
    u(this, "fontSizeOverridden", !1);
    u(this, "fontFamily", "default-sans");
    u(this, "manualMaxLength", 300);
    u(this, "smartLayoutEnabled", !0);
    u(this, "smartFontSizePx", 0);
    u(this, "smartMaxWidthPx", 0);
    u(this, "smartMaxLength", 0);
    u(this, "smartAnchorWidthPx", 0);
    u(this, "smartAnchorHeightPx", 0);
    u(this, "lastSmartLayoutKey", null);
    u(this, "lastSmartLayoutCheckTs", 0);
    u(this, "opacity", "0.2");
    u(this, "maxLength", 300);
    u(this, "repositionPending", !1);
    u(this, "positionRefreshPending", !1);
    u(this, "updatePending", !1);
    u(this, "lastUpdateRequestTs", 0);
    u(this, "updateMinIntervalMs", 100);
    u(this, "updateMinIntervalHighlightMs", 33);
    u(this, "useVideoFrameCallbacks");
    u(this, "videoFrameRequestId", null);
    u(this, "dragDocListenersAttached", !1);
    u(this, "lastPositionRefreshTs", 0);
    u(this, "positionRefreshIntervalMs", 250);
    u(this, "subtitleMaxWidthPx", 0);
    u(this, "breakAfterTokenIndices", []);
    u(this, "breakAfterTokenIndexSet", null);
    u(this, "smartTruncateAfterTokenIndex", null);
    u(this, "wrapPending", !1);
    u(this, "lastWrapKey", null);
    u(this, "lastWrapTokens", null);
    u(this, "measureCanvas", null);
    u(this, "measureCtx", null);
    u(this, "tokenProcessingMemo", null);
    u(this, "tokenPrecomputeMemo", null);
    u(this, "lineMeasureMemo", null);
    u(this, "lastSegmentIndex", 0);
    u(this, "lastAppliedLeftPct", null);
    u(this, "lastAppliedTopPct", null);
    u(this, "position", {
      left: 50,
      top: 100
    });
    u(this, "positionPreset", "bottom-center");
    u(this, "dragging", {
      pointerId: null,
      candidate: !1,
      active: !1,
      moved: !1,
      startClientX: 0,
      startClientY: 0,
      offset: {
        x: 0,
        y: 0
      }
    });
    u(this, "dragStartThresholdPx", 4);
    u(this, "snapThresholdPx", 18);
    u(this, "suppressTokenClicksUntil", 0);
    u(this, "abortController", new AbortController());
    u(this, "resizeObserver");
    u(this, "tokenTooltip");
    u(this, "tooltipTranslationRequestId", 0);
    u(this, "intervalIdleChecker");
    u(this, "checkerUnsubscribe", null);
    u(this, "edgePunctuationTrimRe", /(?:^[\p{P}\p{S}]+|[\p{P}\p{S}]+$)/gu);
    u(this, "strTokens", "");
    u(this, "strTranslatedTokens", "");
    u(this, "passedStateKey", null);
    u(this, "passedThresholds", []);
    u(this, "bottomInsetCachedPx", 0);
    // layout px
    u(this, "safeAreaBottomInsetCachedPx", 0);
    u(this, "containerPaddingBottomCachedPx", 0);
    u(this, "insetCacheReady", !1);
    u(this, "bottomInsetByMode", {
      normal: {
        ratio: 0.1,
        minPx: 56,
        maxPx: 220,
        gapPx: 10
      },
      fullscreen: {
        ratio: 0.07,
        minPx: 44,
        maxPx: 140,
        gapPx: 9
      }
    });
    u(this, "safeAreaProbeEl", null);
    u(this, "guidesLayer", null);
    u(this, "verticalGuide", null);
    u(this, "horizontalGuide", null);
    u(this, "onPointerDownBound");
    u(this, "onPointerUpBound");
    u(this, "onPointerMoveBound");
    u(this, "onTimeUpdateBound");
    u(this, "onPlaybackStateChangeBound");
    u(this, "onVisualViewportChangeBound");
    u(this, "onVideoFrame", (t, e) => {
      if (this.videoFrameRequestId = null, this.abortController.signal.aborted) return;
      const i = this.video;
      !i || i.paused || i.ended || this.subtitles && (this.requestUpdate(t), this.startVideoFrameLoop());
    });
    u(this, "onClick", async (t) => {
      if (performance.now() < this.suppressTokenClicksUntil) {
        t.preventDefault(), t.stopPropagation();
        return;
      }
      const e = this.resolveTokenSpanFromClick(t);
      if (!e) return;
      if (this.tokenTooltip?.target === e && this.tokenTooltip?.container) {
        this.tokenTooltip.showed ? e.classList.add("selected") : e.classList.remove("selected");
        return;
      }
      this.releaseTooltip();
      const i = this.tooltipTranslationRequestId, s = this.normalizeTokenTextForTranslation(
        e.textContent ?? ""
      );
      if (!s) return;
      const o = await I.get(
        "translationService",
        Oi
      );
      if (i !== this.tooltipTranslationRequestId) return;
      e.classList.add("selected");
      const r = L.createSubtitleInfo(
        s,
        this.strTranslatedTokens || this.strTokens,
        o
      ), a = Math.max(
        this.subtitleMaxWidthPx,
        this.subtitlesContainer?.offsetWidth ?? 0,
        this.subtitlesBlock?.offsetWidth ?? 0,
        Math.min(globalThis.innerWidth * 0.6, 320)
      ), l = new mt({
        target: e,
        anchor: this.subtitlesBlock ?? e,
        layoutRoot: this.tooltipLayoutRoot,
        content: r.container,
        parentElement: this.getTokenTooltipParentElement(),
        offset: { x: 4, y: 12 },
        maxWidth: a,
        borderRadius: 12,
        bordered: !1,
        position: "top",
        trigger: "click"
      });
      this.tokenTooltip = l, l.onClick();
      const c = this.strTokens, d = await this.translateStrTokens(s);
      i === this.tooltipTranslationRequestId && (c !== this.strTokens || this.tokenTooltip !== l || l.target !== e || !l.showed || (r.header.textContent = d[1], r.context.textContent = d[0], l.setContent(r.container)));
    });
    this.video = t, this.container = e, this.fullscreenLayerController = new jb({
      video: t,
      container: e
    }), this.intervalIdleChecker = i, this.tooltipLayoutRoot = s, this.useVideoFrameCallbacks = !!this.video && typeof this.video.requestVideoFrameCallback == "function", this.onPointerDownBound = (o) => this.onPointerDown(o), this.onPointerUpBound = (o) => this.onPointerUp(o), this.onPointerMoveBound = (o) => this.onPointerMove(o), this.onTimeUpdateBound = () => this.requestUpdate(), this.onPlaybackStateChangeBound = () => this.handlePlaybackStateChange(), this.onVisualViewportChangeBound = () => this.scheduleReposition(), this.checkerUnsubscribe = this.intervalIdleChecker.subscribe(() => {
      this.onCheckerTick();
    }), this.bindEvents();
  }
  normalizeTokenTextForTranslation(t) {
    return t.trim().replace(this.edgePunctuationTrimRe, "");
  }
  updateMount({
    container: t,
    tooltipLayoutRoot: e
  }) {
    const i = this.container !== t, s = this.tooltipLayoutRoot !== e;
    this.container = t, this.fullscreenLayerController.updateContainer(t), this.tooltipLayoutRoot = e, this.syncWidgetMount(), (i || s) && this.tokenTooltip?.updateMount({
      parentElement: this.getTokenTooltipParentElement(),
      layoutRoot: this.tooltipLayoutRoot ?? document.documentElement
    }), this.subtitles && (this.insetCacheReady = !1, this.lastAppliedLeftPct = null, this.lastAppliedTopPct = null, this.updateContainerRect(), this.requestUpdate());
  }
  resetTranslationContext(t = !1) {
    this.strTranslatedTokens = "", t && this.releaseTooltip();
  }
  resetSegmentationMemo() {
    this.tokenProcessingMemo = null, this.tokenPrecomputeMemo = null, this.lineMeasureMemo = null, this.lastSegmentIndex = 0;
  }
  resetWrapMemo() {
    this.setBreakAfterTokenIndices([]), this.smartTruncateAfterTokenIndex = null, this.lastWrapKey = null;
  }
  resetRenderMemo() {
    this.lastRenderKey = null;
  }
  computeAnchorBoxLayout(t) {
    const e = {
      left: 0,
      top: 0,
      w: t.w,
      h: t.h
    }, i = this.video;
    if (!i) return e;
    const s = i.getBoundingClientRect();
    if (!(s.width > 0 && s.height > 0)) return e;
    const o = t.rect;
    if (!(s.right > o.left && s.left < o.right && s.bottom > o.top && s.top < o.bottom)) return e;
    const a = s.width / t.scaleX, l = s.height / t.scaleY;
    if (!(a > 0 && l > 0)) return e;
    const c = (s.left - o.left) / t.scaleX, d = (s.top - o.top) / t.scaleY, h = t.w - a, f = t.h - l, g = h >= 0 ? Xt(c, 0, h) : (t.w - a) / 2, m = f >= 0 ? Xt(d, 0, f) : (t.h - l) / 2;
    return { left: g, top: m, w: a, h: l };
  }
  readSmartCssMetrics() {
    const t = this.subtitlesBlock;
    if (!t) return null;
    const e = getComputedStyle(t), i = Number.parseFloat(e.fontSize), s = Number.parseFloat(e.maxWidth);
    if (!Number.isFinite(i) || !Number.isFinite(s) || i <= 0 || s <= 0)
      return null;
    this.subtitleMaxWidthPx = s;
    const o = Number.parseFloat(e.paddingLeft) || 0, r = Number.parseFloat(e.paddingRight) || 0, a = Math.max(0, s - o - r);
    return a <= 0 ? null : { fontSizePx: i, maxWidthPx: a };
  }
  ensureSmartLayout(t) {
    if (!this.smartLayoutEnabled)
      return this.maxLength = this.manualMaxLength, null;
    const e = this.readSmartCssMetrics(), i = e?.fontSizePx ?? this.smartFontSizePx, s = e?.maxWidthPx ?? this.smartMaxWidthPx, o = iv(t, e), r = `${Math.round(i)}|${Math.round(
      s
    )}|${o.maxLength}`, a = Math.abs(i - this.smartFontSizePx) > 0.5, l = Math.abs(s - this.smartMaxWidthPx) > 0.5, c = o.maxLength !== this.smartMaxLength;
    return r !== this.lastSmartLayoutKey && (this.lastSmartLayoutKey = r, this.smartFontSizePx = i, this.smartMaxWidthPx = s, this.smartMaxLength = o.maxLength), c && (this.maxLength = o.maxLength, this.resetRenderMemo(), this.resetSegmentationMemo()), (a || l) && this.lastWrapTokens && (this.lastWrapKey = null, this.scheduleWrapRecompute(), this.resetSegmentationMemo()), o;
  }
  scheduleReposition() {
    this.abortController.signal.aborted || this.subtitles && (this.repositionPending = !0, this.intervalIdleChecker.markActivity("subtitles-reposition"), this.intervalIdleChecker.requestImmediateTick());
  }
  setSubtitlesContainerVar(t, e) {
    const i = this.subtitlesContainer;
    if (i) {
      if (e === null) {
        i.style.removeProperty(t);
        return;
      }
      i.style.setProperty(t, e);
    }
  }
  applyOpacityStyle() {
    this.setSubtitlesContainerVar("--vot-subtitles-opacity", this.opacity);
  }
  applyManualFontSizeStyle() {
    if (!this.smartLayoutEnabled && this.fontSizeOverridden) {
      this.setSubtitlesContainerVar(
        "--vot-subtitles-font-size",
        `${this.fontSize}px`
      );
      return;
    }
    this.setSubtitlesContainerVar("--vot-subtitles-font-size", null);
  }
  applyFontFamilyStyle() {
    const t = this.fontFamily;
    this.setSubtitlesContainerVar(
      "--vot-subtitles-font-family-custom",
      Fa(t)
    ), Kb(t, {
      forceGmXhr: !0,
      onLoaded: () => {
        this.fontFamily === t && (this.lastWrapKey = null, this.resetSegmentationMemo(), this.scheduleWrapRecompute(), this.scheduleReposition());
      }
    });
  }
  syncVisualStyleVars() {
    this.applyOpacityStyle(), this.applyManualFontSizeStyle(), this.applyFontFamilyStyle();
  }
  ensureGuidesLayer() {
    if (this.guidesLayer)
      return this.guidesLayer;
    const t = document.createElement("vot-block");
    t.classList.add("vot-subtitles-guides");
    const e = document.createElement("vot-block");
    e.classList.add(
      "vot-subtitles-guide",
      "vot-subtitles-guide--vertical"
    );
    const i = document.createElement("vot-block");
    return i.classList.add(
      "vot-subtitles-guide",
      "vot-subtitles-guide--horizontal"
    ), t.append(e, i), this.guidesLayer = t, this.verticalGuide = e, this.horizontalGuide = i, this.hideSnapGuides(), t;
  }
  hideSnapGuides() {
    this.verticalGuide?.removeAttribute("data-visible"), this.horizontalGuide?.removeAttribute("data-visible");
  }
  updateSnapGuides(t, e) {
    const { showVerticalCenter: i = !1, showHorizontalCenter: s = !1 } = e;
    this.ensureGuidesLayer().isConnected || this.syncGuideLayerMount(), this.verticalGuide && (this.verticalGuide.style.left = `${t.left + t.w / 2}px`, this.verticalGuide.style.top = `${t.top}px`, this.verticalGuide.style.height = `${t.h}px`, i ? this.verticalGuide.dataset.visible = "true" : delete this.verticalGuide.dataset.visible), this.horizontalGuide && (this.horizontalGuide.style.left = `${t.left}px`, this.horizontalGuide.style.top = `${t.top + t.h / 2}px`, this.horizontalGuide.style.width = `${t.w}px`, s ? this.horizontalGuide.dataset.visible = "true" : delete this.horizontalGuide.dataset.visible);
  }
  syncGuideLayerMount() {
    const t = this.fullscreenLayerController.getWidgetParentElement(), e = this.ensureGuidesLayer();
    e.parentElement !== t && t.appendChild(e);
  }
  syncWidgetMount() {
    this.fullscreenLayerController.syncWidgetContainer(this.subtitlesContainer), this.syncGuideLayerMount();
  }
  getTokenTooltipParentElement() {
    const t = this.fullscreenLayerController.getWidgetParentElement();
    return t === this.container ? document.documentElement : t;
  }
  createSubtitlesContainer() {
    if (this.subtitlesContainer)
      return this.subtitlesContainer;
    const t = document.createElement("vot-block");
    return t.classList.add("vot-subtitles-widget"), this.subtitlesContainer = t, this.syncWidgetMount(), t.addEventListener("pointerdown", this.onPointerDownBound, {
      signal: this.abortController.signal,
      passive: !0
    }), this.syncVisualStyleVars(), this.insetCacheReady = !1, this.updateContainerRect(), t;
  }
  bindEvents() {
    const { signal: t } = this.abortController, e = { signal: t };
    this.video?.addEventListener("play", this.onPlaybackStateChangeBound, e), this.video?.addEventListener(
      "pause",
      this.onPlaybackStateChangeBound,
      e
    ), this.video?.addEventListener(
      "seeking",
      this.onPlaybackStateChangeBound,
      e
    ), this.video?.addEventListener(
      "seeked",
      this.onPlaybackStateChangeBound,
      e
    ), this.video?.addEventListener(
      "ended",
      this.onPlaybackStateChangeBound,
      e
    ), this.resizeObserver = new ResizeObserver(() => this.onResize()), this.resizeObserver.observe(this.container), this.video && this.resizeObserver.observe(this.video), globalThis.visualViewport?.addEventListener(
      "resize",
      this.onVisualViewportChangeBound,
      e
    ), globalThis.visualViewport?.addEventListener(
      "scroll",
      this.onVisualViewportChangeBound,
      e
    );
  }
  getUpdateMinIntervalMs() {
    return this.highlightWords ? this.updateMinIntervalHighlightMs : this.updateMinIntervalMs;
  }
  requestUpdate(t = performance.now()) {
    if (this.abortController.signal.aborted || !this.subtitles) return;
    const e = this.getUpdateMinIntervalMs();
    t - this.lastUpdateRequestTs < e || (this.lastUpdateRequestTs = t, this.updatePending = !0, this.intervalIdleChecker.requestImmediateTick());
  }
  handlePlaybackStateChange() {
    if (!this.subtitles) {
      this.stopVideoFrameLoop();
      return;
    }
    this.scheduleReposition(), this.requestUpdate(), this.syncVideoFrameLoop();
  }
  syncVideoFrameLoop() {
    if (!this.useVideoFrameCallbacks) return;
    const t = this.video;
    if (t) {
      if (!this.subtitles || t.paused || t.ended) {
        this.stopVideoFrameLoop();
        return;
      }
      this.startVideoFrameLoop();
    }
  }
  startVideoFrameLoop() {
    if (!this.useVideoFrameCallbacks) return;
    const t = this.video;
    t && this.videoFrameRequestId === null && (this.videoFrameRequestId = t.requestVideoFrameCallback(
      this.onVideoFrame
    ));
  }
  stopVideoFrameLoop() {
    if (!this.useVideoFrameCallbacks) return;
    const t = this.video;
    if (t && this.videoFrameRequestId !== null) {
      try {
        t.cancelVideoFrameCallback(this.videoFrameRequestId);
      } catch {
      }
      this.videoFrameRequestId = null;
    }
  }
  onCheckerTick() {
    this.abortController.signal.aborted || (this.repositionPending && (this.repositionPending = !1, this.updateContainerRect(), this.updatePending = !0), this.wrapPending && (this.wrapPending = !1, this.recomputeWrapNow()), this.positionRefreshPending && (this.positionRefreshPending = !1, this.applySubtitlePosition()), this.updatePending && (this.updatePending = !1, this.update()));
  }
  attachDragDocumentListeners() {
    this.dragDocListenersAttached || (this.dragDocListenersAttached = !0, document.addEventListener("pointermove", this.onPointerMoveBound, {
      passive: !1
    }), document.addEventListener("pointerup", this.onPointerUpBound), document.addEventListener("pointercancel", this.onPointerUpBound));
  }
  detachDragDocumentListeners() {
    this.dragDocListenersAttached && (this.dragDocListenersAttached = !1, document.removeEventListener("pointermove", this.onPointerMoveBound), document.removeEventListener("pointerup", this.onPointerUpBound), document.removeEventListener("pointercancel", this.onPointerUpBound));
  }
  onResize() {
    this.syncWidgetMount(), this.scheduleReposition();
  }
  updateContainerRect() {
    const t = this.getLayoutSize();
    if (!t.w || !t.h) return;
    const e = this.computeAnchorBoxLayout(t);
    !e.w || !e.h || (this.refreshBottomInsetNow(t, e), this.applySubtitlePositionWithLayout(t, e));
  }
  getLayoutSize() {
    const t = this.fullscreenLayerController.getLayoutRootElement(), e = t.getBoundingClientRect(), i = t.clientWidth || e.width, s = t.clientHeight || e.height, o = e.width && i ? e.width / i : 1, r = e.height && s ? e.height / s : 1;
    return { w: i, h: s, rect: e, scaleX: o, scaleY: r };
  }
  ensureSafeAreaProbe() {
    if (this.safeAreaProbeEl) return;
    const t = document.createElement("div");
    t.style.position = "fixed", t.style.left = "0", t.style.right = "0", t.style.bottom = "0", t.style.height = "env(safe-area-inset-bottom, 0px)", t.style.pointerEvents = "none", t.style.opacity = "0", t.style.zIndex = "-1", document.documentElement.appendChild(t), this.safeAreaProbeEl = t;
  }
  getSafeAreaBottomInsetPx() {
    return this.ensureSafeAreaProbe(), this.safeAreaProbeEl && this.safeAreaProbeEl.offsetHeight || 0;
  }
  refreshInsetCache() {
    const t = this.fullscreenLayerController.getLayoutRootElement();
    this.safeAreaBottomInsetCachedPx = this.getSafeAreaBottomInsetPx(), this.containerPaddingBottomCachedPx = Number.parseFloat(getComputedStyle(t).paddingBottom || "0") || 0, this.insetCacheReady = !0;
  }
  isMobileViewport() {
    return typeof globalThis.matchMedia != "function" ? !1 : globalThis.matchMedia("(max-width: 900px) and (pointer: coarse)").matches;
  }
  getBottomInsetPreset() {
    const t = document, e = t.fullscreenElement ?? t.webkitFullscreenElement;
    if (!(e instanceof Element))
      return this.bottomInsetByMode.normal;
    const { container: i, video: s } = this;
    return e === i || e.contains(i) || i.contains(e) ? this.bottomInsetByMode.fullscreen : s && (e === s || e.contains(s) || s.contains(e)) ? this.bottomInsetByMode.fullscreen : this.bottomInsetByMode.normal;
  }
  computeReservedBottomInsetPx(t, e = this.getBottomInsetPreset()) {
    const i = t * e.ratio;
    return Xt(i, e.minPx, e.maxPx);
  }
  refreshBottomInsetNow(t, e) {
    this.refreshInsetCache();
    const i = e?.h ?? this.computeAnchorBoxLayout(t ?? this.getLayoutSize()).h;
    if (!i) {
      this.bottomInsetCachedPx = 0;
      return;
    }
    const s = this.getBottomInsetPreset();
    this.bottomInsetCachedPx = this.computeReservedBottomInsetPx(
      i,
      s
    );
  }
  getBottomInsetPx(t, e) {
    this.insetCacheReady || this.refreshInsetCache();
    const i = this.getBottomInsetPreset(), s = this.safeAreaBottomInsetCachedPx, o = this.containerPaddingBottomCachedPx;
    if (this.isMobileViewport())
      return Math.max(o, s);
    const r = e?.h ?? this.computeAnchorBoxLayout(t ?? this.getLayoutSize()).h, a = r ? this.computeReservedBottomInsetPx(r, i) : i.minPx, l = Math.max(this.bottomInsetCachedPx, a);
    return Math.max(o, s, l) + i.gapPx;
  }
  onPointerDown(t) {
    const e = this.subtitlesContainer;
    if (!e) return;
    const i = t.target;
    if (!(i instanceof Node) || !e.contains(i) || !t.isPrimary || t.pointerType === "mouse" && t.button !== 0) return;
    const s = this.getLayoutSize(), { rect: o, w: r, h: a, scaleX: l, scaleY: c } = s;
    if (!r || !a) return;
    const d = this.computeAnchorBoxLayout(s);
    if (!d.w || !d.h) return;
    this.lastPositionRefreshTs = performance.now();
    const h = e.getBoundingClientRect(), f = (t.clientX - o.left) / l - d.left, g = (t.clientY - o.top) / c - d.top, m = (h.left - o.left + h.width / 2) / l - d.left, v = (h.top - o.top + h.height) / c - d.top;
    this.dragging.pointerId = t.pointerId, this.dragging.candidate = !0, this.dragging.active = !1, this.dragging.moved = !1, this.dragging.startClientX = t.clientX, this.dragging.startClientY = t.clientY, this.dragging.offset.x = m - f, this.dragging.offset.y = v - g, this.hideSnapGuides(), this.attachDragDocumentListeners();
    const S = this.subtitlesBlock ?? (i instanceof Element ? i : null);
    try {
      S?.setPointerCapture(t.pointerId);
    } catch {
    }
  }
  onPointerUp(t) {
    this.dragging.pointerId !== null && t.pointerId === this.dragging.pointerId && (this.dragging.moved && (this.suppressTokenClicksUntil = performance.now() + 450), this.dragging.pointerId = null, this.dragging.candidate = !1, this.dragging.active = !1, this.dragging.moved = !1, this.hideSnapGuides(), this.detachDragDocumentListeners());
  }
  onPointerMove(t) {
    if (!this.dragging.candidate || this.dragging.pointerId === null || t.pointerId !== this.dragging.pointerId) return;
    if (this.dragging.active)
      this.dragging.moved = !0;
    else {
      if (!Zb(
        this.dragging.startClientX,
        this.dragging.startClientY,
        t.clientX,
        t.clientY,
        this.dragStartThresholdPx
      ))
        return;
      this.dragging.active = !0, this.dragging.moved = !0, this.suppressTokenClicksUntil = performance.now() + 450, this.releaseTooltip();
    }
    t.preventDefault(), t.stopPropagation();
    const e = this.getLayoutSize(), { rect: i, w: s, h: o, scaleX: r, scaleY: a } = e;
    if (!s || !o) return;
    const l = this.computeAnchorBoxLayout(e);
    if (!l.w || !l.h) return;
    const c = (t.clientX - i.left) / r - l.left, d = (t.clientY - i.top) / a - l.top;
    let h = c + this.dragging.offset.x, f = d + this.dragging.offset.y;
    const g = this.subtitlesContainer?.offsetWidth ?? 0, m = this.subtitlesContainer?.offsetHeight ?? 0, v = this.getBottomInsetPx(e, l), S = Ua({
      current: h,
      candidates: [l.w / 2],
      thresholdPx: this.snapThresholdPx
    });
    S.snapped && (h = S.value);
    const T = l.h / 2 + m / 2, w = Ua({
      current: f,
      candidates: [T],
      thresholdPx: this.snapThresholdPx
    });
    w.snapped && (f = w.value), { anchorX: h, anchorY: f } = Na({
      anchorX: h,
      anchorY: f,
      elementWidth: g,
      elementHeight: m,
      boxWidth: l.w,
      boxHeight: l.h,
      bottomInset: v
    }), this.positionPreset = "custom", this.position.left = h / l.w * 100, this.position.top = f / l.h * 100, this.updateSnapGuides(l, {
      showVerticalCenter: S.snapped,
      showHorizontalCenter: w.snapped
    }), this.applySubtitlePositionWithLayout(e, l);
  }
  applySubtitlePosition() {
    if (!this.subtitlesContainer) return;
    const e = this.getLayoutSize();
    if (!e.w || !e.h) return;
    const i = this.computeAnchorBoxLayout(e);
    !i.w || !i.h || this.applySubtitlePositionWithLayout(e, i);
  }
  applySubtitlePositionWithLayout(t, e) {
    const i = this.subtitlesContainer;
    if (!i) return;
    const s = Math.min(t.scaleX || 1, t.scaleY || 1), o = s > 0 && s < 0.999 ? Math.min(1 / s, 3) : 1;
    Math.abs(o - 1) < 1e-3 ? i.style.removeProperty(
      "--vot-subtitles-scale-compensation"
    ) : i.style.setProperty(
      "--vot-subtitles-scale-compensation",
      o.toFixed(3)
    );
    const r = Math.max(1, Math.round(e.w)), a = Math.max(1, Math.round(e.h));
    (r !== this.smartAnchorWidthPx || a !== this.smartAnchorHeightPx) && (this.smartAnchorWidthPx = r, this.smartAnchorHeightPx = a, i.style.setProperty(
      "--vot-subtitles-anchor-width",
      `${r}px`
    ), i.style.setProperty(
      "--vot-subtitles-anchor-height",
      `${a}px`
    ), this.lastWrapTokens && (this.lastWrapKey = null, this.resetSegmentationMemo(), this.scheduleWrapRecompute())), this.smartLayoutEnabled && this.ensureSmartLayout(e);
    const c = i.offsetWidth, d = i.offsetHeight, h = this.getBottomInsetPx(t, e);
    let f = this.position.left / 100 * e.w, g = this.position.top / 100 * e.h;
    if (this.positionPreset !== "custom") {
      const O = this.resolvePresetAnchorPosition({
        preset: this.positionPreset,
        anchorBox: e,
        elementWidth: c,
        elementHeight: d,
        bottomInset: h
      });
      f = O.anchorX, g = O.anchorY, e.w > 0 && (this.position.left = f / e.w * 100), e.h > 0 && (this.position.top = g / e.h * 100);
    }
    let m = f - c / 2, v = g - d;
    const S = e.w - c, T = e.h - h - d;
    S >= 0 ? m = Xt(m, 0, S) : m = S / 2, T >= 0 ? v = Xt(v, 0, T) : v = 0, f = m + c / 2, g = v + d;
    const w = e.left + f, A = e.top + g, P = w / t.w * 100, _ = A / t.h * 100;
    (this.lastAppliedLeftPct === null || Math.abs(P - this.lastAppliedLeftPct) >= 0.01) && (i.style.left = `${P}%`, this.lastAppliedLeftPct = P), (this.lastAppliedTopPct === null || Math.abs(_ - this.lastAppliedTopPct) >= 0.01) && (i.style.top = `${_}%`, this.lastAppliedTopPct = _), this.tokenTooltip?.updatePos();
  }
  resolvePresetAnchorPosition({
    preset: t,
    anchorBox: e,
    elementWidth: i,
    elementHeight: s,
    bottomInset: o
  }) {
    let r = e.w / 2, a = e.h - o;
    switch (t) {
      case "top-center":
        a = s;
        break;
      case "center":
        a = e.h / 2 + s / 2;
        break;
      case "bottom-left":
        r = i / 2;
        break;
      case "bottom-right":
        r = e.w - i / 2;
        break;
    }
    return Na({
      anchorX: r,
      anchorY: a,
      elementWidth: i,
      elementHeight: s,
      boxWidth: e.w,
      boxHeight: e.h,
      bottomInset: o
    });
  }
  applyPositionAfterContentRender() {
    const t = this.getLayoutSize();
    if (t.w && t.h) {
      const e = this.computeAnchorBoxLayout(t);
      if (e.w && e.h) {
        this.refreshBottomInsetNow(t, e), this.applySubtitlePositionWithLayout(t, e);
        return;
      }
      this.refreshBottomInsetNow(t), this.applySubtitlePosition();
      return;
    }
    this.refreshBottomInsetNow(), this.applySubtitlePosition();
  }
  trimEdgeWhitespaceTokens(t) {
    if (!t.length) return t;
    let e = 0, i = t.length;
    for (; e < i && !t[e]?.text.trim(); ) e += 1;
    for (; i > e && !t[i - 1]?.text.trim(); ) i -= 1;
    return e === 0 && i === t.length ? t : e >= i ? [] : t.slice(e, i);
  }
  selectTokensByMaxLength(t, e) {
    if (!t.length) return t;
    let i = 0, s = 0, o = !1, r = 0, a = t.length, l = !1, c = !1;
    const d = (h, f) => {
      if (f <= h || (l || (r = h, a = f, l = !0), c)) return;
      const g = t[h], m = t[f - 1];
      if (!g || !m) return;
      const S = (f < t.length ? t[f]?.startMs : void 0) ?? m.startMs + (m.durationMs ?? 0);
      g.startMs <= e && e < S && (r = h, a = f, c = !0);
    };
    for (const [h, f] of t.entries()) {
      const g = s + f.text.length;
      if (g > this.maxLength && h > i) {
        o = !0, d(i, h), i = h, s = f.text.length;
        continue;
      }
      s = g;
    }
    return o ? (d(i, t.length), this.trimEdgeWhitespaceTokens(t.slice(r, a))) : this.trimEdgeWhitespaceTokens(t);
  }
  buildTokenPrecomputeInput(t) {
    const e = this.tokenPrecomputeMemo;
    if (e?.tokens === t)
      return e.value;
    const { slices: i, key: s } = ov(t), r = {
      words: i.map((a) => ({
        tokenIndex: a.tokenIndex,
        breakAfterTokenIndex: a.breakAfterTokenIndex
      })),
      wordSlices: i,
      normalizedWordsKey: s
    };
    return this.tokenPrecomputeMemo = {
      tokens: t,
      value: r
    }, r;
  }
  getTokenLayoutInputs(t) {
    const e = this.subtitlesBlock;
    if (e) {
      const c = getComputedStyle(e), d = `${c.fontStyle} ${c.fontVariant} ${c.fontWeight} ${c.fontSize} ${c.fontFamily}`;
      t.font = d;
      const h = Number.parseFloat(c.maxWidth), f = Number.parseFloat(c.paddingLeft) || 0, g = Number.parseFloat(c.paddingRight) || 0, m = Number.isFinite(h) ? h : this.subtitleMaxWidthPx || globalThis.innerWidth * 0.8;
      return Number.isFinite(m) && m > 0 && (this.subtitleMaxWidthPx = m), {
        fontKey: d,
        maxWidthPx: Math.max(0, m - f - g)
      };
    }
    const i = Number.parseFloat(getComputedStyle(document.documentElement).fontSize) || 16, r = Math.min(
      i * 52,
      this.subtitleMaxWidthPx || globalThis.innerWidth * 0.8
    ), a = this.fontSizeOverridden ? this.fontSize : Math.min(24, Math.max(14, globalThis.innerWidth * 0.016)), l = `normal normal 500 ${a}px ${Fa(this.fontFamily)}`;
    return t.font = l, {
      fontKey: l,
      maxWidthPx: Math.max(0, r - a)
    };
  }
  getActiveLineKey(t) {
    return this.lastActiveLineIndex !== null ? `${this.lastActiveLineIndex}` : `${t[0]?.startMs ?? 0}:${t[0]?.durationMs ?? 0}:${t.length}`;
  }
  getLineMeasureMemo(t, e) {
    const { words: i, wordSlices: s, normalizedWordsKey: o } = this.buildTokenPrecomputeInput(t);
    if (!i.length) return null;
    const r = this.getMeasureContext();
    if (!r) return null;
    const { fontKey: a, maxWidthPx: l } = this.getTokenLayoutInputs(r);
    if (!Number.isFinite(l) || l < 24)
      return null;
    const c = `${e}|${a}|${Math.round(
      l
    )}|${o}`;
    if (this.lineMeasureMemo?.key === c)
      return this.lineMeasureMemo;
    const d = rv(
      s,
      (f) => r.measureText(f).width
    ), h = {
      key: c,
      words: i,
      metrics: d,
      maxWidthPx: l
    };
    return this.lineMeasureMemo = h, h;
  }
  buildTokenProcessingMemo(t, e) {
    const i = this.getLineMeasureMemo(t, e);
    if (!i) return null;
    const s = `${i.key}|${this.maxLength}`;
    if (this.tokenProcessingMemo?.key === s)
      return this.tokenProcessingMemo;
    const o = Wa(i.maxWidthPx), r = wv(
      t,
      i.words,
      i.metrics,
      o,
      this.maxLength
    ), a = {
      key: s,
      segmentRanges: r
    };
    return this.tokenProcessingMemo = a, this.lastSegmentIndex = 0, a;
  }
  selectSegmentIndexFromRanges(t, e) {
    if (!t.length) return -1;
    let i = this.lastSegmentIndex;
    for (i >= t.length && (i = 0); i < t.length - 1 && e >= t[i].endMs; )
      i += 1;
    for (; i > 0 && e < t[i].startMs; )
      i -= 1;
    if (!(e >= t[i].startMs && e < t[i].endMs)) {
      const s = t.findIndex(
        (o) => e >= o.startMs && e < o.endMs
      );
      s >= 0 ? i = s : i = e < t[0].startMs ? 0 : t.length - 1;
    }
    return this.lastSegmentIndex = i, i;
  }
  processTokens(t, e) {
    if (!t.length) return t;
    const i = this.getActiveLineKey(t), s = this.buildTokenProcessingMemo(t, i);
    if (!s)
      return this.selectTokensByMaxLength(t, e);
    const { segmentRanges: o } = s;
    if (!o.length)
      return this.trimEdgeWhitespaceTokens(t);
    const r = this.selectSegmentIndexFromRanges(o, e);
    if (r < 0)
      return this.trimEdgeWhitespaceTokens(t);
    const a = o[r];
    return this.trimEdgeWhitespaceTokens(
      t.slice(a.startToken, a.endToken)
    );
  }
  async translateStrTokens(t) {
    const e = this.subtitleLang ?? "", i = p.lang;
    if (this.strTranslatedTokens) {
      const l = await Os(t, e, i);
      return [
        this.strTranslatedTokens,
        typeof l == "string" ? l : ""
      ];
    }
    const s = await Os(
      [this.strTokens, t],
      e,
      i
    ), o = Array.isArray(s) ? s : [s, s], r = typeof o[0] == "string" ? o[0] : "", a = typeof o[1] == "string" ? o[1] : "";
    return this.strTranslatedTokens = r, [r, a];
  }
  isTokenSpanElement(t) {
    return t instanceof HTMLSpanElement && t.dataset.votToken === "1";
  }
  findTokenSpanInPath(t, e) {
    for (const i of t)
      if (this.isTokenSpanElement(i) && e.contains(i))
        return i;
    return null;
  }
  findTokenSpanByPoint(t, e, i) {
    const s = document.elementFromPoint(t, e);
    if (this.isTokenSpanElement(s) && i.contains(s))
      return s;
    if (!(s instanceof Element)) return null;
    const o = s.closest('span[data-vot-token="1"]');
    return o instanceof HTMLSpanElement && i.contains(o) ? o : null;
  }
  resolveTokenSpanFromClick(t) {
    const e = this.subtitlesBlock ?? this.subtitlesContainer;
    if (!e) return null;
    if (this.isTokenSpanElement(t.target) && e.contains(t.target))
      return t.target;
    const i = typeof t.composedPath == "function" ? t.composedPath() : [], s = this.findTokenSpanInPath(i, e);
    if (s)
      return s;
    const o = t.clientX, r = t.clientY;
    return Number.isFinite(o) && Number.isFinite(r) ? this.findTokenSpanByPoint(o, r, e) : null;
  }
  releaseTooltip() {
    return this.tooltipTranslationRequestId += 1, this.tokenTooltip?.target && this.tokenTooltip.target.classList.remove("selected"), this.tokenTooltip?.release(), this.tokenTooltip = void 0, this;
  }
  clearPendingSchedulerState() {
    this.repositionPending = !1, this.updatePending = !1, this.wrapPending = !1, this.positionRefreshPending = !1;
  }
  clearRenderedContent({
    releaseTooltip: t = !1
  } = {}) {
    t && this.releaseTooltip(), this.resetRenderMemo(), this.lastActiveLineIndex = null, this.strTokens = "", this.resetTranslationContext(), this.subtitlesBlock = null, this.renderedTokenEls = [], this.resetWrapMemo(), this.lastWrapTokens = null, this.subtitleMaxWidthPx = 0, this.smartAnchorWidthPx = 0, this.smartAnchorHeightPx = 0, this.smartFontSizePx = 0, this.smartMaxWidthPx = 0, this.lastAppliedLeftPct = null, this.lastAppliedTopPct = null, this.passedStateKey = null, this.passedThresholds.length = 0, this.insetCacheReady = !1, this.hideSnapGuides(), this.resetSegmentationMemo(), this.clearPendingSchedulerState(), this.subtitlesContainer && wt(null, this.subtitlesContainer);
  }
  buildPassedState(t, e, i) {
    if (this.passedStateKey !== i) {
      this.passedStateKey = i, this.passedThresholds.length = 0;
      for (const r of t) {
        if (!r.isWordLike) continue;
        const a = r.startMs + r.durationMs / 2, l = Math.max(r.startMs - 100, a - 275);
        this.passedThresholds.push(Math.min(a, l));
      }
    }
    const s = this.passedFlagsBuffer, o = this.passedThresholds;
    for (let r = 0; r < o.length; r += 1)
      s[r] = e > o[r];
    return s.length = o.length, s;
  }
  renderTokens(t) {
    const e = this.breakAfterTokenIndexSet, i = [], s = Qb(t, t.length - 1, e);
    for (const o of s) {
      if (o.kind === "word") {
        i.push(
          ln`<span
            data-vot-token="1"
            data-vot-style-italic=${o.style?.italic ? "1" : "0"}
            data-vot-style-bold=${o.style?.bold ? "1" : "0"}
            data-vot-style-underline=${o.style?.underline ? "1" : "0"}
            >${o.text}</span
          >`
        );
        continue;
      }
      if (o.kind === "break") {
        i.push(ln`<br class="vot-subtitles-br" />`);
        continue;
      }
      if (o.style) {
        i.push(
          ln`<span
            data-vot-style-italic=${o.style.italic ? "1" : "0"}
            data-vot-style-bold=${o.style.bold ? "1" : "0"}
            data-vot-style-underline=${o.style.underline ? "1" : "0"}
            >${o.text}</span
          >`
        );
        continue;
      }
      i.push(o.text);
    }
    return i;
  }
  updatePassedClasses(t) {
    const e = this.renderedTokenEls, i = Math.min(e.length, t.length);
    for (let s = 0; s < i; s += 1)
      e[s].classList.toggle("passed", t[s]);
    for (let s = i; s < e.length; s += 1)
      e[s].classList.remove("passed");
  }
  clearPassedClasses() {
    for (const t of this.renderedTokenEls)
      t.classList.remove("passed");
  }
  setBreakAfterTokenIndices(t) {
    this.breakAfterTokenIndices = t, this.breakAfterTokenIndexSet = t.length ? new Set(t) : null;
  }
  scheduleWrapRecompute(t = null) {
    t && (this.lastWrapTokens = t);
    const e = !this.wrapPending;
    this.wrapPending = !0, e && this.intervalIdleChecker.requestImmediateTick();
  }
  maybeRefreshPosition(t = !1) {
    if (this.abortController.signal.aborted || !this.subtitlesContainer) return;
    const e = performance.now();
    !t && e - this.lastPositionRefreshTs < this.positionRefreshIntervalMs || (this.lastPositionRefreshTs = e, this.positionRefreshPending = !0, this.intervalIdleChecker.requestImmediateTick());
  }
  getMeasureContext(t) {
    return this.measureCanvas || (this.measureCanvas = document.createElement("canvas"), this.measureCanvas.width = 1, this.measureCanvas.height = 1), this.measureCtx || (this.measureCtx = this.measureCanvas.getContext("2d", { alpha: !1 }) ?? this.measureCanvas.getContext("2d")), this.measureCtx ? (typeof t == "string" && t && (this.measureCtx.font = t), this.measureCtx) : null;
  }
  arraysEqual(t, e) {
    if (t === e) return !0;
    if (t.length !== e.length) return !1;
    for (let i = 0; i < t.length; i += 1)
      if (t[i] !== e[i]) return !1;
    return !0;
  }
  recomputeWrapNow() {
    const t = this.lastWrapTokens, e = this.subtitlesBlock;
    if (!t || !e) return;
    const i = this.getLineMeasureMemo(
      t,
      this.getActiveLineKey(t)
    );
    if (!i || i.maxWidthPx < 50) return;
    const { words: s, metrics: o, maxWidthPx: r } = i, a = Wa(r);
    if (s.length <= 1) {
      (this.breakAfterTokenIndices.length || this.smartTruncateAfterTokenIndex !== null) && (this.resetWrapMemo(), this.resetRenderMemo(), this.update());
      return;
    }
    const l = i.key;
    if (l === this.lastWrapKey) return;
    this.lastWrapKey = l;
    let c = [], d = null;
    if (!(av(o, 0, s.length - 1) <= a)) {
      const m = Nu(
        o,
        a
      );
      if (m.length)
        c = m.map(
          (v) => s[v].breakAfterTokenIndex
        );
      else if (this.smartLayoutEnabled) {
        const v = dv(o, a);
        c = v.breakAfterWordIndices.map(
          (S) => s[S].breakAfterTokenIndex
        ), v.truncateAfterWordIndex !== null && (d = s[v.truncateAfterWordIndex]?.breakAfterTokenIndex ?? null);
      }
    }
    const f = !this.arraysEqual(
      c,
      this.breakAfterTokenIndices
    ), g = d !== this.smartTruncateAfterTokenIndex;
    (f || g) && (this.setBreakAfterTokenIndices(c), this.smartTruncateAfterTokenIndex = d, this.resetRenderMemo(), this.update());
  }
  setContent(t, e = void 0) {
    if (this.releaseTooltip(), this.subtitleLang = e, !t || !this.video) {
      this.clearRenderedContent(), this.subtitles = null, this.clearPendingSchedulerState(), this.video?.removeEventListener("timeupdate", this.onTimeUpdateBound), this.stopVideoFrameLoop(), this.detachDragDocumentListeners();
      return;
    }
    this.createSubtitlesContainer(), this.subtitles = t, this.lastActiveLineIndex = null, this.useVideoFrameCallbacks || this.video.addEventListener("timeupdate", this.onTimeUpdateBound, {
      signal: this.abortController.signal
    }), this.syncVideoFrameLoop(), this.updateContainerRect(), this.update(), this.intervalIdleChecker.requestImmediateTick();
  }
  setMaxLength(t) {
    typeof t == "number" && t > 0 && (this.manualMaxLength = t, this.smartLayoutEnabled || (this.maxLength = t, this.resetSegmentationMemo(), this.update(), this.scheduleReposition()));
  }
  setHighlightWords(t) {
    const e = this.highlightWords;
    this.highlightWords = !!t, e && !this.highlightWords && this.clearPassedClasses(), this.update();
  }
  setSmartLayout(t) {
    const e = t !== !1;
    e !== this.smartLayoutEnabled && (this.smartLayoutEnabled = e, this.subtitlesContainer?.style.removeProperty("--vot-subtitles-max-width"), this.lastSmartLayoutKey = null, this.resetWrapMemo(), this.resetRenderMemo(), this.resetSegmentationMemo(), this.smartLayoutEnabled || (this.maxLength = this.manualMaxLength), this.applyManualFontSizeStyle(), this.update(), this.scheduleWrapRecompute(), this.scheduleReposition());
  }
  setFontSize(t) {
    this.fontSize = t, this.fontSizeOverridden = !0, this.smartLayoutEnabled || (this.applyManualFontSizeStyle(), this.lastWrapKey = null, this.resetSegmentationMemo(), this.scheduleWrapRecompute(), this.scheduleReposition());
  }
  setFontFamily(t) {
    this.fontFamily = t, this.applyFontFamilyStyle(), this.lastWrapKey = null, this.resetSegmentationMemo(), this.scheduleWrapRecompute(), this.scheduleReposition();
  }
  setOpacity(t) {
    const e = Number(t), i = Number.isFinite(e) ? Xt(e, 0, 100) : 0;
    this.opacity = ((100 - i) / 100).toFixed(2), this.applyOpacityStyle();
  }
  stringifyTokens(t) {
    let e = "";
    for (const i of t)
      e += i.text;
    return e;
  }
  update() {
    if (!this.video || !this.subtitles) return;
    const t = this.video.currentTime * 1e3, e = this.subtitles.subtitles;
    let i, s = -1;
    const o = this.lastActiveLineIndex;
    if (typeof o == "number" && o >= 0 && o < e.length) {
      const S = e[o];
      Xb(t, S) && (i = S, s = o);
    }
    if (!i) {
      const S = Jb(t, e);
      S !== -1 && (i = e[S], s = S);
    }
    if (!i) {
      this.lastActiveLineIndex = null, this.subtitlesBlock || this.lastRenderKey !== null || this.strTokens ? this.clearRenderedContent({ releaseTooltip: !0 }) : this.releaseTooltip();
      return;
    }
    if (this.lastActiveLineIndex = s, this.smartLayoutEnabled) {
      const S = performance.now();
      if (this.lastSmartLayoutKey === null || S - this.lastSmartLayoutCheckTs > 500) {
        this.lastSmartLayoutCheckTs = S;
        const T = this.getLayoutSize();
        if (T.w && T.h) {
          const w = this.computeAnchorBoxLayout(T);
          w.w && w.h && this.ensureSmartLayout(w);
        }
      }
    } else
      this.maxLength = this.manualMaxLength;
    const r = this.processTokens(i.tokens, t);
    this.lastWrapTokens = r;
    const a = this.smartLayoutEnabled && typeof this.smartTruncateAfterTokenIndex == "number" && this.smartTruncateAfterTokenIndex >= 0 && this.smartTruncateAfterTokenIndex < r.length - 1, l = this.stringifyTokens(r), c = l !== this.strTokens;
    c && (this.releaseTooltip(), this.strTokens = l, this.resetTranslationContext(), this.resetWrapMemo());
    const d = `${s}:${l}`, h = this.highlightWords ? this.buildPassedState(r, t, d) : null, f = `${this.breakAfterTokenIndices.join(",")}|${this.smartTruncateAfterTokenIndex ?? ""}`, g = `${s}:${l}:${f}`;
    if (g === this.lastRenderKey) {
      this.highlightWords && !c && h && this.updatePassedClasses(h), this.maybeRefreshPosition();
      return;
    }
    this.lastRenderKey = g, this.subtitlesContainer = this.subtitlesContainer ?? this.createSubtitlesContainer(), wt(
      ln`<vot-block
        class="${a ? "vot-subtitles vot-subtitles--clamped" : "vot-subtitles"}"
        @click=${this.onClick}
      >
        ${this.renderTokens(r)}
      </vot-block>`,
      this.subtitlesContainer
    );
    const v = this.subtitlesContainer.firstElementChild;
    this.subtitlesBlock = v instanceof HTMLElement && v.classList.contains("vot-subtitles") ? v : null, this.renderedTokenEls = this.subtitlesBlock ? Array.from(
      this.subtitlesBlock.querySelectorAll(
        'span[data-vot-token="1"]'
      )
    ) : [], this.highlightWords && h && this.updatePassedClasses(h), c ? (this.applyPositionAfterContentRender(), this.scheduleWrapRecompute(r), this.scheduleReposition()) : this.maybeRefreshPosition();
  }
  release() {
    this.detachDragDocumentListeners(), this.stopVideoFrameLoop(), this.abortController.abort(), this.resizeObserver?.disconnect(), this.clearPendingSchedulerState(), this.checkerUnsubscribe?.(), this.checkerUnsubscribe = null, this.releaseTooltip(), this.subtitlesContainer && (this.subtitlesContainer.remove(), this.subtitlesContainer = null), this.fullscreenLayerController.release(), this.safeAreaProbeEl && (this.safeAreaProbeEl.remove(), this.safeAreaProbeEl = null), this.guidesLayer && (this.guidesLayer.remove(), this.guidesLayer = null, this.verticalGuide = null, this.horizontalGuide = null), this.measureCtx = null, this.measureCanvas = null, this.lastAppliedLeftPct = null, this.lastAppliedTopPct = null, this.passedStateKey = null, this.passedThresholds.length = 0, this.insetCacheReady = !1;
  }
}
const Av = /^<\s*(\/?)\s*([a-z0-9]+)(?:[.\s][^>]*)?>/iu, xv = /^\{([^}]*)\}/u, Vv = /^(\s*)>>\s*/u, Cv = (n) => {
  const t = {};
  return n.italic && (t.italic = !0), n.bold && (t.bold = !0), n.underline && (t.underline = !0), Object.keys(t).length > 0 ? t : void 0;
}, Ev = (n, t) => !!n?.italic == !!t?.italic && !!n?.bold == !!t?.bold && !!n?.underline == !!t?.underline, on = (n, t, e) => {
  if (!t) return;
  const i = Cv(e), s = n.at(-1);
  if (s && Ev(s.style, i)) {
    s.text += t;
    return;
  }
  n.push({
    text: t,
    style: i
  });
}, Iv = (n, t) => {
  const e = /^\\([ibu])([01])$/u.exec(n.trim());
  if (!e) return;
  const i = e[2] === "1";
  if (e[1] === "i") {
    t.italic = i;
    return;
  }
  if (e[1] === "b") {
    t.bold = i;
    return;
  }
  e[1] === "u" && (t.underline = i);
}, Pv = (n) => {
  for (const t of n) {
    if (!t.text) continue;
    const e = t.text.replace(Vv, "$1");
    if (t.text = e, e.length > 0)
      break;
  }
  for (; n[0]?.text === ""; )
    n.shift();
}, _n = (n) => {
  const t = [], e = {
    italic: !1,
    bold: !1,
    underline: !1
  };
  let i = 0;
  for (; i < n.length; ) {
    const f = n.slice(i);
    if (f.startsWith("\\N") || f.startsWith("\\n")) {
      on(t, `
`, e), i += 2;
      continue;
    }
    if (f.startsWith("\\h")) {
      on(t, " ", e), i += 2;
      continue;
    }
    if (f[0] === `
`) {
      on(t, `
`, e), i += 1;
      continue;
    }
    const g = xv.exec(f);
    if (g) {
      const v = g[1].match(/\\[ibu][01]/gu) ?? [];
      for (const S of v)
        Iv(S, e);
      i += g[0].length;
      continue;
    }
    const m = Av.exec(f);
    if (m) {
      const v = m[1] === "/", S = m[2].toLowerCase();
      S === "br" ? on(t, `
`, e) : S === "i" ? e.italic = !v : S === "b" ? e.bold = !v : S === "u" && (e.underline = !v), i += m[0].length;
      continue;
    }
    on(t, f[0], e), i += 1;
  }
  Pv(t);
  const s = [];
  let o = "";
  for (const f of t) {
    if (!f.text) continue;
    const g = o.length;
    o += f.text;
    const m = o.length;
    s.push({
      start: g,
      end: m,
      style: f.style
    });
  }
  const r = o.replaceAll(" ", " "), a = /^\s*/u.exec(r)?.[0].length ?? 0, l = /\s*$/u.exec(r)?.[0].length ?? 0, c = Math.max(
    a,
    r.length - l
  ), d = r.slice(a, c), h = s.map((f) => ({
    start: Math.max(0, f.start - a),
    end: Math.max(0, f.end - a),
    style: f.style
  })).filter((f) => f.end > f.start && f.start < d.length).map((f) => ({
    ...f,
    end: Math.min(f.end, d.length)
  }));
  return {
    text: d,
    styledSpans: h
  };
}, za = (n, t, e) => !n?.length || e <= t ? void 0 : n.find(
  (s) => t < s.end && e > s.start && s.style
)?.style, Mv = "\uFEFF", Ov = /\{[^}]*\}/gu, Xn = /^\s*(?<start>\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})\s*-->\s*(?<end>\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})\s*$/u, us = /^(?<start>(?:\d{2}:)?\d{2}:\d{2}\.\d{3})\s+-->\s+(?<end>(?:\d{2}:)?\d{2}:\d{2}\.\d{3})(?<settings>(?:[ \t]+.+)?)$/u, Ao = (n) => n.replace(Mv, "").replaceAll(/\r\n?/gu, `
`), Dv = (n) => n.length >= 3 ? n.slice(0, 3) : n.padEnd(3, "0"), wi = (n, t) => {
  const e = n.trim().split(":");
  if (e.length < 2 || e.length > 3)
    return null;
  const i = e.length === 2 ? ["00", ...e] : e, [s, o, r] = i, [a, l = "0"] = r.split(/[.,]/u);
  if (!/^\d+$/u.test(s) || !/^\d{2}$/u.test(o) || !/^\d{2}$/u.test(a) || !/^\d+$/u.test(l))
    return null;
  const c = Number(s), d = Number(o), h = Number(a), f = Number(
    Dv(l).slice(0, t)
  );
  return !Number.isFinite(c) || !Number.isFinite(d) || !Number.isFinite(h) || d > 59 || h > 59 ? null : ((c * 60 + d) * 60 + h) * 1e3 + f;
}, Si = (n, {
  delimiter: t,
  allowOptionalHours: e,
  fractionDigits: i
}) => {
  const s = Math.max(0, Math.round(n)), o = Math.floor(s / 36e5), r = Math.floor(s % 36e5 / 6e4), a = Math.floor(s % 6e4 / 1e3), c = (s % 1e3).toString().padStart(3, "0").slice(0, i);
  return `${e && o === 0 ? "" : `${o.toString().padStart(2, "0")}:`}${r.toString().padStart(2, "0")}:${a.toString().padStart(2, "0")}${t}${c}`;
}, qa = (n) => {
  const t = Math.max(0, Math.round(n)), e = Math.floor(t / 36e5), i = Math.floor(t % 36e5 / 6e4), s = Math.floor(t % 6e4 / 1e3), o = Math.floor(t % 1e3 / 10);
  return `${e}:${i.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}.${o.toString().padStart(2, "0")}`;
}, Ga = (n) => {
  const t = /^(?<hours>\d+):(?<minutes>\d{2}):(?<seconds>\d{2})\.(?<centiseconds>\d{2})$/u.exec(
    n.trim()
  );
  if (!t?.groups) return null;
  const e = Number(t.groups.hours), i = Number(t.groups.minutes), s = Number(t.groups.seconds), o = Number(t.groups.centiseconds);
  return i > 59 || s > 59 || !Number.isFinite(e) || !Number.isFinite(o) ? null : ((e * 60 + i) * 60 + s) * 1e3 + o * 10;
}, He = (n) => _n(n).text, Ri = (n) => n.sort((t, e) => {
  const i = t.line.startMs - e.line.startMs;
  if (i !== 0) return i;
  const s = t.line.startMs + Math.max(0, t.line.durationMs) - (e.line.startMs + Math.max(0, e.line.durationMs));
  return s !== 0 ? s : t.index - e.index;
}).map(({ line: t }) => t), _v = (n) => {
  let t = 0, e = n.length;
  for (; t < e && n[t] === ""; )
    t += 1;
  for (; e > t && n[e - 1] === ""; )
    e -= 1;
  return n.slice(t, e);
}, Rv = (n) => {
  const t = n.trim();
  if (!t) return;
  const e = {};
  for (const i of t.split(/\s+/u)) {
    const s = i.indexOf(":");
    s <= 0 || (e[i.slice(0, s)] = i.slice(s + 1));
  }
  return {
    raw: t,
    values: e
  };
}, Bv = (n) => {
  const e = (/^\s*<v(?:\.[^ >]+)?(?:\s+([^>]*?))?>/iu.exec(n) ?? /^\s*<v\s+([^>]*?)>/iu.exec(n))?.[1]?.trim();
  return e || void 0;
}, Fv = (n) => He(n), Nv = (n) => He(n), Uv = (n) => He(n), $v = (n) => {
  const e = Ao(n).split(`
`), i = [], s = (a) => {
    const l = e[a]?.trim() ?? "", c = e[a + 1]?.trim() ?? "";
    return Xn.test(l) || /^\d+$/u.test(l) && Xn.test(c);
  };
  let o = 0, r = 0;
  for (; o < e.length; ) {
    for (; o < e.length && e[o].trim() === ""; )
      o += 1;
    if (o >= e.length) break;
    let a = o;
    /^\d+$/u.test(e[o].trim()) && Xn.test(e[o + 1]?.trim() ?? "") && (a = o + 1);
    const l = Xn.exec(
      e[a]?.trim() ?? ""
    );
    if (!l?.groups) {
      o += 1;
      continue;
    }
    const c = wi(l.groups.start, 3), d = wi(l.groups.end, 3);
    if (c == null || d == null || d < c) {
      o = a + 1;
      continue;
    }
    o = a + 1;
    const h = [];
    for (; o < e.length; ) {
      if (e[o].trim() === "") {
        const m = o + 1;
        if (s(m))
          break;
        o += 1;
        continue;
      }
      if (h.length > 0 && s(o))
        break;
      h.push(e[o]), o += 1;
    }
    const f = _v(h).join(`
`), g = _n(f);
    i.push({
      index: r,
      line: {
        text: Fv(f),
        startMs: c,
        durationMs: Math.max(0, d - c),
        speakerId: "0",
        tokens: [],
        metadata: {
          rawText: f,
          styledSpans: g.styledSpans
        }
      }
    }), r += 1;
  }
  return {
    format: "srt",
    subtitles: Ri(i)
  };
}, Uu = (n, t, e) => n.format === e ? t.metadata?.rawText ?? t.text : e === "ass" ? t.text.replaceAll(`
`, "\\N") : t.text, Hv = (n) => n.subtitles.map((t, e) => {
  const i = Uu(n, t, "srt"), s = t.startMs + Math.max(0, t.durationMs);
  return [
    String(e + 1),
    `${Si(t.startMs, {
      delimiter: ",",
      allowOptionalHours: !1,
      fractionDigits: 3
    })} --> ${Si(s, {
      delimiter: ",",
      allowOptionalHours: !1,
      fractionDigits: 3
    })}`,
    i
  ].join(`
`);
}).join(`

`), Wv = (n, t, e) => {
  n.push({
    cueIndex: t,
    lines: e
  });
}, zv = (n) => {
  const e = Ao(n).split(`
`), i = e[0] ?? "";
  if (!i.startsWith("WEBVTT"))
    return {
      format: "vtt",
      subtitles: [],
      metadata: {
        vtt: {
          headerText: "",
          blocks: []
        }
      }
    };
  const s = {
    headerText: i.slice(6).trim(),
    blocks: []
  }, o = [];
  let r = 1;
  for (; r < e.length; ) {
    for (; r < e.length && e[r].trim() === ""; )
      r += 1;
    if (r >= e.length) break;
    if (e[r].startsWith("NOTE") || e[r] === "STYLE" || e[r] === "REGION") {
      const v = [];
      for (; r < e.length && e[r].trim() !== ""; )
        v.push(e[r]), r += 1;
      Wv(s.blocks, o.length, v);
      continue;
    }
    let a;
    !us.test(e[r] ?? "") && us.test(e[r + 1] ?? "") && (a = e[r], r += 1);
    const l = us.exec(e[r] ?? "");
    if (!l?.groups) {
      r += 1;
      continue;
    }
    const c = wi(l.groups.start, 3), d = wi(l.groups.end, 3);
    if (c == null || d == null || d < c) {
      r += 1;
      continue;
    }
    r += 1;
    const h = [];
    for (; r < e.length && e[r].trim() !== ""; )
      h.push(e[r]), r += 1;
    const f = h.join(`
`), g = _n(f), m = Bv(f);
    o.push({
      index: o.length,
      line: {
        text: Nv(f),
        startMs: c,
        durationMs: Math.max(0, d - c),
        speakerId: m ?? "0",
        tokens: [],
        metadata: {
          rawText: f,
          styledSpans: g.styledSpans,
          vtt: {
            cueId: a,
            settings: Rv(l.groups.settings ?? ""),
            voice: m,
            rawPayload: h
          }
        }
      }
    });
  }
  return {
    format: "vtt",
    subtitles: Ri(o),
    metadata: {
      vtt: s
    }
  };
}, qv = (n) => {
  const t = n.startMs + Math.max(0, n.durationMs), e = n.metadata?.vtt?.settings?.raw;
  return `${Si(n.startMs, {
    delimiter: ".",
    allowOptionalHours: !0,
    fractionDigits: 3
  })} --> ${Si(t, {
    delimiter: ".",
    allowOptionalHours: !0,
    fractionDigits: 3
  })}${e ? ` ${e}` : ""}`;
}, Gv = (n) => {
  const t = n.metadata?.vtt, e = [
    `WEBVTT${t?.headerText ? ` ${t.headerText}` : ""}`
  ], i = /* @__PURE__ */ new Map();
  for (const o of t?.blocks ?? []) {
    const r = i.get(o.cueIndex) ?? [];
    r.push(o.lines), i.set(o.cueIndex, r);
  }
  const s = (o) => {
    for (const r of i.get(o) ?? [])
      e.push(r.join(`
`));
  };
  return s(0), n.subtitles.forEach((o, r) => {
    const a = o.metadata?.vtt?.cueId, l = [
      ...a ? [a] : [],
      qv(o),
      (n.format === "vtt" ? o.metadata?.vtt?.rawPayload : o.text.split(`
`))?.join(`
`) ?? o.text
    ];
    e.push(l.join(`
`)), s(r + 1);
  }), e.filter(Boolean).join(`

`);
}, Kv = (n, t) => {
  if (t <= 1)
    return [n];
  const e = [];
  let i = 0;
  for (let s = 0; s < t - 1; s += 1) {
    const o = n.indexOf(",", i);
    if (o < 0) {
      e.push(n.slice(i).trim()), i = n.length;
      break;
    }
    e.push(n.slice(i, o).trim()), i = o + 1;
  }
  return e.push(n.slice(i).trim()), e;
}, Yv = () => ({
  scriptInfoLines: [],
  styleFormat: "",
  styleLines: [],
  eventFormat: "",
  preEventLines: [],
  commentLines: []
}), jv = (n = "Exported subtitles") => ({
  scriptInfoLines: [
    `Title: ${n}`,
    "ScriptType: v4.00+",
    "WrapStyle: 0",
    "ScaledBorderAndShadow: yes"
  ],
  styleFormat: "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
  styleLines: [
    "Style: Default,Arial,42,&H00FFFFFF,&H000000FF,&H00000000,&H64000000,0,0,0,0,100,100,0,0,1,2,0,2,20,20,20,1"
  ],
  eventFormat: "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
  preEventLines: [],
  commentLines: []
}), Xv = (n) => {
  const e = Ao(n).split(`
`), i = Yv(), s = [];
  let o = "", r = [];
  return e.forEach((a, l) => {
    const c = a.trim();
    if (!c) return;
    const d = /^\[(.+)\]$/u.exec(c);
    if (d) {
      o = d[1];
      return;
    }
    if (o === "Script Info") {
      i.scriptInfoLines.push(a);
      return;
    }
    if (o === "V4+ Styles" || o === "V4 Styles") {
      if (a.startsWith("Format:")) {
        i.styleFormat = a;
        return;
      }
      if (a.startsWith("Style:")) {
        i.styleLines.push(a);
        return;
      }
      i.preEventLines.push(a);
      return;
    }
    if (o === "Events") {
      if (a.startsWith("Format:")) {
        i.eventFormat = a, r = a.slice(7).split(",").map((_) => _.trim());
        return;
      }
      if (!a.includes(":")) {
        i.preEventLines.push(a);
        return;
      }
      const h = a.indexOf(":"), f = a.slice(0, h).trim(), g = a.slice(h + 1).trim();
      !r.length && i.eventFormat && (r = i.eventFormat.slice(7).split(",").map((_) => _.trim()));
      const m = Kv(g, r.length), v = Object.fromEntries(
        r.map((_, O) => [
          _,
          m[O] ?? ""
        ])
      );
      if (f === "Comment") {
        i.commentLines.push(a);
        return;
      }
      if (f !== "Dialogue") {
        i.preEventLines.push(a);
        return;
      }
      const S = Ga(v.Start ?? ""), T = Ga(v.End ?? "");
      if (S == null || T == null || T < S)
        return;
      const w = v.Text ?? "", A = _n(w), P = {
        kind: "dialogue",
        layer: v.Layer ?? "0",
        style: v.Style ?? "Default",
        name: v.Name ?? "",
        marginL: v.MarginL ?? "0",
        marginR: v.MarginR ?? "0",
        marginV: v.MarginV ?? "0",
        effect: v.Effect ?? "",
        rawText: w,
        overrideTags: w.match(Ov) ?? []
      };
      s.push({
        index: l,
        line: {
          text: Uv(w),
          startMs: S,
          durationMs: Math.max(0, T - S),
          speakerId: P.name || "0",
          tokens: [],
          metadata: {
            rawText: w,
            styledSpans: A.styledSpans,
            ass: P
          }
        }
      });
    }
  }), {
    format: "ass",
    subtitles: Ri(s),
    metadata: {
      ass: i
    }
  };
}, Jv = (n) => {
  const t = n.metadata?.ass, e = n.startMs + Math.max(0, n.durationMs), i = t?.rawText ?? n.metadata?.rawText ?? n.text.replaceAll(`
`, "\\N");
  return [
    t?.kind === "comment" ? "Comment" : "Dialogue",
    ": ",
    [
      t?.layer ?? "0",
      qa(n.startMs),
      qa(e),
      t?.style ?? "Default",
      t?.name ?? "",
      t?.marginL ?? "0",
      t?.marginR ?? "0",
      t?.marginV ?? "0",
      t?.effect ?? "",
      i
    ].join(",")
  ].join("");
}, Zv = (n, t) => {
  if (!t)
    return n;
  const e = `Title: ${t}`, i = [...n.scriptInfoLines], s = i.findIndex(
    (o) => o.startsWith("Title:")
  );
  return s >= 0 ? i[s] === "Title: Exported subtitles" && (i[s] = e) : i.unshift(e), {
    ...n,
    scriptInfoLines: i
  };
}, Qv = (n, t) => {
  const e = n.metadata?.ass, i = e && e.scriptInfoLines.length > 0 && e.styleFormat && e.styleLines.length > 0 && e.eventFormat ? e : jv(t?.assTitle), s = Zv(i, t?.assTitle);
  return [
    "[Script Info]",
    ...s.scriptInfoLines,
    "",
    "[V4+ Styles]",
    s.styleFormat,
    ...s.styleLines,
    ...s.preEventLines,
    "",
    "[Events]",
    s.eventFormat,
    ...s.commentLines,
    ...n.subtitles.map(
      (r) => Jv({
        ...r,
        metadata: n.format === "ass" ? r.metadata : {
          ...r.metadata,
          rawText: Uu(n, r, "ass")
        }
      })
    )
  ].join(`
`).trim();
}, tw = (n, t) => t === "srt" ? $v(n) : t === "vtt" ? zv(n) : Xv(n), Ka = (n) => ({
  ...n,
  subtitles: Ri(
    n.subtitles.map((t, e) => ({
      index: e,
      line: t
    }))
  )
}), ew = (n) => {
  const t = n.subtitles.map((e) => ({
    text: e.text,
    startMs: e.startMs,
    durationMs: e.durationMs,
    speakerId: e.speakerId,
    tokens: e.tokens.map((i) => ({
      text: i.text,
      startMs: i.startMs,
      durationMs: i.durationMs
    }))
  }));
  return {
    containsTokens: t.some((e) => e.tokens.length > 0),
    subtitles: t
  };
}, nw = (n, t, e) => t === "json" ? ew(n) : t === "srt" ? Hv(n) : t === "vtt" ? Gv(n) : Qv(n, e);
function iw(n) {
  return new Uint8Array([
    n >>> 24 & 255,
    n >>> 16 & 255,
    n >>> 8 & 255,
    n & 255
  ]);
}
function sw(n) {
  return new Uint8Array([
    n >>> 21 & 127,
    n >>> 14 & 127,
    n >>> 7 & 127,
    n & 127
  ]);
}
function ow(n, t) {
  const e = new TextEncoder().encode(t), i = new Uint8Array(e.length + 1);
  i[0] = 3, i.set(e, 1);
  const s = new Uint8Array(10 + i.length);
  s.set([84, 73, 84, 50], 0), s.set(iw(i.length), 4), s.set(i, 10);
  const o = new Uint8Array(10);
  o.set([73, 68, 51, 3, 0, 0], 0), o.set(sw(s.length), 6);
  const r = new Uint8Array(n), a = new Uint8Array(o.length + s.length + r.length);
  return a.set(o, 0), a.set(s, o.length), a.set(r, o.length + s.length), new Blob([a], { type: "audio/mpeg" });
}
async function rw(n, t) {
  const e = Number(n.headers.get("Content-Length") ?? 0);
  if (!n.body) return n.arrayBuffer();
  const i = n.body.getReader();
  let s = 0, o = e > 0 ? new Uint8Array(e) : null;
  const r = [];
  for (; ; ) {
    const { done: c, value: d } = await i.read();
    if (c) break;
    if (!(!d || d.byteLength === 0)) {
      if (o) {
        const h = s + d.byteLength;
        if (h > o.length) {
          const f = new Uint8Array(Math.max(h, o.length * 2));
          f.set(o.subarray(0, s)), o = f;
        }
        o.set(d, s), s = h;
      } else
        r.push(d), s += d.byteLength;
      e > 0 && t(K(Math.round(s / e * 100)));
    }
  }
  if (o)
    return o.buffer.slice(0, s);
  const a = new Uint8Array(s);
  let l = 0;
  for (const c of r)
    a.set(c, l), l += c.byteLength;
  return a.buffer;
}
async function aw(n, t, e = () => {
}, i = {}) {
  const s = await lw(n, t, e);
  return await iu(s, `${t}.mp3`, i);
}
async function lw(n, t, e = () => {
}) {
  const i = await rw(n, e);
  return e(100), ow(i, t);
}
function $u(n, t) {
  return n.root === t.root && n.portalContainer === t.portalContainer && n.subtitlesMountContainer === t.subtitlesMountContainer && n.tooltipLayoutRoot === t.tooltipLayoutRoot;
}
function uw(n, t, e) {
  return $u(n, t) ? n : (e(t), t);
}
function cw(n, t) {
  return n.root !== t.root || n.tooltipLayoutRoot !== t.tooltipLayoutRoot;
}
const dw = St`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <path
    id="vot-translate-icon"
    fill-rule="evenodd"
    d="M15.778 18.95L14.903 21.375C14.8364 21.5583 14.7197 21.7083 14.553 21.825C14.3864 21.9417 14.203 22 14.003 22C13.6697 22 13.3989 21.8625 13.1905 21.5875C12.9822 21.3125 12.9447 21.0083 13.078 20.675L16.878 10.625C16.9614 10.4417 17.0864 10.2917 17.253 10.175C17.4197 10.0583 17.603 10 17.803 10H18.553C18.753 10 18.9364 10.0583 19.103 10.175C19.2697 10.2917 19.3947 10.4417 19.478 10.625L23.278 20.7C23.4114 21.0167 23.378 21.3125 23.178 21.5875C22.978 21.8625 22.7114 22 22.378 22C22.1614 22 21.9739 21.9375 21.8155 21.8125C21.6572 21.6875 21.5364 21.525 21.453 21.325L20.628 18.95H15.778ZM19.978 17.2H16.378L18.228 12.25L19.978 17.2Z"
  ></path>
  <path
    d="M9 14L4.7 18.3C4.51667 18.4833 4.28333 18.575 4 18.575C3.71667 18.575 3.48333 18.4833 3.3 18.3C3.11667 18.1167 3.025 17.8833 3.025 17.6C3.025 17.3167 3.11667 17.0833 3.3 16.9L7.65 12.55C7.01667 11.85 6.4625 11.125 5.9875 10.375C5.5125 9.625 5.1 8.83333 4.75 8H6.85C7.15 8.6 7.47083 9.14167 7.8125 9.625C8.15417 10.1083 8.56667 10.6167 9.05 11.15C9.78333 10.35 10.3917 9.52917 10.875 8.6875C11.3583 7.84583 11.7667 6.95 12.1 6H2C1.71667 6 1.47917 5.90417 1.2875 5.7125C1.09583 5.52083 1 5.28333 1 5C1 4.71667 1.09583 4.47917 1.2875 4.2875C1.47917 4.09583 1.71667 4 2 4H8V3C8 2.71667 8.09583 2.47917 8.2875 2.2875C8.47917 2.09583 8.71667 2 9 2C9.28333 2 9.52083 2.09583 9.7125 2.2875C9.90417 2.47917 10 2.71667 10 3V4H16C16.2833 4 16.5208 4.09583 16.7125 4.2875C16.9042 4.47917 17 4.71667 17 5C17 5.28333 16.9042 5.52083 16.7125 5.7125C16.5208 5.90417 16.2833 6 16 6H14.1C13.75 7.18333 13.275 8.33333 12.675 9.45C12.075 10.5667 11.3333 11.6167 10.45 12.6L12.85 15.05L12.1 17.1L9 14Z"
  ></path>
  <path
    id="vot-loading-icon"
    style="display:none"
    d="M19.8081 16.3697L18.5842 15.6633V13.0832C18.5842 12.9285 18.5228 12.7801 18.4134 12.6707C18.304 12.5613 18.1556 12.4998 18.0009 12.4998C17.8462 12.4998 17.6978 12.5613 17.5884 12.6707C17.479 12.7801 17.4176 12.9285 17.4176 13.0832V15.9998C17.4176 16.1022 17.4445 16.2028 17.4957 16.2915C17.5469 16.3802 17.6205 16.4538 17.7092 16.505L19.2247 17.38C19.2911 17.4189 19.3645 17.4443 19.4407 17.4547C19.5169 17.4652 19.5945 17.4604 19.6688 17.4407C19.7432 17.4211 19.813 17.3869 19.8741 17.3402C19.9352 17.2934 19.9864 17.2351 20.0249 17.1684C20.0634 17.1018 20.0883 17.0282 20.0982 16.952C20.1081 16.8757 20.1028 16.7982 20.0827 16.7239C20.0625 16.6497 20.0279 16.5802 19.9808 16.5194C19.9336 16.4586 19.8749 16.4077 19.8081 16.3697ZM18.0015 10C16.8478 10 15.6603 10.359 14.7011 11C13.7418 11.641 12.9415 12.4341 12.5 13.5C12.0585 14.5659 11.8852 16.0369 12.1103 17.1684C12.3353 18.3 12.8736 19.4942 13.6894 20.31C14.5053 21.1258 15.8684 21.7749 17 22C18.1316 22.2251 19.4341 21.9415 20.5 21.5C21.5659 21.0585 22.359 20.2573 23 19.298C23.641 18.3387 24.0015 17.1537 24.0015 16C23.9998 14.4534 23.5951 13.0936 22.5015 12C21.4079 10.9064 19.5481 10.0017 18.0015 10ZM18.0009 20.6665C17.0779 20.6665 16.1757 20.3928 15.4082 19.88C14.6408 19.3672 14.0427 18.6384 13.6894 17.7857C13.3362 16.933 13.2438 15.9947 13.4239 15.0894C13.604 14.1842 14.0484 13.3527 14.7011 12.7C15.3537 12.0474 16.1852 11.6029 17.0905 11.4228C17.9957 11.2428 18.934 11.3352 19.7867 11.6884C20.6395 12.0416 21.3683 12.6397 21.8811 13.4072C22.3939 14.1746 22.6676 15.0769 22.6676 15.9998C22.666 17.237 22.1738 18.4231 21.299 19.298C20.4242 20.1728 19.2381 20.665 18.0009 20.6665Z"
  ></path>
</svg>`, hw = St`<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24">
  <path
    d="M120-520q-17 0-28.5-11.5T80-560q0-17 11.5-28.5T120-600h104L80-743q-12-12-12-28.5T80-800q12-12 28.5-12t28.5 12l143 144v-104q0-17 11.5-28.5T320-800q17 0 28.5 11.5T360-760v200q0 17-11.5 28.5T320-520H120Zm40 360q-33 0-56.5-23.5T80-240v-160q0-17 11.5-28.5T120-440q17 0 28.5 11.5T160-400v160h280q17 0 28.5 11.5T480-200q0 17-11.5 28.5T440-160H160Zm680-280q-17 0-28.5-11.5T800-480v-240H480q-17 0-28.5-11.5T440-760q0-17 11.5-28.5T480-800h320q33 0 56.5 23.5T880-720v240q0 17-11.5 28.5T840-440ZM600-160q-17 0-28.5-11.5T560-200v-120q0-17 11.5-28.5T600-360h240q17 0 28.5 11.5T880-320v120q0 17-11.5 28.5T840-160H600Z"
  />
</svg>`, fw = St`<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24">
  <path
    d="M480-160q-33 0-56.5-23.5T400-240q0-33 23.5-56.5T480-320q33 0 56.5 23.5T560-240q0 33-23.5 56.5T480-160Zm0-240q-33 0-56.5-23.5T400-480q0-33 23.5-56.5T480-560q33 0 56.5 23.5T560-480q0 33-23.5 56.5T480-400Zm0-240q-33 0-56.5-23.5T400-720q0-33 23.5-56.5T480-800q33 0 56.5 23.5T560-720q0 33-23.5 56.5T480-640Z"
  />
</svg>`, gw = St`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="100%" viewBox="0 0 24 24" class="vot-loader" id="vot-loader-download">
  <path class="vot-loader-main" d="M12 15.575C11.8667 15.575 11.7417 15.5542 11.625 15.5125C11.5083 15.4708 11.4 15.4 11.3 15.3L7.7 11.7C7.5 11.5 7.40417 11.2667 7.4125 11C7.42083 10.7333 7.51667 10.5 7.7 10.3C7.9 10.1 8.1375 9.99583 8.4125 9.9875C8.6875 9.97917 8.925 10.075 9.125 10.275L11 12.15V5C11 4.71667 11.0958 4.47917 11.2875 4.2875C11.4792 4.09583 11.7167 4 12 4C12.2833 4 12.5208 4.09583 12.7125 4.2875C12.9042 4.47917 13 4.71667 13 5V12.15L14.875 10.275C15.075 10.075 15.3125 9.97917 15.5875 9.9875C15.8625 9.99583 16.1 10.1 16.3 10.3C16.4833 10.5 16.5792 10.7333 16.5875 11C16.5958 11.2667 16.5 11.5 16.3 11.7L12.7 15.3C12.6 15.4 12.4917 15.4708 12.375 15.5125C12.2583 15.5542 12.1333 15.575 12 15.575ZM6 20C5.45 20 4.97917 19.8042 4.5875 19.4125C4.19583 19.0208 4 18.55 4 18V16C4 15.7167 4.09583 15.4792 4.2875 15.2875C4.47917 15.0958 4.71667 15 5 15C5.28333 15 5.52083 15.0958 5.7125 15.2875C5.90417 15.4792 6 15.7167 6 16V18H18V16C18 15.7167 18.0958 15.4792 18.2875 15.2875C18.4792 15.0958 18.7167 15 19 15C19.2833 15 19.5208 15.0958 19.7125 15.2875C19.9042 15.4792 20 15.7167 20 16V18C20 18.55 19.8042 19.0208 19.4125 19.4125C19.0208 19.8042 18.55 20 18 20H6Z"/>
  <circle class="vot-loader-progress" cx="12" cy="12" r="9"></circle>
</svg>`, mw = St`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="100%" viewBox="0 0 24 24">
  <path d="M4 20q-.825 0-1.413-.588T2 18V6q0-.825.588-1.413T4 4h16q.825 0 1.413.588T22 6v12q0 .825-.588 1.413T20 20H4Zm2-4h8v-2H6v2Zm10 0h2v-2h-2v2ZM6 12h2v-2H6v2Zm4 0h8v-2h-8v2Z"/>
</svg>`, pw = St`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="100%" viewBox="0 -960 960 960">
  <path d="M555-80H405q-15 0-26-10t-13-25l-12-93q-13-5-24.5-12T307-235l-87 36q-14 5-28 1t-22-17L96-344q-8-13-5-28t15-24l75-57q-1-7-1-13.5v-27q0-6.5 1-13.5l-75-57q-12-9-15-24t5-28l74-129q7-14 21.5-17.5T220-761l87 36q11-8 23-15t24-12l12-93q2-15 13-25t26-10h150q15 0 26 10t13 25l12 93q13 5 24.5 12t22.5 15l87-36q14-5 28-1t22 17l74 129q8 13 5 28t-15 24l-75 57q1 7 1 13.5v27q0 6.5-2 13.5l75 57q12 9 15 24t-5 28l-74 128q-8 13-22.5 17.5T738-199l-85-36q-11 8-23 15t-24 12l-12 93q-2 15-13 25t-26 10Zm-73-260q58 0 99-41t41-99q0-58-41-99t-99-41q-59 0-99.5 41T342-480q0 58 40.5 99t99.5 41Zm0-80q-25 0-42.5-17.5T422-480q0-25 17.5-42.5T482-540q25 0 42.5 17.5T542-480q0 25-17.5 42.5T482-420Zm-2-60Zm-40 320h79l14-106q31-8 57.5-23.5T639-327l99 41 39-68-86-65q5-14 7-29.5t2-31.5q0-16-2-31.5t-7-29.5l86-65-39-68-99 42q-22-23-48.5-38.5T533-694l-13-106h-79l-14 106q-31 8-57.5 23.5T321-633l-99-41-39 68 86 64q-5 15-7 30t-2 32q0 16 2 31t7 30l-86 65 39 68 99-42q22 23 48.5 38.5T427-266l13 106Z"/>
</svg>`, Hu = St`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" >
  <path
    d="M12 14.975q-.2 0-.375-.062T11.3 14.7l-4.6-4.6q-.275-.275-.275-.7t.275-.7q.275-.275.7-.275t.7.275l3.9 3.9l3.9-3.9q.275-.275.7-.275t.7.275q.275.275.275.7t-.275.7l-4.6 4.6q-.15.15-.325.213t-.375.062Z"
  />
</svg>`, yw = St`<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24">
  <path
    d="M647-440H200q-17 0-28.5-11.5T160-480q0-17 11.5-28.5T200-520h447L451-716q-12-12-11.5-28t12.5-28q12-11 28-11.5t28 11.5l264 264q6 6 8.5 13t2.5 15q0 8-2.5 15t-8.5 13L508-188q-11 11-27.5 11T452-188q-12-12-12-28.5t12-28.5l195-195Z"
  />
</svg>`, bw = St`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="100%" viewBox="0 -960 960 960">
  <path d="M480-424 284-228q-11 11-28 11t-28-11q-11-11-11-28t11-28l196-196-196-196q-11-11-11-28t11-28q11-11 28-11t28 11l196 196 196-196q11-11 28-11t28 11q11 11 11 28t-11 28L536-480l196 196q11 11 11 28t-11 28q-11 11-28 11t-28-11L480-424Z"/>
</svg>`, Ya = St`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <g fill="none">
    <path d="m12.593 23.258l-.011.002l-.071.035l-.02.004l-.014-.004l-.071-.035q-.016-.005-.024.005l-.004.01l-.017.428l.005.02l.01.013l.104.074l.015.004l.012-.004l.104-.074l.012-.016l.004-.017l-.017-.427q-.004-.016-.017-.018m.265-.113l-.013.002l-.185.093l-.01.01l-.003.011l.018.43l.005.012l.008.007l.201.093q.019.005.029-.008l.004-.014l-.034-.614q-.005-.018-.02-.022m-.715.002a.02.02 0 0 0-.027.006l-.006.014l-.034.614q.001.018.017.024l.015-.002l.201-.093l.01-.008l.004-.011l.017-.43l-.003-.012l-.01-.01z"/><path fill="currentColor" d="M12 2c5.523 0 10 4.477 10 10s-4.477 10-10 10S2 17.523 2 12S6.477 2 12 2m0 2a8 8 0 1 0 0 16a8 8 0 0 0 0-16m0 11a1 1 0 1 1 0 2a1 1 0 0 1 0-2m0-9a1 1 0 0 1 1 1v6a1 1 0 1 1-2 0V7a1 1 0 0 1 1-1"/>
  </g>
</svg>`, ja = St`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <g fill="none">
    <path d="m12.593 23.258l-.011.002l-.071.035l-.02.004l-.014-.004l-.071-.035q-.016-.005-.024.005l-.004.01l-.017.428l.005.02l.01.013l.104.074l.015.004l.012-.004l.104-.074l.012-.016l.004-.017l-.017-.427q-.004-.016-.017-.018m.265-.113l-.013.002l-.185.093l-.01.01l-.003.011l.018.43l.005.012l.008.007l.201.093q.019.005.029-.008l.004-.014l-.034-.614q-.005-.018-.02-.022m-.715.002a.02.02 0 0 0-.027.006l-.006.014l-.034.614q.001.018.017.024l.015-.002l.201-.093l.01-.008l.004-.011l.017-.43l-.003-.012l-.01-.01z"/><path fill="currentColor" d="M12 2c5.523 0 10 4.477 10 10s-4.477 10-10 10S2 17.523 2 12S6.477 2 12 2m0 2a8 8 0 1 0 0 16a8 8 0 0 0 0-16m0 12a1 1 0 1 1 0 2a1 1 0 0 1 0-2m0-9.5a3.625 3.625 0 0 1 1.348 6.99a.8.8 0 0 0-.305.201c-.044.05-.051.114-.05.18L13 14a1 1 0 0 1-1.993.117L11 14v-.25c0-1.153.93-1.845 1.604-2.116a1.626 1.626 0 1 0-2.229-1.509a1 1 0 1 1-2 0A3.625 3.625 0 0 1 12 6.5"/>
  </g>
</svg>`, vw = St`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <g fill="none">
    <path d="m12.594 23.258l-.012.002l-.071.035l-.02.004l-.014-.004l-.071-.036q-.016-.004-.024.006l-.004.01l-.017.428l.005.02l.01.013l.104.074l.015.004l.012-.004l.104-.074l.012-.016l.004-.017l-.017-.427q-.004-.016-.016-.018m.264-.113l-.014.002l-.184.093l-.01.01l-.003.011l.018.43l.005.012l.008.008l.201.092q.019.005.029-.008l.004-.014l-.034-.614q-.005-.019-.02-.022m-.715.002a.02.02 0 0 0-.027.006l-.006.014l-.034.614q.001.018.017.024l.015-.002l.201-.093l.01-.008l.003-.011l.018-.43l-.003-.012l-.01-.01z"/>
    <path fill="currentColor" d="M20 9a1 1 0 0 1 1 1v1a8 8 0 0 1-8 8H9.414l.793.793a1 1 0 0 1-1.414 1.414l-2.496-2.496a1 1 0 0 1-.287-.567L6 17.991a1 1 0 0 1 .237-.638l.056-.06l2.5-2.5a1 1 0 0 1 1.414 1.414L9.414 17H13a6 6 0 0 0 6-6v-1a1 1 0 0 1 1-1m-4.793-6.207l2.5 2.5a1 1 0 0 1 0 1.414l-2.5 2.5a1 1 0 1 1-1.414-1.414L14.586 7H11a6 6 0 0 0-6 6v1a1 1 0 1 1-2 0v-1a8 8 0 0 1 8-8h3.586l-.793-.793a1 1 0 0 1 1.414-1.414"/>
  </g>
</svg>`, ww = St`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <path fill="currentColor" d="M7 15q1.25 0 2.125-.875T10 12t-.875-2.125T7 9t-2.125.875T4 12t.875 2.125T7 15m0 3q-2.5 0-4.25-1.75T1 12t1.75-4.25T7 6q2.025 0 3.538 1.15T12.65 10h8.375L23 11.975l-3.5 4L17 14l-2 2l-2-2h-.35q-.625 1.8-2.175 2.9T7 18"/>
  </svg>`;
function Qt(n, t, e) {
  n[t].addListener(e);
}
function te(n, t, e) {
  n[t].removeListener(e);
}
function Tt(n, t) {
  n.hidden = t;
}
function kt(n) {
  return n.hidden;
}
class Sw {
  constructor() {
    u(this, "button");
    u(this, "loaderMain");
    u(this, "loaderCircle");
    u(this, "onClick", new z());
    u(this, "events", {
      click: this.onClick
    });
    u(this, "_progress", 0);
    const t = this.createElements();
    this.button = t.button, this.loaderMain = t.loaderMain, this.loaderCircle = t.loaderCircle, this.progress = 0;
  }
  createElements() {
    const t = L.createIconButton(gw, {
      ariaLabel: "Download translation"
    }), e = t.querySelector(".vot-loader-main");
    if (!e)
      throw new Error("[VOT] DownloadButton loader main element not found");
    const i = t.querySelector(
      ".vot-loader-progress"
    );
    if (!i)
      throw new Error("[VOT] DownloadButton loader circle element not found");
    return t.addEventListener("click", () => {
      this.onClick.dispatch();
    }), { button: t, loaderMain: e, loaderCircle: i };
  }
  addEventListener(t, e) {
    return Qt(this.events, "click", e), this;
  }
  removeEventListener(t, e) {
    return te(this.events, "click", e), this;
  }
  get progress() {
    return this._progress;
  }
  set progress(t) {
    const e = Tw(t);
    this._progress = e;
    const i = this.getCircleCircumference();
    this.loaderCircle.style.strokeDasharray = `${i}`;
    const s = i * (1 - e / 100);
    this.loaderCircle.style.strokeDashoffset = `${s}`, this.loaderMain.style.opacity = e === 0 ? "1" : "0", this.loaderCircle.style.opacity = e === 0 ? "0" : "1";
  }
  getCircleCircumference() {
    const t = this.loaderCircle.r?.baseVal?.value ?? 0;
    return 2 * Math.PI * t;
  }
  set hidden(t) {
    Tt(this.button, t);
  }
  get hidden() {
    return kt(this.button);
  }
}
function Tw(n) {
  if (!Number.isFinite(n)) return 0;
  const t = n < 1 ? n * 100 : n;
  return Math.max(0, Math.min(100, Math.round(t)));
}
class $t {
  constructor({ labelText: t, icon: e }) {
    u(this, "container");
    u(this, "icon");
    u(this, "text");
    u(this, "_labelText");
    u(this, "_icon");
    this._labelText = t, this._icon = e;
    const i = this.createElements();
    this.container = i.container, this.icon = i.icon, this.text = i.text;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-label"]), e = L.createEl("span", ["vot-label-text"]);
    e.textContent = this._labelText;
    const i = L.createEl("span", ["vot-label-icon"]);
    return this._icon ? wt(this._icon, i) : i.hidden = !0, t.append(e, i), {
      container: t,
      icon: i,
      text: e
    };
  }
  set hidden(t) {
    Tt(this.container, t);
  }
  get hidden() {
    return kt(this.container);
  }
}
class Fs {
  constructor({ titleHtml: t, isTemp: e = !1 }) {
    u(this, "container");
    u(this, "backdrop");
    u(this, "box");
    u(this, "contentWrapper");
    u(this, "headerContainer");
    u(this, "titleContainer");
    u(this, "title");
    u(this, "closeButton");
    u(this, "bodyContainer");
    u(this, "footerContainer");
    u(this, "onClose", new z());
    u(this, "events", {
      close: this.onClose
    });
    // Focus management for accessibility.
    u(this, "previouslyFocused", null);
    u(this, "keydownListener");
    // Adaptive vertical alignment for long content.
    u(this, "adaptiveAlignObserver");
    u(this, "adaptiveAlignRaf", null);
    u(this, "handleViewportChange", () => {
      this.scheduleAdaptiveVerticalAlign();
    });
    u(this, "titleId", typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `vot-dialog-title-${Math.random().toString(36).slice(2)}`);
    u(this, "_titleHtml");
    u(this, "_isTemp");
    this._titleHtml = t, this._isTemp = e;
    const i = this.createElements();
    this.container = i.container, this.backdrop = i.backdrop, this.box = i.box, this.contentWrapper = i.contentWrapper, this.headerContainer = i.headerContainer, this.titleContainer = i.titleContainer, this.title = i.title, this.closeButton = i.closeButton, this.bodyContainer = i.bodyContainer, this.footerContainer = i.footerContainer;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-dialog-container"]);
    this._isTemp && t.classList.add("vot-dialog-temp"), t.hidden = !this._isTemp, t.setAttribute("aria-hidden", t.hidden ? "true" : "false"), t.toggleAttribute("inert", t.hidden);
    const e = L.createEl("vot-block", ["vot-dialog-backdrop"]), i = L.createEl("vot-block", ["vot-dialog"]);
    i.dataset.verticalAlign = "center", i.setAttribute("role", "dialog"), i.setAttribute("aria-modal", "true"), i.tabIndex = -1;
    const s = L.createEl("vot-block", [
      "vot-dialog-content-wrapper"
    ]), o = L.createEl("vot-block", [
      "vot-dialog-header-container"
    ]), r = L.createEl("vot-block", [
      "vot-dialog-title-container"
    ]), a = L.createEl("vot-block", ["vot-dialog-title"]);
    a.id = this.titleId, a.append(this._titleHtml), r.appendChild(a), i.setAttribute("aria-labelledby", this.titleId);
    const l = L.createIconButton(bw, {
      ariaLabel: "Close"
    });
    l.classList.add("vot-dialog-close-button"), e.addEventListener("click", () => {
      this.close();
    }), l.addEventListener("click", () => {
      this.close();
    }), o.append(r, l);
    const c = L.createEl("vot-block", [
      "vot-dialog-body-container"
    ]), d = L.createEl("vot-block", [
      "vot-dialog-footer-container"
    ]);
    return s.append(o, c, d), i.appendChild(s), t.append(e, i), i.addEventListener("click", (h) => {
      h.stopPropagation();
    }), {
      container: t,
      backdrop: e,
      box: i,
      contentWrapper: s,
      headerContainer: o,
      titleContainer: r,
      title: a,
      closeButton: l,
      bodyContainer: c,
      footerContainer: d
    };
  }
  addEventListener(t, e) {
    return Qt(this.events, "close", e), this;
  }
  removeEventListener(t, e) {
    return te(this.events, "close", e), this;
  }
  open() {
    return this.previouslyFocused ?? (this.previouslyFocused = document.activeElement), this.hidden = !1, this.attachKeydownTrap(), this.attachAdaptiveVerticalAlign(), queueMicrotask(() => this.focusFirst()), this;
  }
  remove() {
    return this.detachAdaptiveVerticalAlign(), this.detachKeydownTrap(), this.container.remove(), this.restoreFocus(), this.onClose.dispatch(), this;
  }
  close() {
    return this._isTemp ? this.remove() : (this.detachAdaptiveVerticalAlign(), this.detachKeydownTrap(), this.hidden = !0, this.restoreFocus(), this.onClose.dispatch(), this);
  }
  attachAdaptiveVerticalAlign() {
    if (this.adaptiveAlignObserver) {
      this.scheduleAdaptiveVerticalAlign();
      return;
    }
    typeof ResizeObserver < "u" && (this.adaptiveAlignObserver = new ResizeObserver(() => {
      this.scheduleAdaptiveVerticalAlign();
    }), this.adaptiveAlignObserver.observe(this.contentWrapper)), globalThis.addEventListener("resize", this.handleViewportChange, {
      passive: !0
    }), globalThis.visualViewport && (globalThis.visualViewport.addEventListener(
      "resize",
      this.handleViewportChange,
      { passive: !0 }
    ), globalThis.visualViewport.addEventListener(
      "scroll",
      this.handleViewportChange,
      { passive: !0 }
    )), this.scheduleAdaptiveVerticalAlign();
  }
  detachAdaptiveVerticalAlign() {
    this.adaptiveAlignObserver && (this.adaptiveAlignObserver.disconnect(), this.adaptiveAlignObserver = void 0), globalThis.removeEventListener("resize", this.handleViewportChange), globalThis.visualViewport?.removeEventListener(
      "resize",
      this.handleViewportChange
    ), globalThis.visualViewport?.removeEventListener(
      "scroll",
      this.handleViewportChange
    ), this.adaptiveAlignRaf !== null && (cancelAnimationFrame(this.adaptiveAlignRaf), this.adaptiveAlignRaf = null);
  }
  scheduleAdaptiveVerticalAlign() {
    this.adaptiveAlignRaf !== null && cancelAnimationFrame(this.adaptiveAlignRaf), this.adaptiveAlignRaf = requestAnimationFrame(() => {
      this.adaptiveAlignRaf = null, this.updateAdaptiveVerticalAlign();
    });
  }
  updateAdaptiveVerticalAlign() {
    const t = globalThis.visualViewport?.height ?? globalThis.innerHeight;
    if (!t || t <= 0)
      return;
    const e = 16, i = Math.max(160, Math.round(t * 0.75)), s = Math.max(160, Math.round(t - e * 2)), o = this.contentWrapper.scrollHeight, r = this.box.dataset.verticalAlign === "top", a = i - 8, l = Math.round(t * 0.6);
    (r ? o > l : o >= a) ? (this.box.dataset.verticalAlign = "top", this.box.style.setProperty("--vot-dialog-max-height", `${s}px`)) : (this.box.dataset.verticalAlign = "center", this.box.style.setProperty("--vot-dialog-max-height", `${i}px`));
  }
  restoreFocus() {
    const t = this.previouslyFocused;
    this.previouslyFocused = null, t && t instanceof HTMLElement && document.contains(t) && t.focus();
  }
  getFocusableElements() {
    const t = [
      "button:not([disabled])",
      "[href]",
      "input:not([disabled])",
      "select:not([disabled])",
      "textarea:not([disabled])",
      "[tabindex]:not([tabindex='-1'])",
      "[role='button']:not([aria-disabled='true'])"
    ];
    return Array.from(
      this.container.querySelectorAll(t.join(","))
    ).filter((e) => !e.hidden && e.getClientRects().length > 0);
  }
  focusFirst() {
    (this.getFocusableElements()[0] ?? this.closeButton ?? this.box).focus?.();
  }
  attachKeydownTrap() {
    this.keydownListener || (this.keydownListener = (t) => {
      if (t.key === "Escape") {
        t.preventDefault(), this.close();
        return;
      }
      if (t.key !== "Tab")
        return;
      const e = this.getFocusableElements();
      if (!e.length) {
        t.preventDefault(), this.box.focus();
        return;
      }
      const i = e[0], s = e.at(-1) ?? i, o = document.activeElement;
      t.shiftKey ? (o === i || o === this.box) && (t.preventDefault(), s.focus()) : o === s && (t.preventDefault(), i.focus());
    }, this.container.addEventListener("keydown", this.keydownListener));
  }
  detachKeydownTrap() {
    this.keydownListener && (this.container.removeEventListener("keydown", this.keydownListener), this.keydownListener = void 0);
  }
  set hidden(t) {
    Tt(this.container, t), this.container.setAttribute("aria-hidden", t ? "true" : "false"), this.container.toggleAttribute("inert", t);
  }
  get hidden() {
    return kt(this.container);
  }
  get isDialogOpen() {
    return !this.container.hidden;
  }
}
class Ns {
  constructor({
    labelHtml: t = "",
    placeholder: e = "",
    value: i = "",
    multiline: s = !1
  }) {
    u(this, "container");
    u(this, "input");
    u(this, "label");
    u(this, "onInput", new z());
    u(this, "onChange", new z());
    u(this, "events", {
      input: this.onInput,
      change: this.onChange
    });
    u(this, "_labelHtml");
    u(this, "_multiline");
    u(this, "_placeholder");
    u(this, "_value");
    this._labelHtml = t, this._multiline = s, this._placeholder = e, this._value = i;
    const o = this.createElements();
    this.container = o.container, this.input = o.input, this.label = o.label;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-textfield"]), e = document.createElement(
      this._multiline ? "textarea" : "input"
    );
    this._labelHtml || e.classList.add("vot-show-placeholer", "vot-show-placeholder"), e.placeholder = this._placeholder, e.value = this._value;
    const i = L.createEl("span");
    return i.append(this._labelHtml), t.append(e, i), e.addEventListener("input", () => {
      this._value = this.input.value, this.onInput.dispatch(this._value);
    }), e.addEventListener("change", () => {
      this._value = this.input.value, this.onChange.dispatch(this._value);
    }), {
      container: t,
      label: i,
      input: e
    };
  }
  addEventListener(t, e) {
    return Qt(this.events, t, e), this;
  }
  removeEventListener(t, e) {
    return te(this.events, t, e), this;
  }
  get value() {
    return this._value;
  }
  /**
   * If you set a different new value, it will trigger the change event
   */
  set value(t) {
    this._value !== t && (this.input.value = this._value = t, this.onChange.dispatch(this._value));
  }
  get placeholder() {
    return this._placeholder;
  }
  set placeholder(t) {
    this.input.placeholder = this._placeholder = t;
  }
  get disabled() {
    return this.input.disabled;
  }
  set disabled(t) {
    this.input.disabled = t;
  }
  set hidden(t) {
    Tt(this.container, t);
  }
  get hidden() {
    return kt(this.container);
  }
}
class ht {
  constructor({
    selectTitle: t,
    dialogTitle: e,
    items: i,
    searchItemsProvider: s,
    labelElement: o,
    dialogParent: r = document.documentElement,
    multiSelect: a
  }) {
    u(this, "container");
    u(this, "outer");
    u(this, "arrowIcon");
    u(this, "title");
    u(this, "dialogParent");
    u(this, "labelElement");
    u(this, "_selectTitle");
    u(this, "_dialogTitle");
    u(this, "multiSelect");
    u(this, "baseItems");
    u(this, "_items");
    u(this, "searchItemsProvider");
    u(this, "isLoading", !1);
    u(this, "isDialogOpen", !1);
    u(this, "searchRequestId", 0);
    u(this, "onSelectItem", new z());
    u(this, "onBeforeOpen", new z());
    u(this, "events", {
      selectItem: this.onSelectItem,
      beforeOpen: this.onBeforeOpen
    });
    u(this, "contentList");
    u(this, "contentItemSearchDatasetKey", "votSearchLabel");
    u(this, "contentItemIndexDatasetKey", "votIndex");
    u(this, "selectedItems", []);
    u(this, "selectedValues");
    u(this, "multiSelectItemHandle", (t) => {
      const e = t.value;
      this.selectedValues.has(e) && this.selectedValues.size > 1 ? this.selectedValues.delete(e) : this.selectedValues.add(e), this.syncItemsSelectionState(), this.syncItemsSelectionState(this.baseItems), this.updateSelectedState(), this.onSelectItem.dispatch(Array.from(this.selectedValues));
    });
    u(this, "singleSelectItemHandle", (t) => {
      const e = t.value;
      this.selectedValues = /* @__PURE__ */ new Set([e]), this.syncItemsSelectionState(), this.syncItemsSelectionState(this.baseItems), this.updateSelectedState(), this.onSelectItem.dispatch(e);
    });
    u(this, "onContentItemClick", (t) => {
      if (!(t.target instanceof HTMLElement))
        return;
      const e = t.target.closest(
        ".vot-select-content-item"
      );
      if (!e || e.inert || !this.contentList?.contains(e))
        return;
      const i = e.dataset[this.contentItemIndexDatasetKey];
      if (!i)
        return;
      const s = this._items[Number(i)];
      if (s) {
        if (this.multiSelect) {
          this.multiSelectItemHandle(s);
          return;
        }
        this.singleSelectItemHandle(s);
      }
    });
    this._selectTitle = t, this._dialogTitle = e, this.baseItems = this.cloneItems(i), this._items = this.cloneItems(i), this.searchItemsProvider = s, this.multiSelect = a ?? !1, this.labelElement = o, this.dialogParent = r, this.selectedValues = this.calcSelectedValues();
    const l = this.createElements();
    this.container = l.container, this.outer = l.outer, this.arrowIcon = l.arrowIcon, this.title = l.title;
  }
  cloneItems(t) {
    return t.map((e) => ({ ...e }));
  }
  static genLanguageItems(t, e) {
    return t.map((i) => {
      const s = `langs.${i}`, o = p.get(s);
      return {
        label: o === s ? i.toUpperCase() : o,
        value: i,
        selected: e === i
      };
    });
  }
  syncItemsSelectionState(t = this._items) {
    for (const e of t)
      e.selected = this.selectedValues.has(e.value);
  }
  restoreBaseItems() {
    this._items = this.cloneItems(this.baseItems), this.syncItemsSelectionState(), this.updateSelectedState();
  }
  createDialogContentList() {
    const t = L.createEl("vot-block", ["vot-select-content-list"]);
    for (const [e, i] of this._items.entries()) {
      const s = L.createEl("vot-block", ["vot-select-content-item"]);
      s.textContent = i.label, s.dataset.votSelected = i.selected === !0 ? "true" : "false", s.dataset.votValue = i.value, s.dataset[this.contentItemSearchDatasetKey] = i.label.toLowerCase(), s.dataset[this.contentItemIndexDatasetKey] = String(e), i.disabled && (s.inert = !0), t.appendChild(s);
    }
    return t.addEventListener("click", this.onContentItemClick), this.selectedItems = Array.from(t.children), t;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-select"]);
    this.labelElement ? (t.classList.add("vot-select--labeled"), t.append(this.labelElement)) : t.classList.add("vot-select--control-only");
    const e = L.createEl("vot-block", ["vot-select-outer"]);
    L.makeButtonLike(e), e.setAttribute("aria-haspopup", "dialog"), e.setAttribute("aria-expanded", "false");
    const i = L.createEl("vot-block", ["vot-select-title"]);
    i.textContent = this.visibleText;
    const s = L.createEl("vot-block", ["vot-select-arrow-icon"]);
    return wt(Hu, s), e.append(i, s), e.addEventListener("click", () => {
      if (!this.disabled && !(this.isLoading || this.isDialogOpen))
        try {
          this.isLoading = !0;
          const o = new Fs({
            titleHtml: this._dialogTitle,
            isTemp: !0
          });
          this.onBeforeOpen.dispatch(o), this.dialogParent.appendChild(o.container), this.isDialogOpen = !0, e.setAttribute("aria-expanded", "true");
          const r = new Ns({
            labelHtml: p.get("searchField")
          });
          r.addEventListener("input", async (a) => {
            const l = ++this.searchRequestId;
            if (this.searchItemsProvider) {
              const d = await this.searchItemsProvider(a);
              if (l !== this.searchRequestId)
                return;
              this.updateItems(d, { persist: !1 });
            }
            const c = a.toLowerCase();
            for (const d of this.selectedItems) {
              const h = d.dataset[this.contentItemSearchDatasetKey] ?? "";
              d.hidden = !h.includes(c);
            }
          }), this.contentList = this.createDialogContentList(), o.bodyContainer.append(
            r.container,
            this.contentList
          ), o.addEventListener("close", () => {
            this.isDialogOpen = !1, this.restoreBaseItems(), this.selectedItems = [], this.contentList = void 0, e.setAttribute("aria-expanded", "false");
          }), o.open();
        } finally {
          this.isLoading = !1;
        }
    }), t.appendChild(e), {
      container: t,
      outer: e,
      arrowIcon: s,
      title: i
    };
  }
  calcSelectedValues() {
    return new Set(
      this._items.filter((t) => t.selected).map((t) => t.value)
    );
  }
  addEventListener(t, e) {
    return Qt(this.events, t, e), this;
  }
  removeEventListener(t, e) {
    return te(this.events, t, e), this;
  }
  updateTitle() {
    return this.title.textContent = this.visibleText, this;
  }
  updateSelectedState() {
    if (this.selectedItems.length > 0)
      for (const t of this.selectedItems) {
        const e = t.dataset.votValue;
        e !== void 0 && (t.dataset.votSelected = this.selectedValues.has(e).toString());
      }
    return this.updateTitle(), this;
  }
  setSelectedValue(t) {
    const e = Array.isArray(t) ? t : [t];
    let i;
    return this.multiSelect ? i = e : i = e.length > 0 ? [e[0]] : [], this.selectedValues = new Set(i), this.syncItemsSelectionState(), this.syncItemsSelectionState(this.baseItems), this.updateSelectedState(), this;
  }
  /**
   * @warning Use chaining with this method or reassign to variable to get the updated type of instance
   */
  updateItems(t, e = {}) {
    const { persist: i = !0 } = e, s = this.cloneItems(t);
    i && (this.baseItems = this.cloneItems(s)), this._items = s, this.selectedValues = this.calcSelectedValues(), this.updateSelectedState();
    const o = this.contentList?.parentElement;
    if (!this.contentList || !o)
      return this;
    const r = this.contentList;
    return this.contentList = this.createDialogContentList(), o.replaceChild(this.contentList, r), this;
  }
  get visibleText() {
    return this.multiSelect ? this._items.filter((t) => this.selectedValues.has(t.value)).map((t) => t.label).join(", ") || this._selectTitle : this._items.find((t) => t.selected)?.label ?? this._selectTitle;
  }
  set selectTitle(t) {
    this._selectTitle = t, this.updateTitle();
  }
  set hidden(t) {
    Tt(this.container, t);
  }
  get hidden() {
    return kt(this.container);
  }
  get disabled() {
    return this.outer.getAttribute("disabled") === "true" || this.outer.getAttribute("aria-disabled") === "true";
  }
  set disabled(t) {
    if (t) {
      this.outer.setAttribute("disabled", "true");
      return;
    }
    this.outer.removeAttribute("disabled");
  }
}
class kw {
  constructor({
    from: {
      selectTitle: t = p.get("videoLanguage"),
      dialogTitle: e = p.get("videoLanguage"),
      items: i
    },
    to: {
      selectTitle: s = p.get(
        "translationLanguage"
      ),
      dialogTitle: o = p.get(
        "translationLanguage"
      ),
      items: r
    },
    dialogParent: a = document.documentElement
  }) {
    u(this, "container");
    u(this, "fromSelect");
    u(this, "directionIcon");
    u(this, "toSelect");
    u(this, "dialogParent");
    // from select opts
    u(this, "_fromSelectTitle");
    u(this, "_fromDialogTitle");
    u(this, "_fromItems");
    // to select opts
    u(this, "_toSelectTitle");
    u(this, "_toDialogTitle");
    u(this, "_toItems");
    this._fromSelectTitle = t, this._fromDialogTitle = e, this._fromItems = i, this._toSelectTitle = s, this._toDialogTitle = o, this._toItems = r, this.dialogParent = a;
    const l = this.createElements();
    this.container = l.container, this.fromSelect = l.fromSelect, this.directionIcon = l.directionIcon, this.toSelect = l.toSelect;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-lang-select"]), e = new ht({
      selectTitle: this._fromSelectTitle,
      dialogTitle: this._fromDialogTitle,
      items: this._fromItems,
      dialogParent: this.dialogParent
    }), i = L.createEl("vot-block", ["vot-lang-select-icon"]);
    wt(yw, i);
    const s = new ht({
      selectTitle: this._toSelectTitle,
      dialogTitle: this._toDialogTitle,
      items: this._toItems,
      dialogParent: this.dialogParent
    });
    return t.append(e.container, i, s.container), {
      container: t,
      fromSelect: e,
      directionIcon: i,
      toSelect: s
    };
  }
  setSelectedValues(t, e) {
    return this.fromSelect.setSelectedValue(t), this.toSelect.setSelectedValue(e), this;
  }
  updateItems(t, e) {
    return this._fromItems = t, this._toItems = e, this.fromSelect = this.fromSelect.updateItems(t), this.toSelect = this.toSelect.updateItems(e), this;
  }
}
class re {
  constructor({
    labelHtml: t,
    value: e = 50,
    min: i = 0,
    max: s = 100,
    step: o = 1
  }) {
    u(this, "container");
    u(this, "input");
    u(this, "label");
    u(this, "onInput", new z());
    u(this, "_labelHtml");
    u(this, "_value");
    u(this, "_min");
    u(this, "_max");
    u(this, "_step");
    this._labelHtml = t, this._value = e, this._min = i, this._max = s, this._step = o;
    const r = this.createElements();
    this.container = r.container, this.input = r.input, this.label = r.label, this.update();
  }
  updateProgress() {
    const t = this._max - this._min, e = t <= 0 ? 0 : (this._value - this._min) / t, i = Math.max(0, Math.min(1, e));
    return this.container.style.setProperty("--vot-progress", i.toString()), this;
  }
  update() {
    return this._value = this.input.valueAsNumber, this._min = +this.input.min, this._max = +this.input.max, this.updateProgress(), this;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-slider"]), e = document.createElement("input");
    e.type = "range", e.min = this._min.toString(), e.max = this._max.toString(), e.step = this._step.toString(), e.value = this._value.toString();
    const i = L.createEl("span");
    return wt(this._labelHtml, i), t.append(e, i), e.addEventListener("input", () => {
      this.update(), this.onInput.dispatch(this._value, !1);
    }), {
      container: t,
      label: i,
      input: e
    };
  }
  addEventListener(t, e) {
    return this.onInput.addListener(e), this;
  }
  removeEventListener(t, e) {
    return this.onInput.removeListener(e), this;
  }
  get value() {
    return this._value;
  }
  /**
   * If you set a different new value, it will trigger the input event
   */
  set value(t) {
    this._value = cs(t, this._min, this._max), this.input.value = this._value.toString(), this.updateProgress(), this.onInput.dispatch(this._value, !0);
  }
  get min() {
    return this._min;
  }
  set min(t) {
    this._min = t, this.input.min = this._min.toString(), this._value = cs(this._value, this._min, this._max), this.input.value = this._value.toString(), this.updateProgress();
  }
  get max() {
    return this._max;
  }
  set max(t) {
    this._max = t, this.input.max = this._max.toString(), this._value = cs(this._value, this._min, this._max), this.input.value = this._value.toString(), this.updateProgress();
  }
  get step() {
    return this._step;
  }
  set step(t) {
    this._step = t, this.input.step = this._step.toString();
  }
  get disabled() {
    return this.input.disabled;
  }
  set disabled(t) {
    this.input.disabled = t;
  }
  set hidden(t) {
    Tt(this.container, t);
  }
  get hidden() {
    return kt(this.container);
  }
}
function cs(n, t, e) {
  return !Number.isFinite(n) || e < t ? t : Math.max(t, Math.min(e, n));
}
class ae {
  constructor({
    labelText: t,
    labelEOL: e = "",
    value: i = 50,
    symbol: s = "%"
  }) {
    u(this, "container");
    u(this, "strong");
    u(this, "text");
    u(this, "_labelText");
    u(this, "_labelEOL");
    u(this, "_value");
    u(this, "_symbol");
    this._labelText = t, this._labelEOL = e, this._value = i, this._symbol = s;
    const o = this.createElements();
    this.container = o.container, this.strong = o.strong, this.text = o.text;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-slider-label"]), e = L.createEl("span", ["vot-slider-label-text"]);
    e.textContent = this.labelText;
    const i = L.createEl("span", ["vot-slider-label-value"]);
    return i.textContent = this.valueText, t.append(e, i), {
      container: t,
      strong: i,
      text: e
    };
  }
  get labelText() {
    return `${this._labelText}${this._labelEOL}`;
  }
  get valueText() {
    return `${this._value}${this._symbol}`;
  }
  get value() {
    return this._value;
  }
  set value(t) {
    this._value = t, this.strong.textContent = this.valueText;
  }
  set hidden(t) {
    Tt(this.container, t);
  }
  get hidden() {
    return kt(this.container);
  }
}
class ds {
  constructor({
    position: t = "default",
    direction: e = "default",
    status: i = "none",
    labelHtml: s = ""
  }) {
    u(this, "container");
    u(this, "translateButton");
    u(this, "separator");
    u(this, "pipButton");
    u(this, "separator2");
    u(this, "menuButton");
    u(this, "label");
    // Opacity is driven by a CSS class so host pages cannot break visibility by
    // writing inline `style="opacity:0; pointer-events:none"`.
    u(this, "_opacity", 1);
    u(this, "_position");
    u(this, "_direction");
    u(this, "_status");
    /** Text shown next to the translate icon (plain text, not HTML). */
    u(this, "_labelText");
    this._position = t, this._direction = e, this._status = i, this._labelText = s;
    const o = this.createElements();
    this.container = o.container, this.translateButton = o.translateButton, this.separator = o.separator, this.pipButton = o.pipButton, this.separator2 = o.separator2, this.menuButton = o.menuButton, this.label = o.label;
  }
  static calcPosition(t, e) {
    return e ? t <= 44 ? "left" : t >= 66 ? "right" : "default" : "default";
  }
  static calcDirection(t) {
    return ["default", "top"].includes(t) ? "row" : "column";
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-segmented-button"]);
    t.dataset.position = this._position, t.dataset.direction = this._direction, t.dataset.status = this._status;
    const e = L.createEl("vot-block", [
      "vot-segment",
      "vot-translate-button"
    ]);
    e.setAttribute("role", "button"), e.tabIndex = 0, e.setAttribute("aria-label", this._labelText || "Translate"), wt(dw, e);
    const i = L.createEl("span", ["vot-segment-label"]);
    i.textContent = this._labelText, e.appendChild(i);
    const s = L.createEl("vot-block", ["vot-separator"]), o = L.createEl("vot-block", ["vot-segment-only-icon"]);
    o.setAttribute("role", "button"), o.tabIndex = 0, o.setAttribute("aria-label", "Picture in picture"), wt(hw, o);
    const r = L.createEl("vot-block", ["vot-separator"]), a = L.createEl("vot-block", ["vot-segment-only-icon"]);
    return a.setAttribute("role", "button"), a.tabIndex = 0, a.setAttribute("aria-label", "Menu"), a.setAttribute("aria-haspopup", "dialog"), a.setAttribute("aria-expanded", "false"), wt(fw, a), t.append(
      e,
      s,
      o,
      r,
      a
    ), {
      container: t,
      translateButton: e,
      separator: s,
      pipButton: o,
      separator2: r,
      menuButton: a,
      label: i
    };
  }
  showPiPButton(t) {
    return this.separator2.hidden = this.pipButton.hidden = !t, this;
  }
  setText(t) {
    return this._labelText = t, this.label.textContent = t, this.translateButton.setAttribute("aria-label", t || "Translate"), this;
  }
  remove() {
    return this.container.remove(), this;
  }
  get tooltipPos() {
    switch (this.position) {
      case "left":
        return "right";
      case "right":
        return "left";
      default:
        return "bottom";
    }
  }
  set status(t) {
    this._status = this.container.dataset.status = t;
  }
  get status() {
    return this._status;
  }
  set loading(t) {
    this.container.dataset.loading = t.toString();
  }
  get loading() {
    return this.container.dataset.loading === "true";
  }
  set hidden(t) {
    Tt(this.container, t);
  }
  get hidden() {
    return kt(this.container);
  }
  get position() {
    return this._position;
  }
  set position(t) {
    this._position = this.container.dataset.position = t;
  }
  get direction() {
    return this._direction;
  }
  set direction(t) {
    this._direction = this.container.dataset.direction = t;
  }
  set opacity(t) {
    const e = Number.isFinite(t) ? t : 1;
    this._opacity = e;
    const i = e <= 0.01;
    this.container.classList.toggle("vot-segmented-button--hidden", i);
  }
  get opacity() {
    return this._opacity;
  }
}
class Lw {
  constructor({ position: t = "default", titleHtml: e = "" }) {
    u(this, "container");
    u(this, "contentWrapper");
    u(this, "headerContainer");
    u(this, "bodyContainer");
    u(this, "footerContainer");
    u(this, "titleContainer");
    u(this, "title");
    u(this, "_position");
    u(this, "_titleHtml");
    // A11y: stable ids for aria-controls / aria-labelledby.
    u(this, "menuId", typeof crypto < "u" && "randomUUID" in crypto ? `vot-menu-${crypto.randomUUID()}` : `vot-menu-${Math.random().toString(36).slice(2)}`);
    u(this, "titleId", typeof crypto < "u" && "randomUUID" in crypto ? `vot-menu-title-${crypto.randomUUID()}` : `vot-menu-title-${Math.random().toString(36).slice(2)}`);
    this._position = t, this._titleHtml = e;
    const i = this.createElements();
    this.container = i.container, this.contentWrapper = i.contentWrapper, this.headerContainer = i.headerContainer, this.bodyContainer = i.bodyContainer, this.footerContainer = i.footerContainer, this.titleContainer = i.titleContainer, this.title = i.title;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-menu"]);
    t.hidden = !0, t.id = this.menuId, t.dataset.position = this._position, t.setAttribute("role", "dialog"), t.setAttribute("aria-modal", "false"), t.setAttribute("aria-hidden", "true"), t.toggleAttribute("inert", !0);
    const e = L.createEl("vot-block", [
      "vot-menu-content-wrapper"
    ]);
    t.appendChild(e);
    const i = L.createEl("vot-block", [
      "vot-menu-header-container"
    ]), s = L.createEl("vot-block", [
      "vot-menu-title-container"
    ]);
    i.appendChild(s);
    const o = L.createEl("vot-block", ["vot-menu-title"]);
    o.id = this.titleId, o.append(this._titleHtml), s.appendChild(o), t.setAttribute("aria-labelledby", this.titleId);
    const r = L.createEl("vot-block", ["vot-menu-body-container"]), a = L.createEl("vot-block", [
      "vot-menu-footer-container"
    ]);
    return e.append(i, r, a), {
      container: t,
      contentWrapper: e,
      headerContainer: i,
      bodyContainer: r,
      footerContainer: a,
      titleContainer: s,
      title: o
    };
  }
  setText(t) {
    return this._titleHtml = this.title.textContent = t, this;
  }
  remove() {
    return this.container.remove(), this;
  }
  set hidden(t) {
    Tt(this.container, t), this.container.setAttribute("aria-hidden", t ? "true" : "false"), this.container.toggleAttribute("inert", t);
  }
  get hidden() {
    return kt(this.container);
  }
  get position() {
    return this._position;
  }
  set position(t) {
    this._position = this.container.dataset.position = t;
  }
}
const Re = class Re {
  constructor({
    mount: t,
    globalPortal: e,
    data: i = {},
    videoHandler: s,
    intervalIdleChecker: o
  }) {
    u(this, "mount");
    u(this, "globalPortal");
    u(this, "abortController", null);
    u(this, "defaultVolumePersistTimer");
    u(this, "defaultVolumePersistDelayMs", 250);
    u(this, "dragging", !1);
    u(this, "dragCandidate", !1);
    u(this, "dragDirty", !1);
    u(this, "dragStartX", 0);
    u(this, "dragStartY", 0);
    u(this, "currentClientX", 0);
    u(this, "dragThresholdPx", 6);
    u(this, "containerRect", null);
    u(this, "dragIsBigContainer", null);
    u(this, "checkerUnsubscribe", null);
    u(this, "initialized", !1);
    u(this, "data");
    u(this, "videoHandler");
    u(this, "intervalIdleChecker");
    u(this, "events", {
      "click:settings": new z(),
      "click:pip": new z(),
      "click:downloadTranslation": new z(),
      "click:downloadSubtitles": new z(),
      "click:translate": new z(),
      "input:videoVolume": new z(),
      "input:translationVolume": new z(),
      "select:fromLanguage": new z(),
      "select:toLanguage": new z(),
      "select:subtitles": new z()
    });
    // button
    u(this, "votButton");
    u(this, "votButtonTooltip");
    // menu
    u(this, "votMenu");
    u(this, "downloadTranslationButton");
    u(this, "downloadSubtitlesButton");
    u(this, "openSettingsButton");
    u(this, "languagePairSelect");
    u(this, "subtitlesSelectLabel");
    u(this, "subtitlesSelect");
    u(this, "videoVolumeSliderLabel");
    u(this, "videoVolumeSlider");
    u(this, "translationVolumeSliderLabel");
    u(this, "translationVolumeSlider");
    u(this, "onDragStart", (t) => {
      !t.isPrimary || t.button !== 0 || t.pointerType !== "touch" && (t.preventDefault(), this.startDragSession(t.clientX, t.clientY, "overlay-pointer-down"), document.addEventListener("pointermove", this.onGlobalPointerMove, {
        passive: !0
      }), document.addEventListener("pointerup", this.onDragEnd), document.addEventListener("pointercancel", this.onDragEnd));
    });
    // Touch fallback for browsers/environments that don't deliver Pointer Events
    // reliably on mobile. We only use the first active touch.
    u(this, "onTouchDragStart", (t) => {
      if (!t.touches || t.touches.length === 0) return;
      const e = t.touches[0];
      this.startDragSession(e.clientX, e.clientY, "overlay-touch-start"), document.addEventListener("touchmove", this.onGlobalTouchMove, {
        passive: !1
      }), document.addEventListener("touchend", this.onDragEnd), document.addEventListener("touchcancel", this.onDragEnd);
    });
    u(this, "onGlobalTouchMove", (t) => {
      if (!t.touches || t.touches.length === 0) return;
      const e = t.touches[0];
      this.updateDragFromMove(e.clientX, e.clientY, "overlay-touch-move"), this.dragging && t.preventDefault();
    });
    u(this, "onGlobalPointerMove", (t) => {
      this.updateDragFromMove(
        t.clientX,
        t.clientY,
        "overlay-pointer-move"
      );
    });
    u(this, "applyDragFromState", () => {
      if (!this.dragging || !this.dragDirty || !this.containerRect) return;
      const t = this.containerRect.width;
      if (!(t > 0 && Number.isFinite(t)))
        return;
      this.dragDirty = !1;
      const e = this.currentClientX - this.containerRect.left, s = Math.max(0, Math.min(e, t)) / t * 100;
      this.moveButton(s);
    });
    u(this, "onCheckerTick", () => {
      this.applyDragFromState();
    });
    u(this, "onDragEnd", () => {
      document.removeEventListener("pointermove", this.onGlobalPointerMove), document.removeEventListener("pointerup", this.onDragEnd), document.removeEventListener("pointercancel", this.onDragEnd), document.removeEventListener("touchmove", this.onGlobalTouchMove), document.removeEventListener("touchend", this.onDragEnd), document.removeEventListener("touchcancel", this.onDragEnd), this.applyDragFromState();
      const t = this.dragIsBigContainer ?? this.isBigContainer;
      this.dragging && t && this.data.buttonPos && I.set("buttonPos", this.data.buttonPos), this.dragging = !1, this.dragCandidate = !1, this.dragDirty = !1, this.containerRect = null, this.dragIsBigContainer = null;
    });
    this.mount = t, this.globalPortal = e, this.data = i, this.videoHandler = s, this.intervalIdleChecker = o;
  }
  get root() {
    return this.mount.root;
  }
  get portalContainer() {
    return this.mount.portalContainer;
  }
  get tooltipLayoutRoot() {
    return this.mount.tooltipLayoutRoot;
  }
  shouldLogMobileOverlay() {
    return /^(m|music)\.youtube\.com$/i.test(
      String(globalThis.location.hostname || "")
    );
  }
  /**
   * Update mount points (root/tooltipLayoutRoot) when the player container changes.
   * Moves already-mounted UI nodes and rebinds root-bound listeners (dragging).
   */
  updateMount(t) {
    const e = this.mount.root, i = t.root, s = this.mount.tooltipLayoutRoot, o = t.tooltipLayoutRoot;
    return this.mount = t, this.isInitialized() ? (e !== i && (this.votButton && i.appendChild(this.votButton.container), this.votMenu && i.appendChild(this.votMenu.container)), this.votButtonTooltip && cw(
      {
        root: e,
        portalContainer: this.mount.portalContainer,
        subtitlesMountContainer: this.mount.subtitlesMountContainer,
        tooltipLayoutRoot: s
      },
      t
    ) && this.votButtonTooltip.updateMount({
      layoutRoot: o ?? document.documentElement
    }), this) : this;
  }
  isInitialized() {
    return this.initialized;
  }
  calcButtonLayout(t) {
    return this.isBigContainer && Aw(t) ? {
      direction: "column",
      position: t
    } : {
      direction: "row",
      position: "default"
    };
  }
  addEventListener(t, e) {
    return this.events[t].addListener(e), this;
  }
  removeEventListener(t, e) {
    return this.events[t].removeListener(e), this;
  }
  scheduleDefaultVolumePersist() {
    this.defaultVolumePersistTimer !== void 0 && globalThis.clearTimeout(this.defaultVolumePersistTimer), this.defaultVolumePersistTimer = globalThis.setTimeout(() => {
      this.defaultVolumePersistTimer = void 0, this.flushDefaultVolumePersist();
    }, this.defaultVolumePersistDelayMs);
  }
  flushDefaultVolumePersist() {
    this.defaultVolumePersistTimer !== void 0 && (globalThis.clearTimeout(this.defaultVolumePersistTimer), this.defaultVolumePersistTimer = void 0), typeof this.data.defaultVolume == "number" && I.set("defaultVolume", this.data.defaultVolume);
  }
  initUI(t = "default") {
    if (this.isInitialized())
      throw new Error("[VOT] OverlayView is already initialized");
    this.initialized = !0;
    const { position: e, direction: i } = this.calcButtonLayout(t);
    this.votButton = new ds({
      position: e,
      direction: i,
      status: "none",
      labelHtml: p.get("translateVideo")
    }), this.votButton.opacity = 0, this.pipButtonVisible || this.votButton.showPiPButton(!1), this.root.appendChild(this.votButton.container), this.votButtonTooltip = new mt({
      target: this.votButton.translateButton,
      content: p.get("translateVideo"),
      position: this.votButton.tooltipPos,
      // Keep side-tooltip direction stable for the moved button (left/right)
      // so status/error text does not mirror to the opposite side.
      autoLayout: !1,
      hidden: i === "row",
      bordered: !1,
      parentElement: this.globalPortal,
      layoutRoot: this.tooltipLayoutRoot
    }), this.votMenu = new Lw({
      titleHtml: p.get("VOTSettings"),
      position: e
    }), this.root.appendChild(this.votMenu.container), this.votButton.menuButton.setAttribute(
      "aria-controls",
      this.votMenu.container.id
    ), this.downloadTranslationButton = new Sw(), this.downloadTranslationButton.hidden = !0, this.downloadSubtitlesButton = L.createIconButton(mw, {
      ariaLabel: "Download subtitles"
    }), this.downloadSubtitlesButton.hidden = !0, this.openSettingsButton = L.createIconButton(pw, {
      ariaLabel: p.get("VOTSettings")
    }), this.votMenu.headerContainer.append(
      this.downloadTranslationButton.button,
      this.downloadSubtitlesButton,
      this.openSettingsButton
    );
    const s = this.videoHandler?.videoData?.detectedLanguage ?? "en", o = this.data.responseLanguage ?? "ru";
    this.languagePairSelect = new kw({
      from: {
        // `detectedLanguage` is dynamic and may include codes that aren't in
        // the compile-time Phrase union.
        selectTitle: p.get(
          `langs.${s}`
        ),
        items: ht.genLanguageItems(Bt, s)
      },
      to: {
        selectTitle: p.get(
          `langs.${o}`
        ),
        items: ht.genLanguageItems(Pi, o)
      },
      dialogParent: this.globalPortal
    }), this.subtitlesSelectLabel = new $t({
      labelText: p.get("VOTSubtitles")
    }), this.subtitlesSelect = new ht({
      selectTitle: p.get("VOTSubtitlesDisabled"),
      dialogTitle: p.get("VOTSubtitles"),
      labelElement: this.subtitlesSelectLabel.container,
      dialogParent: this.globalPortal,
      items: [
        {
          label: p.get("VOTSubtitlesDisabled"),
          value: "disabled",
          selected: !0
        }
      ]
    });
    const r = this.videoHandler ? this.videoHandler.getVideoVolume() * 100 : 100;
    this.videoVolumeSliderLabel = new ae({
      labelText: p.get("VOTVolume"),
      value: r
    }), this.videoVolumeSlider = new re({
      labelHtml: this.videoVolumeSliderLabel.container,
      value: r
    }), this.videoVolumeSlider.hidden = !this.data.showVideoSlider || this.votButton.status !== "success";
    const a = this.data.defaultVolume ?? 100;
    return this.translationVolumeSliderLabel = new ae({
      labelText: p.get("VOTVolumeTranslation"),
      value: a
    }), this.translationVolumeSlider = new re({
      labelHtml: this.translationVolumeSliderLabel.container,
      value: a,
      max: this.data.audioBooster ? tu : 100
    }), this.translationVolumeSlider.hidden = this.votButton.status !== "success", this.votMenu.bodyContainer.append(
      this.languagePairSelect.container,
      this.subtitlesSelect.container,
      this.videoVolumeSlider.container,
      this.translationVolumeSlider.container
    ), this;
  }
  initUIEvents() {
    if (!this.isInitialized())
      throw new Error("[VOT] OverlayView isn't initialized");
    this.abortController = new AbortController();
    const t = this.abortController.signal;
    this.checkerUnsubscribe?.(), this.checkerUnsubscribe = this.intervalIdleChecker.subscribe(() => {
      this.onCheckerTick();
    }), this.votButton.container.addEventListener(
      "click",
      (l) => {
        l.preventDefault(), l.stopPropagation(), l.stopImmediatePropagation();
      },
      { signal: t }
    );
    const e = (l) => (c) => {
      (c.key === "Enter" || c.key === " ") && (c.preventDefault(), l());
    }, i = (l) => l.isPrimary && l.button === 0, s = (l, { returnFocusToToggle: c = !1 } = {}) => {
      this.isInitialized() && (this.votMenu.hidden = !l, this.votButton.menuButton.setAttribute("aria-expanded", l.toString()), this.votButtonTooltip && (this.votButtonTooltip.hidden = l || this.votButton.direction === "row"), l ? queueMicrotask(() => this.openSettingsButton?.focus?.()) : c ? queueMicrotask(() => this.votButton.menuButton.focus?.()) : this.votButton.menuButton.blur());
    }, o = () => s(this.votMenu.hidden), r = (l = !1) => s(!1, { returnFocusToToggle: l });
    this.votButton.translateButton.addEventListener(
      "pointerdown",
      (l) => {
        i(l) && (r(), this.events["click:translate"].dispatch());
      },
      { signal: t }
    ), this.votButton.translateButton.addEventListener(
      "keydown",
      e(() => {
        r(), this.events["click:translate"].dispatch();
      }),
      { signal: t }
    ), this.votButton.pipButton.addEventListener(
      "pointerdown",
      (l) => {
        i(l) && (r(), this.events["click:pip"].dispatch());
      },
      { signal: t }
    ), this.votButton.pipButton.addEventListener(
      "keydown",
      e(() => {
        r(), this.events["click:pip"].dispatch();
      }),
      { signal: t }
    ), this.votButton.menuButton.addEventListener(
      "pointerdown",
      (l) => {
        i(l) && (l.preventDefault(), o());
      },
      { signal: t }
    ), this.votButton.menuButton.addEventListener(
      "keydown",
      e(o),
      { signal: t }
    );
    const a = "none";
    this.votButton.container.style.touchAction = a, this.votButton.translateButton.style.touchAction = a, this.votButton.pipButton.style.touchAction = a, this.votButton.menuButton.style.touchAction = a, this.votButton.container.addEventListener("pointerdown", this.onDragStart, {
      signal: t
    }), this.votButton.container.addEventListener(
      "touchstart",
      this.onTouchDragStart,
      { signal: t, passive: !1 }
    ), this.votMenu.container.addEventListener(
      "click",
      (l) => {
        l.preventDefault(), l.stopPropagation(), l.stopImmediatePropagation();
      },
      { signal: t }
    );
    for (const l of ["pointerdown", "mousedown"])
      this.votMenu.container.addEventListener(
        l,
        (c) => {
          c.stopImmediatePropagation();
        },
        { signal: t }
      );
    return document.addEventListener(
      "pointerdown",
      (l) => {
        if (this.votMenu.hidden) return;
        const c = l.target, d = typeof l.composedPath == "function" ? l.composedPath() : [], h = c && this.votMenu.container.contains(c) || d.includes(this.votMenu.container), f = c && this.votButton.menuButton.contains(c) || d.includes(this.votButton.menuButton), g = c && this.votButton.container.contains(c) || d.includes(this.votButton.container), m = c instanceof HTMLElement && !!c.closest(".vot-dialog-container");
        h || f || g || m || r(!1);
      },
      { signal: t, capture: !0, passive: !0 }
    ), this.votMenu.container.addEventListener(
      "keydown",
      (l) => {
        if (l.key !== "Escape") return;
        const c = document.documentElement.classList.contains("vot-keyboard-nav");
        l.preventDefault(), l.stopPropagation(), r(c), this.votButton.container.matches(":hover") || this.votMenu.container.matches(":hover") || this.videoHandler?.overlayVisibility?.queueAutoHide?.();
      },
      { signal: t }
    ), this.downloadTranslationButton.addEventListener("click", () => {
      this.events["click:downloadTranslation"].dispatch();
    }), this.downloadSubtitlesButton.addEventListener(
      "click",
      () => {
        this.events["click:downloadSubtitles"].dispatch();
      },
      { signal: t }
    ), this.openSettingsButton.addEventListener(
      "click",
      () => {
        r(), this.events["click:settings"].dispatch();
      },
      { signal: t }
    ), this.languagePairSelect.fromSelect.addEventListener(
      "selectItem",
      (l) => {
        this.videoHandler?.videoData && (this.videoHandler.videoData.detectedLanguage = l, this.videoHandler.videoManager.rememberUserLanguageSelection(
          this.videoHandler.videoData.videoId,
          l
        )), this.events["select:fromLanguage"].dispatch(l);
      }
    ), this.languagePairSelect.toSelect.addEventListener(
      "selectItem",
      async (l) => {
        this.videoHandler?.videoData && (this.videoHandler.translateToLang = this.videoHandler.videoData.responseLanguage = l);
        const c = this.data.responseLanguage;
        c !== l && (this.data.responseLanguage = l, await I.set("responseLanguage", this.data.responseLanguage)), this.data.enabledDontTranslateLanguages && Array.isArray(this.data.dontTranslateLanguages) && this.data.dontTranslateLanguages.length === 1 && c !== l && typeof c == "string" && this.data.dontTranslateLanguages[0] === c && (this.data.dontTranslateLanguages = [l], await I.set(
          "dontTranslateLanguages",
          this.data.dontTranslateLanguages
        )), this.events["select:toLanguage"].dispatch(l);
      }
    ), this.subtitlesSelect.addEventListener("beforeOpen", async (l) => {
      if (!this.videoHandler?.videoData)
        return;
      const c = this.videoHandler.getSubtitlesCacheKey(
        this.videoHandler.videoData.videoId,
        this.videoHandler.videoData.detectedLanguage,
        this.videoHandler.videoData.responseLanguage
      );
      if (this.videoHandler.subtitlesCacheKey === c)
        return;
      if (this.videoHandler.cacheManager.getSubtitles(c) !== void 0) {
        await this.videoHandler.ensureSubtitlesForCurrentLangPair();
        return;
      }
      const d = this.votButton?.loading ?? !1;
      this.votButton && (this.votButton.loading = !0);
      const h = L.createInlineLoader();
      h.style.margin = "0 auto", l.footerContainer.appendChild(h);
      try {
        await this.videoHandler.ensureSubtitlesForCurrentLangPair();
      } finally {
        h.remove(), this.votButton && (this.votButton.loading = d);
      }
    }), this.subtitlesSelect.addEventListener("selectItem", (l) => {
      this.events["select:subtitles"].dispatch(l);
    }), this.videoVolumeSlider.addEventListener("input", (l, c) => {
      this.videoVolumeSliderLabel && (this.videoVolumeSliderLabel.value = l), !c && this.events["input:videoVolume"].dispatch(l);
    }), this.translationVolumeSlider.addEventListener(
      "input",
      (l, c) => {
        this.translationVolumeSliderLabel && (this.translationVolumeSliderLabel.value = l), this.data.defaultVolume !== l && (this.data.defaultVolume = l, this.scheduleDefaultVolumePersist()), !c && this.events["input:translationVolume"].dispatch(l);
      }
    ), this;
  }
  updateButtonLayout(t, e) {
    return this.isInitialized() ? (this.votMenu.position = t, this.votButton.position = t, this.votButton.direction = e, this.votButtonTooltip.hidden = e === "row", this.votButtonTooltip.setPosition(this.votButton.tooltipPos), this) : this;
  }
  moveButton(t) {
    if (!this.isInitialized())
      return this;
    const e = this.dragIsBigContainer ?? this.isBigContainer, i = ds.calcPosition(t, e);
    if (i === this.votButton.position)
      return this;
    const s = ds.calcDirection(i);
    return this.data.buttonPos = i, this.updateButtonLayout(i, s), this;
  }
  startDragSession(t, e, i) {
    this.dragCandidate = !0, this.dragging = !1, this.dragStartX = t, this.dragStartY = e, this.currentClientX = t, this.containerRect = this.root.getBoundingClientRect(), this.dragIsBigContainer = this.isBigContainer, this.dragDirty = !1, this.intervalIdleChecker.markActivity(i), this.intervalIdleChecker.requestImmediateTick();
  }
  queueDragTick(t) {
    this.dragDirty || (this.dragDirty = !0, this.intervalIdleChecker.markActivity(t), this.intervalIdleChecker.requestImmediateTick());
  }
  updateDragFromMove(t, e, i) {
    if (this.currentClientX = t, !!this.dragCandidate) {
      if (!this.dragging) {
        const s = Math.abs(this.currentClientX - this.dragStartX), o = Math.abs(e - this.dragStartY);
        s + o >= this.dragThresholdPx && (this.dragging = !0);
      }
      this.dragging && this.queueDragTick(i);
    }
  }
  updateButtonOpacity(t) {
    return !this.isInitialized() || !this.votMenu.hidden ? this : (Math.abs(this.votButton.opacity - t) > 0.01 && (this.votButton.opacity = t), this);
  }
  doReleaseUI() {
    this.shouldLogMobileOverlay() && console.log("[VOT][mobile-overlay][ui] remove overlay UI nodes", {
      hasButton: !!this.votButton?.container?.isConnected,
      hasMenu: !!this.votMenu?.container?.isConnected
    }), this.votButton?.remove(), this.votMenu?.remove(), this.votButtonTooltip?.release();
  }
  doReleaseUIEvents() {
    this.abortController?.abort(), this.abortController = null, this.checkerUnsubscribe?.(), this.checkerUnsubscribe = null, this.onDragEnd(), this.flushDefaultVolumePersist();
    for (const t of Object.values(this.events))
      t.clear();
  }
  release() {
    return this.isInitialized() ? (this.shouldLogMobileOverlay() && console.log("[VOT][mobile-overlay][ui] overlay view release"), this.doReleaseUIEvents(), this.doReleaseUI(), this.initialized = !1, this) : this;
  }
  get isBigContainer() {
    const t = this.videoHandler?.video?.getBoundingClientRect?.().width;
    if (typeof t == "number" && Number.isFinite(t))
      return t > Re.BIG_CONTAINER_WIDTH_PX;
    const e = this.videoHandler?.container?.getBoundingClientRect?.().width;
    return typeof e == "number" && Number.isFinite(e) ? e > Re.BIG_CONTAINER_WIDTH_PX : this.root.clientWidth > Re.BIG_CONTAINER_WIDTH_PX;
  }
  get pipButtonVisible() {
    return nu() && !!this.data.showPiPButton;
  }
};
u(Re, "BIG_CONTAINER_WIDTH_PX", 550);
let Us = Re;
function Aw(n) {
  return n === "left" || n === "right";
}
const xw = ["default", "top", "left", "right"], Vw = {
  AmazonBot: "amazonbot",
  "Amazon Silk": "amazon_silk",
  "Android Browser": "android",
  BaiduSpider: "baiduspider",
  Bada: "bada",
  BingCrawler: "bingcrawler",
  Brave: "brave",
  BlackBerry: "blackberry",
  "ChatGPT-User": "chatgpt_user",
  Chrome: "chrome",
  ClaudeBot: "claudebot",
  Chromium: "chromium",
  Diffbot: "diffbot",
  DuckDuckBot: "duckduckbot",
  DuckDuckGo: "duckduckgo",
  Electron: "electron",
  Epiphany: "epiphany",
  FacebookExternalHit: "facebookexternalhit",
  Firefox: "firefox",
  Focus: "focus",
  Generic: "generic",
  "Google Search": "google_search",
  Googlebot: "googlebot",
  GPTBot: "gptbot",
  "Internet Explorer": "ie",
  InternetArchiveCrawler: "internetarchivecrawler",
  "K-Meleon": "k_meleon",
  LibreWolf: "librewolf",
  Linespider: "linespider",
  Maxthon: "maxthon",
  "Meta-ExternalAds": "meta_externalads",
  "Meta-ExternalAgent": "meta_externalagent",
  "Meta-ExternalFetcher": "meta_externalfetcher",
  "Meta-WebIndexer": "meta_webindexer",
  "Microsoft Edge": "edge",
  "MZ Browser": "mz",
  "NAVER Whale Browser": "naver",
  "OAI-SearchBot": "oai_searchbot",
  Omgilibot: "omgilibot",
  Opera: "opera",
  "Opera Coast": "opera_coast",
  "Pale Moon": "pale_moon",
  PerplexityBot: "perplexitybot",
  "Perplexity-User": "perplexity_user",
  PhantomJS: "phantomjs",
  PingdomBot: "pingdombot",
  Puffin: "puffin",
  QQ: "qq",
  QQLite: "qqlite",
  QupZilla: "qupzilla",
  Roku: "roku",
  Safari: "safari",
  Sailfish: "sailfish",
  "Samsung Internet for Android": "samsung_internet",
  SlackBot: "slackbot",
  SeaMonkey: "seamonkey",
  Sleipnir: "sleipnir",
  "Sogou Browser": "sogou",
  Swing: "swing",
  Tizen: "tizen",
  "UC Browser": "uc",
  Vivaldi: "vivaldi",
  "WebOS Browser": "webos",
  WeChat: "wechat",
  YahooSlurp: "yahooslurp",
  "Yandex Browser": "yandex",
  YandexBot: "yandexbot",
  YouBot: "youbot"
}, Wu = {
  amazonbot: "AmazonBot",
  amazon_silk: "Amazon Silk",
  android: "Android Browser",
  baiduspider: "BaiduSpider",
  bada: "Bada",
  bingcrawler: "BingCrawler",
  blackberry: "BlackBerry",
  brave: "Brave",
  chatgpt_user: "ChatGPT-User",
  chrome: "Chrome",
  claudebot: "ClaudeBot",
  chromium: "Chromium",
  diffbot: "Diffbot",
  duckduckbot: "DuckDuckBot",
  duckduckgo: "DuckDuckGo",
  edge: "Microsoft Edge",
  electron: "Electron",
  epiphany: "Epiphany",
  facebookexternalhit: "FacebookExternalHit",
  firefox: "Firefox",
  focus: "Focus",
  generic: "Generic",
  google_search: "Google Search",
  googlebot: "Googlebot",
  gptbot: "GPTBot",
  ie: "Internet Explorer",
  internetarchivecrawler: "InternetArchiveCrawler",
  k_meleon: "K-Meleon",
  librewolf: "LibreWolf",
  linespider: "Linespider",
  maxthon: "Maxthon",
  meta_externalads: "Meta-ExternalAds",
  meta_externalagent: "Meta-ExternalAgent",
  meta_externalfetcher: "Meta-ExternalFetcher",
  meta_webindexer: "Meta-WebIndexer",
  mz: "MZ Browser",
  naver: "NAVER Whale Browser",
  oai_searchbot: "OAI-SearchBot",
  omgilibot: "Omgilibot",
  opera: "Opera",
  opera_coast: "Opera Coast",
  pale_moon: "Pale Moon",
  perplexitybot: "PerplexityBot",
  perplexity_user: "Perplexity-User",
  phantomjs: "PhantomJS",
  pingdombot: "PingdomBot",
  puffin: "Puffin",
  qq: "QQ Browser",
  qqlite: "QQ Browser Lite",
  qupzilla: "QupZilla",
  roku: "Roku",
  safari: "Safari",
  sailfish: "Sailfish",
  samsung_internet: "Samsung Internet for Android",
  seamonkey: "SeaMonkey",
  slackbot: "SlackBot",
  sleipnir: "Sleipnir",
  sogou: "Sogou Browser",
  swing: "Swing",
  tizen: "Tizen",
  uc: "UC Browser",
  vivaldi: "Vivaldi",
  webos: "WebOS Browser",
  wechat: "WeChat",
  yahooslurp: "YahooSlurp",
  yandex: "Yandex Browser",
  yandexbot: "YandexBot",
  youbot: "YouBot"
}, R = {
  bot: "bot",
  desktop: "desktop",
  mobile: "mobile",
  tablet: "tablet",
  tv: "tv"
}, ct = {
  Android: "Android",
  Bada: "Bada",
  BlackBerry: "BlackBerry",
  ChromeOS: "Chrome OS",
  HarmonyOS: "HarmonyOS",
  iOS: "iOS",
  Linux: "Linux",
  MacOS: "macOS",
  PlayStation4: "PlayStation 4",
  Roku: "Roku",
  Tizen: "Tizen",
  WebOS: "WebOS",
  Windows: "Windows",
  WindowsPhone: "Windows Phone"
}, Yt = {
  Blink: "Blink",
  EdgeHTML: "EdgeHTML",
  Gecko: "Gecko",
  Presto: "Presto",
  Trident: "Trident",
  WebKit: "WebKit"
};
class y {
  /**
   * Get first matched item for a string
   * @param {RegExp} regexp
   * @param {String} ua
   * @return {Array|{index: number, input: string}|*|boolean|string}
   */
  static getFirstMatch(t, e) {
    const i = e.match(t);
    return i && i.length > 0 && i[1] || "";
  }
  /**
   * Get second matched item for a string
   * @param regexp
   * @param {String} ua
   * @return {Array|{index: number, input: string}|*|boolean|string}
   */
  static getSecondMatch(t, e) {
    const i = e.match(t);
    return i && i.length > 1 && i[2] || "";
  }
  /**
   * Match a regexp and return a constant or undefined
   * @param {RegExp} regexp
   * @param {String} ua
   * @param {*} _const Any const that will be returned if regexp matches the string
   * @return {*}
   */
  static matchAndReturnConst(t, e, i) {
    if (t.test(e))
      return i;
  }
  static getWindowsVersionName(t) {
    switch (t) {
      case "NT":
        return "NT";
      case "XP":
        return "XP";
      case "NT 5.0":
        return "2000";
      case "NT 5.1":
        return "XP";
      case "NT 5.2":
        return "2003";
      case "NT 6.0":
        return "Vista";
      case "NT 6.1":
        return "7";
      case "NT 6.2":
        return "8";
      case "NT 6.3":
        return "8.1";
      case "NT 10.0":
        return "10";
      default:
        return;
    }
  }
  /**
   * Get macOS version name
   *    10.5 - Leopard
   *    10.6 - Snow Leopard
   *    10.7 - Lion
   *    10.8 - Mountain Lion
   *    10.9 - Mavericks
   *    10.10 - Yosemite
   *    10.11 - El Capitan
   *    10.12 - Sierra
   *    10.13 - High Sierra
   *    10.14 - Mojave
   *    10.15 - Catalina
   *    11 - Big Sur
   *    12 - Monterey
   *    13 - Ventura
   *    14 - Sonoma
   *    15 - Sequoia
   *
   * @example
   *   getMacOSVersionName("10.14") // 'Mojave'
   *
   * @param  {string} version
   * @return {string} versionName
   */
  static getMacOSVersionName(t) {
    const e = t.split(".").splice(0, 2).map((o) => parseInt(o, 10) || 0);
    e.push(0);
    const i = e[0], s = e[1];
    if (i === 10)
      switch (s) {
        case 5:
          return "Leopard";
        case 6:
          return "Snow Leopard";
        case 7:
          return "Lion";
        case 8:
          return "Mountain Lion";
        case 9:
          return "Mavericks";
        case 10:
          return "Yosemite";
        case 11:
          return "El Capitan";
        case 12:
          return "Sierra";
        case 13:
          return "High Sierra";
        case 14:
          return "Mojave";
        case 15:
          return "Catalina";
        default:
          return;
      }
    switch (i) {
      case 11:
        return "Big Sur";
      case 12:
        return "Monterey";
      case 13:
        return "Ventura";
      case 14:
        return "Sonoma";
      case 15:
        return "Sequoia";
      default:
        return;
    }
  }
  /**
   * Get Android version name
   *    1.5 - Cupcake
   *    1.6 - Donut
   *    2.0 - Eclair
   *    2.1 - Eclair
   *    2.2 - Froyo
   *    2.x - Gingerbread
   *    3.x - Honeycomb
   *    4.0 - Ice Cream Sandwich
   *    4.1 - Jelly Bean
   *    4.4 - KitKat
   *    5.x - Lollipop
   *    6.x - Marshmallow
   *    7.x - Nougat
   *    8.x - Oreo
   *    9.x - Pie
   *
   * @example
   *   getAndroidVersionName("7.0") // 'Nougat'
   *
   * @param  {string} version
   * @return {string} versionName
   */
  static getAndroidVersionName(t) {
    const e = t.split(".").splice(0, 2).map((i) => parseInt(i, 10) || 0);
    if (e.push(0), !(e[0] === 1 && e[1] < 5)) {
      if (e[0] === 1 && e[1] < 6) return "Cupcake";
      if (e[0] === 1 && e[1] >= 6) return "Donut";
      if (e[0] === 2 && e[1] < 2) return "Eclair";
      if (e[0] === 2 && e[1] === 2) return "Froyo";
      if (e[0] === 2 && e[1] > 2) return "Gingerbread";
      if (e[0] === 3) return "Honeycomb";
      if (e[0] === 4 && e[1] < 1) return "Ice Cream Sandwich";
      if (e[0] === 4 && e[1] < 4) return "Jelly Bean";
      if (e[0] === 4 && e[1] >= 4) return "KitKat";
      if (e[0] === 5) return "Lollipop";
      if (e[0] === 6) return "Marshmallow";
      if (e[0] === 7) return "Nougat";
      if (e[0] === 8) return "Oreo";
      if (e[0] === 9) return "Pie";
    }
  }
  /**
   * Get version precisions count
   *
   * @example
   *   getVersionPrecision("1.10.3") // 3
   *
   * @param  {string} version
   * @return {number}
   */
  static getVersionPrecision(t) {
    return t.split(".").length;
  }
  /**
   * Calculate browser version weight
   *
   * @example
   *   compareVersions('1.10.2.1',  '1.8.2.1.90')    // 1
   *   compareVersions('1.010.2.1', '1.09.2.1.90');  // 1
   *   compareVersions('1.10.2.1',  '1.10.2.1');     // 0
   *   compareVersions('1.10.2.1',  '1.0800.2');     // -1
   *   compareVersions('1.10.2.1',  '1.10',  true);  // 0
   *
   * @param {String} versionA versions versions to compare
   * @param {String} versionB versions versions to compare
   * @param {boolean} [isLoose] enable loose comparison
   * @return {Number} comparison result: -1 when versionA is lower,
   * 1 when versionA is bigger, 0 when both equal
   */
  /* eslint consistent-return: 1 */
  static compareVersions(t, e, i = !1) {
    const s = y.getVersionPrecision(t), o = y.getVersionPrecision(e);
    let r = Math.max(s, o), a = 0;
    const l = y.map([t, e], (c) => {
      const d = r - y.getVersionPrecision(c), h = c + new Array(d + 1).join(".0");
      return y.map(h.split("."), (f) => new Array(20 - f.length).join("0") + f).reverse();
    });
    for (i && (a = r - Math.min(s, o)), r -= 1; r >= a; ) {
      if (l[0][r] > l[1][r])
        return 1;
      if (l[0][r] === l[1][r]) {
        if (r === a)
          return 0;
        r -= 1;
      } else if (l[0][r] < l[1][r])
        return -1;
    }
  }
  /**
   * Array::map polyfill
   *
   * @param  {Array} arr
   * @param  {Function} iterator
   * @return {Array}
   */
  static map(t, e) {
    const i = [];
    let s;
    if (Array.prototype.map)
      return Array.prototype.map.call(t, e);
    for (s = 0; s < t.length; s += 1)
      i.push(e(t[s]));
    return i;
  }
  /**
   * Array::find polyfill
   *
   * @param  {Array} arr
   * @param  {Function} predicate
   * @return {Array}
   */
  static find(t, e) {
    let i, s;
    if (Array.prototype.find)
      return Array.prototype.find.call(t, e);
    for (i = 0, s = t.length; i < s; i += 1) {
      const o = t[i];
      if (e(o, i))
        return o;
    }
  }
  /**
   * Object::assign polyfill
   *
   * @param  {Object} obj
   * @param  {Object} ...objs
   * @return {Object}
   */
  static assign(t, ...e) {
    const i = t;
    let s, o;
    if (Object.assign)
      return Object.assign(t, ...e);
    for (s = 0, o = e.length; s < o; s += 1) {
      const r = e[s];
      typeof r == "object" && r !== null && Object.keys(r).forEach((l) => {
        i[l] = r[l];
      });
    }
    return t;
  }
  /**
   * Get short version/alias for a browser name
   *
   * @example
   *   getBrowserAlias('Microsoft Edge') // edge
   *
   * @param  {string} browserName
   * @return {string}
   */
  static getBrowserAlias(t) {
    return Vw[t];
  }
  /**
   * Get browser name for a short version/alias
   *
   * @example
   *   getBrowserTypeByAlias('edge') // Microsoft Edge
   *
   * @param  {string} browserAlias
   * @return {string}
   */
  static getBrowserTypeByAlias(t) {
    return Wu[t] || "";
  }
}
const B = /version\/(\d+(\.?_?\d+)+)/i, Cw = [
  /* GPTBot */
  {
    test: [/gptbot/i],
    describe(n) {
      const t = {
        name: "GPTBot"
      }, e = y.getFirstMatch(/gptbot\/(\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* ChatGPT-User */
  {
    test: [/chatgpt-user/i],
    describe(n) {
      const t = {
        name: "ChatGPT-User"
      }, e = y.getFirstMatch(/chatgpt-user\/(\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* OAI-SearchBot */
  {
    test: [/oai-searchbot/i],
    describe(n) {
      const t = {
        name: "OAI-SearchBot"
      }, e = y.getFirstMatch(/oai-searchbot\/(\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* ClaudeBot */
  {
    test: [/claudebot/i, /claude-web/i, /claude-user/i, /claude-searchbot/i],
    describe(n) {
      const t = {
        name: "ClaudeBot"
      }, e = y.getFirstMatch(/(?:claudebot|claude-web|claude-user|claude-searchbot)\/(\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* Omgilibot */
  {
    test: [/omgilibot/i, /webzio-extended/i],
    describe(n) {
      const t = {
        name: "Omgilibot"
      }, e = y.getFirstMatch(/(?:omgilibot|webzio-extended)\/(\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* Diffbot */
  {
    test: [/diffbot/i],
    describe(n) {
      const t = {
        name: "Diffbot"
      }, e = y.getFirstMatch(/diffbot\/(\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* PerplexityBot */
  {
    test: [/perplexitybot/i],
    describe(n) {
      const t = {
        name: "PerplexityBot"
      }, e = y.getFirstMatch(/perplexitybot\/(\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* Perplexity-User */
  {
    test: [/perplexity-user/i],
    describe(n) {
      const t = {
        name: "Perplexity-User"
      }, e = y.getFirstMatch(/perplexity-user\/(\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* YouBot */
  {
    test: [/youbot/i],
    describe(n) {
      const t = {
        name: "YouBot"
      }, e = y.getFirstMatch(/youbot\/(\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* Meta-WebIndexer */
  {
    test: [/meta-webindexer/i],
    describe(n) {
      const t = {
        name: "Meta-WebIndexer"
      }, e = y.getFirstMatch(/meta-webindexer\/(\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* Meta-ExternalAds */
  {
    test: [/meta-externalads/i],
    describe(n) {
      const t = {
        name: "Meta-ExternalAds"
      }, e = y.getFirstMatch(/meta-externalads\/(\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* Meta-ExternalAgent */
  {
    test: [/meta-externalagent/i],
    describe(n) {
      const t = {
        name: "Meta-ExternalAgent"
      }, e = y.getFirstMatch(/meta-externalagent\/(\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* Meta-ExternalFetcher */
  {
    test: [/meta-externalfetcher/i],
    describe(n) {
      const t = {
        name: "Meta-ExternalFetcher"
      }, e = y.getFirstMatch(/meta-externalfetcher\/(\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* Googlebot */
  {
    test: [/googlebot/i],
    describe(n) {
      const t = {
        name: "Googlebot"
      }, e = y.getFirstMatch(/googlebot\/(\d+(\.\d+))/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* Linespider */
  {
    test: [/linespider/i],
    describe(n) {
      const t = {
        name: "Linespider"
      }, e = y.getFirstMatch(/(?:linespider)(?:-[-\w]+)?[\s/](\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* AmazonBot */
  {
    test: [/amazonbot/i],
    describe(n) {
      const t = {
        name: "AmazonBot"
      }, e = y.getFirstMatch(/amazonbot\/(\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* BingCrawler */
  {
    test: [/bingbot/i],
    describe(n) {
      const t = {
        name: "BingCrawler"
      }, e = y.getFirstMatch(/bingbot\/(\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* BaiduSpider */
  {
    test: [/baiduspider/i],
    describe(n) {
      const t = {
        name: "BaiduSpider"
      }, e = y.getFirstMatch(/baiduspider\/(\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* DuckDuckBot */
  {
    test: [/duckduckbot/i],
    describe(n) {
      const t = {
        name: "DuckDuckBot"
      }, e = y.getFirstMatch(/duckduckbot\/(\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* InternetArchiveCrawler */
  {
    test: [/ia_archiver/i],
    describe(n) {
      const t = {
        name: "InternetArchiveCrawler"
      }, e = y.getFirstMatch(/ia_archiver\/(\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* FacebookExternalHit */
  {
    test: [/facebookexternalhit/i, /facebookcatalog/i],
    describe() {
      return {
        name: "FacebookExternalHit"
      };
    }
  },
  /* SlackBot */
  {
    test: [/slackbot/i, /slack-imgProxy/i],
    describe(n) {
      const t = {
        name: "SlackBot"
      }, e = y.getFirstMatch(/(?:slackbot|slack-imgproxy)(?:-[-\w]+)?[\s/](\d+(\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* YahooSlurp */
  {
    test: [/yahoo!?[\s/]*slurp/i],
    describe() {
      return {
        name: "YahooSlurp"
      };
    }
  },
  /* YandexBot */
  {
    test: [/yandexbot/i, /yandexmobilebot/i],
    describe() {
      return {
        name: "YandexBot"
      };
    }
  },
  /* PingdomBot */
  {
    test: [/pingdom/i],
    describe() {
      return {
        name: "PingdomBot"
      };
    }
  },
  /* Opera < 13.0 */
  {
    test: [/opera/i],
    describe(n) {
      const t = {
        name: "Opera"
      }, e = y.getFirstMatch(B, n) || y.getFirstMatch(/(?:opera)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  /* Opera > 13.0 */
  {
    test: [/opr\/|opios/i],
    describe(n) {
      const t = {
        name: "Opera"
      }, e = y.getFirstMatch(/(?:opr|opios)[\s/](\S+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/SamsungBrowser/i],
    describe(n) {
      const t = {
        name: "Samsung Internet for Android"
      }, e = y.getFirstMatch(B, n) || y.getFirstMatch(/(?:SamsungBrowser)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/Whale/i],
    describe(n) {
      const t = {
        name: "NAVER Whale Browser"
      }, e = y.getFirstMatch(B, n) || y.getFirstMatch(/(?:whale)[\s/](\d+(?:\.\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/PaleMoon/i],
    describe(n) {
      const t = {
        name: "Pale Moon"
      }, e = y.getFirstMatch(B, n) || y.getFirstMatch(/(?:PaleMoon)[\s/](\d+(?:\.\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/MZBrowser/i],
    describe(n) {
      const t = {
        name: "MZ Browser"
      }, e = y.getFirstMatch(/(?:MZBrowser)[\s/](\d+(?:\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/focus/i],
    describe(n) {
      const t = {
        name: "Focus"
      }, e = y.getFirstMatch(/(?:focus)[\s/](\d+(?:\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/swing/i],
    describe(n) {
      const t = {
        name: "Swing"
      }, e = y.getFirstMatch(/(?:swing)[\s/](\d+(?:\.\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/coast/i],
    describe(n) {
      const t = {
        name: "Opera Coast"
      }, e = y.getFirstMatch(B, n) || y.getFirstMatch(/(?:coast)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/opt\/\d+(?:.?_?\d+)+/i],
    describe(n) {
      const t = {
        name: "Opera Touch"
      }, e = y.getFirstMatch(/(?:opt)[\s/](\d+(\.?_?\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/yabrowser/i],
    describe(n) {
      const t = {
        name: "Yandex Browser"
      }, e = y.getFirstMatch(/(?:yabrowser)[\s/](\d+(\.?_?\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/ucbrowser/i],
    describe(n) {
      const t = {
        name: "UC Browser"
      }, e = y.getFirstMatch(B, n) || y.getFirstMatch(/(?:ucbrowser)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/Maxthon|mxios/i],
    describe(n) {
      const t = {
        name: "Maxthon"
      }, e = y.getFirstMatch(B, n) || y.getFirstMatch(/(?:Maxthon|mxios)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/epiphany/i],
    describe(n) {
      const t = {
        name: "Epiphany"
      }, e = y.getFirstMatch(B, n) || y.getFirstMatch(/(?:epiphany)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/puffin/i],
    describe(n) {
      const t = {
        name: "Puffin"
      }, e = y.getFirstMatch(B, n) || y.getFirstMatch(/(?:puffin)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/sleipnir/i],
    describe(n) {
      const t = {
        name: "Sleipnir"
      }, e = y.getFirstMatch(B, n) || y.getFirstMatch(/(?:sleipnir)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/k-meleon/i],
    describe(n) {
      const t = {
        name: "K-Meleon"
      }, e = y.getFirstMatch(B, n) || y.getFirstMatch(/(?:k-meleon)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/micromessenger/i],
    describe(n) {
      const t = {
        name: "WeChat"
      }, e = y.getFirstMatch(/(?:micromessenger)[\s/](\d+(\.?_?\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/qqbrowser/i],
    describe(n) {
      const t = {
        name: /qqbrowserlite/i.test(n) ? "QQ Browser Lite" : "QQ Browser"
      }, e = y.getFirstMatch(/(?:qqbrowserlite|qqbrowser)[/](\d+(\.?_?\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/msie|trident/i],
    describe(n) {
      const t = {
        name: "Internet Explorer"
      }, e = y.getFirstMatch(/(?:msie |rv:)(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/\sedg\//i],
    describe(n) {
      const t = {
        name: "Microsoft Edge"
      }, e = y.getFirstMatch(/\sedg\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/edg([ea]|ios)/i],
    describe(n) {
      const t = {
        name: "Microsoft Edge"
      }, e = y.getSecondMatch(/edg([ea]|ios)\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/vivaldi/i],
    describe(n) {
      const t = {
        name: "Vivaldi"
      }, e = y.getFirstMatch(/vivaldi\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/seamonkey/i],
    describe(n) {
      const t = {
        name: "SeaMonkey"
      }, e = y.getFirstMatch(/seamonkey\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/sailfish/i],
    describe(n) {
      const t = {
        name: "Sailfish"
      }, e = y.getFirstMatch(/sailfish\s?browser\/(\d+(\.\d+)?)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/silk/i],
    describe(n) {
      const t = {
        name: "Amazon Silk"
      }, e = y.getFirstMatch(/silk\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/phantom/i],
    describe(n) {
      const t = {
        name: "PhantomJS"
      }, e = y.getFirstMatch(/phantomjs\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/slimerjs/i],
    describe(n) {
      const t = {
        name: "SlimerJS"
      }, e = y.getFirstMatch(/slimerjs\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/blackberry|\bbb\d+/i, /rim\stablet/i],
    describe(n) {
      const t = {
        name: "BlackBerry"
      }, e = y.getFirstMatch(B, n) || y.getFirstMatch(/blackberry[\d]+\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/(web|hpw)[o0]s/i],
    describe(n) {
      const t = {
        name: "WebOS Browser"
      }, e = y.getFirstMatch(B, n) || y.getFirstMatch(/w(?:eb)?[o0]sbrowser\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/bada/i],
    describe(n) {
      const t = {
        name: "Bada"
      }, e = y.getFirstMatch(/dolfin\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/tizen/i],
    describe(n) {
      const t = {
        name: "Tizen"
      }, e = y.getFirstMatch(/(?:tizen\s?)?browser\/(\d+(\.?_?\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/qupzilla/i],
    describe(n) {
      const t = {
        name: "QupZilla"
      }, e = y.getFirstMatch(/(?:qupzilla)[\s/](\d+(\.?_?\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/librewolf/i],
    describe(n) {
      const t = {
        name: "LibreWolf"
      }, e = y.getFirstMatch(/(?:librewolf)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/firefox|iceweasel|fxios/i],
    describe(n) {
      const t = {
        name: "Firefox"
      }, e = y.getFirstMatch(/(?:firefox|iceweasel|fxios)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/electron/i],
    describe(n) {
      const t = {
        name: "Electron"
      }, e = y.getFirstMatch(/(?:electron)\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/sogoumobilebrowser/i, /metasr/i, /se 2\.[x]/i],
    describe(n) {
      const t = {
        name: "Sogou Browser"
      }, e = y.getFirstMatch(/(?:sogoumobilebrowser)[\s/](\d+(\.?_?\d+)+)/i, n), i = y.getFirstMatch(/(?:chrome|crios|crmo)\/(\d+(\.?_?\d+)+)/i, n), s = y.getFirstMatch(/se ([\d.]+)x/i, n), o = e || i || s;
      return o && (t.version = o), t;
    }
  },
  {
    test: [/MiuiBrowser/i],
    describe(n) {
      const t = {
        name: "Miui"
      }, e = y.getFirstMatch(/(?:MiuiBrowser)[\s/](\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  /* DuckDuckGo Browser */
  {
    test(n) {
      return n.hasBrand("DuckDuckGo") ? !0 : n.test(/\sDdg\/[\d.]+$/i);
    },
    describe(n, t) {
      const e = {
        name: "DuckDuckGo"
      };
      if (t) {
        const s = t.getBrandVersion("DuckDuckGo");
        if (s)
          return e.version = s, e;
      }
      const i = y.getFirstMatch(/\sDdg\/([\d.]+)$/i, n);
      return i && (e.version = i), e;
    }
  },
  /* Brave Browser */
  {
    test(n) {
      return n.hasBrand("Brave");
    },
    describe(n, t) {
      const e = {
        name: "Brave"
      };
      if (t) {
        const i = t.getBrandVersion("Brave");
        if (i)
          return e.version = i, e;
      }
      return e;
    }
  },
  {
    test: [/chromium/i],
    describe(n) {
      const t = {
        name: "Chromium"
      }, e = y.getFirstMatch(/(?:chromium)[\s/](\d+(\.?_?\d+)+)/i, n) || y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/chrome|crios|crmo/i],
    describe(n) {
      const t = {
        name: "Chrome"
      }, e = y.getFirstMatch(/(?:chrome|crios|crmo)\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  {
    test: [/GSA/i],
    describe(n) {
      const t = {
        name: "Google Search"
      }, e = y.getFirstMatch(/(?:GSA)\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  /* Android Browser */
  {
    test(n) {
      const t = !n.test(/like android/i), e = n.test(/android/i);
      return t && e;
    },
    describe(n) {
      const t = {
        name: "Android Browser"
      }, e = y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* PlayStation 4 */
  {
    test: [/playstation 4/i],
    describe(n) {
      const t = {
        name: "PlayStation 4"
      }, e = y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* Safari */
  {
    test: [/safari|applewebkit/i],
    describe(n) {
      const t = {
        name: "Safari"
      }, e = y.getFirstMatch(B, n);
      return e && (t.version = e), t;
    }
  },
  /* Something else */
  {
    test: [/.*/i],
    describe(n) {
      const t = /^(.*)\/(.*) /, e = /^(.*)\/(.*)[ \t]\((.*)/, s = n.search("\\(") !== -1 ? e : t;
      return {
        name: y.getFirstMatch(s, n),
        version: y.getSecondMatch(s, n)
      };
    }
  }
], Ew = [
  /* Roku */
  {
    test: [/Roku\/DVP/],
    describe(n) {
      const t = y.getFirstMatch(/Roku\/DVP-(\d+\.\d+)/i, n);
      return {
        name: ct.Roku,
        version: t
      };
    }
  },
  /* Windows Phone */
  {
    test: [/windows phone/i],
    describe(n) {
      const t = y.getFirstMatch(/windows phone (?:os)?\s?(\d+(\.\d+)*)/i, n);
      return {
        name: ct.WindowsPhone,
        version: t
      };
    }
  },
  /* Windows */
  {
    test: [/windows /i],
    describe(n) {
      const t = y.getFirstMatch(/Windows ((NT|XP)( \d\d?.\d)?)/i, n), e = y.getWindowsVersionName(t);
      return {
        name: ct.Windows,
        version: t,
        versionName: e
      };
    }
  },
  /* Firefox on iPad */
  {
    test: [/Macintosh(.*?) FxiOS(.*?)\//],
    describe(n) {
      const t = {
        name: ct.iOS
      }, e = y.getSecondMatch(/(Version\/)(\d[\d.]+)/, n);
      return e && (t.version = e), t;
    }
  },
  /* macOS */
  {
    test: [/macintosh/i],
    describe(n) {
      const t = y.getFirstMatch(/mac os x (\d+(\.?_?\d+)+)/i, n).replace(/[_\s]/g, "."), e = y.getMacOSVersionName(t), i = {
        name: ct.MacOS,
        version: t
      };
      return e && (i.versionName = e), i;
    }
  },
  /* iOS */
  {
    test: [/(ipod|iphone|ipad)/i],
    describe(n) {
      const t = y.getFirstMatch(/os (\d+([_\s]\d+)*) like mac os x/i, n).replace(/[_\s]/g, ".");
      return {
        name: ct.iOS,
        version: t
      };
    }
  },
  /* HarmonyOS */
  {
    test: [/OpenHarmony/i],
    describe(n) {
      const t = y.getFirstMatch(/OpenHarmony\s+(\d+(\.\d+)*)/i, n);
      return {
        name: ct.HarmonyOS,
        version: t
      };
    }
  },
  /* Android */
  {
    test(n) {
      const t = !n.test(/like android/i), e = n.test(/android/i);
      return t && e;
    },
    describe(n) {
      const t = y.getFirstMatch(/android[\s/-](\d+(\.\d+)*)/i, n), e = y.getAndroidVersionName(t), i = {
        name: ct.Android,
        version: t
      };
      return e && (i.versionName = e), i;
    }
  },
  /* WebOS */
  {
    test: [/(web|hpw)[o0]s/i],
    describe(n) {
      const t = y.getFirstMatch(/(?:web|hpw)[o0]s\/(\d+(\.\d+)*)/i, n), e = {
        name: ct.WebOS
      };
      return t && t.length && (e.version = t), e;
    }
  },
  /* BlackBerry */
  {
    test: [/blackberry|\bbb\d+/i, /rim\stablet/i],
    describe(n) {
      const t = y.getFirstMatch(/rim\stablet\sos\s(\d+(\.\d+)*)/i, n) || y.getFirstMatch(/blackberry\d+\/(\d+([_\s]\d+)*)/i, n) || y.getFirstMatch(/\bbb(\d+)/i, n);
      return {
        name: ct.BlackBerry,
        version: t
      };
    }
  },
  /* Bada */
  {
    test: [/bada/i],
    describe(n) {
      const t = y.getFirstMatch(/bada\/(\d+(\.\d+)*)/i, n);
      return {
        name: ct.Bada,
        version: t
      };
    }
  },
  /* Tizen */
  {
    test: [/tizen/i],
    describe(n) {
      const t = y.getFirstMatch(/tizen[/\s](\d+(\.\d+)*)/i, n);
      return {
        name: ct.Tizen,
        version: t
      };
    }
  },
  /* Linux */
  {
    test: [/linux/i],
    describe() {
      return {
        name: ct.Linux
      };
    }
  },
  /* Chrome OS */
  {
    test: [/CrOS/],
    describe() {
      return {
        name: ct.ChromeOS
      };
    }
  },
  /* Playstation 4 */
  {
    test: [/PlayStation 4/],
    describe(n) {
      const t = y.getFirstMatch(/PlayStation 4[/\s](\d+(\.\d+)*)/i, n);
      return {
        name: ct.PlayStation4,
        version: t
      };
    }
  }
], Iw = [
  /* Googlebot */
  {
    test: [/googlebot/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Google"
      };
    }
  },
  /* LineSpider */
  {
    test: [/linespider/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Line"
      };
    }
  },
  /* AmazonBot */
  {
    test: [/amazonbot/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Amazon"
      };
    }
  },
  /* GPTBot */
  {
    test: [/gptbot/i],
    describe() {
      return {
        type: R.bot,
        vendor: "OpenAI"
      };
    }
  },
  /* ChatGPT-User */
  {
    test: [/chatgpt-user/i],
    describe() {
      return {
        type: R.bot,
        vendor: "OpenAI"
      };
    }
  },
  /* OAI-SearchBot */
  {
    test: [/oai-searchbot/i],
    describe() {
      return {
        type: R.bot,
        vendor: "OpenAI"
      };
    }
  },
  /* Baidu */
  {
    test: [/baiduspider/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Baidu"
      };
    }
  },
  /* Bingbot */
  {
    test: [/bingbot/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Bing"
      };
    }
  },
  /* DuckDuckBot */
  {
    test: [/duckduckbot/i],
    describe() {
      return {
        type: R.bot,
        vendor: "DuckDuckGo"
      };
    }
  },
  /* ClaudeBot */
  {
    test: [/claudebot/i, /claude-web/i, /claude-user/i, /claude-searchbot/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Anthropic"
      };
    }
  },
  /* Omgilibot */
  {
    test: [/omgilibot/i, /webzio-extended/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Webz.io"
      };
    }
  },
  /* Diffbot */
  {
    test: [/diffbot/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Diffbot"
      };
    }
  },
  /* PerplexityBot */
  {
    test: [/perplexitybot/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Perplexity AI"
      };
    }
  },
  /* Perplexity-User */
  {
    test: [/perplexity-user/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Perplexity AI"
      };
    }
  },
  /* YouBot */
  {
    test: [/youbot/i],
    describe() {
      return {
        type: R.bot,
        vendor: "You.com"
      };
    }
  },
  /* Internet Archive Crawler */
  {
    test: [/ia_archiver/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Internet Archive"
      };
    }
  },
  /* Meta-WebIndexer */
  {
    test: [/meta-webindexer/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Meta"
      };
    }
  },
  /* Meta-ExternalAds */
  {
    test: [/meta-externalads/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Meta"
      };
    }
  },
  /* Meta-ExternalAgent */
  {
    test: [/meta-externalagent/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Meta"
      };
    }
  },
  /* Meta-ExternalFetcher */
  {
    test: [/meta-externalfetcher/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Meta"
      };
    }
  },
  /* Meta Web Crawler */
  {
    test: [/facebookexternalhit/i, /facebookcatalog/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Meta"
      };
    }
  },
  /* SlackBot */
  {
    test: [/slackbot/i, /slack-imgProxy/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Slack"
      };
    }
  },
  /* Yahoo! Slurp */
  {
    test: [/yahoo/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Yahoo"
      };
    }
  },
  /* Yandex */
  {
    test: [/yandexbot/i, /yandexmobilebot/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Yandex"
      };
    }
  },
  /* Pingdom */
  {
    test: [/pingdom/i],
    describe() {
      return {
        type: R.bot,
        vendor: "Pingdom"
      };
    }
  },
  /* Huawei */
  {
    test: [/huawei/i],
    describe(n) {
      const t = y.getFirstMatch(/(can-l01)/i, n) && "Nova", e = {
        type: R.mobile,
        vendor: "Huawei"
      };
      return t && (e.model = t), e;
    }
  },
  /* Nexus Tablet */
  {
    test: [/nexus\s*(?:7|8|9|10).*/i],
    describe() {
      return {
        type: R.tablet,
        vendor: "Nexus"
      };
    }
  },
  /* iPad */
  {
    test: [/ipad/i],
    describe() {
      return {
        type: R.tablet,
        vendor: "Apple",
        model: "iPad"
      };
    }
  },
  /* Firefox on iPad */
  {
    test: [/Macintosh(.*?) FxiOS(.*?)\//],
    describe() {
      return {
        type: R.tablet,
        vendor: "Apple",
        model: "iPad"
      };
    }
  },
  /* Amazon Kindle Fire */
  {
    test: [/kftt build/i],
    describe() {
      return {
        type: R.tablet,
        vendor: "Amazon",
        model: "Kindle Fire HD 7"
      };
    }
  },
  /* Another Amazon Tablet with Silk */
  {
    test: [/silk/i],
    describe() {
      return {
        type: R.tablet,
        vendor: "Amazon"
      };
    }
  },
  /* Tablet */
  {
    test: [/tablet(?! pc)/i],
    describe() {
      return {
        type: R.tablet
      };
    }
  },
  /* iPod/iPhone */
  {
    test(n) {
      const t = n.test(/ipod|iphone/i), e = n.test(/like (ipod|iphone)/i);
      return t && !e;
    },
    describe(n) {
      const t = y.getFirstMatch(/(ipod|iphone)/i, n);
      return {
        type: R.mobile,
        vendor: "Apple",
        model: t
      };
    }
  },
  /* Nexus Mobile */
  {
    test: [/nexus\s*[0-6].*/i, /galaxy nexus/i],
    describe() {
      return {
        type: R.mobile,
        vendor: "Nexus"
      };
    }
  },
  /* Nokia */
  {
    test: [/Nokia/i],
    describe(n) {
      const t = y.getFirstMatch(/Nokia\s+([0-9]+(\.[0-9]+)?)/i, n), e = {
        type: R.mobile,
        vendor: "Nokia"
      };
      return t && (e.model = t), e;
    }
  },
  /* Mobile */
  {
    test: [/[^-]mobi/i],
    describe() {
      return {
        type: R.mobile
      };
    }
  },
  /* BlackBerry */
  {
    test(n) {
      return n.getBrowserName(!0) === "blackberry";
    },
    describe() {
      return {
        type: R.mobile,
        vendor: "BlackBerry"
      };
    }
  },
  /* Bada */
  {
    test(n) {
      return n.getBrowserName(!0) === "bada";
    },
    describe() {
      return {
        type: R.mobile
      };
    }
  },
  /* Windows Phone */
  {
    test(n) {
      return n.getBrowserName() === "windows phone";
    },
    describe() {
      return {
        type: R.mobile,
        vendor: "Microsoft"
      };
    }
  },
  /* Android Tablet */
  {
    test(n) {
      const t = Number(String(n.getOSVersion()).split(".")[0]);
      return n.getOSName(!0) === "android" && t >= 3;
    },
    describe() {
      return {
        type: R.tablet
      };
    }
  },
  /* Android Mobile */
  {
    test(n) {
      return n.getOSName(!0) === "android";
    },
    describe() {
      return {
        type: R.mobile
      };
    }
  },
  /* Smart TV */
  {
    test: [/smart-?tv|smarttv/i],
    describe() {
      return {
        type: R.tv
      };
    }
  },
  /* NetCast (LG Smart TV) */
  {
    test: [/netcast/i],
    describe() {
      return {
        type: R.tv
      };
    }
  },
  /* desktop */
  {
    test(n) {
      return n.getOSName(!0) === "macos";
    },
    describe() {
      return {
        type: R.desktop,
        vendor: "Apple"
      };
    }
  },
  /* Windows */
  {
    test(n) {
      return n.getOSName(!0) === "windows";
    },
    describe() {
      return {
        type: R.desktop
      };
    }
  },
  /* Linux */
  {
    test(n) {
      return n.getOSName(!0) === "linux";
    },
    describe() {
      return {
        type: R.desktop
      };
    }
  },
  /* PlayStation 4 */
  {
    test(n) {
      return n.getOSName(!0) === "playstation 4";
    },
    describe() {
      return {
        type: R.tv
      };
    }
  },
  /* Roku */
  {
    test(n) {
      return n.getOSName(!0) === "roku";
    },
    describe() {
      return {
        type: R.tv
      };
    }
  }
], Pw = [
  /* EdgeHTML */
  {
    test(n) {
      return n.getBrowserName(!0) === "microsoft edge";
    },
    describe(n) {
      if (/\sedg\//i.test(n))
        return {
          name: Yt.Blink
        };
      const e = y.getFirstMatch(/edge\/(\d+(\.?_?\d+)+)/i, n);
      return {
        name: Yt.EdgeHTML,
        version: e
      };
    }
  },
  /* Trident */
  {
    test: [/trident/i],
    describe(n) {
      const t = {
        name: Yt.Trident
      }, e = y.getFirstMatch(/trident\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  /* Presto */
  {
    test(n) {
      return n.test(/presto/i);
    },
    describe(n) {
      const t = {
        name: Yt.Presto
      }, e = y.getFirstMatch(/presto\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  /* Gecko */
  {
    test(n) {
      const t = n.test(/gecko/i), e = n.test(/like gecko/i);
      return t && !e;
    },
    describe(n) {
      const t = {
        name: Yt.Gecko
      }, e = y.getFirstMatch(/gecko\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  },
  /* Blink */
  {
    test: [/(apple)?webkit\/537\.36/i],
    describe() {
      return {
        name: Yt.Blink
      };
    }
  },
  /* WebKit */
  {
    test: [/(apple)?webkit/i],
    describe(n) {
      const t = {
        name: Yt.WebKit
      }, e = y.getFirstMatch(/webkit\/(\d+(\.?_?\d+)+)/i, n);
      return e && (t.version = e), t;
    }
  }
];
class Xa {
  /**
   * Create instance of Parser
   *
   * @param {String} UA User-Agent string
   * @param {Boolean|ClientHints} [skipParsingOrHints=false] Either a boolean to skip parsing,
   * or a ClientHints object containing User-Agent Client Hints data
   * @param {ClientHints} [clientHints] User-Agent Client Hints data (navigator.userAgentData)
   *
   * @throw {Error} in case of empty UA String
   *
   * @constructor
   */
  constructor(t, e = !1, i = null) {
    if (t == null || t === "")
      throw new Error("UserAgent parameter can't be empty");
    this._ua = t;
    let s = !1;
    typeof e == "boolean" ? (s = e, this._hints = i) : e != null && typeof e == "object" ? this._hints = e : this._hints = null, this.parsedResult = {}, s !== !0 && this.parse();
  }
  /**
   * Get Client Hints data
   * @return {ClientHints|null}
   *
   * @public
   * @example
   * const parser = Bowser.getParser(UA, clientHints);
   * const hints = parser.getHints();
   * console.log(hints.platform); // 'Windows'
   * console.log(hints.mobile); // false
   */
  getHints() {
    return this._hints;
  }
  /**
   * Check if a brand exists in Client Hints brands array
   * @param {string} brandName The brand name to check for
   * @return {boolean}
   *
   * @public
   * @example
   * const parser = Bowser.getParser(UA, clientHints);
   * if (parser.hasBrand('Google Chrome')) {
   *   console.log('Chrome detected!');
   * }
   */
  hasBrand(t) {
    if (!this._hints || !Array.isArray(this._hints.brands))
      return !1;
    const e = t.toLowerCase();
    return this._hints.brands.some(
      (i) => i.brand && i.brand.toLowerCase() === e
    );
  }
  /**
   * Get brand version from Client Hints
   * @param {string} brandName The brand name to get version for
   * @return {string|undefined}
   *
   * @public
   * @example
   * const parser = Bowser.getParser(UA, clientHints);
   * const version = parser.getBrandVersion('Google Chrome');
   * console.log(version); // '131'
   */
  getBrandVersion(t) {
    if (!this._hints || !Array.isArray(this._hints.brands))
      return;
    const e = t.toLowerCase(), i = this._hints.brands.find(
      (s) => s.brand && s.brand.toLowerCase() === e
    );
    return i ? i.version : void 0;
  }
  /**
   * Get UserAgent string of current Parser instance
   * @return {String} User-Agent String of the current <Parser> object
   *
   * @public
   */
  getUA() {
    return this._ua;
  }
  /**
   * Test a UA string for a regexp
   * @param {RegExp} regex
   * @return {Boolean}
   */
  test(t) {
    return t.test(this._ua);
  }
  /**
   * Get parsed browser object
   * @return {Object}
   */
  parseBrowser() {
    this.parsedResult.browser = {};
    const t = y.find(Cw, (e) => {
      if (typeof e.test == "function")
        return e.test(this);
      if (Array.isArray(e.test))
        return e.test.some((i) => this.test(i));
      throw new Error("Browser's test function is not valid");
    });
    return t && (this.parsedResult.browser = t.describe(this.getUA(), this)), this.parsedResult.browser;
  }
  /**
   * Get parsed browser object
   * @return {Object}
   *
   * @public
   */
  getBrowser() {
    return this.parsedResult.browser ? this.parsedResult.browser : this.parseBrowser();
  }
  /**
   * Get browser's name
   * @return {String} Browser's name or an empty string
   *
   * @public
   */
  getBrowserName(t) {
    return t ? String(this.getBrowser().name).toLowerCase() || "" : this.getBrowser().name || "";
  }
  /**
   * Get browser's version
   * @return {String} version of browser
   *
   * @public
   */
  getBrowserVersion() {
    return this.getBrowser().version;
  }
  /**
   * Get OS
   * @return {Object}
   *
   * @example
   * this.getOS();
   * {
   *   name: 'macOS',
   *   version: '10.11.12'
   * }
   */
  getOS() {
    return this.parsedResult.os ? this.parsedResult.os : this.parseOS();
  }
  /**
   * Parse OS and save it to this.parsedResult.os
   * @return {*|{}}
   */
  parseOS() {
    this.parsedResult.os = {};
    const t = y.find(Ew, (e) => {
      if (typeof e.test == "function")
        return e.test(this);
      if (Array.isArray(e.test))
        return e.test.some((i) => this.test(i));
      throw new Error("Browser's test function is not valid");
    });
    return t && (this.parsedResult.os = t.describe(this.getUA())), this.parsedResult.os;
  }
  /**
   * Get OS name
   * @param {Boolean} [toLowerCase] return lower-cased value
   * @return {String} name of the OS — macOS, Windows, Linux, etc.
   */
  getOSName(t) {
    const { name: e } = this.getOS();
    return t ? String(e).toLowerCase() || "" : e || "";
  }
  /**
   * Get OS version
   * @return {String} full version with dots ('10.11.12', '5.6', etc)
   */
  getOSVersion() {
    return this.getOS().version;
  }
  /**
   * Get parsed platform
   * @return {{}}
   */
  getPlatform() {
    return this.parsedResult.platform ? this.parsedResult.platform : this.parsePlatform();
  }
  /**
   * Get platform name
   * @param {Boolean} [toLowerCase=false]
   * @return {*}
   */
  getPlatformType(t = !1) {
    const { type: e } = this.getPlatform();
    return t ? String(e).toLowerCase() || "" : e || "";
  }
  /**
   * Get parsed platform
   * @return {{}}
   */
  parsePlatform() {
    this.parsedResult.platform = {};
    const t = y.find(Iw, (e) => {
      if (typeof e.test == "function")
        return e.test(this);
      if (Array.isArray(e.test))
        return e.test.some((i) => this.test(i));
      throw new Error("Browser's test function is not valid");
    });
    return t && (this.parsedResult.platform = t.describe(this.getUA())), this.parsedResult.platform;
  }
  /**
   * Get parsed engine
   * @return {{}}
   */
  getEngine() {
    return this.parsedResult.engine ? this.parsedResult.engine : this.parseEngine();
  }
  /**
   * Get engines's name
   * @return {String} Engines's name or an empty string
   *
   * @public
   */
  getEngineName(t) {
    return t ? String(this.getEngine().name).toLowerCase() || "" : this.getEngine().name || "";
  }
  /**
   * Get parsed platform
   * @return {{}}
   */
  parseEngine() {
    this.parsedResult.engine = {};
    const t = y.find(Pw, (e) => {
      if (typeof e.test == "function")
        return e.test(this);
      if (Array.isArray(e.test))
        return e.test.some((i) => this.test(i));
      throw new Error("Browser's test function is not valid");
    });
    return t && (this.parsedResult.engine = t.describe(this.getUA())), this.parsedResult.engine;
  }
  /**
   * Parse full information about the browser
   * @returns {Parser}
   */
  parse() {
    return this.parseBrowser(), this.parseOS(), this.parsePlatform(), this.parseEngine(), this;
  }
  /**
   * Get parsed result
   * @return {ParsedResult}
   */
  getResult() {
    return y.assign({}, this.parsedResult);
  }
  /**
   * Check if parsed browser matches certain conditions
   *
   * @param {Object} checkTree It's one or two layered object,
   * which can include a platform or an OS on the first layer
   * and should have browsers specs on the bottom-laying layer
   *
   * @returns {Boolean|undefined} Whether the browser satisfies the set conditions or not.
   * Returns `undefined` when the browser is no described in the checkTree object.
   *
   * @example
   * const browser = Bowser.getParser(window.navigator.userAgent);
   * if (browser.satisfies({chrome: '>118.01.1322' }))
   * // or with os
   * if (browser.satisfies({windows: { chrome: '>118.01.1322' } }))
   * // or with platforms
   * if (browser.satisfies({desktop: { chrome: '>118.01.1322' } }))
   */
  satisfies(t) {
    const e = {};
    let i = 0;
    const s = {};
    let o = 0;
    if (Object.keys(t).forEach((a) => {
      const l = t[a];
      typeof l == "string" ? (s[a] = l, o += 1) : typeof l == "object" && (e[a] = l, i += 1);
    }), i > 0) {
      const a = Object.keys(e), l = y.find(a, (d) => this.isOS(d));
      if (l) {
        const d = this.satisfies(e[l]);
        if (d !== void 0)
          return d;
      }
      const c = y.find(
        a,
        (d) => this.isPlatform(d)
      );
      if (c) {
        const d = this.satisfies(e[c]);
        if (d !== void 0)
          return d;
      }
    }
    if (o > 0) {
      const a = Object.keys(s), l = y.find(a, (c) => this.isBrowser(c, !0));
      if (l !== void 0)
        return this.compareVersion(s[l]);
    }
  }
  /**
   * Check if the browser name equals the passed string
   * @param {string} browserName The string to compare with the browser name
   * @param [includingAlias=false] The flag showing whether alias will be included into comparison
   * @returns {boolean}
   */
  isBrowser(t, e = !1) {
    const i = this.getBrowserName().toLowerCase();
    let s = t.toLowerCase();
    const o = y.getBrowserTypeByAlias(s);
    return e && o && (s = o.toLowerCase()), s === i;
  }
  compareVersion(t) {
    let e = [0], i = t, s = !1;
    const o = this.getBrowserVersion();
    if (typeof o == "string")
      return t[0] === ">" || t[0] === "<" ? (i = t.substr(1), t[1] === "=" ? (s = !0, i = t.substr(2)) : e = [], t[0] === ">" ? e.push(1) : e.push(-1)) : t[0] === "=" ? i = t.substr(1) : t[0] === "~" && (s = !0, i = t.substr(1)), e.indexOf(
        y.compareVersions(o, i, s)
      ) > -1;
  }
  /**
   * Check if the OS name equals the passed string
   * @param {string} osName The string to compare with the OS name
   * @returns {boolean}
   */
  isOS(t) {
    return this.getOSName(!0) === String(t).toLowerCase();
  }
  /**
   * Check if the platform type equals the passed string
   * @param {string} platformType The string to compare with the platform type
   * @returns {boolean}
   */
  isPlatform(t) {
    return this.getPlatformType(!0) === String(t).toLowerCase();
  }
  /**
   * Check if the engine name equals the passed string
   * @param {string} engineName The string to compare with the engine name
   * @returns {boolean}
   */
  isEngine(t) {
    return this.getEngineName(!0) === String(t).toLowerCase();
  }
  /**
   * Is anything? Check if the browser is called "anything",
   * the OS called "anything" or the platform called "anything"
   * @param {String} anything
   * @param [includingAlias=false] The flag showing whether alias will be included into comparison
   * @returns {Boolean}
   */
  is(t, e = !1) {
    return this.isBrowser(t, e) || this.isOS(t) || this.isPlatform(t);
  }
  /**
   * Check if any of the given values satisfies this.is(anything)
   * @param {String[]} anythings
   * @returns {Boolean}
   */
  some(t = []) {
    return t.some((e) => this.is(e));
  }
}
class Mw {
  /**
   * Creates a {@link Parser} instance
   *
   * @param {String} UA UserAgent string
   * @param {Boolean|Object} [skipParsingOrHints=false] Either a boolean to skip parsing,
   * or a ClientHints object (navigator.userAgentData)
   * @param {Object} [clientHints] User-Agent Client Hints data (navigator.userAgentData)
   * @returns {Parser}
   * @throws {Error} when UA is not a String
   *
   * @example
   * const parser = Bowser.getParser(window.navigator.userAgent);
   * const result = parser.getResult();
   *
   * @example
   * // With User-Agent Client Hints
   * const parser = Bowser.getParser(
   *   window.navigator.userAgent,
   *   window.navigator.userAgentData
   * );
   */
  static getParser(t, e = !1, i = null) {
    if (typeof t != "string")
      throw new Error("UserAgent should be a string");
    return new Xa(t, e, i);
  }
  /**
   * Creates a {@link Parser} instance and runs {@link Parser.getResult} immediately
   *
   * @param {String} UA UserAgent string
   * @param {Object} [clientHints] User-Agent Client Hints data (navigator.userAgentData)
   * @return {ParsedResult}
   *
   * @example
   * const result = Bowser.parse(window.navigator.userAgent);
   *
   * @example
   * // With User-Agent Client Hints
   * const result = Bowser.parse(
   *   window.navigator.userAgent,
   *   window.navigator.userAgentData
   * );
   */
  static parse(t, e = null) {
    return new Xa(t, e).getResult();
  }
  static get BROWSER_MAP() {
    return Wu;
  }
  static get ENGINE_MAP() {
    return Yt;
  }
  static get OS_MAP() {
    return ct;
  }
  static get PLATFORMS_MAP() {
    return R;
  }
}
const Jn = Mw.getParser(
  globalThis.navigator.userAgent
).getResult(), un = "unknown", Ja = (...n) => n.filter(Boolean).join(" ").trim() || un;
function zu() {
  const n = Ja(Jn.os?.name, Jn.os?.version), t = Ja(
    Jn.browser?.name,
    Jn.browser?.version
  ), e = (() => {
    const r = GM_info?.scriptHandler, a = GM_info?.version;
    return r && a ? `${r} v${a}` : r || a || un;
  })(), i = GM_info?.script?.version ?? un, s = GM_info?.script?.name ?? un, o = globalThis?.location?.href ?? un;
  return {
    os: n,
    browser: t,
    loader: e,
    scriptVersion: i,
    scriptName: s,
    url: o
  };
}
class Ow {
  constructor({
    loggedIn: t = !1,
    username: e = "unnamed",
    avatarId: i = "0/0-0"
  } = {}) {
    u(this, "container");
    u(this, "accountWrapper");
    u(this, "buttons");
    u(this, "usernameEl");
    u(this, "avatarEl");
    u(this, "avatarImg");
    u(this, "actionButton");
    u(this, "refreshButton");
    u(this, "tokenButton");
    u(this, "onClick", new z());
    u(this, "onRefresh", new z());
    u(this, "onClickSecret", new z());
    u(this, "events", {
      click: this.onClick,
      "click:secret": this.onClickSecret,
      refresh: this.onRefresh
    });
    u(this, "_loggedIn");
    u(this, "_username");
    u(this, "_avatarId");
    this._loggedIn = t, this._username = e, this._avatarId = i;
    const s = this.createElements();
    this.container = s.container, this.accountWrapper = s.accountWrapper, this.buttons = s.buttons, this.usernameEl = s.usernameEl, this.avatarEl = s.avatarEl, this.avatarImg = s.avatarImg, this.actionButton = s.actionButton, this.refreshButton = s.refreshButton, this.tokenButton = s.tokenButton;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-account"]), e = L.createEl("vot-block", ["vot-account-wrapper"]);
    e.hidden = !this._loggedIn;
    const i = L.createEl("img", [
      "vot-account-avatar-img"
    ]);
    i.src = `${br}/${this._avatarId}/islands-retina-middle`, i.loading = "lazy", i.alt = "user avatar";
    const s = L.createEl(
      "vot-block",
      ["vot-account-avatar"],
      i
    ), o = L.createEl("vot-block", ["vot-account-username"]);
    o.textContent = this._username, e.append(s, o);
    const r = L.createEl("vot-block", ["vot-account-buttons"]), a = L.createOutlinedButton(this.buttonText);
    a.addEventListener("click", () => {
      this.onClick.dispatch();
    });
    const l = L.createIconButton(ww, {
      ariaLabel: p.get("VOTLoginViaToken")
    });
    l.hidden = this._loggedIn, l.addEventListener("click", () => {
      this.onClickSecret.dispatch();
    });
    const c = L.createIconButton(vw, {
      ariaLabel: p.get("VOTRefresh")
    });
    return c.addEventListener("click", () => {
      this.onRefresh.dispatch();
    }), r.append(a, l, c), t.append(e, r), {
      container: t,
      accountWrapper: e,
      buttons: r,
      usernameEl: o,
      avatarImg: i,
      avatarEl: s,
      actionButton: a,
      refreshButton: c,
      tokenButton: l
    };
  }
  addEventListener(t, e) {
    return Qt(this.events, t, e), this;
  }
  removeEventListener(t, e) {
    return te(this.events, t, e), this;
  }
  get buttonText() {
    return this._loggedIn ? p.get("VOTLogout") : p.get("VOTLogin");
  }
  get loggedIn() {
    return this._loggedIn;
  }
  set loggedIn(t) {
    this._loggedIn = t, this.accountWrapper.hidden = !this._loggedIn, this.actionButton.textContent = this.buttonText, this.tokenButton.hidden = this._loggedIn;
  }
  get avatarId() {
    return this._avatarId;
  }
  set avatarId(t) {
    this._avatarId = t ?? "0/0-0", this.avatarImg.src = `${br}/${this._avatarId}/islands-retina-middle`;
  }
  get username() {
    return this._username;
  }
  set username(t) {
    this._username = t ?? "unnamed", this.usernameEl.textContent = this._username;
  }
  set hidden(t) {
    Tt(this.container, t);
  }
  get hidden() {
    return kt(this.container);
  }
}
class st {
  constructor({
    labelHtml: t,
    checked: e = !1,
    isSubCheckbox: i = !1
  }) {
    u(this, "container");
    u(this, "input");
    u(this, "label");
    u(this, "onChange", new z());
    u(this, "events", {
      change: this.onChange
    });
    u(this, "_labelHtml");
    u(this, "_checked");
    u(this, "_isSubCheckbox");
    this._labelHtml = t, this._checked = e, this._isSubCheckbox = i;
    const s = this.createElements();
    this.container = s.container, this.input = s.input, this.label = s.label;
  }
  createElements() {
    const t = L.createEl("label", ["vot-checkbox"]);
    this._isSubCheckbox && t.classList.add("vot-checkbox-sub");
    const e = document.createElement("input");
    e.type = "checkbox", e.checked = this._checked, e.addEventListener("change", () => {
      this._checked = e.checked, this.onChange.dispatch(this._checked);
    });
    const i = L.createEl("span");
    return wt(this._labelHtml, i), t.append(e, i), { container: t, input: e, label: i };
  }
  addEventListener(t, e) {
    return Qt(this.events, "change", e), this;
  }
  removeEventListener(t, e) {
    return te(this.events, "change", e), this;
  }
  set hidden(t) {
    Tt(this.container, t);
  }
  get hidden() {
    return kt(this.container);
  }
  get disabled() {
    return this.input.disabled;
  }
  set disabled(t) {
    this.input.disabled = t;
  }
  get checked() {
    return this._checked;
  }
  /**
   * If you set a different new value, it will trigger the change event
   */
  set checked(t) {
    this._checked !== t && (this._checked = this.input.checked = t, this.onChange.dispatch(this._checked));
  }
}
class Dw {
  constructor({ titleHtml: t }) {
    u(this, "container");
    u(this, "header");
    u(this, "arrowIcon");
    u(this, "onClick", new z());
    u(this, "events", {
      click: this.onClick
    });
    u(this, "_titleHtml");
    this._titleHtml = t;
    const e = this.createElements();
    this.container = e.container, this.header = e.header, this.arrowIcon = e.arrowIcon;
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-details"]);
    L.makeButtonLike(t);
    const e = L.createEl("vot-block");
    e.append(this._titleHtml);
    const i = L.createEl("vot-block", ["vot-details-arrow-icon"]);
    return wt(Hu, i), t.append(e, i), t.addEventListener("click", () => {
      this.onClick.dispatch();
    }), {
      container: t,
      header: e,
      arrowIcon: i
    };
  }
  addEventListener(t, e) {
    return Qt(this.events, "click", e), this;
  }
  removeEventListener(t, e) {
    return te(this.events, "click", e), this;
  }
  set hidden(t) {
    Tt(this.container, t);
  }
  get hidden() {
    return kt(this.container);
  }
}
class Za {
  constructor({ labelHtml: t, key: e = null }) {
    u(this, "container");
    u(this, "button");
    u(this, "onChange", new z());
    u(this, "events", {
      change: this.onChange
    });
    u(this, "_labelHtml");
    u(this, "_key");
    // Currently held keys while recording.
    u(this, "pressedKeys");
    // Union of all keys pressed during the recording session.
    u(this, "comboKeys");
    u(this, "recording", !1);
    u(this, "keydownHandle", (t) => {
      if (!(!this.recording || t.repeat)) {
        if (t.preventDefault(), t.code === "Escape") {
          this.key = null, this.button.textContent = this.keyText, this.stopRecordingKeys();
          return;
        }
        this.pressedKeys.add(t.code), this.comboKeys.add(t.code), this.button.textContent = Zn(this.pressedKeys);
      }
    });
    u(this, "keyupOrBlurHandle", (t) => {
      this.recording && (t && (this.pressedKeys.delete(t.code), this.button.textContent = this.pressedKeys.size ? Zn(this.pressedKeys) : Zn(this.comboKeys), this.pressedKeys.size) || (this.key = this.comboKeys.size ? _w(this.comboKeys) : null, this.stopRecordingKeys()));
    });
    u(this, "blurHandle", () => {
      this.keyupOrBlurHandle();
    });
    this._labelHtml = t, this._key = e, this.pressedKeys = /* @__PURE__ */ new Set(), this.comboKeys = /* @__PURE__ */ new Set();
    const i = this.createElements();
    this.container = i.container, this.button = i.button;
  }
  stopRecordingKeys() {
    this.recording = !1, document.removeEventListener("keydown", this.keydownHandle), document.removeEventListener("keyup", this.keyupOrBlurHandle), globalThis.removeEventListener("blur", this.blurHandle), delete this.button.dataset.status, this.pressedKeys.clear(), this.comboKeys.clear();
  }
  createElements() {
    const t = L.createEl("vot-block", ["vot-hotkey"]), e = L.createEl("vot-block", ["vot-hotkey-label"]);
    e.textContent = this._labelHtml;
    const i = L.createEl("vot-block", ["vot-hotkey-button"]);
    return L.makeButtonLike(i), i.textContent = this.keyText, i.addEventListener("click", () => {
      if (this.recording) {
        this.stopRecordingKeys(), this.button.textContent = this.keyText;
        return;
      }
      i.dataset.status = "active", this.recording = !0, this.pressedKeys.clear(), this.comboKeys.clear(), this.button.textContent = p.get(
        "PressTheKeyCombination"
      ), document.addEventListener("keydown", this.keydownHandle), document.addEventListener("keyup", this.keyupOrBlurHandle), globalThis.addEventListener("blur", this.blurHandle);
    }), t.append(e, i), { container: t, button: i, label: e };
  }
  addEventListener(t, e) {
    return Qt(this.events, "change", e), this;
  }
  removeEventListener(t, e) {
    return te(this.events, "change", e), this;
  }
  set hidden(t) {
    Tt(this.container, t);
  }
  get hidden() {
    return kt(this.container);
  }
  get key() {
    return this._key;
  }
  get keyText() {
    return this._key ? Zn(this._key) : p.get("None");
  }
  /**
   * If you set a different new value, it will trigger the change event
   */
  set key(t) {
    this._key !== t && (this._key = t, this.button.textContent = this.keyText, this.onChange.dispatch(this._key));
  }
}
function _w(n) {
  return (Array.isArray(n) ? n : Array.from(n)).map((e) => e.replace("Key", "").replace("Digit", "")).join("+");
}
function Zn(n) {
  let t;
  typeof n == "string" ? t = n.split("+").filter(Boolean) : Array.isArray(n) ? t = n : t = Array.from(n);
  const e = (s) => {
    switch (s) {
      case "ControlLeft":
      case "ControlRight":
      case "Control":
        return "Ctrl";
      case "ShiftLeft":
      case "ShiftRight":
      case "Shift":
        return "Shift";
      case "AltLeft":
      case "AltRight":
      case "Alt":
        return "Alt";
      case "MetaLeft":
      case "MetaRight":
      case "Meta":
        return "Meta";
      case "Space":
        return "Space";
      case "ArrowUp":
        return "↑";
      case "ArrowDown":
        return "↓";
      case "ArrowLeft":
        return "←";
      case "ArrowRight":
        return "→";
      default:
        return s.replace("Key", "").replace("Digit", "");
    }
  }, i = (s) => {
    const o = e(s);
    return o === "Ctrl" ? 0 : o === "Alt" ? 1 : o === "Shift" ? 2 : o === "Meta" ? 3 : 10;
  };
  return t.slice().sort((s, o) => i(s) - i(o)).map(e).join("+");
}
const Rw = [
  "click:bugReport",
  "click:resetSettings",
  "update:account",
  "change:autoTranslate",
  "change:autoSubtitles",
  "change:showVideoVolume",
  "change:audioBooster",
  "change:syncVolume",
  "change:useLivelyVoice",
  "change:subtitlesHighlightWords",
  "change:subtitlesSmartLayout",
  "select:subtitlesFontFamily",
  "change:proxyWorkerHost",
  "change:useNewAudioPlayer",
  "change:onlyBypassMediaCSP",
  "change:showPiPButton",
  "input:subtitlesMaxLength",
  "input:subtitlesFontSize",
  "input:subtitlesBackgroundOpacity",
  "input:autoHideButtonDelay",
  "select:proxyTranslationStatus",
  "select:translationTextService",
  "select:buttonPosition",
  "select:menuLanguage"
];
function Bw() {
  const n = {};
  for (const t of Rw)
    n[t] = new z();
  return n;
}
const Fw = 30, qu = {
  "default-sans": "Default Sans",
  arial: "Arial",
  helvetica: "Helvetica",
  roboto: "Roboto",
  verdana: "Verdana",
  "open-sans": "Open Sans",
  poppins: "Poppins",
  lato: "Lato",
  montserrat: "Montserrat",
  barlow: "Barlow"
};
function Qa(n) {
  return vi(n) ? qu[n] : $e(n) ?? "Default Sans";
}
const Ii = class Ii {
  constructor({ globalPortal: t, data: e = {}, videoHandler: i }) {
    u(this, "globalPortal");
    u(this, "initialized", !1);
    u(this, "data");
    u(this, "videoHandler");
    u(this, "suppressSubtitlesSmartLayoutCheckboxChange", !1);
    u(this, "events", Bw());
    u(this, "oauthMessageListenerBound", !1);
    u(this, "persistTimerIds", {});
    u(this, "dialog");
    u(this, "accountButton");
    u(this, "accountButtonRefreshTooltip");
    u(this, "accountButtonTokenTooltip");
    u(this, "autoTranslateCheckbox");
    u(this, "autoSubtitlesCheckbox");
    u(this, "dontTranslateLanguagesCheckbox");
    u(this, "dontTranslateLanguagesSelect");
    u(this, "autoSetVolumeSliderLabel");
    u(this, "autoSetVolumeCheckbox");
    u(this, "smartDuckingCheckbox");
    u(this, "autoSetVolumeSlider");
    u(this, "showVideoVolumeSliderCheckbox");
    u(this, "audioBoosterCheckbox");
    u(this, "audioBoosterTooltip");
    u(this, "syncVolumeCheckbox");
    u(this, "downloadWithNameCheckbox");
    u(this, "sendNotifyOnCompleteCheckbox");
    u(this, "useLivelyVoiceCheckbox");
    u(this, "useLivelyVoiceTooltip");
    u(this, "useAudioDownloadCheckbox");
    u(this, "useAudioDownloadCheckboxLabel");
    u(this, "useAudioDownloadCheckboxTooltip");
    u(this, "subtitlesDownloadFormatSelectLabel");
    u(this, "subtitlesDownloadFormatSelect");
    u(this, "subtitlesHighlightWordsCheckbox");
    u(this, "subtitlesSmartLayoutCheckbox");
    u(this, "subtitlesMaxLengthSliderLabel");
    u(this, "subtitlesMaxLengthSlider");
    u(this, "subtitlesFontSizeSliderLabel");
    u(this, "subtitlesFontSizeSlider");
    u(this, "subtitlesFontFamilySelectLabel");
    u(this, "subtitlesFontFamilySelect");
    u(this, "subtitlesBackgroundOpacitySliderLabel");
    u(this, "subtitlesBackgroundOpacitySlider");
    u(this, "translateHotkeyButton");
    u(this, "subtitlesHotkeyButton");
    u(this, "proxyWorkerHostTextfield");
    u(this, "proxyTranslationStatusSelectLabel");
    u(this, "proxyTranslationStatusSelectTooltip");
    u(this, "proxyTranslationStatusSelect");
    u(this, "translateAPIErrorsCheckbox");
    u(this, "useNewAudioPlayerCheckbox");
    u(this, "useNewAudioPlayerTooltip");
    u(this, "onlyBypassMediaCSPCheckbox");
    u(this, "onlyBypassMediaCSPTooltip");
    u(this, "translationTextServiceLabel");
    u(this, "translationTextServiceSelect");
    u(this, "translationTextServiceTooltip");
    u(this, "detectServiceLabel");
    u(this, "detectServiceSelect");
    u(this, "showPiPButtonCheckbox");
    u(this, "autoHideButtonDelaySliderLabel");
    u(this, "autoHideButtonDelaySlider");
    u(this, "buttonPositionSelectLabel");
    u(this, "buttonPositionSelect");
    u(this, "buttonPositionTooltip");
    u(this, "menuLanguageSelectLabel");
    u(this, "menuLanguageSelect");
    u(this, "bugReportButton");
    u(this, "resetSettingsButton");
    this.globalPortal = t, this.data = e, this.videoHandler = i;
  }
  isInitialized() {
    return this.initialized;
  }
  bindOAuthMessageListener() {
    this.oauthMessageListenerBound || (this.oauthMessageListenerBound = !0, globalThis.addEventListener("message", async (t) => {
      const e = t.data;
      if (!e || typeof e != "object" || e.source !== "vot-auth") return;
      if (t.origin !== On) {
        C.log(
          "[VOT] Ignoring OAuth message from unexpected origin:",
          t.origin
        );
        return;
      }
      if (e.type === "error") {
        C.log("[VOT] OAuth error:", e.error, e.error_description);
        return;
      }
      if (e.type !== "code") return;
      const i = sessionStorage.getItem("vot-yandex-oauth-state") ?? void 0;
      if (!(!e.state || !i || e.state !== i)) {
        try {
          const s = await pf(e.code);
          await yf(s), this.data.account = {
            ...this.data.account ?? {},
            token: s.access_token,
            expires: Date.now() + s.expires_in * 1e3
          }, C.log("[VOT] OAuth login success");
        } catch (s) {
          console.error("[VOT] OAuth token exchange failed:", s);
          return;
        }
        if (this.isInitialized())
          try {
            this.updateAccountInfo();
          } catch (s) {
            console.warn("[VOT] Failed to update account UI:", s);
          }
      }
    }));
  }
  createAccordionSection(t, e = {}) {
    const i = L.createEl("vot-block", ["vot-settings-section"]), s = new Dw({ titleHtml: t });
    s.container.classList.add("vot-settings-section-header");
    const o = typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`, r = `vot-settings-section-header-${o}`, a = `vot-settings-section-content-${o}`;
    s.container.id = r;
    const l = L.createEl("vot-block", ["vot-settings-section-content"]);
    l.id = a, l.setAttribute("role", "region"), l.setAttribute("aria-labelledby", r), s.container.setAttribute("aria-controls", a);
    const c = (h) => {
      s.container.dataset.open = h ? "true" : "false", s.container.setAttribute("aria-expanded", h ? "true" : "false"), l.hidden = !h;
    }, d = () => s.container.dataset.open === "true";
    return c(!!e.open), s.addEventListener("click", () => {
      const h = s.container.dataset.open === "true";
      c(!h);
    }), i.append(s.container, l), {
      title: t,
      container: i,
      header: s.container,
      content: l,
      setOpen: c,
      getOpen: d
    };
  }
  setSubtitlesSmartLayout(t) {
    this.data.subtitlesSmartLayout = t, I.set("subtitlesSmartLayout", t), this.subtitlesSmartLayoutCheckbox?.checked !== t && (this.suppressSubtitlesSmartLayoutCheckboxChange = !0, this.subtitlesSmartLayoutCheckbox.checked = t, this.suppressSubtitlesSmartLayoutCheckboxChange = !1), this.events["change:subtitlesSmartLayout"].dispatch(t);
  }
  scheduleStoragePersist(t, e) {
    const i = this.persistTimerIds[t];
    i !== void 0 && globalThis.clearTimeout(i), this.persistTimerIds[t] = globalThis.setTimeout(() => {
      this.persistTimerIds[t] = void 0, I.set(t, e);
    }, Ii.PERSIST_DELAY_MS);
  }
  flushStoragePersists() {
    for (const t of Object.keys(this.persistTimerIds)) {
      const e = this.persistTimerIds[t];
      if (e === void 0) continue;
      globalThis.clearTimeout(e), this.persistTimerIds[t] = void 0;
      const i = this.data[t];
      typeof i == "number" && I.set(t, i);
    }
  }
  bindPersistedSetting({
    control: t,
    event: e,
    apply: i,
    storageKey: s,
    readPersistedValue: o,
    logLabel: r,
    dispatch: a,
    afterPersist: l
  }) {
    t.addEventListener(e, async (c) => {
      i(c), await I.set(s, o()), l && await l(c), a?.(c);
    });
  }
  initUI() {
    if (this.isInitialized())
      throw new Error("[VOT] SettingsView is already initialized");
    this.dialog = new Fs({
      titleHtml: p.get("VOTSettings")
    }), this.globalPortal.appendChild(this.dialog.container);
    const t = this.createAccordionSection(
      p.get("VOTMyAccount"),
      { open: !0 }
    ), e = this.createAccordionSection(
      p.get("translationSettings"),
      { open: !0 }
    ), i = this.createAccordionSection(
      p.get("subtitlesSettings")
    ), s = this.createAccordionSection(
      p.get("hotkeysSettings")
    ), o = this.createAccordionSection(
      p.get("proxySettings")
    ), r = this.createAccordionSection(
      p.get("miscSettings")
    ), a = this.createAccordionSection(
      p.get("appearance")
    ), l = this.createAccordionSection(
      p.get("aboutExtension")
    ), c = [
      t,
      e,
      i,
      s,
      o,
      r,
      a,
      l
    ];
    this.dialog.bodyContainer.append(
      ...c.map((U) => U.container)
    ), this.accountButton = new Ow({
      avatarId: this.data.account?.avatarId,
      username: this.data.account?.username,
      loggedIn: !!this.data.account?.token
    }), I.isSupportOnlyLS ? (this.accountButton.refreshButton.setAttribute("disabled", "true"), this.accountButton.actionButton.setAttribute("disabled", "true")) : this.accountButtonRefreshTooltip = new mt({
      target: this.accountButton.refreshButton,
      content: p.get("VOTRefresh"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal
    }), this.accountButtonTokenTooltip = new mt({
      target: this.accountButton.tokenButton,
      content: p.get("VOTLoginViaToken"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal
    }), this.autoTranslateCheckbox = new st({
      labelHtml: p.get("VOTAutoTranslate"),
      checked: this.data.autoTranslate
    }), this.autoSubtitlesCheckbox = new st({
      labelHtml: p.get("VOTAutoSubtitles"),
      checked: this.data.autoSubtitles
    });
    const d = this.data.dontTranslateLanguages ?? [];
    this.dontTranslateLanguagesCheckbox = new st({
      labelHtml: p.get("DontTranslateSelectedLanguages"),
      checked: this.data.enabledDontTranslateLanguages
    }), this.dontTranslateLanguagesSelect = new ht({
      dialogParent: this.globalPortal,
      dialogTitle: p.get("DontTranslateSelectedLanguages"),
      selectTitle: d.map((U) => p.get(`langs.${U}`)).join(", ") || p.get("DontTranslateSelectedLanguages"),
      items: ht.genLanguageItems(Bt).map((U) => ({
        ...U,
        selected: d.includes(U.value)
      })),
      multiSelect: !0,
      labelElement: this.dontTranslateLanguagesCheckbox.container
    }), this.dontTranslateLanguagesSelect.disabled = !this.dontTranslateLanguagesCheckbox.checked;
    const h = this.data.autoVolume ?? Mi;
    this.autoSetVolumeSliderLabel = new ae({
      labelText: p.get("VOTAutoSetVolume"),
      value: h
    }), this.autoSetVolumeCheckbox = new st({
      labelHtml: this.autoSetVolumeSliderLabel.container,
      checked: this.data.enabledAutoVolume ?? !0
    }), this.autoSetVolumeSlider = new re({
      labelHtml: this.autoSetVolumeCheckbox.container,
      value: h,
      min: 0
    });
    const f = !!this.data.syncVolume;
    this.autoSetVolumeSlider.disabled = !this.autoSetVolumeCheckbox.checked, this.smartDuckingCheckbox = new st({
      labelHtml: p.get("smartDucking"),
      checked: this.data.enabledSmartDucking ?? !0
    }), this.smartDuckingCheckbox.disabled = f || !this.autoSetVolumeCheckbox.checked, this.showVideoVolumeSliderCheckbox = new st({
      labelHtml: p.get("showVideoVolumeSlider"),
      checked: this.data.showVideoSlider
    }), this.audioBoosterCheckbox = new st({
      labelHtml: p.get("VOTAudioBooster"),
      checked: this.data.audioBooster
    }), this.videoHandler?.isAudioContextSupported || (this.audioBoosterCheckbox.disabled = !0, this.audioBoosterTooltip = new mt({
      target: this.audioBoosterCheckbox.container,
      content: p.get("VOTNeedWebAudioAPI"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal
    })), this.syncVolumeCheckbox = new st({
      labelHtml: p.get("VOTSyncVolume"),
      checked: this.data.syncVolume
    }), this.downloadWithNameCheckbox = new st({
      labelHtml: p.get("VOTDownloadWithName"),
      checked: this.data.downloadWithName
    }), this.downloadWithNameCheckbox.disabled = !Ln, this.sendNotifyOnCompleteCheckbox = new st({
      labelHtml: p.get("VOTSendNotifyOnComplete"),
      checked: this.data.sendNotifyOnComplete
    }), this.useLivelyVoiceCheckbox = new st({
      labelHtml: p.get("VOTUseLivelyVoice"),
      checked: this.data.useLivelyVoice
    }), this.useLivelyVoiceTooltip = new mt({
      target: this.useLivelyVoiceCheckbox.container,
      content: p.get("VOTAccountRequired"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal,
      hidden: !!this.data.account?.token
    }), this.data.account?.token || (this.useLivelyVoiceCheckbox.disabled = !0), this.useAudioDownloadCheckboxLabel = new $t({
      labelText: p.get("VOTUseAudioDownload"),
      icon: Ya
    }), this.useAudioDownloadCheckbox = new st({
      labelHtml: this.useAudioDownloadCheckboxLabel.container,
      checked: this.data.useAudioDownload
    }), Ln || (this.useAudioDownloadCheckbox.disabled = !0), this.useAudioDownloadCheckboxTooltip = new mt({
      target: this.useAudioDownloadCheckboxLabel.container,
      content: p.get("VOTUseAudioDownloadWarning"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal
    }), t.content.append(this.accountButton.container), e.content.append(
      this.autoTranslateCheckbox.container,
      this.autoSubtitlesCheckbox.container,
      this.dontTranslateLanguagesSelect.container,
      this.autoSetVolumeSlider.container,
      this.smartDuckingCheckbox.container,
      this.showVideoVolumeSliderCheckbox.container,
      this.audioBoosterCheckbox.container,
      this.syncVolumeCheckbox.container,
      this.downloadWithNameCheckbox.container,
      this.sendNotifyOnCompleteCheckbox.container,
      this.useLivelyVoiceCheckbox.container,
      this.useAudioDownloadCheckbox.container
    ), this.subtitlesDownloadFormatSelectLabel = new $t({
      labelText: p.get("VOTSubtitlesDownloadFormat")
    }), this.subtitlesDownloadFormatSelect = new ht({
      selectTitle: this.data.subtitlesDownloadFormat ?? p.get("VOTSubtitlesDownloadFormat"),
      dialogTitle: p.get("VOTSubtitlesDownloadFormat"),
      dialogParent: this.globalPortal,
      labelElement: this.subtitlesDownloadFormatSelectLabel.container,
      items: Ub.map((U) => ({
        label: U.toUpperCase(),
        value: U,
        selected: U === this.data.subtitlesDownloadFormat
      }))
    }), this.subtitlesHighlightWordsCheckbox = new st({
      labelHtml: p.get("VOTHighlightWords"),
      checked: this.data.highlightWords
    });
    const g = this.data.subtitlesSmartLayout ?? !0;
    this.subtitlesSmartLayoutCheckbox = new st({
      labelHtml: p.get("subtitlesSmartLayout"),
      checked: g
    });
    const m = this.data.subtitlesMaxLength ?? 300;
    this.subtitlesMaxLengthSliderLabel = new ae({
      labelText: p.get("VOTSubtitlesMaxLength"),
      labelEOL: ":",
      value: m,
      symbol: ""
    }), this.subtitlesMaxLengthSlider = new re({
      labelHtml: this.subtitlesMaxLengthSliderLabel.container,
      value: m,
      min: 50,
      max: 300
    });
    const v = this.data.subtitlesFontSize ?? 20;
    this.subtitlesFontSizeSliderLabel = new ae({
      labelText: p.get("VOTSubtitlesFontSize"),
      labelEOL: ":",
      value: v,
      symbol: "px"
    }), this.subtitlesFontSizeSlider = new re({
      labelHtml: this.subtitlesFontSizeSliderLabel.container,
      value: v,
      min: 8,
      max: 50
    });
    const S = typeof this.data.subtitlesFontFamily == "string" ? this.data.subtitlesFontFamily : void 0, T = S && (vi(S) || $e(S)) ? S : "default-sans", w = (U, At = []) => {
      const Ft = _u.map(
        (it) => ({
          label: qu[it],
          value: it,
          selected: it === U
        })
      ), It = At.filter((it) => {
        const Pt = it.toLowerCase();
        return !Ft.some(
          (ee) => ee.label.toLowerCase() === Pt
        );
      }).map((it) => {
        const Pt = zb(it);
        return {
          label: it,
          value: Pt,
          selected: Pt === U
        };
      });
      if (!vi(U) && !It.some((it) => it.value === U)) {
        const it = $e(U);
        it && It.unshift({
          label: it,
          value: U,
          selected: !0
        });
      }
      return [...Ft, ...It];
    };
    this.subtitlesFontFamilySelectLabel = new $t({
      labelText: p.get("VOTSubtitlesFont")
    }), this.subtitlesFontFamilySelect = new ht({
      selectTitle: Qa(T),
      dialogTitle: p.get("VOTSubtitlesFont"),
      dialogParent: this.globalPortal,
      labelElement: this.subtitlesFontFamilySelectLabel.container,
      items: w(T),
      searchItemsProvider: async (U) => {
        const At = Array.from(this.subtitlesFontFamilySelect?.selectedValues ?? [])[0] ?? T, Ft = U.trim().toLowerCase();
        if (!Ft)
          return w(At);
        const it = (await Yb()).filter(
          (Pt) => Pt.toLowerCase().includes(Ft)
        ).slice(0, Fw);
        return w(At, it);
      }
    }), this.subtitlesFontFamilySelect.addEventListener("selectItem", (U) => {
      this.subtitlesFontFamilySelect && (this.subtitlesFontFamilySelect.updateItems(w(U)), this.subtitlesFontFamilySelect.selectTitle = Qa(U));
    });
    const A = this.data.subtitlesOpacity ?? 20;
    this.subtitlesBackgroundOpacitySliderLabel = new ae({
      labelText: p.get("VOTSubtitlesOpacity"),
      labelEOL: ":",
      value: A,
      symbol: "%"
    }), this.subtitlesBackgroundOpacitySlider = new re({
      labelHtml: this.subtitlesBackgroundOpacitySliderLabel.container,
      value: A,
      min: 0,
      max: 100
    }), i.content.append(
      this.subtitlesDownloadFormatSelect.container,
      this.subtitlesFontFamilySelect.container,
      this.subtitlesHighlightWordsCheckbox.container,
      this.subtitlesSmartLayoutCheckbox.container,
      this.subtitlesMaxLengthSlider.container,
      this.subtitlesFontSizeSlider.container,
      this.subtitlesBackgroundOpacitySlider.container
    ), this.translateHotkeyButton = new Za({
      labelHtml: p.get("translateVideo"),
      key: this.data.translationHotkey
    }), this.subtitlesHotkeyButton = new Za({
      labelHtml: p.get("VOTSubtitles"),
      key: this.data.subtitlesHotkey
    }), s.content.append(
      this.translateHotkeyButton.container,
      this.subtitlesHotkeyButton.container
    ), this.proxyWorkerHostTextfield = new Ns({
      labelHtml: p.get("VOTProxyWorkerHost"),
      value: this.data.proxyWorkerHost,
      placeholder: Sn
    });
    const P = [
      p.get("VOTTranslateProxyDisabled"),
      p.get("VOTTranslateProxyEnabled"),
      p.get("VOTTranslateProxyEverything")
    ], _ = this.data.translateProxyEnabled ?? 0, O = We && eu.includes(We);
    this.proxyTranslationStatusSelectLabel = new $t({
      icon: O ? Ya : void 0,
      labelText: p.get("VOTTranslateProxyStatus")
    }), O && (this.proxyTranslationStatusSelectTooltip = new mt({
      target: this.proxyTranslationStatusSelectLabel.icon,
      content: p.get("VOTTranslateProxyStatusDefault"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal
    })), this.proxyTranslationStatusSelect = new ht({
      selectTitle: P[_],
      dialogTitle: p.get("VOTTranslateProxyStatus"),
      dialogParent: this.globalPortal,
      labelElement: this.proxyTranslationStatusSelectLabel.container,
      items: P.map((U, At) => ({
        label: U,
        value: At.toString(),
        selected: At === _,
        disabled: At === 0 && au
      }))
    }), o.content.append(
      this.proxyWorkerHostTextfield.container,
      this.proxyTranslationStatusSelect.container
    ), this.translateAPIErrorsCheckbox = new st({
      labelHtml: p.get("VOTTranslateAPIErrors"),
      checked: this.data.translateAPIErrors ?? !0
    }), this.translateAPIErrorsCheckbox.hidden = p.lang === "ru", this.useNewAudioPlayerCheckbox = new st({
      labelHtml: p.get("VOTNewAudioPlayer"),
      checked: this.data.newAudioPlayer
    }), this.videoHandler?.isAudioContextSupported || (this.useNewAudioPlayerCheckbox.disabled = !0, this.useNewAudioPlayerTooltip = new mt({
      target: this.useNewAudioPlayerCheckbox.container,
      content: p.get("VOTNeedWebAudioAPI"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal
    }));
    const Q = this.videoHandler?.site.needBypassCSP ? `${p.get("VOTOnlyBypassMediaCSP")} (${p.get("VOTMediaCSPEnabledOnSite")})` : p.get("VOTOnlyBypassMediaCSP");
    this.onlyBypassMediaCSPCheckbox = new st({
      labelHtml: Q,
      checked: this.data.onlyBypassMediaCSP,
      isSubCheckbox: !0
    }), this.videoHandler?.isAudioContextSupported || (this.onlyBypassMediaCSPTooltip = new mt({
      target: this.onlyBypassMediaCSPCheckbox.container,
      content: p.get("VOTNeedWebAudioAPI"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal
    })), this.onlyBypassMediaCSPCheckbox.disabled = !this.data.newAudioPlayer && !!this.videoHandler?.isAudioContextSupported, this.data.newAudioPlayer || (this.onlyBypassMediaCSPCheckbox.hidden = !0), this.translationTextServiceLabel = new $t({
      labelText: p.get("VOTTranslationTextService"),
      icon: ja
    });
    const Y = this.data.translationService ?? Oi;
    this.translationTextServiceSelect = new ht({
      selectTitle: p.get(`services.${Y}`),
      dialogTitle: p.get("VOTTranslationTextService"),
      dialogParent: this.globalPortal,
      labelElement: this.translationTextServiceLabel.container,
      items: Vu.map((U) => ({
        label: p.get(`services.${U}`),
        value: U,
        selected: U === Y
      }))
    }), this.translationTextServiceTooltip = new mt({
      target: this.translationTextServiceLabel.icon,
      content: p.get("VOTNotAffectToVoice"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal
    }), this.detectServiceLabel = new $t({
      labelText: p.get("VOTDetectService")
    });
    const at = this.data.detectService ?? oo;
    this.detectServiceSelect = new ht({
      selectTitle: p.get(`services.${at}`),
      dialogTitle: p.get("VOTDetectService"),
      dialogParent: this.globalPortal,
      labelElement: this.detectServiceLabel.container,
      items: eb.map((U) => ({
        label: p.get(`services.${U}`),
        value: U,
        selected: U === at
      }))
    }), this.showPiPButtonCheckbox = new st({
      labelHtml: p.get("VOTShowPiPButton"),
      checked: this.data.showPiPButton
    }), this.showPiPButtonCheckbox.hidden = !nu();
    const k = Math.round(
      (this.data.autoHideButtonDelay ?? ro) / 1e3 * 10
    ) / 10;
    this.autoHideButtonDelaySliderLabel = new ae({
      labelText: p.get("autoHideButtonDelay"),
      labelEOL: ":",
      value: k,
      symbol: ` ${p.get("secs")}`
    }), this.autoHideButtonDelaySlider = new re({
      labelHtml: this.autoHideButtonDelaySliderLabel.container,
      value: k,
      min: 0.1,
      max: 3,
      step: 0.1
    }), this.buttonPositionSelectLabel = new $t({
      labelText: p.get("buttonPosition"),
      icon: ja
    });
    const V = this.data.buttonPos ?? "default";
    this.buttonPositionSelect = new ht({
      selectTitle: p.get(`position.${V}`),
      dialogTitle: p.get("buttonPosition"),
      labelElement: this.buttonPositionSelectLabel.container,
      dialogParent: this.globalPortal,
      items: xw.map((U) => ({
        label: p.get(`position.${U}`),
        value: U,
        selected: U === V
      }))
    }), this.buttonPositionTooltip = new mt({
      target: this.buttonPositionSelectLabel.icon,
      content: p.get("minButtonPositionContainer"),
      position: "bottom",
      backgroundColor: "var(--vot-helper-ondialog)",
      parentElement: this.globalPortal
    }), this.menuLanguageSelectLabel = new $t({
      labelText: p.get("VOTMenuLanguage")
    }), this.menuLanguageSelect = new ht({
      selectTitle: p.get(
        `langs.${p.langOverride}`
      ),
      dialogTitle: p.get("VOTMenuLanguage"),
      labelElement: this.menuLanguageSelectLabel.container,
      dialogParent: this.globalPortal,
      items: ht.genLanguageItems(
        p.getAvailableLangs(),
        p.langOverride
      )
    }), this.bugReportButton = L.createOutlinedButton(
      p.get("VOTBugReport")
    ), this.resetSettingsButton = L.createButton(
      p.get("resetSettings")
    ), r.content.append(
      this.translateAPIErrorsCheckbox.container,
      this.useNewAudioPlayerCheckbox.container,
      this.onlyBypassMediaCSPCheckbox.container
    ), e.content.append(
      this.translationTextServiceSelect.container,
      this.detectServiceSelect.container
    ), a.content.append(
      this.showPiPButtonCheckbox.container,
      this.autoHideButtonDelaySlider.container,
      this.buttonPositionSelect.container,
      this.menuLanguageSelect.container
    );
    const E = zu(), F = L.createInformation(
      `${p.get("VOTVersion")}:`,
      E.scriptVersion || GM_info.script.version || p.get("notFound")
    ), G = L.createInformation(
      `${p.get("VOTAuthors")}:`,
      GM_info.script.author || "Toil, SashaXser, MrSoczekXD, mynovelhost, sodapng, Acobat12" || p.get("notFound")
    ), nt = L.createInformation(
      `${p.get("VOTLoader")}:`,
      E.loader
    ), j = L.createInformation(
      `${p.get("VOTBrowser")}:`,
      `${E.browser} (${E.os})`
    ), Lt = new Date(
      (this.data.localeUpdatedAt ?? 0) * 1e3
    ).toLocaleString(), xt = this.data.localeHash ?? p.get("notFound"), Se = ln`${xt}<br />(${p.get(
      "VOTUpdatedAt"
    )} ${Lt})`, qe = L.createInformation(
      `${p.get("VOTLocaleHash")}:`,
      Se
    ), Wt = L.createOutlinedButton(
      p.get("VOTUpdateLocaleFiles")
    );
    return Wt.addEventListener("click", async () => {
      await I.set("localeHash", ""), await p.update(!0), globalThis.location.reload();
    }), l.content.append(
      F.container,
      G.container,
      nt.container,
      j.container,
      qe.container,
      Wt
    ), this.dialog.footerContainer.append(
      this.bugReportButton,
      this.resetSettingsButton
    ), this.initialized = !0, this;
  }
  initUIEvents() {
    if (!this.isInitialized())
      throw new Error("[VOT] SettingsView isn't initialized");
    return this.bindOAuthMessageListener(), this.accountButton.addEventListener("click", async () => {
      if (I.isSupportOnlyLS) return;
      if (this.accountButton.loggedIn)
        return await I.delete("account"), this.data.account = {}, this.updateAccountInfo();
      const t = await gf();
      globalThis.open(
        t,
        "yandex-oauth",
        "popup=yes,width=520,height=720,resizable=yes,scrollbars=yes"
      )?.focus();
    }), this.accountButton.addEventListener("click:secret", async () => {
      const t = new Fs({
        titleHtml: p.get("VOTLoginViaToken"),
        isTemp: !0
      });
      this.globalPortal.appendChild(t.container);
      const e = L.createEl(
        "vot-block",
        void 0,
        p.get("VOTYandexTokenInfo")
      ), i = new Ns({
        labelHtml: p.get("VOTYandexToken"),
        value: this.data.account?.token
      });
      i.addEventListener("change", async (s) => {
        this.data.account = s ? { expires: Date.now() + 3153418e4, token: s } : {}, await I.set("account", this.data.account), this.updateAccountInfo();
      }), t.bodyContainer.append(e, i.container), t.open();
    }), this.accountButton.addEventListener("refresh", async () => {
      I.isSupportOnlyLS || (this.data.account = await I.get("account", {}), this.updateAccountInfo());
    }), this.bindPersistedSetting({
      control: this.autoTranslateCheckbox,
      event: "change",
      apply: (t) => {
        this.data.autoTranslate = t;
      },
      storageKey: "autoTranslate",
      readPersistedValue: () => this.data.autoTranslate,
      logLabel: "autoTranslate",
      dispatch: (t) => this.events["change:autoTranslate"].dispatch(t)
    }), this.bindPersistedSetting({
      control: this.autoSubtitlesCheckbox,
      event: "change",
      apply: (t) => {
        this.data.autoSubtitles = t;
      },
      storageKey: "autoSubtitles",
      readPersistedValue: () => this.data.autoSubtitles,
      logLabel: "autoSubtitles",
      dispatch: (t) => this.events["change:autoSubtitles"].dispatch(t)
    }), this.dontTranslateLanguagesCheckbox.addEventListener(
      "change",
      async (t) => {
        this.data.enabledDontTranslateLanguages = t, this.dontTranslateLanguagesSelect.disabled = !t, await I.set(
          "enabledDontTranslateLanguages",
          this.data.enabledDontTranslateLanguages
        );
      }
    ), this.dontTranslateLanguagesSelect.addEventListener(
      "selectItem",
      async (t) => {
        this.data.dontTranslateLanguages = t, await I.set(
          "dontTranslateLanguages",
          this.data.dontTranslateLanguages
        );
      }
    ), this.bindPersistedSetting({
      control: this.autoSetVolumeCheckbox,
      event: "change",
      apply: (t) => {
        this.data.enabledAutoVolume = t, this.autoSetVolumeSlider.disabled = !t, this.smartDuckingCheckbox.disabled = !t || !!this.syncVolumeCheckbox?.checked;
      },
      storageKey: "enabledAutoVolume",
      readPersistedValue: () => this.data.enabledAutoVolume,
      logLabel: "enabledAutoVolume",
      afterPersist: async () => this.videoHandler?.setupAudioSettings?.()
    }), this.bindPersistedSetting({
      control: this.smartDuckingCheckbox,
      event: "change",
      apply: (t) => {
        this.data.enabledSmartDucking = t;
      },
      storageKey: "enabledSmartDucking",
      readPersistedValue: () => this.data.enabledSmartDucking,
      logLabel: "enabledSmartDucking",
      afterPersist: async () => this.videoHandler?.setupAudioSettings?.()
    }), this.bindPersistedSetting({
      control: this.autoSetVolumeSlider,
      event: "input",
      apply: (t) => {
        this.data.autoVolume = this.autoSetVolumeSliderLabel.value = t;
      },
      storageKey: "autoVolume",
      readPersistedValue: () => this.data.autoVolume,
      logLabel: "autoVolume"
    }), this.bindPersistedSetting({
      control: this.showVideoVolumeSliderCheckbox,
      event: "change",
      apply: (t) => {
        this.data.showVideoSlider = t;
      },
      storageKey: "showVideoSlider",
      readPersistedValue: () => this.data.showVideoSlider,
      logLabel: "showVideoVolumeSlider",
      dispatch: (t) => this.events["change:showVideoVolume"].dispatch(t)
    }), this.bindPersistedSetting({
      control: this.audioBoosterCheckbox,
      event: "change",
      apply: (t) => {
        this.data.audioBooster = t;
      },
      storageKey: "audioBooster",
      readPersistedValue: () => this.data.audioBooster,
      logLabel: "audioBooster",
      dispatch: (t) => this.events["change:audioBooster"].dispatch(t)
    }), this.bindPersistedSetting({
      control: this.syncVolumeCheckbox,
      event: "change",
      apply: (t) => {
        this.data.syncVolume = t, this.autoSetVolumeSlider.disabled = !this.autoSetVolumeCheckbox?.checked, this.smartDuckingCheckbox.disabled = t || !this.autoSetVolumeCheckbox?.checked, t && this.smartDuckingCheckbox?.checked && (this.smartDuckingCheckbox.checked = !1);
      },
      storageKey: "syncVolume",
      readPersistedValue: () => this.data.syncVolume,
      logLabel: "syncVolume",
      dispatch: (t) => this.events["change:syncVolume"].dispatch(t)
    }), this.bindPersistedSetting({
      control: this.downloadWithNameCheckbox,
      event: "change",
      apply: (t) => {
        this.data.downloadWithName = t;
      },
      storageKey: "downloadWithName",
      readPersistedValue: () => this.data.downloadWithName,
      logLabel: "downloadWithName"
    }), this.bindPersistedSetting({
      control: this.sendNotifyOnCompleteCheckbox,
      event: "change",
      apply: (t) => {
        this.data.sendNotifyOnComplete = t;
      },
      storageKey: "sendNotifyOnComplete",
      readPersistedValue: () => this.data.sendNotifyOnComplete,
      logLabel: "sendNotifyOnComplete"
    }), this.bindPersistedSetting({
      control: this.useLivelyVoiceCheckbox,
      event: "change",
      apply: (t) => {
        this.data.useLivelyVoice = t;
      },
      storageKey: "useLivelyVoice",
      readPersistedValue: () => this.data.useLivelyVoice,
      logLabel: "useLivelyVoice",
      dispatch: (t) => this.events["change:useLivelyVoice"].dispatch(t)
    }), this.bindPersistedSetting({
      control: this.useAudioDownloadCheckbox,
      event: "change",
      apply: (t) => {
        this.data.useAudioDownload = t;
      },
      storageKey: "useAudioDownload",
      readPersistedValue: () => this.data.useAudioDownload,
      logLabel: "useAudioDownload"
    }), this.bindPersistedSetting({
      control: this.subtitlesDownloadFormatSelect,
      event: "selectItem",
      apply: (t) => {
        this.data.subtitlesDownloadFormat = t;
      },
      storageKey: "subtitlesDownloadFormat",
      readPersistedValue: () => this.data.subtitlesDownloadFormat,
      logLabel: "subtitlesDownloadFormat"
    }), this.bindPersistedSetting({
      control: this.subtitlesHighlightWordsCheckbox,
      event: "change",
      apply: (t) => {
        this.data.highlightWords = t;
      },
      storageKey: "highlightWords",
      readPersistedValue: () => this.data.highlightWords,
      logLabel: "highlightWords",
      dispatch: (t) => this.events["change:subtitlesHighlightWords"].dispatch(t)
    }), this.subtitlesSmartLayoutCheckbox?.addEventListener("change", (t) => {
      this.suppressSubtitlesSmartLayoutCheckboxChange || this.setSubtitlesSmartLayout(t);
    }), this.subtitlesMaxLengthSlider.addEventListener("input", (t) => {
      this.subtitlesMaxLengthSliderLabel.value = t, (this.data.subtitlesSmartLayout ?? !0) === !0 && this.setSubtitlesSmartLayout(!1), this.data.subtitlesMaxLength = t, this.scheduleStoragePersist(
        "subtitlesMaxLength",
        this.data.subtitlesMaxLength
      ), this.events["input:subtitlesMaxLength"].dispatch(t);
    }), this.subtitlesFontSizeSlider.addEventListener("input", (t) => {
      this.subtitlesFontSizeSliderLabel.value = t, (this.data.subtitlesSmartLayout ?? !0) === !0 && this.setSubtitlesSmartLayout(!1), this.data.subtitlesFontSize = t, this.scheduleStoragePersist(
        "subtitlesFontSize",
        this.data.subtitlesFontSize
      ), this.events["input:subtitlesFontSize"].dispatch(t);
    }), this.subtitlesBackgroundOpacitySlider.addEventListener("input", (t) => {
      this.subtitlesBackgroundOpacitySliderLabel.value = t, this.data.subtitlesOpacity = t, this.scheduleStoragePersist(
        "subtitlesOpacity",
        this.data.subtitlesOpacity
      ), this.events["input:subtitlesBackgroundOpacity"].dispatch(t);
    }), this.bindPersistedSetting({
      control: this.subtitlesFontFamilySelect,
      event: "selectItem",
      apply: (t) => {
        this.data.subtitlesFontFamily = t;
      },
      storageKey: "subtitlesFontFamily",
      readPersistedValue: () => this.data.subtitlesFontFamily,
      logLabel: "subtitlesFontFamily",
      dispatch: (t) => this.events["select:subtitlesFontFamily"].dispatch(t)
    }), this.bindPersistedSetting({
      control: this.translateHotkeyButton,
      event: "change",
      apply: (t) => {
        this.data.translationHotkey = t;
      },
      storageKey: "translationHotkey",
      readPersistedValue: () => this.data.translationHotkey,
      logLabel: "translationHotkey"
    }), this.bindPersistedSetting({
      control: this.subtitlesHotkeyButton,
      event: "change",
      apply: (t) => {
        this.data.subtitlesHotkey = t;
      },
      storageKey: "subtitlesHotkey",
      readPersistedValue: () => this.data.subtitlesHotkey,
      logLabel: "subtitlesHotkey"
    }), this.proxyWorkerHostTextfield.addEventListener("change", async (t) => {
      this.data.proxyWorkerHost = t || Sn, await I.set("proxyWorkerHost", this.data.proxyWorkerHost), C.log(
        "proxyWorkerHost value changed. New value:",
        this.data.proxyWorkerHost
      ), this.events["change:proxyWorkerHost"].dispatch(t);
    }), this.proxyTranslationStatusSelect.addEventListener(
      "selectItem",
      async (t) => {
        this.data.translateProxyEnabled = Number.parseInt(
          t,
          10
        ), await I.set(
          "translateProxyEnabled",
          this.data.translateProxyEnabled
        ), await I.set("translateProxyEnabledDefault", !1), C.log(
          "translateProxyEnabled value changed. New value:",
          this.data.translateProxyEnabled
        ), this.events["select:proxyTranslationStatus"].dispatch(t);
      }
    ), this.bindPersistedSetting({
      control: this.translateAPIErrorsCheckbox,
      event: "change",
      apply: (t) => {
        this.data.translateAPIErrors = t;
      },
      storageKey: "translateAPIErrors",
      readPersistedValue: () => this.data.translateAPIErrors,
      logLabel: "translateAPIErrors"
    }), this.bindPersistedSetting({
      control: this.useNewAudioPlayerCheckbox,
      event: "change",
      apply: (t) => {
        this.data.newAudioPlayer = t, this.onlyBypassMediaCSPCheckbox.disabled = this.onlyBypassMediaCSPCheckbox.hidden = !t;
      },
      storageKey: "newAudioPlayer",
      readPersistedValue: () => this.data.newAudioPlayer,
      logLabel: "newAudioPlayer",
      dispatch: (t) => this.events["change:useNewAudioPlayer"].dispatch(t)
    }), this.bindPersistedSetting({
      control: this.onlyBypassMediaCSPCheckbox,
      event: "change",
      apply: (t) => {
        this.data.onlyBypassMediaCSP = t;
      },
      storageKey: "onlyBypassMediaCSP",
      readPersistedValue: () => this.data.onlyBypassMediaCSP,
      logLabel: "onlyBypassMediaCSP",
      dispatch: (t) => this.events["change:onlyBypassMediaCSP"].dispatch(t)
    }), this.bindPersistedSetting({
      control: this.translationTextServiceSelect,
      event: "selectItem",
      apply: (t) => {
        this.data.translationService = t;
      },
      storageKey: "translationService",
      readPersistedValue: () => this.data.translationService,
      logLabel: "translationService",
      dispatch: (t) => this.events["select:translationTextService"].dispatch(t)
    }), this.bindPersistedSetting({
      control: this.detectServiceSelect,
      event: "selectItem",
      apply: (t) => {
        this.data.detectService = t;
      },
      storageKey: "detectService",
      readPersistedValue: () => this.data.detectService,
      logLabel: "detectService"
    }), this.bindPersistedSetting({
      control: this.showPiPButtonCheckbox,
      event: "change",
      apply: (t) => {
        this.data.showPiPButton = t;
      },
      storageKey: "showPiPButton",
      readPersistedValue: () => this.data.showPiPButton,
      logLabel: "showPiPButton",
      dispatch: (t) => this.events["change:showPiPButton"].dispatch(t)
    }), this.autoHideButtonDelaySlider.addEventListener("input", (t) => {
      this.autoHideButtonDelaySliderLabel.value = t;
      const e = Math.round(t * 1e3);
      this.data.autoHideButtonDelay = e, this.scheduleStoragePersist(
        "autoHideButtonDelay",
        this.data.autoHideButtonDelay
      ), this.events["input:autoHideButtonDelay"].dispatch(t);
    }), this.bindPersistedSetting({
      control: this.buttonPositionSelect,
      event: "selectItem",
      apply: (t) => {
        this.data.buttonPos = t;
      },
      storageKey: "buttonPos",
      readPersistedValue: () => this.data.buttonPos,
      logLabel: "buttonPos",
      dispatch: (t) => this.events["select:buttonPosition"].dispatch(t)
    }), this.menuLanguageSelect.addEventListener("selectItem", async (t) => {
      await p.changeLang(t) && (this.data.localeUpdatedAt = await I.get("localeUpdatedAt", 0), this.events["select:menuLanguage"].dispatch(t));
    }), this.bugReportButton.addEventListener(
      "click",
      () => this.events["click:bugReport"].dispatch()
    ), this.resetSettingsButton.addEventListener(
      "click",
      () => this.events["click:resetSettings"].dispatch()
    ), this;
  }
  addEventListener(t, e) {
    return this.events[t].addListener(e), this;
  }
  removeEventListener(t, e) {
    return this.events[t].removeListener(e), this;
  }
  doReleaseUI() {
    this.dialog?.remove();
    for (const t of [
      this.accountButtonRefreshTooltip,
      this.accountButtonTokenTooltip,
      this.audioBoosterTooltip,
      this.useLivelyVoiceTooltip,
      this.useAudioDownloadCheckboxTooltip,
      this.useNewAudioPlayerTooltip,
      this.onlyBypassMediaCSPTooltip,
      this.translationTextServiceTooltip,
      this.proxyTranslationStatusSelectTooltip,
      this.buttonPositionTooltip
    ])
      t?.release();
  }
  doReleaseUIEvents() {
    this.flushStoragePersists();
    for (const t of Object.values(this.events)) t.clear();
  }
  release() {
    return this.isInitialized() ? (this.doReleaseUIEvents(), this.doReleaseUI(), this.initialized = !1, this) : this;
  }
  updateAccountInfo() {
    if (!this.isInitialized())
      throw new Error("[VOT] SettingsView isn't initialized");
    const t = !!this.data.account?.token;
    return this.accountButton.avatarId = this.data.account?.avatarId, this.useLivelyVoiceTooltip.hidden = this.accountButton.loggedIn = t, this.accountButton.username = this.data.account?.username, this.useLivelyVoiceCheckbox.disabled = !t, this.events["update:account"].dispatch(this.data.account), this;
  }
  open() {
    if (!this.isInitialized())
      throw new Error("[VOT] SettingsView isn't initialized");
    return this.dialog.open();
  }
  close() {
    if (!this.isInitialized())
      throw new Error("[VOT] SettingsView isn't initialized");
    return this.dialog.close();
  }
};
u(Ii, "PERSIST_DELAY_MS", 250);
let $s = Ii;
class Nw {
  constructor({
    mount: t,
    data: e = {},
    videoHandler: i,
    intervalIdleChecker: s
  }) {
    u(this, "mount");
    u(this, "translationActionInFlight", !1);
    u(this, "overlayEventsBound", !1);
    u(this, "settingsEventsBound", !1);
    u(this, "initialized", !1);
    u(this, "videoHandler");
    u(this, "intervalIdleChecker");
    u(this, "data");
    u(this, "votGlobalPortal");
    /**
     * Contains all elements over video player e.g. button, menu and etc
     */
    u(this, "votOverlayView");
    /**
     * Dialog settings menu
     */
    u(this, "votSettingsView");
    this.mount = t, this.videoHandler = i, this.data = e, this.intervalIdleChecker = s;
  }
  get root() {
    return this.mount.root;
  }
  get portalContainer() {
    return this.mount.portalContainer;
  }
  get tooltipLayoutRoot() {
    return this.mount.tooltipLayoutRoot;
  }
  getSubtitlesMountContainer() {
    return this.mount.subtitlesMountContainer;
  }
  isInitialized() {
    return this.initialized;
  }
  initUI() {
    if (this.isInitialized())
      throw new Error("[VOT] UIManager is already initialized");
    return this.initialized = !0, this.votGlobalPortal = L.createPortal(), this.getGlobalPortalHost(this.mount).appendChild(this.votGlobalPortal), this.votOverlayView = new Us({
      mount: this.mount,
      globalPortal: this.votGlobalPortal,
      data: this.data,
      videoHandler: this.videoHandler,
      intervalIdleChecker: this.intervalIdleChecker
    }), this.votOverlayView.initUI(this.data.buttonPos ?? "default"), this.votSettingsView = new $s({
      globalPortal: this.votGlobalPortal,
      data: this.data,
      videoHandler: this.videoHandler
    }), this.votSettingsView.initUI(), this.videoHandler?.subtitlesWidget?.updateMount({
      container: this.getSubtitlesMountContainer(),
      tooltipLayoutRoot: this.mount.tooltipLayoutRoot
    }), this;
  }
  updateMount(t) {
    const e = this.getGlobalPortalHost(t);
    return this.votGlobalPortal?.parentElement !== e && e.appendChild(this.votGlobalPortal), this.mount = uw(this.mount, t, (i) => {
      this.votOverlayView?.updateMount(i);
    }), this.videoHandler?.subtitlesWidget?.updateMount({
      container: this.getSubtitlesMountContainer(),
      tooltipLayoutRoot: t.tooltipLayoutRoot
    }), this;
  }
  getGlobalPortalHost(t) {
    const e = document, i = e.fullscreenElement ?? e.webkitFullscreenElement;
    return !!co(i, [t.root], {
      allowDocumentViewport: !0
    }) ? t.root : document.documentElement;
  }
  initUIEvents() {
    if (!this.isInitialized())
      throw new Error("[VOT] UIManager isn't initialized");
    this.votOverlayView.initUIEvents(), this.overlayEventsBound || (this.bindOverlayViewEvents(), this.overlayEventsBound = !0), this.votSettingsView.initUIEvents(), this.settingsEventsBound || (this.bindSettingsViewEvents(), this.settingsEventsBound = !0);
  }
  bindOverlayViewEvents() {
    const t = this.votOverlayView;
    t && t.addEventListener("click:translate", async () => {
      await this.handleTranslationBtnClick();
    }).addEventListener("click:pip", async () => {
      if (this.videoHandler)
        try {
          await (this.videoHandler.video === document.pictureInPictureElement ? document.exitPictureInPicture() : this.videoHandler.video.requestPictureInPicture());
        } catch {
        }
    }).addEventListener("click:settings", async () => {
      this.videoHandler?.subtitlesWidget?.releaseTooltip(), this.videoHandler?.overlayVisibility?.cancel(), this.videoHandler?.overlayVisibility?.show(), this.votSettingsView.open();
    }).addEventListener("click:downloadTranslation", async () => {
      await this.handleDownloadTranslationClick();
    }).addEventListener("click:downloadSubtitles", async () => {
      await this.handleDownloadSubtitlesClick();
    }).addEventListener("input:videoVolume", (e) => {
      if (this.videoHandler) {
        if (this.videoHandler.setVideoVolume(e / 100), !this.data.syncVolume) {
          this.videoHandler.onVideoVolumeSliderSynced(e);
          return;
        }
        this.videoHandler.syncVolumeWrapper("video", e);
      }
    }).addEventListener("input:translationVolume", (e) => {
      if (!this.videoHandler)
        return;
      const i = e ?? this.data.defaultVolume ?? 100;
      if (this.videoHandler.syncTranslationPlaybackVolume(), !this.data.syncVolume) {
        this.videoHandler.onTranslationVolumeSliderSynced(i);
        return;
      }
      const s = this.videoHandler.syncVolumeWrapper(
        "translation",
        i
      );
      typeof s?.nextVideo == "number" && this.videoHandler.applyManualVideoVolumeOverride(
        s.nextVideo / 100
      );
    }).addEventListener("select:subtitles", (e) => {
      this.videoHandler && this.runDetached(
        this.videoHandler.changeSubtitlesLang(e),
        "Failed to change subtitles language"
      );
    });
  }
  bindSettingsViewEvents() {
    const t = this.votSettingsView;
    t && t.addEventListener("update:account", async (e) => {
      this.videoHandler && (this.videoHandler.votClient.apiToken = e?.token);
    }).addEventListener("change:autoTranslate", async (e) => {
      const i = this.videoHandler;
      e && i && !i.hasActiveSource() && await this.handleTranslationBtnClick();
    }).addEventListener("change:autoSubtitles", async (e) => {
      !e || !this.videoHandler?.videoData?.videoId || await this.videoHandler.enableSubtitlesForCurrentLangPair();
    }).addEventListener("change:showVideoVolume", () => {
      this.withInitializedOverlayView((e) => {
        !e.videoVolumeSlider || !e.votButton || (e.videoVolumeSlider.container.hidden = !this.data.showVideoSlider || e.votButton.status !== "success");
      });
    }).addEventListener("change:audioBooster", async () => {
      this.withInitializedOverlayView((e) => {
        if (!e.translationVolumeSlider)
          return;
        const i = e.translationVolumeSlider.value, s = this.data.audioBooster ? tu : 100;
        e.translationVolumeSlider.max = s;
        const o = K(i, 0, s);
        e.translationVolumeSlider.value = o, this.videoHandler?.onTranslationVolumeSliderSynced(o), this.videoHandler?.syncTranslationPlaybackVolume();
      });
    }).addEventListener("change:syncVolume", (e) => {
      this.videoHandler && (this.videoHandler.setupAudioSettings(), e && this.withInitializedOverlayView((i) => {
        const s = i.videoVolumeSlider, o = i.translationVolumeSlider;
        !s || !o || (this.videoHandler.syncTranslationPlaybackVolume(), this.videoHandler.resetVolumeLinkState(
          Number(s.value),
          Number(o.value)
        ));
      }));
    }).addEventListener("change:useLivelyVoice", () => {
      !this.videoHandler || this.votOverlayView?.votButton?.loading === !0 || this.videoHandler.hadAsyncWait || this.runDetached(
        this.videoHandler.stopTranslate(),
        "Failed to stop translation after voice mode change"
      );
    }).addEventListener("change:subtitlesHighlightWords", (e) => {
      this.updateSubtitlesWidgetSetting(
        e,
        this.data.highlightWords,
        (i, s) => {
          i.setHighlightWords(s);
        }
      );
    }).addEventListener("change:subtitlesSmartLayout", (e) => {
      this.updateSubtitlesWidgetSetting(
        e,
        this.data.subtitlesSmartLayout,
        (i, s) => {
          i.setSmartLayout(s);
        }
      );
    }).addEventListener("input:subtitlesMaxLength", (e) => {
      this.updateSubtitlesWidgetSetting(
        e,
        this.data.subtitlesMaxLength,
        (i, s) => {
          i.setMaxLength(s);
        }
      );
    }).addEventListener("input:subtitlesFontSize", (e) => {
      this.updateSubtitlesWidgetSetting(
        e,
        this.data.subtitlesFontSize,
        (i, s) => {
          i.setFontSize(s);
        }
      );
    }).addEventListener("select:subtitlesFontFamily", (e) => {
      this.updateSubtitlesWidgetSetting(
        e,
        this.data.subtitlesFontFamily,
        (i, s) => {
          i.setFontFamily(s);
        }
      );
    }).addEventListener("input:subtitlesBackgroundOpacity", (e) => {
      this.updateSubtitlesWidgetSetting(
        e,
        this.data.subtitlesOpacity,
        (i, s) => {
          i.setOpacity(s);
        }
      );
    }).addEventListener("change:proxyWorkerHost", (e) => {
      this.videoHandler && this.runDetached(
        this.videoHandler.handleProxySettingsChanged("proxyWorkerHost"),
        "Failed to apply proxyWorkerHost change"
      );
    }).addEventListener("select:proxyTranslationStatus", () => {
      this.videoHandler && this.runDetached(
        this.videoHandler.handleProxySettingsChanged(
          "proxyTranslationStatus"
        ),
        "Failed to apply proxyTranslationStatus change"
      );
    }).addEventListener("change:useNewAudioPlayer", () => {
      this.restartAudioPlayer();
    }).addEventListener("change:onlyBypassMediaCSP", () => {
      this.restartAudioPlayer();
    }).addEventListener("select:translationTextService", () => {
      this.withSubtitlesWidget((e) => {
        e.resetTranslationContext(!0);
      });
    }).addEventListener("change:showPiPButton", () => {
      this.withInitializedOverlayView((e) => {
        e.votButton && (e.votButton.pipButton.hidden = e.votButton.separator2.hidden = !e.pipButtonVisible);
      });
    }).addEventListener("select:buttonPosition", (e) => {
      this.withInitializedOverlayView((i) => {
        const s = this.data.buttonPos ?? e, { position: o, direction: r } = i.calcButtonLayout(s);
        i.updateButtonLayout(o, r);
      });
    }).addEventListener("select:menuLanguage", async () => {
      await this.reloadMenu();
    }).addEventListener("click:bugReport", () => {
      if (!this.videoHandler)
        return;
      const e = new URLSearchParams(
        this.videoHandler.collectReportInfo()
      ).toString();
      globalThis.open(`${hh}/issues/new?${e}`, "_blank")?.focus();
    }).addEventListener("click:resetSettings", async () => {
      const e = await I.list();
      await Promise.all(e.map((i) => I.delete(i))), await I.set("compatVersion", Tn), globalThis.location.reload();
    });
  }
  async downloadCurrentSubtitles() {
    await this.handleDownloadSubtitlesClick();
  }
  async handleDownloadTranslationClick() {
    const t = this.votOverlayView, e = this.videoHandler;
    if (!t?.isInitialized() || !e?.downloadTranslationUrl || !e.videoData)
      return;
    const i = t.downloadTranslationButton, s = e.downloadTranslationUrl, o = this.data.downloadWithName ? Tr(e.getDownloadBaseName()) : `translation_${e.videoData.videoId}`, a = { preferShare: this.isLikelyMobileDownloadContext() }, l = (c) => {
      i && (i.progress = c);
    };
    l(0);
    try {
      await this.downloadTranslationAudio(
        s,
        o,
        l,
        a
      );
    } catch (c) {
      console.error("[VOT] Download translation failed:", c), this.triggerUrlDownload(s, `${o}.mp3`) || globalThis.open(s, "_blank")?.focus();
    } finally {
      l(0);
    }
  }
  async downloadTranslationAudio(t, e, i, s) {
    const o = await ut(t, { timeout: 0 });
    if (!o.ok)
      throw new Error(`HTTP ${o.status}`);
    await aw(o, e, i, s);
  }
  async handleDownloadSubtitlesClick() {
    const t = this.videoHandler;
    if (!t?.yandexSubtitles || !t.videoData)
      return;
    const e = this.data.subtitlesDownloadFormat ?? "json", i = nw(
      t.yandexSubtitles,
      e,
      {
        assTitle: t.videoData.localizedTitle ?? t.videoData.title ?? t.videoData.downloadTitle
      }
    ), s = new Blob(
      [
        e === "json" ? JSON.stringify(i) : i
      ],
      {
        type: "text/plain"
      }
    ), r = `${this.data.downloadWithName ? Tr(t.getDownloadBaseName()) : `subtitles_${t.videoData.videoId}`}.${e}`, l = { preferShare: this.isLikelyMobileDownloadContext() };
    await iu(s, r, l);
  }
  async reloadMenu() {
    if (!this.votOverlayView?.isInitialized())
      throw new Error("[VOT] OverlayView isn't initialized");
    const t = this.votOverlayView.votButton.opacity, e = this.votOverlayView.votButton.container.hidden, i = this.votOverlayView.votMenu.hidden, s = this.data.buttonPos ?? "default", o = this.votSettingsView?.dialog?.container?.hidden === !1;
    if (await this.videoHandler?.stopTranslation(), this.release(), this.initUI(), this.initUIEvents(), !this.videoHandler)
      return this;
    try {
      const { position: a, direction: l } = this.votOverlayView.calcButtonLayout(s);
      this.votOverlayView.updateButtonLayout(a, l), this.votOverlayView.votMenu.hidden = i, this.votOverlayView.votButton.container.hidden = e, this.votOverlayView.votButton.opacity = t;
    } catch {
    }
    try {
      this.videoHandler.rebindOverlayVisibilityTargets();
    } catch {
    }
    if (o)
      try {
        this.votSettingsView?.open();
      } catch {
      }
    await this.videoHandler.updateSubtitlesLangSelect();
    const r = this.videoHandler.subtitlesWidget;
    return r && r.resetTranslationContext(!0), this;
  }
  async handleTranslationBtnClick() {
    if (!this.votOverlayView?.isInitialized())
      throw new Error("[VOT] OverlayView isn't initialized");
    const t = this.videoHandler;
    if (!t)
      return this;
    if (t.isAwaitingAutoplayRecovery())
      return await t.resumePendingAutoplayRecovery("button"), this;
    if (t.hasActiveSource())
      return await t.stopTranslation(), this;
    if (this.translationActionInFlight || this.votOverlayView.votButton.loading)
      return this;
    this.translationActionInFlight = !0;
    try {
      if (!t.syncSourceAudioAvailabilityUi({
        forceVisible: !0
      }).ready)
        return this;
      this.votOverlayView.votButton.status === "disabled" && this.transformBtn("none", p.get("translateVideo")), this.votOverlayView.votButton.status === "error" ? this.transformBtn("none", p.get("translateVideo")) : this.votOverlayView.votButton.status !== "disabled" && this.votOverlayView.votButton.status !== "none" && !t.hasActiveSource() && (C.log("[handleTranslationBtnClick] reset stale button state"), this.transformBtn("none", p.get("translateVideo"))), C.log("[handleTranslationBtnClick] trying execute translation"), await t.primePlaybackByGesture("translate-button");
      const i = await this.getVideoDataForTranslation(t);
      await t.videoManager.ensureDetectedLanguageForTranslation(
        i
      ), C.log(
        "[handleTranslationBtnClick] Run translateFunc",
        i.videoId
      ), await t.translateFunc(
        i.videoId,
        i.isStream,
        i.detectedLanguage,
        i.responseLanguage,
        i.translationHelp
      );
    } catch (e) {
      if (this.isAbortError(e))
        return this.transformBtn("none", p.get("translateVideo")), this;
      if (console.error("[VOT]", e), !(e instanceof Error))
        return this.transformBtn("error", String(e)), this;
      const i = e.name === "VOTLocalizedError" ? e.localizedMessage : e.message;
      this.transformBtn("error", i);
    } finally {
      this.translationActionInFlight = !1;
    }
    return this;
  }
  async getVideoDataForTranslation(t) {
    if (t.videoData?.videoId || (t.videoData = await t.getVideoData()), this.shouldRefreshVideoDataBeforeTranslation(t) && (t.videoData = await t.getVideoData()), !t.videoData?.videoId)
      throw new bt("VOTNoVideoIDFound");
    return t.videoData;
  }
  shouldRefreshVideoDataBeforeTranslation(t) {
    return t.site.host === "vk" && t.site.additionalData === "clips" || t.site.host === "douyin";
  }
  isAbortError(t) {
    return t instanceof Error && t.name === "AbortError";
  }
  isLoadingText(t) {
    const e = p.get("TranslationDelayed");
    return typeof t == "string" && (t.includes(p.get("translationTake")) || (e ? t.includes(e) : !1));
  }
  transformBtn(t, e) {
    if (!this.votOverlayView?.isInitialized())
      throw new Error("[VOT] OverlayView isn't initialized");
    return this.votOverlayView.votButton.status = t, this.votOverlayView.votButton.loading = t === "error" && this.isLoadingText(e), this.votOverlayView.votButton.setText(e), this.votOverlayView.votButtonTooltip.setContent(e), this;
  }
  release() {
    return this.isInitialized() ? (/^(m|music)\.youtube\.com$/i.test(
      String(globalThis.location.hostname || "")
    ) && console.log("[VOT][mobile-overlay][ui] UIManager release"), this.votOverlayView.release(), this.votSettingsView.release(), this.votGlobalPortal.remove(), this.initialized = !1, this) : this;
  }
  withInitializedOverlayView(t) {
    this.votOverlayView?.isInitialized() && t(this.votOverlayView);
  }
  withSubtitlesWidget(t) {
    const e = this.videoHandler?.subtitlesWidget;
    e && t(e);
  }
  updateSubtitlesWidgetSetting(t, e, i) {
    this.withSubtitlesWidget((s) => {
      i(s, e ?? t);
    });
  }
  runDetached(t, e) {
    t.catch((i) => {
    });
  }
  triggerUrlDownload(t, e) {
    try {
      const i = document.createElement("a");
      return i.href = t, i.download = e, i.target = "_blank", i.rel = "noopener noreferrer", i.style.display = "none", document.body.appendChild(i), i.click(), i.remove(), !0;
    } catch {
      return !1;
    }
  }
  isLikelyMobileDownloadContext() {
    return this.videoHandler?.site.additionalData === "mobile" || this.videoHandler?.site.additionalData === "music" ? !0 : typeof matchMedia == "function" && matchMedia("(pointer: coarse)").matches;
  }
  restartAudioPlayer() {
    this.restartAudioPlayerSafely();
  }
  async restartAudioPlayerSafely() {
    const t = this.videoHandler;
    if (t)
      try {
        await t.stopTranslate(), t.createPlayer();
      } catch {
      }
  }
}
class Uw {
  constructor(t) {
    u(this, "deps");
    u(this, "hideDeadlineMs", 0);
    u(this, "hideArmed", !1);
    u(this, "unsubscribeChecker");
    this.deps = t, this.unsubscribeChecker = this.deps.checker.subscribe(() => {
      this.onCheckerTick();
    });
  }
  /**
   * Ensures overlay is visible immediately and returns current view.
   */
  show() {
    const t = this.getView();
    return t ? (t.updateButtonOpacity(1), t) : null;
  }
  /**
   * Cancels scheduled auto-hide.
   */
  cancel() {
    this.hideDeadlineMs = 0, this.hideArmed = !1;
  }
  release() {
    this.cancel(), this.unsubscribeChecker();
  }
  /**
   * Schedules overlay auto-hide after configured delay.
   */
  queueAutoHide() {
    if (!this.show())
      return;
    if (!this.shouldAutoHide()) {
      this.cancel();
      return;
    }
    const t = this.deps.getAutoHideDelay();
    this.hideDeadlineMs = this.nowMs() + Math.max(0, t), this.hideArmed = !0, this.deps.checker.markActivity("overlay-queue-hide"), this.deps.checker.requestImmediateTick();
  }
  /**
   * Handles pointer/focus interactions originating from overlay elements.
   */
  handleOverlayInteraction(t) {
    const e = t?.type;
    if (e) {
      if (e === "focusin") {
        this.handleFocusIn();
        return;
      }
      if (e.startsWith("pointer")) {
        this.cancel(), this.show(), this.deps.checker.markActivity("overlay-interaction"), t.stopPropagation?.();
        return;
      }
      this.handleHostInteraction(t);
    }
  }
  /**
   * Handles interactions from the broader host container (video, document etc.).
   */
  handleHostInteraction(t) {
    const e = t?.type;
    if (e) {
      if (e === "focusin") {
        this.handleFocusIn();
        return;
      }
      if (e.startsWith("pointer")) {
        const i = t.target;
        this.deps.isInteractiveNode(i) && t.stopPropagation?.(), this.deps.checker.markActivity("overlay-host-pointer");
      }
      this.queueAutoHide();
    }
  }
  /**
   * Schedules hide if focus leaves overlay tree entirely.
   */
  scheduleHide(t) {
    if (!this.getView())
      return;
    const e = t?.currentTarget;
    let i = t?.relatedTarget ?? null;
    !i && typeof t?.composedPath == "function" && (i = t.composedPath()[1] ?? null);
    const s = i instanceof Node ? i : null, o = e instanceof Node ? e : null;
    s && (o?.contains(s) || this.deps.isInteractiveNode(s)) || this.queueAutoHide();
  }
  onCheckerTick() {
    if (!this.shouldAutoHide()) {
      this.cancel(), this.show();
      return;
    }
    if (!this.hideArmed || this.hideDeadlineMs <= 0 || this.nowMs() + 2 < this.hideDeadlineMs)
      return;
    this.hideArmed = !1;
    let e = null;
    if (typeof document < "u" && typeof document.hasFocus == "function" && document.hasFocus() && (e = document.activeElement), e && this.deps.isInteractiveNode(e))
      return;
    this.getView()?.updateButtonOpacity(0);
  }
  handleFocusIn() {
    this.cancel(), this.show(), this.deps.checker.markActivity("overlay-focus-in");
  }
  getView() {
    const t = this.deps.getOverlayView();
    return t?.isInitialized() ? t : null;
  }
  nowMs() {
    return this.deps.nowMs ? this.deps.nowMs() : typeof performance < "u" && typeof performance.now == "function" ? performance.now() : Date.now();
  }
  shouldAutoHide() {
    return this.deps.shouldAutoHide ? this.deps.shouldAutoHide() : !0;
  }
}
const tl = {
  checkIntervalMs: 250,
  idleAfterMs: 180
};
function $w(n, t) {
  return typeof n != "number" || !Number.isFinite(n) ? t : Math.max(1, Math.trunc(n));
}
function Hw(n, t) {
  return typeof n != "number" || !Number.isFinite(n) ? t : Math.max(0, Math.trunc(n));
}
function Ww(n = {}) {
  return {
    checkIntervalMs: $w(
      n.checkIntervalMs,
      tl.checkIntervalMs
    ),
    idleAfterMs: Hw(
      n.idleAfterMs,
      tl.idleAfterMs
    )
  };
}
function zw() {
  return {
    nowMs: () => typeof performance < "u" && typeof performance.now == "function" ? performance.now() : Date.now(),
    setInterval: globalThis.setInterval.bind(globalThis),
    clearInterval: globalThis.clearInterval.bind(globalThis),
    queueMicrotask: (n) => {
      if (typeof globalThis.queueMicrotask == "function") {
        globalThis.queueMicrotask(n);
        return;
      }
      Promise.resolve().then(n);
    },
    isDocumentHidden: () => typeof document < "u" && typeof document.hidden == "boolean" ? document.hidden : !1,
    onVisibilityChange: (n) => typeof document > "u" || typeof document.addEventListener != "function" ? () => {
    } : (document.addEventListener("visibilitychange", n), () => {
      typeof document.removeEventListener == "function" && document.removeEventListener("visibilitychange", n);
    })
  };
}
class qw {
  constructor(t = {}) {
    u(this, "profile");
    u(this, "runtime");
    u(this, "subscribers", /* @__PURE__ */ new Set());
    u(this, "intervalId", null);
    u(this, "unsubscribeVisibilityChange", null);
    u(this, "running", !1);
    u(this, "destroyed", !1);
    u(this, "immediateQueued", !1);
    u(this, "currentMode", "active");
    u(this, "lastActivityAt");
    u(this, "onVisibilityChangeHandler", () => {
      this.destroyed || !this.running || (this.runtime.isDocumentHidden() ? this.clearIntervalTimer() : this.armInterval(), this.requestImmediateTick());
    });
    this.profile = Ww(t.profile), this.runtime = {
      ...zw(),
      ...t.runtime
    }, this.lastActivityAt = this.runtime.nowMs();
  }
  start() {
    this.destroyed || this.running || (this.running = !0, this.lastActivityAt = this.runtime.nowMs(), this.subscribeVisibilityChange(), this.armInterval(), this.runTick("start"));
  }
  stop() {
    this.running && (this.running = !1, this.clearIntervalTimer(), this.immediateQueued = !1, this.unsubscribeFromVisibilityChange());
  }
  destroy() {
    this.destroyed || (this.stop(), this.subscribers.clear(), this.destroyed = !0);
  }
  subscribe(t) {
    return this.destroyed ? () => {
    } : (this.subscribers.add(t), () => {
      this.subscribers.delete(t);
    });
  }
  markActivity(t) {
    if (this.destroyed || (this.lastActivityAt = this.runtime.nowMs(), !this.running)) return;
    const e = this.resolveMode(this.lastActivityAt);
    e !== this.currentMode && (this.currentMode = e);
  }
  requestImmediateTick() {
    this.destroyed || !this.running || this.immediateQueued || (this.immediateQueued = !0, this.runtime.queueMicrotask(() => {
      this.immediateQueued = !1, !(this.destroyed || !this.running) && this.runTick("immediate");
    }));
  }
  resolveMode(t) {
    return this.runtime.isDocumentHidden() ? "hidden" : t - this.lastActivityAt >= this.profile.idleAfterMs ? "idle" : "active";
  }
  clearIntervalTimer() {
    this.intervalId !== null && (this.runtime.clearInterval(this.intervalId), this.intervalId = null);
  }
  armInterval() {
    this.intervalId === null && (this.intervalId = this.runtime.setInterval(() => {
      this.runTick("interval");
    }, this.profile.checkIntervalMs));
  }
  runTick(t) {
    if (this.destroyed || !this.running || this.subscribers.size === 0) return;
    const e = this.runtime.nowMs(), i = this.resolveMode(e);
    i !== this.currentMode && (this.currentMode = i);
    const s = {
      nowMs: e,
      mode: i,
      source: t
    };
    for (const o of this.subscribers)
      try {
        o(s);
      } catch {
      }
  }
  subscribeVisibilityChange() {
    this.unsubscribeVisibilityChange === null && (this.unsubscribeVisibilityChange = this.runtime.onVisibilityChange(
      this.onVisibilityChangeHandler
    ));
  }
  unsubscribeFromVisibilityChange() {
    this.unsubscribeVisibilityChange !== null && (this.unsubscribeVisibilityChange(), this.unsubscribeVisibilityChange = null);
  }
}
function xo(n) {
  return new qw({ profile: n });
}
const Gu = () => Date.now();
function hs() {
  return GM_info?.script?.name || "VOT";
}
function Ku(n, t) {
  try {
    return p?.get?.(n) || t;
  } catch {
    return t;
  }
}
function Gw(n, t, e) {
  if (!e) return !0;
  const i = n.get(t) ?? 0;
  return Gu() - i >= e;
}
function Kw(n, t) {
  n.set(t, Gu());
}
function fs(n) {
  const t = n.trim();
  if (!t) return null;
  try {
    const e = p.get(t), i = p.getDefault(t);
    return e !== t || i !== t ? e || i || t : null;
  } catch {
    return null;
  }
}
function Yw(n) {
  if (n && typeof n == "object") {
    const e = n;
    if (e.name === "VOTLocalizedError") {
      if (typeof e.localizedMessage == "string" && e.localizedMessage.trim())
        return e.localizedMessage;
      if (typeof e.unlocalizedMessage == "string") {
        const i = fs(
          e.unlocalizedMessage
        );
        if (i) return i;
      }
    }
  }
  if (typeof n == "string") {
    const e = fs(n);
    if (e) return e;
  }
  const t = ce(n);
  return t ? fs(t) || t : Ku("requestTranslationFailed", "Translation failed");
}
function jw(n) {
  try {
    if (typeof GM_notification == "function")
      return GM_notification(n), !0;
    const t = globalThis.GM;
    if (t !== void 0 && typeof t.notification == "function") {
      const e = {
        text: n.text,
        title: n.title,
        image: n.image,
        onclick: n.onclick,
        ondone: n.ondone
      };
      return t.notification(e), !0;
    }
  } catch {
  }
  return !1;
}
class Xw {
  constructor() {
    u(this, "lastSentAt", /* @__PURE__ */ new Map());
  }
  send(t, e = {}) {
    try {
      const i = e.key || t.tag || `${t.title ?? ""}|${t.text ?? ""}`, s = e.cooldownMs ?? 0;
      if (!Gw(this.lastSentAt, i, s)) return;
      const o = {
        ...t,
        title: t.title ?? hs()
      };
      jw(o) ? Kw(this.lastSentAt, i) : C.log("[notify] unavailable", o);
    } catch {
    }
  }
  translationCompleted(t) {
    const e = Ku(
      "VOTTranslationCompletedNotify",
      "The translation on the {0} has been completed!"
    ).replace("{0}", t);
    this.send(
      {
        text: e,
        title: hs(),
        timeout: 5e3,
        silent: !0,
        tag: "VOTTranslationCompleted",
        onclick: () => {
          try {
            globalThis.focus();
          } catch {
          }
        }
      },
      { key: `translation_completed_${t}`, cooldownMs: 1e4 }
    );
  }
  translationFailed(t) {
    const { videoId: e, message: i } = t;
    if (kn(i)) return;
    const s = Yw(i), o = hs();
    this.send(
      {
        text: s,
        title: o,
        timeout: 8e3,
        silent: !0,
        // Keep legacy tag casing so existing notification replacement/dedupe continues to work.
        tag: `VOTtranslationFailed_${e || "unknown"}`,
        onclick: () => {
          try {
            globalThis.focus();
          } catch {
          }
        }
      },
      // Errors can loop while polling; keep these non-spammy.
      { key: `translation_failed_${e || "unknown"}`, cooldownMs: 3e4 }
    );
  }
}
const Jw = ["class", "id", "title"], Zw = [
  "advertise",
  "advertisement",
  "promo",
  "sponsor",
  "banner",
  "commercial",
  "preroll",
  "midroll",
  "postroll",
  "ad-container",
  "sponsored"
], Qw = new RegExp(
  Zw.map(
    (n) => n.replaceAll(/[.*+?^${}()|[\]\\]/g, String.raw`\$&`)
  ).join("|")
), Ti = /* @__PURE__ */ Symbol.for("vot.attachShadowHook");
function el() {
  return /^(m|music)\.youtube\.com$/i.test(
    String(globalThis.location?.hostname || "")
  );
}
const rn = {
  preferProbeBootstrap: !1,
  startDomObservationOnEnable: !0,
  probeStrategy: "mutation",
  probeSelectors: ["video"],
  probePollIntervalMs: 75,
  probePollTimeoutMs: 4e3,
  stopAfterFirstVideoDetected: !1,
  keepWatchingAfterVideoDetected: !0,
  observeShadowRoots: !0,
  shadowHostSelectors: []
};
function tS() {
  const n = Object.getOwnPropertyDescriptor(
    Element.prototype,
    "attachShadow"
  );
  return !n || typeof n.value != "function" ? null : n;
}
function eS() {
  const n = globalThis, t = n[Ti];
  if (t?.descriptor && t.subscribers instanceof Set)
    return t;
  const e = tS();
  if (!e) return null;
  const i = e.value, s = {
    descriptor: e,
    subscribers: /* @__PURE__ */ new Set()
  }, o = function(r) {
    const a = i.call(this, r);
    for (const l of s.subscribers)
      try {
        l(a);
      } catch {
      }
    return a;
  };
  try {
    Object.defineProperty(Element.prototype, "attachShadow", {
      ...e,
      value: o
    });
  } catch {
    return null;
  }
  return n[Ti] = s, s;
}
function nS(n) {
  const t = globalThis, e = t[Ti];
  if (e && (e.subscribers.delete(n), !(e.subscribers.size > 0))) {
    try {
      Object.defineProperty(Element.prototype, "attachShadow", e.descriptor);
    } catch {
      const i = e.descriptor.value;
      typeof i == "function" && (Element.prototype.attachShadow = i);
    }
    delete t[Ti];
  }
}
const ue = class ue {
  constructor(t = xo()) {
    u(this, "seenVideos", /* @__PURE__ */ new WeakSet());
    u(this, "activeVideos", /* @__PURE__ */ new WeakSet());
    u(this, "observedRoots", /* @__PURE__ */ new WeakSet());
    u(this, "videoListenerControllers", /* @__PURE__ */ new Map());
    u(this, "pendingAdded", /* @__PURE__ */ new Set());
    u(this, "pendingRemoved", /* @__PURE__ */ new Set());
    u(this, "flushPending", !1);
    u(this, "onVideoAdded", new z());
    u(this, "onVideoRemoved", new z());
    u(this, "observer", new MutationObserver(
      (t) => this.onMutations(t)
    ));
    u(this, "intervalIdleChecker");
    u(this, "checkerUnsubscribe", null);
    u(this, "enabled", !1);
    u(this, "attachShadowSubscriber", null);
    u(this, "onDocumentReady", null);
    u(this, "policy", rn);
    u(this, "flushSlice", () => {
      if (!this.enabled) {
        this.pendingAdded.clear(), this.pendingRemoved.clear(), this.flushPending = !1;
        return;
      }
      const t = this.getNowMs(), e = this.processPendingAdded(t);
      this.processPendingRemoved(t, e), this.flushPending = this.pendingAdded.size > 0 || this.pendingRemoved.size > 0, this.flushPending && this.intervalIdleChecker.requestImmediateTick();
    });
    u(this, "onCheckerTick", () => {
      this.flushPending && this.flushSlice();
    });
    u(this, "scheduleFlush", () => {
      this.enabled && (this.flushPending = !0, this.intervalIdleChecker.requestImmediateTick());
    });
    u(this, "onPageShow", () => {
      const t = document.documentElement;
      t && (this.canObserveRoots() && this.observeRoot(t), this.scan(t));
    });
    this.intervalIdleChecker = t;
  }
  setPolicy(t) {
    this.policy = {
      ...rn,
      ...t,
      probeSelectors: Array.isArray(t.probeSelectors) && t.probeSelectors.length > 0 ? [...t.probeSelectors] : [...rn.probeSelectors],
      shadowHostSelectors: Array.isArray(t.shadowHostSelectors) ? [...t.shadowHostSelectors] : [...rn.shadowHostSelectors]
    };
  }
  static containsAdKeyword(t) {
    return t.length > 0 && Qw.test(t);
  }
  isAdRelated(t) {
    for (const e of Jw) {
      const i = t.getAttribute(e);
      if (i && ue.containsAdKeyword(i.toLowerCase()))
        return !0;
    }
    return !1;
  }
  isInsideAd(t) {
    for (let e = t.parentElement; e; e = e.parentElement)
      if (this.isAdRelated(e)) return !0;
    return !1;
  }
  getCapturedAudioTrackCount(t) {
    const e = t, i = e.captureStream ?? e.mozCaptureStream;
    if (typeof i != "function") return null;
    try {
      return i.call(t).getAudioTracks().length;
    } catch {
      return null;
    }
  }
  isLikelySilentDecorativeVideo(t) {
    if (!(t.muted || t.defaultMuted) || !t.autoplay || !t.loop || t.controls) return !1;
    const e = t;
    if (typeof e.mozHasAudio == "boolean")
      return !e.mozHasAudio;
    if ("audioTracks" in e && typeof e.audioTracks?.length == "number") {
      if (e.audioTracks.length > 0) return !1;
      const s = this.getCapturedAudioTrackCount(t);
      return s !== null ? s === 0 : !0;
    }
    const i = this.getCapturedAudioTrackCount(t);
    return i !== null ? i === 0 : !1;
  }
  hasAudio(t) {
    const e = t;
    return t.srcObject instanceof MediaStream ? t.srcObject.getAudioTracks().length > 0 : typeof e.mozHasAudio == "boolean" ? e.mozHasAudio : typeof e.webkitAudioDecodedByteCount == "number" && e.webkitAudioDecodedByteCount > 0 || "audioTracks" in e && typeof e.audioTracks?.length == "number" && e.audioTracks.length > 0 ? !0 : !this.isLikelySilentDecorativeVideo(t);
  }
  isVkLikeVideo(t) {
    const e = String(globalThis.location?.hostname || ""), i = String(t.currentSrc || t.src || "");
    return /(?:^|\.)vkvideo\.ru$|(?:^|\.)vk\.(?:com|ru)$|(?:^|\.)okcdn\.ru$/i.test(
      e
    ) || /vkvd\d+\.okcdn\.ru|\.okcdn\.ru|vkvideo\.ru|vk\.(?:com|ru)/i.test(
      i
    );
  }
  isValidVideo(t) {
    return !(this.isAdRelated(t) || this.isInsideAd(t) || !this.hasAudio(t) && !this.isVkLikeVideo(t));
  }
  stopObservingDom() {
    el() && console.log(
      "[VOT][mobile-overlay][video-observer] disconnect DOM observer"
    ), this.observer.disconnect(), this.observedRoots = /* @__PURE__ */ new WeakSet(), this.pendingAdded.clear(), this.pendingRemoved.clear(), this.flushPending = !1;
  }
  canObserveRoots() {
    return this.policy.startDomObservationOnEnable;
  }
  observeRoot(t) {
    this.canObserveRoots() && (this.observedRoots.has(t) || (this.observedRoots.add(t), this.observer.observe(t, { childList: !0, subtree: !0 })));
  }
  scan(t) {
    if (!this.policy.startDomObservationOnEnable) {
      this.scanTargeted(t, this.policy.probeSelectors);
      return;
    }
    this.scanDefault(t);
  }
  scanTargeted(t, e) {
    if (t instanceof HTMLVideoElement) {
      this.trackVideo(t);
      return;
    }
    if (!(t instanceof Document) && !(t instanceof DocumentFragment) && !(t instanceof Element))
      return;
    const i = /* @__PURE__ */ new Set(), s = (r) => {
      !(r instanceof HTMLVideoElement) || i.has(r) || (i.add(r), this.trackVideo(r));
    }, o = e.length > 0 ? e : rn.probeSelectors;
    for (const r of o) {
      try {
        t instanceof Element && t.matches(r) && s(t);
      } catch {
      }
      try {
        for (const a of t.querySelectorAll(r))
          s(a);
      } catch {
      }
    }
    if (this.policy.observeShadowRoots)
      for (const r of this.policy.shadowHostSelectors) {
        let a;
        try {
          a = t.querySelectorAll(r);
        } catch {
          continue;
        }
        for (const l of a) {
          const c = l.shadowRoot;
          c && this.scanTargeted(c, o);
        }
      }
  }
  scanDefault(t) {
    if (t instanceof HTMLVideoElement) {
      this.trackVideo(t);
      return;
    }
    if (t.nodeType !== Node.ELEMENT_NODE && t.nodeType !== Node.DOCUMENT_FRAGMENT_NODE && t.nodeType !== Node.DOCUMENT_NODE)
      return;
    const e = document.createTreeWalker(t, NodeFilter.SHOW_ELEMENT, {
      acceptNode: (i) => {
        const s = i, o = s.tagName === "VIDEO", r = !!s.shadowRoot;
        return o || r ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
      }
    });
    for (; e.nextNode(); ) {
      const i = e.currentNode;
      if (i instanceof HTMLVideoElement) {
        this.trackVideo(i);
        continue;
      }
      const s = i.shadowRoot;
      s && (this.observeRoot(s), this.scanDefault(s));
    }
  }
  getVideoListenerSignal(t) {
    const e = this.videoListenerControllers.get(t);
    e && e.abort();
    const i = new AbortController();
    return this.videoListenerControllers.set(t, i), i.signal;
  }
  cleanupVideoListeners(t) {
    const e = this.videoListenerControllers.get(t);
    e && (e.abort(), this.videoListenerControllers.delete(t));
  }
  cleanupAllVideoListeners() {
    for (const t of this.videoListenerControllers.values())
      t.abort();
    this.videoListenerControllers.clear();
  }
  trackVideo(t) {
    if (this.seenVideos.has(t)) return;
    this.seenVideos.add(t);
    const e = this.getVideoListenerSignal(t), i = () => {
      this.isValidVideo(t) && (this.activeVideos.has(t) || (this.activeVideos.add(t), this.onVideoAdded.dispatch(t)));
    };
    if (t.readyState >= HTMLMediaElement.HAVE_METADATA || !!(t.currentSrc || t.src || t.srcObject))
      i();
    else {
      t.addEventListener("loadedmetadata", i, {
        once: !0,
        signal: e
      }), t.addEventListener("loadeddata", i, {
        once: !0,
        signal: e
      }), t.addEventListener("canplay", i, {
        once: !0,
        signal: e
      }), t.addEventListener("playing", i, {
        once: !0,
        passive: !0,
        signal: e
      }), t.addEventListener("timeupdate", i, {
        once: !0,
        passive: !0,
        signal: e
      });
      const o = () => {
        t.readyState >= HTMLMediaElement.HAVE_METADATA && i();
      };
      t.addEventListener("play", o, {
        once: !0,
        passive: !0,
        signal: e
      });
    }
    t.addEventListener(
      "emptied",
      () => {
        t.isConnected || this.untrackVideo(t);
      },
      { passive: !0, signal: e }
    ), t.addEventListener(
      "durationchange",
      () => {
        this.activeVideos.has(t) || i();
      },
      { passive: !0, signal: e }
    );
  }
  untrackVideo(t) {
    this.cleanupVideoListeners(t), this.activeVideos.has(t) && (this.onVideoRemoved.dispatch(t), this.activeVideos.delete(t)), this.seenVideos.delete(t);
  }
  collectVideos(t) {
    const e = /* @__PURE__ */ new Set(), i = (s) => {
      for (const o of s) e.add(o);
    };
    if (t instanceof HTMLVideoElement && e.add(t), (t instanceof Document || t instanceof DocumentFragment || t instanceof Element) && i(t.querySelectorAll("video")), t instanceof Element) {
      const s = t.shadowRoot;
      s && i(s.querySelectorAll("video"));
    }
    return Array.from(e);
  }
  getNowMs() {
    return typeof performance < "u" && typeof performance.now == "function" ? performance.now() : Date.now();
  }
  isSliceBudgetReached(t, e) {
    return e >= ue.MAX_NODES_PER_SLICE ? !0 : this.getNowMs() - t >= ue.MAX_FLUSH_BUDGET_MS;
  }
  processPendingAdded(t) {
    let e = 0;
    for (; this.pendingAdded.size > 0; ) {
      const i = this.pendingAdded.values().next();
      if (i.done || (this.pendingAdded.delete(i.value), this.scan(i.value), e += 1, this.isSliceBudgetReached(t, e)))
        break;
    }
    return e;
  }
  processPendingRemoved(t, e) {
    let i = e;
    for (; this.pendingRemoved.size > 0 && !this.isSliceBudgetReached(t, i); ) {
      const s = this.pendingRemoved.values().next();
      if (s.done) break;
      this.pendingRemoved.delete(s.value);
      for (const o of this.collectVideos(s.value))
        o.isConnected || this.untrackVideo(o);
      i += 1;
    }
    return i;
  }
  installAttachShadowHook() {
    if (!this.canObserveRoots() || !this.policy.observeShadowRoots || this.attachShadowSubscriber) return;
    const t = eS();
    if (!t) return;
    const e = (i) => {
      this.enabled && (this.observeRoot(i), this.pendingAdded.add(i), this.scheduleFlush());
    };
    t.subscribers.add(e), this.attachShadowSubscriber = e;
  }
  uninstallAttachShadowHook() {
    this.attachShadowSubscriber && (nS(this.attachShadowSubscriber), this.attachShadowSubscriber = null);
  }
  enqueueAddedNode(t) {
    if (this.canObserveRoots() && this.policy.observeShadowRoots && t.nodeType === Node.ELEMENT_NODE) {
      const e = t.shadowRoot;
      e && this.observeRoot(e);
    }
    this.pendingAdded.add(t);
  }
  enqueueMutation(t) {
    for (const e of t.addedNodes)
      this.enqueueAddedNode(e);
    for (const e of t.removedNodes)
      this.pendingRemoved.add(e);
  }
  onMutations(t) {
    for (const e of t)
      e.type === "childList" && this.enqueueMutation(e);
    (this.pendingAdded.size > 0 || this.pendingRemoved.size > 0) && this.scheduleFlush();
  }
  enable(t) {
    if (this.enabled) return;
    this.enabled = !0;
    const e = () => {
      const o = document.documentElement, r = t && "isConnected" in t && t.isConnected ? t : o;
      r && (this.policy.startDomObservationOnEnable && this.observeRoot(o), this.scan(r));
    };
    if (!this.policy.startDomObservationOnEnable) {
      if (document.documentElement) {
        e();
        return;
      }
      const r = () => {
        document.removeEventListener("readystatechange", r), this.onDocumentReady = null, this.enabled && e();
      };
      this.onDocumentReady = r, document.addEventListener("readystatechange", r), typeof queueMicrotask == "function" ? queueMicrotask(r) : Promise.resolve().then(r);
      return;
    }
    if (this.checkerUnsubscribe?.(), this.checkerUnsubscribe = this.intervalIdleChecker.subscribe(
      this.onCheckerTick
    ), this.intervalIdleChecker.start(), this.intervalIdleChecker.markActivity("video-observer-enable"), this.installAttachShadowHook(), globalThis.addEventListener("pageshow", this.onPageShow, {
      passive: !0
    }), document.documentElement) {
      e();
      return;
    }
    const s = () => {
      document.documentElement && (document.removeEventListener("readystatechange", s), this.onDocumentReady = null, this.enabled && e());
    };
    this.onDocumentReady = s, document.addEventListener("readystatechange", s), typeof queueMicrotask == "function" ? queueMicrotask(s) : Promise.resolve().then(s);
  }
  disable() {
    this.enabled && (el() && console.log("[VOT][mobile-overlay][video-observer] disable observer"), this.enabled = !1, globalThis.removeEventListener("pageshow", this.onPageShow), this.onDocumentReady && (document.removeEventListener("readystatechange", this.onDocumentReady), this.onDocumentReady = null), this.uninstallAttachShadowHook(), this.stopObservingDom(), this.cleanupAllVideoListeners(), this.checkerUnsubscribe?.(), this.checkerUnsubscribe = null, this.intervalIdleChecker.stop(), this.seenVideos = /* @__PURE__ */ new WeakSet(), this.activeVideos = /* @__PURE__ */ new WeakSet(), this.observedRoots = /* @__PURE__ */ new WeakSet());
  }
};
u(ue, "MAX_FLUSH_BUDGET_MS", 6), u(ue, "MAX_NODES_PER_SLICE", 120);
let Hs = ue;
function gs(n, t) {
  const e = Rt(t);
  n.lastVideoPercent = e;
}
function ms(n, t) {
  const e = Number(t);
  if (!Number.isFinite(e))
    return;
  const i = Math.max(0, Math.round(e));
  n.lastTranslationPercent = i;
}
function iS({
  state: n,
  fromType: t,
  newVolume: e,
  currentVideo: i,
  currentTranslation: s,
  translationMin: o,
  translationMax: r
}) {
  if (n.initialized || (n.lastVideoPercent = Number(i), n.lastTranslationPercent = Number(s), n.initialized = !0), t === "video") {
    const d = Rt(e), h = d - Rt(n.lastVideoPercent);
    n.lastVideoPercent = d;
    const f = Ds(
      n.lastTranslationPercent + h,
      o,
      r
    );
    return n.lastTranslationPercent = f, { nextTranslation: f };
  }
  const a = Ds(
    Number.isFinite(e) ? e : s,
    o,
    r
  ), l = a - n.lastTranslationPercent;
  n.lastTranslationPercent = a;
  const c = Rt(n.lastVideoPercent + l);
  return n.lastVideoPercent = c, { nextVideo: c };
}
const nl = {
  allowTouchMoveHandler: !0,
  disableContainerDrag: !1
}, sS = {
  xvideos: {
    allowTouchMoveHandler: !1
  },
  youtube: {
    disableContainerDrag: !0
  }
};
function oS(n) {
  if (!n)
    return nl;
  const t = sS[n] ?? {};
  return {
    ...nl,
    ...t
  };
}
const il = 2200, rS = 2500;
function aS(n, t) {
  if (!t || t === n || n.aborted)
    return n;
  if (t.aborted)
    return t;
  if (typeof AbortSignal < "u" && "any" in AbortSignal)
    return AbortSignal.any([n, t]);
  const i = new AbortController(), s = () => {
    n.removeEventListener("abort", o), t.removeEventListener("abort", r);
  }, o = () => {
    s(), i.abort(n.reason);
  }, r = () => {
    s(), i.abort(t.reason);
  };
  return n.addEventListener("abort", o, { once: !0 }), t.addEventListener("abort", r, { once: !0 }), i.signal;
}
function Yu(n) {
  return n === "vk" || /(?:^|\.)vkvideo\.ru$|(?:^|\.)vk\.(?:com|ru)$/i.test(
    String(globalThis.location?.hostname || "")
  );
}
function lS() {
  return /^(m|music)\.youtube\.com$/i.test(
    String(globalThis.location?.hostname || "")
  );
}
function Ht(n, t) {
  lS() && console.log(`[VOT][mobile-overlay][events] ${n}`, t ?? {});
}
function Ws() {
  return `${globalThis.location.origin}${globalThis.location.pathname}${globalThis.location.search}`;
}
function ju(n) {
  n.mobileYouTubeLifecycleDebounceTimer !== void 0 && (clearTimeout(n.mobileYouTubeLifecycleDebounceTimer), n.mobileYouTubeLifecycleDebounceTimer = void 0);
}
function zs(n) {
  n.votMenu && (n.votMenu.hidden = !0);
}
function Xu(n, t, e, i) {
  ju(n);
  const s = Ws();
  Ht("schedule lifecycle retry", {
    reason: e,
    pageKey: s,
    delayMs: il
  }), n.mobileYouTubeLifecycleDebounceTimer = globalThis.setTimeout(() => {
    if (n.mobileYouTubeLifecycleDebounceTimer = void 0, n.abortController.signal.aborted) {
      Ht("skip lifecycle retry: handler aborted", { reason: e });
      return;
    }
    const o = Ws();
    if (o !== s) {
      Ht("run lifecycle cleanup after page change", {
        reason: e,
        pageKey: s,
        currentPageKey: o
      }), i();
      return;
    }
    const r = W.getCurrentVideoId(), a = n.videoData?.videoId, l = typeof r == "string" && r.length > 0, c = l && !!a && r === a, d = !!(n.video.currentSrc || n.video.src || n.video.srcObject), h = !!n.container?.isConnected;
    if (c || l || d || h) {
      Ht("keep overlay after lifecycle retry", {
        reason: e,
        currentVideoId: a,
        recoveredVideoId: r,
        hasSource: d,
        hasConnectedShell: h
      }), zs(t), n.refreshOverlayMount();
      return;
    }
    if (n.site.additionalData === "music") {
      Ht("keep overlay for music shell without stable video", {
        reason: e,
        pageKey: s
      }), zs(t), n.refreshOverlayMount(), Xu(n, t, e, i);
      return;
    }
    Ht("lifecycle retry expired; cleaning up", {
      reason: e,
      pageKey: s
    }), i();
  }, il);
}
function Ju(n) {
  const t = (i, s, o, r) => {
    const a = aS(n, r?.signal);
    if (!r) {
      i.addEventListener(s, o, { signal: a });
      return;
    }
    const { signal: l, ...c } = r;
    i.addEventListener(s, o, {
      ...c,
      signal: a
    });
  };
  return { add: t, addMany: (i, s, o, r) => {
    for (const a of s)
      t(i, a, o, r);
  } };
}
function sl(n, t, e) {
  n(
    t,
    ["pointerenter", "focusin"],
    (i) => e.handleOverlayInteraction(i)
  ), n(
    t,
    ["pointermove"],
    (i) => e.handleOverlayInteraction(i),
    { passive: !0 }
  ), n(
    t,
    ["pointerleave", "focusout"],
    (i) => e.scheduleHide(i)
  );
}
function qs(n, t = 0) {
  const e = typeof n == "number" ? n : Number(n);
  return Number.isFinite(e) ? Rt(e) : t;
}
function Zu(n, t, e = {}) {
  e.skipYouTubeLikeHosts && ho(n.site.host) || n.smartVolumeDuckingInterval === void 0 && (!n.data?.syncVolume || !n.audioPlayer?.player?.src || n.isLikelyInternalVideoVolumeChange(t) || n.syncVolumeWrapper("video", t));
}
function ol(n, t, e) {
  const i = t.votMenu?.container;
  if (i) {
    const r = e ?? n.video.getBoundingClientRect().height;
    i.style.setProperty("--vot-container-height", `${r}px`);
  }
  const { position: s, direction: o } = t.calcButtonLayout(
    n.data?.buttonPos ?? "default"
  );
  t.updateButtonLayout(s, o);
}
function Qu(n) {
  return n.replace("Key", "").replace("Digit", "");
}
function uS(n) {
  const t = /* @__PURE__ */ new Set();
  for (const e of n)
    t.add(Qu(e));
  return t;
}
function rl(n, t) {
  if (!n) return null;
  const e = t.get(n);
  if (e) return e;
  const i = n.split("+").filter(Boolean).map(Qu), s = {
    parts: i,
    partsSet: new Set(i)
  };
  return t.set(n, s), s;
}
function al(n, t) {
  if (!t || n.size !== t.parts.length) return !1;
  for (const e of t.partsSet)
    if (!n.has(e)) return !1;
  return !0;
}
function cS(n) {
  const { self: t, overlayView: e, addMany: i } = n, s = () => {
    t.refreshOverlayMount(), ol(t, e);
  };
  if (t.resizeObserver = new ResizeObserver((o) => {
    for (const r of o)
      ol(t, e, r.contentRect.height);
  }), t.resizeObserver.observe(t.video), s(), i(
    document,
    ["fullscreenchange", "webkitfullscreenchange"],
    () => s()
  ), i(
    t.video,
    ["webkitbeginfullscreen", "webkitendfullscreen"],
    () => s()
  ), _t(t.site)) {
    let o = !1;
    const r = () => {
      o || (o = !0, queueMicrotask(() => {
        o = !1, !(t.abortController.signal.aborted || !(!t.container.isConnected || !t.video.isConnected || t.video.isConnected && !be(t.container, t.video))) && (Ht("sync mount after DOM repaint", {
          containerConnected: t.container.isConnected,
          videoConnected: t.video.isConnected
        }), s());
      }));
    };
    t.overlayMountObserver = new MutationObserver(() => {
      r();
    }), t.overlayMountObserver.observe(document.documentElement, {
      childList: !0,
      subtree: !0
    }), i(
      document,
      ["yt-page-data-updated", "yt-navigate-finish"],
      () => r()
    );
  }
}
function dS(n) {
  const { self: t } = n;
  if (!Di(t.site)) return;
  t.syncVolumeObserver = new MutationObserver((i) => {
    if (!t.audioPlayer?.player?.src) return;
    let s = !1, o = null;
    for (const a of i) {
      if (a.type !== "attributes" || a.attributeName !== "aria-valuenow")
        continue;
      s = !0;
      const l = a.target instanceof Element ? a.target.getAttribute("aria-valuenow") : null, c = l != null ? Number.parseFloat(l) : Number.NaN;
      Number.isFinite(c) && (o = c);
    }
    if (!s) return;
    let r;
    if (o != null)
      r = qs(o);
    else {
      const a = t.isMuted() ? 0 : t.getVideoVolume();
      r = qs(a * 100);
    }
    t.syncVideoVolumeSlider(), Zu(t, r);
  });
  const e = document.querySelector(".ytp-volume-panel");
  e && t.syncVolumeObserver.observe(e, {
    attributes: !0,
    subtree: !0,
    attributeFilter: ["aria-valuenow"]
  });
}
function hS(n) {
  const { self: t } = n;
  if (!Di(t.site)) return;
  const e = async () => {
    try {
      if (!t.videoData) return;
      const o = W.getPlayer(), r = o?.getAvailableAudioTracks?.() ?? null;
      if (!Array.isArray(r) || r.length <= 1)
        return;
      const l = o?.getAudioTrack?.()?.getLanguageInfo?.()?.id, c = l && l !== "und" ? l.toLowerCase().split(/[-_.]/)[0] : void 0;
      if (!c || !Bt.includes(c)) return;
      const d = c;
      if (d === t.videoData.detectedLanguage) return;
      if (t.videoManager.rememberDetectedLanguage(
        t.videoData.videoId,
        d
      ), t.setSelectMenuValues(
        d,
        t.videoData.responseLanguage
      ), t.data?.autoTranslate && d !== t.videoData.responseLanguage) {
        C.log(
          `[VOT] Audio track language changed to ${d}, triggering auto-translation`
        );
        try {
          await t.uiManager.handleTranslationBtnClick();
        } catch (h) {
          C.log(
            "[VOT] Failed to trigger auto-translation on audio track change:",
            h
          );
        }
      }
    } catch {
    }
  }, i = W.getPlayer(), s = ["onApiChange", "onStateChange"];
  if (i?.addEventListener)
    for (const o of s)
      try {
        i.addEventListener(o, e);
      } catch {
      }
  e(), t.abortController.signal.addEventListener(
    "abort",
    () => {
      if (i?.removeEventListener)
        for (const o of s)
          try {
            i.removeEventListener(o, e);
          } catch {
          }
    },
    { once: !0 }
  );
}
function fS(n) {
  const { self: t, overlayView: e, add: i, addMany: s, platformConfig: o } = n;
  i(document, "click", (f) => {
    const g = f.target, m = e.votButton?.container, v = e.votMenu?.container, S = t.uiManager.votSettingsView?.dialog?.container, T = g && m ? m.contains(g) : !1, w = g && v ? v.contains(g) : !1, A = g ? t.container.contains(g) : !1, P = g && S ? S.contains(g) : !1, _ = g instanceof Element && g.closest(".vot-dialog-temp") instanceof Element;
    T || w || P || _ || (!A && !Yu(t.site.host) && !_t(t.site) && e.updateButtonOpacity(0), v && !v.hidden && (v.hidden = !0, t.overlayVisibility?.queueAutoHide()));
  });
  const r = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Map(), l = () => r.clear(), c = (f, g) => {
    f().catch((m) => {
    });
  };
  i(document, "keydown", (f) => {
    const g = f;
    if (g.repeat) return;
    r.add(g.code);
    const m = document.activeElement, v = m?.tagName?.toLowerCase?.() ?? "";
    if (["input", "textarea"].includes(v) || !!m?.isContentEditable) return;
    const T = uS(r);
    if (al(
      T,
      rl(t.data?.translationHotkey, a)
    )) {
      l(), c(
        () => t.uiManager.handleTranslationBtnClick()
      );
      return;
    }
    al(
      T,
      rl(t.data?.subtitlesHotkey, a)
    ) && (l(), c(
      () => t.toggleSubtitlesForCurrentLangPair()
    ));
  }), i(
    document,
    "keyup",
    (f) => r.delete(f.code)
  ), i(document, "blur", l), i(document, "visibilitychange", () => {
    document.hidden && l();
  }), i(globalThis, "blur", l);
  const d = /* @__PURE__ */ new Set(), h = t.getEventContainer();
  h && d.add(h), d.add(t.container), d.add(t.video);
  for (const f of d)
    s(
      f,
      ["pointerenter", "pointerdown"],
      (g) => t.overlayVisibility.handleHostInteraction(g)
    ), _t(t.site) && s(
      f,
      ["touchstart"],
      (g) => t.overlayVisibility.handleHostInteraction(g),
      { passive: !0 }
    ), i(
      f,
      "pointermove",
      (g) => t.overlayVisibility.handleHostInteraction(g),
      { passive: !0 }
    ), i(
      f,
      "pointerleave",
      (g) => t.overlayVisibility.scheduleHide(g)
    );
  t.rebindOverlayVisibilityTargets(), o.allowTouchMoveHandler && i(
    document,
    "touchmove",
    (f) => t.overlayVisibility.handleHostInteraction(f),
    { passive: !0 }
  ), _t(t.site) && i(
    document,
    "touchstart",
    (f) => t.overlayVisibility.handleHostInteraction(f),
    { passive: !0, capture: !0 }
  ), o.disableContainerDrag && (t.container.draggable = !1);
}
function gS(n) {
  const { self: t, overlayView: e, add: i } = n, s = async () => {
    try {
      await t.setCanPlay();
    } catch {
    }
  };
  let o = !1;
  const r = () => {
    o || (o = !0, queueMicrotask(async () => {
      o = !1, await s();
    }));
  };
  i(t.video, "canplay", () => {
    t.site.host === "rutube" && t.video.src || r();
  });
  for (const l of [
    "loadedmetadata",
    "loadeddata",
    "play",
    "playing"
  ])
    i(t.video, l, () => {
      if (l === "play" || l === "playing") {
        console.log("[VOT][source-audio] play event received", {
          eventName: l,
          host: t.site.host,
          paused: t.video.paused,
          currentTime: Number(t.video.currentTime.toFixed(3)),
          readyState: t.video.readyState,
          src: t.video.currentSrc || t.video.src || ""
        });
        const c = t.syncSourceAudioAvailabilityUi({
          forceVisible: !0
        });
        c.ready && t.data?.autoTranslate && t.firstPlay && !t.hasActiveSource() && (console.log("[VOT][source-audio] retry auto-translate after playback", {
          eventName: l,
          kind: c.kind,
          audioDetected: c.audioDetected,
          detectionSource: c.detectionSource
        }), t.translationOrchestrator.runAutoTranslationIfEligible().catch((d) => {
        }));
      }
      r();
    });
  const a = async () => {
    let l;
    try {
      l = t.site.host === "youtube" && Eu(t.site.additionalData) ? W.getCurrentVideoId() : await Yl(t.site, {
        fetchFn: ut,
        video: t.video
      });
    } catch {
    }
    if (!(t.videoData && l && l === t.videoData.videoId) && !(t.site.host === "custom" && uo())) {
      if (_t(t.site)) {
        Ht("video emptied; start grace period", {
          currentVideoId: t.videoData?.videoId,
          resolvedVideoId: l,
          pageKey: Ws()
        }), mo(t, {
          clearVideoData: !0
        }), zs(e), Xu(
          t,
          e,
          "video-emptied",
          () => {
            Vs(t, e, {
              clearVideoData: !0,
              hideMenu: !0
            });
          }
        );
        return;
      }
      Vs(t, e, {
        clearVideoData: !0,
        hideMenu: !0
      });
    }
  };
  i(t.video, "emptied", () => {
    a().catch((l) => {
    });
  }), fp(t.site.host) || i(t.video, "volumechange", () => {
    t.syncVideoVolumeSlider();
    const l = t.uiManager.votOverlayView;
    if (!l?.isInitialized()) return;
    const c = qs(
      l.videoVolumeSlider.value
    );
    Zu(t, c, {
      skipYouTubeLikeHosts: !0
    });
  }), t.site.host === "youtube" && !t.site.additionalData && i(document, "yt-page-data-updated", () => {
    globalThis.location.pathname.startsWith("/shorts/") && r();
  });
}
function mS() {
  const n = this.uiManager.votOverlayView;
  if (!n?.subtitlesSelect) return;
  const { add: t, addMany: e } = Ju(this.abortController.signal), i = {
    self: this,
    overlayView: n,
    platformConfig: oS(this.site.host),
    add: t,
    addMany: e
  };
  cS(i), dS(i), hS(i), fS(i), gS(i);
}
function pS() {
  this.overlayVisibilityTargetsAbortController?.abort(), this.overlayVisibilityTargetsAbortController = new AbortController();
  const { signal: n } = this.overlayVisibilityTargetsAbortController, t = this.uiManager?.votOverlayView?.votButton?.container, e = this.uiManager?.votOverlayView?.votMenu?.container;
  if (!t || !e || !this.overlayVisibility) return;
  const i = this.overlayVisibility, { addMany: s } = Ju(n);
  sl(s, t, i), sl(s, e, i);
}
function yS(n) {
  if (!(n instanceof Node)) return !1;
  const t = this.uiManager?.votOverlayView, e = t?.votButton?.container, i = t?.votMenu?.container;
  return e instanceof Node && e.contains(n) || i instanceof Node && i.contains(n);
}
function bS() {
  if (Yu(this.site.host))
    return 6e4;
  const n = this.data?.autoHideButtonDelay, t = typeof n == "number" && Number.isFinite(n) ? n : ro;
  return _t(this.site) ? Math.max(t, rS) : t;
}
function vS() {
  ju(this), Ht("release extra events / disconnect observers", {
    hasResizeObserver: !!this.resizeObserver,
    hasOverlayMountObserver: !!this.overlayMountObserver,
    hasSyncVolumeObserver: !!this.syncVolumeObserver
  }), this.resizeObserver?.disconnect(), this.overlayVisibilityTargetsAbortController?.abort(), this.overlayVisibilityTargetsAbortController = void 0, this.overlayMountObserver?.disconnect(), this.overlayMountObserver = void 0, Di(this.site) && this.syncVolumeObserver?.disconnect();
}
const vn = class vn {
  constructor() {
    u(this, "popup", null);
    u(this, "isBound", !1);
    u(this, "geometrySaveTimer", null);
    u(this, "ownerId", null);
    u(this, "onTranslate");
    u(this, "onTurnOff");
    u(this, "onSettings");
    u(this, "onDownload");
    u(this, "onDownloadSubtitles");
    u(this, "onToggleSubtitles");
    u(this, "onVideoVolumeChange");
    u(this, "onTranslationVolumeChange");
    u(this, "onFromLanguageChange");
    u(this, "onToLanguageChange");
    u(this, "onAutoTranslateChange");
    u(this, "onAutoSubtitlesChange");
    u(this, "onSyncVolumeChange");
    u(this, "onShowVideoSliderChange");
    u(this, "onAudioBoosterChange");
    u(this, "onAutoVolumeChange");
    u(this, "onSmartDuckingChange");
  }
  open() {
    if (this.popup && !this.popup.closed) {
      try {
        this.popup.focus();
      } catch {
      }
      return;
    }
    const t = this.readGeometry(), e = this.buildPopupFeatures(t);
    let i = null;
    try {
      i = window.open("about:blank", "vot_overlay", e);
    } catch (gt) {
      console.warn("[VOT] popup open failed", gt);
      return;
    }
    if (!i)
      return;
    this.popup = i;
    const s = this.popup.document;
    for (s.title = "VOT"; s.firstChild; ) s.removeChild(s.firstChild);
    const o = s.createElement("html"), r = s.createElement("head"), a = s.createElement("meta");
    a.setAttribute("charset", "utf-8");
    const l = s.createElement("title");
    l.textContent = "VOT";
    const c = s.createElement("style");
    c.textContent = `
      :root {
        color-scheme: dark;
        --vot-bg: #0f172a;
        --vot-card: #111827;
        --vot-card-2: #1f2937;
        --vot-text: #f9fafb;
        --vot-muted: rgba(248, 250, 252, 0.72);
        --vot-border: rgba(255,255,255,0.08);
        --vot-accent: #2563eb;
        --vot-accent-2: #1d4ed8;
        --vot-success: #059669;
        --vot-warning: #d97706;
        --vot-danger: #dc2626;
      }
      * { box-sizing: border-box; }
      body {
        margin: 0;
        min-height: 100vh;
        padding: 14px;
        font-family: Arial, sans-serif;
        background:
          radial-gradient(circle at top right, rgba(37,99,235,.14), transparent 34%),
          linear-gradient(180deg, #0b1220, var(--vot-bg));
        color: var(--vot-text);
      }
      .vot-card {
        display: flex;
        flex-direction: column;
        gap: 12px;
        border: 1px solid var(--vot-border);
        border-radius: 16px;
        padding: 14px;
        background: linear-gradient(180deg, rgba(255,255,255,.045), rgba(255,255,255,.025));
        box-shadow: 0 16px 36px rgba(0,0,0,.28);
      }
      .vot-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
      }
      .vot-title-wrap { display: flex; flex-direction: column; gap: 3px; }
      .vot-title { font-size: 13px; opacity: .82; font-weight: 700; }
      .vot-subtitle { font-size: 11px; color: var(--vot-muted); }
      .vot-badge {
        border-radius: 999px;
        padding: 6px 10px;
        font-size: 11px;
        font-weight: 700;
        background: rgba(255,255,255,.08);
        color: var(--vot-text);
      }
      .vot-badge[data-status="loading"] { background: rgba(217,119,6,.18); color: #fbbf24; }
      .vot-badge[data-status="success"] { background: rgba(5,150,105,.18); color: #34d399; }
      .vot-badge[data-status="error"] { background: rgba(220,38,38,.18); color: #fca5a5; }
      .vot-row { display: flex; gap: 8px; align-items: center; }
      .vot-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
      .vot-field { display: flex; flex-direction: column; gap: 6px; }
      .vot-label { font-size: 12px; color: var(--vot-muted); }
      .vot-select,
      button {
        border: 1px solid rgba(255,255,255,.06);
        border-radius: 12px;
        padding: 10px 12px;
        font-size: 14px;
        background: var(--vot-card-2);
        color: var(--vot-text);
      }
      .vot-select { width: 100%; }
      button {
        cursor: pointer;
        font-weight: 600;
        transition: transform .12s ease, background .12s ease, opacity .12s ease;
      }
      button:hover { background: #273244; }
      button:active { transform: translateY(1px); }
      button:disabled, input:disabled, select:disabled { cursor: not-allowed; opacity: .45; }
      #vot-main-btn { flex: 1; background: var(--vot-accent); border-color: transparent; }
      #vot-main-btn:hover { background: var(--vot-accent-2); }
      #vot-main-btn[data-mode="turn-off"] { background: var(--vot-danger); }
      #vot-main-btn[data-mode="turn-off"]:hover { background: #b91c1c; }
      #vot-subtitles-btn[data-active="true"] {
        background: rgba(37,99,235,.18);
        border-color: rgba(96,165,250,.35);
      }
      #vot-download-btn:disabled { text-decoration: line-through; }
      #vot-status { font-size: 12px; opacity: .92; }
      #vot-hint { font-size: 12px; color: var(--vot-muted); line-height: 1.35; }
      .vot-slider-head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
      }
      .vot-slider-value { font-size: 12px; color: var(--vot-muted); }
      input[type="range"] { width: 100%; accent-color: var(--vot-accent); }
      .vot-toggle-row { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
      .vot-toggle {
        display: flex; align-items: center; gap: 8px;
        padding: 10px 12px; border-radius: 12px;
        background: rgba(255,255,255,.05); border: 1px solid rgba(255,255,255,.06);
      }
      .vot-toggle input { margin: 0; }
    `, r.append(a, l, c);
    const d = s.createElement("body"), h = s.createElement("div");
    h.className = "vot-card";
    const f = s.createElement("div");
    f.className = "vot-header";
    const g = s.createElement("div");
    g.className = "vot-title-wrap";
    const m = s.createElement("div");
    m.className = "vot-title", m.textContent = "Voice Over Translation";
    const v = s.createElement("div");
    v.className = "vot-subtitle", v.textContent = "Popup mode for Google-hosted players.", g.append(m, v);
    const S = s.createElement("div");
    S.id = "vot-badge", S.className = "vot-badge", S.dataset.status = "none", S.textContent = "idle", f.append(g, S);
    const T = s.createElement("div");
    T.className = "vot-row";
    const w = s.createElement("button");
    w.id = "vot-main-btn", w.textContent = "Translate video", T.append(w);
    const A = s.createElement("div");
    A.className = "vot-grid";
    const P = s.createElement("div");
    P.className = "vot-field";
    const _ = s.createElement("div");
    _.className = "vot-label", _.textContent = "From";
    const O = s.createElement("select");
    O.id = "vot-from-lang", O.className = "vot-select", P.append(_, O);
    const Q = s.createElement("div");
    Q.className = "vot-field";
    const Y = s.createElement("div");
    Y.className = "vot-label", Y.textContent = "To";
    const at = s.createElement("select");
    at.id = "vot-to-lang", at.className = "vot-select", Q.append(Y, at), A.append(P, Q);
    const k = s.createElement("div");
    k.className = "vot-toggle-row";
    const V = s.createElement("label");
    V.className = "vot-toggle";
    const E = s.createElement("input");
    E.type = "checkbox", E.id = "vot-auto-translate";
    const F = s.createElement("span");
    F.textContent = "Auto translate", V.append(E, F);
    const H = s.createElement("label");
    H.className = "vot-toggle";
    const G = s.createElement("input");
    G.type = "checkbox", G.id = "vot-auto-subtitles";
    const nt = s.createElement("span");
    nt.textContent = "Auto subtitles", H.append(G, nt), k.append(V, H);
    const j = s.createElement("div");
    j.className = "vot-toggle-row";
    const Lt = s.createElement("label");
    Lt.className = "vot-toggle";
    const xt = s.createElement("input");
    xt.type = "checkbox", xt.id = "vot-sync-volume";
    const Se = s.createElement("span");
    Se.textContent = "Sync volume", Lt.append(xt, Se);
    const qe = s.createElement("label");
    qe.className = "vot-toggle";
    const Wt = s.createElement("input");
    Wt.type = "checkbox", Wt.id = "vot-show-video-slider";
    const U = s.createElement("span");
    U.textContent = "Video slider", qe.append(Wt, U), j.append(Lt, qe);
    const At = s.createElement("div");
    At.className = "vot-toggle-row";
    const Ft = s.createElement("label");
    Ft.className = "vot-toggle";
    const It = s.createElement("input");
    It.type = "checkbox", It.id = "vot-audio-booster";
    const it = s.createElement("span");
    it.textContent = "Audio booster", Ft.append(It, it);
    const Pt = s.createElement("label");
    Pt.className = "vot-toggle";
    const ee = s.createElement("input");
    ee.type = "checkbox", ee.id = "vot-auto-volume";
    const Ro = s.createElement("span");
    Ro.textContent = "Auto volume", Pt.append(ee, Ro), At.append(Ft, Pt);
    const Fi = s.createElement("div");
    Fi.className = "vot-toggle-row";
    const Ni = s.createElement("label");
    Ni.className = "vot-toggle";
    const Ge = s.createElement("input");
    Ge.type = "checkbox", Ge.id = "vot-smart-ducking";
    const Bo = s.createElement("span");
    Bo.textContent = "Smart ducking", Ni.append(Ge, Bo), Fi.append(Ni);
    const Ui = s.createElement("div");
    Ui.className = "vot-row";
    const Fn = s.createElement("button");
    Fn.id = "vot-subtitles-btn", Fn.textContent = "Subtitles";
    const Ke = s.createElement("button");
    Ke.id = "vot-download-btn", Ke.textContent = "Download MP3";
    const Nn = s.createElement("button");
    Nn.id = "vot-download-subtitles-btn", Nn.textContent = "Download subtitles", Ui.append(Fn, Ke, Nn);
    const $i = s.createElement("div");
    $i.className = "vot-field";
    const Hi = s.createElement("div");
    Hi.className = "vot-slider-head";
    const Un = s.createElement("div");
    Un.id = "vot-video-volume-label", Un.className = "vot-label", Un.textContent = "Video volume";
    const Ye = s.createElement("div");
    Ye.id = "vot-video-volume-value", Ye.className = "vot-slider-value", Ye.textContent = "100%", Hi.append(Un, Ye);
    const Nt = s.createElement("input");
    Nt.id = "vot-video-volume", Nt.type = "range", Nt.min = "0", Nt.max = "100", Nt.value = "100", $i.append(Hi, Nt);
    const Wi = s.createElement("div");
    Wi.className = "vot-field";
    const zi = s.createElement("div");
    zi.className = "vot-slider-head";
    const $n = s.createElement("div");
    $n.id = "vot-translation-volume-label", $n.className = "vot-label", $n.textContent = "Translation volume";
    const je = s.createElement("div");
    je.id = "vot-translation-volume-value", je.className = "vot-slider-value", je.textContent = "100%", zi.append(
      $n,
      je
    );
    const Ut = s.createElement("input");
    Ut.id = "vot-translation-volume", Ut.type = "range", Ut.min = "0", Ut.max = "300", Ut.value = "100", Wi.append(
      zi,
      Ut
    );
    const qi = s.createElement("div");
    qi.id = "vot-status", qi.textContent = "Status: none";
    const Gi = s.createElement("div");
    Gi.id = "vot-hint", Gi.textContent = "Popup mode for Google-hosted players.", h.append(
      f,
      T,
      A,
      k,
      j,
      At,
      Fi,
      Ui,
      $i,
      Wi,
      qi,
      Gi
    ), d.append(h), o.append(r, d), s.appendChild(o), w.addEventListener("click", () => {
      w.dataset.mode === "turn-off" ? this.onTurnOff?.() : this.onTranslate?.();
    }), Ke.addEventListener("click", () => this.onDownload?.()), Nn.addEventListener(
      "click",
      () => this.onDownloadSubtitles?.()
    ), Fn.addEventListener("click", () => this.onToggleSubtitles?.()), Nt.addEventListener("input", () => {
      Ye.textContent = `${Nt.value}%`, this.onVideoVolumeChange?.(Number(Nt.value));
    }), Ut.addEventListener("input", () => {
      je.textContent = `${Ut.value}%`, this.onTranslationVolumeChange?.(Number(Ut.value));
    }), O.addEventListener(
      "change",
      () => this.onFromLanguageChange?.(O.value)
    ), at.addEventListener(
      "change",
      () => this.onToLanguageChange?.(at.value)
    ), E.addEventListener(
      "change",
      () => this.onAutoTranslateChange?.(E.checked)
    ), G.addEventListener(
      "change",
      () => this.onAutoSubtitlesChange?.(G.checked)
    ), xt.addEventListener(
      "change",
      () => this.onSyncVolumeChange?.(xt.checked)
    ), Wt.addEventListener(
      "change",
      () => this.onShowVideoSliderChange?.(Wt.checked)
    ), It.addEventListener(
      "change",
      () => this.onAudioBoosterChange?.(It.checked)
    ), ee.addEventListener(
      "change",
      () => this.onAutoVolumeChange?.(ee.checked)
    ), Ge.addEventListener(
      "change",
      () => this.onSmartDuckingChange?.(Ge.checked)
    ), s.addEventListener("keydown", (gt) => {
      const vc = gt.target instanceof HTMLInputElement || gt.target instanceof HTMLSelectElement || gt.target instanceof HTMLTextAreaElement;
      if (gt.key === "Escape") {
        gt.preventDefault(), this.close();
        return;
      }
      if (gt.key === "Enter" && !vc) {
        gt.preventDefault(), w.dataset.mode === "turn-off" ? this.onTurnOff?.() : this.onTranslate?.();
        return;
      }
      (gt.ctrlKey || gt.metaKey) && gt.key.toLowerCase() === "d" && (gt.preventDefault(), Ke.disabled || this.onDownload?.());
    }), this.attachGeometryPersistence(this.popup);
  }
  bind() {
    this.isBound || (this.isBound = !0);
  }
  setOwner(t) {
    this.ownerId = t;
  }
  isOpen() {
    return !!(this.popup && !this.popup.closed);
  }
  isOwner(t) {
    return this.ownerId === t;
  }
  setHandlers(t) {
    this.onTranslate = t.onTranslate, this.onTurnOff = t.onTurnOff, this.onSettings = t.onSettings, this.onDownload = t.onDownload, this.onDownloadSubtitles = t.onDownloadSubtitles, this.onToggleSubtitles = t.onToggleSubtitles, this.onVideoVolumeChange = t.onVideoVolumeChange, this.onTranslationVolumeChange = t.onTranslationVolumeChange, this.onFromLanguageChange = t.onFromLanguageChange, this.onToLanguageChange = t.onToLanguageChange, this.onAutoTranslateChange = t.onAutoTranslateChange, this.onAutoSubtitlesChange = t.onAutoSubtitlesChange, this.onSyncVolumeChange = t.onSyncVolumeChange, this.onShowVideoSliderChange = t.onShowVideoSliderChange, this.onAudioBoosterChange = t.onAudioBoosterChange, this.onAutoVolumeChange = t.onAutoVolumeChange, this.onSmartDuckingChange = t.onSmartDuckingChange;
  }
  updateState(t) {
    if (!this.popup || this.popup.closed) return;
    const e = this.getEl("vot-main-btn"), i = this.getEl("vot-subtitles-btn"), s = this.getEl("vot-download-btn"), o = this.getEl(
      "vot-download-subtitles-btn"
    ), r = this.getEl("vot-status"), a = this.getEl("vot-hint"), l = this.getEl("vot-from-lang"), c = this.getEl("vot-to-lang"), d = this.getEl("vot-badge"), h = this.getEl("vot-video-volume"), f = this.getEl(
      "vot-video-volume-value"
    ), g = this.getEl(
      "vot-translation-volume"
    ), m = this.getEl(
      "vot-translation-volume-value"
    ), v = this.getEl("vot-auto-translate"), S = this.getEl("vot-auto-subtitles"), T = this.getEl("vot-sync-volume"), w = this.getEl(
      "vot-show-video-slider"
    ), A = this.getEl("vot-audio-booster"), P = this.getEl("vot-auto-volume"), _ = this.getEl("vot-smart-ducking");
    this.popup.document.body.style.display = t.visible ? "block" : "none";
    const O = t.status === "loading";
    e && (e.textContent = t.label, e.dataset.mode = t.status === "success" ? "turn-off" : "translate", e.disabled = O), d && (d.dataset.status = t.status, d.textContent = this.getBadgeText(t.status)), i && (i.dataset.active = String(!!t.subtitlesEnabled), i.textContent = t.subtitlesEnabled ? "Subtitles: on" : "Subtitles: off"), s && (s.disabled = !t.canDownload || O, s.title = t.canDownload ? "Download translated audio" : "Translation audio is not available yet"), o && (o.disabled = !t.canDownloadSubtitles || O, o.title = t.canDownloadSubtitles ? "Download subtitles" : "Subtitles are not available yet"), r && (r.textContent = `Status: ${t.status}`), a && (a.textContent = t.hint ?? "Popup mode for Google-hosted players."), l && this.renderSelectOptions(
      l,
      t.fromLangOptions ?? [],
      t.fromLangValue,
      t.fromLangLabel
    ), c && this.renderSelectOptions(
      c,
      t.toLangOptions ?? [],
      t.toLangValue,
      t.toLangLabel
    ), l && (l.disabled = O), c && (c.disabled = O), i && (i.disabled = O), v && (v.checked = !!t.autoTranslateEnabled, v.disabled = O), S && (S.checked = !!t.autoSubtitlesEnabled, S.disabled = O), T && (T.checked = !!t.syncVolumeEnabled, T.disabled = O), w && (w.checked = !!t.showVideoSliderEnabled, w.disabled = O), A && (A.checked = !!t.audioBoosterEnabled, A.disabled = O), P && (P.checked = !!t.autoVolumeEnabled, P.disabled = O), _ && (_.checked = !!t.smartDuckingEnabled, _.disabled = O || !t.autoVolumeEnabled), h && typeof t.videoVolume == "number" && (h.value = String(
      Math.max(0, Math.min(100, Math.round(t.videoVolume)))
    ), h.disabled = O || t.showVideoSliderEnabled === !1, f && (f.textContent = `${h.value}%`)), g && typeof t.translationVolume == "number" && (g.value = String(
      Math.max(
        0,
        Math.min(
          Number(g.max),
          Math.round(t.translationVolume)
        )
      )
    ), g.disabled = t.canAdjustTranslationVolume === !1 || O, m && (m.textContent = `${g.value}%`));
  }
  close() {
    this.geometrySaveTimer && (clearTimeout(this.geometrySaveTimer), this.geometrySaveTimer = null);
    try {
      this.persistGeometry(), this.popup?.close();
    } catch {
    }
    this.popup = null;
  }
  renderSelectOptions(t, e, i, s) {
    const o = JSON.stringify(e);
    if ((t.dataset.signature ?? "") !== o) {
      for (; t.firstChild; )
        t.removeChild(t.firstChild);
      for (const r of e) {
        const a = t.ownerDocument.createElement("option");
        a.value = r.value, a.textContent = r.label, t.appendChild(a);
      }
      t.dataset.signature = o;
    }
    if (i && Array.from(t.options).some((r) => r.value === i))
      t.value = i;
    else if (s) {
      if (!Array.from(t.options).some(
        (a) => a.value === (i ?? "")
      )) {
        const a = t.ownerDocument.createElement("option");
        a.value = i ?? "", a.textContent = s, t.appendChild(a);
      }
      t.value = i ?? "";
    } else t.options.length > 0 && (t.selectedIndex = 0);
  }
  getEl(t) {
    return !this.popup || this.popup.closed ? null : this.popup.document.getElementById(t);
  }
  getBadgeText(t) {
    switch (t) {
      case "loading":
        return "loading";
      case "success":
        return "active";
      case "error":
        return "error";
      default:
        return "idle";
    }
  }
  buildPopupFeatures(t) {
    const e = t ?? {
      width: 500,
      height: 520,
      left: 120,
      top: 120
    };
    return [
      `width=${e.width}`,
      `height=${e.height}`,
      `left=${e.left}`,
      `top=${e.top}`,
      "resizable=yes",
      "scrollbars=yes"
    ].join(",");
  }
  readGeometry() {
    try {
      const t = window.localStorage.getItem(
        vn.GEOMETRY_STORAGE_KEY
      );
      if (!t) return null;
      const e = JSON.parse(t);
      if ([e.width, e.height, e.left, e.top].some(
        (a) => typeof a != "number"
      ))
        return null;
      const { width: i, height: s, left: o, top: r } = e;
      return i === void 0 || s === void 0 || o === void 0 || r === void 0 ? null : {
        width: Math.max(420, Math.round(i)),
        height: Math.max(420, Math.round(s)),
        left: Math.round(o),
        top: Math.round(r)
      };
    } catch {
      return null;
    }
  }
  attachGeometryPersistence(t) {
    t.addEventListener("beforeunload", () => {
      this.persistGeometry(), this.popup = null;
    }), t.addEventListener("resize", () => this.scheduleGeometryPersist()), t.addEventListener("move", () => this.scheduleGeometryPersist());
  }
  scheduleGeometryPersist() {
    this.geometrySaveTimer && clearTimeout(this.geometrySaveTimer), this.geometrySaveTimer = setTimeout(() => {
      this.geometrySaveTimer = null, this.persistGeometry();
    }, 200);
  }
  persistGeometry() {
    if (!(!this.popup || this.popup.closed))
      try {
        const t = {
          width: this.popup.outerWidth,
          height: this.popup.outerHeight,
          left: this.popup.screenX,
          top: this.popup.screenY
        };
        window.localStorage.setItem(
          vn.GEOMETRY_STORAGE_KEY,
          JSON.stringify(t)
        );
      } catch {
      }
  }
};
u(vn, "GEOMETRY_STORAGE_KEY", "vot-popup-overlay-geometry");
let Gs = vn, We;
function wS(n) {
  We = n;
}
let ps = null;
async function SS() {
  We || (ps ?? (ps = (async () => {
    try {
      const e = (await (await ut(
        "https://cloudflare-dns.com/cdn-cgi/trace",
        {
          timeout: 7e3
        }
      )).text()).split(`
`).find((i) => i.startsWith("loc="));
      wS(e?.slice(4, 6).toUpperCase());
    } catch (n) {
      console.error("[VOT] Error getting country:", n);
    }
  })().finally(() => {
    ps = null;
  })), await ps);
}
async function TS() {
  if (this.initialized) return;
  const n = this.isAudioContextSupported;
  this.data = await I.getValues({
    autoTranslate: !1,
    autoSubtitles: !1,
    dontTranslateLanguages: [ii],
    enabledDontTranslateLanguages: !0,
    enabledAutoVolume: !0,
    enabledSmartDucking: !0,
    autoVolume: Mi,
    buttonPos: "default",
    showVideoSlider: !0,
    syncVolume: !1,
    downloadWithName: Ln,
    sendNotifyOnComplete: !1,
    subtitlesMaxLength: 300,
    subtitlesSmartLayout: !0,
    highlightWords: !0,
    subtitlesFontSize: 20,
    subtitlesFontFamily: "default-sans",
    subtitlesOpacity: 20,
    subtitlesDownloadFormat: "srt",
    responseLanguage: ii,
    defaultVolume: 100,
    onlyBypassMediaCSP: n,
    newAudioPlayer: n,
    showPiPButton: !1,
    translateAPIErrors: !0,
    translationService: Oi,
    detectService: oo,
    translationHotkey: null,
    subtitlesHotkey: null,
    m3u8ProxyHost: lh,
    proxyWorkerHost: Sn,
    translateProxyEnabled: 0,
    translateProxyEnabledDefault: !0,
    audioBooster: !1,
    useLivelyVoice: !1,
    autoHideButtonDelay: ro,
    // Audio download now uses direct network requests (GM_fetch/GM_xmlhttpRequest).
    useAudioDownload: Ln,
    compatVersion: "",
    account: {},
    localeHash: "",
    localeUpdatedAt: 0
  }), this.data.compatVersion !== Tn && (this.data = await cf(this.data), await I.set("compatVersion", Tn));
  try {
    if (ii === "en" && this.data?.enabledDontTranslateLanguages && Array.isArray(this.data?.dontTranslateLanguages) && this.data.dontTranslateLanguages.length === 1 && this.data.dontTranslateLanguages[0] === "en" && typeof this.data.responseLanguage == "string" && this.data.responseLanguage !== "en") {
      const t = this.data.responseLanguage;
      this.data.dontTranslateLanguages = [t], await I.set(
        "dontTranslateLanguages",
        this.data.dontTranslateLanguages
      );
    }
  } catch {
  }
  if (this.uiManager.data = this.data, console.log("[VOT] data from db:", this.data), this.data.translateProxyEnabled, await SS(), We && eu.includes(We) && this.data.translateProxyEnabledDefault && (this.data.translateProxyEnabled = 2), C.log(
    "translateProxyEnabled",
    this.data.translateProxyEnabled,
    this.data.translateProxyEnabledDefault
  ), await this.initVOTClient(), this.uiManager.initUI(), this.uiManager.initUIEvents(), _t(this.site) && (this.uiManager.votOverlayView?.updateButtonOpacity(1), this.uiManager.votOverlayView?.votButton?.container && (this.uiManager.votOverlayView.votButton.container.hidden = !1), this.overlayVisibility?.queueAutoHide()), Ls()) {
    const t = globalThis.__votPopupOverlayBridge ?? new Gs();
    globalThis.__votPopupOverlayBridge = t, this.popupOverlayBridge = t, this.popupOverlayBridge.setOwner(this.popupOwnerId), this.popupOverlayBridge.bind(), this.popupOverlayBridge.setHandlers({
      onTranslate: () => {
        this.popupOverlayBridge?.isOwner(this.popupOwnerId) && this.uiManager.handleTranslationBtnClick();
      },
      onTurnOff: () => {
        this.popupOverlayBridge?.isOwner(this.popupOwnerId) && this.stopTranslation();
      },
      onDownload: () => {
        this.uiManager.handleDownloadTranslationClick?.();
      },
      onDownloadSubtitles: () => {
        this.uiManager.handleDownloadSubtitlesClick?.();
      },
      onToggleSubtitles: () => {
        (async () => {
          try {
            this.resetSubtitlesWidget(), await this.ensureSubtitlesForCurrentLangPair(), await this.toggleSubtitlesForCurrentLangPair();
          } finally {
            this.syncPopupOverlayState({
              subtitlesEnabled: !!(this.yandexSubtitles && Array.isArray(this.yandexSubtitles.subtitles) && this.yandexSubtitles.subtitles.length > 0),
              canDownloadSubtitles: !!this.yandexSubtitles
            });
          }
        })();
      },
      onFromLanguageChange: (e) => {
        this.videoData && (this.videoData.detectedLanguage = e, this.videoManager.rememberUserLanguageSelection(
          this.videoData.videoId,
          e
        )), this.setSelectMenuValues(
          e,
          this.videoData?.responseLanguage ?? this.translateToLang
        ), this.syncPopupOverlayState({ fromLangValue: e });
      },
      onToLanguageChange: (e) => {
        this.translateToLang = e, this.videoData && (this.videoData.responseLanguage = e), this.data.responseLanguage = e, I.set("responseLanguage", e), this.setSelectMenuValues(
          this.videoData?.detectedLanguage ?? this.translateFromLang,
          e
        ), this.syncPopupOverlayState({ toLangValue: e });
      },
      onAutoTranslateChange: (e) => {
        this.data.autoTranslate = e, I.set("autoTranslate", e), this.syncPopupOverlayState({ autoTranslateEnabled: e });
      },
      onAutoSubtitlesChange: (e) => {
        this.data.autoSubtitles = e, I.set("autoSubtitles", e), this.syncPopupOverlayState({ autoSubtitlesEnabled: e });
      },
      onSyncVolumeChange: (e) => {
        this.data.syncVolume = e, I.set("syncVolume", e), this.syncPopupOverlayState({ syncVolumeEnabled: e });
      },
      onShowVideoSliderChange: (e) => {
        this.data.showVideoSlider = e, I.set("showVideoSlider", e), this.uiManager.votOverlayView?.videoVolumeSlider && (this.uiManager.votOverlayView.videoVolumeSlider.hidden = !e || this.uiManager.votOverlayView.votButton?.status !== "success"), this.syncPopupOverlayState({ showVideoSliderEnabled: e });
      },
      onAudioBoosterChange: (e) => {
        this.data.audioBooster = e, I.set("audioBooster", e);
        const i = this.uiManager.votOverlayView?.translationVolumeSlider;
        i && (i.max = e ? 300 : 100, !e && Number(i.value) > 100 && (i.value = 100, this.audioPlayer?.player && (this.audioPlayer.player.volume = 1), this.data.defaultVolume = 100)), this.syncPopupOverlayState({
          audioBoosterEnabled: e,
          translationVolume: Number(
            this.uiManager.votOverlayView?.translationVolumeSlider?.value ?? this.data.defaultVolume ?? 100
          )
        });
      },
      onAutoVolumeChange: (e) => {
        this.data.enabledAutoVolume = e, I.set("enabledAutoVolume", e), this.setupAudioSettings(), this.syncPopupOverlayState({ autoVolumeEnabled: e });
      },
      onSmartDuckingChange: (e) => {
        this.data.enabledSmartDucking = e, I.set("enabledSmartDucking", e), this.syncPopupOverlayState({ smartDuckingEnabled: e });
      },
      onVideoVolumeChange: (e) => {
        this.setVideoVolume(e / 100), this.onVideoVolumeSliderSynced(e), this.uiManager.votOverlayView?.videoVolumeSlider && (this.uiManager.votOverlayView.videoVolumeSlider.value = e), this.syncPopupOverlayState({ videoVolume: e });
      },
      onTranslationVolumeChange: (e) => {
        this.data.defaultVolume = e, this.audioPlayer?.player && (this.audioPlayer.player.volume = e / 100), this.onTranslationVolumeSliderSynced(e), this.uiManager.votOverlayView?.translationVolumeSlider && (this.uiManager.votOverlayView.translationVolumeSlider.value = e), this.syncPopupOverlayState({ translationVolume: e });
      }
    }), this.uiManager.votOverlayView?.votButton?.container && (this.uiManager.votOverlayView.votButton.container.style.display = "none"), this.syncPopupOverlayState({
      status: "none",
      label: p.get("translateVideo"),
      hint: "Popup mode for Google-hosted players."
    });
  }
  this.translateToLang = this.data.responseLanguage ?? "ru", this.initExtraEvents(), this.site.host === "custom" && this.overlayVisibility?.queueAutoHide(), this.initialized = !0;
}
function kS(n, t = "Operation timed out") {
  return new Promise(
    (e, i) => setTimeout(() => i(new Error(t)), n)
  );
}
const LS = "und", AS = /* @__PURE__ */ new Map(), xS = /* @__PURE__ */ new Map(), VS = (n) => {
  if (n)
    try {
      return Intl.getCanonicalLocales(n)[0];
    } catch {
      return;
    }
}, CS = (n) => {
  const t = VS(n);
  if (t)
    return Intl.Segmenter.supportedLocalesOf([t])[0];
}, tc = (n, t) => {
  const e = CS(n), i = `${t}:${e ?? LS}`, s = t === "sentence" ? xS : AS, o = s.get(i);
  if (o) return o;
  const r = new Intl.Segmenter(e, { granularity: t });
  return s.set(i, r), r;
}, ec = (n, t) => n ? Array.from(tc(t, "word").segment(n), (e) => ({
  text: e.segment,
  index: e.index,
  isWordLike: !!e.isWordLike
})) : [], ES = (n, t) => n ? Array.from(tc(t, "sentence").segment(n), (e) => ({
  text: e.segment,
  index: e.index
})) : [], ki = /\s/u, IS = /^[,.:;!?%)\]}>В»]/u, PS = /[([{'"В«вЂћ-]$/u, ll = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/u, nc = (n) => !!n.trim(), MS = (n, t) => {
  const e = n.at(-1) ?? "", i = t[0] ?? "";
  return !(!e || !i || ki.test(e) || ki.test(i) || PS.test(n) || IS.test(t) || ll.test(e) && ll.test(i));
}, OS = (n) => {
  let t = "", e = "";
  const i = [];
  for (const s of n) {
    const o = s.text.trim();
    if (!o) continue;
    t && MS(e, o) && (t += " ");
    const r = t.length;
    t += o;
    const a = t.length;
    i.push({
      line: {
        ...s,
        text: o
      },
      text: o,
      start: r,
      end: a
    }), e = o;
  }
  return { streamText: t, spans: i };
}, DS = (n, t, e) => {
  let i = t, s = e;
  for (; i < s && ki.test(n[i] ?? ""); )
    i += 1;
  for (; s > i && ki.test(n[s - 1] ?? ""); )
    s -= 1;
  return i >= s ? null : {
    start: i,
    end: s
  };
}, _S = (n, t, e) => {
  const i = Math.max(t, n.start), s = Math.min(e, n.end);
  if (i >= s)
    return null;
  const o = i - n.start, r = s - n.start, a = n.text.slice(o, r);
  if (!a)
    return null;
  const l = Math.max(n.text.length, 1), c = n.line.startMs + Math.round(n.line.durationMs * o / l), d = n.line.startMs + Math.round(n.line.durationMs * r / l);
  return {
    text: a,
    startMs: c,
    durationMs: Math.max(0, d - c),
    isWordLike: nc(a)
  };
}, RS = (n, t, e) => {
  const i = e.index, s = i + e.text.length, o = DS(n, i, s);
  if (!o)
    return null;
  const r = n.slice(o.start, o.end);
  if (!nc(r))
    return null;
  const a = [];
  let l = "0";
  for (const h of t) {
    const f = _S(h, o.start, o.end);
    f && (a.length === 0 && (l = h.line.speakerId), a.push(f));
  }
  if (!a.length)
    return null;
  const c = Math.min(...a.map((h) => h.startMs)), d = Math.max(
    ...a.map((h) => h.startMs + Math.max(0, h.durationMs))
  );
  return {
    text: r,
    startMs: c,
    durationMs: Math.max(0, d - c),
    speakerId: l,
    tokens: a
  };
}, BS = (n, t) => {
  const { streamText: e, spans: i } = OS(n);
  if (!e || !i.length)
    return [];
  const o = ES(e, t).map((r) => RS(e, i, r)).filter((r) => r !== null);
  return o.length ? o : i.map(({ line: r }) => r);
}, FS = (n) => n === "json" || n === "srt" || n === "vtt" || n === "ass", NS = (n) => !!(n && typeof n == "object"), US = (n) => typeof n == "number" && Number.isFinite(n) ? n : 0, Li = (n) => Math.max(0, US(n)), $S = (n) => NS(n) ? typeof n.source == "string" && FS(n.format) && typeof n.language == "string" && typeof n.url == "string" && (n.translatedFromLanguage === void 0 || typeof n.translatedFromLanguage == "string") && (n.isAutoGenerated === void 0 || typeof n.isAutoGenerated == "boolean") : !1, HS = (n, t, e) => {
  const i = n.subtitles;
  if (!Array.isArray(i) || i.length === 0) return null;
  const s = t ?? e;
  if (s) {
    const o = i.find(
      (a) => a.language === s && typeof a.translatedFromLanguage == "string"
    );
    if (o) return o;
    const r = i.find((a) => a.language === s);
    if (r) return r;
  }
  return i[0] ?? null;
}, ic = (n) => {
  try {
    return new URL(n, globalThis.location.href).toString();
  } catch {
    return String(n || "");
  }
}, WS = (n, t) => {
  const e = ic(t);
  if (!e)
    return !1;
  try {
    if (typeof n.isDirectMediaUrl == "function") {
      if (!n.isDirectMediaUrl(e))
        return !1;
    } else
      return !1;
    return new URL(e).hostname !== globalThis.location.hostname;
  } catch {
    return !1;
  }
}, zS = (n, t) => {
  try {
    return String(t?.host || globalThis.location?.hostname || "") === "custom" ? !0 : WS(n, t?.url);
  } catch {
    return !0;
  }
}, qS = (n) => {
  const t = Dt.getPoToken();
  if (!t) return n;
  let e = t;
  for (let o = 0; o < 10; o += 1) {
    let r;
    try {
      r = decodeURIComponent(e);
    } catch {
      break;
    }
    if (r === e)
      break;
    e = r;
  }
  const i = Dt.getDeviceParams(), s = typeof i == "string" ? i.replace(/^[?&]+/u, "") : "";
  try {
    const o = new URL(n);
    if (o.searchParams.set("potc", "1"), o.searchParams.set("pot", e), s) {
      const r = new URLSearchParams(s);
      for (const [a, l] of r.entries())
        o.searchParams.set(a, l);
    }
    return o.toString();
  } catch {
    const o = n.includes("?") ? "&" : "?", r = s ? `&${s}` : "";
    return `${n}${o}potc=1&pot=${encodeURIComponent(e)}${r}`;
  }
}, ul = (n, t) => n - t, Qn = (n, t) => n < t ? -1 : n > t ? 1 : 0, GS = (n, t) => {
  const e = Math.min(n.length, t.length);
  for (let i = 0; i < e; i += 1) {
    const s = n[i] - t[i];
    if (s !== 0) return s;
  }
  return n.length !== t.length ? n.length - t.length : 0;
}, KS = (n, t, e) => n ? t === 0 ? e ? 1 : 0 : e ? 0 : 1 : 0, YS = (n, t, e, i) => !n || !t || e === i ? 0 : 1, jS = (n, t) => {
  const e = n.source === "yandex", i = e ? 0 : 1, s = n.language === lo ? 0 : 1, o = !!n.translatedFromLanguage, r = t && n.language === t ? 0 : 1, a = KS(
    e,
    r,
    o
  ), l = YS(
    e,
    o,
    n.translatedFromLanguage,
    t
  ), c = e && !o ? r : 0, d = e ? 0 : +!!n.isAutoGenerated;
  return [
    i,
    s,
    a,
    l,
    c,
    d
  ];
}, XS = (n, t, e) => ({
  descriptor: n,
  index: t,
  rank: jS(n, e),
  language: n.language,
  translatedFromLanguage: n.translatedFromLanguage ?? "",
  source: n.source,
  url: n.url,
  isAutoGenerated: +!!n.isAutoGenerated
}), JS = (n, t) => {
  const e = n.map(
    (i, s) => XS(i, s, t)
  );
  return e.sort((i, s) => {
    const o = GS(i.rank, s.rank);
    if (o !== 0) return o;
    const r = Qn(i.language, s.language) || Qn(
      i.translatedFromLanguage,
      s.translatedFromLanguage
    ) || Qn(i.source, s.source) || Qn(i.url, s.url) || ul(i.isAutoGenerated, s.isAutoGenerated);
    return r !== 0 ? r : ul(i.index, s.index);
  }), e.map((i) => i.descriptor);
}, ZS = (n, t) => typeof n == "boolean" ? n : !!t.trim(), QS = (n) => {
  if (!n || typeof n != "object")
    return {
      text: "",
      startMs: 0,
      durationMs: 0,
      isWordLike: !1
    };
  const t = n, e = typeof t.text == "string" ? t.text : "";
  return {
    text: e,
    startMs: Li(t.startMs),
    durationMs: Li(t.durationMs),
    isWordLike: ZS(t.isWordLike, e)
  };
}, tT = (n) => {
  if (!n || typeof n != "object")
    return {
      text: "",
      startMs: 0,
      durationMs: 0,
      speakerId: "0",
      tokens: []
    };
  const t = n, e = Array.isArray(t.tokens) ? t.tokens.map(QS) : [];
  return {
    text: typeof t.text == "string" ? t.text : "",
    startMs: Li(t.startMs),
    durationMs: Li(t.durationMs),
    speakerId: typeof t.speakerId == "string" ? t.speakerId : "0",
    tokens: e
  };
}, cl = (n) => {
  if (!n || typeof n != "object")
    return { format: "json", subtitles: [] };
  const t = n, e = Array.isArray(t.subtitles) ? t.subtitles.map(tT) : [];
  return { format: t.format ?? "json", subtitles: e };
}, eT = /<(?:\d{1,2}:)?\d{2}:\d{2}(?:[.,]\d{1,3})?>/gu, nT = 120, iT = /\s+([,.:;!?])/gu, sT = /[ \t]*\n[ \t]*/gu, oT = /[ \t]{2,}/gu, rT = /\n{3,}/gu, aT = /\s+/gu, lT = (n) => n.includes("<") ? typeof DOMParser < "u" ? new DOMParser().parseFromString(n, "text/html").body.textContent ?? "" : n.replaceAll(/<\/?[^>]+>/gu, "") : n, dl = (n) => {
  let t = n;
  return t.includes("<") && (t = lT(
    t.replaceAll(eT, "")
  )), t.replaceAll(iT, "$1").replaceAll(sT, `
`).replaceAll(oT, " ").replaceAll(rT, `

`).trim();
}, uT = (n) => n.toLowerCase().replaceAll(aT, " ").trim(), cT = (n, t) => !t || n.tStartMs + n.dDurationMs <= t.tStartMs ? Math.max(0, n.dDurationMs) : Math.max(0, t.tStartMs - n.tStartMs), dT = (n, t, e) => {
  const i = [];
  let s = "", o = e;
  for (let r = 0; r < t.length; r += 1) {
    const a = t[r], l = typeof a.utf8 == "string" ? a.utf8 : "";
    if (!l) continue;
    const c = Math.max(0, a.tOffsetMs ?? 0);
    let d = e;
    const h = t[r + 1];
    if (h?.tOffsetMs !== void 0) {
      const g = Math.max(c, h.tOffsetMs);
      d = Math.max(0, g - c), o = Math.max(o - d, 0);
    }
    let f = Math.max(0, o);
    h && (f = Math.max(0, d)), i.push({
      text: l,
      startMs: n.tStartMs + c,
      durationMs: f,
      isWordLike: !!l.trim()
    }), s += l;
  }
  return { text: s, sourceTokens: i };
}, hT = (n) => n.durationMs > 0, fT = (n) => n.text ? He(n.text) : n.tokens.length ? He(
  n.tokens.map((t) => t.text).join("")
) : "", Ks = (n, t, e) => {
  if (!n.length) return [];
  const i = Math.max(0, e), s = n.map((l) => Math.max(l.length, 1)), o = s.reduce((l, c) => l + c, 0), r = new Array(s.length + 1).fill(0);
  for (let l = 0; l < s.length; l += 1)
    r[l + 1] = r[l] + s[l];
  const a = [];
  for (let l = 0; l < n.length; l += 1) {
    const c = Math.round(i * r[l] / o), d = l === n.length - 1 ? i : Math.round(i * r[l + 1] / o);
    a.push({
      startMs: t + c,
      durationMs: Math.max(0, d - c)
    });
  }
  return a;
}, gT = (n) => {
  const t = [];
  let e = 0;
  for (let i = 0; i < n.length; i += 1)
    n[i] === `
` && (e < i && t.push({
      text: n.slice(e, i),
      startOffset: e,
      endOffset: i
    }), t.push({
      text: `
`,
      startOffset: i,
      endOffset: i + 1
    }), e = i + 1);
  return e < n.length && t.push({
    text: n.slice(e),
    startOffset: e,
    endOffset: n.length
  }), t.length ? t : [
    {
      text: n,
      startOffset: 0,
      endOffset: n.length
    }
  ];
}, mT = (n, t) => {
  const e = [];
  for (const i of n) {
    const s = He(i.text);
    if (!s || !hT(i)) continue;
    const o = ec(s, t).filter(
      (a) => a.isWordLike && a.text.trim()
    );
    if (!o.length) continue;
    const r = Ks(
      o.map((a) => a.text),
      i.startMs,
      i.durationMs
    );
    e.push(...r);
  }
  return e;
}, pT = (n, t, e) => {
  if (!e) return [];
  const i = t.language, s = n.metadata?.styledSpans ?? _n(n.metadata?.rawText ?? n.text ?? e).styledSpans, o = ec(e, i);
  if (!o.length) return [];
  const r = Ks(
    o.map((h) => h.text),
    n.startMs,
    n.durationMs
  ), a = [];
  for (let h = 0; h < o.length; h += 1) {
    const f = o[h], g = r[h]?.startMs ?? n.startMs, m = r[h]?.durationMs ?? 0, v = gT(f.text);
    if (v.length === 1 && v[0].text === f.text) {
      a.push({
        text: f.text,
        startMs: g,
        durationMs: m,
        isWordLike: f.isWordLike,
        style: za(
          s,
          f.index,
          f.index + f.text.length
        )
      });
      continue;
    }
    const S = Ks(
      v.map((T) => T.text === `
` ? "" : T.text),
      g,
      m
    );
    for (let T = 0; T < v.length; T += 1) {
      const w = v[T], A = w.text === `
`;
      a.push({
        text: w.text,
        startMs: S[T]?.startMs ?? g,
        durationMs: A ? 0 : S[T]?.durationMs ?? 0,
        isWordLike: !A && f.isWordLike,
        style: A ? void 0 : za(
          s,
          f.index + w.startOffset,
          f.index + w.endOffset
        )
      });
    }
  }
  const l = mT(n.tokens, i);
  if (!l.length) return a;
  const c = a.reduce((h, f, g) => (f.isWordLike && f.text.trim() && h.push(g), h), []);
  if (!c.length) return a;
  const d = c.length;
  for (let h = 0; h < d; h += 1) {
    const f = c[h], g = Math.floor(
      h * l.length / d
    ), m = l[Math.min(g, l.length - 1)];
    a[f] = {
      ...a[f],
      startMs: m.startMs,
      durationMs: m.durationMs
    };
  }
  return a;
}, yT = async (n, t) => {
  const e = await ut(n, { timeout: 7e3 });
  if (t === "vtt" || t === "srt" || t === "ass") {
    const i = await e.text();
    return tw(i, t);
  }
  return e.json();
}, bT = (n, t) => {
  if (t.source === "youtube")
    return ze.formatYoutubeSubtitles(
      n,
      !!t.isAutoGenerated
    );
  if (t.format === "srt" || t.format === "vtt" || t.format === "ass")
    return Ka(cl(n));
  const e = cl(n);
  return t.source === "vk" && t.format === "json" ? ze.cleanJsonSubtitles(e) : Ka(e);
}, vT = (n, t) => {
  const e = ze.autoMerge(n, t);
  return {
    ...e,
    subtitles: ze.processTokens(e, t)
  };
}, wT = (n) => {
  const t = [], e = /* @__PURE__ */ new Set();
  for (const i of n.subtitles ?? [])
    i.language && !e.has(i.language) && (e.add(i.language), t.push({
      source: "yandex",
      format: "json",
      language: i.language,
      url: i.url
    })), i.translatedLanguage && t.push({
      source: "yandex",
      format: "json",
      language: i.translatedLanguage,
      translatedFromLanguage: i.language,
      url: i.translatedUrl ?? i.url
    });
  return t;
}, ze = {
  processTokens(n, t) {
    const e = [];
    for (const i of n.subtitles) {
      const s = fT(i), o = pT(i, t, s);
      e.push({
        ...i,
        text: s,
        tokens: o
      });
    }
    return e;
  },
  formatYoutubeSubtitles(n, t = !1) {
    const e = n.events ?? [];
    if (!e.length)
      return console.error("[VOT] Invalid YouTube subtitles format:", n), { format: "json", subtitles: [] };
    const i = [];
    for (let s = 0; s < e.length; s += 1) {
      const o = e[s], r = o.segs;
      if (!r?.length) continue;
      const a = e[s + 1], l = cT(o, a), { text: c, sourceTokens: d } = dT(
        o,
        r,
        l
      ), h = c.trim();
      h && i.push({
        text: h,
        startMs: o.tStartMs,
        durationMs: l,
        speakerId: "0",
        tokens: t ? d : []
      });
    }
    return {
      format: "json",
      subtitles: i
    };
  },
  autoMerge(n, t) {
    return !t.isAutoGenerated || n.subtitles.length < 2 || !n.subtitles.some((e) => e.tokens.length > 0) ? n : {
      ...n,
      subtitles: BS(
        n.subtitles,
        t.language
      )
    };
  },
  cleanJsonSubtitles(n) {
    const t = (o) => o.startMs + Math.max(0, o.durationMs), e = (o) => {
      let r = 0;
      for (const a of o)
        r += a.text.length;
      return r;
    }, i = [];
    for (const o of n.subtitles) {
      const r = dl(o.text);
      if (!r) continue;
      const a = [];
      for (const l of o.tokens) {
        const c = dl(l.text);
        c && a.push({
          ...l,
          text: c
        });
      }
      i.push({
        line: {
          ...o,
          text: r,
          tokens: a
        },
        comparableText: uT(r),
        tokensTextLength: e(a)
      });
    }
    const s = [];
    for (const o of i) {
      const {
        line: r,
        comparableText: a,
        tokensTextLength: l
      } = o;
      if (!a) continue;
      const c = s.at(-1);
      if (!c) {
        s.push(o);
        continue;
      }
      const d = t(c.line), h = t(r), f = c.comparableText === a, g = r.startMs <= d + nT;
      if (!f || !g) {
        s.push(o);
        continue;
      }
      const m = Math.min(c.line.startMs, r.startMs), v = Math.max(d, h), S = l >= c.tokensTextLength ? r.tokens : c.line.tokens;
      c.line = {
        ...c.line,
        startMs: m,
        durationMs: Math.max(0, v - m),
        tokens: S
      }, c.tokensTextLength = Math.max(
        c.tokensTextLength,
        l
      );
    }
    return {
      ...n,
      subtitles: s.map(({ line: o }) => o)
    };
  },
  async fetchSubtitles(n, t, e) {
    const i = $S(n) ? n : HS(
      n,
      t,
      e
    );
    if (!i)
      return { format: "json", subtitles: [] };
    const { source: s, format: o } = i;
    let { url: r } = i;
    s === "youtube" && (r = qS(r));
    try {
      const a = await yT(r, o), l = bT(a, i), c = vT(
        l,
        i
      );
      return C.log("[VOT] Processed subtitles:", c), c;
    } catch (a) {
      return console.error("[VOT] Failed to process subtitles:", a), { format: "json", subtitles: [] };
    }
  },
  async getSubtitles(n, t) {
    const {
      host: e,
      url: i,
      detectedLanguage: s,
      videoId: o,
      duration: r,
      subtitles: a = []
    } = t;
    try {
      const l = {
        videoData: {
          host: e,
          url: i,
          videoId: o,
          duration: r
        },
        requestLang: s
      }, c = n, h = zS(
        c,
        t
      ) && typeof c.getSubtitlesYAImpl == "function" ? c.getSubtitlesYAImpl({
        videoData: {
          ...t,
          url: ic(t.url)
        },
        requestLang: s,
        headers: {}
      }) : n.getSubtitles(l), g = await Promise.race([
        h,
        kS(5e3, "Timeout")
      ]);
      C.log("[VOT] Subtitles response:", g), g.waiting && console.error("[VOT] Failed to get Yandex subtitles");
      const v = [...wT(g), ...a];
      return JS(v, s);
    } catch (l) {
      let c = "Error in getSubtitles function";
      throw l instanceof Error && l.message === "Timeout" && (c = "Failed to get Yandex subtitles: timeout"), console.error(`[VOT] ${c}`, l), l;
    }
  }
}, Ys = "https://vtrans.s3-private.mds.yandex.net/tts/prod/", Ai = "/video-translation/audio-proxy/", hl = "https://brosubs.s3-private.mds.yandex.net/vtrans/", ST = "/video-subtitles/subtitles-proxy/";
function Vo(n) {
  return n ?? Sn;
}
function sc(n) {
  return n.translateProxyEnabled === 2;
}
function TT(n, t) {
  return !sc(t) || !n.startsWith(Ys) ? n : n.replace(
    Ys,
    `https://${Vo(t.proxyWorkerHost)}${Ai}`
  );
}
function kT(n) {
  const t = String(n || "");
  if (!t) return t;
  try {
    const e = new URL(t);
    return e.pathname.startsWith(Ai) ? (e.host = "vtrans.s3-private.mds.yandex.net", e.pathname = `/tts/prod/${e.pathname.slice(Ai.length).replace(/^\/+/, "")}`, e.protocol = "https:", e.toString()) : t;
  } catch {
    return t;
  }
}
function LT(n, t) {
  return n.startsWith(Ys) || n.startsWith(
    `https://${Vo(t.proxyWorkerHost)}${Ai}`
  );
}
function AT(n, t) {
  if (!sc(t) || !n.startsWith(hl))
    return n;
  const e = n.slice(hl.length);
  return `https://${Vo(t.proxyWorkerHost)}${ST}${e}`;
}
const pt = "disabled", xT = /* @__PURE__ */ new Set([
  "srt",
  "vtt",
  "ass",
  "json"
]), VT = /^\d+$/u, js = /* @__PURE__ */ new WeakMap(), fl = /* @__PURE__ */ new WeakMap();
function gl() {
  return /(?:^|\.)vkvideo\.ru$|(?:^|\.)vk\.(?:com|ru)$/i.test(
    String(globalThis.location.hostname || "")
  );
}
function CT(n) {
  const t = n.videoData;
  if (!t?.videoId)
    return null;
  const e = Eo(n);
  if (!e)
    return null;
  const i = Co(n);
  return i ? n.getSubtitlesCacheKey(
    t.videoId,
    e,
    i
  ) : null;
}
function Co(n) {
  const t = n.videoData;
  return n.getPreferredSubtitlesLanguage(
    t?.detectedLanguage,
    t?.responseLanguage
  ) ?? t?.responseLanguage ?? n.translateToLang;
}
function Eo(n) {
  const t = String(n.videoData?.detectedLanguage || "").trim().toLowerCase();
  if (t && t !== "auto")
    return t;
  const e = String(n.translateFromLang || "").trim().toLowerCase();
  return e && e !== "auto" ? e : "auto";
}
function ET(n) {
  return n !== null && typeof n == "object";
}
function Io(n) {
  if (!ET(n))
    return null;
  const t = n, e = t.format;
  return typeof t.source != "string" || typeof t.language != "string" || typeof t.url != "string" || typeof e != "string" || !xT.has(e) ? null : {
    source: t.source,
    format: e,
    language: t.language,
    url: t.url,
    translatedFromLanguage: typeof t.translatedFromLanguage == "string" ? t.translatedFromLanguage : void 0,
    isAutoGenerated: typeof t.isAutoGenerated == "boolean" ? t.isAutoGenerated : void 0
  };
}
function oc(n) {
  const t = [];
  for (let e = 0; e < n.length; e += 1) {
    const i = Io(n[e]);
    i && t.push({
      descriptor: i,
      index: e
    });
  }
  return t;
}
function IT(n) {
  return {
    index: n.index,
    language: n.descriptor.language,
    translatedFromLanguage: n.descriptor.translatedFromLanguage ?? "",
    source: n.descriptor.source,
    isAutoGenerated: !!n.descriptor.isAutoGenerated,
    url: n.descriptor.url
  };
}
function yn(n) {
  const t = globalThis;
  if (n.tracks && (t.__VOT_SUBTITLE_TRACKS__ = n.tracks), "selected" in n) {
    t.__VOT_LAST_SUBTITLE_TRACK__ = n.selected;
    const e = typeof n.selected?.effectiveUrl == "string" ? n.selected.effectiveUrl : null;
    t.__PVL_LAST_TRANSLATED_SUBTITLES_URL = e, t.__VOT_LAST_EXTERNAL_SUBTITLE_URL__ = e;
  }
}
function PT(n, t) {
  const e = t.map(IT);
  yn({ tracks: e });
  const i = e.map(
    (s) => [
      s.index,
      s.language,
      s.translatedFromLanguage,
      s.source,
      s.isAutoGenerated ? "1" : "0",
      s.url
    ].join("|")
  ).join("||");
  fl.get(n) !== i && fl.set(n, i);
}
function Xs(...n) {
  const t = [], e = /* @__PURE__ */ new Set();
  for (const i of n)
    for (const s of i) {
      const o = Io(s);
      if (!o)
        continue;
      const r = [
        o.source,
        o.language,
        o.translatedFromLanguage ?? "",
        o.url
      ].join("|");
      e.has(r) || (e.add(r), t.push(o));
    }
  return t;
}
function MT(n) {
  if (!VT.test(n))
    return null;
  const t = Number(n);
  return Number.isSafeInteger(t) ? t : null;
}
function OT(n, t) {
  return !Number.isInteger(t) || t < 0 || t >= n.length ? null : Io(n[t]);
}
function DT(n) {
  const t = (js.get(n) ?? 0) + 1;
  return js.set(n, t), t;
}
function _T(n, t) {
  return js.get(n) === t;
}
function RT() {
  return {
    label: p.get("VOTSubtitlesDisabled"),
    value: pt,
    selected: !0,
    disabled: !1
  };
}
function BT(n, t = pt) {
  const e = [
    {
      ...RT(),
      selected: t === pt
    }
  ];
  for (const { descriptor: i, index: s } of n)
    e.push({
      label: FT(i),
      value: String(s),
      selected: String(s) === t,
      disabled: !1
    });
  return e;
}
function rc(n) {
  const e = n[Symbol.iterator]().next();
  return e.done ? void 0 : e.value;
}
function FT(n) {
  const t = p.getLangLabel(n.language), e = n.translatedFromLanguage ? ` ${p.get("VOTTranslatedFrom")} ${p.getLangLabel(
    n.translatedFromLanguage
  )}` : "", i = n.source === "yandex" ? "" : `, ${globalThis.location.hostname}`, s = n.isAutoGenerated ? ` (${p.get("VOTAutogenerated")})` : "";
  return `${t}${e}${i}${s}`;
}
function In(n) {
  return (n ?? "").toLowerCase();
}
function xi(n) {
  return In(n).split(/[-_]/)[0];
}
function Gt(n, t) {
  if (!n || !t) return !1;
  const e = In(n), i = In(t);
  return e === i || xi(e) === xi(i);
}
function NT(n, t, e) {
  if (!n.length) return null;
  const i = In(t), s = In(e), o = i === "auto" || i === "", r = xi(i), a = xi(s), l = (w) => w.source === "yandex", c = (w) => !!w.isAutoGenerated, d = (w, A, P) => Gt(w.language, P) ? o ? !0 : Gt(w.translatedFromLanguage, A) : !1, h = (w, A) => Gt(w.language, A) ? w.translatedFromLanguage ? Gt(w.translatedFromLanguage, A) : !0 : !1, f = (w) => n.find(({ descriptor: A }) => w(A))?.index ?? null, g = () => {
    const w = f(
      (A) => !l(A) && Gt(A.language, s) && !c(A)
    );
    return w ?? f(
      (A) => !l(A) && Gt(A.language, s) && c(A)
    );
  }, m = f((w) => l(w) && d(w, i, s));
  if (m != null) return m;
  if (!o && r && a && r === a) {
    const w = f(
      (O) => h(O, s) && !c(O)
    );
    if (w != null) return w;
    const A = f(
      (O) => h(O, s) && c(O)
    );
    if (A != null) return A;
    const P = g();
    if (P != null) return P;
    const _ = f(
      (O) => l(O) && Gt(O.language, s)
    );
    if (_ != null) return _;
  }
  const v = f((w) => l(w) && Gt(w.language, s));
  if (v != null) return v;
  const S = f((w) => !l(w) && d(w, i, s));
  if (S != null) return S;
  const T = g();
  return T ?? null;
}
async function UT(n) {
  const t = DT(this), e = this.uiManager.votOverlayView;
  if (!e?.subtitlesSelect || !e.downloadSubtitlesButton)
    return this;
  if (e.subtitlesSelect.setSelectedValue(n), n === pt)
    return this.hasSubtitlesWidget() && this.subtitlesWidget?.setContent(null), e.downloadSubtitlesButton.hidden = !0, this.yandexSubtitles = null, yn({ selected: null }), this;
  const i = MT(n);
  if (i == null)
    return this.hasSubtitlesWidget() && this.subtitlesWidget?.setContent(null), e.downloadSubtitlesButton.hidden = !0, this.yandexSubtitles = null, this;
  const s = OT(
    this.subtitles,
    i
  );
  if (!s)
    return this.hasSubtitlesWidget() && this.subtitlesWidget?.setContent(null), e.downloadSubtitlesButton.hidden = !0, this.yandexSubtitles = null, yn({ selected: null }), this;
  let o = { ...s };
  const r = AT(o.url, {
    translateProxyEnabled: this.data?.translateProxyEnabled,
    proxyWorkerHost: this.data?.proxyWorkerHost
  });
  r !== o.url && (o = {
    ...o,
    url: r
  }, console.log(`[VOT] Subs proxied via ${o.url}`));
  const a = {
    index: i,
    language: s.language,
    translatedFromLanguage: s.translatedFromLanguage ?? "",
    source: s.source,
    isAutoGenerated: !!s.isAutoGenerated,
    originalUrl: s.url,
    effectiveUrl: o.url
  };
  yn({ selected: a });
  let l;
  try {
    l = await ze.fetchSubtitles(o);
  } catch (d) {
    return console.error("[VOT][subtitles][fetch failed]", o, d), this;
  }
  return _T(this, t) ? Array.isArray(l.subtitles) && l.subtitles.length > 0 ? (this.yandexSubtitles = l, this.getSubtitlesWidget().setContent(
    this.yandexSubtitles,
    o.language
  ), e.downloadSubtitlesButton.hidden = !1, this) : (this.hasSubtitlesWidget() && this.subtitlesWidget?.setContent(null), e.subtitlesSelect.setSelectedValue(pt), e.downloadSubtitlesButton.hidden = !0, this.yandexSubtitles = null, this) : this;
}
async function $T() {
  const n = this.uiManager.votOverlayView;
  if (!n?.subtitlesSelect)
    return;
  const t = oc(this.subtitles);
  PT(this, t);
  const e = rc(n.subtitlesSelect.selectedValues) ?? pt, i = e !== pt && this.hasSubtitlesWidget(), s = e === pt || t.some(({ index: a }) => String(a) === e), o = i && s ? e : pt, r = BT(
    t,
    o
  );
  n.subtitlesSelect.updateItems(r), n.subtitlesSelect.setSelectedValue(o), o === pt && e !== pt && (this.hasSubtitlesWidget() && this.subtitlesWidget?.setContent(null), n.downloadSubtitlesButton.hidden = !0, this.yandexSubtitles = null, yn({ selected: null }));
}
async function ac() {
  const n = CT(this);
  if (!n)
    return (this.subtitlesCacheKey !== null || this.subtitles.length > 0) && (this.subtitles = [], this.subtitlesCacheKey = null, await this.updateSubtitlesLangSelect()), this;
  if (this.subtitlesCacheKey === n && this.subtitles.length > 0)
    return this;
  const t = Array.isArray(this.videoData?.subtitles) ? this.videoData.subtitles : [], e = this.cacheManager.getSubtitles(n);
  return e !== void 0 && e.length > 0 ? (this.subtitles = Xs(
    t,
    Array.isArray(e) ? e : []
  ), this.subtitlesCacheKey = n, await this.updateSubtitlesLangSelect(), this) : (await this.loadSubtitles(), this);
}
async function HT() {
  if (!this.uiManager.votOverlayView?.subtitlesSelect) return this;
  try {
    await ac.call(this);
  } catch (s) {
    return gl() && console.warn("[VOT][VK probe] auto subtitles failed", s), this;
  }
  const t = Eo(this) ?? this.translateFromLang, e = Co(this);
  if (!e)
    return this;
  const i = NT(
    oc(this.subtitles),
    t,
    e
  );
  return i == null ? (gl() && console.warn("[VOT][VK probe] no suitable subtitles after load", {
    count: this.subtitles?.length || 0,
    fromLang: t,
    toLang: e,
    subtitles: this.subtitles
  }), this) : (await this.changeSubtitlesLang(pt), await this.changeSubtitlesLang(String(i)), this);
}
async function WT() {
  const n = this.uiManager.votOverlayView;
  if (!n?.subtitlesSelect) return this;
  const t = rc(
    n.subtitlesSelect.selectedValues
  );
  return t && t !== pt ? (await this.changeSubtitlesLang(pt), this) : (await this.enableSubtitlesForCurrentLangPair(), this);
}
async function zT() {
  if (!this.videoData?.videoId) {
    console.error(
      `[VOT] ${p.getDefault("VOTNoVideoIDFound")}`
    ), this.subtitles = [], this.subtitlesCacheKey = null;
    return;
  }
  const n = Co(this);
  if (!n) {
    this.subtitles = [], this.subtitlesCacheKey = null, await this.updateSubtitlesLangSelect();
    return;
  }
  const t = Eo(this);
  if (!t) {
    this.subtitles = [], this.subtitlesCacheKey = null, await this.updateSubtitlesLangSelect();
    return;
  }
  const e = this.getSubtitlesCacheKey(
    this.videoData.videoId,
    t,
    n
  ), i = Array.isArray(this.videoData.subtitles) ? this.videoData.subtitles : [];
  try {
    let s = this.cacheManager.getSubtitles(e);
    if (s === void 0 || s.length === 0) {
      let r = this.subtitlesLoadPromises.get(e);
      r === void 0 && (r = ze.getSubtitles(this.votClient, {
        ...this.videoData,
        detectedLanguage: t,
        responseLanguage: n
      }), this.subtitlesLoadPromises.set(e, r));
      try {
        s = await r, s = Array.isArray(s) ? s : [], s.length > 0 ? this.cacheManager.setSubtitles(e, s) : this.cacheManager.deleteSubtitles?.(e);
      } finally {
        this.subtitlesLoadPromises.get(e) === r && this.subtitlesLoadPromises.delete(e);
      }
    }
    const o = Array.isArray(s) ? s : [];
    this.subtitles = Xs(
      i,
      o
    ), this.subtitlesCacheKey = e;
  } catch (s) {
    console.error("[VOT] Failed to load subtitles:", s), this.subtitles = Xs(i), this.subtitlesCacheKey = e;
  }
  await this.updateSubtitlesLangSelect();
}
const li = 0, ui = 1, Bi = Object.freeze({
  tickMs: 50,
  thresholdOnRms: 0.012,
  thresholdOffRms: 9e-3,
  rmsAttackTauMs: 60,
  rmsReleaseTauMs: 240,
  holdMs: 520,
  attackTauMs: 110,
  releaseTauMs: 600,
  maxDownPerSec: 3.5,
  maxUpPerSec: 0.9,
  rmsMissingGraceMs: 200,
  maxDtMs: 250,
  externalBaselineDelta01: 0.02,
  unduckTolerance01: 0.01,
  volumeStep01: yi,
  applyDeltaThreshold01: yi / 2
});
function Po(n) {
  return {
    isDucked: !1,
    speechGateOpen: !1,
    rmsEnvelope: 0,
    baseline: me(n),
    lastApplied: void 0,
    lastTickAt: 0,
    lastSoundAt: 0,
    rmsMissingSinceAt: null
  };
}
function qT() {
  return Po();
}
function GT(n, t, e = Bi) {
  const i = KT(t), s = me(n.volumeOnStart);
  if (!n.translationActive)
    return {
      kind: "stop",
      runtime: i,
      restoreVolume: i.baseline ?? s
    };
  const o = Number.isFinite(n.nowMs) ? n.nowMs : Date.now(), r = i.lastTickAt || o, a = K(o - r, 0, e.maxDtMs), l = a / 1e3;
  i.lastTickAt = o;
  const c = Zt(n.rms), d = c ? K(n.rms, li, ui) : 0, h = i.rmsEnvelope, f = d > h ? e.rmsAttackTauMs : e.rmsReleaseTauMs, g = f > 0 ? -Math.expm1(-a / f) : 1;
  i.rmsEnvelope = K(
    h + (d - h) * g,
    li,
    ui
  );
  let m = i.speechGateOpen;
  n.audioIsPlaying && !c ? (i.rmsMissingSinceAt ?? (i.rmsMissingSinceAt = o), m && (i.lastSoundAt = o), i.rmsMissingSinceAt !== null && o - i.rmsMissingSinceAt >= e.rmsMissingGraceMs && (m = !0, i.lastSoundAt = o)) : (i.rmsMissingSinceAt = null, m ? n.audioIsPlaying && i.rmsEnvelope >= e.thresholdOffRms ? i.lastSoundAt = o : o - i.lastSoundAt > e.holdMs && (m = !1) : n.audioIsPlaying && i.rmsEnvelope >= e.thresholdOnRms && (m = !0, i.lastSoundAt = o)), i.speechGateOpen = m;
  const v = me(n.currentVideoVolume);
  if (!Zt(v))
    return { kind: "noop", runtime: i };
  i.isDucked && Zt(i.lastApplied) && Math.abs(v - i.lastApplied) > e.externalBaselineDelta01 && (i.baseline = v), i.isDucked || (i.baseline = v);
  const S = i.baseline ?? s ?? v;
  if (i.baseline = S, !n.hostVideoActive)
    return i.lastApplied = v, { kind: "noop", runtime: i };
  const T = me(n.duckingTarget01) ?? S, w = Math.min(S, T);
  let A = S;
  m ? (i.isDucked || (i.isDucked = !0), A = w) : i.isDucked && Math.abs(S - v) < e.unduckTolerance01 && (i.isDucked = !1);
  const P = A < v ? e.attackTauMs : e.releaseTauMs, _ = P > 0 ? -Math.expm1(-a / P) : 1;
  let O = v + (A - v) * _;
  const Q = (A < v ? e.maxDownPerSec : e.maxUpPerSec) * l;
  Q > 0 && (O = K(
    O,
    v - Q,
    v + Q
  )), O = K(O, li, ui);
  const Y = rb(
    O,
    v,
    A,
    e.volumeStep01
  ), at = e.applyDeltaThreshold01;
  return Math.abs(Y - v) < at ? (i.lastApplied = Y, { kind: "noop", runtime: i }) : !Zt(i.lastApplied) || Math.abs(Y - i.lastApplied) >= at ? (i.lastApplied = Y, {
    kind: "apply",
    runtime: i,
    volume01: Y
  }) : { kind: "noop", runtime: i };
}
function KT(n) {
  return {
    isDucked: !!n.isDucked,
    speechGateOpen: !!n.speechGateOpen,
    rmsEnvelope: me(n.rmsEnvelope) ?? 0,
    baseline: me(n.baseline),
    lastApplied: me(n.lastApplied),
    lastTickAt: Zt(n.lastTickAt) ? n.lastTickAt : 0,
    lastSoundAt: Zt(n.lastSoundAt) ? n.lastSoundAt : 0,
    rmsMissingSinceAt: Zt(n.rmsMissingSinceAt) ? n.rmsMissingSinceAt : null
  };
}
function me(n) {
  if (Zt(n))
    return K(n, li, ui);
}
function Zt(n) {
  return typeof n == "number" && Number.isFinite(n);
}
const YT = Bi.tickMs, ml = 1200, jT = 100, pl = 1, Mo = 4e3, Vi = /* @__PURE__ */ new WeakMap();
function lc(n) {
  const t = String(n?.name ?? ""), e = String(
    n?.message ?? n ?? ""
  );
  return t === "AbortError" || e.includes(
    "The fetching process for the media resource was aborted"
  ) || e.includes("media resource was aborted by the user agent");
}
function ys(n) {
  if (!n || typeof n != "object") return !1;
  const t = n;
  return typeof t.connect == "function" && typeof t.disconnect == "function";
}
function yl(n) {
  return Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0;
}
function XT(n) {
  return Number.isFinite(n) ? Math.max(0, n) : 0;
}
function JT(n, t, e) {
  const i = e?.currentTime;
  if (typeof i == "number" && Number.isFinite(i)) {
    try {
      typeof n.cancelAndHoldAtTime == "function" ? n.cancelAndHoldAtTime(i) : typeof n.cancelScheduledValues == "function" && n.cancelScheduledValues(i);
    } catch {
    }
    if (typeof n.setValueAtTime == "function") {
      n.setValueAtTime(t, i);
      return;
    }
  }
  n.value = t;
}
function ZT(n, t) {
  if (!n) return;
  const e = n.gainNode;
  e?.gain && JT(
    e.gain,
    XT(t),
    e.context
  ), typeof n.volume == "number" && (n.volume = yl(t));
  const i = Rn(n);
  i && (i.volume = yl(t));
}
function uc(n, t, e) {
  const i = typeof t == "number" && Number.isFinite(t) ? t : e;
  typeof i != "number" || !Number.isFinite(i) || ZT(n, i / 100);
}
function Rn(n) {
  return n?.audio ?? n?.audioElement;
}
function bl() {
  return p.lang === "ru" ? "Запустить звук перевода" : "Start translated audio";
}
function QT() {
  return p.lang === "ru" ? "Браузер заблокировал автозапуск перевода. Нажмите на страницу или на кнопку ещё раз." : "Browser autoplay blocked translated audio. Click the page or the button again.";
}
function cc(n, t) {
  const e = globalThis;
  if (!t) {
    try {
      e.__VOT_PENDING_AUTOPLAY_RECOVERY__ = null;
    } catch {
    }
    return;
  }
  try {
    e.__VOT_PENDING_AUTOPLAY_RECOVERY__ = {
      ...t,
      siteHost: n.site.host,
      pageUrl: globalThis.location.href
    };
  } catch {
  }
}
function Pn(n) {
  try {
    n.pendingAutoplayRecoveryAbortController?.abort();
  } catch {
  }
  n.pendingAutoplayRecoveryAbortController = void 0, n.pendingAutoplayRecovery = null, cc(n, null);
}
function t0(n) {
  return !!(n.readyState >= HTMLMediaElement.HAVE_METADATA || n.currentTime > 0 || Number.isFinite(n.duration) && n.duration > 0);
}
function dc(n) {
  return !!(n?.gainNode || n?.audioSource || n?.mediaElementSource);
}
function ti(n, t, e) {
  return !(t.paused || t.readyState < 2 || t.error || (n.audioPlayer?.audioContext?.state ?? n.audioContext?.state) === "suspended" && dc(e));
}
function e0(n) {
  const t = n.audioPlayer?.player, e = Rn(t), i = String(t?.currentSrc || t?.src || ""), s = n.audioPlayer?.audioContext?.state ?? n.audioContext?.state;
  return !t || !e || !i || !n.video || n.video.paused || e.error ? !1 : s === "suspended" && dc(t) ? !0 : e.paused && t0(e);
}
async function hc(n, t) {
  const e = n.pendingAutoplayRecovery;
  if (!e)
    return !1;
  const i = {
    gen: e.gen,
    videoId: e.videoId
  };
  if (n.isActionStale(i))
    return Pn(n), !1;
  C.log("[VOT][audio] retrying translated audio after user gesture", {
    trigger: t,
    sourceUrl: e.sourceUrl,
    videoId: e.videoId
  });
  const s = n.audioPlayer?.player, o = String(s?.currentSrc || s?.src || ""), r = Ci(
    n,
    e.sourceUrl
  ), a = Ci(
    n,
    o
  );
  return r && a !== r && (await Ei(
    n,
    e.sourceUrl,
    i
  )).status !== "success" ? !1 : (await Do(n), await _e(n, i), await _o(
    n,
    i,
    1800
  ) ? (Pn(n), n.transformBtn("success", p.get("disableTranslate")), n.syncPopupOverlayState({
    hint: n.downloadTranslationUrl ? "Translated audio is ready for download." : "Waiting for translated audio."
  }), !0) : (C.log(
    "[VOT][audio] translated audio still did not start after gesture",
    {
      trigger: t,
      sourceUrl: e.sourceUrl
    }
  ), !1));
}
function vl(n, t, e) {
  Pn(n);
  const i = {
    gen: e?.gen ?? n.actionsGeneration,
    videoId: e?.videoId ?? n.videoData?.videoId ?? "",
    sourceUrl: t,
    createdAt: Date.now()
  }, s = new AbortController(), o = [
    "pointerdown",
    "touchstart",
    "click",
    "keydown"
  ], r = (a) => {
    C.log(
      "[VOT][audio] user gesture detected while autoplay recovery is pending",
      {
        type: a.type,
        sourceUrl: t,
        videoId: i.videoId
      }
    ), hc(
      n,
      `gesture:${a.type}`
    );
  };
  n.pendingAutoplayRecovery = i, n.pendingAutoplayRecoveryAbortController = s, cc(n, i);
  for (const a of o)
    document.addEventListener(a, r, {
      capture: !0,
      passive: a !== "keydown",
      signal: s.signal
    });
}
async function _e(n, t) {
  if (n.isActionStale(t))
    return;
  const e = n.audioPlayer?.player, i = Rn(e), s = n.video, o = !!(e?.currentSrc || e?.src);
  if (!(!e || !s || s.paused || !o)) {
    try {
      e.lipSync?.("play");
    } catch {
    }
    try {
      await e.play?.();
    } catch {
    }
    if (i) {
      try {
        i.currentTime = s.currentTime;
      } catch {
      }
      try {
        i.playbackRate = s.playbackRate;
      } catch {
      }
      try {
        await i.play();
      } catch {
      }
    }
  }
}
function n0(n = !1) {
  const t = !!this.pendingAutoplayRecovery;
  Pn(this), n && t && this.hasActiveSource() && this.transformBtn("success", p.get("disableTranslate"));
}
function i0() {
  return !!this.pendingAutoplayRecovery;
}
async function s0(n = "manual") {
  if (!this.pendingAutoplayRecovery)
    return !1;
  if (this.pendingAutoplayRecoveryPromise)
    return await this.pendingAutoplayRecoveryPromise;
  const t = hc(this, n).finally(
    () => {
      this.pendingAutoplayRecoveryPromise === t && (this.pendingAutoplayRecoveryPromise = null);
    }
  );
  return this.pendingAutoplayRecoveryPromise = t, await t;
}
function o0() {
  const n = this.audioPlayer?.player, t = this.uiManager.votOverlayView?.translationVolumeSlider?.value;
  uc(n, t, this.data?.defaultVolume);
}
async function r0(n = "manual") {
  try {
    this.audioPlayer || this.createPlayer();
    const t = await Do(this);
    C.log("[VOT][audio] primed playback context from user gesture", {
      trigger: n,
      result: t,
      player: this.audioPlayer?.player?.constructor?.name ?? "unknown"
    });
  } catch {
  }
}
function fc() {
  return typeof performance < "u" && typeof performance.now == "function" ? performance.now() : Date.now();
}
function Oo(n) {
  return n.data?.syncVolume || !n.data?.enabledAutoVolume ? "off" : n.data?.enabledSmartDucking ?? !0 ? "smart" : "classic";
}
async function Do(n) {
  const t = n.audioPlayer?.audioContext;
  if (!t || t.state !== "suspended") return "not-needed";
  const e = 1500, i = (async () => {
    try {
      return await t.resume(), "resumed";
    } catch {
      return "failed";
    }
  })();
  let s;
  const o = new Promise((a) => {
    s = setTimeout(() => a("timeout"), e);
  }), r = await Promise.race([i, o]);
  return s !== void 0 && clearTimeout(s), r;
}
async function bn(n, t) {
  if (!t || !n.audioPlayer) return;
  const e = n.audioPlayer.player, i = String(e.currentSrc || e.src || ""), s = n.proxifyAudio(
    n.unproxifyAudio(i)
  ), o = n.proxifyAudio(
    n.unproxifyAudio(t)
  );
  if (s === o)
    try {
      await e.clear(), e.src = "", C.log("[updateTranslation] cleared stale partially-applied source");
    } catch {
    }
}
function a0(n) {
  return n.audioPlayer?.audioContext ?? n.audioContext;
}
function gc(n) {
  if (n.connectedInputNode && n.analyser)
    try {
      n.connectedInputNode.disconnect(n.analyser);
    } catch {
    }
  if (n.connectedInputNode = void 0, n.createdMediaSource)
    try {
      n.createdMediaSource.disconnect();
    } catch {
    }
  if (n.createdMediaSource = void 0, n.analyser)
    try {
      n.analyser.disconnect();
    } catch {
    }
  n.analyser = void 0, n.analyserFloatData = void 0, n.analyserData = void 0, n.mediaElement = void 0, n.audioContext = void 0, n.mediaSourceCreationFailed = !1;
}
function l0(n) {
  const t = Vi.get(n);
  t && (gc(t), Vi.delete(n));
}
function u0(n, t, e, i) {
  if (ys(n?.gainNode)) return n.gainNode;
  if (ys(n?.audioSource)) return n.audioSource;
  if (ys(n?.mediaElementSource)) return n.mediaElementSource;
  if (!(i.mediaSourceCreationFailed && i.mediaElement === t && i.audioContext === e)) {
    if (i.createdMediaSource && i.mediaElement === t && i.audioContext === e)
      return i.createdMediaSource;
    try {
      const s = e.createMediaElementSource(t);
      return i.createdMediaSource = s, i.mediaSourceCreationFailed = !1, s;
    } catch {
      i.mediaSourceCreationFailed = !0;
      return;
    }
  }
}
function c0(n, t, e) {
  const i = a0(n);
  if (!i) return;
  let s = Vi.get(n);
  if (s || (s = {}, Vi.set(n, s)), (s.mediaElement && s.mediaElement !== e || s.audioContext && s.audioContext !== i) && gc(s), s.mediaElement = e, s.audioContext = i, !s.analyser) {
    const a = i.createAnalyser();
    a.fftSize = 512, s.analyser = a;
  }
  const o = u0(
    t,
    e,
    i,
    s
  ), r = s.analyser;
  if (!(!o || !r)) {
    if (s.connectedInputNode !== o) {
      if (s.connectedInputNode)
        try {
          s.connectedInputNode.disconnect(r);
        } catch {
        }
      try {
        o.connect(r), s.connectedInputNode = o;
      } catch {
        return;
      }
    }
    return { analyser: r, state: s };
  }
}
function d0(n) {
  return {
    isDucked: n.smartVolumeIsDucked,
    speechGateOpen: n.smartVolumeSpeechGateOpen,
    rmsEnvelope: n.smartVolumeRmsEnvelope,
    baseline: n.smartVolumeDuckingBaseline,
    lastApplied: n.smartVolumeLastApplied,
    lastTickAt: n.smartVolumeLastTickAt,
    lastSoundAt: n.smartVolumeLastSoundAt,
    rmsMissingSinceAt: n.smartVolumeRmsMissingSinceAt
  };
}
function Mn(n, t) {
  n.smartVolumeIsDucked = t.isDucked, n.smartVolumeSpeechGateOpen = t.speechGateOpen, n.smartVolumeRmsEnvelope = t.rmsEnvelope, n.smartVolumeDuckingBaseline = t.baseline, n.smartVolumeLastApplied = t.lastApplied, n.smartVolumeLastTickAt = t.lastTickAt, n.smartVolumeLastSoundAt = t.lastSoundAt, n.smartVolumeRmsMissingSinceAt = t.rmsMissingSinceAt;
}
function Bn(n, t = {}) {
  const { restoreVolume: e } = t;
  n.smartVolumeDuckingInterval !== void 0 && (clearTimeout(n.smartVolumeDuckingInterval), n.smartVolumeDuckingInterval = void 0);
  const i = typeof e == "number" ? e : n.smartVolumeDuckingBaseline ?? n.volumeOnStart;
  if (typeof i == "number" && (typeof e == "number" || n.smartVolumeIsDucked))
    try {
      n.setVideoVolume(i);
    } catch {
    }
  l0(n), Mn(n, qT());
}
function mc(n) {
  typeof globalThis > "u" || n.smartVolumeDuckingInterval !== void 0 && (n.smartVolumeDuckingInterval = globalThis.setTimeout(() => {
    if (n.smartVolumeDuckingInterval !== void 0) {
      try {
        g0(n);
      } catch {
        Bn(n);
        return;
      }
      n.smartVolumeDuckingInterval !== void 0 && mc(n);
    }
  }, YT));
}
function h0(n) {
  if (typeof globalThis > "u" || n.smartVolumeDuckingInterval !== void 0 || Oo(n) !== "smart") return;
  const t = n.getVideoVolume(), e = typeof n.smartVolumeDuckingBaseline == "number" ? n.smartVolumeDuckingBaseline : t, i = Po(e);
  if (Number.isFinite(t) && Number.isFinite(e) && t < e - Bi.externalBaselineDelta01) {
    const s = fc();
    i.isDucked = !0, i.speechGateOpen = !0, i.lastApplied = t, i.lastSoundAt = s;
  }
  Mn(n, i), n.smartVolumeDuckingInterval = globalThis.setTimeout(() => {
  }, 0), clearTimeout(n.smartVolumeDuckingInterval), mc(n);
}
function f0(n, t) {
  const e = n.audioPlayer?.player, i = c0(n, e, t);
  if (!i) return;
  const { analyser: s, state: o } = i;
  try {
    if (typeof s.getFloatTimeDomainData == "function") {
      let l = o.analyserFloatData;
      l?.length !== s.fftSize && (l = new Float32Array(s.fftSize), o.analyserFloatData = l), s.getFloatTimeDomainData(l);
      let c = 0;
      for (const d of l)
        c += d * d;
      return K(Math.sqrt(c / l.length), 0, 1);
    }
    let r = o.analyserData;
    r?.length !== s.fftSize && (r = new Uint8Array(s.fftSize), o.analyserData = r), s.getByteTimeDomainData(r);
    let a = 0;
    for (const l of r) {
      const c = (l - 128) / 128;
      a += c * c;
    }
    return K(Math.sqrt(a / r.length), 0, 1);
  } catch {
    return;
  }
}
function g0(n) {
  if (Oo(n) !== "smart") {
    bc.call(n);
    return;
  }
  const t = n.audioPlayer?.player, e = Rn(t), i = !!e && !e.paused && !e.muted && // Treat near-zero volume as inactive.
  (e.volume ?? 1) > 1e-3, s = fc(), o = n.getVideoVolume(), r = n.video, a = !(r && (r.paused || r.ended)), l = K(n.data?.autoVolume ?? Mi, 0, 100) / 100;
  n.smartVolumeDuckingTarget = l;
  const c = i && e ? f0(n, e) : 0, d = GT(
    {
      nowMs: s,
      translationActive: n.hasActiveSource(),
      audioIsPlaying: i,
      rms: c,
      currentVideoVolume: o,
      hostVideoActive: a,
      duckingTarget01: l,
      volumeOnStart: n.volumeOnStart
    },
    d0(n),
    Bi
  );
  switch (d.kind) {
    case "stop":
      Bn(n, {
        restoreVolume: d.restoreVolume
      });
      return;
    case "apply":
      n.setVideoVolume(d.volume01), Mn(n, d.runtime);
      return;
    case "noop":
      Mn(n, d.runtime);
      return;
    default:
      throw new TypeError("Unhandled smart ducking decision");
  }
}
function m0(n, t) {
  return t.aborted ? Promise.resolve() : new Promise((e) => {
    const i = setTimeout(() => {
      t.removeEventListener("abort", s), e();
    }, n), s = () => {
      clearTimeout(i), t.removeEventListener("abort", s), e();
    };
    t.addEventListener("abort", s, { once: !0 });
  });
}
async function wl(n, t, e) {
  const i = n.actionsAbortController.signal, s = n.isMultiMethodS3(t) ? {
    method: "HEAD",
    signal: i,
    timeout: ml
  } : {
    // Some S3 providers reject HEAD while supporting range probes.
    headers: {
      range: "bytes=0-0"
    },
    signal: i,
    timeout: ml
  };
  for (let o = 1; o <= pl; o++) {
    if (n.isActionStale(e)) return !1;
    try {
      const r = await ut(t, s);
      if (n.isActionStale(e)) return !1;
      if (C.log("[validateAudioUrl] probe response", {
        audioUrl: t,
        attempt: o,
        ok: r.ok,
        status: r.status
      }), r.ok) return !0;
    } catch {
      if (n.isActionStale(e) || i.aborted)
        return !1;
    }
    if (o < pl && (n.isActionStale(e) || i.aborted || (await m0(jT, i), n.isActionStale(e) || i.aborted)))
      return !1;
  }
  return !1;
}
async function p0(n, t) {
  if (this.isActionStale(t))
    return n;
  const e = String(n || ""), i = this.unproxifyAudio(e), s = this.proxifyAudio(i), o = this.audioPlayer?.player?.currentSrc || this.audioPlayer?.player?.src || "", r = this.proxifyAudio(
    this.unproxifyAudio(o)
  );
  return s === r || this.site.host === "yandexdisk" || this.site.host === "googledrive" || this.isMultiMethodS3(e) || this.isMultiMethodS3(i) || i.includes("vtrans.s3-private.mds.yandex.net") || i.includes("/tts/prod/") || await wl(this, n, t) ? n : i !== n && await wl(
    this,
    i,
    t
  ) ? i : n;
}
function y0() {
  if (!this.videoData || this.videoData.isStream || !this.hasActiveSource()) return;
  clearTimeout(this.translationRefreshTimeout);
  const n = Math.max(3e4, ou - 300 * 1e3);
  this.translationRefreshTimeout = setTimeout(() => {
    this.refreshTranslationAudio().catch((t) => {
    });
  }, n);
}
async function pc(n, t) {
  const e = await ky({
    requester: n.translationHandler,
    request: {
      videoData: t.videoData,
      requestLang: t.requestLang,
      responseLang: t.responseLang,
      translationHelp: t.translationHelp,
      useAudioDownload: !!n.data?.useAudioDownload,
      signal: n.actionsAbortController.signal
    },
    actionContext: t.actionContext,
    isActionStale: (i) => n.isActionStale(i),
    updateTranslation: (i, s) => n.updateTranslation(i, s),
    scheduleTranslationRefresh: () => n.scheduleTranslationRefresh()
  });
  return e ? (t.onBeforeCache && await t.onBeforeCache(e), Ly({
    cacheKey: t.cacheKey,
    setTranslation: (i, s) => n.cacheManager.setTranslation(i, s),
    videoId: t.cacheVideoId,
    requestLang: t.cacheRequestLang,
    responseLang: t.cacheResponseLang,
    fallbackUrl: e.url,
    downloadTranslationUrl: n.downloadTranslationUrl,
    usedLivelyVoice: e.usedLivelyVoice
  }), e) : null;
}
async function b0() {
  if (!this.videoData || this.videoData.isStream || !this.hasActiveSource() || this.isRefreshingTranslation) return;
  const n = this.videoData.videoId;
  if (!n) return;
  this.actionsAbortController?.signal?.aborted && this.resetActionsAbortController("refreshTranslationAudio"), this.isRefreshingTranslation = !0;
  const t = { gen: this.actionsGeneration, videoId: n }, e = go(
    this.videoData.translationHelp
  );
  try {
    if (!await pc(this, {
      videoData,
      requestLang: resolvedReqLang,
      responseLang: resLang,
      translationHelp: e,
      actionContext: t,
      cacheKey,
      cacheVideoId: VIDEO_ID,
      cacheRequestLang: resolvedReqLang,
      cacheResponseLang: responseLang,
      onBeforeCache: async () => {
        const s = this.videoData ? this.getSubtitlesCacheKey(
          VIDEO_ID,
          this.videoData.detectedLanguage,
          this.videoData.responseLanguage
        ) : null;
        (s ? this.cacheManager.getSubtitles(s) : null)?.some(
          (r) => r.source === "yandex" && r.translatedFromLanguage === videoData.detectedLanguage && r.language === videoData.responseLanguage
        ) || (s && this.cacheManager.deleteSubtitles(s), this.subtitles = [], this.subtitlesCacheKey = null);
      }
    })) return;
  } finally {
    this.isRefreshingTranslation = !1;
  }
}
function v0(n) {
  return TT(n, {
    translateProxyEnabled: this.data?.translateProxyEnabled,
    proxyWorkerHost: this.data?.proxyWorkerHost
  });
}
function w0(n) {
  return kT(n);
}
async function S0(n = "proxySettingsChanged") {
  try {
    this.cacheManager.clear(), this.activeTranslation = null;
  } catch {
  }
  try {
    await this.stopTranslation();
  } catch {
  }
  await this.initVOTClient();
}
function T0(n) {
  return LT(n, {
    proxyWorkerHost: this.data?.proxyWorkerHost
  });
}
function Ci(n, t) {
  return n.proxifyAudio(n.unproxifyAudio(t));
}
async function Ei(n, t, e) {
  const i = n.audioPlayer.player.src !== t;
  let s = null;
  i && (n.audioPlayer.player.src = t, s = t);
  try {
    if (i)
      try {
        await n.audioPlayer.init();
      } catch (r) {
        if (!lc(r) || n.isActionStale(e))
          throw r;
        if (C.log(
          "[updateTranslation] transient media abort, retrying init once",
          {
            sourceUrl: t,
            error: r
          }
        ), await new Promise((l) => setTimeout(l, 200)), n.isActionStale(e))
          return await bn(
            n,
            s
          ), {
            status: "stale",
            didSetSource: i,
            appliedSourceUrl: s
          };
        String(
          n.audioPlayer.player.currentSrc || n.audioPlayer.player.src || ""
        ) || (n.audioPlayer.player.src = t), await n.audioPlayer.init();
      }
    if (n.isActionStale(e))
      return await bn(n, s), {
        status: "stale",
        didSetSource: i,
        appliedSourceUrl: s
      };
    const o = await Do(n);
    return o === "timeout" ? C.log(
      "[updateTranslation] continuing after AudioContext resume timeout"
    ) : o === "failed" && C.log(
      "[updateTranslation] AudioContext resume failed, continue without deferred resume"
    ), n.isActionStale(e) ? (await bn(n, s), {
      status: "stale",
      didSetSource: i,
      appliedSourceUrl: s
    }) : (!n.video.paused && n.audioPlayer.player.src && await _e(n, e), {
      status: "success",
      didSetSource: i,
      appliedSourceUrl: s
    });
  } catch (o) {
    return {
      status: "error",
      didSetSource: i,
      appliedSourceUrl: s,
      error: o
    };
  }
}
async function _o(n, t, e = Mo) {
  const i = n.audioPlayer?.player, s = Rn(i);
  return !i || !String(i.currentSrc || i.src || "") ? !1 : !s || ti(n, s, i) || (await _e(n, t), ti(n, s, i)) ? !0 : await new Promise((r) => {
    let a = !1;
    const l = (m) => {
      a || (a = !0, g(), r(m));
    }, c = () => {
      _e(n, t), l(!0);
    }, d = () => l(!1), h = () => {
      _e(n, t), ti(n, s, i) && l(!0);
    }, f = setTimeout(() => {
      _e(n, t), l(ti(n, s, i));
    }, e), g = () => {
      clearTimeout(f), s.removeEventListener("playing", c), s.removeEventListener("canplay", h), s.removeEventListener("loadeddata", h), s.removeEventListener("loadedmetadata", h), s.removeEventListener("error", d);
    };
    s.addEventListener("playing", c, { once: !0 }), s.addEventListener("canplay", h, { once: !0 }), s.addEventListener("loadeddata", h, { once: !0 }), s.addEventListener("loadedmetadata", h, { once: !0 }), s.addEventListener("error", d, { once: !0 }), n.isActionStale(t) && l(!1);
  });
}
function yc(n) {
  const t = n.video;
  return !!(t && !t.paused && !t.ended);
}
async function Sl(n, t, e) {
  try {
    await n.audioPlayer?.player?.clear();
  } catch {
  }
  try {
    n.audioPlayer?.player && (n.audioPlayer.player.src = "");
  } catch {
  }
  try {
    n.createPlayer();
  } catch {
    return !1;
  }
  return await new Promise((s) => setTimeout(s, 150)), n.isActionStale(e) || (await Ei(
    n,
    t,
    e
  )).status !== "success" || yc(n) && !await _o(
    n,
    e,
    Mo
  ) ? !1 : (n.setupAudioSettings(), n.transformBtn("success", p.get("disableTranslate")), n.afterUpdateTranslation(t), this.data?.autoSubtitles && (setTimeout(() => {
    this.enableSubtitlesForCurrentLangPair();
  }, 1500), setTimeout(() => {
    this.enableSubtitlesForCurrentLangPair();
  }, 5e3)), !0);
}
async function k0(n, t) {
  if (await this.waitForPendingStopTranslate(), this.isActionStale(t)) return;
  Pn(this), this.audioPlayer || this.createPlayer(), this.audioPlayer.audioContext?.state === "closed" && this.createPlayer();
  const e = Ci(this, n), i = this.audioPlayer.player.currentSrc || this.audioPlayer.player.src || "", s = Ci(this, i);
  let o = e;
  if (e !== s && (o = await this.validateAudioUrl(
    e,
    t
  )), this.isActionStale(t)) return;
  this.externalTranslationSourceUrl = null;
  let r = await Ei(
    this,
    o,
    t
  ), a = r.appliedSourceUrl;
  if (r.status === "error" && r.didSetSource && !this.isActionStale(t)) {
    const l = this.unproxifyAudio(o);
    if (l !== o)
      try {
        C.log(
          "[updateTranslation] proxied audio init failed, retrying direct URL"
        );
        const c = await this.validateAudioUrl(
          l,
          t
        );
        if (this.isActionStale(t)) {
          await bn(
            this,
            a
          );
          return;
        }
        o = c, r = await Ei(
          this,
          c,
          t
        ), a = r.appliedSourceUrl;
      } catch (c) {
        r = {
          status: "error",
          didSetSource: !0,
          appliedSourceUrl: a,
          error: c
        };
      }
  }
  if (r.status !== "stale") {
    if (r.status === "error") {
      if (C.log("this.audioPlayer.init() error", r.error), lc(r.error) && (C.log(
        "[updateTranslation] media abort detected, recreating player and retrying once",
        r.error
      ), await Sl(
        this,
        o,
        t
      )))
        return;
      await bn(this, a);
      try {
        await this.audioPlayer?.player?.clear();
      } catch {
      }
      try {
        this.audioPlayer?.player && (this.audioPlayer.player.src = "");
      } catch {
      }
      this.downloadTranslationUrl = null;
      const l = ru(r.error);
      throw this.transformBtn("error", l), r.error instanceof Error ? r.error : new Error(l);
    }
    if (yc(this) && !await _o(
      this,
      t,
      Mo
    )) {
      if (oe(this.site.host, this.videoData?.host)) {
        this.setupAudioSettings(), this.afterUpdateTranslation(o), vl(this, o, t), this.transformBtn("success", bl()), this.data?.autoSubtitles && (setTimeout(() => {
          this.enableSubtitlesForCurrentLangPair();
        }, 1500), setTimeout(() => {
          this.enableSubtitlesForCurrentLangPair();
        }, 5e3));
        return;
      }
      if (e0(this)) {
        C.log(
          "[VOT][audio] translated audio is waiting for a user gesture",
          {
            sourceUrl: o,
            videoId: t?.videoId ?? this.videoData?.videoId
          }
        ), vl(this, o, t), this.setupAudioSettings(), this.transformBtn("success", bl()), this.afterUpdateTranslation(o), this.data?.autoSubtitles && (setTimeout(() => {
          this.enableSubtitlesForCurrentLangPair();
        }, 1500), setTimeout(() => {
          this.enableSubtitlesForCurrentLangPair();
        }, 5e3)), this.syncPopupOverlayState({
          hint: QT()
        });
        return;
      }
      if (await Sl(
        this,
        o,
        t
      ))
        return;
      try {
        await this.audioPlayer?.player?.clear();
      } catch {
      }
      try {
        this.audioPlayer?.player && (this.audioPlayer.player.src = "");
      } catch {
      }
      throw this.downloadTranslationUrl = null, this.transformBtn("error", "Translated audio did not start"), new Error("Translated audio did not start");
    }
    this.setupAudioSettings(), this.transformBtn("success", p.get("disableTranslate")), this.afterUpdateTranslation(o);
  }
}
async function L0(n, t, e, i, s) {
  await this.waitForPendingStopTranslate(), await this.videoValidator(), this.actionsAbortController?.signal?.aborted && this.resetActionsAbortController("translateFunc");
  const o = this.uiManager.votOverlayView;
  if (!o?.votButton)
    return;
  if (o.votButton.loading = !0, this.hadAsyncWait = !1, this.volumeOnStart = this.getVideoVolume(), !n) {
    await this.updateTranslationErrorMsg(
      new bt("VOTNoVideoIDFound"),
      this.actionsAbortController.signal
    );
    return;
  }
  const r = this.videoData;
  if (!r) {
    await this.updateTranslationErrorMsg(
      new bt("VOTNoVideoIDFound"),
      this.actionsAbortController.signal
    );
    return;
  }
  const a = n;
  if (this.lastTranslationVideoId !== a) {
    C.log("[translateFunc] video changed, recreating player", {
      prev: this.lastTranslationVideoId,
      next: a
    }), this.resetActionsAbortController("translateFunc video changed");
    try {
      await this.audioPlayer?.player?.clear();
    } catch {
    }
    try {
      this.audioPlayer?.player && (this.audioPlayer.player.src = "");
    } catch {
    }
    try {
      this.translationRefreshTimeout !== void 0 && (clearTimeout(this.translationRefreshTimeout), this.translationRefreshTimeout = void 0);
    } catch {
    }
    this.downloadTranslationUrl = null, this.activeTranslation = null, this.hadAsyncWait = !1, Bn(this, {
      restoreVolume: this.smartVolumeDuckingBaseline ?? this.volumeOnStart
    }), this.smartVolumeDuckingBaseline = void 0;
    try {
      this.createPlayer();
    } catch {
    }
    this.lastTranslationVideoId = a;
  }
  const l = go(s);
  await this.videoManager.ensureDetectedLanguageForTranslation(r);
  const c = e === "auto" && r.detectedLanguage !== "auto" ? r.detectedLanguage : e, d = this.getTranslationCacheKey(
    n,
    c,
    i,
    l
  ), h = `video_${d}`;
  if (this.activeTranslation?.key === h) {
    await this.activeTranslation.promise;
    return;
  }
  const f = {
    gen: this.actionsGeneration,
    videoId: n
  }, g = (async () => {
    if (this.isActionStale(f))
      return;
    const m = c, v = i, S = async (A) => await Su({
      url: A,
      actionContext: f,
      isActionStale: (P) => this.isActionStale(P),
      updateTranslation: (P, _) => this.updateTranslation(P, _),
      scheduleTranslationRefresh: () => this.scheduleTranslationRefresh()
    }), T = this.cacheManager.getTranslation(d);
    if (T?.url) {
      try {
        if (await S(T.url) && this.hasActiveSource()) {
          C.log("[translateFunc] Cached translation was received");
          return;
        }
        C.log(
          "[translateFunc] Cached translation did not activate source, dropping cache and requesting fresh URL"
        );
      } catch {
      }
      typeof this.cacheManager.deleteTranslation == "function" ? this.cacheManager.deleteTranslation(d) : this.cacheManager.clear();
    }
    await pc(this, {
      videoData: r,
      requestLang: m,
      responseLang: v,
      translationHelp: l,
      actionContext: f,
      cacheKey: d,
      cacheVideoId: n,
      cacheRequestLang: c,
      cacheResponseLang: i,
      onBeforeCache: async () => {
        const A = this.videoData ? this.getSubtitlesCacheKey(
          n,
          this.videoData.detectedLanguage,
          this.videoData.responseLanguage
        ) : null;
        (A ? this.cacheManager.getSubtitles(A) : null)?.some(
          (_) => _.source === "yandex" && _.translatedFromLanguage === r.detectedLanguage && _.language === r.responseLanguage
        ) || (A && this.cacheManager.deleteSubtitles(A), this.subtitles = [], this.subtitlesCacheKey = null);
      }
    });
  })();
  this.activeTranslation = {
    key: h,
    promise: g
  };
  try {
    return await g;
  } catch (m) {
    throw this.hadAsyncWait = xs({
      aborted: this.actionsAbortController.signal.aborted,
      translateApiErrorsEnabled: !!this.data?.translateAPIErrors,
      hadAsyncWait: this.hadAsyncWait,
      videoId: n,
      error: m,
      notify: (v) => this.notifier.translationFailed(v)
    }), m;
  } finally {
    this.activeTranslation?.promise === g && (this.activeTranslation = null);
    const m = this.uiManager.votOverlayView?.votButton;
    !this.activeTranslation && m?.loading && !this.hasActiveSource() && this.transformBtn("none", p.get("translateVideo"));
  }
}
function A0() {
  return gp(this.site.host);
}
function bc() {
  uc(
    this.audioPlayer?.player,
    this.uiManager.votOverlayView?.translationVolumeSlider?.value,
    this.data?.defaultVolume
  );
  const n = Oo(this);
  if (n === "off") {
    Bn(this, {
      restoreVolume: this.smartVolumeDuckingBaseline ?? this.volumeOnStart
    });
    return;
  }
  const t = K(this.data.autoVolume ?? Mi, 0, 100) / 100;
  if (this.smartVolumeDuckingTarget = t, !this.hasActiveSource())
    return;
  if (n === "smart") {
    h0(this);
    return;
  }
  this.smartVolumeDuckingInterval !== void 0 && (clearTimeout(this.smartVolumeDuckingInterval), this.smartVolumeDuckingInterval = void 0), typeof this.smartVolumeDuckingBaseline != "number" && (this.smartVolumeDuckingBaseline = this.getVideoVolume());
  const e = this.smartVolumeDuckingBaseline ?? this.getVideoVolume();
  this.setVideoVolume(Math.min(e, t)), Mn(
    this,
    Po(this.smartVolumeDuckingBaseline)
  ), this.smartVolumeIsDucked = !0;
}
function x0(n) {
  if (!this.data?.enabledAutoVolume || !this.hasActiveSource()) return;
  const t = Math.max(0, Math.min(1, n));
  this.smartVolumeDuckingBaseline = t, this.smartVolumeLastApplied = t;
}
const V0 = new Set(Pi), C0 = (n) => V0.has(n), E0 = Promise.resolve();
/(?:^|\.)vkvideo\.ru$|(?:^|\.)vk\.(?:com|ru)$/i.test(location.hostname) && (Wy(), pu());
class I0 {
  /**
   * Constructs a new VideoHandler instance.
   * @param {HTMLVideoElement} video The video element to handle.
   * @param {HTMLElement} container The container element for the video.
   * @param {Object} site The site object associated with the video.
   */
  constructor(t, e, i) {
    u(this, "video");
    u(this, "container");
    u(this, "site");
    // Public API / core state
    u(this, "translateFromLang", "auto");
    u(this, "translateToLang", ii);
    u(this, "data");
    u(this, "videoData");
    u(this, "firstPlay", !0);
    u(this, "audioContext");
    u(this, "votClient");
    u(this, "audioPlayer");
    u(this, "abortController");
    u(this, "actionsAbortController");
    /** Increments whenever we reset/abort translation actions to invalidate stale async work */
    u(this, "actionsGeneration", 0);
    u(this, "notifier", new Xw());
    u(this, "cacheManager");
    u(this, "votSessionStorage", new Nh());
    /**
     * In-flight subtitles list requests, keyed by subtitles cache key.
     *
     * Prevents duplicate parallel requests when the subtitles hotkey is spammed
     * before the first request resolves.
     */
    u(this, "subtitlesLoadPromises", /* @__PURE__ */ new Map());
    u(this, "downloadTranslationUrl", null);
    u(this, "translationRefreshTimeout");
    u(this, "isRefreshingTranslation", !1);
    u(this, "autoRetry");
    // streamPing?: ReturnType<typeof setInterval>;
    u(this, "votOpts");
    u(this, "volumeOnStart");
    /**
     * syncVolume (link translation and video volume) runtime state.
     * We keep last-known slider values to apply deltas reliably.
     */
    u(this, "volumeLinkState", {
      initialized: !1,
      lastVideoPercent: 0,
      lastTranslationPercent: 0
    });
    /**
     * Used to ignore our own programmatic video-volume updates when observing
     * external UIs (e.g. YouTube volume panel aria mutations).
     */
    u(this, "internalVideoVolumeSetAt", 0);
    u(this, "internalVideoVolumeSetPercent", null);
    u(this, "internalVideoVolumeSuppressionMs", 250);
    u(this, "internalVideoVolumeSetHistory", []);
    u(this, "internalVideoVolumeSetHistoryLimit", 48);
    // Smart auto-volume ducking state. Used to lower the original video volume
    // only while the translated track has audible sound (not during silence).
    u(this, "smartVolumeDuckingInterval");
    u(this, "smartVolumeDuckingTarget", 0.2);
    u(this, "smartVolumeDuckingBaseline");
    u(this, "smartVolumeLastApplied");
    // Internal smoothing state for Smart Auto-Volume ducking.
    u(this, "smartVolumeLastTickAt", 0);
    u(this, "smartVolumeLastSoundAt", 0);
    u(this, "smartVolumeRmsMissingSinceAt", null);
    /** Smoothed translated-track RMS envelope (0..1). */
    u(this, "smartVolumeRmsEnvelope", 0);
    /**
     * Internal speech gate state for Smart Auto-Volume ducking.
     *
     * This is a debounced/hysteresis-based boolean that tracks whether the
     * translated track is considered "audible" for the purpose of ducking.
     */
    u(this, "smartVolumeSpeechGateOpen", !1);
    u(this, "smartVolumeIsDucked", !1);
    u(this, "longWaitingResCount", 0);
    u(this, "hadAsyncWait", !1);
    // Available subtitle tracks for the current video. The subtitles UI widget
    // maintains its own internal line/token representation.
    u(this, "subtitles", []);
    u(this, "subtitlesCacheKey", null);
    u(this, "subtitlesWidget");
    u(this, "activeTranslation", null);
    u(this, "lastTranslationVideoId", null);
    u(this, "externalTranslationSourceUrl", null);
    u(this, "pendingAutoplayRecovery", null);
    u(this, "pendingAutoplayRecoveryAbortController");
    u(this, "pendingAutoplayRecoveryPromise", null);
    /**
     * In-flight async teardown for translation/audio player cleanup.
     * New translation starts should wait for this to avoid clear/init races.
     */
    u(this, "stopTranslatePromise", null);
    // Managers
    u(this, "interactionChecker");
    u(this, "uiManager");
    u(this, "overlayVisibility");
    u(this, "popupOverlayBridge");
    u(this, "popupOwnerId", Math.random().toString(36).slice(2));
    u(this, "overlayVisibilityTargetsAbortController");
    u(this, "translationOrchestrator");
    u(this, "lifecycleController");
    u(this, "translationHandler");
    u(this, "videoManager");
    // Subtitles received directly from API (Yandex) when available
    u(this, "yandexSubtitles", null);
    // Observers / listeners
    u(this, "resizeObserver");
    u(this, "syncVolumeObserver");
    u(this, "overlayMountObserver");
    u(this, "mobileYouTubeLifecycleDebounceTimer");
    // Init guard
    u(this, "initialized", !1);
    u(this, "onPrimaryAttachReady");
    /**
     * Cached overlay mount points (root/portal). Recomputed when container changes.
     * Avoids doing the same DOM/style walks multiple times per lifecycle update.
     */
    u(this, "mountCache");
    /**
     * In-memory cache for translated error strings (RU -> UI language).
     * This avoids repeated translation API calls during retry loops when the
     * same backend message is emitted multiple times.
     */
    u(this, "errorTranslationCache", /* @__PURE__ */ new Map());
    /**
     * Re-attach overlayVisibility listeners to the *current* overlay button/menu elements.
     *
     * The overlay UI gets recreated in some flows (e.g. menu language change),
     * so listeners that were attached to the old DOM nodes must be re-bound.
     */
    u(this, "rebindOverlayVisibilityTargets", pS);
    /**
     * Changes subtitles language based on user selection.
     * @param {string} subs The subtitles selection value.
     */
    u(this, "changeSubtitlesLang", UT);
    /**
     * Updates the subtitles selection options.
     */
    u(this, "updateSubtitlesLangSelect", $T);
    /**
     * Ensures the in-memory subtitles list matches the current language-pair cache key.
     */
    u(this, "ensureSubtitlesForCurrentLangPair", ac);
    /**
     * Loads subtitles for the current video.
     */
    u(this, "loadSubtitles", zT);
    u(this, "refreshTranslationAudio", b0);
    /**
     * Called when proxy-related settings are changed at runtime.
     *
     * - Clears in-memory caches so old failures/URLs don't persist.
     * - Cancels any in-flight translation work.
     * - Best-effort refreshes the active audio source so the new proxy host/mode
     *   takes effect immediately.
     */
    u(this, "handleProxySettingsChanged", S0);
    /**
     * Updates the translation audio source.
     * @param {string} audioUrl The audio URL.
     */
    u(this, "updateTranslation", k0);
    /**
     * Stops translation and synchronizes volume.
     */
    u(this, "stopTranslation", async () => {
      this.translationOrchestrator?.reset(), this.overlayVisibility?.cancel(), await this.stopTranslate(), this.syncVideoVolumeSlider();
    });
    /**
     * Releases extra event listeners.
     */
    u(this, "releaseExtraEvents", vS);
    this.video = t, this.container = e, this.site = i, this.abortController = new AbortController(), this.actionsAbortController = new AbortController(), this.cacheManager = new Uh(), this.interactionChecker = xo(), this.interactionChecker.start();
    const s = () => this, o = this.getOverlayMount(e);
    this.uiManager = new Nw({
      mount: o,
      data: this.data,
      videoHandler: this,
      intervalIdleChecker: this.interactionChecker
    }), this.overlayVisibility = new Uw({
      checker: this.interactionChecker,
      getOverlayView: () => this.uiManager.votOverlayView ?? null,
      getAutoHideDelay: () => this.getAutoHideDelay(),
      isInteractiveNode: (a) => this.isOverlayInteractiveNode(a),
      shouldAutoHide: () => this.uiManager.votOverlayView?.votButton?.status !== "disabled"
    }), this.translationOrchestrator = new xy({
      isFirstPlay: () => this.firstPlay,
      setFirstPlay: (a) => {
        this.firstPlay = a;
      },
      isAutoTranslateEnabled: () => !!this.data?.autoTranslate,
      getVideoId: () => this.videoData?.videoId,
      scheduleAutoTranslate: () => this.runAutoTranslate(),
      isMobileYouTubeMuted: () => this.site.host === "youtube" && this.site.additionalData === "mobile" && this.video.muted,
      setMuteWatcher: (a) => {
        let l = !1;
        const c = () => {
          l || (l = !0, this.video.removeEventListener("volumechange", d), a());
        }, d = () => {
          this.video.muted || c();
        };
        this.video.addEventListener("volumechange", d, {
          signal: this.abortController.signal
        }), queueMicrotask(() => {
          this.video.muted || c();
        });
      }
    });
    const r = {
      get video() {
        return s().video;
      },
      get site() {
        return s().site;
      },
      get container() {
        return s().container;
      },
      set container(a) {
        s().container !== a && (s().container = a, s().uiManager.updateMount(s().getOverlayMount(a)));
      },
      get firstPlay() {
        return s().firstPlay;
      },
      set firstPlay(a) {
        s().firstPlay = a;
      },
      stopTranslation: () => this.stopTranslation(),
      get uiManager() {
        return s().uiManager;
      },
      getVideoData: () => this.getVideoData(),
      cacheManager: {
        getSubtitles: (a) => s().cacheManager.getSubtitles(a)
      },
      getSubtitlesCacheKey: (a, l, c) => this.getSubtitlesCacheKey(a, l, c),
      updateSubtitlesLangSelect: () => this.updateSubtitlesLangSelect(),
      enableSubtitlesForCurrentLangPair: () => this.enableSubtitlesForCurrentLangPair(),
      setSelectMenuValues: (a, l) => this.setSelectMenuValues(a, l),
      get translateToLang() {
        return s().translateToLang;
      },
      set translateToLang(a) {
        C0(a) && (s().translateToLang = a);
      },
      get data() {
        return s().data ?? {};
      },
      get subtitles() {
        return s().subtitles;
      },
      set subtitles(a) {
        s().subtitles = a;
      },
      get subtitlesCacheKey() {
        return s().subtitlesCacheKey;
      },
      set subtitlesCacheKey(a) {
        s().subtitlesCacheKey = a;
      },
      get videoData() {
        return s().videoData;
      },
      set videoData(a) {
        s().videoData = a;
      },
      get actionsAbortController() {
        return s().actionsAbortController;
      },
      set actionsAbortController(a) {
        s().actionsAbortController = a;
      },
      resetActionsAbortController: (a) => this.resetActionsAbortController(a),
      initVOTClient: () => this.initVOTClient(),
      translationOrchestrator: this.translationOrchestrator,
      resetSubtitlesWidget: () => this.resetSubtitlesWidget(),
      queueOverlayAutoHide: () => this.overlayVisibility?.queueAutoHide(),
      onPrimaryAttachReady: () => this.onPrimaryAttachReady?.(),
      syncSourceAudioAvailabilityUi: (a) => this.syncSourceAudioAvailabilityUi(a)
    };
    this.lifecycleController = new Ey(r), this.translationHandler = new Ay(this), this.videoManager = new Vb(this);
  }
  /**
   * Returns fullscreen root for overlay if the active fullscreen session belongs
   * to the current video/container. Otherwise returns null.
   */
  getFullscreenOverlayRoot() {
    const t = document, e = t.fullscreenElement ?? t.webkitFullscreenElement;
    return co(e, [this.container]);
  }
  findPageScopedContainer() {
    const t = String(this.site.selector || "").trim();
    if (!t)
      return null;
    const e = t.split(",").map((s) => s.trim()).filter(Boolean);
    let i = null;
    for (const s of e) {
      let o;
      try {
        o = document.querySelectorAll(s);
      } catch {
        continue;
      }
      for (const r of o) {
        if (!(r instanceof HTMLElement) || !r.isConnected || r === document.body || r === document.documentElement)
          continue;
        const a = r.getBoundingClientRect();
        if (a.width > 0 && a.height > 0)
          return r;
        i ?? (i = r);
      }
    }
    return i;
  }
  resolveCurrentContainer() {
    if (!this.site.selector)
      return this.video.parentElement ?? this.container;
    const t = An(
      this.video,
      this.site.selector
    );
    if (t)
      return t;
    if (this.container.isConnected && be(this.container, this.video))
      return this.container;
    if (_t(this.site)) {
      const e = this.findPageScopedContainer();
      if (e)
        return e;
    }
    return this.video.parentElement ?? this.container;
  }
  getOverlayMountPoints(t = this.container) {
    const e = this.getFullscreenOverlayRoot(), { base: i, root: s, portalContainer: o, subtitlesMountContainer: r } = bp({
      container: t,
      site: this.site,
      fullscreenRoot: e
    }), a = this.mountCache;
    return a?.container === t && a.base === i && a.subtitlesMountContainer === r && a.fullscreenRoot === e && (a.root.isConnected ?? document.documentElement.contains(a.root)) ? {
      root: a.root,
      portalContainer: a.portalContainer,
      subtitlesMountContainer: a.subtitlesMountContainer,
      fullscreenRoot: a.fullscreenRoot
    } : (this.mountCache = {
      container: t,
      base: i,
      root: s,
      portalContainer: o,
      subtitlesMountContainer: r,
      fullscreenRoot: e
    }, { root: s, portalContainer: o, subtitlesMountContainer: r, fullscreenRoot: e });
  }
  getOverlayMount(t = this.container) {
    const { root: e, portalContainer: i, subtitlesMountContainer: s, fullscreenRoot: o } = this.getOverlayMountPoints(t);
    return {
      root: e,
      portalContainer: i,
      subtitlesMountContainer: s,
      tooltipLayoutRoot: o ?? this.tooltipLayoutRoot
    };
  }
  /**
   * Builds a stable cache key for translations.
   *
   * NOTE: Keep this in sync with CacheManager expectations.
   * @param {string} videoId
   * @param {string} from
   * @param {string} to
   */
  getTranslationCacheKey(t, e, i, s) {
    const o = this.getRequestLangForTranslation(
      e,
      i
    ), r = this.isLivelyVoiceAllowed(o, i) && this.data?.useLivelyVoice, a = s == null ? "" : xh(s), l = a ? Ss(a) : "0";
    return `${t}_${o}_${i}_${r}_${l}`;
  }
  /**
   * Builds a stable cache key for subtitles.
   *
   * Bugfix: subtitles cache key must match the key used by loadSubtitles().
   * @param {string} videoId
   * @param {string} detectedLanguage
   * @param {string} responseLanguage
   */
  getSubtitlesCacheKey(t, e, i) {
    return `${t}_${e}_${i}_${!!this.data?.useLivelyVoice}`;
  }
  getPreferredSubtitlesLanguage(t = this.videoData?.detectedLanguage ?? "auto", e = this.videoData?.responseLanguage ?? this.translateToLang) {
    const i = (s) => {
      const o = String(s || "").trim().toLowerCase();
      if (!(!o || o === "auto"))
        return o;
    };
    return i(e) ?? i(t);
  }
  isActionStale(t) {
    return t ? this.actionsGeneration !== t.gen || this.videoData?.videoId !== t.videoId : !1;
  }
  updateVOTClientRequestSignal() {
    this.votClient && (this.votClient.fetchOpts = {
      ...this.votClient.fetchOpts ?? {},
      signal: this.actionsAbortController.signal
    });
  }
  resetActionsAbortController(t) {
    try {
      this.actionsAbortController?.abort(t);
    } catch {
    }
    this.actionsAbortController = new AbortController(), this.actionsGeneration++, this.updateVOTClientRequestSignal();
  }
  /**
   * Lazily creates the subtitles widget.
   * @returns {SubtitlesWidget}
   */
  getSubtitlesWidget() {
    if (!this.subtitlesWidget) {
      const { subtitlesMountContainer: t } = this.getOverlayMountPoints();
      this.subtitlesWidget = new Lv(
        this.video,
        t,
        this.interactionChecker,
        this.tooltipLayoutRoot
      ), this.data && (this.subtitlesWidget.setSmartLayout(
        typeof this.data.subtitlesSmartLayout == "boolean" ? this.data.subtitlesSmartLayout : !0
      ), typeof this.data.subtitlesMaxLength == "number" && this.subtitlesWidget.setMaxLength(this.data.subtitlesMaxLength), typeof this.data.highlightWords == "boolean" && this.subtitlesWidget.setHighlightWords(this.data.highlightWords), typeof this.data.subtitlesFontSize == "number" && this.subtitlesWidget.setFontSize(this.data.subtitlesFontSize), typeof this.data.subtitlesFontFamily == "string" && this.subtitlesWidget.setFontFamily(
        this.data.subtitlesFontFamily
      ), typeof this.data.subtitlesOpacity == "number" && this.subtitlesWidget.setOpacity(this.data.subtitlesOpacity));
    }
    return this.subtitlesWidget;
  }
  /**
   * Determines whether subtitles widget is initialized\.
   * @returns {boolean}
   */
  hasSubtitlesWidget() {
    return !!this.subtitlesWidget;
  }
  resetSubtitlesWidget() {
    this.hasSubtitlesWidget() && (this.subtitlesWidget?.release(), this.subtitlesWidget = void 0);
  }
  /**
   * Root element for overlay UI (buttons/menu) so it remains clickable on players
   * that disable pointer events on inner layers.
   */
  get uiRoot() {
    return this.getOverlayMountPoints().root;
  }
  /**
   * Determines the DOM container used for overlay portals.
   * @returns {HTMLElement}
   */
  get portalContainer() {
    return this.getOverlayMountPoints().portalContainer;
  }
  /**
   * Determines the root element used for tooltip layout calculations.
   * @returns {HTMLElement | undefined}
   */
  get tooltipLayoutRoot() {
    switch (this.site.host) {
      case "kickstarter":
        return document.getElementById("react-project-header") ?? void 0;
      case "custom":
        return;
      default:
        return this.container;
    }
  }
  /**
   * Returns the container element for event listeners.
   * @returns {HTMLElement} The event container.
   */
  getEventContainer() {
    return this.site.eventSelector ? An(
      this.video,
      this.site.eventSelector
    ) ?? this.container : this.container;
  }
  /**
   * Run auto translate using orchestrator dependencies.
   */
  async runAutoTranslate() {
    let t = this.syncSourceAudioAvailabilityUi({
      forceVisible: !0
    });
    return t.ready ? (await this.videoManager.videoValidator(), t = this.syncSourceAudioAvailabilityUi({
      forceVisible: !0
    }), t.ready ? (await this.uiManager.handleTranslationBtnClick(), !0) : (console.log("[VOT][source-audio] auto-translate blocked after validation", {
      kind: t.kind,
      ready: t.ready,
      audioDetected: t.audioDetected,
      detectionSource: t.detectionSource
    }), !1)) : (console.log("[VOT][source-audio] auto-translate blocked before start", {
      kind: t.kind,
      ready: t.ready,
      audioDetected: t.audioDetected,
      detectionSource: t.detectionSource
    }), !1);
  }
  /**
   * Lazily initializes and returns the AudioContext.
   * @returns {AudioContext | undefined}
   */
  getAudioContext() {
    if (this.audioContext) return this.audioContext;
    if (this.isAudioContextSupported)
      try {
        return this.audioContext = no(), this.audioContext;
      } catch (t) {
        console.warn("[VOT] Failed to init AudioContext, falling back:", t);
        return;
      }
  }
  get isAudioContextSupported() {
    return globalThis.AudioContext !== void 0 || globalThis.webkitAudioContext !== void 0;
  }
  /**
   * Determines if audio should be preferred.
   * @returns {boolean} True if audio is preferred.
   */
  getPreferAudio() {
    const t = this.site.host, e = this.videoData?.host, i = this.videoData?.isStream ?? !1;
    if (oe(t, e) || i)
      return !0;
    const s = !!this.getAudioContext(), o = this.data;
    return vp({
      siteHost: t,
      videoHost: e,
      isStream: i,
      hasAudioContext: s,
      newAudioPlayer: o?.newAudioPlayer,
      onlyBypassMediaCSP: o?.onlyBypassMediaCSP,
      needBypassCSP: this.site.needBypassCSP
    });
  }
  /**
   * Creates the audio player.
   * @returns {VideoHandler} The VideoHandler instance.
   */
  createPlayer() {
    const t = this.getPreferAudio();
    if (this.audioPlayer = new rp({
      video: this.video,
      // DEBUG_MODE is injected at build-time.
      debug: !1,
      fetchFn: ut,
      fetchOpts: {
        timeout: 0
      },
      preferAudio: t
    }), t) {
      const e = this.audioPlayer.audioContext;
      if (this.audioPlayer.audioContext = void 0, e && e.state !== "closed" && e.close().catch(() => {
      }), this.audioContext && this.audioContext.state !== "closed") {
        const i = this.audioContext;
        this.audioContext = void 0, i.close().catch(() => {
        });
      }
    }
    return this;
  }
  /**
   * Returns true if a detected external volume update is very likely caused by
   * our own recent programmatic setVideoVolume call.
   */
  isLikelyInternalVideoVolumeChange(t) {
    const e = Date.now(), i = this.internalVideoVolumeSetHistory;
    if (i.length > 0) {
      let o = 0, r = !1;
      for (const a of i)
        e - a.at > a.suppressMs || (i[o++] = a, !r && Math.abs(t - a.percent) <= 1 && (r = !0));
      return i.length = o, r;
    }
    return this.internalVideoVolumeSetPercent === null || e - this.internalVideoVolumeSetAt > this.internalVideoVolumeSuppressionMs ? !1 : Math.abs(t - this.internalVideoVolumeSetPercent) <= 1;
  }
  callModule(t, ...e) {
    return t.call(this, ...e);
  }
  callModuleAsync(t, ...e) {
    return t.call(this, ...e);
  }
  /**
   * Initializes the VideoHandler: loads settings, UI, video data, events, etc.
   * @returns {Promise<void>}
   */
  init() {
    return TS.call(this);
  }
  /**
   * Initializes the VOT client.
   * @returns {VideoHandler} This instance.
   */
  async initVOTClient() {
    const t = this.data?.translateProxyEnabled ? this.data?.proxyWorkerHost ?? Sn : ah;
    this.votOpts = {
      fetchFn: ut,
      fetchOpts: {
        signal: this.actionsAbortController.signal,
        forceGmXhr: !0
      },
      apiToken: this.data?.account?.token,
      hostVOT: uh,
      host: t
    }, this.votClient = new (this.data?.translateProxyEnabled ? Wc : Hc)(this.votOpts), this.votClient.sessions = await this.votSessionStorage.restore(
      t,
      this.votClient.sessions
    );
    const e = this.votClient.getSession.bind(this.votClient);
    return this.votClient.getSession = async (i) => {
      const s = await e(i);
      return await this.votSessionStorage.persist(
        t,
        this.votClient.sessions
      ), s;
    }, this;
  }
  /**
   * Sets the translation button state and text.
   * @param {string} status The new status.
   * @param {string} text The text to display.
   * @returns {VideoHandler} This instance.
   */
  transformBtn(t, e) {
    return this.uiManager.transformBtn(t, e), this.syncPopupOverlayState({
      status: t === "disabled" ? "none" : t,
      label: e,
      hint: this.site.host === "youtube" || globalThis.location.hostname === "youtube.googleapis.com" ? "Google embedded player popup mode." : "Google-hosted player popup mode."
    }), this;
  }
  syncPopupOverlayState(t = {}) {
    if (!Ls() || !this.popupOverlayBridge?.isOwner(this.popupOwnerId))
      return;
    if (!this.popupOverlayBridge.isOpen())
      try {
        this.popupOverlayBridge.open();
      } catch (g) {
        console.warn("[VOT] popup open skipped", g);
        return;
      }
    const e = this.uiManager.votOverlayView, i = this.videoData?.detectedLanguage ?? this.translateFromLang ?? "auto", s = this.videoData?.responseLanguage ?? this.translateToLang ?? "ru", o = p.getLangLabel(i) || i, r = p.getLangLabel(s) || s, a = Number(
      e?.videoVolumeSlider?.value ?? Math.round(this.getVideoVolume() * 100)
    ), l = Number(
      e?.translationVolumeSlider?.value ?? this.data?.defaultVolume ?? 100
    ), c = e?.subtitlesSelect ? Array.from(e.subtitlesSelect.selectedValues)[0] : void 0, d = !!(this.yandexSubtitles && c && c !== "disabled"), h = ["auto", ...Bt].map((g) => ({
      value: g,
      label: g === "auto" ? p.get("langs.auto") : p.getLangLabel(g)
    })), f = Pi.map((g) => ({
      value: g,
      label: p.getLangLabel(g)
    }));
    this.popupOverlayBridge?.updateState({
      visible: !0,
      status: e?.votButton?.status === "disabled" ? "none" : e?.votButton?.status ?? "none",
      label: e?.votButton?.label?.textContent ?? p.get("translateVideo"),
      canDownload: !!this.downloadTranslationUrl,
      canDownloadSubtitles: !!this.yandexSubtitles,
      hint: "Popup mode for Google-hosted players.",
      fromLangLabel: o,
      toLangLabel: r,
      fromLangValue: i,
      toLangValue: s,
      fromLangOptions: h,
      toLangOptions: f,
      subtitlesEnabled: d,
      videoVolume: a,
      translationVolume: l,
      canAdjustTranslationVolume: !!this.hasActiveSource(),
      autoTranslateEnabled: !!this.data?.autoTranslate,
      autoSubtitlesEnabled: !!this.data?.autoSubtitles,
      syncVolumeEnabled: !!this.data?.syncVolume,
      showVideoSliderEnabled: this.data?.showVideoSlider !== !1,
      audioBoosterEnabled: !!this.data?.audioBooster,
      autoVolumeEnabled: this.data?.enabledAutoVolume !== !1,
      smartDuckingEnabled: this.data?.enabledSmartDucking !== !1,
      ...t
    });
  }
  /**
   * @returns {boolean} True if the extension audio player has active audio source
   */
  hasActiveSource() {
    return !!(this.audioPlayer?.player?.src || this.externalTranslationSourceUrl);
  }
  getSourceAudioAvailabilityState() {
    return hu(this.video);
  }
  syncSourceAudioAvailabilityUi(t = {}) {
    const e = this.getSourceAudioAvailabilityState(), i = this.uiManager.votOverlayView;
    if (!i?.votButton)
      return e;
    const s = i.votButton.status;
    if (t.forceVisible && (i.votButton.container.hidden = !1, i.updateButtonOpacity(1)), this.hasActiveSource() || i.votButton.loading)
      return e;
    if (!e.ready) {
      this.overlayVisibility?.cancel();
      const o = p.get(e.localizationKey);
      return this.transformBtn("disabled", o), e;
    }
    return s === "disabled" && (this.transformBtn("none", p.get("translateVideo")), this.overlayVisibility?.queueAutoHide()), e;
  }
  isAwaitingAutoplayRecovery() {
    return this.callModule(i0);
  }
  clearPendingAutoplayRecovery(t = !1) {
    this.callModule(n0, t);
  }
  resumePendingAutoplayRecovery(t = "manual") {
    return this.callModuleAsync(s0, t);
  }
  primePlaybackByGesture(t = "manual") {
    return this.callModuleAsync(r0, t);
  }
  /**
   * Initializes extra event listeners (resize, click outside, keydown, etc.).
   */
  initExtraEvents() {
    return this.callModule(mS);
  }
  /**
   * Recomputes overlay mount points and rebinds interaction targets.
   *
   * Used when fullscreen state changes without changing `this.container`
   * (common for players inside Shadow DOM).
   */
  refreshOverlayMount() {
    if (_t(this.site)) {
      const i = this.resolveCurrentContainer();
      i !== this.container && (this.container = i);
    }
    this.mountCache = void 0;
    const t = this.getOverlayMount(this.container), e = !$u(this.uiManager.mount, t);
    this.uiManager.updateMount(t), e && this.rebindOverlayVisibilityTargets();
  }
  /**
   * Called when the video can play.
   */
  setCanPlay() {
    return this.lifecycleController.setCanPlay();
  }
  isOverlayInteractiveNode(t) {
    return this.callModule(yS, t);
  }
  /**
   * Schedules hiding the overlay button with guard checks for internal navigation.
   */
  getAutoHideDelay() {
    return this.callModule(bS);
  }
  /**
   * Enables subtitles that match the currently selected language pair (from -> to).
   *
   * Used by the subtitles hotkey: prefers Yandex captions for the exact pair,
   * then falls back to any captions in the target language.
   */
  enableSubtitlesForCurrentLangPair() {
    return this.callModuleAsync(HT);
  }
  /**
   * Toggles subtitles for the current video.
   *
   * - If subtitles are enabled, this disables them.
   * - If subtitles are disabled, this enables the best subtitles track for the
   *   current language pair.
   */
  toggleSubtitlesForCurrentLangPair() {
    return this.callModuleAsync(WT);
  }
  getRequestLangForTranslation(t, e) {
    return this.data?.useLivelyVoice && this.data?.account?.token && e === "ru" ? "en" : t;
  }
  isLivelyVoiceAllowed(t = this.videoData?.detectedLanguage ?? "auto", e = this.videoData?.responseLanguage ?? this.translateToLang) {
    return !(this.getRequestLangForTranslation(
      t,
      e
    ) !== "en" || e !== "ru" || !this.data?.account?.token);
  }
  /**
   * Gets the video volume.
   * @returns {number} The video volume (0.0 - 1.0).
   */
  getVideoVolume() {
    return this.videoManager.getVideoVolume();
  }
  /**
   * Sets the video volume.
   * @param {number} volume A number between 0 and 1.
   * @returns {VideoHandler} This instance.
   */
  setVideoVolume(t, e = {}) {
    const i = fe(t), s = typeof e.suppressSyncMs == "number" && Number.isFinite(e.suppressSyncMs) ? Math.max(0, e.suppressSyncMs) : this.internalVideoVolumeSuppressionMs, o = Date.now(), r = Cu(i);
    return this.internalVideoVolumeSetAt = o, this.internalVideoVolumeSetPercent = r, this.internalVideoVolumeSetHistory.push({
      at: o,
      percent: r,
      suppressMs: s
    }), this.internalVideoVolumeSetHistory.length > this.internalVideoVolumeSetHistoryLimit && this.internalVideoVolumeSetHistory.splice(
      0,
      this.internalVideoVolumeSetHistory.length - this.internalVideoVolumeSetHistoryLimit
    ), this.videoManager.setVideoVolume(i), this;
  }
  /**
   * Keeps internal syncVolume state aligned with observed/programmatic video-volume changes.
   */
  onVideoVolumeSliderSynced(t) {
    const e = Rt(t);
    if (!this.volumeLinkState.initialized) {
      gs(this.volumeLinkState, e);
      return;
    }
    this.data?.syncVolume && this.hasActiveSource() && !this.isLikelyInternalVideoVolumeChange(e) || gs(this.volumeLinkState, e);
  }
  /**
   * Keeps internal translation-volume snapshot aligned when syncVolume is
   * temporarily disabled, so re-enabling link mode does not apply stale deltas.
   */
  onTranslationVolumeSliderSynced(t) {
    if (!this.volumeLinkState.initialized) {
      ms(this.volumeLinkState, t);
      return;
    }
    ms(this.volumeLinkState, t);
  }
  /**
   * Re-seeds syncVolume baseline from current UI slider values.
   * Useful when toggling syncVolume on/off to avoid stale delta state.
   */
  resetVolumeLinkState(t, e) {
    gs(this.volumeLinkState, t), ms(this.volumeLinkState, e), this.volumeLinkState.initialized = !0;
  }
  /**
   * Checks if the video is muted.
   * @returns {boolean} True if muted.
   */
  isMuted() {
    return this.videoManager.isMuted();
  }
  /**
   * Syncs the video volume slider.
   */
  syncVideoVolumeSlider() {
    this.videoManager.syncVideoVolumeSlider(), this.syncPopupOverlayState();
  }
  /**
   * Sets language select menu values.
   * @param {string} from Source language.
   * @param {string} to Target language.
   */
  setSelectMenuValues(t, e) {
    this.videoManager.setSelectMenuValues(
      t,
      e
    ), this.syncPopupOverlayState();
  }
  /**
   * Keeps translation and video sliders linked (syncVolume option).
   *
   * The implementation is delta-based: when the user changes one slider, the
   * other slider moves by the same delta. This preserves the relative
   * difference between volumes and works with "audio booster" (translation can
   * exceed 100%).
   */
  syncVolumeWrapper(t, e) {
    const i = this.uiManager.votOverlayView;
    if (!i?.isInitialized())
      return;
    const s = i.videoVolumeSlider, o = i.translationVolumeSlider;
    if (!s || !o)
      return;
    const { nextVideo: r, nextTranslation: a } = iS({
      state: this.volumeLinkState,
      fromType: t,
      newVolume: e,
      currentVideo: Number(s.value),
      currentTranslation: Number(o.value),
      translationMin: o.min,
      translationMax: o.max
    });
    if (typeof a == "number") {
      o.value = a, this.audioPlayer?.player && (this.audioPlayer.player.volume = a / 100);
      return;
    }
    typeof r == "number" && (s.value = r, this.setVideoVolume(r / 100));
  }
  /**
   * Retrieves video data.
   * @returns {Promise<Object>} The video data object.
   */
  getVideoData() {
    return this.videoManager.getVideoData();
  }
  sanitizeDownloadName(t) {
    return t.replace(/\.(mp4|mkv|mov|webm|avi|m4v|mp3|srt|vtt|json)$/iu, "").replace(/[<>:"/\\|?*]/g, "_").replace(/\s+/g, " ").trim();
  }
  getDownloadBaseName() {
    const t = typeof this.videoData?.downloadTitle == "string" && this.videoData.downloadTitle.trim() ? this.videoData.downloadTitle : void 0, e = typeof this.videoData?.title == "string" && this.videoData.title.trim() ? this.videoData.title : void 0, i = typeof this.videoData?.videoTitle == "string" && this.videoData.videoTitle.trim() ? this.videoData.videoTitle : void 0, s = t || e || i || `translation-${this.videoData?.videoId ?? "audio"}`;
    return this.sanitizeDownloadName(s);
  }
  /**
   * Validates the video.
   * @returns {Promise<boolean>} True if valid.
   */
  videoValidator() {
    return this.videoManager.videoValidator();
  }
  /**
   * Stops translation and resets UI elements.
   */
  stopTranslate() {
    if (this.stopTranslatePromise !== null)
      return this.stopTranslatePromise;
    const e = (async () => {
      if (this.clearPendingAutoplayRecovery(), this.externalTranslationSourceUrl = null, this.audioPlayer?.player) {
        try {
          this.audioPlayer.player.removeVideoEvents(), this.audioPlayer.player.src = "", await this.audioPlayer.player.clear();
        } catch {
        }
        C.log("audioPlayer after stopTranslate", this.audioPlayer);
      }
      this.activeTranslation = null;
      const i = this.uiManager.votOverlayView;
      i && (i.videoVolumeSlider && (i.videoVolumeSlider.hidden = !0), i.translationVolumeSlider && (i.translationVolumeSlider.hidden = !0), i.downloadTranslationButton && (i.downloadTranslationButton.hidden = !0)), this.downloadTranslationUrl = null, this.longWaitingResCount = 0, this.hadAsyncWait = !1, this.transformBtn("none", p.get("translateVideo"));
      const s = this.syncSourceAudioAvailabilityUi(), o = this.uiManager.votOverlayView?.votButton?.status, r = this.uiManager.votOverlayView?.votButton?.label?.textContent || p.get("translateVideo");
      this.syncPopupOverlayState({
        status: o === "success" || o === "error" ? o : "none",
        label: r,
        canDownload: !1,
        hint: s.ready ? "Translation audio is not available yet." : r
      }), C.log(`Volume on start: ${this.volumeOnStart}`);
      const a = typeof this.smartVolumeDuckingBaseline == "number" ? this.smartVolumeDuckingBaseline : this.volumeOnStart;
      Bn(this, { restoreVolume: a }), this.volumeOnStart = void 0, this.autoRetry !== void 0 && (clearTimeout(this.autoRetry), this.autoRetry = void 0), this.translationRefreshTimeout !== void 0 && (clearTimeout(this.translationRefreshTimeout), this.translationRefreshTimeout = void 0), this.resetActionsAbortController("stopTranslate");
    })().finally(() => {
      this.stopTranslatePromise === e && (this.stopTranslatePromise = null);
    });
    return this.stopTranslatePromise = e, e;
  }
  waitForPendingStopTranslate() {
    return this.stopTranslatePromise ?? E0;
  }
  /**
   * Updates the translation error message on the UI.
   * @param {string|Error} errorMessage The error message.
   */
  async updateTranslationErrorMsg(t, e) {
    if (e?.aborted)
      return;
    const i = p.get("translationTake"), s = p.lang;
    if (this.longWaitingResCount = t === p.get("translationTakeAboutMinute") ? this.longWaitingResCount + 1 : 0, C.log("longWaitingResCount", this.longWaitingResCount), this.longWaitingResCount > fh && (t = new bt("TranslationDelayed")), t?.name === "VOTLocalizedError")
      this.transformBtn("error", t.localizedMessage);
    else if (t instanceof Error)
      this.transformBtn("error", t?.message);
    else if (this.data?.translateAPIErrors && s !== "ru" && !t?.includes(i)) {
      const o = this.uiManager.votOverlayView;
      if (!o?.votButton)
        return;
      const r = Array.isArray(t) ? t.join(" ") : String(t), a = `${s}:${r}`, l = this.errorTranslationCache.get(a);
      if (l)
        this.transformBtn("error", l);
      else {
        o.votButton.loading = !0;
        const c = await Os(r, "ru", s), d = Array.isArray(c) ? c.join(`
`) : String(c);
        if (e?.aborted)
          return;
        if (this.errorTranslationCache.set(a, d), this.errorTranslationCache.size > 50) {
          const h = this.errorTranslationCache.keys().next().value;
          h && this.errorTranslationCache.delete(h);
        }
        this.transformBtn("error", d);
      }
      if (e?.aborted)
        return;
    } else {
      const o = Array.isArray(t) ? t.join(`
`) : String(t ?? "");
      this.transformBtn("error", o);
    }
    e?.aborted || [
      "Подготавливаем перевод",
      "Видео передано в обработку",
      "Ожидаем перевод видео",
      "Загружаем переведенное аудио"
    ].includes(t) && this.uiManager.votOverlayView?.votButton && (this.uiManager.votOverlayView.votButton.loading = !0);
  }
  /**
   * Called after translation is updated.
   * @param {string} audioUrl The URL of the translation audio.
   */
  afterUpdateTranslation(t) {
    const e = this.uiManager.votOverlayView;
    if (!e?.votButton)
      return;
    const i = e.votButton.container.dataset.status === "success";
    if (e.videoVolumeSlider && (e.videoVolumeSlider.hidden = !this.data?.showVideoSlider || !i), e.translationVolumeSlider && (e.translationVolumeSlider.hidden = !i), e.videoVolumeSlider && e.translationVolumeSlider ? (this.volumeLinkState.lastVideoPercent = Number(
      e.videoVolumeSlider.value
    ), this.volumeLinkState.lastTranslationPercent = Number(
      e.translationVolumeSlider.value
    ), this.volumeLinkState.initialized = !0) : this.volumeLinkState.initialized = !1, this.videoData && !this.videoData.isStream && (e.downloadTranslationButton && (e.downloadTranslationButton.hidden = !1), this.downloadTranslationUrl = t), C.log(
      "afterUpdateTranslation downloadTranslationUrl",
      this.downloadTranslationUrl
    ), this.syncTranslationPlaybackVolume(), this.syncPopupOverlayState({
      status: i ? "success" : "none",
      label: i ? "Turn off" : p.get("translateVideo"),
      canDownload: !!this.downloadTranslationUrl,
      canDownloadSubtitles: !!this.yandexSubtitles,
      hint: this.downloadTranslationUrl ? "Translated audio is ready for download." : "Waiting for translated audio."
    }), i && this.site.host === "vk" && this.videoData?.videoId) {
      const s = this.getSubtitlesCacheKey(
        this.videoData.videoId,
        this.videoData.detectedLanguage,
        this.videoData.responseLanguage
      );
      this.cacheManager.deleteSubtitles(s), this.subtitles = [], this.subtitlesCacheKey = null, (async () => {
        try {
          await this.loadSubtitles(), this.data?.autoSubtitles && await this.enableSubtitlesForCurrentLangPair();
        } catch (o) {
          C.log("[VOT][VK subtitles] failed to refresh after translation", {
            error: o,
            videoId: this.videoData?.videoId
          });
        }
      })();
    }
    this.data?.sendNotifyOnComplete && this.hadAsyncWait && i && (this.notifier.translationCompleted(globalThis.location.hostname), this.hadAsyncWait = !1);
  }
  /**
   * Validates the audio URL by sending a request.
   * @param {string} audioUrl The audio URL to validate.
   * @returns {Promise<string>} The valid audio URL.
   */
  validateAudioUrl(t, e) {
    return this.callModuleAsync(p0, t, e);
  }
  scheduleTranslationRefresh() {
    this.callModule(y0);
  }
  /**
   * Proxifies the audio URL if needed.
   * @param {string} audioUrl The original audio URL.
   * @returns {string} The proxified audio URL.
   */
  proxifyAudio(t) {
    return this.callModule(v0, t);
  }
  /**
   * Reverts a previously proxified audio URL back to the original Yandex S3 URL.
   *
   * This allows us to re-apply proxy settings when the proxy host/mode changes
   * without permanently "locking in" the old proxy host in the current player
   * src.
   */
  unproxifyAudio(t) {
    return this.callModule(w0, t);
  }
  isMultiMethodS3(t) {
    return this.callModule(T0, t);
  }
  /**
   * Translates the video/audio.
   * @param {string} VIDEO_ID The video ID.
   * @param {boolean} isStream Whether the video is a stream.
   * @param {string} requestLang Source language.
   * @param {string} responseLang Target language.
   * @param {any} translationHelp Optional translation helper data.
   */
  translateFunc(t, e, i, s, o) {
    return L0.call(
      this,
      t,
      e,
      i,
      s,
      o
    );
  }
  /**
   * used for enable audio downloader on this hosts
   */
  isYouTubeHosts() {
    return this.callModule(A0);
  }
  canUploadAudioForCurrentSite() {
    const t = this.site.host, e = String(
      this.videoData?.url || this.video?.currentSrc || this.video?.src || ""
    );
    return (() => {
      if (!e)
        return oe(t, this.videoData?.host);
      try {
        const s = new URL(
          e,
          globalThis.location.href
        ).toString();
        return this.votClient.isDirectMediaUrl(s) ? oe(t, this.videoData?.host) || new URL(s).hostname !== globalThis.location.hostname : oe(t, this.videoData?.host);
      } catch {
        return oe(t, this.videoData?.host);
      }
    })() ? !0 : this.data?.useAudioDownload ? t === "youtube" || t === "invidious" || t === "piped" || t === "yandexdisk" || t === "custom" || t === "vk" : !1;
  }
  /**
   * Configures audio settings such as volume.
   */
  setupAudioSettings() {
    return this.callModule(bc);
  }
  syncTranslationPlaybackVolume() {
    this.callModule(o0);
  }
  applyManualVideoVolumeOverride(t) {
    this.callModule(x0, t);
  }
  /**
   * Handles video source change events.
   */
  handleSrcChanged() {
    return this.lifecycleController.handleSrcChanged();
  }
  /**
   * Releases resources and removes event listeners.
   */
  async release() {
    /^(m|music)\.youtube\.com$/i.test(
      String(globalThis.location.hostname || "")
    ) && console.log("[VOT][mobile-overlay][handler] VideoHandler.release()", {
      videoId: this.videoData?.videoId,
      page: `${globalThis.location.origin}${globalThis.location.pathname}${globalThis.location.search}`
    }), this.initialized = !1;
    try {
      await this.stopTranslation();
    } catch {
    }
    this.lifecycleController?.teardown(), this.abortController?.abort(), this.abortController = new AbortController(), this.overlayVisibility?.release(), this.releaseExtraEvents(), this.hasSubtitlesWidget() && (this.subtitlesWidget?.release(), this.subtitlesWidget = void 0), this.interactionChecker?.destroy(), this.uiManager.release(), Ls() && this.popupOverlayBridge?.isOwner(this.popupOwnerId) && this.popupOverlayBridge.close(), this.popupOverlayBridge = void 0;
  }
  /**
   * Collects report information for bug reporting.
   * @returns {Object} Report info object.
   */
  collectReportInfo() {
    const t = zu(), e = this.videoData?.detectedLanguage ?? "unknown", i = this.videoData?.responseLanguage ?? "unknown", s = `<details>
<summary>Autogenerated by VOT:</summary>
<ul>
  <li>OS: ${t.os}</li>
  <li>Browser: ${t.browser}</li>
  <li>Loader: ${t.loader}</li>
  <li>Script version: ${t.scriptVersion}</li>
  <li>URL: <code>${t.url}</code></li>
  <li>Lang: <code>${e}</code> -> <code>${i}</code> (Lively voice: ${this.data?.useLivelyVoice ?? !1} | Audio download: ${this.data?.useAudioDownload ?? !1})</li>
  <li>Player: ${this.data?.newAudioPlayer ? "New" : "Old"} (CSP only: ${this.data?.onlyBypassMediaCSP ?? !1})</li>
  <li>Proxying mode: ${this.data?.translateProxyEnabled ?? 0}</li>
</ul>
</details>`;
    return {
      assignees: "Acobat12",
      template: `1-bug-report-${p.lang === "ru" ? "ru" : "en"}.yml`,
      os: t.os,
      "script-version": t.scriptVersion,
      "additional-info": s
    };
  }
}
const P0 = xo(), ei = new Hs(P0), M0 = /* @__PURE__ */ new WeakMap();
let an = null;
const Kt = sh();
function O0(n) {
  try {
    const e = new URL(n, globalThis.location.origin).pathname;
    return /\/file\/d\/([^/]+)/.exec(e)?.[1] || /\/videos\/d\/([^/]+)/.exec(e)?.[1] || /\/d\/([^/]+)/.exec(e)?.[1];
  } catch {
    return;
  }
}
function D0(n) {
  return typeof n != "string" ? void 0 : n.replace(/\s*-\s*Google Drive\s*$/i, "").replace(/\s*-\s*Google Диск\s*$/i, "").trim() || void 0;
}
function _0() {
  const n = Array.from(
    document.querySelectorAll('[data-is-tooltip-wrapper="true"] > span')
  ).map((s) => s.textContent?.trim() ?? "").find((s) => /\.(mp4|mkv|mov|webm|avi|m4v)$/i.test(s)) || "", t = document.querySelector('h1, [role="heading"], div[role="heading"]')?.textContent?.trim() || "", e = document.querySelector('meta[property="og:title"], meta[name="title"]')?.getAttribute("content")?.trim() || "", i = String(document.title || "").trim();
  return D0(
    n || t || e || i
  );
}
async function R0() {
  const n = globalThis.location.hostname;
  if (n !== "drive.google.com" && n !== "docs.google.com")
    return;
  const t = O0(globalThis.location.href);
  if (!t)
    return;
  const e = _0();
  if (e)
    try {
      await I.set(`googledrive:title:${t}`, e);
    } catch (i) {
      console.warn("[VOT] failed to persist Google Drive title", i);
    }
}
function B0() {
  return {
    frame: hi() ? "iframe" : "top",
    host: globalThis.location.hostname || "unknown",
    path: globalThis.location.pathname || "/"
  };
}
function Mt(n, t) {
  const e = B0(), i = {
    host: e.host,
    path: e.path
  };
  t && Object.assign(i, t), console.log(`[VOT][bootstrap][${e.frame}] ${n}`, i);
}
function Tl(n, t) {
  const e = t.hostname, i = (s) => {
    if (s instanceof RegExp) return s.test(e);
    if (typeof s == "string") return e.includes(s);
    if (typeof s == "function")
      try {
        return !!s(t);
      } catch {
        return !1;
      }
    return !1;
  };
  return Array.isArray(n.match) ? n.match.some(i) : i(n.match);
}
function kl() {
  if (!an) {
    const n = Qd(), t = new URL(globalThis.location.href), e = n.filter((r) => Tl(r, t));
    an = [...qm.filter((r) => Tl(r, t)), ...e];
    const s = {
      host: "custom",
      url: "stub",
      selector: q,
      eventSelector: q,
      rawResult: !0,
      priority: -1e3
    };
    an.some(
      (r) => String(r.host) === "custom" && r.selector === q
    ) || an.push(s);
  }
  return an;
}
function F0(n, t) {
  if (n.selector) {
    const i = An(t, n.selector);
    if (i)
      return i;
  }
  const e = An(
    t,
    q
  );
  return e || t.parentElement;
}
function N0() {
  const n = String(globalThis.location.hostname || "").toLowerCase();
  return n === "youtube.com" || n.endsWith(".youtube.com") || n === "youtu.be" || n.endsWith(".youtube-nocookie.com") || n.endsWith(".youtubekids.com") || n === "youtube.googleapis.com";
}
function U0() {
  return String(globalThis.location.hostname || "").toLowerCase() === "music.youtube.com";
}
function $0() {
  return U0() || !N0();
}
async function H0() {
  await R0(), $0() && pu();
  const n = hi(), t = op({
    isIframe: hi(),
    origin: globalThis.location.origin,
    authOrigin: On
  });
  if (t === "skip") {
    Mt("Skipping bootstrap for non-runnable iframe");
    return;
  }
  n && document.visibilityState === "hidden" && (Mt("Hidden iframe detected; delaying bootstrap until visible"), await new Promise((s) => {
    const o = () => {
      document.visibilityState !== "hidden" && (document.removeEventListener("visibilitychange", o), s());
    };
    document.addEventListener("visibilitychange", o), setTimeout(() => {
      document.removeEventListener("visibilitychange", o), s();
    }, 1500);
  })), Mt("Loading extension"), t === "auth-eager" ? $r("auth-page", Mt).catch((s) => {
    console.error("[VOT] Failed to activate runtime", s);
  }) : Mt("Lazy bootstrap enabled; waiting for video detection"), $m({
    videoObserver: ei,
    videosWrappers: M0,
    ensureRuntimeActivated: (s) => $r(s, Mt),
    getServicesCached: kl,
    findContainer: F0,
    createVideoHandler: (s, o, r) => new I0(s, o, r)
  });
  const e = kl(), i = ip({
    hostname: globalThis.location.hostname,
    services: e
  });
  if (ei.setPolicy(i), i.preferProbeBootstrap) {
    Mt("Lightweight video probe enabled", {
      strategy: i.probeStrategy,
      selectors: i.probeSelectors.join(", ")
    }), rh({
      strategy: i.probeStrategy,
      selectors: i.probeSelectors,
      pollIntervalMs: i.probePollIntervalMs,
      pollTimeoutMs: i.probePollTimeoutMs,
      onVideoDetected: (s, o) => {
        Mt("Probe detected candidate video", { reason: s }), ei.enable(o);
      }
    });
    return;
  }
  ei.enable();
}
const Ll = "data-vot-bootstrap-active";
if (document.documentElement.hasAttribute(Ll))
  Mt("dom bootstrap already initialized, skipping duplicate run");
else if (document.documentElement.setAttribute(Ll, "1"), Kt.status === "booting" || Kt.status === "booted")
  Mt("bootstrap already initialized, skipping duplicate run", {
    status: Kt.status
  });
else {
  const n = async () => {
    try {
      await H0(), Kt.status = "booted";
    } catch (t) {
      Kt.status = "failed", Kt.error = t, console.error("[VOT]", t);
    }
  };
  Kt.status = "booting", Kt.promise = n();
}
export {
  I0 as VideoHandler,
  We as countryCode,
  zu as getEnvironmentInfo
};
