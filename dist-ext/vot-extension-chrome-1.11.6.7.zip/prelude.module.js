//#region src/utils/debug.ts
var e = () => {}, t = {
	log: e,
	warn: e,
	error: e
};
//#endregion
//#region src/utils/errors.ts
function n(e) {
	let t = /* @__PURE__ */ new WeakSet();
	try {
		return JSON.stringify(e, (e, n) => typeof n != "object" || !n ? n : t.has(n) ? "[Circular]" : (t.add(n), n)) ?? null;
	} catch {
		return null;
	}
}
function r(e, t = "Unknown error") {
	if (e instanceof Error) return e.message || t;
	if (typeof e == "string") return e || t;
	if (e == null) return t;
	if (typeof e == "object") {
		let r = e;
		if (typeof r?.data?.message == "string" && r.data.message) return r.data.message;
		if (typeof r?.error?.message == "string" && r.error.message) return r.error.message;
		if (typeof r?.message == "string" && r.message) return r.message;
		let i = n(e);
		if (i && i !== "{}") return i;
		let a = e.constructor?.name;
		return a ? `[${a}]` : t;
	}
	return typeof e == "number" || typeof e == "boolean" || typeof e == "bigint" ? `${e}` : typeof e == "symbol" ? e.description ? `Symbol(${e.description})` : "Symbol" : typeof e == "function" ? e.name ? `[Function ${e.name}]` : "[Function]" : t;
}
//#endregion
//#region src/extension/base64.ts
var i = { alphabet: "base64url" }, a = typeof Uint8Array.prototype.toBase64 == "function" ? Uint8Array.prototype.toBase64 : null, o = Uint8Array.fromBase64;
function s(e) {
	let t = String(e).replaceAll(/\s+/g, ""), n = t.length % 4;
	if (n === 1) throw TypeError("Invalid base64 input.");
	return n === 0 ? t : t + "=".repeat(4 - n);
}
function ee(e) {
	let t = "";
	for (let n of e) t += String.fromCharCode(n);
	return t;
}
function te(e) {
	let t = globalThis.atob;
	if (typeof t != "function") throw TypeError("Base64 decoder is not available in this environment.");
	let n = t(e), r = new Uint8Array(n.length);
	for (let e = 0; e < n.length; e += 1) r[e] = n.charCodeAt(e);
	return r;
}
function ne(e) {
	let t = globalThis.btoa;
	if (typeof t != "function") throw TypeError("Base64 encoder is not available in this environment.");
	return t(ee(e));
}
function re(e) {
	let t = s(e), n = t.replaceAll("-", "+").replaceAll("_", "/");
	if (typeof o != "function") return te(n);
	let r = t.includes("-") || t.includes("_"), a = t.includes("+") || t.includes("/");
	return r && !a ? o(t, i) : o(r && a ? n : t);
}
function c(e) {
	return typeof a == "function" ? a.call(e) : ne(e);
}
function l(e) {
	return re(e);
}
//#endregion
//#region src/extension/bodySerialization.ts
var u = 1e7, ie = 12, ae = 2;
function d(e) {
	return typeof e == "object" && !!e;
}
function oe(e) {
	return f(e) === "[object Object]";
}
function f(e) {
	try {
		return Object.prototype.toString.call(e);
	} catch {
		return null;
	}
}
function p(e) {
	return f(e) === "[object ArrayBuffer]";
}
function se(e) {
	try {
		let t = e?.constructor?.name;
		return typeof t == "string" ? t : null;
	} catch {
		return null;
	}
}
function m(e, t) {
	try {
		let n = e?.[t];
		return typeof n == "string" ? n : null;
	} catch {
		return null;
	}
}
function h(e) {
	if (f(e) === "[object Blob]") return !0;
	if (!e || typeof e != "object") return !1;
	try {
		let t = e, n = typeof t.arrayBuffer == "function", r = typeof t.slice == "function", i = typeof t.size == "number", a = typeof t.type == "string";
		return (n || r) && i && a;
	} catch {
		return !1;
	}
}
function ce(e) {
	try {
		return JSON.stringify(e);
	} catch {
		return null;
	}
}
function g(e) {
	if (typeof e != "number" || !Number.isFinite(e)) return null;
	let t = Math.trunc(e);
	return t < 0 || t > u ? null : t;
}
function _(e) {
	return typeof e != "number" || !Number.isFinite(e) ? null : Math.trunc(e) & 255;
}
function v(e) {
	let t = e.length;
	if (t > u) return null;
	let n = new Uint8Array(t);
	for (let r = 0; r < t; r += 1) {
		let t = _(e[r]);
		if (t === null) return null;
		n[r] = t;
	}
	return n;
}
function y(e) {
	return new Uint8Array(e.buffer, e.byteOffset, e.byteLength);
}
function b(e) {
	return y(e).slice();
}
function le(e) {
	if (e === "") return null;
	let t = Number(e);
	return !Number.isFinite(t) || !Number.isInteger(t) || t < 0 ? null : t;
}
function x(e) {
	if (!d(e)) return !1;
	let t = e;
	return t.__votExtBody === !0 && typeof t.b64 == "string";
}
function S(e) {
	return {
		__votExtBody: !0,
		kind: "bytes",
		b64: c(e)
	};
}
function ue(e, t) {
	return {
		__votExtBody: !0,
		kind: "blob",
		b64: c(e),
		mime: t
	};
}
async function de(e) {
	if (!d(e)) return null;
	try {
		let t = e;
		if (typeof t.arrayBuffer == "function") return {
			ab: await t.arrayBuffer(),
			mime: m(t, "type")
		};
	} catch {}
	if (typeof Response < "u") try {
		return {
			ab: await new Response(e).arrayBuffer(),
			mime: m(e, "type")
		};
	} catch {}
	if (typeof Blob < "u" && h(e)) try {
		return {
			ab: await e.arrayBuffer(),
			mime: m(e, "type")
		};
	} catch {}
	return null;
}
function C(e, t = 0) {
	if (t > ae || !d(e)) return null;
	let n = e;
	if (p(e)) return new Uint8Array(e);
	try {
		if (ArrayBuffer.isView(e)) return b(e);
	} catch {}
	if (Array.isArray(e)) return v(e);
	if (n.type === "Buffer" && Array.isArray(n.data)) {
		let e = v(n.data);
		if (e) return e;
	}
	if (Array.isArray(n.data)) {
		let e = v(n.data);
		if (e) return e;
	}
	if (Array.isArray(n.bytes)) {
		let e = v(n.bytes);
		if (e) return e;
	}
	if (typeof n.b64 == "string") try {
		return l(n.b64);
	} catch {}
	if (typeof n.base64 == "string") try {
		return l(n.base64);
	} catch {}
	let r = g(n.byteLength), i = g(n.byteOffset ?? 0);
	if (r !== null && i !== null) {
		let a = n.buffer;
		if (p(a)) try {
			return new Uint8Array(a, i, r).slice();
		} catch {}
		if (a && a !== e) {
			let e = C(a, t + 1);
			if (e) {
				if (i > e.byteLength) return null;
				let t = Math.min(e.byteLength, i + r);
				return e.slice(i, t);
			}
		}
	}
	let a = g(n.length);
	if (a !== null) {
		let e = n, t = new Uint8Array(a);
		for (let n = 0; n < a; n += 1) {
			let r = _(e[n]);
			if (r === null) return null;
			t[n] = r;
		}
		return t;
	}
	if (oe(e)) {
		let e = Object.keys(n);
		if (!e.length) return null;
		let t = Array(e.length), r = -1;
		for (let n = 0; n < e.length; n += 1) {
			let i = le(e[n]);
			if (i === null || i > u) return null;
			t[n] = i, i > r && (r = i);
		}
		let i = new Uint8Array(r + 1);
		for (let r = 0; r < e.length; r += 1) {
			let a = e[r], o = _(n[a]);
			if (o === null) return null;
			i[t[r]] = o;
		}
		return i;
	}
	return null;
}
function w(e) {
	return C(e);
}
function T(e) {
	let t = e === null ? "null" : typeof e, n = f(e), r = se(e);
	if (e == null) return {
		kind: "empty",
		jsType: t,
		tag: n,
		ctor: r
	};
	if (typeof e == "string") return {
		kind: "string",
		jsType: t,
		tag: n,
		ctor: r,
		textLength: e.length
	};
	if (x(e)) return {
		kind: `serialized:${typeof e.kind == "string" && e.kind ? e.kind : "bytes"}`,
		jsType: t,
		tag: n,
		ctor: r,
		base64Length: e.b64.length,
		mime: m(e, "mime")
	};
	if (p(e)) return {
		kind: "ArrayBuffer",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: e.byteLength
	};
	try {
		if (ArrayBuffer.isView(e)) {
			let i = e;
			return {
				kind: r ? `TypedArray:${r}` : "TypedArray",
				jsType: t,
				tag: n,
				ctor: r,
				byteLength: i.byteLength
			};
		}
	} catch {}
	if (h(e)) return {
		kind: "BlobLike",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: typeof e.size == "number" ? Number(e.size) : -1,
		mime: m(e, "type")
	};
	let i = w(e);
	if (i) return {
		kind: "coerced-bytes",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: i.byteLength
	};
	if (d(e)) {
		let i = Object.keys(e);
		return {
			kind: "object",
			jsType: t,
			tag: n,
			ctor: r,
			keyCount: i.length,
			keys: i.slice(0, ie)
		};
	}
	return {
		kind: "primitive",
		jsType: t,
		tag: n,
		ctor: r
	};
}
async function fe(e) {
	if (e == null || typeof e == "string") return e;
	if (x(e)) return e.kind === "blob" ? {
		__votExtBody: !0,
		kind: "blob",
		b64: e.b64,
		mime: m(e, "mime")
	} : {
		__votExtBody: !0,
		kind: "bytes",
		b64: e.b64
	};
	if (p(e)) return S(new Uint8Array(e));
	try {
		if (ArrayBuffer.isView(e)) return S(y(e));
	} catch {}
	let t = await de(e);
	if (t) return ue(new Uint8Array(t.ab), t.mime);
	let n = w(e);
	if (n) return S(n);
	let r = T(e);
	try {
		console.warn("[VOT Extension] Unsupported GM_xmlhttpRequest body type; coercing fallback.", r);
	} catch {}
	if (d(e)) {
		let t = ce(e);
		if (typeof t == "string") return t;
	}
	return String(e);
}
//#endregion
//#region src/extension/constants.ts
var pe = "__VOT_EXT_BRIDGE__", E = "VOT_EXT_REQ", me = "VOT_EXT_RES", D = "VOT_EXT_XHR_START", O = "VOT_EXT_XHR_ABORT", he = "VOT_EXT_XHR_ACK", ge = "VOT_EXT_XHR_EVENT", k = "VOT_EXT_NOTIFY", A = /* @__PURE__ */ new Set([
	E,
	me,
	k,
	D,
	O,
	he,
	ge
]);
function j(e) {
	return !!(e && typeof e == "object" && e.__VOT_EXT_BRIDGE__ === !0 && typeof e.type == "string" && A.has(e.type));
}
//#endregion
//#region src/extension/bridgeTransport.ts
function M(e) {
	return {
		...e,
		[pe]: !0
	};
}
function N(e) {
	return M(e);
}
//#endregion
//#region src/extension/prelude.ts
var P = "__VOT_EXT_PRELUDE_BOOTED__", F = 1e3, I = 15e3, L = typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now().toString(36)}_${Math.random().toString(36).slice(2)}`;
function R(e) {
	return e && typeof e == "object" ? e : {};
}
function _e(e) {
	if (e == null) return;
	let t = Number(e);
	return Number.isFinite(t) ? t : void 0;
}
function z(e) {
	globalThis.postMessage(N(e), "*");
}
function B(e) {
	let t = R(e);
	return {
		title: t.title == null ? void 0 : String(t.title),
		text: t.text == null ? void 0 : String(t.text),
		image: t.image == null ? void 0 : String(t.image),
		silent: !!t.silent,
		timeout: _e(t.timeout),
		tag: t.tag == null ? void 0 : String(t.tag)
	};
}
var V = 0, H = /* @__PURE__ */ new Map();
function U() {
	return V += 1, `${L}_${V.toString(36)}`;
}
function W(e, t = {}) {
	let n = U();
	return new Promise((r, i) => {
		let a = globalThis.setTimeout(() => {
			H.delete(n), i(/* @__PURE__ */ Error(`VOT bridge timeout for ${e}`));
		}, I);
		H.set(n, {
			resolve: (e) => r(e),
			reject: i,
			timeoutId: a
		}), z({
			type: E,
			id: n,
			action: e,
			payload: t
		});
	});
}
var G = /* @__PURE__ */ new Map();
function K(e, t) {
	try {
		typeof e == "function" && e(t);
	} catch (e) {
		console.error("[VOT Extension] GM_xmlhttpRequest callback error", e);
	}
}
function q(e, t, n, r, i) {
	return (a) => {
		if (K(t[e], a), !n.isSettled) {
			if (n.isSettled = !0, e === "onload") {
				r(a);
				return;
			}
			i(a);
		}
	};
}
function J(e) {
	let t = G.get(e);
	return t ? (t.settled = !0, G.delete(e), t.timeoutId !== null && clearTimeout(t.timeoutId), t.callbacks) : null;
}
function Y(e, n) {
	n.timeoutId !== null && (clearTimeout(n.timeoutId), n.timeoutId = null), !(n.settled || !n.acknowledged || !Number.isFinite(n.timeoutMs) || n.timeoutMs <= 0) && (n.timeoutId = globalThis.setTimeout(() => {
		let n = G.get(e);
		if (!n || n.settled) return;
		t.warn("[VOT EXT][prelude] GM_xmlhttpRequest timeout fallback fired", {
			requestId: e,
			timeoutMs: n.timeoutMs,
			state: "terminal",
			lastBridgeEventAt: n.lastBridgeEventAt || null
		});
		let r = J(e);
		if (r) {
			try {
				z({
					type: O,
					requestId: e
				});
			} catch {}
			K(r.ontimeout, {
				finalUrl: String(n.callbacks.url || ""),
				readyState: 4,
				status: 0,
				statusText: "",
				responseHeaders: "",
				response: null,
				responseText: "",
				error: "Timeout"
			});
		}
	}, n.timeoutMs + F));
}
function X(e) {
	return {
		method: e.method,
		url: e.url,
		headers: e.headers,
		data: T(e.data),
		timeout: e.timeout,
		responseType: e.responseType,
		anonymous: e.anonymous,
		withCredentials: e.withCredentials
	};
}
async function ve(e) {
	let n = T(e.data), r = await fe(e.data), i = T(r);
	return t.log("[VOT EXT][prelude] GM_xmlhttpRequest body serialized", {
		url: e.url,
		method: e.method,
		from: n,
		to: i
	}), typeof r == "string" && /^\[object [^\]]+\]$/.test(r.trim()) && t.warn("[VOT EXT][prelude] suspicious serialized body string", {
		url: e.url,
		method: e.method,
		serializedBody: r,
		sourceBody: n
	}), {
		method: e.method,
		url: e.url,
		headers: e.headers,
		data: r,
		timeout: e.timeout,
		responseType: e.responseType,
		anonymous: e.anonymous,
		withCredentials: e.withCredentials
	};
}
function Z(e) {
	let t = R(e);
	return {
		status: t.status ?? null,
		statusText: t.statusText ?? null,
		readyState: t.readyState ?? null,
		finalUrl: t.finalUrl ?? null
	};
}
function ye(e, t) {
	return {
		finalUrl: String(e.url ?? ""),
		readyState: 4,
		status: 0,
		statusText: "",
		responseHeaders: "",
		response: null,
		responseText: "",
		error: t
	};
}
function be() {
	globalThis.GM_notification = (e) => {
		try {
			z({
				type: k,
				details: B(e)
			});
		} catch {}
	}, globalThis.GM_addStyle = (e) => {
		let t = document.createElement("style");
		return t.textContent = String(e ?? ""), (document.head || document.documentElement).appendChild(t), t;
	}, globalThis.GM_xmlhttpRequest = (e) => {
		let n = U(), i = R(e), a = Number(i.timeout ?? 0), o = {
			callbacks: i,
			timeoutId: null,
			timeoutMs: Number.isFinite(a) ? a : 0,
			acknowledged: !1,
			settled: !1,
			lastBridgeEventAt: 0
		};
		G.set(n, o);
		let s = !0;
		return t.log("[VOT EXT][prelude] GM_xmlhttpRequest", {
			requestId: n,
			state: "created",
			timeoutMs: o.timeoutMs,
			details: X(i)
		}), (async () => {
			try {
				if (!s || !G.has(n)) return;
				let e = await ve(i);
				if (!s || !G.has(n)) return;
				t.log("[VOT EXT][prelude] GM_xmlhttpRequest post TYPE_XHR_START", {
					requestId: n,
					details: X(i)
				}), z({
					type: D,
					requestId: n,
					details: e
				});
			} catch (e) {
				if (!s || !G.has(n)) return;
				s = !1;
				let a = r(e);
				t.log("[VOT EXT][prelude] GM_xmlhttpRequest start error", {
					requestId: n,
					error: a
				}), K(J(n)?.onerror, ye(i, a));
			}
		})(), { abort: () => {
			s && (s = !1, t.warn("[VOT EXT][prelude] GM_xmlhttpRequest abort called", { requestId: n }), J(n), z({
				type: O,
				requestId: n
			}));
		} };
	};
	let e = (e) => {
		let t = R(e), n = null, r = new Promise((e, r) => {
			let i = { ...t }, a = { isSettled: !1 };
			i.onload = q("onload", t, a, e, r), i.onerror = q("onerror", t, a, e, r), i.ontimeout = q("ontimeout", t, a, e, r), i.onabort = q("onabort", t, a, e, r);
			let o = globalThis.GM_xmlhttpRequest(i);
			n = o && typeof o.abort == "function" ? o.abort.bind(o) : null;
		});
		return r.abort = () => {
			try {
				n?.();
			} catch {}
		}, r;
	};
	globalThis.GM = {
		getValue: (e, t) => W("gm_getValue", {
			key: e,
			def: t
		}),
		setValue: (e, t) => W("gm_setValue", {
			key: e,
			value: t
		}),
		deleteValue: (e) => W("gm_deleteValue", { key: e }),
		listValues: () => W("gm_listValues"),
		getValues: (e) => W("gm_getValues", { defaults: e }),
		notification: (e) => {
			z({
				type: k,
				details: B(e)
			});
		},
		xmlHttpRequest: (t) => e(t)
	}, globalThis.GM_info = {
		script: {
			name: "VOT Extension",
			version: "0.0.0"
		},
		scriptHandler: "VOT Extension",
		version: "0.0.0"
	};
}
function xe() {
	globalThis.addEventListener("message", (e) => {
		if (e.source !== globalThis.window) return;
		let t = e.data;
		j(t) && (Se(t) || Ce(t) || Ee(t));
	});
}
function Se(e) {
	if (e.type !== "VOT_EXT_RES") return !1;
	let t = String(e.id ?? ""), n = H.get(t);
	return n ? (H.delete(t), clearTimeout(n.timeoutId), e.ok ? n.resolve(e.result) : n.reject(Error(r(e.error ?? "Bridge error"))), !0) : !0;
}
function Ce(e) {
	if (e.type !== "VOT_EXT_XHR_ACK") return !1;
	let n = String(e.requestId ?? ""), r = G.get(n);
	return r ? (r.acknowledged = !0, r.lastBridgeEventAt = Date.now(), Y(n, r), t.log("[VOT EXT][prelude] XHR acknowledged", {
		requestId: n,
		state: "acknowledged",
		timeoutMs: r.timeoutMs,
		payload: e.payload ?? null
	}), !0) : !0;
}
function we(e, n, r) {
	t.log("[VOT EXT][prelude] XHR event", {
		requestId: e,
		state: n === "progress" ? "in_flight" : "terminal",
		kind: n,
		...Z(r.response ?? r.error ?? r.progress)
	});
}
function Q(e, n, r) {
	t.log("[VOT EXT][prelude] XHR terminal load", {
		requestId: e,
		state: "terminal",
		...Z(r.response)
	}), K(n.onload, r.response), J(e);
}
function Te(e, n, r, i) {
	let a = i === "error" ? t.error : t.warn, o = {
		error: "onerror",
		timeout: "ontimeout",
		abort: "onabort"
	}[i];
	a(`[VOT EXT][prelude] XHR terminal ${i}`, {
		requestId: e,
		state: "terminal",
		...Z(r.error),
		error: r?.error?.error ?? null
	}), K(n[o], r.error), J(e);
}
function Ee(e) {
	if (e.type !== "VOT_EXT_XHR_EVENT") return;
	let n = String(e.requestId ?? ""), r = G.get(n);
	if (!r) return;
	let i = r.callbacks, a = R(e.payload), o = String(a.type ?? "");
	if (we(n, o, a), o === "progress") {
		r.lastBridgeEventAt = Date.now(), Y(n, r), K(i.onprogress, a.progress);
		return;
	}
	if (o === "load") {
		Q(n, i, a);
		return;
	}
	if (o === "error" || o === "timeout" || o === "abort") {
		Te(n, i, a, o);
		return;
	}
	t.warn("[VOT EXT][prelude] unexpected XHR bridge event", {
		requestId: n,
		kind: o,
		payload: a
	});
}
var $ = globalThis;
if ($[P]) t.log("[VOT EXT][prelude] already initialized");
else {
	$[P] = !0;
	let e = async () => {
		be(), xe();
		try {
			let { manifest: e } = await W("handshake"), t = globalThis.GM_info;
			e?.name && (t.script.name = e.name), e?.version && (t.script.version = e.version, t.version = e.version);
		} catch {}
	};
	(async () => {
		try {
			await e();
		} catch {}
	})();
}
//#endregion
