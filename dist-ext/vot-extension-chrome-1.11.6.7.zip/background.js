//#region src/utils/debug.ts
var e = () => {}, t = {
	log: e,
	warn: e,
	error: e
}, n = { alphabet: "base64url" }, r = typeof Uint8Array.prototype.toBase64 == "function" ? Uint8Array.prototype.toBase64 : null, i = Uint8Array.fromBase64;
function a(e) {
	let t = String(e).replaceAll(/\s+/g, ""), n = t.length % 4;
	if (n === 1) throw TypeError("Invalid base64 input.");
	return n === 0 ? t : t + "=".repeat(4 - n);
}
function o(e) {
	let t = "";
	for (let n of e) t += String.fromCharCode(n);
	return t;
}
function s(e) {
	let t = globalThis.atob;
	if (typeof t != "function") throw TypeError("Base64 decoder is not available in this environment.");
	let n = t(e), r = new Uint8Array(n.length);
	for (let e = 0; e < n.length; e += 1) r[e] = n.charCodeAt(e);
	return r;
}
function c(e) {
	let t = globalThis.btoa;
	if (typeof t != "function") throw TypeError("Base64 encoder is not available in this environment.");
	return t(o(e));
}
function l(e) {
	let t = a(e), r = t.replaceAll("-", "+").replaceAll("_", "/");
	if (typeof i != "function") return s(r);
	let o = t.includes("-") || t.includes("_"), c = t.includes("+") || t.includes("/");
	return o && !c ? i(t, n) : i(o && c ? r : t);
}
function u(e) {
	return typeof r == "function" ? r.call(e) : c(e);
}
function ee(e) {
	return u(new Uint8Array(e));
}
function d(e) {
	return l(e);
}
//#endregion
//#region src/extension/bodySerialization.ts
var f = 1e7, p = 12, m = 2;
function h(e) {
	return typeof e == "object" && !!e;
}
function g(e) {
	return _(e) === "[object Object]";
}
function _(e) {
	try {
		return Object.prototype.toString.call(e);
	} catch {
		return null;
	}
}
function v(e) {
	return _(e) === "[object ArrayBuffer]";
}
function y(e) {
	try {
		let t = e?.constructor?.name;
		return typeof t == "string" ? t : null;
	} catch {
		return null;
	}
}
function b(e, t) {
	try {
		let n = e?.[t];
		return typeof n == "string" ? n : null;
	} catch {
		return null;
	}
}
function x(e) {
	if (_(e) === "[object Blob]") return !0;
	if (!e || typeof e != "object") return !1;
	try {
		let t = e, n = typeof t.arrayBuffer == "function", r = typeof t.slice == "function", i = typeof t.size == "number", a = typeof t.type == "string";
		return (n || r) && i && a;
	} catch {
		return !1;
	}
}
function S(e) {
	try {
		return JSON.stringify(e);
	} catch {
		return null;
	}
}
function C(e) {
	if (typeof e != "number" || !Number.isFinite(e)) return null;
	let t = Math.trunc(e);
	return t < 0 || t > f ? null : t;
}
function w(e) {
	return typeof e != "number" || !Number.isFinite(e) ? null : Math.trunc(e) & 255;
}
function T(e) {
	let t = e.length;
	if (t > f) return null;
	let n = new Uint8Array(t);
	for (let r = 0; r < t; r += 1) {
		let t = w(e[r]);
		if (t === null) return null;
		n[r] = t;
	}
	return n;
}
function E(e) {
	return new Uint8Array(e.buffer, e.byteOffset, e.byteLength);
}
function D(e) {
	return E(e).slice();
}
function O(e) {
	if (e === "") return null;
	let t = Number(e);
	return !Number.isFinite(t) || !Number.isInteger(t) || t < 0 ? null : t;
}
function k(e) {
	if (!h(e)) return !1;
	let t = e;
	return t.__votExtBody === !0 && typeof t.b64 == "string";
}
function A(e, t = 0) {
	if (t > m || !h(e)) return null;
	let n = e;
	if (v(e)) return new Uint8Array(e);
	try {
		if (ArrayBuffer.isView(e)) return D(e);
	} catch {}
	if (Array.isArray(e)) return T(e);
	if (n.type === "Buffer" && Array.isArray(n.data)) {
		let e = T(n.data);
		if (e) return e;
	}
	if (Array.isArray(n.data)) {
		let e = T(n.data);
		if (e) return e;
	}
	if (Array.isArray(n.bytes)) {
		let e = T(n.bytes);
		if (e) return e;
	}
	if (typeof n.b64 == "string") try {
		return d(n.b64);
	} catch {}
	if (typeof n.base64 == "string") try {
		return d(n.base64);
	} catch {}
	let r = C(n.byteLength), i = C(n.byteOffset ?? 0);
	if (r !== null && i !== null) {
		let a = n.buffer;
		if (v(a)) try {
			return new Uint8Array(a, i, r).slice();
		} catch {}
		if (a && a !== e) {
			let e = A(a, t + 1);
			if (e) {
				if (i > e.byteLength) return null;
				let t = Math.min(e.byteLength, i + r);
				return e.slice(i, t);
			}
		}
	}
	let a = C(n.length);
	if (a !== null) {
		let e = n, t = new Uint8Array(a);
		for (let n = 0; n < a; n += 1) {
			let r = w(e[n]);
			if (r === null) return null;
			t[n] = r;
		}
		return t;
	}
	if (g(e)) {
		let e = Object.keys(n);
		if (!e.length) return null;
		let t = Array(e.length), r = -1;
		for (let n = 0; n < e.length; n += 1) {
			let i = O(e[n]);
			if (i === null || i > f) return null;
			t[n] = i, i > r && (r = i);
		}
		let i = new Uint8Array(r + 1);
		for (let r = 0; r < e.length; r += 1) {
			let a = e[r], o = w(n[a]);
			if (o === null) return null;
			i[t[r]] = o;
		}
		return i;
	}
	return null;
}
function j(e) {
	return A(e);
}
function M(e) {
	let t = e === null ? "null" : typeof e, n = _(e), r = y(e);
	if (e == null) return {
		kind: "empty",
		jsType: t,
		tag: n,
		ctor: r
	};
	if (typeof e == "string") return {
		kind: "string",
		jsType: t,
		tag: n,
		ctor: r,
		textLength: e.length
	};
	if (k(e)) return {
		kind: `serialized:${typeof e.kind == "string" && e.kind ? e.kind : "bytes"}`,
		jsType: t,
		tag: n,
		ctor: r,
		base64Length: e.b64.length,
		mime: b(e, "mime")
	};
	if (v(e)) return {
		kind: "ArrayBuffer",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: e.byteLength
	};
	try {
		if (ArrayBuffer.isView(e)) {
			let i = e;
			return {
				kind: r ? `TypedArray:${r}` : "TypedArray",
				jsType: t,
				tag: n,
				ctor: r,
				byteLength: i.byteLength
			};
		}
	} catch {}
	if (x(e)) return {
		kind: "BlobLike",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: typeof e.size == "number" ? Number(e.size) : -1,
		mime: b(e, "type")
	};
	let i = j(e);
	if (i) return {
		kind: "coerced-bytes",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: i.byteLength
	};
	if (h(e)) {
		let i = Object.keys(e);
		return {
			kind: "object",
			jsType: t,
			tag: n,
			ctor: r,
			keyCount: i.length,
			keys: i.slice(0, p)
		};
	}
	return {
		kind: "primitive",
		jsType: t,
		tag: n,
		ctor: r
	};
}
function te(e) {
	if (e == null) return;
	if (typeof e == "string") return e;
	if (k(e)) {
		let t = d(e.b64);
		if ((typeof e.kind == "string" && e.kind ? e.kind : "bytes") === "blob") {
			let n = e.mime, r = t.buffer;
			return typeof n == "string" && n ? new Blob([r], { type: n }) : new Blob([r]);
		}
		return t;
	}
	let t = j(e);
	if (t) return t;
	if (h(e)) {
		let t = S(e);
		if (typeof t == "string") return t;
	}
	return String(e);
}
//#endregion
//#region src/extension/webext.ts
var N = globalThis.browser, P = globalThis.chrome, F = N ?? P ?? null, ne = !!N && F === N;
function I() {
	let e = P?.runtime?.lastError ?? F?.runtime?.lastError;
	return e?.message ? String(e.message) : null;
}
async function L(e, t = [], n = {}) {
	if (typeof e != "function") throw TypeError("WebExtension API is not available");
	let r = n.mapCbArgs, i = n.rejectOnLastError !== !1;
	return ne ? await e(...t) : await new Promise((n, a) => {
		try {
			e(...t, (...e) => {
				let t = i ? I() : null;
				t ? a(Error(t)) : n(r ? r(...e) : e[0]);
			});
		} catch (e) {
			a(e);
		}
	});
}
async function re(e, t) {
	let n = F?.notifications, r = n?.create;
	!n || typeof r != "function" || await L(r.bind(n), [e, t], { mapCbArgs: () => void 0 });
}
async function ie(e) {
	let t = F?.notifications, n = t?.clear;
	!t || typeof n != "function" || await L(n.bind(t), [e], {
		mapCbArgs: () => void 0,
		rejectOnLastError: !1
	});
}
async function ae(e, t) {
	let n = F?.windows, r = n?.update;
	!n || typeof r != "function" || await L(r.bind(n), [e, t], {
		mapCbArgs: () => void 0,
		rejectOnLastError: !1
	});
}
async function oe(e, t) {
	let n = F?.tabs, r = n?.update;
	!n || typeof r != "function" || await L(r.bind(n), [e, t], {
		mapCbArgs: () => void 0,
		rejectOnLastError: !1
	});
}
//#endregion
//#region src/extension/yandexHeaders.ts
var se = "api.browser.yandex.ru", ce = /* @__PURE__ */ new Set([
	"sec-ch-ua",
	"sec-ch-ua-mobile",
	"sec-ch-ua-platform",
	"sec-ch-ua-full-version-list"
]), R = [
	"sec-ch-ua-full-version",
	"sec-ch-ua-platform-version",
	"sec-ch-ua-arch",
	"sec-ch-ua-bitness",
	"sec-ch-ua-model",
	"sec-ch-ua-wow64"
], le = new Set(R);
function ue(e) {
	return String(e || "") === se;
}
function z(e) {
	return String(e || "").trim();
}
function de(e) {
	let t = z(e).toLowerCase();
	return t ? !!(t === "origin" || t === "referer" || le.has(t) || t.startsWith("sec-ch-ua") && !ce.has(t)) : !1;
}
function fe(e) {
	let t = {};
	for (let [n, r] of Object.entries(e || {})) {
		let e = z(n);
		e && (de(e) || (t[e] = String(r)));
	}
	return t;
}
//#endregion
//#region src/extension/background.ts
var pe = 512 * 1024, B = 9001, V = 9002, H = 9003, U = /* @__PURE__ */ new Map(), W = Promise.resolve();
function G() {
	return !!F?.declarativeNetRequest?.updateSessionRules;
}
function me(e) {
	let t = F?.declarativeNetRequest?.updateSessionRules;
	if (typeof t != "function") return Promise.resolve();
	try {
		let n = t({
			addRules: e.addRules || [],
			removeRuleIds: e.removeRuleIds || []
		});
		if (n && typeof n.then == "function") return n;
	} catch {}
	return new Promise((n, r) => {
		try {
			t({
				addRules: e.addRules || [],
				removeRuleIds: e.removeRuleIds || []
			}, () => {
				let e = I();
				e ? r(Error(e)) : n();
			});
		} catch (e) {
			r(e);
		}
	});
}
function he(e) {
	let t = z(e).toLowerCase();
	return t ? !!(t.startsWith("sec-") || t.startsWith("proxy-") || t === "user-agent" || t === "origin" || t === "referer") : !1;
}
function K(e) {
	let t = e.map((e) => [`${z(String(e.header)).toLowerCase()}:${String(e.operation)}`, String("value" in e ? e.value : "")]).sort((e, t) => e[0].localeCompare(t[0]));
	return JSON.stringify(t);
}
function q(e, t, n) {
	return t === U.get(e) ? Promise.resolve() : (W = W.catch(() => void 0).then(async () => {
		t !== U.get(e) && (await me({
			removeRuleIds: [e],
			addRules: [n]
		}), U.set(e, t));
	}), W);
}
async function ge(e, t) {
	if (!G()) return;
	let n = "";
	try {
		n = new URL(e).hostname;
	} catch {
		return;
	}
	if (!ue(n)) return;
	let r = [
		{
			header: "Origin",
			operation: "remove"
		},
		{
			header: "Referer",
			operation: "remove"
		},
		...R.map((e) => ({
			header: e,
			operation: "remove"
		}))
	], i = fe(t);
	for (let [e, t] of Object.entries(i)) r.push({
		header: z(e),
		operation: "set",
		value: String(t)
	});
	await q(B, K(r), {
		id: B,
		priority: 1,
		action: {
			type: "modifyHeaders",
			requestHeaders: r
		},
		condition: {
			urlFilter: "|https://api.browser.yandex.ru/",
			resourceTypes: ["xmlhttprequest"],
			tabIds: [-1]
		}
	});
}
function _e(e) {
	try {
		let t = new URL(e);
		return t.protocol === "https:" && t.hostname === "www.youtube.com" && t.pathname.startsWith("/youtubei/");
	} catch {
		return !1;
	}
}
function ve(e) {
	try {
		let t = new URL(e), n = t.hostname.toLowerCase();
		return t.protocol === "https:" && (n === "googlevideo.com" || n.endsWith(".googlevideo.com"));
	} catch {
		return !1;
	}
}
async function ye(e) {
	if (!G() || !_e(e)) return;
	let t = [
		{
			header: "Origin",
			operation: "remove"
		},
		{
			header: "x-client-data",
			operation: "remove"
		},
		{
			header: "x-goog-visitor-id",
			operation: "remove"
		}
	];
	await q(V, JSON.stringify({
		v: 2,
		headers: K(t)
	}), {
		id: V,
		priority: 1,
		action: {
			type: "modifyHeaders",
			requestHeaders: t
		},
		condition: {
			urlFilter: "|https://www.youtube.com/youtubei/",
			resourceTypes: ["xmlhttprequest"],
			tabIds: [-1]
		}
	});
}
async function be(e) {
	if (!G() || !ve(e)) return;
	let t = [{
		header: "x-client-data",
		operation: "remove"
	}];
	await q(H, JSON.stringify({
		v: 1,
		headers: K(t)
	}), {
		id: H,
		priority: 1,
		action: {
			type: "modifyHeaders",
			requestHeaders: t
		},
		condition: {
			urlFilter: "||googlevideo.com/",
			resourceTypes: ["xmlhttprequest"],
			tabIds: [-1]
		}
	});
}
function J(e) {
	if (e instanceof Error) return e.message;
	if (e && typeof e == "object") try {
		return JSON.stringify(e);
	} catch {
		return Object.prototype.toString.call(e);
	}
	try {
		return String(e);
	} catch {
		return "Unknown error";
	}
}
function xe(e) {
	return Array.from(e.entries()).map(([e, t]) => `${e}: ${t}`).join("\r\n");
}
function Se(e) {
	let t = {};
	if (!e) return t;
	for (let [n, r] of Object.entries(e)) r !== void 0 && (typeof r == "string" || typeof r == "number" || typeof r == "boolean") && (t[String(n)] = String(r));
	return t;
}
function Y(e, t) {
	return {
		finalUrl: e,
		readyState: 4,
		status: 0,
		statusText: "",
		responseHeaders: "",
		response: null,
		responseText: "",
		error: t
	};
}
function Ce(e, t) {
	let n = t.toLowerCase();
	for (let [t, r] of Object.entries(e)) if (String(t).toLowerCase() === n) return String(r);
}
function we(e) {
	let t = String(e || "").toLowerCase();
	return t ? t.includes("application/x-protobuf") || t.includes("application/protobuf") || t.includes("application/octet-stream") : !1;
}
function Te(e) {
	let t = String(e || "");
	if (!t || /\s/.test(t) || !/^[A-Za-z0-9+/=_-]+$/.test(t) || !/[+/=_-]/.test(t)) return null;
	let n = t.replaceAll("-", "+").replaceAll("_", "/"), r = n.length % 4;
	if (r === 1) return null;
	let i = r === 0 ? n : `${n}${"=".repeat(4 - r)}`;
	try {
		return d(i);
	} catch {
		return null;
	}
}
function Ee(e) {
	let t = String(e || ""), n = new Uint8Array(t.length);
	for (let e = 0; e < t.length; e += 1) n[e] = (t.codePointAt(e) ?? 0) & 255;
	return n;
}
function De(e) {
	return /^\[object [^\]]+\]$/.test(String(e || "").trim());
}
var X = 0;
F?.runtime?.onConnect?.addListener?.((e) => {
	if (!e || typeof e != "object") return;
	let n = e;
	if (n.name !== "vot_gm_xhr" || typeof n.onDisconnect?.addListener != "function" || typeof n.onMessage?.addListener != "function" || typeof n.postMessage != "function") return;
	let r = (e) => {
		n.postMessage?.(e);
	};
	X += 1;
	let i = X, a = null, o = null, s = !1, c = !1, l = () => {
		o !== null && (clearTimeout(o), o = null);
	};
	n.onDisconnect.addListener(() => {
		l(), t.warn("[VOT EXT][background][xhr] port disconnected", { xhrSessionId: i });
		try {
			a?.abort();
		} catch {}
	}), n.onMessage.addListener(async (e) => {
		if (!e || typeof e != "object") return;
		if (e.type === "abort") {
			s = !0, t.warn("[VOT EXT][background][xhr] abort requested", { xhrSessionId: i });
			try {
				a?.abort();
			} catch {}
			return;
		}
		if (e.type !== "start") return;
		let n = s && a === null;
		s = !1;
		let { details: d } = e, f = d.url, p = (d.method || "GET").toUpperCase(), m = Se(d.headers), h = {}, g = {};
		for (let [e, t] of Object.entries(m)) he(e) ? g[e] = t : h[e] = t;
		let _ = Number(d.timeout || 0), v = String(d.responseType || "text").toLowerCase();
		if (t.log("[VOT EXT][background][xhr] start", {
			xhrSessionId: i,
			state: "in_flight",
			url: f,
			method: p,
			responseType: v,
			timeoutMs: _,
			headerCount: Object.keys(m).length,
			headerNames: Object.keys(m),
			forbiddenHeaderNames: Object.keys(g),
			body: M(d.data)
		}), n) {
			let e = {
				finalUrl: f,
				readyState: 4,
				status: 0,
				statusText: "",
				responseHeaders: "",
				response: null,
				responseText: "",
				error: "Aborted"
			};
			try {
				r({
					type: "abort",
					state: "terminal",
					error: e
				});
			} catch {}
			return;
		}
		c = !1, a = new AbortController(), _ > 0 && (o = setTimeout(() => {
			c = !0;
			try {
				a?.abort();
			} catch {}
		}, _));
		let y = "include";
		(d.anonymous || d.withCredentials === !1) && (y = "omit");
		try {
			let e;
			d.nocache ? e = "no-store" : d.revalidate && (e = "no-cache");
			let n = d.redirect === "error" || d.redirect === "manual" ? d.redirect : "follow", o = p !== "GET" && p !== "HEAD";
			try {
				await be(f), await ye(f), await ge(f, g);
			} catch (e) {
				console.warn("[VOT Extension] Failed to apply DNR header rules; requests may break:", e);
			}
			let s = o ? te(d.data) : void 0, c, _ = () => (c === void 0 && (c = j(d.data)), c), b = Ce(m, "content-type"), x = we(b);
			if (t.log("[VOT EXT][background][xhr] body decoded", {
				xhrSessionId: i,
				url: f,
				method: p,
				contentType: b ?? null,
				isProtobufRequest: x,
				sourceBody: M(d.data),
				decodedBody: M(s)
			}), o && x && s == null) {
				let e = _();
				e && (s = e, t.warn("[VOT EXT][background][xhr] protobuf body recovered from raw payload", {
					xhrSessionId: i,
					url: f,
					method: p,
					recoveredBody: M(s)
				}));
			}
			if (o && typeof s == "string" && x) {
				if (De(s)) {
					let e = _();
					e && (s = e, t.warn("[VOT EXT][background][xhr] recovered protobuf body from object-like string fallback", {
						xhrSessionId: i,
						url: f,
						method: p,
						sourceBody: M(d.data),
						recoveredBody: M(e)
					}));
				}
				if (typeof s == "string") {
					let e = Te(s);
					s = e ?? Ee(s), t.log("[VOT EXT][background][xhr] protobuf string converted to bytes", {
						xhrSessionId: i,
						url: f,
						method: p,
						strategy: e ? "base64" : "latin1",
						convertedBody: M(s)
					});
				}
			}
			t.log("[VOT EXT][background][xhr] fetch dispatch", {
				xhrSessionId: i,
				url: f,
				method: p,
				credentials: y,
				redirect: n,
				cache: e ?? "default",
				body: M(s)
			});
			let S = {
				method: p,
				headers: h,
				redirect: n,
				credentials: y,
				signal: a.signal
			};
			s !== void 0 && (S.body = s), e !== void 0 && (S.cache = e);
			let C = await fetch(f, S);
			t.log("[VOT EXT][background][xhr] fetch response received", {
				xhrSessionId: i,
				url: C.url || f,
				method: p,
				status: C.status,
				statusText: C.statusText,
				responseType: v,
				contentType: C.headers.get("content-type") || null,
				contentLength: C.headers.get("content-length") || null
			});
			let w = xe(C.headers), T = C.url || f, E = C.headers.get("content-type") || "", D = (e) => ({
				finalUrl: T,
				readyState: e,
				status: C.status,
				statusText: C.statusText,
				responseHeaders: w
			}), O = v === "arraybuffer" || v === "blob" || v === "stream", k, A, N;
			if (O) {
				let e = Number(C.headers.get("content-length") || 0);
				if (C.body && (!Number.isFinite(e) || e > pe)) {
					let t = 0, n = Number.isFinite(e) ? e : 0, i = C.body.getReader();
					for (;;) {
						let { done: e, value: a } = await i.read();
						if (e) break;
						a && (t += a.byteLength, r({
							type: "progress",
							state: "in_flight",
							progress: {
								...D(3),
								loaded: t,
								total: n,
								lengthComputable: n > 0,
								chunkB64: u(a)
							}
						}));
					}
					k = void 0;
				} else {
					let e = await C.arrayBuffer();
					e.byteLength > 0 && (N = ee(e)), k = void 0;
				}
			} else if (v === "json") {
				A = await C.text();
				try {
					k = JSON.parse(A);
				} catch {
					k = null;
				}
			} else A = await C.text(), k = A;
			l(), t.log("[VOT EXT][background][xhr] terminal", {
				xhrSessionId: i,
				state: "terminal",
				kind: "load",
				url: T,
				status: C.status,
				responseType: v,
				responseBody: M(k),
				responseTextLength: A?.length ?? 0,
				responseB64Length: N?.length ?? 0
			}), r({
				type: "load",
				state: "terminal",
				response: {
					...D(4),
					responseType: v,
					...E ? { contentType: E } : {},
					...N ? { responseB64: N } : {},
					response: k,
					...typeof A == "string" ? { responseText: A } : {}
				}
			});
		} catch (e) {
			if (l(), s || c || e instanceof DOMException && e.name === "AbortError") {
				let e;
				e = c ? "timeout" : "abort";
				let n = Y(f, e === "timeout" ? "Timeout" : "Aborted");
				try {
					r({
						type: e,
						state: "terminal",
						error: n
					});
				} catch {}
				t.warn("[VOT EXT][background][xhr] terminal", {
					xhrSessionId: i,
					state: "terminal",
					kind: e,
					url: f,
					method: p,
					responseType: v
				});
				return;
			}
			let n = Y(f, J(e));
			r({
				type: "error",
				state: "terminal",
				error: n
			}), t.error("[VOT EXT][background][xhr] terminal", {
				xhrSessionId: i,
				state: "terminal",
				kind: "error",
				url: f,
				method: p,
				responseType: v,
				error: n.error
			});
		}
	});
});
function Z(e) {
	return !e || typeof e != "object" ? !1 : e.type === "gm_notification";
}
function Q(e) {
	let t = e && typeof e == "object" ? e : {}, n = Number(t.timeout ?? 0);
	return {
		title: t.title == null ? "" : String(t.title),
		text: t.text == null ? "" : String(t.text),
		silent: !!t.silent,
		timeout: Number.isFinite(n) && n > 0 ? n : 0
	};
}
function Oe(e) {
	let t = e.tab?.id, n = e.tab?.windowId;
	return `vot:${typeof t == "number" ? t : -1}:${typeof n == "number" ? n : -1}:${typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}:${Math.random().toString(36).slice(2)}`}`;
}
function ke(e) {
	let t = typeof F?.runtime?.getBrowserInfo == "function", n = {
		type: "basic",
		iconUrl: F?.runtime?.getURL ? F.runtime.getURL("icons/icon-128.png") : "icons/icon-128.png",
		title: e.title || "VOT",
		message: e.text
	};
	return t || (n.silent = e.silent), n;
}
function $(e, t) {
	if (typeof e == "function") try {
		e(t);
	} catch {}
}
F?.runtime?.onMessage?.addListener?.((e, n, r) => {
	if (!Z(e)) return;
	let i = Q(e.details), a = Oe(n), o = ke(i);
	return (async () => {
		try {
			await re(a, o), i.timeout > 0 && setTimeout(() => {
				ie(a);
			}, i.timeout), $(r, { ok: !0 });
		} catch (e) {
			t.error("[VOT EXT][background] Failed to create notification", e), $(r, {
				ok: !1,
				error: J(e)
			});
		}
	})(), !0;
}), F?.notifications?.onClicked?.addListener?.((e) => {
	if (!e.startsWith("vot:")) return;
	let t = e.split(":");
	if (t.length < 3) return;
	let n = Number(t[1]), r = Number(t[2]);
	Number.isFinite(r) && r >= 0 && ae(r, { focused: !0 }), Number.isFinite(n) && n >= 0 && oe(n, { active: !0 });
});
//#endregion
export { Oe as createBridgeNotificationId, ke as createBridgeNotificationOptions, Z as isGmNotificationMessage, Q as normalizeGmNotificationDetails };
