// ==UserScript==
// @name            [FORK] - Voice Over Translation Safari Page Runtime
// @name:de         [VOT] - Voice-Over-Video-Übersetzung Safari Page Runtime
// @name:es         [VOT] - Traducción de vídeo en off Safari Page Runtime
// @name:fr         [VOT] - Traduction vidéo voix-off Safari Page Runtime
// @name:it         [VOT] - Traduzione Video fuori campo Safari Page Runtime
// @name:ru         [VOT] - Закадровый перевод видео Safari Page Runtime
// @name:zh         [VOT] - 画外音视频翻译 Safari Page Runtime
// @namespace       vot-direct
// @version         1.11.6.11
// @author          Toil, SashaXser, MrSoczekXD, mynovelhost, sodapng, Acobat12
// @description     A small extension that adds a Yandex Browser video translation to other browsers
// @description:de  Eine kleine Erweiterung, die eine Voice-over-Übersetzung von Videos aus dem Yandex-Browser zu anderen Browsern hinzufügt
// @description:es  Una pequeña extensión que agrega una traducción de voz en off de un video de Yandex Browser a otros navegadores
// @description:fr  Une petite extension qui ajoute la traduction vocale de la vidéo du Navigateur Yandex à d'autres navigateurs
// @description:it  Una piccola estensione che aggiunge la traduzione vocale del video dal browser Yandex ad altri browser
// @description:ru  Небольшое расширение, которое добавляет закадровый перевод видео из Яндекс Браузера в другие браузеры
// @description:zh  一个小扩展，它增加了视频从Yandex浏览器到其他浏览器的画外音翻译
// @license         MIT
// @icon            https://translate.yandex.ru/icons/favicon.ico
// @homepageURL     https://github.com/Acobat12/voice-over-translation-direct
// @source          https://github.com/Acobat12/voice-over-translation-direct.git
// @supportURL      https://github.com/Acobat12/voice-over-translation-direct/issues
// @downloadURL     https://raw.githubusercontent.com/Acobat12/voice-over-translation-direct/master/dist/vot-safari-page.user.js
// @updateURL       https://raw.githubusercontent.com/Acobat12/voice-over-translation-direct/master/dist/vot-safari-page.user.js
// @match           *://*.*
// @match           *://cloud.mail.ru/*
// @match           *://*.cloud.mail.ru/*
// @match           *://*.kodik.info/*
// @match           *://*.kodik.biz/*
// @match           *://*.kodik.cc/*
// @match           *://kodikplayer.com/*
// @match           *://*.kodikplayer.com/*
// @match           *://wikianimex.ru/*
// @match           *://*.wikianimex.ru/*
// @match           *://*.cdnvideohub.com/*
// @match           *://*.okcdn.ru/*
// @match           *://*.solodcdn.com/*
// @match           *://oauth.yandex.com/*
// @match           *://oauth.yandex.ru/*
// @match           *://*.youtube.com/*
// @match           *://*.youtube-nocookie.com/*
// @match           *://*.youtubekids.com/*
// @match           *://*.twitch.tv/*
// @match           *://*.xvideos.com/*
// @match           *://*.xvideos-ar.com/*
// @match           *://*.xvideos005.com/*
// @match           *://*.xv-ru.com/*
// @match           *://*.xhamster.com/*
// @match           *://*.xhamster.desi/*
// @match           *://*.xhvid.com/*
// @match           *://*.spankbang.com/*
// @match           *://*.rule34video.com/*
// @match           *://*.picarto.tv/*
// @match           *://*.olympics.com/*
// @match           *://*.pornhub.com/*
// @match           *://*.pornhub.org/*
// @match           *://*.vk.com/*
// @match           *://*.vkvideo.ru/*
// @match           *://*.vk.ru/*
// @match           *://*.vimeo.com/*
// @match           *://*.imdb.com/*
// @match           *://*.9gag.com/*
// @match           *://*.twitter.com/*
// @match           *://*.x.com/*
// @match           *://*.facebook.com/*
// @match           *://*.rutube.ru/*
// @match           *://*.bilibili.com/*
// @match           *://*.bilibili.tv/*
// @match           *://my.mail.ru/*
// @match           *://*.bitchute.com/*
// @match           *://*.coursera.org/*
// @match           *://*.udemy.com/course/*
// @match           *://*.tiktok.com/*
// @match           *://*.douyin.com/*
// @match           *://rumble.com/*
// @match           *://*.eporner.com/*
// @match           *://*.dailymotion.com/*
// @match           *://*.ok.ru/*
// @match           *://trovo.live/*
// @match           *://disk.yandex.ru/*
// @match           *://disk.yandex.kz/*
// @match           *://disk.yandex.com/*
// @match           *://disk.yandex.com.am/*
// @match           *://disk.yandex.com.ge/*
// @match           *://disk.yandex.com.tr/*
// @match           *://disk.yandex.by/*
// @match           *://disk.yandex.az/*
// @match           *://disk.yandex.co.il/*
// @match           *://disk.yandex.ee/*
// @match           *://disk.yandex.lt/*
// @match           *://disk.yandex.lv/*
// @match           *://disk.yandex.md/*
// @match           *://disk.yandex.net/*
// @match           *://disk.yandex.tj/*
// @match           *://disk.yandex.tm/*
// @match           *://disk.yandex.uz/*
// @match           *://disk.360.yandex.ru/*
// @match           *://drive.google.com/*
// @match           *://docs.google.com/*
// @match           *://youtube.googleapis.com/embed/*
// @match           *://*.banned.video/*
// @match           *://*.madmaxworld.tv/*
// @match           *://*.weverse.io/*
// @match           *://*.newgrounds.com/*
// @match           *://*.egghead.io/*
// @match           *://*.youku.com/*
// @match           *://*.archive.org/*
// @match           *://*.patreon.com/*
// @match           *://*.reddit.com/*
// @match           *://*.kick.com/*
// @match           *://developer.apple.com/*
// @match           *://dev.epicgames.com/*
// @match           *://*.rapid-cloud.co/*
// @match           *://odysee.com/*
// @match           *://learning.sap.com/*
// @match           *://*.watchporn.to/*
// @match           *://*.linkedin.com/*
// @match           *://*.incestflix.net/*
// @match           *://*.incestflix.to/*
// @match           *://*.porntn.com/*
// @match           *://*.dzen.ru/*
// @match           *://*.cloudflarestream.com/*
// @match           *://*.loom.com/*
// @match           *://*.artstation.com/learning/*
// @match           *://*.rt.com/*
// @match           *://*.bitview.net/*
// @match           *://*.kickstarter.com/*
// @match           *://*.thisvid.com/*
// @match           *://*.ign.com/*
// @match           *://*.bunkr.site/*
// @match           *://*.bunkr.black/*
// @match           *://*.bunkr.cat/*
// @match           *://*.bunkr.media/*
// @match           *://*.bunkr.red/*
// @match           *://*.bunkr.ws/*
// @match           *://*.bunkr.org/*
// @match           *://*.bunkr.sk/*
// @match           *://*.bunkr.si/*
// @match           *://*.bunkr.su/*
// @match           *://*.bunkr.ci/*
// @match           *://*.bunkr.cr/*
// @match           *://*.bunkr.fi/*
// @match           *://*.bunkr.ph/*
// @match           *://*.bunkr.pk/*
// @match           *://*.bunkr.ps/*
// @match           *://*.bunkr.ru/*
// @match           *://*.bunkr.la/*
// @match           *://*.bunkr.is/*
// @match           *://*.bunkr.to/*
// @match           *://*.bunkr.ac/*
// @match           *://*.bunkr.ax/*
// @match           *://web.telegram.org/k/*
// @match           *://rust-server-531j.onrender.com/*
// @match           *://mylearn.oracle.com/*
// @match           *://learn.deeplearning.ai/*
// @match           *://learn-staging.deeplearning.ai/*
// @match           *://learn-dev.deeplearning.ai/*
// @match           *://*.netacad.com/content/i2cs/*
// @match           *://*.nicovideo.jp/*
// @match           *://*.zdf.de/*
// @match           *://*.ivi.ru/*
// @match           *://*.kinopoisk.ru/*
// @match           *://*.okko.tv/*
// @match           *://*.okko.ru/*
// @match           *://*.kion.ru/*
// @match           *://*.wink.ru/*
// @match           *://*.seasonvar.ru/*
// @match           *://*.zrok.io/*
// @match           *://*.ts.net/*
// @match           *://*.tunnel4.com/*
// @match           *://*.lhr.life/*
// @match           *://iframe.mediadelivery.net/*
// @match           *://video.bunnycdn.com/*
// @match           *://*.weibo.com/*
// @match           *://*/*.mp4*
// @match           *://*/*.m4v*
// @match           *://*/*.webm*
// @match           *://*/*.mov*
// @match           *://*/*.mkv*
// @match           *://*/*.avi*
// @match           *://*/*.ogv*
// @match           *://*.trycloudflare.com/*
// @match           *://*.ngrok-free.app/*
// @match           *://*.ngrok-free.dev/*
// @match           *://*.ngrok.app/*
// @match           *://*.yewtu.be/*
// @match           *://inv.nadeko.net/*
// @match           *://invidious.nerdvpn.de/*
// @match           *://invidious.protokolla.fi/*
// @match           *://invidious.materialio.us/*
// @match           *://iv.melmac.space/*
// @match           *://*.piped.video/*
// @match           *://piped.kavin.rocks/*
// @match           *://piped.private.coffee/*
// @match           *://proxitok.pabloferreiro.es/*
// @match           *://proxitok.pussthecat.org/*
// @match           *://tok.habedieeh.re/*
// @match           *://proxitok.esmailelbob.xyz/*
// @match           *://proxitok.privacydev.net/*
// @match           *://tok.artemislena.eu/*
// @match           *://tok.adminforge.de/*
// @match           *://tt.vern.cc/*
// @match           *://cringe.whatever.social/*
// @match           *://proxitok.lunar.icu/*
// @match           *://proxitok.privacy.com.de/*
// @match           *://peertube.tmp.rcp.tf/*
// @match           *://*.dalek.zone/*
// @match           *://video.sadmin.io/*
// @match           *://videos.viorsan.com/*
// @match           *://peertube.1312.media/*
// @match           *://tube.shanti.cafe/*
// @match           *://*.bee-tube.fr/*
// @match           *://video.blender.org/*
// @match           *://*.beetoons.tv/*
// @match           *://*.makertube.net/*
// @match           *://*.peertube.tv/*
// @match           *://*.framatube.org/*
// @match           *://*.tilvids.com/*
// @match           *://*.diode.zone/*
// @match           *://*.fedimovie.com/*
// @match           *://video.hardlimit.com/*
// @match           *://*.share.tube/*
// @match           *://*.peervideo.club/*
// @match           *://*.coursehunter.net/*
// @match           *://*.coursetrain.net/*
// @exclude         *://accounts.youtube.com/*
// @exclude         *://github.com/*
// @exclude         *://*.github.com/*
// @exclude         *://githubusercontent.com/*
// @exclude         *://*.githubusercontent.com/*
// @exclude         *://githubassets.com/*
// @exclude         *://*.githubassets.com/*
// @require         https://gist.githubusercontent.com/ilyhalight/6eb5bb4dffc7ca9e3c57d6933e2452f3/raw/7ab38af2228d0bed13912e503bc8a9ee4b11828d/gm-addstyle-polyfill.js
// @connect         cloud-api.yandex.com
// @connect         oauth.yandex.ru
// @connect         yandex.ru
// @connect         disk.yandex.kz
// @connect         disk.yandex.com
// @connect         disk.yandex.com.am
// @connect         disk.yandex.com.ge
// @connect         disk.yandex.com.tr
// @connect         disk.yandex.by
// @connect         disk.yandex.az
// @connect         disk.yandex.co.il
// @connect         disk.yandex.ee
// @connect         disk.yandex.lt
// @connect         disk.yandex.lv
// @connect         disk.yandex.md
// @connect         disk.yandex.net
// @connect         disk.yandex.tj
// @connect         disk.yandex.tm
// @connect         disk.yandex.uz
// @connect         disk.360.yandex.ru
// @connect         yandex.net
// @connect         timeweb.cloud
// @connect         raw.githubusercontent.com
// @connect         vimeo.com
// @connect         vot.toil.cc
// @connect         *.toil.cc
// @connect         toil.cc
// @connect         deno.dev
// @connect         onrender.com
// @connect         workers.dev
// @connect         packaged-media.redd.it
// @connect         cloudflare-dns.com
// @connect         porntn.com
// @connect         youtube.com
// @connect         googlevideo.com
// @connect         vk.com
// @connect         *.vk.com
// @connect         *.douyinvod.com
// @connect         douyinvod.com
// @connect         *.douyin.com
// @connect         douyin.com
// @connect         www.douyin.com
// @connect         *.zjcdn.com
// @connect         zjcdn.com
// @connect         *.bytecdn.cn
// @connect         bytecdn.cn
// @connect         *.byteimg.com
// @connect         byteimg.com
// @connect         *
// @grant           none
// @inject-into     page
// ==/UserScript==
(function() {
	"use strict";
	var VideoService$1;
	(function(VideoService) {
		VideoService["custom"] = "custom";
		VideoService["directlink"] = "custom";
		VideoService["youtube"] = "youtube";
		VideoService["preservetube"] = "preservetube";
		VideoService["piped"] = "piped";
		VideoService["invidious"] = "invidious";
		VideoService["niconico"] = "niconico";
		VideoService["vk"] = "vk";
		VideoService["nine_gag"] = "nine_gag";
		VideoService["gag"] = "nine_gag";
		VideoService["twitch"] = "twitch";
		VideoService["proxitok"] = "proxitok";
		VideoService["tiktok"] = "tiktok";
		VideoService["vimeo"] = "vimeo";
		VideoService["xvideos"] = "xvideos";
		VideoService["xhamster"] = "xhamster";
		VideoService["spankbang"] = "spankbang";
		VideoService["rule34video"] = "rule34video";
		VideoService["picarto"] = "picarto";
		VideoService["olympicsreplay"] = "olympics_replay";
		VideoService["pornhub"] = "pornhub";
		VideoService["twitter"] = "twitter";
		VideoService["x"] = "twitter";
		VideoService["rumble"] = "rumble";
		VideoService["facebook"] = "facebook";
		VideoService["rutube"] = "rutube";
		VideoService["coub"] = "coub";
		VideoService["bilibili"] = "bilibili";
		VideoService["mail_ru"] = "mailru";
		VideoService["mailru"] = "mailru";
		VideoService["bitchute"] = "bitchute";
		VideoService["eporner"] = "eporner";
		VideoService["peertube"] = "peertube";
		VideoService["dailymotion"] = "dailymotion";
		VideoService["trovo"] = "trovo";
		VideoService["yandexdisk"] = "yandexdisk";
		VideoService["ok_ru"] = "okru";
		VideoService["okru"] = "okru";
		VideoService["googledrive"] = "googledrive";
		VideoService["bannedvideo"] = "bannedvideo";
		VideoService["weverse"] = "weverse";
		VideoService["weibo"] = "weibo";
		VideoService["newgrounds"] = "newgrounds";
		VideoService["egghead"] = "egghead";
		VideoService["youku"] = "youku";
		VideoService["archive"] = "archive";
		VideoService["kodik"] = "kodik";
		VideoService["patreon"] = "patreon";
		VideoService["reddit"] = "reddit";
		VideoService["kick"] = "kick";
		VideoService["apple_developer"] = "apple_developer";
		VideoService["appledeveloper"] = "apple_developer";
		VideoService["epicgames"] = "epicgames";
		VideoService["odysee"] = "odysee";
		VideoService["coursehunterLike"] = "coursehunterLike";
		VideoService["sap"] = "sap";
		VideoService["watchpornto"] = "watchpornto";
		VideoService["jove"] = "jove";
		VideoService["linkedin"] = "linkedin";
		VideoService["incestflix"] = "incestflix";
		VideoService["porntn"] = "porntn";
		VideoService["dzen"] = "dzen";
		VideoService["bunnystream"] = "bunnystream";
		VideoService["cloudflarestream"] = "cloudflarestream";
		VideoService["loom"] = "loom";
		VideoService["rtnews"] = "rtnews";
		VideoService["bitview"] = "bitview";
		VideoService["thisvid"] = "thisvid";
		VideoService["ign"] = "ign";
		VideoService["noodlemagazine"] = "noodlemagazine";
		VideoService["zdf"] = "zdf";
		VideoService["bunkr"] = "bunkr";
		VideoService["imdb"] = "imdb";
		VideoService["telegram"] = "telegram";
	})(VideoService$1 || (VideoService$1 = {}));
	var VideoDataError = class extends Error {
		constructor(message) {
			super(message);
			this.name = "VideoDataError";
		}
	};
	var localLinkRe = /(file:\/\/(\/)?|(http(s)?:\/\/)(127\.0\.0\.1|localhost|192\.168\.(\d){1,3}\.(\d){1,3}))/;
	var sitesInvidious = [
		"yewtu.be",
		"inv.nadeko.net",
		"invidious.nerdvpn.de",
		"invidious.protokolla.fi",
		"invidious.materialio.us",
		"iv.melmac.space"
	];
	var sitesPiped = [
		"piped.video",
		"piped.kavin.rocks",
		"piped.private.coffee"
	];
	var sitesProxiTok = [
		"proxitok.pabloferreiro.es",
		"proxitok.pussthecat.org",
		"tok.habedieeh.re",
		"proxitok.esmailelbob.xyz",
		"proxitok.privacydev.net",
		"tok.artemislena.eu",
		"tok.adminforge.de",
		"tt.vern.cc",
		"cringe.whatever.social",
		"proxitok.lunar.icu",
		"proxitok.privacy.com.de"
	];
	var sitesPeertube = [
		"peertube.tmp.rcp.tf",
		"dalek.zone",
		"video.sadmin.io",
		"videos.viorsan.com",
		"peertube.1312.media",
		"tube.shanti.cafe",
		"bee-tube.fr",
		"video.blender.org",
		"beetoons.tv",
		"makertube.net",
		"peertube.tv",
		"framatube.org",
		"tilvids.com",
		"diode.zone",
		"fedimovie.com",
		"video.hardlimit.com",
		"share.tube",
		"peervideo.club"
	];
	var sitesCoursehunterLike = ["coursehunter.net", "coursetrain.net"];
	var ExtVideoService;
	(function(ExtVideoService) {
		ExtVideoService["udemy"] = "udemy";
		ExtVideoService["coursera"] = "coursera";
		ExtVideoService["douyin"] = "douyin";
		ExtVideoService["artstation"] = "artstation";
		ExtVideoService["kickstarter"] = "kickstarter";
		ExtVideoService["datacamp"] = "datacamp";
		ExtVideoService["oraclelearn"] = "oraclelearn";
		ExtVideoService["deeplearningai"] = "deeplearningai";
		ExtVideoService["netacad"] = "netacad";
		ExtVideoService["mediafile"] = "mediafile";
		ExtVideoService["skilljar"] = "skilljar";
	})(ExtVideoService || (ExtVideoService = {}));
	({
		...VideoService$1,
		...ExtVideoService
	});
	var sharedSelectors = {
		bilibiliPlayer: ".bpx-player-video-wrap, div.player-mobile-box.player-mobile-autoplay",
		flowplayer: ".fp-player, div.flowplayer",
		idPlayer: "#player",
		jwPlayer: ".jwplayer, .jw-media",
		player: ".player",
		shakaPlayer: ".shaka-video-container, [id^=\"shaka-video-container-\"]",
		videoJsUniversal: "[id^='vjs_video_']:not([id*='_html5_api']):not(video), video-js:not([id*='_html5_api']), .video-js:not(video):not([id*='_html5_api']), .vjs-player:not([id*='_html5_api']), [data-vjs-player]:not([id*='_html5_api'])",
		vkVideoPlayer: ".videoplayer_media, vk-video-player"
	};
	var sites_default = [
		{
			additionalData: "mobile",
			host: VideoService$1.youtube,
			url: "https://youtu.be/",
			match: /^m.youtube.com$/,
			selector: ".player-container",
			needExtraData: true
		},
		{
			host: VideoService$1.youtube,
			url: "https://youtu.be/",
			match: (enteredUrl) => /^(www.)?youtube(-nocookie|kids)?.com$/.test(enteredUrl.hostname) && enteredUrl.pathname.startsWith("/tv"),
			selector: "#container",
			needExtraData: true
		},
		{
			host: VideoService$1.youtube,
			url: "https://youtu.be/",
			match: (url) => /^(www.)?youtube(-nocookie|kids)?.com$/.test(url.host) && !url.pathname.startsWith("/embed/"),
			selector: ".html5-video-container:not(#inline-player *)",
			needExtraData: true
		},
		{
			host: VideoService$1.youtube,
			url: "https://youtu.be/",
			additionalData: "embed",
			match: (url) => /^(www.)?youtube(-nocookie|kids)?.com$/.test(url.host) && url.pathname.startsWith("/embed/"),
			selector: "html",
			needExtraData: true
		},
		{
			host: VideoService$1.youtube,
			url: "https://youtu.be/",
			match: (url) => /^music\.youtube\.com$/.test(url.host),
			selector: "#song-video",
			eventSelector: "#player",
			needExtraData: true
		},
		{
			host: VideoService$1.invidious,
			url: "https://youtu.be/",
			match: sitesInvidious,
			selector: sharedSelectors.idPlayer,
			needBypassCSP: true
		},
		{
			host: VideoService$1.piped,
			url: "https://youtu.be/",
			match: sitesPiped,
			selector: sharedSelectors.shakaPlayer,
			needBypassCSP: true
		},
		{
			host: VideoService$1.preservetube,
			url: "https://preservetube.com/",
			match: /^preservetube\.com$/,
			selector: "div.video-wrapper",
			needExtraData: true
		},
		{
			host: VideoService$1.zdf,
			url: "https://www.zdf.de/play/",
			match: [/^zdf.de$/, /^(www.)?zdf.de$/],
			selector: "div.zdfplayer-app.zdfplayer-desktop, div.zdfplayer-app"
		},
		{
			host: VideoService$1.niconico,
			url: "https://www.nicovideo.jp/watch/",
			match: [/^(www\.|sp\.)?nicovideo\.jp$/, /^nico\.ms$/],
			selector: `[class*="grid-area_[player]"] > div`
		},
		{
			additionalData: "mobile",
			host: VideoService$1.vk,
			url: "https://vk.com/",
			match: [/^m.vk.(com|ru)$/, /^m.vkvideo.ru$/],
			selector: sharedSelectors.vkVideoPlayer,
			shadowRoot: true,
			needExtraData: true
		},
		{
			additionalData: "clips",
			host: VideoService$1.vk,
			url: "https://vk.com/",
			match: /^(www.|m.)?vk.(com|ru)$/,
			selector: "div[data-testid=\"clipcontainer-video\"]",
			needExtraData: true
		},
		{
			host: VideoService$1.vk,
			url: "https://vk.com/",
			match: [/^(www\.|m\.)?vk\.(com|ru)$/, /^(.*\.)?vkvideo\.ru$/],
			selector: sharedSelectors.vkVideoPlayer,
			needExtraData: true
		},
		{
			host: VideoService$1.nine_gag,
			url: "https://9gag.com/gag/",
			match: /^9gag.com$/,
			selector: ".video-post",
			needExtraData: true
		},
		{
			host: VideoService$1.twitch,
			url: "https://twitch.tv/",
			match: [
				/^m.twitch.tv$/,
				/^(www.)?twitch.tv$/,
				/^clips.twitch.tv$/,
				/^player.twitch.tv$/
			],
			needExtraData: true,
			selector: ".video-ref, main > div > section > div > div > div"
		},
		{
			host: VideoService$1.proxitok,
			url: "https://www.tiktok.com/",
			match: sitesProxiTok,
			selector: ".column.has-text-centered"
		},
		{
			host: VideoService$1.tiktok,
			url: "https://www.tiktok.com/",
			match: /^(www.)?tiktok.com$/,
			selector: null
		},
		{
			host: ExtVideoService.douyin,
			url: "https://www.douyin.com/",
			match: /^(www.)?douyin.com/,
			selector: ".xg-video-container",
			needExtraData: true,
			needBypassCSP: true
		},
		{
			host: VideoService$1.vimeo,
			url: "https://vimeo.com/",
			match: /^(www\.|m\.)?vimeo.com$/,
			needExtraData: true,
			selector: sharedSelectors.player
		},
		{
			host: VideoService$1.vimeo,
			url: "https://player.vimeo.com/",
			match: /^player.vimeo.com$/,
			additionalData: "embed",
			needExtraData: true,
			needBypassCSP: true,
			selector: sharedSelectors.player
		},
		{
			host: VideoService$1.xvideos,
			url: "https://www.xvideos.com/",
			match: [
				/^(www.)?xvideos(-ar)?.com$/,
				/^(www.)?xvideos(\d\d\d).com$/,
				/^(www.)?xv-ru.com$/
			],
			selector: "#hlsplayer",
			needBypassCSP: true
		},
		{
			host: VideoService$1.xhamster,
			url: "https://xhamster.com/",
			match: (url) => /^(?:[^.]+\.)?(?:xhamster\.(?:com|desi)|xhamster\d+\.(?:com|desi)|xhvid\.com)$/.test(url.host) && /\/(?:videos\/[^/]+-[\dA-Za-z]+)\/?$/.test(url.pathname),
			selector: "#player-container"
		},
		{
			host: VideoService$1.spankbang,
			url: "https://spankbang.com/",
			match: (url) => /^(?:[^.]+\.)?spankbang\.com$/.test(url.host) && /\/(?:[\da-z]+\/(?:video|play|embed)(?:\/[^/]+)?|[\da-z]+-[\da-z]+\/playlist\/[^/?#&]+)\/?$/i.test(url.pathname),
			selector: "#main_video_player"
		},
		{
			host: VideoService$1.rule34video,
			url: "https://rule34video.com/video/",
			match: (url) => /^(www\.)?rule34video\.com$/.test(url.host) && /\/videos?\/\d+/.test(url.pathname),
			selector: sharedSelectors.flowplayer
		},
		{
			host: VideoService$1.picarto,
			url: "https://picarto.tv/",
			match: (url) => /^(www\.)?picarto\.tv$/.test(url.host) && /^(?:\/[^/]+\/(?:profile\/)?videos\/[^/?#&]+|\/videopopout\/[^/?#&]+|\/[^/#?]+\/?)$/.test(url.pathname),
			selector: `[class*="VideosTab__PlayerWrapper"]`
		},
		{
			host: VideoService$1.olympicsreplay,
			url: "https://olympics.com/",
			match: (url) => /^(www\.)?olympics\.com$/.test(url.host) && /^\/[a-z]{2}\/(?:[a-z0-9-]+\/)?(?:replay|videos?|original-series\/episode)\/[\w-]+\/?$/i.test(url.pathname),
			selector: sharedSelectors.videoJsUniversal
		},
		{
			host: VideoService$1.pornhub,
			url: "https://rt.pornhub.com/view_video.php?viewkey=",
			match: /^[a-z]+.pornhub.(com|org)$/,
			selector: "div.video-element-wrapper-js"
		},
		{
			additionalData: "embed",
			host: VideoService$1.pornhub,
			url: "https://rt.pornhub.com/view_video.php?viewkey=",
			match: (url) => /^[a-z]+.pornhub.(com|org)$/.exec(url.host) && url.pathname.startsWith("/embed/"),
			selector: sharedSelectors.idPlayer
		},
		{
			host: VideoService$1.twitter,
			url: "https://twitter.com/i/status/",
			match: /^(twitter|x).com$/,
			selector: "div[data-testid=\"videoComponent\"]",
			needBypassCSP: true
		},
		{
			host: VideoService$1.rumble,
			url: "https://rumble.com/",
			match: /^rumble.com$/,
			selector: `[id^="vid_"] > div`
		},
		{
			host: VideoService$1.facebook,
			url: "https://facebook.com/",
			match: (url) => url.host.includes("facebook.com") && url.pathname.includes("/videos/"),
			selector: "div[role=\"main\"] div[data-pagelet$=\"video\" i]",
			needBypassCSP: true
		},
		{
			additionalData: "reels",
			host: VideoService$1.facebook,
			url: "https://facebook.com/",
			match: (url) => url.host.includes("facebook.com") && url.pathname.includes("/reel/"),
			selector: "div[role=\"main\"]",
			needBypassCSP: true
		},
		{
			host: VideoService$1.rutube,
			url: "https://rutube.ru/video/",
			match: /^rutube.ru$/,
			selector: `div[class*="videoWrapper"]`
		},
		{
			additionalData: "embed",
			host: VideoService$1.rutube,
			url: "https://rutube.ru/video/",
			match: /^rutube.ru$/,
			selector: "#app > div > div"
		},
		{
			host: VideoService$1.bilibili,
			url: "https://www.bilibili.com/",
			match: /^(www|m|player).bilibili.com$/,
			selector: sharedSelectors.bilibiliPlayer
		},
		{
			host: VideoService$1.bilibili,
			url: "https://www.bilibili.tv/",
			match: /^(?:www\.|m\.)?bilibili\.tv$/,
			selector: sharedSelectors.bilibiliPlayer
		},
		{
			additionalData: "old",
			host: VideoService$1.bilibili,
			url: "https://www.bilibili.com/",
			match: /^(www|m).bilibili.com$/,
			selector: null
		},
		{
			host: VideoService$1.mailru,
			url: "https://my.mail.ru/",
			match: /^my.mail.ru$/,
			selector: "#b-video-wrapper"
		},
		{
			host: VideoService$1.bitchute,
			url: "https://www.bitchute.com/video/",
			match: /^(www.)?bitchute.com$/,
			selector: sharedSelectors.videoJsUniversal
		},
		{
			host: VideoService$1.eporner,
			url: "https://www.eporner.com/",
			match: /^(www.)?eporner.com$/,
			selector: sharedSelectors.videoJsUniversal
		},
		{
			host: VideoService$1.peertube,
			url: "stub",
			match: sitesPeertube,
			selector: sharedSelectors.videoJsUniversal
		},
		{
			host: VideoService$1.dailymotion,
			url: "https://www.dailymotion.com/video/",
			match: /^((www\.|player\.)?dailymotion\.com|geo(\d+)?\.dailymotion\.com|dai\.ly)$/,
			selector: sharedSelectors.player
		},
		{
			host: VideoService$1.trovo,
			url: "https://trovo.live/s/",
			match: /^trovo.live$/,
			selector: ".player-video"
		},
		{
			host: VideoService$1.yandexdisk,
			url: "https://yadi.sk/",
			match: /^disk.yandex.(ru|kz|com(\.(am|ge|tr))?|by|az|co\.il|ee|lt|lv|md|net|tj|tm|uz)$/,
			selector: ".video-player__player > div:nth-child(1)",
			needBypassCSP: true,
			needExtraData: true
		},
		{
			host: VideoService$1.okru,
			url: "https://ok.ru/video/",
			match: /^ok.ru$/,
			selector: sharedSelectors.vkVideoPlayer,
			shadowRoot: true
		},
		{
			host: VideoService$1.googledrive,
			url: "https://drive.google.com/file/d/",
			match: /^youtube.googleapis.com$/,
			selector: "html"
		},
		{
			host: VideoService$1.bannedvideo,
			url: "https://madmaxworld.tv/watch?id=",
			match: /^(www.)?banned.video|madmaxworld.tv$/,
			selector: sharedSelectors.videoJsUniversal,
			needExtraData: true
		},
		{
			host: VideoService$1.weverse,
			url: "https://weverse.io/",
			match: /^weverse.io$/,
			selector: ".webplayer-internal-source-wrapper",
			needExtraData: true
		},
		{
			host: VideoService$1.weibo,
			url: "https://weibo.com/",
			match: (url) => /^(?:www\.)?weibo\.com$/.test(url.host) && /^\/(?:\d+\/[A-Za-z0-9]+|0\/[A-Za-z0-9]+|tv\/show\/\d+:(?:[\da-f]{32}|\d{16,}))\/?$/.test(url.pathname) || /^video\.weibo\.com$/.test(url.host) && /^\/show\/?$/.test(url.pathname) && /^\d+:(?:[\da-f]{32}|\d{16,})$/i.test(url.searchParams.get("fid") ?? "") || /^(?:www\.)?weibo\.com$/.test(url.host) && /^\/newlogin\/?$/.test(url.pathname) && (url.searchParams.has("url") || /^[A-Za-z0-9]+$/.test(url.searchParams.get("layerid") ?? "")),
			selector: sharedSelectors.videoJsUniversal || "#playVideo"
		},
		{
			host: VideoService$1.newgrounds,
			url: "https://www.newgrounds.com/",
			match: /^(www.)?newgrounds.com$/,
			selector: ".ng-video-player"
		},
		{
			host: VideoService$1.egghead,
			url: "https://egghead.io/",
			match: /^egghead.io$/,
			selector: ".cueplayer-react-video-holder"
		},
		{
			host: VideoService$1.youku,
			url: "https://v.youku.com/",
			match: /^v.youku.com$/,
			selector: "#ykPlayer"
		},
		{
			host: VideoService$1.archive,
			url: "https://archive.org/details/",
			match: /^archive.org$/,
			selector: sharedSelectors.jwPlayer,
			needExtraData: true
		},
		{
			host: VideoService$1.kodik,
			url: "stub",
			match: /^kodikplayer.com$/,
			selector: sharedSelectors.flowplayer,
			needExtraData: true
		},
		{
			host: VideoService$1.patreon,
			url: "stub",
			match: /^(www.)?patreon.com$/,
			selector: `[class*="videoArea"]`,
			needExtraData: true
		},
		{
			additionalData: "old",
			host: VideoService$1.reddit,
			url: "stub",
			match: /^old.reddit.com$/,
			selector: ".reddit-video-player-root",
			needExtraData: true,
			needBypassCSP: true
		},
		{
			host: VideoService$1.reddit,
			url: "stub",
			match: /^(www.|new.)?reddit.com$/,
			selector: "div[slot=post-media-container]",
			shadowRoot: true,
			needExtraData: true,
			needBypassCSP: true
		},
		{
			host: VideoService$1.kick,
			url: "https://kick.com/",
			match: /^kick.com$/,
			selector: "#injected-embedded-channel-player-video > div",
			needExtraData: true
		},
		{
			host: VideoService$1.appledeveloper,
			url: "https://developer.apple.com/",
			match: /^developer.apple.com$/,
			selector: ".developer-video-player",
			needExtraData: true,
			needBypassCSP: true
		},
		{
			host: VideoService$1.epicgames,
			url: "https://dev.epicgames.com/community/learning/",
			match: /^dev.epicgames.com$/,
			selector: sharedSelectors.videoJsUniversal,
			needExtraData: true
		},
		{
			host: VideoService$1.odysee,
			url: "stub",
			match: /^odysee.com$/,
			selector: ".video-js-parent",
			needExtraData: true
		},
		{
			host: VideoService$1.coursehunterLike,
			url: "stub",
			match: sitesCoursehunterLike,
			selector: null,
			needExtraData: true
		},
		{
			host: VideoService$1.sap,
			url: "https://learning.sap.com/courses/",
			match: /^learning.sap.com$/,
			selector: ".kaltura-player-container",
			needExtraData: true,
			needBypassCSP: true
		},
		{
			host: ExtVideoService.udemy,
			url: "https://www.udemy.com/",
			match: /udemy.com$/,
			selector: sharedSelectors.shakaPlayer,
			needExtraData: true
		},
		{
			host: ExtVideoService.datacamp,
			url: "https://www.datacamp.com/courses/",
			match: (url) => /^(?:campus\.|projector\.)?datacamp\.com$/.test(url.hostname),
			selector: sharedSelectors.videoJsUniversal,
			needExtraData: true
		},
		{
			host: ExtVideoService.coursera,
			url: "https://www.coursera.org/",
			match: /coursera.org$/,
			selector: sharedSelectors.videoJsUniversal,
			needExtraData: true
		},
		{
			host: VideoService$1.watchpornto,
			url: "https://watchporn.to/",
			match: /^watchporn.to$/,
			selector: sharedSelectors.flowplayer
		},
		{
			host: VideoService$1.jove,
			url: "https://jove.com/",
			match: /^(?:app|www)\.jove\.com$/,
			selector: sharedSelectors.flowplayer,
			needExtraData: true
		},
		{
			host: VideoService$1.linkedin,
			url: "https://www.linkedin.com/learning/",
			match: /^(www.)?linkedin.com$/,
			selector: sharedSelectors.videoJsUniversal,
			needExtraData: true,
			needBypassCSP: true
		},
		{
			host: VideoService$1.incestflix,
			url: "https://www.incestflix.net/watch/",
			match: /^(www.)?incestflix.(net|to|com)$/,
			selector: "#incflix-stream",
			needExtraData: true
		},
		{
			host: VideoService$1.porntn,
			url: "https://porntn.com/videos/",
			match: /^porntn.com$/,
			selector: sharedSelectors.flowplayer,
			needExtraData: true
		},
		{
			host: VideoService$1.dzen,
			url: "https://dzen.ru/video/watch/",
			match: /^dzen.ru$/,
			selector: `[class*="player__playerWrap"] > div`
		},
		{
			host: VideoService$1.bunnystream,
			url: "stub",
			match: [
				/^video\.bunnycdn\.com$/,
				/^iframe\.mediadelivery\.net$/,
				/^(?:[^.]+\.)*b-cdn\.net$/
			],
			selector: null
		},
		{
			host: VideoService$1.cloudflarestream,
			url: "stub",
			match: /^(watch|embed|iframe|customer-[^.]+).cloudflarestream.com$/,
			selector: null
		},
		{
			host: VideoService$1.loom,
			url: "https://www.loom.com/share/",
			match: /^(www.)?loom.com$/,
			selector: ".VideoLayersContainer",
			needExtraData: true,
			needBypassCSP: true
		},
		{
			host: ExtVideoService.artstation,
			url: "https://www.artstation.com/learning/",
			match: /^(www.)?artstation.com$/,
			selector: sharedSelectors.videoJsUniversal,
			needExtraData: true
		},
		{
			host: VideoService$1.rtnews,
			url: "https://www.rt.com/",
			match: /^(www.)?rt.com$/,
			selector: sharedSelectors.jwPlayer,
			needExtraData: true
		},
		{
			host: VideoService$1.noodlemagazine,
			url: "https://hot.noodlemagazine.com/",
			match: /^(hot\.)?noodlemagazine\.com$/,
			selector: sharedSelectors.jwPlayer,
			needExtraData: true
		},
		{
			host: VideoService$1.bitview,
			url: "https://www.bitview.net/watch?v=",
			match: /^(www.)?bitview.net$/,
			selector: ".vlScreen",
			needExtraData: true
		},
		{
			host: ExtVideoService.kickstarter,
			url: "https://www.kickstarter.com/",
			match: /^(www.)?kickstarter.com/,
			selector: ".ksr-video-player",
			needExtraData: true
		},
		{
			host: VideoService$1.thisvid,
			url: "https://thisvid.com/",
			match: /^(www.)?thisvid.com$/,
			selector: sharedSelectors.flowplayer
		},
		{
			additionalData: "regional",
			host: VideoService$1.ign,
			url: "https://de.ign.com/",
			match: /^(\w{2}.)?ign.com$/,
			needExtraData: true,
			selector: ".video-container"
		},
		{
			host: VideoService$1.ign,
			url: "https://www.ign.com/",
			match: /^(www.)?ign.com$/,
			selector: sharedSelectors.player,
			needExtraData: true
		},
		{
			host: VideoService$1.bunkr,
			url: "https://bunkr.site/",
			match: /^bunkr\.(site|black|cat|media|red|site|ws|org|s[kiu]|c[ir]|fi|p[hks]|ru|la|is|to|a[cx])$/,
			needExtraData: true,
			selector: ".plyr__video-wrapper"
		},
		{
			host: VideoService$1.imdb,
			url: "https://www.imdb.com/video/",
			match: /^(www\.)?imdb\.com$/,
			selector: sharedSelectors.jwPlayer
		},
		{
			host: VideoService$1.telegram,
			url: "https://t.me/",
			match: (url) => /^web\.telegram\.org$/.test(url.hostname) && url.pathname.startsWith("/k"),
			selector: ".ckin__player"
		},
		{
			host: ExtVideoService.oraclelearn,
			url: "https://mylearn.oracle.com/ou/course/",
			match: /^mylearn\.oracle\.com/,
			selector: sharedSelectors.videoJsUniversal,
			needExtraData: true,
			needBypassCSP: true
		},
		{
			host: ExtVideoService.deeplearningai,
			url: "https://learn.deeplearning.ai/courses/",
			match: /^learn(-dev|-staging)?\.deeplearning\.ai/,
			selector: ".lesson-video-player",
			needExtraData: true
		},
		{
			host: ExtVideoService.netacad,
			url: "https://www.netacad.com/",
			match: /^(www\.)?netacad\.com/,
			selector: sharedSelectors.videoJsUniversal,
			needExtraData: true
		},
		{
			host: ExtVideoService.mediafile,
			url: "https://mediafile.cc/",
			match: /^(www\.)?mediafile\.cc$/,
			selector: "div#playerContainer",
			needExtraData: true
		},
		{
			host: ExtVideoService.skilljar,
			url: "https://anthropic.skilljar.com/",
			match: /skilljar\.com$/,
			selector: sharedSelectors.jwPlayer,
			needExtraData: true
		},
		{
			host: VideoService$1.custom,
			url: "stub",
			match: (url) => /([^.]+)\.(mp4|webm)/.test(url.pathname),
			rawResult: true
		}
	];
	var config_default = {
		"host": "api.browser.yandex.ru",
		"hostVOT": "vot.toil.cc/v1",
		"hostWorker": "vot-worker.toil.cc",
		"mediaProxy": "media-proxy.transly.eu.cc",
		"userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 YaBrowser/26.6.0.0 Safari/537.36",
		"componentVersion": "26.6.0.1831",
		"hmac": "bt8xH3VOlb4mqf0nqAibnDOoiPlXsisf",
		"defaultDuration": 310,
		"minChunkSize": 5295308,
		"loggerLevel": 1,
		"version": "2.4.18"
	};
	var LoggerLevel;
	(function(LoggerLevel) {
		LoggerLevel[LoggerLevel["DEBUG"] = 0] = "DEBUG";
		LoggerLevel[LoggerLevel["INFO"] = 1] = "INFO";
		LoggerLevel[LoggerLevel["WARN"] = 2] = "WARN";
		LoggerLevel[LoggerLevel["ERROR"] = 3] = "ERROR";
		LoggerLevel[LoggerLevel["SILENCE"] = 4] = "SILENCE";
	})(LoggerLevel || (LoggerLevel = {}));
	var prefix = `[vot.js v${config_default.version}]`;
	function canLog(level) {
		return config_default.loggerLevel <= level;
	}
	function log(...messages) {
		if (!canLog(LoggerLevel.DEBUG)) return;
		console.log(prefix, ...messages);
	}
	function info(...messages) {
		if (!canLog(LoggerLevel.INFO)) return;
		console.info(prefix, ...messages);
	}
	function warn(...messages) {
		if (!canLog(LoggerLevel.WARN)) return;
		console.warn(prefix, ...messages);
	}
	function error(...messages) {
		if (!canLog(LoggerLevel.ERROR)) return;
		console.error(prefix, ...messages);
	}
	var Logger = {
		canLog,
		log,
		info,
		warn,
		error
	};
	var iso6392to6391 = {
		afr: "af",
		aka: "ak",
		alb: "sq",
		amh: "am",
		ara: "ar",
		arm: "hy",
		asm: "as",
		aym: "ay",
		aze: "az",
		baq: "eu",
		bel: "be",
		ben: "bn",
		bos: "bs",
		bul: "bg",
		bur: "my",
		cat: "ca",
		chi: "zh",
		cos: "co",
		cze: "cs",
		dan: "da",
		div: "dv",
		dut: "nl",
		eng: "en",
		epo: "eo",
		est: "et",
		ewe: "ee",
		fin: "fi",
		fre: "fr",
		fry: "fy",
		geo: "ka",
		ger: "de",
		gla: "gd",
		gle: "ga",
		glg: "gl",
		gre: "el",
		grn: "gn",
		guj: "gu",
		hat: "ht",
		hau: "ha",
		hin: "hi",
		hrv: "hr",
		hun: "hu",
		ibo: "ig",
		ice: "is",
		ind: "id",
		ita: "it",
		jav: "jv",
		jpn: "ja",
		kan: "kn",
		kaz: "kk",
		khm: "km",
		kin: "rw",
		kir: "ky",
		kor: "ko",
		kur: "ku",
		lao: "lo",
		lat: "la",
		lav: "lv",
		lin: "ln",
		lit: "lt",
		ltz: "lb",
		lug: "lg",
		mac: "mk",
		mal: "ml",
		mao: "mi",
		mar: "mr",
		may: "ms",
		mlg: "mg",
		mlt: "mt",
		mon: "mn",
		nep: "ne",
		nor: "no",
		nya: "ny",
		ori: "or",
		orm: "om",
		pan: "pa",
		per: "fa",
		pol: "pl",
		por: "pt",
		pus: "ps",
		que: "qu",
		rum: "ro",
		rus: "ru",
		san: "sa",
		sin: "si",
		slo: "sk",
		slv: "sl",
		smo: "sm",
		sna: "sn",
		snd: "sd",
		som: "so",
		sot: "st",
		spa: "es",
		srp: "sr",
		sun: "su",
		swa: "sw",
		swe: "sv",
		tam: "ta",
		tat: "tt",
		tel: "te",
		tgk: "tg",
		tha: "th",
		tir: "ti",
		tso: "ts",
		tuk: "tk",
		tur: "tr",
		uig: "ug",
		ukr: "uk",
		urd: "ur",
		uzb: "uz",
		vie: "vi",
		wel: "cy",
		xho: "xh",
		yid: "yi",
		yor: "yo",
		zul: "zu"
	};
	async function fetchWithTimeout(url, options = { headers: { "User-Agent": config_default.userAgent } }) {
		const { timeout = 3e3, signal, ...fetchOptions } = options;
		if (!signal && (!timeout || timeout <= 0)) return await fetch(url, fetchOptions);
		const controller = new AbortController();
		const abort = (reason) => {
			if (!controller.signal.aborted) controller.abort(reason);
		};
		if (signal) if (signal.aborted) abort(signal.reason);
		else signal.addEventListener("abort", () => abort(signal.reason), { once: true });
		let timeoutId;
		if (timeout && timeout > 0) timeoutId = setTimeout(() => abort(new Error("Fetch timeout")), timeout);
		try {
			return await fetch(url, {
				...fetchOptions,
				signal: controller.signal
			});
		} finally {
			if (timeoutId) clearTimeout(timeoutId);
		}
	}
	function normalizeLang(lang) {
		if (lang.length === 3) return iso6392to6391[lang];
		return lang.toLowerCase().split(/[_;-]/)[0].trim();
	}
	function proxyMedia(url, format = "mp4") {
		const generalUrl = `https://${config_default.mediaProxy}/v1/proxy/video.${format}?format=base64&force=true`;
		if (!(url instanceof URL)) return `${generalUrl}&url=${btoa(url)}`;
		return `${generalUrl}&url=${btoa(url.href)}&origin=${url.origin}&referer=${url.origin}`;
	}
	var VideoHelperError = class extends Error {
		constructor(message) {
			super(message);
			this.name = "VideoHelperError";
		}
	};
	var BaseHelper = class {
		API_ORIGIN = window.location.origin;
		fetch;
		extraInfo;
		referer;
		origin;
		service;
		video;
		language;
		constructor({ fetchFn = fetchWithTimeout, extraInfo = true, referer = document.referrer ?? `${window.location.origin}/`, origin = window.location.origin, service, video, language = "en" } = {}) {
			this.fetch = fetchFn;
			this.extraInfo = extraInfo;
			this.referer = referer;
			this.origin = /^(http(s)?):\/\//.test(String(origin)) ? origin : window.location.origin;
			this.service = service;
			this.video = video;
			this.language = language;
		}
		getVideoData(_videoId) {
			return Promise.resolve(void 0);
		}
		getVideoId(_url) {
			return Promise.resolve(void 0);
		}
		returnBaseData(videoId) {
			if (!this.service) return;
			return {
				url: this.service.url + videoId,
				videoId,
				host: this.service.host,
				duration: void 0
			};
		}
	};
	var AppleDeveloperHelper = class extends BaseHelper {
		API_ORIGIN = "https://developer.apple.com";
		async getVideoData(videoId) {
			try {
				const contentUrl = document.querySelector("meta[property='og:video']")?.content;
				if (!contentUrl) throw new VideoHelperError("Failed to find content url");
				return { url: contentUrl };
			} catch (err) {
				Logger.error(`Failed to get apple developer video data by video ID: ${videoId}`, err.message);
				return;
			}
		}
		async getVideoId(url) {
			return /videos\/play\/([^/]+)\/([\d]+)/.exec(url.pathname)?.[0];
		}
	};
	var ArchiveHelper = class extends BaseHelper {
		async getVideoId(url) {
			const videoId = /(details|embed)\/(.+)/.exec(url.pathname)?.[2];
			if (!videoId) return void 0;
			return videoId.replace(/\/$/, "") || void 0;
		}
		async getVideoData(videoId) {
			if (!videoId) return void 0;
			const downloadUrl = `https://archive.org/download/${videoId.replace(/\+/g, "%20").replace(/\.[^.]+$/, ".mp4")}`;
			return {
				url: videoId,
				video_url: downloadUrl,
				translationHelp: [{
					target: "video_file_url",
					targetUrl: downloadUrl
				}]
			};
		}
	};
	var ArtstationHelper = class extends BaseHelper {
		API_ORIGIN = "https://www.artstation.com/api/v2/learning";
		getCSRFToken() {
			return document.querySelector("meta[name=\"public-csrf-token\"]")?.content;
		}
		async getCourseInfo(courseId) {
			try {
				const csrfToken = this.getCSRFToken();
				return await (await this.fetch(`${this.API_ORIGIN}/courses/${courseId}/autoplay.json`, {
					method: "POST",
					headers: csrfToken ? { "PUBLIC-CSRF-TOKEN": csrfToken } : {}
				})).json();
			} catch (err) {
				Logger.error(`Failed to get artstation course info by courseId: ${courseId}.`, err.message);
				return false;
			}
		}
		async getVideoUrl(chapterId) {
			try {
				return (await (await this.fetch(`${this.API_ORIGIN}/quicksilver/video_url.json?chapter_id=${chapterId}`)).json()).url.replace("qsep://", "https://");
			} catch (err) {
				Logger.error(`Failed to get artstation video url by chapterId: ${chapterId}.`, err.message);
				return false;
			}
		}
		async getVideoData(videoId) {
			const [, courseId, , , chapterId] = videoId.split("/");
			const courseInfo = await this.getCourseInfo(courseId);
			if (!courseInfo) return;
			const chapter = courseInfo.chapters.find((chapter) => chapter.hash_id === chapterId);
			if (!chapter) return;
			const videoUrl = await this.getVideoUrl(chapter.id);
			if (!videoUrl) return;
			const { title, duration, subtitles: videoSubtitles } = chapter;
			return {
				url: videoUrl,
				title,
				duration,
				subtitles: videoSubtitles.filter((subtitle) => subtitle.format === "vtt").map((subtitle) => ({
					language: normalizeLang(subtitle.locale),
					source: "artstation",
					format: "vtt",
					url: subtitle.file_url
				}))
			};
		}
		async getVideoId(url) {
			return /courses\/(\w{3,5})\/([^/]+)\/chapters\/(\w{3,5})/.exec(url.pathname)?.[0];
		}
	};
	var BannedVideoHelper = class extends BaseHelper {
		API_ORIGIN = "https://api.banned.video";
		async getVideoInfo(videoId) {
			try {
				return await (await this.fetch(`${this.API_ORIGIN}/graphql`, {
					method: "POST",
					body: JSON.stringify({
						operationName: "GetVideo",
						query: `query GetVideo($id: String!) {
            getVideo(id: $id) {
              title
              description: summary
              duration: videoDuration
              videoUrl: directUrl
              isStream: live
            }
          }`,
						variables: { id: videoId }
					}),
					headers: {
						"User-Agent": "bannedVideoFrontEnd",
						"apollographql-client-name": "banned-web",
						"apollographql-client-version": "1.3",
						"content-type": "application/json"
					}
				})).json();
			} catch (err) {
				console.error(`Failed to get bannedvideo video info by videoId: ${videoId}.`, err.message);
				return false;
			}
		}
		async getVideoData(videoId) {
			const videoInfo = await this.getVideoInfo(videoId);
			if (!videoInfo) return;
			const { videoUrl, duration, isStream, description, title } = videoInfo.data.getVideo;
			return {
				url: videoUrl,
				duration,
				isStream,
				title,
				description
			};
		}
		async getVideoId(url) {
			return url.searchParams.get("id") ?? void 0;
		}
	};
	var BilibiliHelper = class extends BaseHelper {
		getVideoElement() {
			return document.querySelector("video");
		}
		getBilibiliVideoId(url) {
			const bangumiId = /\/bangumi\/play\/([^/?#]+)/.exec(url.pathname)?.[1];
			if (bangumiId) return `bangumi/play/${bangumiId}`;
			const cheeseId = /\/cheese\/play\/([^/?#]+)/.exec(url.pathname)?.[1];
			if (cheeseId) return `cheese/play/${cheeseId}`;
			const bvid = window.__INITIAL_STATE__?.bvid || window.__INITIAL_STATE__?.videoData?.bvid || url.searchParams.get("bvid") || /\/video\/(BV[^/?#]+)/.exec(url.pathname)?.[1];
			if (bvid) {
				const p = url.searchParams.get("p");
				return `video/${bvid}${p ? `/?p=${p}` : ""}`;
			}
			return /video\/[^/?#]+/.exec(url.pathname)?.[0];
		}
		getBvidAndCid(url) {
			return {
				bvid: window.__INITIAL_STATE__?.bvid || window.__INITIAL_STATE__?.videoData?.bvid || /\/video\/(BV[^/?#]+)/.exec(url.pathname)?.[1] || url.searchParams.get("bvid"),
				cid: window.__INITIAL_STATE__?.cid || window.__INITIAL_STATE__?.videoData?.cid || window.__INITIAL_STATE__?.videoData?.pages?.[0]?.cid
			};
		}
		async getCidByBvid(bvid) {
			if (!bvid) return void 0;
			try {
				return (await (await fetch(`https://api.bilibili.com/x/web-interface/view?bvid=${encodeURIComponent(bvid)}`, { credentials: "include" })).json())?.data?.pages?.[0]?.cid;
			} catch {
				return;
			}
		}
		async getVideoUrlFromApi(bvid, cid) {
			if (!bvid || !cid) return void 0;
			try {
				const json = await (await fetch(`https://api.bilibili.com/x/player/playurl?bvid=${encodeURIComponent(bvid)}&cid=${encodeURIComponent(cid)}&qn=16&type=mp4&platform=html5&high_quality=0`, { credentials: "include" })).json();
				return json?.data?.durl?.[0]?.url || json?.durl?.[0]?.url;
			} catch {
				return;
			}
		}
		async getVideoData() {
			const currentUrl = new URL(location.href);
			const video = this.getVideoElement();
			const videoId = this.getBilibiliVideoId(currentUrl);
			if (!videoId) return void 0;
			if (/^(cheese|bangumi)\/play\//.test(videoId)) return {
				url: `${currentUrl.origin}/${videoId}`,
				videoId,
				host: "bilibili",
				duration: video?.duration,
				isStream: false
			};
			const { bvid, cid: initialCid } = this.getBvidAndCid(currentUrl);
			const cid = initialCid ?? await this.getCidByBvid(bvid);
			const videoUrl = await this.getVideoUrlFromApi(bvid, cid);
			if (!videoUrl) return void 0;
			return {
				url: videoUrl,
				videoId,
				host: "bilibili",
				duration: video?.duration,
				isStream: false
			};
		}
		async getVideoId(url) {
			return this.getBilibiliVideoId(url);
		}
	};
	var BitchuteHelper = class extends BaseHelper {
		async getVideoId(url) {
			return /(video|embed)\/([^/]+)/.exec(url.pathname)?.[2];
		}
	};
	var BitviewHelper = class extends BaseHelper {
		async getVideoData(videoId) {
			try {
				const videoUrl = document.querySelector(".vlScreen > video")?.src;
				if (!videoUrl) throw new VideoHelperError("Failed to find video URL");
				return { url: videoUrl };
			} catch (err) {
				Logger.error(`Failed to get Bitview data by videoId: ${videoId}`, err.message);
				return;
			}
		}
		async getVideoId(url) {
			return url.searchParams.get("v");
		}
	};
	var PlyrHelper = class {
		SUBTITLE_SOURCE = "plyr";
		SUBTITLE_FORMAT = "vtt";
		getPlayer() {
			const customWindow = window;
			if (customWindow.player?.media) return customWindow.player;
			return document.querySelector("video, audio, .plyr video")?.plyr || void 0;
		}
		getVideoData(videoId) {
			try {
				const player = this.getPlayer();
				const videoEl = document.querySelector("video, audio, .plyr video");
				if (!player && !videoEl) throw new Error("Plyr player or media element not found");
				const duration = player?.duration ?? videoEl?.duration ?? 0;
				const fileUrl = player?.source || videoEl?.currentSrc || videoEl?.src || videoEl?.querySelector("source")?.getAttribute("src");
				if (!fileUrl) throw new Error("Failed to find video url");
				return {
					url: videoId,
					duration,
					translationHelp: [{
						target: "video_file_url",
						targetUrl: fileUrl
					}]
				};
			} catch (err) {
				console.error("[VOT] PlyrHelper error:", err instanceof Error ? err.message : String(err));
				return;
			}
		}
		getSubtitles() {
			const subtitles = [];
			try {
				const player = this.getPlayer();
				const videoEl = document.querySelector("video, audio, .plyr video");
				const rawTracks = [];
				const searchTargets = [];
				if (videoEl) searchTargets.push(videoEl);
				if (player?.elements?.container) searchTargets.push(player.elements.container);
				for (const target of searchTargets) {
					const tracks = Array.from(target.querySelectorAll("track[src]"));
					for (const track of tracks) {
						const src = track.getAttribute("src");
						if (src && track.kind !== "metadata") rawTracks.push({
							src,
							lang: track.srclang || ""
						});
					}
				}
				if (player?.config?.tracks && Array.isArray(player.config.tracks)) {
					const configTracks = player.config.tracks;
					for (const track of configTracks) if (track?.src && track.kind !== "metadata") rawTracks.push({
						src: track.src,
						lang: track.srclang || track.lang || ""
					});
				}
				const seenUrls = new Set();
				for (const { src, lang } of rawTracks) try {
					const absUrl = new URL(src, window.location.href).toString();
					if (!seenUrls.has(absUrl)) {
						seenUrls.add(absUrl);
						subtitles.push({
							source: this.SUBTITLE_SOURCE,
							format: this.SUBTITLE_FORMAT,
							language: normalizeLang(lang),
							url: absUrl
						});
					}
				} catch {}
			} catch (err) {
				console.error("[VOT] PlyrHelper getSubtitles error:", err);
			}
			return subtitles;
		}
	};
	var BunkrHelper = class extends BaseHelper {
		async getVideoData(videoId) {
			return new PlyrHelper().getVideoData(videoId);
		}
		async getVideoId(url) {
			return /\/(?:f|v)\/([^/]+)/.exec(url.pathname)?.[1];
		}
	};
	var BunnyStreamHelper = class extends BaseHelper {
		async getVideoId(url) {
			return url.pathname + url.search;
		}
	};
	var CloudflareStreamHelper = class extends BaseHelper {
		async getVideoId(url) {
			return url.pathname + url.search;
		}
	};
	var CoursehunterLikeHelper = class extends BaseHelper {
		API_ORIGIN = this.origin ?? "https://coursehunter.net";
		async getCourseId() {
			const courseId = window.course_id;
			if (courseId !== void 0) return String(courseId);
			return document.querySelector("input[name=\"course_id\"]")?.value;
		}
		async getLessonsData(courseId) {
			const lessons = window.lessons;
			if (lessons?.length) return lessons;
			try {
				return await (await this.fetch(`${this.API_ORIGIN}/api/v1/course/${courseId}/lessons`)).json();
			} catch (err) {
				Logger.error(`Failed to get CoursehunterLike lessons data by courseId: ${courseId}, because ${err.message}`);
				return;
			}
		}
		getLessondId(videoId) {
			let lessondId = videoId.split("?lesson=")?.[1];
			if (lessondId) return +lessondId;
			lessondId = document.querySelector(".lessons-item_active")?.dataset?.index;
			if (lessondId) return +lessondId;
			return 1;
		}
		async getVideoData(videoId) {
			const courseId = await this.getCourseId();
			if (!courseId) return;
			const lessonsData = await this.getLessonsData(courseId);
			if (!lessonsData) return;
			const lessonId = this.getLessondId(videoId);
			const { file: videoUrl, duration, title } = lessonsData?.[lessonId - 1];
			if (!videoUrl) return;
			return {
				url: videoId,
				video_url: videoUrl,
				translationHelp: [{
					target: "video_file_url",
					targetUrl: proxyMedia(videoUrl)
				}],
				duration,
				title
			};
		}
		async getVideoId(url) {
			return url.href;
		}
	};
	var availableLangs = [
		"auto",
		"ru",
		"en",
		"zh",
		"ko",
		"lt",
		"lv",
		"ar",
		"fr",
		"it",
		"es",
		"de",
		"ja"
	];
	var VideoJSHelper = class VideoJSHelper extends BaseHelper {
		SUBTITLE_SOURCE = "videojs";
		SUBTITLE_FORMAT = "vtt";
		static getPlayer() {
			const vjs = window.videojs;
			const techEl = document.querySelector("video.vjs-tech, video[id$='_html5_api'], video");
			const derivedPlayerId = techEl?.id?.endsWith("_html5_api") ? techEl.id.slice(0, -10) : void 0;
			if (vjs?.getPlayer) {
				if (derivedPlayerId) {
					const p = vjs.getPlayer(derivedPlayerId);
					if (p) return p;
				}
				if (techEl) {
					const p = vjs.getPlayer(techEl);
					if (p) return p;
				}
			}
			const players = (typeof vjs?.getPlayers === "function" ? vjs.getPlayers() : vjs?.players) ?? {};
			for (const p of Object.values(players)) {
				const player = p;
				const innerVideo = (typeof player.el === "function" ? player.el() : null)?.querySelector?.("video.vjs-tech, video") ?? null;
				if (innerVideo && techEl && innerVideo === techEl) return p;
				if (derivedPlayerId && typeof player.id === "function" && player.id() === derivedPlayerId) return p;
			}
		}
		getVideoDataByPlayer(videoId) {
			try {
				const player = VideoJSHelper.getPlayer();
				const techEl = document.querySelector("video.vjs-tech, video[id$='_html5_api'], video[src], video");
				if (!player && !techEl) throw new Error(`Video player/video element not found, videoId ${videoId}`);
				const duration = player?.duration?.() ?? techEl?.duration;
				let url;
				if (player) {
					const sources = typeof player.currentSources === "function" ? player.currentSources() : player.getCache?.()?.sources;
					url = (Array.isArray(sources) ? sources.find((source) => source?.type === "video/mp4" || source?.type === "video/webm" || source?.src) : void 0)?.src;
				}
				url ??= techEl?.currentSrc || techEl?.src || techEl?.querySelector("source")?.src || techEl?.getAttribute?.("src") || void 0;
				if (!url) throw new Error(`Failed to find video url for videoID ${videoId}`);
				return {
					url,
					duration,
					subtitles: this.getSubtitles()
				};
			} catch (err) {
				Logger.error("Failed to get videojs video data", err.message);
				return;
			}
		}
		getSubtitles() {
			const techEl = document.querySelector("video.vjs-tech, video[id$='_html5_api'], video[src], video");
			return (techEl ? Array.from(techEl.querySelectorAll("track[src]")) : []).filter((t) => t.kind !== "metadata").flatMap((t) => {
				const src = t.getAttribute("src");
				if (!src) return [];
				const absUrl = new URL(src, window.location.href).toString();
				return [{
					language: normalizeLang(t.srclang || ""),
					source: this.SUBTITLE_SOURCE,
					format: this.SUBTITLE_FORMAT,
					url: absUrl
				}];
			});
		}
	};
	var CourseraHelper = class CourseraHelper extends VideoJSHelper {
		API_ORIGIN = "https://www.coursera.org/api";
		SUBTITLE_SOURCE = "coursera";
		async getCourseData(courseIdOrSlug) {
			try {
				const url = typeof courseIdOrSlug === "string" && courseIdOrSlug.includes("-") ? `${this.API_ORIGIN}/onDemandCourses.v1?q=slug&slug=${courseIdOrSlug}` : `${this.API_ORIGIN}/onDemandCourses.v1/${courseIdOrSlug}`;
				return (await (await this.fetch(url)).json())?.elements?.[0];
			} catch (err) {
				Logger.error(`Failed to get course data: ${courseIdOrSlug}`, err.message);
				return;
			}
		}
		getCourseSlug() {
			return (/learn\/([^/]+)\/lecture/.exec(window.location.pathname) ?? /lecture\/([^/]+)\//.exec(window.location.pathname))?.[1];
		}
		getCourseId() {
			const player = CourseraHelper.getPlayer();
			if (player?.options_?.courseId) return player.options_.courseId;
			const courseraObj = window.coursera;
			if (typeof courseraObj?.courseId === "string") return courseraObj.courseId;
			else if (typeof courseraObj?.courseId === "function") try {
				return courseraObj.courseId();
			} catch {}
			return window.App?.context?.dispatcher?.stores?.CourseStore?.courseId;
		}
		static getPlayer() {
			return VideoJSHelper.getPlayer();
		}
		async getVideoData(videoId) {
			const data = this.getVideoDataByPlayer(videoId);
			if (!data) return;
			const options = CourseraHelper.getPlayer()?.options_;
			if (!data.subtitles?.length && options?.tracks) data.subtitles = options.tracks.map((track) => ({
				url: track.src,
				language: normalizeLang(track.srclang),
				source: this.SUBTITLE_SOURCE,
				format: this.SUBTITLE_FORMAT
			}));
			const courseIdOrSlug = options?.courseId ?? this.getCourseId() ?? this.getCourseSlug();
			let courseLang = "en";
			let courseData;
			if (courseIdOrSlug) courseData = await this.getCourseData(courseIdOrSlug);
			if (courseData?.primaryLanguageCodes?.[0]) courseLang = normalizeLang(courseData.primaryLanguageCodes[0]);
			else courseLang = normalizeLang(document.documentElement.lang || "en");
			if (!availableLangs.includes(courseLang)) courseLang = "en";
			const subtitleUrl = (data.subtitles.find((subtitle) => subtitle.language === courseLang) ?? data.subtitles?.[0])?.url;
			if (!subtitleUrl) Logger.warn("Failed to find any subtitle file");
			const { url, duration } = data;
			const translationHelp = subtitleUrl ? [{
				target: "subtitles_file_url",
				targetUrl: subtitleUrl
			}, {
				target: "video_file_url",
				targetUrl: url
			}] : null;
			return {
				url: subtitleUrl ? this.service?.url + videoId : url,
				translationHelp,
				detectedLanguage: courseLang,
				duration
			};
		}
		async getVideoId(url) {
			return (/learn\/([^/]+)\/lecture\/([^/]+)/.exec(url.pathname) ?? /lecture\/([^/]+)\/([^/]+)/.exec(url.pathname))?.[0];
		}
	};
	var DailymotionHelper = class extends BaseHelper {
		getVideoIdFromUrl(url) {
			const videoIdFromQuery = url.searchParams.get("video");
			if (videoIdFromQuery) return videoIdFromQuery;
		}
		resolveVideoIdViaPostMessage() {
			return new Promise((resolve) => {
				const origin = "https://www.dailymotion.com";
				const timeout = setTimeout(() => {
					window.removeEventListener("message", onMessage);
					resolve(void 0);
				}, 3e3);
				const onMessage = (e) => {
					if (e.origin !== origin) return;
					if (!(typeof e.data === "string" && e.data.startsWith("getVideoId:"))) return;
					clearTimeout(timeout);
					window.removeEventListener("message", onMessage);
					resolve(e.data.replace("getVideoId:", ""));
				};
				window.addEventListener("message", onMessage);
				window.top?.postMessage("getVideoId:", origin);
			});
		}
		async getVideoId(url) {
			const videoIdFromUrl = this.getVideoIdFromUrl(url);
			if (videoIdFromUrl) return videoIdFromUrl;
			if (window.self !== window.top) return await this.resolveVideoIdViaPostMessage();
			return url.hostname === "dai.ly" ? url.pathname.slice(1) : /video\/([^/]+)/.exec(url.pathname)?.[1];
		}
	};
	var DataCampHelper = class extends VideoJSHelper {
		SUBTITLE_SOURCE = "datacamp";
		getVideoUrlFromInput(input) {
			try {
				if (!(input instanceof HTMLInputElement || input instanceof HTMLTextAreaElement || input.tagName === "INPUT" || input.tagName === "TEXTAREA")) return null;
				const value = input.value;
				if (!value) return null;
				const meta = JSON.parse(value);
				const videoUrl = meta?.video_url ?? meta?.plain_video_mp4_link ?? meta?.plain_video_hls_link ?? meta?.video_mp4_link ?? meta?.video_hls_link;
				return typeof videoUrl === "string" ? videoUrl : null;
			} catch {
				return null;
			}
		}
		getVideoUrlFromDocument(doc = document) {
			const videoDataInput = doc.querySelector("#videoData");
			if (videoDataInput) {
				const url = this.getVideoUrlFromInput(videoDataInput);
				if (url) return url;
			}
			const slideDeckInput = doc.querySelector("#slideDeckData");
			if (slideDeckInput) {
				const url = this.getVideoUrlFromInput(slideDeckInput);
				if (url) return url;
			}
			return null;
		}
		async getVideoData(videoId) {
			const cleanUrl = videoId.split("||")[0];
			let videoUrl = this.getVideoUrlFromDocument(document);
			if (!videoUrl) try {
				const response = await fetch(cleanUrl);
				if (response.ok) {
					const html = await response.text();
					const doc = new DOMParser().parseFromString(html, "text/html");
					videoUrl = this.getVideoUrlFromDocument(doc);
				}
			} catch (err) {
				Logger.error("Failed to fetch DataCamp page for DOMParser", err instanceof Error ? err.message : String(err));
			}
			if (!videoUrl) return;
			return {
				url: videoId,
				video_url: videoUrl,
				translationHelp: [{
					target: "video_file_url",
					targetUrl: videoUrl
				}]
			};
		}
		async getVideoId(url) {
			return url.href;
		}
	};
	var DeeplearningAIHelper = class extends BaseHelper {
		async getVideoData(_videoId) {
			if (!this.video) return;
			const sourceUrl = this.video.querySelector("source[type=\"application/x-mpegurl\"]")?.src.replace(/\.m3u8/, "_360p.mp4");
			if (!sourceUrl) return;
			return { url: sourceUrl };
		}
		async getVideoId(url) {
			return /courses\/(([^/]+)\/lesson\/([^/]+)\/([^/]+))/.exec(url.pathname)?.[1];
		}
	};
	var DouyinHelper = class extends BaseHelper {
		constructor(...args) {
			super(...args);
			this.lastHref = "";
			this.lastVideoData = void 0;
			this.lastCacheKey = "";
			this.lastBlobUrl = "";
			this.lastAwemeId = "";
			this.currentAwemeId = "";
			this.startWatcher();
		}
		startWatcher() {
			const update = () => {
				const video = document.querySelector("video");
				const href = location.href;
				const blobUrl = video?.currentSrc || video?.src || "";
				const awemeId = this.getCurrentAwemeId() || "";
				if (href !== this.lastHref || blobUrl !== this.lastBlobUrl || awemeId !== this.currentAwemeId) {
					this.lastHref = href;
					this.lastBlobUrl = blobUrl;
					this.currentAwemeId = awemeId;
					this.lastVideoData = void 0;
					this.lastCacheKey = "";
					console.log("[VOT][douyin] current aweme", awemeId);
				}
				requestAnimationFrame(update);
			};
			update();
		}
		decodeText(value) {
			return String(value || "").replace(/\\u0026/g, "&").replace(/\\\//g, "/").replace(/&amp;/g, "&");
		}
		cleanUrl(url) {
			try {
				const u = new URL(url);
				return `${u.origin}${u.pathname}`;
			} catch {
				return String(url || "").split("?")[0];
			}
		}
		getCurrentAweme() {
			return this.getPlayer()?.config?.awemeInfo;
		}
		getCurrentAwemeId() {
			const aweme = this.getCurrentAweme();
			return aweme?.awemeId || aweme?.aweme_id || aweme?.groupId || aweme?.group_id || void 0;
		}
		getPlayer() {
			return typeof player === "undefined" ? window.player : player;
		}
		getAwemeInfo() {
			return this.getPlayer()?.config?.awemeInfo;
		}
		getAwemeId() {
			const aweme = this.getAwemeInfo();
			return aweme?.awemeId || aweme?.aweme_id || aweme?.groupId || aweme?.group_id || /[?&]modal_id=(\d{16,22})/.exec(location.href)?.[1] || void 0;
		}
		getJingxuanUrl(awemeId) {
			if (!/^\d{16,22}$/.test(String(awemeId || ""))) return;
			return `https://www.douyin.com/jingxuan?modal_id=${encodeURIComponent(awemeId)}`;
		}
		getVideoIdFromUrl(value) {
			if (!value) return void 0;
			const decoded = this.decodeText(value);
			return /[?&]video_id=(v0[a-zA-Z0-9_-]+)/.exec(decoded)?.[1] || /["']video_id["']\s*:\s*["'](v0[a-zA-Z0-9_-]+)/.exec(decoded)?.[1] || /["']videoId["']\s*:\s*["'](v0[a-zA-Z0-9_-]+)/.exec(decoded)?.[1] || /[?&]vid=(v0[a-zA-Z0-9_-]+)/.exec(decoded)?.[1] || /["']vid["']\s*:\s*["'](v0[a-zA-Z0-9_-]+)/.exec(decoded)?.[1];
		}
		getPlayerVideoId() {
			const player = this.getPlayer();
			const video = this.getAwemeInfo()?.video || {};
			const candidates = [
				video.playApiH265,
				video.playApi,
				player?.curDefinition?.url,
				player?.curDefinition?.fallback_url,
				player?.vodLogger?.apiLog?.dynamic_video
			].flat();
			for (const value of candidates) {
				const text = typeof value === "string" ? value : JSON.stringify(value || "");
				const id = this.getVideoIdFromUrl(text);
				if (/^v[a-zA-Z0-9_-]{10,}$/.test(id || "")) return id;
			}
		}
		getPlaywmUrl(videoId) {
			if (!/^v[a-zA-Z0-9_-]{10,}$/.test(String(videoId || ""))) return;
			return `https://www.douyin.com/aweme/v1/playwm/?line=0&logo_name=aweme_diversion_search&ratio=720p&video_id=${encodeURIComponent(videoId)}`;
		}
		getCurrentMediaResource() {
			const entry = performance.getEntriesByType("resource").filter((entry) => {
				const url = entry.name || "";
				return /douyinvod\.com/.test(url) && /media-video/.test(url) && !/media-audio/.test(url);
			}).sort((a, b) => b.startTime - a.startTime)[0];
			if (!entry) return void 0;
			const url = entry.name;
			return {
				url,
				videoId: this.cleanUrl(url),
				rawVideoId: this.getVideoIdFromUrl(url),
				from: "performance media-video"
			};
		}
		async waitCurrentMediaResource(timeout = 1200) {
			const started = performance.now();
			while (performance.now() - started < timeout) {
				const media = this.getCurrentMediaResource();
				if (media?.url) return media;
				await new Promise((resolve) => setTimeout(resolve, 80));
			}
		}
		async fetchRedirectUrl(url, timeout = 1500) {
			return new Promise((resolve) => {
				if (typeof GM_xmlhttpRequest === "undefined") {
					resolve(void 0);
					return;
				}
				GM_xmlhttpRequest({
					method: "GET",
					url,
					anonymous: false,
					timeout,
					headers: {
						Referer: "https://www.douyin.com/",
						Range: "bytes=0-1"
					},
					onload: (res) => resolve(res.finalUrl || res.responseURL || void 0),
					onerror: () => resolve(void 0),
					ontimeout: () => resolve(void 0)
				});
			});
		}
		getFileIdFromUrl(value) {
			if (!value) return void 0;
			const decoded = this.decodeText(value);
			return /[?&]file_id=([^&"'\\\s]+)/.exec(decoded)?.[1] || /["']file_id["']\s*:\s*["']([^"']+)/.exec(decoded)?.[1];
		}
		getPlayerFileId() {
			const video = this.getAwemeInfo()?.video || {};
			const candidates = [
				video.playApiH265,
				video.playApi,
				this.getPlayer()?.vodLogger?.apiLog?.dynamic_video,
				this.getPlayer()?.curDefinition?.url,
				this.getPlayer()?.curDefinition?.fallback_url
			].flat();
			for (const value of candidates) {
				const text = typeof value === "string" ? value : this.safeStringify(value || "");
				const fileId = this.getFileIdFromUrl(text);
				if (fileId && /^[a-zA-Z0-9_-]{16,256}$/.test(fileId)) return fileId;
			}
		}
		safeStringify(value) {
			const seen = new WeakSet();
			try {
				return JSON.stringify(value, (key, val) => {
					if (typeof val === "object" && val !== null) {
						if (seen.has(val)) return "[Circular]";
						seen.add(val);
					}
					return val;
				});
			} catch {
				return String(value || "");
			}
		}
		getVideoIdFromText(value) {
			if (!value) return void 0;
			const decoded = this.decodeText(value);
			return /[?&]video_id=(v[a-zA-Z0-9_-]{10,})/.exec(decoded)?.[1] || /["']video_id["']\s*:\s*["'](v[a-zA-Z0-9_-]{10,})/.exec(decoded)?.[1] || /["']videoId["']\s*:\s*["'](v[a-zA-Z0-9_-]{10,})/.exec(decoded)?.[1] || /[?&]vid=(v[a-zA-Z0-9_-]{10,})/.exec(decoded)?.[1] || /["']vid["']\s*:\s*["'](v[a-zA-Z0-9_-]{10,})/.exec(decoded)?.[1];
		}
		getVideoIdFromUrl(value) {
			return this.getVideoIdFromText(value);
		}
		async fetchText(url, timeout = 5e3) {
			return new Promise((resolve) => {
				if (typeof GM_xmlhttpRequest === "undefined") {
					resolve(void 0);
					return;
				}
				GM_xmlhttpRequest({
					method: "GET",
					url,
					anonymous: false,
					timeout,
					headers: { Referer: "https://www.douyin.com/" },
					onload: (res) => resolve(res.responseText || ""),
					onerror: () => resolve(void 0),
					ontimeout: () => resolve(void 0)
				});
			});
		}
		async getVideoIdFromJingxuan(awemeId) {
			const url = this.getJingxuanUrl(awemeId);
			if (!url) return void 0;
			const html = await this.fetchText(url, 5e3);
			if (!html) return void 0;
			return this.getVideoIdFromText(html);
		}
		async getResolvedVideoId(timeout = 3500) {
			const started = performance.now();
			while (performance.now() - started < timeout) {
				const videoId = this.getPlayerVideoId();
				if (videoId) return videoId;
				await new Promise((resolve) => setTimeout(resolve, 100));
			}
			const awemeId = this.getCurrentAwemeId();
			if (awemeId) return await this.getVideoIdFromJingxuan(awemeId);
		}
		async waitPlayerVideoId(timeout = 2500) {
			const started = performance.now();
			while (performance.now() - started < timeout) {
				const videoId = this.getPlayerVideoId();
				if (videoId) return videoId;
				await new Promise((resolve) => setTimeout(resolve, 100));
			}
		}
		getAwemeId() {
			return this.currentAwemeId;
		}
		getBoundVideoElement() {
			return this.video || this.videoElement || this.media || this.target || this.container?.querySelector?.("video") || void 0;
		}
		getActiveVideoElement() {
			return [...document.querySelectorAll("video")].map((video) => {
				const rect = video.getBoundingClientRect();
				return {
					video,
					paused: video.paused,
					readyState: video.readyState,
					visible: rect.width > 100 && rect.height > 100 && rect.bottom > 0 && rect.top < window.innerHeight,
					centerDistance: Math.abs(rect.top + rect.height / 2 - window.innerHeight / 2)
				};
			}).filter((x) => x.visible).sort((a, b) => {
				if (a.paused !== b.paused) return a.paused ? 1 : -1;
				if (a.readyState !== b.readyState) return b.readyState - a.readyState;
				return a.centerDistance - b.centerDistance;
			})[0]?.video;
		}
		isCurrentHandlerVideoActive() {
			const bound = this.getBoundVideoElement();
			const active = this.getActiveVideoElement();
			if (!bound || !active) return true;
			return bound === active;
		}
		async getVideoData() {
			if (!this.isCurrentHandlerVideoActive()) return void 0;
			const requestAwemeId = this.getCurrentAwemeId();
			if (!requestAwemeId) return void 0;
			const player = this.getPlayer();
			const video = this.getActiveVideoElement();
			const lang = player?.config?.lang;
			const videoId = await this.getResolvedVideoId(3500);
			if (!this.isCurrentHandlerVideoActive() || requestAwemeId !== this.getCurrentAwemeId()) return;
			const playwmUrl = this.getPlaywmUrl(videoId);
			if (!playwmUrl) return void 0;
			const finalUrl = await this.fetchRedirectUrl(playwmUrl, 4e3);
			if (!this.isCurrentHandlerVideoActive() || requestAwemeId !== this.getCurrentAwemeId()) return;
			if (!finalUrl || finalUrl.includes("douyin.com/aweme/v1/playwm")) return;
			const title = player?.config?.title || player?.config?.desc || document.title;
			player?.config?.awemeInfo?.video?.playApi;
			this.lastVideoData = {
				url: this.cleanUrl(finalUrl),
				videoId: `douyin/${requestAwemeId}`,
				host: "douyin",
				title,
				duration: player?.config?.duration ?? video?.duration,
				isStream: player?.config?.isLive ?? false,
				...availableLangs.includes(lang) ? { detectedLanguage: lang } : {}
			};
			return this.lastVideoData;
		}
		async getVideoId() {
			if (!this.isCurrentHandlerVideoActive()) return;
			const awemeId = this.getCurrentAwemeId();
			return awemeId ? `douyin/${awemeId}` : void 0;
		}
	};
	var DzenHelper = class extends BaseHelper {
		async getVideoId(url) {
			return /video\/watch\/([^/]+)/.exec(url.pathname)?.[1];
		}
	};
	var EggheadHelper = class extends BaseHelper {
		async getVideoId(url) {
			return url.pathname.slice(1);
		}
	};
	var EpicGamesHelper = class extends BaseHelper {
		API_ORIGIN = "https://dev.epicgames.com/community/api/learning";
		async getPostInfo(videoId) {
			try {
				return await (await this.fetch(`${this.API_ORIGIN}/post.json?hash_id=${videoId}`)).json();
			} catch (err) {
				Logger.error(`Failed to get epicgames post info by videoId: ${videoId}.`, err.message);
				return false;
			}
		}
		getVideoBlock() {
			const videoUrlRe = /videoUrl\s?=\s"([^"]+)"?/;
			const script = Array.from(document.body.querySelectorAll("script")).find((s) => videoUrlRe.exec(s.innerHTML));
			if (!script) return;
			const content = script.innerHTML.trim();
			const playlistUrl = videoUrlRe.exec(content)?.[1]?.replace("qsep://", "https://");
			if (!playlistUrl) return;
			let subtitlesString = /sources\s?=\s(\[([^\]]+)\])?/.exec(content)?.[1];
			if (!subtitlesString) return {
				playlistUrl,
				subtitles: []
			};
			try {
				subtitlesString = `${subtitlesString.replace(/src:(\s)+?(videoUrl)/g, "src:\"removed\"").substring(0, subtitlesString.lastIndexOf("},"))}]`.split("\n").map((line) => line.replace(/([^\s]+):\s?(?!.*\1)/, "\"$1\":")).join("\n");
				return {
					playlistUrl,
					subtitles: JSON.parse(subtitlesString).filter((sub) => sub.type === "captions")
				};
			} catch {
				return {
					playlistUrl,
					subtitles: []
				};
			}
		}
		async getVideoData(videoId) {
			const courseId = videoId.split(":")?.[1];
			const postInfo = await this.getPostInfo(courseId);
			if (!postInfo) return;
			const videoBlock = this.getVideoBlock();
			if (!videoBlock) return;
			const { playlistUrl, subtitles: videoSubtitles } = videoBlock;
			const { title, description } = postInfo;
			return {
				url: playlistUrl,
				title,
				description,
				subtitles: videoSubtitles.map((caption) => ({
					language: normalizeLang(caption.srclang),
					source: "epicgames",
					format: "vtt",
					url: caption.src
				}))
			};
		}
		async getVideoId(_url) {
			return new Promise((resolve) => {
				const origin = "https://dev.epicgames.com";
				const reqId = btoa(window.location.href);
				window.addEventListener("message", (e) => {
					if (e.origin !== origin) return;
					if (!(typeof e.data === "string" && e.data.startsWith("getVideoId:"))) return;
					return resolve(e.data.replace("getVideoId:", ""));
				});
				window.top?.postMessage(`getVideoId:${reqId}`, origin);
			});
		}
	};
	var EpornerHelper = class extends BaseHelper {
		async getVideoId(url) {
			return /video-([^/]+)\/([^/]+)/.exec(url.pathname)?.[0];
		}
	};
	var FacebookHelper = class extends BaseHelper {
		async getVideoId(url) {
			return url.pathname.slice(1);
		}
	};
	var GoogleDriveHelper = class extends BaseHelper {
		getPlayerData() {
			return document.querySelector("#movie_player")?.getVideoData?.() ?? void 0;
		}
		async getVideoId(_url) {
			return this.getPlayerData()?.video_id;
		}
	};
	var IgnHelper = class extends BaseHelper {
		getVideoDataBySource(videoId) {
			const url = document.querySelector(".icms.video > source[type=\"video/mp4\"][data-quality=\"360\"]")?.src;
			if (!url) return this.returnBaseData(videoId);
			return { url: proxyMedia(url) };
		}
		getVideoDataByNext(videoId) {
			try {
				const nextContent = document.getElementById("__NEXT_DATA__")?.textContent;
				if (!nextContent) throw new VideoDataError("Not found __NEXT_DATA__ content");
				const { props: { pageProps: { page: { description, title, video: { videoMetadata: { duration }, assets } } } } } = JSON.parse(nextContent);
				const videoUrl = assets.find((asset) => asset.height === 360 && asset.url.includes(".mp4"))?.url;
				if (!videoUrl) throw new VideoDataError("Not found video URL in assets");
				return {
					url: proxyMedia(videoUrl),
					duration,
					title,
					description
				};
			} catch (err) {
				Logger.warn(`Failed to get ign video data by video ID: ${videoId}, because ${err.message}. Using clear link instead...`);
				return this.returnBaseData(videoId);
			}
		}
		async getVideoData(videoId) {
			if (document.getElementById("__NEXT_DATA__")) return this.getVideoDataByNext(videoId);
			return this.getVideoDataBySource(videoId);
		}
		async getVideoId(url) {
			return /([^/]+)\/([\d]+)\/video\/([^/]+)/.exec(url.pathname)?.[0] ?? /\/videos\/([^/]+)/.exec(url.pathname)?.[0];
		}
	};
	var IMDbHelper = class extends BaseHelper {
		async getVideoId(url) {
			return /video\/([^/]+)/.exec(url.pathname)?.[1];
		}
	};
	var IncestflixHelper = class extends BaseHelper {
		async getVideoData(videoId) {
			try {
				const sourceEl = document.querySelector("#incflix-stream source:first-of-type");
				if (!sourceEl) throw new VideoHelperError("Failed to find source element");
				const srcLink = sourceEl.getAttribute("src");
				if (!srcLink) throw new VideoHelperError("Failed to find source link");
				const source = new URL(srcLink.startsWith("//") ? `https:${srcLink}` : srcLink);
				source.searchParams.append("media-proxy", "video.mp4");
				return { url: proxyMedia(source) };
			} catch (err) {
				Logger.error(`Failed to get Incestflix data by videoId: ${videoId}`, err.message);
				return;
			}
		}
		async getVideoId(url) {
			return /\/watch\/([^/]+)/.exec(url.pathname)?.[1];
		}
	};
	var JoveHelper = class extends BaseHelper {
		async getVideoId(url) {
			const match = /^\/(?:[a-z]{2}\/)?v\/(\d+)\/([^/?#]+)/i.exec(url.pathname);
			return match ? `v/${match[1]}/${match[2]}` : void 0;
		}
		async getVideoData(videoId) {
			if (!videoId) return void 0;
			let nextData;
			if (typeof window !== "undefined" && typeof document !== "undefined") {
				const nextDataEl = document.getElementById("__NEXT_DATA__");
				if (nextDataEl?.textContent) try {
					nextData = JSON.parse(nextDataEl.textContent);
				} catch (err) {
					throw new VideoHelperError(`Failed to parse DOM __NEXT_DATA__: ${err.message}`);
				}
			}
			const queries = nextData?.props?.pageProps?.dehydratedState?.queries || [];
			let extracted;
			for (const q of queries) {
				const data = q.state?.data;
				if (!data) continue;
				for (const target of [data.domain, data]) {
					const videoObj = target?.videos?.en;
					if (videoObj?.cdnFile) {
						extracted = {
							videoUrl: videoObj.cdnFile,
							duration: videoObj.lengthSeconds ? parseInt(videoObj.lengthSeconds, 10) : void 0,
							title: target.title,
							description: target.titleDescription,
							subtitles: videoObj.subtitles
						};
						break;
					}
				}
				if (extracted) break;
			}
			if (!extracted?.videoUrl) throw new VideoHelperError(`Failed to retrieve video URL for ${videoId}`);
			const { videoUrl, duration, title, description, subtitles: subtitlesObj } = extracted;
			const subtitles = subtitlesObj ? Object.entries(subtitlesObj).filter(([, url]) => typeof url === "string").map(([lang, url]) => ({
				language: normalizeLang(lang),
				source: "jove",
				format: "vtt",
				url,
				isAutoGenerated: false
			})) : [];
			return {
				url: `https://www.jove.com/${videoId}`,
				video_url: videoUrl,
				title,
				description,
				duration,
				subtitles,
				translationHelp: [{
					target: "video_file_url",
					targetUrl: videoUrl
				}]
			};
		}
	};
	var KickHelper = class extends BaseHelper {
		API_ORIGIN = "https://kick.com/api";
		async getClipInfo(clipId) {
			try {
				const { clip_url: url, duration, title } = (await (await this.fetch(`${this.API_ORIGIN}/v2/clips/${clipId}`)).json()).clip;
				return {
					url,
					duration,
					title
				};
			} catch (err) {
				Logger.error(`Failed to get kick clip info by clipId: ${clipId}.`, err.message);
				return;
			}
		}
		async getVideoInfo(videoId) {
			try {
				const { source: url, livestream } = await (await this.fetch(`${this.API_ORIGIN}/v1/video/${videoId}`)).json();
				const { session_title: title, duration } = livestream;
				return {
					url,
					duration: Math.round(duration / 1e3),
					title
				};
			} catch (err) {
				Logger.error(`Failed to get kick video info by videoId: ${videoId}.`, err.message);
				return;
			}
		}
		async getVideoData(videoId) {
			return videoId.startsWith("videos") ? await this.getVideoInfo(videoId.replace("videos/", "")) : await this.getClipInfo(videoId.replace("clips/", ""));
		}
		async getVideoId(url) {
			return /([^/]+)\/((videos|clips)\/([^/]+))/.exec(url.pathname)?.[2];
		}
	};
	var KickstarterHelper = class extends BaseHelper {
		async getVideoData(videoId) {
			try {
				const videoEl = document.querySelector(".ksr-video-player > video");
				const url = videoEl?.querySelector("source[type^='video/mp4']")?.src;
				if (!url) throw new VideoHelperError("Failed to find video URL");
				const subtitles = videoEl?.querySelectorAll("track") ?? [];
				return {
					url,
					subtitles: Array.from(subtitles).reduce((result, sub) => {
						const lang = sub.getAttribute("srclang");
						const url = sub.getAttribute("src");
						if (!lang || !url) return result;
						result.push({
							language: normalizeLang(lang),
							url,
							format: "vtt",
							source: "kickstarter"
						});
						return result;
					}, [])
				};
			} catch (err) {
				Logger.error(`Failed to get Kickstarter data by videoId: ${videoId}`, err.message);
				return;
			}
		}
		async getVideoId(url) {
			return url.pathname.slice(1);
		}
	};
	var yandexBrowserComponentVersion = "26.8.1.1024";
	var yandexBrowserMajorMinorVersion = "26.8";
	var chromiumUserAgentVersion = "150.0.0.0";
	var chromiumFullVersion = "150.0.7871.1024";
	function normalizeUserAgent(rawUserAgent, browserVersion) {
		return String(rawUserAgent || "").replace(/Chrome\/[\d.]+/i, `Chrome/${chromiumUserAgentVersion}`).replace(/YaBrowser\/[\d.]+/i, `YaBrowser/${browserVersion}`);
	}
	var normalizedBrowserUserAgent = normalizeUserAgent(String(config_default.userAgent || ""), yandexBrowserComponentVersion);
	var config = {
		...config_default,
		componentVersion: yandexBrowserComponentVersion,
		userAgent: normalizedBrowserUserAgent
	};
	var KodikHelper = class extends BaseHelper {
		API_ORIGIN = window.location.origin;
		getSecureData(videoPath) {
			try {
				const [videoType, videoId, hash] = videoPath.split("/").filter((a) => a);
				const allScripts = Array.from(document.getElementsByTagName("script"));
				const secureScript = allScripts.filter((s) => s.innerHTML.includes(`videoId = "${videoId}"`) || s.innerHTML.includes(`serialId = Number(${videoId})`));
				if (!secureScript.length) throw new VideoHelperError("Failed to find secure script");
				const secureScriptContent = secureScript[0]?.textContent?.trim();
				if (!secureScriptContent) throw new VideoHelperError("Secure script content is empty");
				const secureContent = /'{[^']+}'/.exec(secureScriptContent)?.[0];
				if (!secureContent) throw new VideoHelperError("Secure json wasn't found in secure script");
				const secureJSON = JSON.parse(secureContent.replaceAll("'", ""));
				if (videoType !== "serial") return {
					videoType,
					videoId,
					hash,
					...secureJSON
				};
				const videoInfoContent = allScripts.find((s) => s.innerHTML.includes(`var videoInfo = {}`))?.textContent?.trim();
				if (!videoInfoContent) throw new VideoHelperError("Failed to find videoInfo content");
				const realVideoType = /videoInfo\.type\s+?=\s+?'([^']+)'/.exec(videoInfoContent)?.[1];
				const realVideoId = /videoInfo\.id\s+?=\s+?'([^']+)'/.exec(videoInfoContent)?.[1];
				const realHash = /videoInfo\.hash\s+?=\s+?'([^']+)'/.exec(videoInfoContent)?.[1];
				if (!realVideoType || !realVideoId || !realHash) throw new VideoHelperError("Failed to parse videoInfo content");
				return {
					videoType: realVideoType,
					videoId: realVideoId,
					hash: realHash,
					...secureJSON
				};
			} catch (err) {
				Logger.error(`Failed to get kodik secure data by videoPath: ${videoPath}.`, err.message);
				return false;
			}
		}
		async getFtor(secureData) {
			const { videoType, videoId: id, hash, d, d_sign, pd, pd_sign, ref, ref_sign } = secureData;
			try {
				return await (await this.fetch(`${this.API_ORIGIN}/ftor`, {
					method: "POST",
					headers: {
						"User-Agent": config.userAgent,
						Origin: this.API_ORIGIN,
						Referer: `${this.API_ORIGIN}/${videoType}/${id}/${hash}/360p`
					},
					body: new URLSearchParams({
						d,
						d_sign,
						pd,
						pd_sign,
						ref: decodeURIComponent(ref),
						ref_sign,
						bad_user: "false",
						cdn_is_working: "true",
						info: "{}",
						type: videoType,
						hash,
						id
					})
				})).json();
			} catch (err) {
				Logger.error(`Failed to get kodik video data (type: ${videoType}, id: ${id}, hash: ${hash})`, err.message);
				return false;
			}
		}
		decryptUrl(encryptedUrl) {
			return `${atob(encryptedUrl.replace(/[a-zA-Z]/g, (e) => {
				const charCode = e.charCodeAt(0) + 18;
				const pos = e <= "Z" ? 90 : 122;
				return String.fromCharCode(pos >= charCode ? charCode : charCode - 26);
			}))}`;
		}
		async getVideoData(videoId) {
			const secureData = this.getSecureData(videoId);
			if (!secureData) return;
			const videoData = await this.getFtor(secureData);
			if (!videoData) return;
			const videoLink = Object.entries(videoData.links[videoData.default.toString()]).find(([, data]) => data.type === "application/x-mpegURL")?.[1];
			if (!videoLink) return;
			let videoUrl = videoLink.src.startsWith("//") ? videoLink.src : this.decryptUrl(videoLink.src);
			if (videoUrl.startsWith("//")) videoUrl = `https:${videoUrl}`;
			return {
				url: videoId,
				video_url: videoUrl,
				translationHelp: [{
					target: "video_file_url",
					targetUrl: proxyMedia(new URL(videoUrl))
				}]
			};
		}
		async getVideoId(url) {
			return /\/(uv|video|seria|episode|season|serial)\/([^/]+)\/([^/]+)\/([\d]+)p/.exec(url.pathname)?.[0];
		}
	};
	var LinkedinHelper = class extends VideoJSHelper {
		SUBTITLE_SOURCE = "linkedin";
		async getVideoData(videoId) {
			const data = this.getVideoDataByPlayer(videoId);
			if (!data) return;
			const { url, duration, subtitles } = data;
			return {
				url: proxyMedia(new URL(url)),
				duration,
				subtitles
			};
		}
		async getVideoId(url) {
			return /\/learning\/(([^/]+)\/([^/]+))/.exec(url.pathname)?.[1];
		}
	};
	var StreamInterval;
	(function(StreamInterval) {
		StreamInterval[StreamInterval["NO_CONNECTION"] = 0] = "NO_CONNECTION";
		StreamInterval[StreamInterval["TRANSLATING"] = 10] = "TRANSLATING";
		StreamInterval[StreamInterval["STREAMING"] = 20] = "STREAMING";
		StreamInterval[StreamInterval["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
	})(StreamInterval || (StreamInterval = {}));
	var TypeName;
	(function(TypeName) {
		TypeName["Channel"] = "Channel";
		TypeName["Video"] = "Video";
	})(TypeName || (TypeName = {}));
	var LoomHelper = class extends BaseHelper {
		getClientVersion() {
			if (typeof SENTRY_RELEASE === "undefined") return;
			return SENTRY_RELEASE.id;
		}
		async getVideoData(videoId) {
			try {
				const clientVer = this.getClientVersion();
				if (!clientVer) throw new VideoHelperError("Failed to get client version");
				const res = await this.fetch("https://www.loom.com/graphql", {
					headers: {
						"User-Agent": config_default.userAgent,
						"content-type": "application/json",
						"x-loom-request-source": `loom_web_${clientVer}`,
						"apollographql-client-name": "web",
						"apollographql-client-version": clientVer,
						"Alt-Used": "www.loom.com"
					},
					body: `{"operationName":"FetchCaptions","variables":{"videoId":"${videoId}"},"query":"query FetchCaptions($videoId: ID!, $password: String) {\\n  fetchVideoTranscript(videoId: $videoId, password: $password) {\\n    ... on VideoTranscriptDetails {\\n      id\\n      captions_source_url\\n      language\\n      __typename\\n    }\\n    ... on GenericError {\\n      message\\n      __typename\\n    }\\n    __typename\\n  }\\n}"}`,
					method: "POST"
				});
				if (res.status !== 200) throw new VideoHelperError("Failed to get data from graphql");
				const data = (await res.json()).data.fetchVideoTranscript;
				if (data.__typename === "GenericError") throw new VideoHelperError(data.message);
				return {
					url: this.service?.url + videoId,
					subtitles: [{
						format: "vtt",
						language: normalizeLang(data.language),
						source: "loom",
						url: data.captions_source_url
					}]
				};
			} catch (err) {
				Logger.error(`Failed to get Loom video data, because: ${err.message}`);
				return this.returnBaseData(videoId);
			}
		}
		async getVideoId(url) {
			return /(embed|share)\/([^/]+)?/.exec(url.pathname)?.[2];
		}
	};
	var MailRuHelper = class extends BaseHelper {
		API_ORIGIN = "https://my.mail.ru";
		async getVideoMeta(videoId) {
			try {
				return await (await this.fetch(`${this.API_ORIGIN}/+/video/meta/${videoId}?xemail=&ajax_call=1&func_name=&mna=&mnb=&ext=1&_=${Date.now()}`)).json();
			} catch (err) {
				Logger.error("Failed to get mail.ru video data", err.message);
				return;
			}
		}
		async getVideoId(url) {
			const pathname = url.pathname;
			if (/\/(v|mail|bk|inbox)\//.exec(pathname)) return pathname.slice(1);
			const videoId = /video\/embed\/([^/]+)/.exec(pathname)?.[1];
			if (!videoId) return;
			const videoData = await this.getVideoMeta(videoId);
			if (!videoData) return;
			return videoData.meta.url.replace("//my.mail.ru/", "");
		}
	};
	var MediafileHelper = class extends BaseHelper {
		DEFAULT_SITE_ORIGIN = "https://mediafile.cc";
		SITE_ORIGIN = this.service?.url?.slice(0, -1) ?? this.DEFAULT_SITE_ORIGIN;
		getVideoSrc() {
			const video = this.video instanceof HTMLVideoElement ? this.video : document.querySelector("video");
			return video?.src || video?.currentSrc || video?.querySelector("source[src]")?.src || void 0;
		}
		async getVideoData(videoId) {
			const videoSource = this.getVideoSrc();
			if (!videoSource) return;
			return {
				url: `${this.SITE_ORIGIN}/${videoId}`,
				video_url: videoSource,
				translationHelp: [{
					target: "video_file_url",
					targetUrl: videoSource
				}]
			};
		}
		async getVideoId(url) {
			return url.pathname.replace(/^\/+/, "") || void 0;
		}
	};
	var NetacadHelper = class extends VideoJSHelper {
		SUBTITLE_SOURCE = "netacad";
		async getVideoData(videoId) {
			const data = this.getVideoDataByPlayer(videoId);
			if (!data) return;
			const { url, duration, subtitles } = data;
			return {
				url: proxyMedia(new URL(url)),
				duration,
				subtitles
			};
		}
		async getVideoId(url) {
			return url.pathname + url.search;
		}
	};
	var NewgroundsHelper = class extends BaseHelper {
		async getVideoId(url) {
			return /([^/]+)\/(view)\/([^/]+)/.exec(url.pathname)?.[0];
		}
	};
	var NicoNicoHelper = class extends BaseHelper {
		async getVideoId(url) {
			if (url.hostname === "nico.ms") return url.pathname.replace(/^\//, "").split("/")[0] || void 0;
			return /\/watch\/([^/?#]+)/.exec(url.pathname)?.[1];
		}
	};
	var NineGAGHelper = class extends BaseHelper {
		async getVideoData(videoId) {
			const data = this.returnBaseData(videoId);
			if (!data) return data;
			try {
				if (!this.video) throw new Error("Video element not found");
				const videoUrl = this.video.querySelector("source[type^=\"video/mp4\"], source[type^=\"video/webm\"]")?.src;
				if (!videoUrl || !/^https?:\/\//.test(videoUrl)) throw new Error("Video source not found");
				return {
					...data,
					translationHelp: [{
						target: "video_file_url",
						targetUrl: videoUrl
					}]
				};
			} catch {
				return data;
			}
		}
		async getVideoId(url) {
			return /gag\/([^/]+)/.exec(url.pathname)?.[1];
		}
	};
	var JWPlayerHelper = class {
		SUBTITLE_SOURCE = "jwplayer";
		SUBTITLE_FORMAT = "vtt";
		getPlayer() {
			if (typeof jwplayer === "undefined") return;
			const playerEl = document.querySelector(".jwplayer");
			if (playerEl?.id) try {
				const player = jwplayer(playerEl.id);
				if (player && typeof player.getPlaylistItem === "function") return player;
			} catch (_e) {}
			try {
				return jwplayer();
			} catch (_e) {
				return;
			}
		}
		getVideoData(videoId) {
			try {
				const player = this.getPlayer();
				if (!player) throw new Error("JW Player instance not ready or not found");
				let item = player.getPlaylistItem ? player.getPlaylistItem() : null;
				if (!item && typeof player.getPlaylist === "function") {
					const playlist = player.getPlaylist();
					const index = typeof player.getPlaylistIndex === "function" ? player.getPlaylistIndex() : 0;
					if (Array.isArray(playlist) && playlist[index]) item = playlist[index];
				}
				if (!item) throw new Error("No playlist item found");
				let duration = 0;
				if (typeof player.getDuration === "function") duration = player.getDuration();
				if ((typeof duration !== "number" || duration <= 0) && typeof item.duration === "number") duration = item.duration;
				const sources = [];
				if (Array.isArray(item.allSources)) sources.push(...item.allSources);
				if (Array.isArray(item.sources)) {
					for (const s of item.sources) if (s?.file && !sources.some((existing) => existing.file === s.file)) sources.push(s);
				}
				const validSources = sources.filter((s) => s && typeof s.file === "string" && s.file.length > 0);
				if (validSources.length === 0) if (typeof item.file === "string" && item.file.length > 0) validSources.push({
					file: item.file,
					type: "",
					label: "default"
				});
				else throw new Error("No valid sources found");
				const getHeight = (s) => {
					if (typeof s.height === "number" && s.height > 0) return s.height;
					if (s.label) {
						const match = s.label.match(/^(\d+)/);
						if (match) return parseInt(match[1], 10);
					}
					return 0;
				};
				validSources.sort((a, b) => {
					const heightA = getHeight(a);
					const heightB = getHeight(b);
					if (heightA === 0 && heightB > 0) return 1;
					if (heightB === 0 && heightA > 0) return -1;
					return heightA - heightB;
				});
				const lowestQuality = validSources[0];
				return {
					url: videoId,
					duration,
					translationHelp: [{
						target: "video_file_url",
						targetUrl: lowestQuality.file
					}],
					subtitles: this.getSubtitles()
				};
			} catch (err) {
				console.error("[VOT] JWPlayerHelper error:", err instanceof Error ? err.message : String(err));
				return;
			}
		}
		getSubtitles() {
			const subtitles = [];
			try {
				const player = this.getPlayer();
				if (!player) return subtitles;
				let item = player.getPlaylistItem ? player.getPlaylistItem() : null;
				if (!item && typeof player.getPlaylist === "function") {
					const playlist = player.getPlaylist();
					const index = typeof player.getPlaylistIndex === "function" ? player.getPlaylistIndex() : 0;
					if (Array.isArray(playlist) && playlist[index]) item = playlist[index];
				}
				const tracks = item?.tracks ?? [];
				const captionsList = typeof player.getCaptionsList === "function" ? player.getCaptionsList() : [];
				const seenUrls = new Set();
				const addSubtitle = (label, file) => {
					if (!file) return;
					try {
						const absoluteUrl = new URL(file, window.location.href).toString();
						if (!seenUrls.has(absoluteUrl)) {
							seenUrls.add(absoluteUrl);
							subtitles.push({
								source: this.SUBTITLE_SOURCE,
								format: this.SUBTITLE_FORMAT,
								language: normalizeLang(label || "en"),
								url: absoluteUrl
							});
						}
					} catch (_e) {}
				};
				if (Array.isArray(tracks)) {
					for (const track of tracks) if (track && (track.kind === "captions" || track.kind === "subtitles") && track.file) addSubtitle(track.label || "en", track.file);
				}
				if (Array.isArray(captionsList)) {
					for (const track of captionsList) if (track && typeof track === "object" && track.file) addSubtitle(track.label || "en", track.file);
				}
			} catch (err) {
				console.error("[VOT] JWPlayerHelper getSubtitles error:", err);
			}
			return subtitles;
		}
	};
	var NoodleMagazineHelper = class extends BaseHelper {
		async getVideoId(url) {
			return url.pathname.slice(1);
		}
		async getVideoData(videoId) {
			return new JWPlayerHelper().getVideoData(videoId);
		}
	};
	var OdyseeHelper = class extends BaseHelper {
		API_ORIGIN = "https://odysee.com";
		async getVideoData(videoId) {
			return { url: `${this.API_ORIGIN}/${videoId}`.replace(/:[a-zA-Z0-9]+$/, "") };
		}
		async getVideoId(url) {
			return url.pathname.slice(1);
		}
	};
	var OKRuHelper = class extends BaseHelper {
		constructor(...args) {
			super(...args);
			this.AUDIO_HOST_RE = /^vd\d*\.okcdn\.ru$/i;
			this.AUDIO_TYPE = "1";
			this.AUDIO_CT = "22";
			this.AUDIO_WAIT_TIMEOUT_MS = 15e3;
			this.lastHref = "";
			this.lastBlobUrl = "";
			this.lastMediaId = "";
			this.lastVideoData = void 0;
			this.lastAudioUrl = "";
			this.startWatcher();
		}
		startWatcher() {
			const update = () => {
				const video = this.getActiveVideoElement();
				const player = this.getActivePlayer();
				const href = location.href;
				const blobUrl = video?.currentSrc || video?.src || "";
				const rawStub = player?.getAttribute("stub-thumb-url") || "";
				const mediaId = this.getActiveMediaId() || "";
				if (href !== this.lastHref || blobUrl !== this.lastBlobUrl || mediaId !== this.lastMediaId) {
					this.lastHref = href;
					this.lastBlobUrl = blobUrl;
					this.lastMediaId = mediaId;
					this.lastVideoData = void 0;
					this.lastAudioUrl = "";
					console.log("[VOT][okru] current media", {
						videoId: this.getPageVideoId(),
						mediaId,
						blobUrl,
						hasPlayer: !!player,
						stubThumbUrl: rawStub
					});
				}
				requestAnimationFrame(update);
			};
			update();
		}
		getPageVideoId() {
			return /\/(?:video|videoembed)\/(\d+)/.exec(location.pathname)?.[1];
		}
		getBoundVideoElement() {
			return this.video || this.videoElement || this.media || this.target || this.container?.querySelector?.("video") || void 0;
		}
		getActiveVideoElement() {
			return [...document.querySelectorAll("video")].map((video) => {
				const rect = video.getBoundingClientRect();
				return {
					video,
					paused: video.paused,
					readyState: video.readyState,
					visible: rect.width > 100 && rect.height > 100 && rect.bottom > 0 && rect.top < window.innerHeight,
					centerDistance: Math.abs(rect.top + rect.height / 2 - window.innerHeight / 2)
				};
			}).filter((x) => x.visible).sort((a, b) => {
				if (a.paused !== b.paused) return a.paused ? 1 : -1;
				if (a.readyState !== b.readyState) return b.readyState - a.readyState;
				return a.centerDistance - b.centerDistance;
			})[0]?.video;
		}
		isCurrentHandlerVideoActive() {
			const bound = this.getBoundVideoElement();
			const active = this.getActiveVideoElement();
			if (!bound || !active) return true;
			return bound === active;
		}
		getActivePlayer() {
			const players = [...document.querySelectorAll("vk-video-player[stub-thumb-url]")];
			return players.map((player) => {
				const rect = player.getBoundingClientRect();
				return {
					player,
					visible: rect.width > 0 && rect.height > 0 && rect.bottom > 0 && rect.top < window.innerHeight,
					centerDistance: Math.abs(rect.top + rect.height / 2 - window.innerHeight / 2)
				};
			}).filter((x) => x.visible).sort((a, b) => a.centerDistance - b.centerDistance)[0]?.player || players[0];
		}
		getActiveMediaId() {
			const player = this.getActivePlayer();
			if (!player) {
				console.log("[VOT][OKRuHelper] no vk-video-player found");
				return;
			}
			const raw = player.getAttribute("stub-thumb-url") || "";
			console.log("[VOT][OKRuHelper] stub-thumb-url", raw);
			if (!raw) return void 0;
			try {
				const id = new URL(raw, location.href).searchParams.get("id");
				if (id) {
					console.log("[VOT][OKRuHelper] mediaId from URLSearchParams", id);
					return id;
				}
			} catch {}
			try {
				const decoded = decodeURIComponent(raw);
				const match = /[?&]id=(\d+)/i.exec(decoded) || /[?&]id%3D(\d+)/i.exec(decoded);
				if (match?.[1]) {
					console.log("[VOT][OKRuHelper] mediaId from decoded URL", match[1]);
					return match[1];
				}
			} catch {}
			const match = /(?:[?&]|&amp;)id=(\d+)/i.exec(raw) || /\bid[=:](\d+)/i.exec(raw);
			if (match?.[1]) {
				console.log("[VOT][OKRuHelper] mediaId from raw URL", match[1]);
				return match[1];
			}
			console.log("[VOT][OKRuHelper] mediaId NOT FOUND in stub-thumb-url", raw);
		}
		isDirectAudioUrl(rawUrl, mediaId) {
			if (!rawUrl) return false;
			try {
				const url = new URL(rawUrl, location.href);
				if (!this.AUDIO_HOST_RE.test(url.hostname)) return false;
				if (url.searchParams.get("type") !== this.AUDIO_TYPE) return false;
				if (url.searchParams.get("ct") !== this.AUDIO_CT) return false;
				const candidateId = url.searchParams.get("id");
				if (!candidateId) return false;
				if (mediaId && candidateId !== mediaId) return false;
				return true;
			} catch {
				return false;
			}
		}
		normalizeDirectAudioUrl(rawUrl) {
			const url = new URL(rawUrl, location.href);
			url.searchParams.delete("bytes");
			return url.toString();
		}
		findDirectAudioUrl(mediaId) {
			const entries = performance.getEntriesByType("resource");
			for (let i = entries.length - 1; i >= 0; i -= 1) {
				const rawUrl = entries[i]?.name;
				if (!this.isDirectAudioUrl(rawUrl, mediaId)) continue;
				return this.normalizeDirectAudioUrl(rawUrl);
			}
		}
		async waitForDirectAudioUrl(mediaId, timeoutMs = this.AUDIO_WAIT_TIMEOUT_MS) {
			const existing = this.findDirectAudioUrl(mediaId);
			if (existing) return existing;
			if (typeof PerformanceObserver !== "function") return void 0;
			return await new Promise((resolve) => {
				let observer;
				const finish = (value) => {
					clearTimeout(timer);
					observer?.disconnect();
					resolve(value);
				};
				const timer = setTimeout(() => finish(void 0), timeoutMs);
				observer = new PerformanceObserver((list) => {
					for (const entry of list.getEntries()) {
						if (!this.isDirectAudioUrl(entry.name, mediaId)) continue;
						finish(this.normalizeDirectAudioUrl(entry.name));
						return;
					}
				});
				try {
					observer.observe({
						type: "resource",
						buffered: true
					});
				} catch {
					observer?.disconnect();
					clearTimeout(timer);
					resolve(void 0);
				}
			});
		}
		async getVideoData() {
			if (!this.isCurrentHandlerVideoActive()) return void 0;
			const requestVideoId = this.getPageVideoId();
			if (!requestVideoId) return void 0;
			const requestMediaId = this.getActiveMediaId();
			console.log("[VOT][OKRuHelper] resolving videoData", {
				videoId: requestVideoId,
				mediaId: requestMediaId
			});
			const audioUrl = await this.waitForDirectAudioUrl(requestMediaId);
			if (!this.isCurrentHandlerVideoActive()) return void 0;
			if (requestVideoId !== this.getPageVideoId()) return void 0;
			const currentMediaId = this.getActiveMediaId();
			if (requestMediaId && currentMediaId && requestMediaId !== currentMediaId) return void 0;
			if (!audioUrl) throw new Error("OK.ru direct audio URL was not detected (expected vd*.okcdn.ru type=1 ct=22)");
			const video = this.getActiveVideoElement();
			this.lastAudioUrl = audioUrl;
			this.lastVideoData = {
				url: audioUrl,
				videoId: requestVideoId,
				host: "okru",
				duration: Number.isFinite(video?.duration) && video.duration > 0 ? video.duration : void 0,
				isStream: false
			};
			console.log("[VOT][OKRuHelper] videoData", this.lastVideoData);
			return this.lastVideoData;
		}
		async getVideoId() {
			if (!this.isCurrentHandlerVideoActive()) return void 0;
			return this.getPageVideoId();
		}
	};
	var OlympicsReplayHelper = class extends BaseHelper {
		async getVideoId(url) {
			return /\/([a-z]{2}\/(?:[a-z0-9-]+\/)?(?:replay|videos?|original-series\/episode)\/[\w-]+)\/?$/i.exec(url.pathname)?.[1];
		}
	};
	var OracleLearnHelper = class extends VideoJSHelper {
		SUBTITLE_SOURCE = "oraclelearn";
		async getVideoData(videoId) {
			const data = this.getVideoDataByPlayer(videoId);
			if (!data) return;
			const { url, duration, subtitles } = data;
			const baseData = this.returnBaseData(videoId);
			const videoUrl = proxyMedia(new URL(url));
			if (!baseData) return {
				url: videoUrl,
				duration,
				subtitles
			};
			return {
				url: baseData.url,
				duration,
				subtitles,
				translationHelp: [{
					target: "video_file_url",
					targetUrl: videoUrl
				}]
			};
		}
		async getVideoId(url) {
			return /\/ou\/course\/(([^/]+)\/(\d+)\/(\d+))/.exec(url.pathname)?.[1];
		}
	};
	var PatreonHelper = class extends BaseHelper {
		API_ORIGIN = "https://www.patreon.com/api";
		async getPosts(postId) {
			try {
				return await (await this.fetch(`${this.API_ORIGIN}/posts/${postId}?json-api-use-default-includes=false`)).json();
			} catch (err) {
				Logger.error(`Failed to get patreon posts by postId: ${postId}.`, err.message);
				return false;
			}
		}
		async getVideoData(postId) {
			const postData = await this.getPosts(postId);
			if (!postData) return;
			const postFileUrl = postData.data.attributes.post_file.url;
			if (!postFileUrl) return;
			return { url: postFileUrl };
		}
		async getVideoId(url) {
			const fullPostId = /posts\/([^/]+)/.exec(url.pathname)?.[1];
			if (!fullPostId) return;
			return fullPostId.replace(/[^\d.]/g, "");
		}
	};
	var PeertubeHelper = class extends BaseHelper {
		async getVideoId(url) {
			const normalizedPathname = url.pathname.replace(/\/+$/, "");
			const watchVideoId = /\/videos\/watch\/([^/]+)/.exec(normalizedPathname)?.[1];
			if (watchVideoId) return `/videos/watch/${watchVideoId}`;
			const shortVideoId = /\/w\/([^/]+)/.exec(normalizedPathname)?.[1];
			if (shortVideoId) return `/videos/watch/${shortVideoId}`;
		}
	};
	var PicartoHelper = class extends BaseHelper {
		async getVideoId(url) {
			return /\/((?:videopopout|[^/]+(?:\/profile)?\/videos)\/[^/?#&/]+)\/?$/.exec(url.pathname)?.[1] ?? /^\/([^/#?]+)\/?$/.exec(url.pathname)?.[1];
		}
	};
	var PornhubHelper = class extends BaseHelper {
		async getVideoId(url) {
			return url.searchParams.get("viewkey") ?? /embed\/([^/]+)/.exec(url.pathname)?.[1];
		}
	};
	var PornTNHelper = class extends BaseHelper {
		async getVideoData(videoId) {
			try {
				if (typeof flashvars === "undefined") return;
				const { rnd, video_url: source, video_title: title } = flashvars;
				if (!source || !rnd) throw new VideoHelperError("Failed to find video source or rnd");
				const getFileUrl = new URL(source);
				getFileUrl.searchParams.append("rnd", rnd);
				Logger.log("PornTN get_file link", getFileUrl.href);
				const cdnResponse = await this.fetch(getFileUrl.href, { method: "head" });
				const cdnUrl = new URL(cdnResponse.url);
				Logger.log("PornTN cdn link", cdnUrl.href);
				return {
					url: proxyMedia(cdnUrl),
					title
				};
			} catch (err) {
				Logger.error(`Failed to get PornTN data by videoId: ${videoId}`, err.message);
				return;
			}
		}
		async getVideoId(url) {
			return /\/videos\/(([^/]+)\/([^/]+))/.exec(url.pathname)?.[1];
		}
	};
	var PreserveTubeHelper = class extends BaseHelper {
		async getVideoData(videoId) {
			try {
				if (!videoId) throw new VideoHelperError("Failed to find PreserveTube video ID");
				return { url: `https://s3.archive.party/preservetube/${videoId}.mp4` };
			} catch (err) {
				Logger.error(`Failed to get PreserveTube data by videoId: ${videoId}`, err.message);
				return;
			}
		}
		async getVideoId(url) {
			return url.searchParams.get("v") ?? void 0;
		}
	};
	var RedditHelper = class extends BaseHelper {
		API_ORIGIN = "https://www.reddit.com";
		async getDashAudioUrl(dashUrl) {
			const res = await fetch(dashUrl);
			if (!res.ok) return void 0;
			const xml = await res.text();
			const doc = new DOMParser().parseFromString(xml, "application/xml");
			const audioBaseUrl = doc.querySelector("AdaptationSet[contentType=\"audio\"] BaseURL")?.textContent ?? doc.querySelector("Representation[id=\"AUDIO-1\"] BaseURL")?.textContent;
			if (!audioBaseUrl) return void 0;
			const base = new URL(dashUrl);
			return new URL(audioBaseUrl, base).href;
		}
		async getVideoData(videoId) {
			try {
				const res = await fetch(`${this.API_ORIGIN}/r/${videoId}.json`, { headers: { Accept: "application/json" } });
				if (!res.ok) throw new VideoHelperError(`Reddit API error: ${res.status}`);
				const post = (await res.json())?.[0]?.data?.children?.[0]?.data;
				const redditVideo = post?.secure_media?.reddit_video ?? post?.media?.reddit_video ?? post?.crosspost_parent_list?.[0]?.secure_media?.reddit_video ?? post?.crosspost_parent_list?.[0]?.media?.reddit_video;
				if (!redditVideo) throw new VideoHelperError("No reddit_video found in post");
				const dashUrl = redditVideo.dash_url?.replaceAll("&amp;", "&");
				if (!dashUrl) throw new VideoHelperError("No dash_url in reddit_video");
				const audioUrl = await this.getDashAudioUrl(dashUrl);
				if (!audioUrl) throw new VideoHelperError("Failed to extract audio URL from DASH MPD");
				return { url: audioUrl };
			} catch (err) {
				Logger.error(`Failed to get reddit video data by video ID: ${videoId}`, err.message);
				return;
			}
		}
		async getVideoId(url) {
			return /\/r\/(([^/]+)\/([^/]+)\/([^/]+)\/([^/]+))/.exec(url.pathname)?.[1];
		}
	};
	var RtNewsHelper = class extends BaseHelper {
		async getVideoData(videoId) {
			const videoEl = document.querySelector(".jw-video, .media__video_noscript");
			if (!videoEl) return;
			let videoSrc = videoEl.getAttribute("src");
			if (!videoSrc) return;
			if (videoSrc.endsWith(".MP4")) videoSrc = proxyMedia(videoSrc);
			return {
				videoId,
				url: videoSrc
			};
		}
		async getVideoId(url) {
			return url.pathname.slice(1);
		}
	};
	var Rule34VideoHelper = class extends BaseHelper {
		async getVideoId(url) {
			const parts = /\/videos?\/(\d+)(?:\/(.+))?\/?$/.exec(url.pathname);
			if (!parts) return;
			const [, id, tail] = parts;
			return tail ? `${id}/${tail.replace(/\/+$/, "")}/` : id;
		}
	};
	var RumbleHelper = class extends BaseHelper {
		async getVideoId(url) {
			return url.pathname.slice(1);
		}
	};
	var RutubeHelper = class extends BaseHelper {
		async getVideoId(url) {
			return /(?:video|embed)\/([^/]+)/.exec(url.pathname)?.[1];
		}
	};
	var SapHelper = class extends BaseHelper {
		API_ORIGIN = "https://learning.sap.com/";
		async requestKaltura(kalturaDomain, partnerId, entryId) {
			const clientTag = "html5:v3.17.22";
			const apiVersion = "3.3.0";
			try {
				return await (await this.fetch(`https://${kalturaDomain}/api_v3/service/multirequest`, {
					method: "POST",
					body: JSON.stringify({
						"1": {
							service: "session",
							action: "startWidgetSession",
							widgetId: `_${partnerId}`
						},
						"2": {
							service: "baseEntry",
							action: "list",
							ks: "{1:result:ks}",
							filter: { redirectFromEntryId: entryId },
							responseProfile: {
								type: 1,
								fields: "id,referenceId,name,description,dataUrl,duration,flavorParamsIds,type,dvrStatus,externalSourceType,createdAt,updatedAt,endDate,plays,views,downloadUrl,creatorId"
							}
						},
						"3": {
							service: "baseEntry",
							action: "getPlaybackContext",
							entryId: "{2:result:objects:0:id}",
							ks: "{1:result:ks}",
							contextDataParams: {
								objectType: "KalturaContextDataParams",
								flavorTags: "all"
							}
						},
						apiVersion,
						format: 1,
						ks: "",
						clientTag,
						partnerId
					}),
					headers: { "Content-Type": "application/json" }
				})).json();
			} catch (err) {
				Logger.error("Failed to request kaltura data", err.message);
				return;
			}
		}
		async getKalturaData(videoId) {
			const url = `${this.API_ORIGIN}${videoId}`;
			try {
				const content = await (await this.fetch(url)).text();
				const nextDataEl = new DOMParser().parseFromString(content, "text/html").getElementById("__NEXT_DATA__");
				if (!nextDataEl?.textContent) throw new VideoHelperError(`Failed to find __NEXT_DATA__ for ${videoId}`);
				const video = JSON.parse(nextDataEl.textContent)?.props?.pageProps?.embeddedVideos?.[0];
				if (!video) throw new VideoHelperError(`Failed to find embeddedVideos in JSON for ${videoId}`);
				const contentUrl = video.contentUrl || "";
				const match = /https:\/\/([^/]+)\/p\/(\d+)\//i.exec(contentUrl);
				if (!match) throw new VideoHelperError(`Failed to extract Kaltura domain and partnerId for ${videoId}`);
				const [, kalturaDomain, partnerId] = match;
				const entryId = video.videoId;
				return await this.requestKaltura(kalturaDomain, partnerId, entryId);
			} catch (err) {
				Logger.error("Failed to get kaltura data", err.message);
				return;
			}
		}
		async getVideoData(videoId) {
			const kalturaData = await this.getKalturaData(videoId);
			if (!kalturaData) return;
			const [, baseEntryList, playbackContext] = kalturaData;
			const { duration } = baseEntryList.objects[0];
			const videoUrl = playbackContext.sources.find((source) => source.format === "url" && source.protocols === "http,https" && source.url.includes(".mp4"))?.url;
			if (!videoUrl) return;
			return {
				url: videoUrl,
				subtitles: playbackContext.playbackCaptions?.map((caption) => {
					return {
						language: normalizeLang(caption.languageCode),
						source: "sap",
						format: "vtt",
						url: caption.webVttUrl,
						isAutoGenerated: caption.label.includes("auto-generated")
					};
				}) ?? [],
				duration
			};
		}
		async getVideoId(url) {
			return /((courses|learning-journeys)\/([^/]+)(\/[^/]+)?)/.exec(url.pathname)?.[1];
		}
	};
	var SkilljarHelper = class extends BaseHelper {
		async getVideoId(url) {
			return url.pathname.slice(1);
		}
		async getVideoData(videoId) {
			return new JWPlayerHelper().getVideoData(videoId);
		}
	};
	var SpankBangHelper = class extends BaseHelper {
		async getVideoId(url) {
			return /\/([\da-z]+\/(?:video|play|embed)(?:\/[^/]+)?)\/?$/i.exec(url.pathname)?.[1] ?? /\/([\da-z]+-[\da-z]+\/playlist\/[^/]+)\/?$/i.exec(url.pathname)?.[1];
		}
	};
	var TelegramHelper = class TelegramHelper extends BaseHelper {
		static getMediaViewer() {
			if (typeof appMediaViewer === "undefined") return;
			return appMediaViewer;
		}
		async getVideoId(_url) {
			const mediaViewer = TelegramHelper.getMediaViewer();
			if (!mediaViewer) return;
			if (mediaViewer.live) return;
			const message = mediaViewer.target.message;
			if (message.peer_id._ !== "peerChannel") return;
			const media = message.media;
			if (media._ !== "messageMediaDocument") return;
			if (media.document.type !== "video") return;
			const postId = message.mid & 4294967295;
			return `${await mediaViewer.managers.appPeersManager.getPeerUsername(message.peerId)}/${postId}`;
		}
	};
	var ThisVidHelper = class extends BaseHelper {
		async getVideoId(url) {
			return /(videos|embed)\/[^/]+/.exec(url.pathname)?.[0];
		}
	};
	var TikTokHelper = class extends BaseHelper {
		async getVideoId(url) {
			return /([^/]+)\/video\/([^/]+)/.exec(url.pathname)?.[0];
		}
	};
	var TrovoHelper = class extends BaseHelper {
		async getVideoId(url) {
			const vid = url.searchParams.get("vid");
			const path = /([^/]+)\/([\d]+)/.exec(url.pathname)?.[0];
			if (!vid || !path) return;
			return `${path}?vid=${vid}`;
		}
	};
	var TwitchHelper = class extends BaseHelper {
		API_ORIGIN = "https://clips.twitch.tv";
		async getClipLink(pathname, clipId) {
			const schema = document.querySelector("script[type='application/ld+json']");
			const clearPathname = pathname.slice(1);
			if (schema) {
				const channelLink = JSON.parse(schema.innerText)["@graph"].find((obj) => obj["@type"] === "VideoObject")?.creator.url;
				if (!channelLink) throw new VideoHelperError("Failed to find channel link");
				return `${channelLink.replace("https://www.twitch.tv/", "")}/clip/${clearPathname}`;
			}
			const isEmbed = clearPathname === "embed";
			const channelLink = document.querySelector(isEmbed ? ".tw-link[data-test-selector='stream-info-card-component__stream-avatar-link']" : ".clips-player a:not([class])");
			if (!channelLink) return;
			return `${channelLink.href.replace("https://www.twitch.tv/", "")}/clip/${isEmbed ? clipId : clearPathname}`;
		}
		async getVideoData(videoId) {
			const title = document.querySelector("[data-a-target=\"stream-title\"], [data-test-selector=\"stream-info-card-component__subtitle\"]")?.innerText;
			const isStream = !!document.querySelector("[data-a-target=\"animated-channel-viewers-count\"], .channel-status-info--live, .top-bar--pointer-enabled .tw-channel-status-text-indicator");
			return {
				url: this.service?.url + videoId,
				isStream,
				title
			};
		}
		async getVideoId(url) {
			const pathname = url.pathname;
			if (/^m\.twitch\.tv$/.test(pathname)) return /videos\/([^/]+)/.exec(url.href)?.[0] ?? pathname.slice(1);
			else if (/^player\.twitch\.tv$/.test(url.hostname)) return `videos/${url.searchParams.get("video")}`;
			const clipPath = /([^/]+)\/(?:clip)\/([^/]+)/.exec(pathname);
			if (clipPath) return clipPath[0];
			if (/^clips\.twitch\.tv$/.test(url.hostname)) return await this.getClipLink(pathname, url.searchParams.get("clip"));
			const videoPath = /(?:videos)\/([^/]+)/.exec(pathname);
			if (videoPath) return videoPath[0];
			const isUserOfflinePage = document.querySelector(".home-offline-hero .tw-link");
			if (isUserOfflinePage?.href) {
				const pageUrl = new URL(isUserOfflinePage.href);
				return /(?:videos)\/([^/]+)/.exec(pageUrl.pathname)?.[0];
			}
			return document.querySelector(".persistent-player") ? pathname : void 0;
		}
	};
	var TwitterHelper = class extends BaseHelper {
		async getVideoId(url) {
			const videoId = /status\/([^/]+)/.exec(url.pathname)?.[1];
			if (videoId) return videoId;
			const newLink = (this.video?.closest("[data-testid=\"tweet\"]"))?.querySelector("a[role=\"link\"][aria-label]")?.href;
			return newLink ? /status\/([^/]+)/.exec(newLink)?.[1] : void 0;
		}
	};
	function isObject(value) {
		return typeof value === "object" && value !== null;
	}
	function isUrlCandidate(value) {
		return typeof value === "object" && value !== null;
	}
	function getUrlCandidates(data) {
		if (Array.isArray(data)) return data.filter(isUrlCandidate);
		if (typeof data !== "object" || data === null) return [];
		const source = data;
		return (Array.isArray(source.Video) ? source.Video : Array.isArray(source.video) ? source.video : []).filter(isUrlCandidate);
	}
	function getOutputCandidates(data) {
		if (!isObject(data)) return [];
		const result = [];
		for (const [fallbackLabel, value] of Object.entries(data)) {
			if (!isObject(value) || typeof value.url !== "string") continue;
			result.push({
				src: value.url,
				type: typeof value.type === "string" ? value.type : void 0,
				label: typeof value.height === "number" || typeof value.height === "string" ? value.height : fallbackLabel
			});
		}
		return result;
	}
	function getQualityValue(value) {
		if (typeof value === "number" && Number.isFinite(value)) return value;
		const match = String(value ?? "").match(/(\d{3,4})/);
		return Number(match?.[1] ?? 0);
	}
	function getCandidateUrl(candidate) {
		if (typeof candidate.file === "string") return candidate.file;
		if (typeof candidate.src === "string") return candidate.src;
	}
	function isM3U8(type, url) {
		return type.includes("mpegurl") || /\.m3u8(?:$|[?#])/i.test(url);
	}
	function isDash(type, url) {
		return type.includes("dash") || /\.mpd(?:$|[?#])/i.test(url);
	}
	var UdemyHelper = class extends BaseHelper {
		API_ORIGIN = `${window.location.origin}/api-2.0`;
		getModuleData() {
			const moduleData = (document.querySelector(".ud-app-loader[data-module-id='course-taking']") ?? document.querySelector("[data-module-id='course-taking']"))?.dataset?.moduleArgs;
			if (!moduleData) return;
			try {
				return JSON.parse(moduleData);
			} catch {
				return;
			}
		}
		getLectureId(videoId) {
			const lectureIdRe = /(?:\/learn\/(?:v4\/t\/)?lecture\/|#\/?lecture\/)(\d+)/i;
			const lectureViewIdRe = /\/lecture\/view\/\?/i;
			const href = window.location.href;
			const lectureViewSearchParams = lectureViewIdRe.test(href) ? new URL(href).searchParams : void 0;
			const lectureViewId = lectureViewSearchParams ? (() => {
				for (const [key, value] of lectureViewSearchParams) {
					const normalizedKey = key.toLowerCase();
					if (normalizedKey === "lectureid" || normalizedKey === "lecture_id") return value;
				}
			})() : void 0;
			return lectureIdRe.exec(href)?.[1] ?? lectureViewId ?? (videoId ? lectureIdRe.exec(`/${videoId}`)?.[1] : void 0);
		}
		getCourseId(moduleData) {
			const moduleDataWithExtra = moduleData;
			const moduleCourseId = this.normalizeId(moduleDataWithExtra?.courseId ?? moduleDataWithExtra?.course_id ?? moduleDataWithExtra?.course?.id);
			if (moduleCourseId) return moduleCourseId;
			const attrCourseId = this.normalizeId(document.querySelector("[data-course-id]")?.getAttribute("data-course-id"));
			if (attrCourseId) return attrCourseId;
			const pageHtml = document.documentElement?.innerHTML ?? "";
			return /data-course-id=["'](\d+)/i.exec(pageHtml)?.[1] ?? /&quot;courseId&quot;\s*:\s*(\d+)/i.exec(pageHtml)?.[1] ?? /"courseId"\s*:\s*(\d+)/i.exec(pageHtml)?.[1];
		}
		normalizeId(value) {
			if (typeof value === "number" && Number.isFinite(value)) return String(value);
			if (typeof value === "string") return /^\d+$/.test(value) ? value : void 0;
		}
		parseJson(value) {
			try {
				return JSON.parse(value);
			} catch {
				const normalized = value.replaceAll("&quot;", "\"").replaceAll("&#34;", "\"").replaceAll("&apos;", "'").replaceAll("&#39;", "'");
				try {
					return JSON.parse(normalized);
				} catch {
					return;
				}
			}
		}
		getViewHtmlCandidates(viewHtml) {
			if (typeof viewHtml !== "string" || !viewHtml.trim()) return [];
			const doc = new DOMParser().parseFromString(viewHtml, "text/html");
			const candidates = [];
			for (const sourceEl of Array.from(doc.querySelectorAll("source"))) {
				const src = sourceEl.getAttribute("src");
				if (!src) continue;
				candidates.push({
					src,
					type: sourceEl.getAttribute("type") ?? void 0,
					label: sourceEl.getAttribute("data-res") ?? void 0
				});
			}
			for (const setupDataEl of Array.from(doc.querySelectorAll("[videojs-setup-data]"))) {
				const setupDataRaw = setupDataEl.getAttribute("videojs-setup-data");
				if (!setupDataRaw) continue;
				const setupData = this.parseJson(setupDataRaw);
				if (setupData) candidates.push(...getUrlCandidates(setupData.sources));
			}
			return candidates;
		}
		isErrorData(data) {
			return Object.hasOwn(data, "error") || Object.hasOwn(data, "detail") && !Object.hasOwn(data, "_class");
		}
		async getLectureData(courseId, lectureId) {
			try {
				const data = await (await this.fetch(`${this.API_ORIGIN}/users/me/subscribed-courses/${courseId}/lectures/${lectureId}/?` + new URLSearchParams({
					"fields[lecture]": "title,description,view_html,asset,download_url,is_free,last_watched_second",
					"fields[asset]": "asset_type,length,stream_url,media_sources,stream_urls,download_urls,external_url,captions,data,thumbnail_sprite,slides,slide_urls,course_is_drmed,media_license_token"
				}).toString())).json();
				if (this.isErrorData(data)) throw new VideoHelperError(data.detail ?? "unknown error");
				return data;
			} catch (err) {
				Logger.error(`Failed to get lecture data by courseId: ${courseId} and lectureId: ${lectureId}`, err.message);
				return;
			}
		}
		async getCourseLang(courseId) {
			try {
				const data = await (await this.fetch(`${this.API_ORIGIN}/users/me/subscribed-courses/${courseId}?` + new URLSearchParams({ "fields[course]": "locale" }).toString())).json();
				if (!this.isErrorData(data)) return data;
				const data2 = await (await this.fetch(`${this.API_ORIGIN}/courses/${courseId}/?` + new URLSearchParams({ "fields[course]": "locale" }).toString())).json();
				if (this.isErrorData(data2)) throw new VideoHelperError(data2.detail ?? "unknown error");
				return data2;
			} catch (err) {
				Logger.error(`Failed to get course lang by courseId: ${courseId}`, err.message);
				return;
			}
		}
		findVideoUrl(sources, streamUrls, downloadUrls, streamUrl, externalUrl, outputs, viewHtml) {
			const allCandidates = [];
			const mediaSources = Array.isArray(sources) ? sources : [];
			for (const source of mediaSources) allCandidates.push({
				src: source.src,
				type: source.type,
				label: source.label
			});
			allCandidates.push(...getUrlCandidates(streamUrls));
			allCandidates.push(...getUrlCandidates(downloadUrls));
			allCandidates.push(...getOutputCandidates(outputs));
			if (typeof viewHtml === "string") allCandidates.push(...this.getViewHtmlCandidates(viewHtml));
			if (typeof streamUrl === "string") allCandidates.push({ src: streamUrl });
			if (typeof externalUrl === "string") allCandidates.push({ src: externalUrl });
			const playerSrc = this.video?.currentSrc || this.video?.src;
			if (typeof playerSrc === "string" && playerSrc) allCandidates.push({ src: playerSrc });
			const dedupCandidates = new Map();
			for (const candidate of allCandidates) {
				const url = getCandidateUrl(candidate);
				if (!url || /^javascript:/i.test(url)) continue;
				const quality = getQualityValue(candidate.label ?? candidate.quality ?? candidate.height);
				const type = String(candidate.type ?? "").toLowerCase();
				const prev = dedupCandidates.get(url);
				if (!prev || quality > prev.quality) dedupCandidates.set(url, {
					url,
					type,
					quality,
					isYouTubeWatch: /:\/\/(?:www\.)?youtube\.com\/watch\?/i.test(url)
				});
			}
			const candidates = Array.from(dedupCandidates.values());
			if (!candidates.length) return;
			const mp4Candidates = candidates.filter((item) => item.type.includes("mp4") || /\.mp4(?:$|[?#])/i.test(item.url));
			if (mp4Candidates.length) {
				mp4Candidates.sort((a, b) => b.quality - a.quality);
				return mp4Candidates[0]?.url;
			}
			const hlsUrl = candidates.find((item) => isM3U8(item.type, item.url))?.url;
			if (hlsUrl) return hlsUrl;
			const dashUrl = candidates.find((item) => isDash(item.type, item.url))?.url;
			if (dashUrl) return dashUrl;
			const nonYoutube = candidates.find((item) => !item.isYouTubeWatch)?.url;
			if (nonYoutube) return nonYoutube;
			return candidates[0]?.url;
		}
		getCaptionLocale(caption) {
			const localeId = typeof caption.locale_id === "string" ? caption.locale_id : typeof caption.locale?.locale === "string" ? caption.locale.locale : void 0;
			return localeId ? normalizeLang(localeId) : void 0;
		}
		findSubtitleUrl(captions, detectedLanguage) {
			if (!Array.isArray(captions)) return;
			const captionsWithDownload = captions.filter((caption) => isObject(caption) && (typeof caption.url === "string" || typeof caption.download_url === "string"));
			const subtitle = captionsWithDownload.find((caption) => this.getCaptionLocale(caption) === detectedLanguage) ?? captionsWithDownload.find((caption) => this.getCaptionLocale(caption) === "en") ?? captionsWithDownload[0];
			return subtitle?.url ?? subtitle?.download_url;
		}
		async getVideoData(videoId) {
			const moduleData = this.getModuleData();
			const courseId = this.getCourseId(moduleData);
			const lectureId = this.getLectureId(videoId);
			Logger.log(`[Udemy] courseId: ${courseId}, lectureId: ${lectureId}`);
			if (!lectureId || !courseId) return;
			const lectureData = await this.getLectureData(courseId, lectureId);
			if (!lectureData) return;
			const { title, description, asset, view_html } = lectureData;
			const { length: duration, media_sources, captions } = asset;
			const assetWithExtraUrls = asset;
			const streamUrls = assetWithExtraUrls.stream_urls;
			const downloadUrls = assetWithExtraUrls.download_urls;
			const videoUrl = this.findVideoUrl(media_sources, streamUrls, downloadUrls, assetWithExtraUrls.stream_url ?? assetWithExtraUrls.streamUrl, assetWithExtraUrls.external_url, assetWithExtraUrls.data?.outputs, view_html);
			if (!videoUrl) {
				Logger.log("Failed to find video file in asset sources", asset);
				return;
			}
			let courseLang = "en";
			const courseLocale = (await this.getCourseLang(courseId))?.locale?.locale;
			if (typeof courseLocale === "string") courseLang = normalizeLang(courseLocale);
			if (!availableLangs.includes(courseLang)) courseLang = "en";
			const subtitleUrl = this.findSubtitleUrl(captions, courseLang);
			if (!subtitleUrl) Logger.log("Failed to find subtitle file in captions", captions);
			return {
				...subtitleUrl ? {
					url: this.service?.url + videoId,
					translationHelp: [{
						target: "subtitles_file_url",
						targetUrl: subtitleUrl
					}, {
						target: "video_file_url",
						targetUrl: videoUrl
					}],
					detectedLanguage: courseLang
				} : {
					url: videoUrl,
					translationHelp: null
				},
				duration,
				title,
				description
			};
		}
		async getVideoId(url) {
			return url.pathname.slice(1);
		}
	};
	var VimeoHelper = class extends BaseHelper {
		API_KEY = "";
		DEFAULT_SITE_ORIGIN = "https://vimeo.com";
		SITE_ORIGIN = this.service?.url?.slice(0, -1) ?? this.DEFAULT_SITE_ORIGIN;
		isErrorData(data) {
			return Object.hasOwn(data, "error");
		}
		isPrivatePlayer() {
			return this.referer && !this.referer.includes("vimeo.com") && this.origin.endsWith("player.vimeo.com");
		}
		toPublicUrl(videoId) {
			const [id, hash] = videoId.split(":", 2);
			return hash ? `${this.DEFAULT_SITE_ORIGIN}/${id}/${hash}` : `${this.DEFAULT_SITE_ORIGIN}/${id}`;
		}
		returnPublicBaseData(videoId) {
			const baseData = this.returnBaseData(videoId);
			if (!baseData) return;
			return {
				...baseData,
				url: this.toPublicUrl(videoId)
			};
		}
		normalizePublicVideoUrl(url, videoId) {
			try {
				const parsed = new URL(url);
				if (parsed.hostname === "player.vimeo.com") return this.toPublicUrl(videoId);
				if (parsed.hostname.endsWith("vimeo.com")) {
					const colonMatch = /^\/(\d+):([a-z0-9]+)$/i.exec(parsed.pathname);
					if (colonMatch) return `${this.DEFAULT_SITE_ORIGIN}/${colonMatch[1]}/${colonMatch[2]}`;
				}
			} catch {}
			return url;
		}
		async getViewerData() {
			try {
				const data = await (await this.fetch("https://vimeo.com/_next/viewer")).json();
				const { apiUrl, jwt } = data;
				this.API_ORIGIN = `https://${apiUrl}`;
				this.API_KEY = `jwt ${jwt}`;
				return data;
			} catch (err) {
				Logger.error(`Failed to get default viewer data.`, err.message);
				return false;
			}
		}
		async getVideoInfo(videoId) {
			try {
				const params = new URLSearchParams({ fields: "name,link,description,duration" }).toString();
				const data = await (await this.fetch(`${this.API_ORIGIN}/videos/${videoId}?${params}`, { headers: { Authorization: this.API_KEY } })).json();
				if (this.isErrorData(data)) throw new Error(data.developer_message ?? data.error);
				return data;
			} catch (err) {
				Logger.error(`Failed to get video info by video ID: ${videoId}`, err.message);
				return false;
			}
		}
		async getPrivateVideoSource(files) {
			try {
				const { default_cdn, cdns } = files.dash;
				const cdnUrl = cdns[default_cdn].url;
				const res = await this.fetch(cdnUrl);
				if (res.status !== 200) throw new VideoHelperError(await res.text());
				const data = await res.json();
				const baseUrl = new URL(data.base_url, cdnUrl);
				const videoData = data.audio.find((v) => v.mime_type === "audio/mp4" && v.format === "dash");
				if (!videoData) throw new VideoHelperError("Failed to find video data");
				const segmentUrl = videoData.segments?.[0]?.url;
				if (!segmentUrl) throw new VideoHelperError("Failed to find first segment url");
				const [videoName, videoParams] = segmentUrl.split("?", 2);
				const params = new URLSearchParams(videoParams);
				params.delete("range");
				return new URL(`${videoData.base_url}${videoName}?${params.toString()}`, baseUrl).href;
			} catch (err) {
				Logger.error(`Failed to get private video source`, err.message);
				return false;
			}
		}
		async getPrivateVideoInfo(videoId) {
			try {
				if (typeof playerConfig === "undefined") return;
				const videoSource = await this.getPrivateVideoSource(playerConfig.request.files);
				if (!videoSource) throw new VideoHelperError("Failed to get private video source");
				const { video: { title, duration }, request: { text_tracks: subs } } = playerConfig;
				return {
					url: `${this.SITE_ORIGIN}/${videoId}`,
					video_url: videoSource,
					title,
					duration,
					subs
				};
			} catch (err) {
				Logger.error(`Failed to get private video info by video ID: ${videoId}`, err.message);
				return false;
			}
		}
		async getSubsInfo(videoId) {
			try {
				const params = new URLSearchParams({
					per_page: "100",
					fields: "language,type,link"
				}).toString();
				const content = await (await this.fetch(`${this.API_ORIGIN}/videos/${videoId}/texttracks?${params}`, { headers: { Authorization: this.API_KEY } })).json();
				if (this.isErrorData(content)) throw new Error(content.developer_message ?? content.error);
				return content.data;
			} catch (err) {
				Logger.error(`Failed to get subtitles info by video ID: ${videoId}`, err.message);
				return [];
			}
		}
		async getVideoData(videoId) {
			if (this.isPrivatePlayer()) {
				const videoInfo = await this.getPrivateVideoInfo(videoId);
				if (!videoInfo) return;
				const { url, subs, video_url, title, duration } = videoInfo;
				const subtitles = subs.map((sub) => ({
					language: normalizeLang(sub.lang),
					source: "vimeo",
					format: "vtt",
					url: new URL(sub.url, this.SITE_ORIGIN).href,
					isAutoGenerated: sub.lang.includes("autogenerated")
				}));
				const translationHelp = subtitles.length ? [{
					target: "video_file_url",
					targetUrl: video_url
				}, {
					target: "subtitles_file_url",
					targetUrl: subtitles[0].url
				}] : null;
				return {
					...translationHelp ? {
						url,
						translationHelp
					} : { url: video_url },
					subtitles,
					title,
					duration
				};
			}
			if (!this.extraInfo) return this.returnPublicBaseData(videoId);
			if (videoId.includes("/")) videoId = videoId.replace("/", ":");
			if (!await this.getViewerData()) return this.returnPublicBaseData(videoId);
			const videoInfo = await this.getVideoInfo(videoId);
			if (!videoInfo) return this.returnPublicBaseData(videoId);
			const subtitles = (await this.getSubsInfo(videoId)).map((caption) => ({
				language: normalizeLang(caption.language),
				source: "vimeo",
				format: "vtt",
				url: caption.link,
				isAutoGenerated: caption.language.includes("autogen")
			}));
			const { link, duration, name: title, description } = videoInfo;
			return {
				url: this.normalizePublicVideoUrl(link, videoId),
				title,
				description,
				subtitles,
				duration
			};
		}
		async getVideoId(url) {
			const normalizedPathname = url.pathname.replace(/\/+$/, "");
			const embedId = /video\/[^/]+$/.exec(normalizedPathname)?.[0];
			if (this.isPrivatePlayer()) return embedId;
			if (embedId) {
				const hash = url.searchParams.get("h");
				const videoId = embedId.replace("video/", "");
				return hash ? `${videoId}/${hash}` : videoId;
			}
			const categoriesVideoId = /channels\/[^/]+\/([^/]+)/.exec(normalizedPathname)?.[1] ?? /groups\/[^/]+\/videos\/([^/]+)/.exec(normalizedPathname)?.[1] ?? /(showcase|album)\/[^/]+\/video\/([^/]+)/.exec(normalizedPathname)?.[2];
			if (categoriesVideoId) return categoriesVideoId;
			return /([^/]+\/)?[^/]+$/.exec(normalizedPathname)?.[0];
		}
	};
	var VKHelper = class VKHelper extends BaseHelper {
		static getPlayer() {
			if (typeof Videoview === "undefined") return;
			return Videoview?.getPlayerObject?.call(void 0);
		}
		async getVideoData(videoId) {
			const player = VKHelper.getPlayer();
			if (!player) return this.returnBaseData(videoId);
			try {
				const { description: descriptionHTML, duration, md_title: title } = player.vars;
				const doc = new DOMParser().parseFromString(descriptionHTML, "text/html");
				const description = Array.from(doc.body.childNodes).filter((el) => el.nodeName !== "BR").map((el) => el.textContent).join("\n");
				let subtitles;
				if (Object.hasOwn(player.vars, "subs")) subtitles = player.vars.subs.map((sub) => ({
					language: normalizeLang(sub.lang),
					source: "vk",
					format: "vtt",
					url: sub.url,
					isAutoGenerated: !!sub.is_auto
				}));
				return {
					url: this.service?.url + videoId,
					title,
					description,
					duration,
					subtitles
				};
			} catch (err) {
				Logger.error(`Failed to get VK video data, because: ${err.message}`);
				return this.returnBaseData(videoId);
			}
		}
		async getVideoId(url) {
			const pathID = /^\/(video|clip)-?\d{8,9}_\d{9}$/.exec(url.pathname);
			if (pathID) return pathID[0].slice(1);
			const idInsidePlaylist = /\/playlist\/[^/]+\/(video-?\d{8,9}_\d{9})/.exec(url.pathname);
			if (idInsidePlaylist) return idInsidePlaylist[1];
			const paramZ = url.searchParams.get("z");
			if (paramZ) return paramZ.split("/")[0];
			const paramOID = url.searchParams.get("oid");
			const paramID = url.searchParams.get("id");
			if (paramOID && paramID) return `video-${Math.abs(parseInt(paramOID, 10))}_${paramID}`;
		}
	};
	var WatchPornToHelper = class extends BaseHelper {
		async getVideoId(url) {
			return /(video|embed)\/(\d+)(\/[^/]+\/)?/.exec(url.pathname)?.[0];
		}
	};
	var weiboVideoIdRe = /^\d+:(?:[\da-f]{32}|\d{16,})$/i;
	var weiboLayerIdRe = /^[A-Za-z0-9]+$/;
	var weiboHostRe = /^(?:www\.)?weibo\.com$/;
	var weiboLoginPathRe = /^\/newlogin\/?$/;
	var WeiboHelper = class extends BaseHelper {
		async getVideoId(url) {
			if (url.hostname === "video.weibo.com") {
				const fid = url.searchParams.get("fid");
				if (!fid || !weiboVideoIdRe.test(fid)) return;
				return `tv/show/${fid}`;
			}
			if (weiboHostRe.test(url.host) && weiboLoginPathRe.test(url.pathname)) {
				const nestedUrl = url.searchParams.get("url");
				if (nestedUrl) try {
					const parsedNestedUrl = new URL(nestedUrl, url.origin);
					if (parsedNestedUrl.href !== url.href) {
						const nestedVideoId = await this.getVideoId(parsedNestedUrl);
						if (nestedVideoId) return nestedVideoId;
					}
				} catch {}
				const layerId = url.searchParams.get("layerid");
				if (layerId && weiboLayerIdRe.test(layerId)) return `0/${layerId}`;
			}
			const normalizedPath = url.pathname.replace(/\/+$/, "");
			if (/^\/\d+\/[A-Za-z0-9]+$/.test(normalizedPath) || /^\/0\/[A-Za-z0-9]+$/.test(normalizedPath) || /^\/tv\/show\/\d+:(?:[\da-f]{32}|\d{16,})$/i.test(normalizedPath)) return normalizedPath.slice(1);
		}
	};
	var { componentVersion } = config;
	var utf8Encoder = new TextEncoder();
	function getBrowserCrypto() {
		const cryptoApi = globalThis.crypto ?? (typeof window !== "undefined" ? window.crypto : void 0);
		if (!cryptoApi?.subtle) throw new Error("Web Crypto API is not available in this browser context");
		return cryptoApi;
	}
	async function signHMAC(hashName, hmac, data) {
		const cryptoApi = getBrowserCrypto();
		const key = await cryptoApi.subtle.importKey("raw", utf8Encoder.encode(hmac), {
			name: "HMAC",
			hash: { name: hashName }
		}, false, ["sign", "verify"]);
		return cryptoApi.subtle.sign("HMAC", key, data);
	}
	async function getHmacSha1(hmacKey, salt) {
		try {
			const signature = await signHMAC("SHA-1", hmacKey, utf8Encoder.encode(salt));
			return btoa(String.fromCharCode(...new Uint8Array(signature)));
		} catch (error) {
			Logger.error(error);
			return false;
		}
	}
	`${yandexBrowserMajorMinorVersion}`, `${chromiumFullVersion}${componentVersion}`;
	var WeverseHelper = class extends BaseHelper {
		API_ORIGIN = "https://global.apis.naver.com/weverse/wevweb";
		API_APP_ID = "be4d79eb8fc7bd008ee82c8ec4ff6fd4";
		API_HMAC_KEY = "1b9cb6378d959b45714bec49971ade22e6e24e42";
		HEADERS = {
			Accept: "application/json, text/plain, */*",
			Origin: "https://weverse.io",
			Referer: "https://weverse.io/"
		};
		getURLData() {
			return {
				appId: this.API_APP_ID,
				language: "en",
				os: "WEB",
				platform: "WEB",
				wpf: "pc"
			};
		}
		async createHash(pathname) {
			const timestamp = Date.now();
			const salt = pathname.substring(0, Math.min(255, pathname.length)) + timestamp;
			const sign = await getHmacSha1(this.API_HMAC_KEY, salt);
			if (!sign) throw new VideoHelperError("Failed to get weverse HMAC signature");
			return {
				wmsgpad: timestamp.toString(),
				wmd: sign
			};
		}
		async getHashURLParams(pathname) {
			const hash = await this.createHash(pathname);
			return new URLSearchParams(hash).toString();
		}
		async getPostPreview(postId) {
			const pathname = `/post/v1.0/post-${postId}/preview?` + new URLSearchParams({
				fieldSet: "postForPreview",
				...this.getURLData()
			}).toString();
			try {
				const urlParams = await this.getHashURLParams(pathname);
				return await (await this.fetch(`${this.API_ORIGIN + pathname}&${urlParams}`, { headers: this.HEADERS })).json();
			} catch (err) {
				Logger.error(`Failed to get weverse post preview by postId: ${postId}`, err.message);
				return false;
			}
		}
		async getVideoInKey(videoId) {
			const pathname = `/video/v1.1/vod/${videoId}/inKey?` + new URLSearchParams({
				gcc: "RU",
				...this.getURLData()
			}).toString();
			try {
				const urlParams = await this.getHashURLParams(pathname);
				return await (await this.fetch(`${this.API_ORIGIN + pathname}&${urlParams}`, {
					method: "POST",
					headers: this.HEADERS
				})).json();
			} catch (err) {
				Logger.error(`Failed to get weverse InKey by videoId: ${videoId}`, err.message);
				return false;
			}
		}
		async getVideoInfo(infraVideoId, inkey, serviceId) {
			const timestamp = Date.now();
			try {
				const urlParams = new URLSearchParams({
					key: inkey,
					sid: serviceId,
					nonce: timestamp.toString(),
					devt: "html5_pc",
					prv: "N",
					aup: "N",
					stpb: "N",
					cpl: "en",
					env: "prod",
					lc: "en",
					adi: JSON.stringify([{ adSystem: null }]),
					adu: "/"
				}).toString();
				return await (await this.fetch(`https://global.apis.naver.com/rmcnmv/rmcnmv/vod/play/v2.0/${infraVideoId}?` + urlParams, { headers: this.HEADERS })).json();
			} catch (err) {
				Logger.error(`Failed to get weverse video info (infraVideoId: ${infraVideoId}, inkey: ${inkey}, serviceId: ${serviceId}`, err.message);
				return false;
			}
		}
		extractVideoInfo(videoList) {
			return videoList.find((video) => video.useP2P === false && video.source.includes(".mp4"));
		}
		async getVideoData(videoId) {
			const videoPreview = await this.getPostPreview(videoId);
			if (!videoPreview) return;
			const { videoId: internalVideoId, serviceId, infraVideoId } = videoPreview.extension.video;
			if (!(internalVideoId && serviceId && infraVideoId)) return;
			const inkeyData = await this.getVideoInKey(internalVideoId);
			if (!inkeyData) return;
			const videoInfo = await this.getVideoInfo(infraVideoId, inkeyData.inKey, serviceId);
			if (!videoInfo) return;
			const videoItem = this.extractVideoInfo(videoInfo.videos.list);
			if (!videoItem) return;
			return {
				url: videoItem.source,
				duration: videoItem.duration
			};
		}
		async getVideoId(url) {
			return /([^/]+)\/(live|media)\/([^/]+)/.exec(url.pathname)?.[3];
		}
	};
	var XHamsterHelper = class extends BaseHelper {
		async getVideoId(url) {
			return /\/(videos\/[^/]+-[\dA-Za-z]+)\/?$/.exec(url.pathname)?.[1];
		}
	};
	var XVideosHelper = class extends BaseHelper {
		async getVideoId(url) {
			return /[^/]+\/[^/]+$/.exec(url.pathname)?.[0];
		}
	};
	var YandexDiskHelper = class extends BaseHelper {
		API_ORIGIN = window.location.origin;
		CLIENT_PREFIX = "/client/disk";
		INLINE_PREFIX = "/i/";
		DISK_PREFIX = "/d/";
		isErrorData(data) {
			return Object.hasOwn(data, "error");
		}
		async getClientVideoData(videoId) {
			const dialogId = new URL(window.location.href).searchParams.get("idDialog");
			if (!dialogId) return;
			const preloadedScript = document.querySelector("#preloaded-data");
			if (!preloadedScript) return;
			try {
				const { idClient, sk } = JSON.parse(preloadedScript.innerText).config;
				const data = await (await this.fetch(`${this.API_ORIGIN}/models-v2?m=mpfs/info`, {
					method: "POST",
					body: JSON.stringify({
						apiMethod: "mpfs/info",
						connection_id: idClient,
						requestParams: { path: dialogId },
						sk
					}),
					headers: { "Content-Type": "application/json" }
				})).json();
				if (this.isErrorData(data)) throw new VideoHelperError(data.error?.message ?? data.error?.code);
				if (data?.type !== "file") throw new VideoHelperError("Failed to get resource info");
				const { meta: { short_url, video_info }, name } = data;
				if (!video_info) throw new VideoHelperError("There's no video open right now");
				if (!short_url) throw new VideoHelperError("Access to the video is limited");
				const title = this.clearTitle(name);
				const duration = Math.round(video_info.duration / 1e3);
				return {
					url: `https://yadi.sk${videoId}`,
					video_url: short_url,
					title,
					duration,
					videoId: data.path,
					translationHelp: [{
						target: "video_file_url",
						targetUrl: short_url
					}]
				};
			} catch (err) {
				Logger.error(`Failed to get yandex disk video data by video ID: ${videoId}, because ${err.message}`);
				return;
			}
		}
		clearTitle(title) {
			return title.replace(/(\.[^.]+)$/, "");
		}
		getBodyHash(fileHash, sk) {
			const data = JSON.stringify({
				hash: fileHash,
				sk
			});
			return encodeURIComponent(data);
		}
		async fetchList(dirHash, sk, offset = 0) {
			const data = JSON.stringify({
				hash: dirHash,
				sk,
				offset
			});
			const body = encodeURIComponent(data);
			const resData = await (await this.fetch(`${this.API_ORIGIN}/public/api/fetch-list`, {
				method: "POST",
				body
			})).json();
			if (Object.hasOwn(resData, "error")) throw new VideoHelperError("Failed to fetch folder list");
			return resData;
		}
		async getDownloadUrl(fileHash, sk) {
			const body = this.getBodyHash(fileHash, sk);
			const data = await (await this.fetch(`${this.API_ORIGIN}/public/api/download-url`, {
				method: "POST",
				body
			})).json();
			if (data.error) throw new VideoHelperError("Failed to get download url");
			return data.data.url;
		}
		async getDiskVideoData(videoId) {
			try {
				const prefetchEl = document.getElementById("store-prefetch");
				if (!prefetchEl) throw new VideoHelperError("Failed to get prefetch data");
				const resourcePaths = videoId.split("/").slice(3);
				if (!resourcePaths.length) throw new VideoHelperError("Failed to find video file path");
				const { resources, rootResourceId, environment: { sk } } = JSON.parse(prefetchEl.innerText);
				const rootResource = resources[rootResourceId];
				const fileName = resourcePaths[resourcePaths.length - 1];
				const dirPath = resourcePaths.slice(0, -1).join("/");
				const expectedPath = dirPath ? `${rootResource.hash}:/${dirPath}/${fileName}` : `${rootResource.hash}:/${fileName}`;
				let resource = Object.values(resources).find((r) => r.path === expectedPath) || Object.values(resources).find((r) => r.name === fileName && r.type === "file");
				if (!resource && dirPath.length > 0) {
					const folderHash = `${rootResource.hash}:/${dirPath}`;
					let offset = 0;
					let completed = false;
					while (!completed) {
						const listData = await this.fetchList(folderHash, sk, offset);
						const fetchedResources = listData.resources || [];
						if (fetchedResources.length === 0) break;
						resource = fetchedResources.find((r) => r.name === fileName);
						if (resource) break;
						completed = !!listData.completed;
						offset += fetchedResources.length;
					}
				}
				if (!resource) throw new VideoHelperError("Failed to find resource");
				if (resource.type === "dir") throw new VideoHelperError("Path is dir, but expected file");
				const { meta: { short_url, mediatype, videoDuration }, path, name } = resource;
				if (mediatype !== "video") throw new VideoHelperError("Resource isn't a video");
				const title = this.clearTitle(name);
				const duration = videoDuration ? Math.round(videoDuration / 1e3) : 0;
				if (short_url) return {
					url: `https://yadi.sk${videoId}`,
					video_url: short_url,
					duration,
					title,
					videoId: path,
					translationHelp: [{
						target: "video_file_url",
						targetUrl: short_url
					}]
				};
				const downloadUrl = await this.getDownloadUrl(path, sk);
				const proxiedUrl = proxyMedia(new URL(downloadUrl));
				return {
					url: `https://yadi.sk${videoId}`,
					video_url: downloadUrl,
					duration,
					title,
					videoId: path,
					translationHelp: [{
						target: "video_file_url",
						targetUrl: proxiedUrl
					}]
				};
			} catch (err) {
				Logger.error(`Failed to get yandex disk video data by disk video ID: ${videoId}`, err.message);
				return;
			}
		}
		async getVideoData(videoId) {
			if (videoId.startsWith(this.INLINE_PREFIX) || /^\/d\/([^/]+)$/.exec(videoId)) return { url: `https://yadi.sk${videoId}` };
			videoId = decodeURIComponent(videoId);
			if (videoId.startsWith(this.CLIENT_PREFIX)) return await this.getClientVideoData(videoId);
			return await this.getDiskVideoData(videoId);
		}
		async getVideoId(url) {
			if (url.pathname.startsWith(this.CLIENT_PREFIX)) return url.pathname + url.search;
			const fileId = /\/i\/([^/]+)/.exec(url.pathname)?.[0];
			if (fileId) return fileId;
			return /\/d\/([^/]+)/.exec(url.pathname) ? url.pathname : void 0;
		}
	};
	var YoukuHelper = class extends BaseHelper {
		async getVideoId(url) {
			return /v_show\/id_[\w=]+/.exec(url.pathname)?.[0];
		}
	};
	var YoutubeHelper = class YoutubeHelper extends BaseHelper {
		static isMobile() {
			return /^m\.youtube\.com$/.test(window.location.hostname);
		}
		static extractVideoId(url) {
			const rawHash = url.hash.replace(/^#/, "");
			if (rawHash) {
				const normalizedHash = rawHash.startsWith("!") ? rawHash.slice(1) : rawHash;
				let decodedHash = normalizedHash;
				try {
					decodedHash = decodeURIComponent(normalizedHash);
				} catch {}
				try {
					const hashUrl = decodedHash.startsWith("http") ? new URL(decodedHash) : new URL(decodedHash.startsWith("/") ? decodedHash : `/${decodedHash}`, url.origin);
					const hashVideoId = YoutubeHelper.extractVideoId(hashUrl);
					if (hashVideoId) return hashVideoId;
				} catch {
					const hashVideoId = /(?:^|[?&#])v=([^&#]+)/.exec(decodedHash)?.[1];
					if (hashVideoId) return hashVideoId;
				}
			}
			if (url.hostname === "youtu.be") return url.pathname.replace(/^\/+/, "").split("/")[0] || void 0;
			const pathVideoId = /\/(?:watch|embed|shorts|live|v|e)\/([^/?#]+)/.exec(url.pathname)?.[1] ?? void 0;
			if (pathVideoId) return pathVideoId;
			return url.searchParams.get("v") ?? void 0;
		}
		static getPlayer() {
			if (window.location.pathname.startsWith("/shorts/") && !YoutubeHelper.isMobile()) return document.querySelector("#shorts-player");
			return document.querySelector("#movie_player");
		}
		static getPlayerResponse() {
			return YoutubeHelper.getPlayer()?.getPlayerResponse?.call(void 0);
		}
		static getPlayerData() {
			return YoutubeHelper.getPlayer()?.getVideoData?.call(void 0);
		}
		static getVolume() {
			const player = YoutubeHelper.getPlayer();
			if (player?.getVolume) return player.getVolume() / 100;
			return 1;
		}
		static setVolume(volume) {
			const player = YoutubeHelper.getPlayer();
			if (player?.setVolume) {
				player.setVolume(Math.round(volume * 100));
				return true;
			}
			return false;
		}
		static isMuted() {
			const player = YoutubeHelper.getPlayer();
			if (player?.isMuted) return player.isMuted();
			return false;
		}
		static videoSeek(video, time) {
			Logger.log("videoSeek", time);
			video.currentTime = (YoutubeHelper.getPlayer()?.getProgressState()?.seekableEnd ?? video.currentTime) - time;
		}
		static getPoToken() {
			const player = YoutubeHelper.getPlayer();
			if (!player) return;
			const audioTrack = player.getAudioTrack?.call(void 0);
			if (!audioTrack?.captionTracks?.length) return;
			const audioTrackWithPoToken = audioTrack.captionTracks.find((captionTrack) => captionTrack.url.includes("&pot="));
			if (!audioTrackWithPoToken) return;
			return /&pot=([^&]+)/.exec(audioTrackWithPoToken.url)?.[1];
		}
		static getGlobalConfig() {
			if (typeof yt !== "undefined") return yt?.config_;
			return typeof ytcfg !== "undefined" ? ytcfg?.data_ : void 0;
		}
		static getDeviceParams() {
			const ytconfig = YoutubeHelper.getGlobalConfig();
			if (!ytconfig) return "c=WEB";
			const innertubeClient = ytconfig.INNERTUBE_CONTEXT?.client;
			const deviceParams = new URLSearchParams(ytconfig.DEVICE);
			deviceParams.delete("ceng");
			deviceParams.delete("cengver");
			deviceParams.set("c", innertubeClient?.clientName ?? ytconfig.INNERTUBE_CLIENT_NAME);
			deviceParams.set("cver", innertubeClient?.clientVersion ?? ytconfig.INNERTUBE_CLIENT_VERSION);
			deviceParams.set("cplayer", "UNIPLAYER");
			return deviceParams.toString();
		}
		static getSubtitles(userLang) {
			const playerCaptions = YoutubeHelper.getPlayerResponse()?.captions?.playerCaptionsTracklistRenderer;
			if (!playerCaptions) return [];
			const captionTracks = playerCaptions.captionTracks ?? [];
			const userLangSupported = (playerCaptions.translationLanguages ?? []).find((language) => language.languageCode === userLang);
			const asrLang = captionTracks.find((captionTrack) => captionTrack?.kind === "asr")?.languageCode ?? "en";
			const subtitles = captionTracks.reduce((result, captionTrack) => {
				if (!("languageCode" in captionTrack)) return result;
				const language = captionTrack.languageCode ? normalizeLang(captionTrack.languageCode) : void 0;
				const url = captionTrack.baseUrl;
				if (!language || !url) return result;
				const captionUrl = `${url.startsWith("http") ? url : `${window.location.origin}/${url}`}&fmt=json3`;
				result.push({
					source: "youtube",
					format: "json",
					language,
					isAutoGenerated: captionTrack?.kind === "asr",
					url: captionUrl
				});
				if (userLangSupported && captionTrack.isTranslatable && captionTrack.languageCode === asrLang && userLang !== language) result.push({
					source: "youtube",
					format: "json",
					language: userLang,
					isAutoGenerated: captionTrack?.kind === "asr",
					translatedFromLanguage: language,
					url: `${captionUrl}&tlang=${userLang}`
				});
				return result;
			}, []);
			Logger.log("youtube subtitles:", subtitles);
			return subtitles;
		}
		static getLanguage() {
			if (!YoutubeHelper.isMobile()) {
				const trackInfo = YoutubeHelper.getPlayer()?.getAudioTrack?.call(void 0)?.getLanguageInfo();
				if (trackInfo && trackInfo.id !== "und") return normalizeLang(trackInfo.id.split(".")[0]);
			}
			const autoCaption = YoutubeHelper.getPlayerResponse()?.captions?.playerCaptionsTracklistRenderer.captionTracks.find((caption) => caption.kind === "asr" && caption.languageCode);
			return autoCaption ? normalizeLang(autoCaption.languageCode) : void 0;
		}
		async getVideoData(videoId) {
			const { title: localizedTitle } = YoutubeHelper.getPlayerData() ?? {};
			const { shortDescription: description, isLive: isStream, title } = YoutubeHelper.getPlayerResponse()?.videoDetails ?? {};
			const subtitles = YoutubeHelper.getSubtitles(this.language);
			let detectedLanguage = YoutubeHelper.getLanguage();
			if (detectedLanguage && !availableLangs.includes(detectedLanguage)) detectedLanguage = void 0;
			const duration = YoutubeHelper.getPlayer()?.getDuration?.call(void 0) ?? void 0;
			return {
				url: this.service?.url + videoId,
				isStream,
				title,
				localizedTitle,
				detectedLanguage,
				description,
				subtitles,
				duration
			};
		}
		async getVideoId(url) {
			if (url.searchParams.has("enablejsapi")) {
				const videoUrl = YoutubeHelper.getPlayer()?.getVideoUrl();
				url = videoUrl ? new URL(videoUrl) : url;
			}
			return YoutubeHelper.extractVideoId(url);
		}
	};
	var zdfPlayPathRe = /^\/play\/([^/?#]+)\/([^/?#]+)\/([^/?#]+)\/?$/i;
	var ZDFHelper = class extends BaseHelper {
		async getVideoId(url) {
			const match = zdfPlayPathRe.exec(url.pathname);
			if (!match) return;
			const [, publicationForm, collectionCanonical, videoCanonical] = match;
			return `${publicationForm}/${collectionCanonical}/${videoCanonical}`;
		}
	};
	var availableHelpers = {
		[VideoService$1.mailru]: MailRuHelper,
		[VideoService$1.weverse]: WeverseHelper,
		[VideoService$1.weibo]: WeiboHelper,
		[VideoService$1.kodik]: KodikHelper,
		[VideoService$1.patreon]: PatreonHelper,
		[VideoService$1.reddit]: RedditHelper,
		[VideoService$1.bannedvideo]: BannedVideoHelper,
		[VideoService$1.kick]: KickHelper,
		[VideoService$1.appledeveloper]: AppleDeveloperHelper,
		[VideoService$1.epicgames]: EpicGamesHelper,
		[VideoService$1.odysee]: OdyseeHelper,
		[VideoService$1.coursehunterLike]: CoursehunterLikeHelper,
		[VideoService$1.twitch]: TwitchHelper,
		[VideoService$1.sap]: SapHelper,
		[VideoService$1.jove]: JoveHelper,
		[VideoService$1.linkedin]: LinkedinHelper,
		[VideoService$1.vimeo]: VimeoHelper,
		[VideoService$1.yandexdisk]: YandexDiskHelper,
		[VideoService$1.vk]: VKHelper,
		[VideoService$1.trovo]: TrovoHelper,
		[VideoService$1.incestflix]: IncestflixHelper,
		[VideoService$1.porntn]: PornTNHelper,
		[VideoService$1.googledrive]: GoogleDriveHelper,
		[VideoService$1.bilibili]: BilibiliHelper,
		[VideoService$1.xvideos]: XVideosHelper,
		[VideoService$1.xhamster]: XHamsterHelper,
		[VideoService$1.spankbang]: SpankBangHelper,
		[VideoService$1.rule34video]: Rule34VideoHelper,
		[VideoService$1.picarto]: PicartoHelper,
		[VideoService$1.olympicsreplay]: OlympicsReplayHelper,
		[VideoService$1.watchpornto]: WatchPornToHelper,
		[VideoService$1.archive]: ArchiveHelper,
		[VideoService$1.dailymotion]: DailymotionHelper,
		[VideoService$1.youku]: YoukuHelper,
		[VideoService$1.egghead]: EggheadHelper,
		[VideoService$1.newgrounds]: NewgroundsHelper,
		[VideoService$1.okru]: OKRuHelper,
		[VideoService$1.peertube]: PeertubeHelper,
		[VideoService$1.eporner]: EpornerHelper,
		[VideoService$1.bitchute]: BitchuteHelper,
		[VideoService$1.rutube]: RutubeHelper,
		[VideoService$1.facebook]: FacebookHelper,
		[VideoService$1.rumble]: RumbleHelper,
		[VideoService$1.twitter]: TwitterHelper,
		[VideoService$1.pornhub]: PornhubHelper,
		[VideoService$1.tiktok]: TikTokHelper,
		[VideoService$1.proxitok]: TikTokHelper,
		[VideoService$1.nine_gag]: NineGAGHelper,
		[VideoService$1.youtube]: YoutubeHelper,
		[VideoService$1.preservetube]: PreserveTubeHelper,
		[VideoService$1.invidious]: YoutubeHelper,
		[VideoService$1.piped]: YoutubeHelper,
		[VideoService$1.zdf]: ZDFHelper,
		[VideoService$1.dzen]: DzenHelper,
		[VideoService$1.bunnystream]: BunnyStreamHelper,
		[VideoService$1.cloudflarestream]: CloudflareStreamHelper,
		[VideoService$1.loom]: LoomHelper,
		[VideoService$1.rtnews]: RtNewsHelper,
		[VideoService$1.bitview]: BitviewHelper,
		[VideoService$1.thisvid]: ThisVidHelper,
		[VideoService$1.ign]: IgnHelper,
		[VideoService$1.bunkr]: BunkrHelper,
		[VideoService$1.imdb]: IMDbHelper,
		[VideoService$1.telegram]: TelegramHelper,
		[VideoService$1.niconico]: NicoNicoHelper,
		[VideoService$1.noodlemagazine]: NoodleMagazineHelper,
		[ExtVideoService.udemy]: UdemyHelper,
		[ExtVideoService.coursera]: CourseraHelper,
		[ExtVideoService.douyin]: DouyinHelper,
		[ExtVideoService.artstation]: ArtstationHelper,
		[ExtVideoService.kickstarter]: KickstarterHelper,
		[ExtVideoService.datacamp]: DataCampHelper,
		[ExtVideoService.oraclelearn]: OracleLearnHelper,
		[ExtVideoService.deeplearningai]: DeeplearningAIHelper,
		[ExtVideoService.netacad]: NetacadHelper,
		[ExtVideoService.mediafile]: MediafileHelper,
		[ExtVideoService.skilljar]: SkilljarHelper
	};
	var VideoHelper = class {
		helpersData;
		constructor(helpersData = {}) {
			this.helpersData = helpersData;
		}
		getHelper(service) {
			return new availableHelpers[service](this.helpersData);
		}
	};
	function hasHelper(host) {
		return host in availableHelpers;
	}
	function getService() {
		if (localLinkRe.exec(window.location.href)) return [];
		const hostname = window.location.hostname;
		const enteredURL = new URL(window.location.href);
		const isMatches = (match) => {
			if (match instanceof RegExp) return match.test(hostname);
			else if (typeof match === "string") return hostname.includes(match);
			else if (typeof match === "function") return match(enteredURL);
			return false;
		};
		return sites_default.filter((e) => {
			return !!e.match && (Array.isArray(e.match) ? e.match.some(isMatches) : isMatches(e.match)) && e.host && e.url;
		});
	}
	async function getVideoID(service, opts = {}) {
		const url = new URL(window.location.href);
		const serviceHost = service.host;
		if (hasHelper(serviceHost)) return await new VideoHelper(opts).getHelper(serviceHost).getVideoId(url);
		return serviceHost === VideoService$1.custom ? url.href : void 0;
	}
	async function getVideoData(service, opts = {}) {
		const currentUrl = new URL(window.location.href);
		const videoId = await getVideoID(service, opts);
		if (!videoId) throw new VideoDataError(`Entered unsupported link: "${service.host}"`);
		const origin = currentUrl.origin;
		if ([
			VideoService$1.peertube,
			VideoService$1.coursehunterLike,
			VideoService$1.bunnystream,
			VideoService$1.cloudflarestream
		].includes(service.host)) service.url = origin;
		if (service.rawResult) return {
			url: videoId,
			videoId,
			host: service.host,
			duration: void 0
		};
		if (!service.needExtraData) return {
			url: service.url + videoId,
			videoId,
			host: service.host,
			duration: void 0
		};
		if (!hasHelper(service.host)) throw new VideoDataError(`No helper is available for "${service.host}"`);
		const result = await new VideoHelper({
			...opts,
			service,
			origin
		}).getHelper(service.host).getVideoData(videoId);
		if (!result) throw new VideoDataError(`Failed to get video raw url for ${service.host}`);
		return {
			...result,
			url: result.url,
			videoId,
			host: service.host
		};
	}
	var SAFARI_PAGE_RUNTIME_REQUEST = "__vot_safari_page_runtime_request__";
	var SAFARI_PAGE_RUNTIME_RESPONSE = "__vot_safari_page_runtime_response__";
	var SAFARI_PAGE_RUNTIME_READY = "__vot_safari_page_runtime_ready__";
	var SAFARI_PAGE_RUNTIME_READY_DATASET = "votSafariPageRuntimeReady";
	var SAFARI_GM_REQUEST = "__vot_safari_gm_request__";
	var SAFARI_GM_RESPONSE = "__vot_safari_gm_response__";
	var SAFARI_GM_ABORT = "__vot_safari_gm_abort__";
	var CLIENT_FLAG = "__votSafariGmBridgeClientInstalled__";
	function makeRequestId() {
		return `${Date.now()}:${Math.random().toString(36).slice(2)}`;
	}
	function arrayBufferToBase64(buffer) {
		const bytes = new Uint8Array(buffer);
		let binary = "";
		const chunkSize = 32768;
		for (let index = 0; index < bytes.length; index += chunkSize) binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
		return btoa(binary);
	}
	function base64ToArrayBuffer(value) {
		const binary = atob(value);
		const bytes = new Uint8Array(binary.length);
		for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
		return bytes.buffer;
	}
	async function serializeBody(body) {
		if (body == null) return void 0;
		if (typeof body === "string") return {
			type: "text",
			value: body
		};
		if (body instanceof URLSearchParams) return {
			type: "text",
			value: body.toString()
		};
		if (body instanceof Blob) return {
			type: "base64",
			value: arrayBufferToBase64(await body.arrayBuffer()),
			mimeType: body.type || void 0
		};
		if (body instanceof ArrayBuffer) return {
			type: "base64",
			value: arrayBufferToBase64(body)
		};
		if (ArrayBuffer.isView(body)) {
			const view = body;
			const bytes = new Uint8Array(view.byteLength);
			bytes.set(new Uint8Array(view.buffer, view.byteOffset, view.byteLength));
			return {
				type: "base64",
				value: arrayBufferToBase64(bytes.buffer)
			};
		}
		return {
			type: "text",
			value: String(body)
		};
	}
	function deserializeBody(body) {
		if (!body) return null;
		if (body.type === "text") return body.value;
		const buffer = base64ToArrayBuffer(body.value);
		if (body.mimeType) return new Blob([buffer], { type: body.mimeType });
		return buffer;
	}
	function headersToRecord(headers) {
		if (!headers) return void 0;
		if (headers instanceof Headers) return Object.fromEntries(headers.entries());
		if (Array.isArray(headers)) return Object.fromEntries(headers);
		return headers;
	}
	function parseRawResponseHeaders(rawHeaders) {
		if (!rawHeaders) return {};
		return rawHeaders.split(/\r?\n/).reduce((acc, line) => {
			const match = /^([\w-]+):\s*(.+)$/.exec(line);
			if (match) acc[match[1]] = match[2];
			return acc;
		}, {});
	}
	function parseBridgeResponse(detail) {
		if (typeof detail === "string") try {
			return JSON.parse(detail);
		} catch {
			return;
		}
		if (detail && typeof detail === "object") return detail;
	}
	async function requestViaMain(request) {
		const id = makeRequestId();
		return await new Promise((resolve) => {
			const timeout = window.setTimeout(() => {
				document.removeEventListener(SAFARI_GM_RESPONSE, onResponse);
				resolve({
					id,
					ok: false,
					phase: "timeout",
					error: "GM bridge timeout"
				});
			}, Math.max(Number(request.timeout || 0), 0) + 5e3);
			function onResponse(event) {
				const response = parseBridgeResponse(event.detail);
				if (!response || response.id !== id) return;
				window.clearTimeout(timeout);
				document.removeEventListener(SAFARI_GM_RESPONSE, onResponse);
				resolve(response);
			}
			document.addEventListener(SAFARI_GM_RESPONSE, onResponse);
			document.dispatchEvent(new CustomEvent(SAFARI_GM_REQUEST, { detail: JSON.stringify({
				...request,
				id
			}) }));
		});
	}
	async function requestToBridgeRequest(input, init = {}) {
		const request = input instanceof Request ? input : void 0;
		return {
			kind: "fetch",
			url: typeof input === "string" ? input : input instanceof URL ? input.href : input.url,
			method: (init.method || request?.method || "GET").toUpperCase(),
			headers: headersToRecord(init.headers || request?.headers),
			body: await serializeBody(init.body ?? void 0),
			timeout: init.timeout,
			forceGmXhr: init.forceGmXhr,
			responseType: "arraybuffer"
		};
	}
	async function safariProxyFetch(input, init = {}) {
		const bridgeRequest = await requestToBridgeRequest(input, init);
		const response = await requestViaMain(bridgeRequest);
		if (!response.ok) throw new TypeError(response.error || `Safari GM bridge ${response.phase}`);
		const body = deserializeBody(response.body);
		const fetchResponse = new Response(body, {
			status: response.status || 200,
			statusText: response.statusText || "",
			headers: response.headers
		});
		Object.defineProperty(fetchResponse, "url", { value: response.finalUrl || response.responseURL || bridgeRequest.url });
		return fetchResponse;
	}
	function safariProxyGMXmlHttpRequest(details) {
		const id = makeRequestId();
		let settled = false;
		const cleanup = () => {
			document.removeEventListener(SAFARI_GM_RESPONSE, onResponse);
		};
		function finish(callback) {
			if (settled) return;
			settled = true;
			cleanup();
			callback?.();
		}
		function onResponse(event) {
			const response = parseBridgeResponse(event.detail);
			if (!response || response.id !== id) return;
			if (response.phase === "timeout") {
				finish(details.ontimeout);
				return;
			}
			if (response.phase === "abort") {
				finish(details.onabort);
				return;
			}
			if (!response.ok) {
				finish(() => details.onerror?.(response));
				return;
			}
			const responseBody = deserializeBody(response.body);
			const rawHeaders = response.responseHeadersRaw || "";
			const textBody = response.body?.type === "text" ? response.body.value : "";
			const xhrResponse = {
				status: response.status || 0,
				statusText: response.statusText || "",
				finalUrl: response.finalUrl,
				responseURL: response.responseURL || response.finalUrl,
				responseHeaders: rawHeaders,
				responseText: textBody,
				response: details.responseType === "arraybuffer" ? response.body?.type === "base64" ? base64ToArrayBuffer(response.body.value) : textBody : details.responseType === "blob" ? responseBody : textBody,
				getAllResponseHeaders: () => rawHeaders,
				responseHeadersObject: response.headers || parseRawResponseHeaders(rawHeaders)
			};
			finish(() => details.onload?.(xhrResponse));
		}
		document.addEventListener(SAFARI_GM_RESPONSE, onResponse);
		serializeBody(details.data).then((body) => {
			if (settled) return;
			document.dispatchEvent(new CustomEvent(SAFARI_GM_REQUEST, { detail: JSON.stringify({
				id,
				kind: "xhr",
				url: details.url,
				method: details.method || "GET",
				headers: details.headers,
				body,
				timeout: details.timeout,
				anonymous: details.anonymous,
				responseType: details.responseType === "arraybuffer" || details.responseType === "blob" ? details.responseType : "text"
			}) }));
		});
		return { abort() {
			if (settled) return;
			document.dispatchEvent(new CustomEvent(SAFARI_GM_ABORT, { detail: JSON.stringify({ id }) }));
			finish(details.onabort);
		} };
	}
	function installSafariGmBridgeClient() {
		const state = globalThis;
		if (state[CLIENT_FLAG]) return;
		state[CLIENT_FLAG] = true;
		globalThis.GM_xmlhttpRequest = safariProxyGMXmlHttpRequest;
	}
	var RUNTIME_FLAG = "__votSafariPageRuntimeInstalled__";
	function parseRequestDetail(detail) {
		if (typeof detail === "string") try {
			return JSON.parse(detail);
		} catch {
			return;
		}
		if (detail && typeof detail === "object") return detail;
	}
	function dispatchResponse(response) {
		document.dispatchEvent(new CustomEvent(SAFARI_PAGE_RUNTIME_RESPONSE, { detail: JSON.stringify(response) }));
	}
	function findService(serviceHost) {
		if (!serviceHost) return void 0;
		return getService().find((service) => String(service.host) === serviceHost);
	}
	async function handleRequest(request) {
		if (request.action === "ping") return true;
		const service = request.service ?? findService(request.serviceHost);
		if (!service) return;
		const opts = {
			fetchFn: safariProxyFetch,
			service,
			origin: globalThis.location.origin,
			language: request.language ?? "en"
		};
		if (request.action === "getVideoID") return await getVideoID(service, opts);
		if (request.action === "getVideoData") return await getVideoData(service, opts);
	}
	function installSafariPageRuntime() {
		const state = globalThis;
		if (state[RUNTIME_FLAG]) return;
		state[RUNTIME_FLAG] = true;
		installSafariGmBridgeClient();
		try {
			if (document.documentElement?.dataset) document.documentElement.dataset[SAFARI_PAGE_RUNTIME_READY_DATASET] = "1";
		} catch {}
		document.addEventListener(SAFARI_PAGE_RUNTIME_REQUEST, (event) => {
			const request = parseRequestDetail(event.detail);
			if (!request?.id || !request.action) return;
			handleRequest(request).then((result) => {
				dispatchResponse({
					id: request.id,
					ok: true,
					result
				});
			}).catch((error) => {
				dispatchResponse({
					id: request.id,
					ok: false,
					error: error instanceof Error ? error.message : String(error)
				});
			});
		});
		document.dispatchEvent(new CustomEvent(SAFARI_PAGE_RUNTIME_READY, { detail: JSON.stringify({
			ready: true,
			href: globalThis.location.href
		}) }));
		dispatchResponse({
			id: "ready",
			ok: true,
			result: true
		});
	}
	installSafariPageRuntime();
})();
