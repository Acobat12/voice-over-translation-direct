#!/usr/bin/env python3
# Диагностический загрузчик аудиодорожек YouTube.
# Требуется yt-dlp или yt-dlp.exe рядом со скриптом.

import json
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent

def find_ytdlp():
    for name in ("yt-dlp.exe", "yt-dlp"):
        p = HERE / name
        if p.exists():
            return str(p)
    found = shutil.which("yt-dlp")
    if found:
        return found
    raise SystemExit(
        "\nyt-dlp не найден.\n"
        "Положите yt-dlp.exe рядом с этим скриптом "
        "или установите yt-dlp и добавьте его в PATH.\n"
    )

def run_capture(args):
    p = subprocess.run(
        args,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if p.returncode != 0:
        print(p.stderr)
        raise SystemExit(f"Ошибка yt-dlp, код: {p.returncode}")
    return p.stdout

def clean(value):
    return str(value).strip() if value is not None else ""

def main():
    ytdlp = find_ytdlp()

    url = sys.argv[1] if len(sys.argv) > 1 else input("Ссылка на видео YouTube: ").strip()
    if not url:
        raise SystemExit("Ссылка не указана.")

    print("\nПолучаю список форматов и аудиодорожек YouTube...\n")
    raw = run_capture([ytdlp, "--dump-single-json", "--no-playlist", url])
    info = json.loads(raw)

    formats = info.get("formats") or []
    audio = [
        f for f in formats
        if f.get("vcodec") == "none" and f.get("acodec") not in (None, "none")
    ]

    if not audio:
        raise SystemExit("Аудиоформаты без видео не найдены.")

    print(f"Название: {clean(info.get('title'))}")
    print(f"ID видео: {clean(info.get('id'))}")
    print(f"Найдено аудиоформатов: {len(audio)}\n")

    header = f"{'№':>3}  {'format/itag':<14} {'язык':<12} {'кодек':<15} {'битрейт':>8}  описание"
    print(header)
    print("-" * len(header))

    for i, f in enumerate(audio):
        fmt = clean(f.get("format_id"))
        lang = clean(f.get("language")) or "-"
        codec = clean(f.get("acodec")) or "-"
        abr = clean(f.get("abr")) or "-"
        note_parts = [
            clean(f.get("format_note")),
            f"предпочтение языка={clean(f.get('language_preference'))}"
            if f.get("language_preference") is not None else "",
            f"{clean(f.get('audio_channels'))} канал(а)"
            if f.get("audio_channels") else "",
        ]
        note = " | ".join(x for x in note_parts if x)
        print(f"{i:>3}  {fmt:<14.14} {lang:<12.12} {codec:<15.15} {abr:>8.8}  {note}")

    print("\nВыберите ТОЧНУЮ строку аудиодорожки для скачивания.")
    print("Скрипт не будет автоматически выбирать первый попавшийся itag 251/140.")

    while True:
        value = input("Номер строки: ").strip()
        try:
            idx = int(value)
            selected = audio[idx]
            break
        except (ValueError, IndexError):
            print("Неверный номер. Попробуйте ещё раз.")

    fmt_id = str(selected.get("format_id"))
    lang = clean(selected.get("language")) or "unknown"
    safe_lang = "".join(c if c.isalnum() or c in "._-" else "_" for c in lang)

    print("\nВыбрана дорожка:")
    print(json.dumps({
        "строка": idx,
        "format_id/itag": selected.get("format_id"),
        "язык": selected.get("language"),
        "описание": selected.get("format_note"),
        "кодек": selected.get("acodec"),
        "битрейт": selected.get("abr"),
        "каналы": selected.get("audio_channels"),
    }, ensure_ascii=False, indent=2))

    same_id = [f for f in audio if str(f.get("format_id")) == fmt_id]
    if len(same_id) > 1:
        print("\nВНИМАНИЕ: несколько дорожек имеют одинаковый format_id.")
        print("В таком случае выбор только по format_id может быть неоднозначным.")
        print("Рекомендуется использовать свежую версию yt-dlp.\n")

    output = str(
        HERE / f"%(id)s__дорожка-{idx}__язык-{safe_lang}__itag-{fmt_id}.%(ext)s"
    )

    print("\nСкачиваю выбранную аудиодорожку без перекодирования...\n")

    rc = subprocess.call([
        ytdlp,
        "--no-playlist",
        "--no-part",
        "-f", fmt_id,
        "-o", output,
        url,
    ])

    if rc != 0:
        raise SystemExit(f"\nНе удалось скачать аудио. Код ошибки: {rc}")

    print("\nГотово.")
    print("Файл сохранён в папке:")
    print(HERE)
    print(
        "\nАудио не перекодировалось — сохранён поток, "
        "который был выбран из доступных форматов YouTube."
    )

if __name__ == "__main__":
    main()
